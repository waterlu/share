# version

## 1.0.0

配置中心，配置文件在本地项目的resources/properties目录下

