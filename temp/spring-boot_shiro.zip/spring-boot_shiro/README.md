# spring-boot-shiro-starter

## 作用

* 保存/读取当前用户信息
* 控制API访问权限

## 版本

### v1.0.0

* 实现基本权限验证功能

### v1.0.1

* 授权过滤器配置时，不再反转字符串
* 解决创建LifecycleBeanPostProcessor后读取不到Properties的问题

### v1.0.2

* 检查到Session过期时，同时删除会话信息和用户信息

### v1.0.3

* 先关闭lifecycleBeanPostProcessor扫描注解，会引发冲突


## 使用

1、引入pom

```
<dependency>
    <groupId>cn.zjhf.kingold</groupId>
    <artifactId>spring-boot-shiro-starter</artifactId>
    <version>1.0.1-SNAPSHOT</version>
</dependency>
```

2、加入注解@EnableShiroAutoConfiguration

```
@SpringBootApplication
@EnableShiroAutoConfiguration
public class MgtFopApplication {
}
```

3、配置属性

```
# 根据Session使用方式的不同，分为master和slave两种模式，默认是slave模式
# master模式：支持用户登录，将Session和用户信息写入Redis
# slave模式：不支持用户登录，从Redis中读取Session和用户信息，没有读取到则返回401错误
# 默认slave，可不设置
shiro.session-mode=slave

# Cookie中存储SessionID的key
# 默认WEBID，可不设置
shiro.cookie-name=WEBID

# Cookie存储时对应的域名
# master模式下需要指定主域名
# slave模式下不需要设置
# 默认.zj-hf.cn，可不设置
shiro.cookie-domain=.zj-hf.cn

# Redis中存储Session和用户信息的Key
# Session的数据结构为string，主键=shiro.session-key+sessionID
# 用户信息的数据结构为hashset，主键=shiro.session-key
# 默认shiro-session:，可不设置
shiro.session-key=shiro-session:

# Redis中Session对象的有效期，单位为毫秒，默认30分钟
# 默认18000000，可不设置
shiro.session-timeout=18000000

# 对Redis中Session对象有效期做检查的时间间隔，单位为毫秒，默认1分钟
# 默认60000，可不设置
shiro.session-validation-interval=60000

# 当获取不到当前用户信息时的跳转地址（需要返回401错误）
# 默认/api/security/login，需要自己实现controller
shiro.login-url=/api/security/login

# 当用户没有API访问权限时的跳转地址（需要返回403错误）
# 默认/api/security/403，需要自己实现controller
shiro.unauthorized-url=/api/security/403

# 设置项目自定义的Realm，用于验证用户身份和获取用户权限，必须实现
# mgt_fop项目给出了一个典型的实现（目前还没有把realm沉到底层）
shiro.realm=

# 设置API访问权限（建议使用注解方式）
# shiro.filter-chain-definitions为map，key不能重复 
#shiro.filter-chain-definitions./advisor/list=perms["fop:advisor:information"]

# 设置API风闻控制的开关，默认为true
# true，对API进行访问权限控制
# false，不对API进行访问权限控制
shiro.perms-enabled=false

```