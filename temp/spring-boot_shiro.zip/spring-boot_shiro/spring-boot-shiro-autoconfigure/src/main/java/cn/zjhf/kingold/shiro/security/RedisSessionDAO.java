package cn.zjhf.kingold.shiro.security;

import cn.zjhf.kingold.shiro.autoconfigure.ShiroProperties;
import cn.zjhf.kingold.shiro.vo.UserVO;
import com.alibaba.fastjson.JSON;
import com.google.common.base.Strings;
import com.google.common.collect.Sets;
import org.apache.shiro.session.Session;
import org.apache.shiro.session.mgt.SimpleSession;
import org.apache.shiro.session.mgt.eis.EnterpriseCacheSessionDAO;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.SimplePrincipalCollection;
import org.apache.shiro.subject.support.DefaultSubjectContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import javax.annotation.Resource;
import java.io.Serializable;
import java.util.Collection;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * Created by lutiehua on 2017/9/13.
 */
public class RedisSessionDAO extends EnterpriseCacheSessionDAO {

    private final static Logger logger = LoggerFactory.getLogger(RedisSessionDAO.class);

    @Autowired
    protected ShiroProperties shiroProperties;

    @Resource(name = "redisObjectTemplate")
    protected RedisTemplate<String, Object> redisObjectTemplate;

    @Resource(name = "redisStringTemplate")
    protected RedisTemplate<String, String> redisStringTemplate;

    /**
     * 主模式：将session写入redis
     * 从模式：没有修改
     *
     * @param session
     * @return
     */
    @Override
    protected Serializable doCreate(Session session) {
        String sessionMode = shiroProperties.getSessionMode();
        if (Strings.isNullOrEmpty(sessionMode)) {
            throw new RuntimeException("sessionMode不能为空");
        }

        if (sessionMode.equalsIgnoreCase(ShiroSessionMode.SLAVE)) {
            return super.doCreate(session);
        }

        if (!sessionMode.equalsIgnoreCase(ShiroSessionMode.MASTER)) {
            throw new RuntimeException("sessionMode只能是master或者slave");
        }

        Serializable sessionId = super.doCreate(session);
        if (null != sessionId) {
            ValueOperations<String, Object> valueOperations = redisObjectTemplate.opsForValue();
            String prefix = shiroProperties.getSessionKey();
            valueOperations.set(prefix + sessionId.toString(), session);
        }

        return sessionId;
    }

    /**
     * 主模式：从redis中读取session，并从redis中读取当前用户信息赋值给session
     * 从模式：从redis中读取session
     *
     * @param sessionId
     * @return
     */
    @Override
    protected Session doReadSession(Serializable sessionId) {
        Session session = super.doReadSession(sessionId);

        String sessionMode = shiroProperties.getSessionMode();
        if (Strings.isNullOrEmpty(sessionMode)) {
            throw new RuntimeException("sessionMode不能为空");
        }

        if (session == null) {
            ValueOperations<String, Object> valueOperations = redisObjectTemplate.opsForValue();
            String prefix = shiroProperties.getSessionKey();
            session = (Session) valueOperations.get(prefix + sessionId.toString());
        }

        if (sessionMode.equalsIgnoreCase(ShiroSessionMode.SLAVE)) {
            return session;
        }

        if (!sessionMode.equalsIgnoreCase(ShiroSessionMode.MASTER)) {
            throw new RuntimeException("sessionMode只能是master或者slave");
        }

        if (null != session && null != session.getId()) {
            HashOperations<String, String, String> hashOperations = redisStringTemplate.opsForHash();
            String prefix = shiroProperties.getSessionKey();
            String jsonString = hashOperations.get(prefix, session.getId().toString());
            if (null != jsonString) {
                UserVO user = JSON.parseObject(jsonString, UserVO.class);
                SimplePrincipalCollection pc = new SimplePrincipalCollection();
                pc.add(user, "RedisSessionDAO");
                session.setAttribute(DefaultSubjectContext.PRINCIPALS_SESSION_KEY, pc);
            }
        }

        return session;
    }

    /**
     * 主模式：更新Redis并刷新时间，更新Hashset中的当前用户信息
     * 从模式：更新Redis并刷新时间
     *
     * @param session
     */
    @Override
    protected void doUpdate(Session session) {
        super.doUpdate(session);

        String sessionMode = shiroProperties.getSessionMode();
        if (Strings.isNullOrEmpty(sessionMode)) {
            throw new RuntimeException("sessionMode不能为空");
        }

        String prefix = shiroProperties.getSessionKey();

        if (sessionMode.equalsIgnoreCase(ShiroSessionMode.SLAVE)) {
            String key = prefix + session.getId().toString();
            if (!redisObjectTemplate.hasKey(key)) {
                ValueOperations<String, Object> valueOperations = redisObjectTemplate.opsForValue();
                valueOperations.set(key, session);
            }
            redisObjectTemplate.expire(key, shiroProperties.getSessionTimeout() / 1000, TimeUnit.SECONDS);
            return;
        }

        if (!sessionMode.equalsIgnoreCase(ShiroSessionMode.MASTER)) {
            throw new RuntimeException("sessionMode只能是master或者slave");
        }

        PrincipalCollection pc = (PrincipalCollection)session.getAttribute(DefaultSubjectContext.PRINCIPALS_SESSION_KEY);
        if (null != pc) {
            HashOperations<String, String, String> hashOperations = redisStringTemplate.opsForHash();
            UserVO user = (UserVO) pc.getPrimaryPrincipal();
            String jsonString = JSON.toJSONString(user);
            String sessionId = session.getId().toString();
            hashOperations.put(prefix, sessionId, jsonString);
        }

        String key = prefix + session.getId().toString();
        if (!redisObjectTemplate.hasKey(key)) {
            ValueOperations<String, Object> valueOperations = redisObjectTemplate.opsForValue();
            valueOperations.set(key, session);
        }
        redisObjectTemplate.expire(key, shiroProperties.getSessionTimeout() / 1000, TimeUnit.SECONDS);
    }

    /**
     * 主模式：删除session和用户信息
     * 从模式：没有修改
     *
     * @param session
     */
    @Override
    protected void doDelete(Session session) {
        super.doDelete(session);

        String sessionMode = shiroProperties.getSessionMode();
        if (Strings.isNullOrEmpty(sessionMode)) {
            throw new RuntimeException("sessionMode不能为空");
        }

        if (sessionMode.equalsIgnoreCase(ShiroSessionMode.SLAVE)) {
            return;
        }

        if (!sessionMode.equalsIgnoreCase(ShiroSessionMode.MASTER)) {
            throw new RuntimeException("sessionMode只能是master或者slave");
        }

        String prefix = shiroProperties.getSessionKey();
        redisObjectTemplate.delete(prefix + session.getId().toString());
        HashOperations<String, String, String> hashOperations = redisStringTemplate.opsForHash();
        hashOperations.delete(prefix, session.getId().toString());
    }

    @Override
    public Collection<Session> getActiveSessions() {
        Set<Session> sessions = Sets.newHashSet();
        String prefix = shiroProperties.getSessionKey();
        HashOperations<String, String, String> hashOperations = redisStringTemplate.opsForHash();
        Set<String> hashKeys = hashOperations.keys(prefix);
        for(String hashKey : hashKeys) {
            String key = prefix + hashKey;
            if (!redisObjectTemplate.hasKey(key)) {
                logger.info("remove session {}", key);
                hashOperations.delete(prefix, hashKey);
                continue;
            }
            SimpleSession session = new SimpleSession();
            session.setId(key);
            sessions.add(session);
        }

        return sessions;
    }
}