package cn.zjhf.kingold.shiro.util;

import cn.zjhf.kingold.shiro.vo.UserVO;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.Subject;

/**
 * Created by lutiehua on 2017/9/13.
 */
public class ShiroUtil {

    /**
     * 从Subject中直接读取当前用户
     *
     * @return
     */
    public static UserVO getUser() {
        Subject subject = SecurityUtils.getSubject();
        if (null == subject) {
            return null;
        }

        Session session = subject.getSession(false);
        if (null == session) {
            return null;
        }

        PrincipalCollection principalCollection = subject.getPrincipals();
        if (null == principalCollection) {
            return null;
        }

        UserVO user = (UserVO)principalCollection.getPrimaryPrincipal();
        return user;
    }

    public static Object getObject() {
        Subject subject = SecurityUtils.getSubject();
        if (null == subject) {
            return null;
        }

        Session session = subject.getSession(false);
        if (null == session) {
            return null;
        }

        PrincipalCollection principalCollection = subject.getPrincipals();
        if (null == principalCollection) {
            return null;
        }

        return principalCollection.getPrimaryPrincipal();
    }
}