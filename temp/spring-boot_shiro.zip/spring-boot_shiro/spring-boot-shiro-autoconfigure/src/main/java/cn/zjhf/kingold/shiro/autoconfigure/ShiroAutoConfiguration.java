package cn.zjhf.kingold.shiro.autoconfigure;

import cn.zjhf.kingold.shiro.security.*;
import com.google.common.base.Strings;
import org.apache.shiro.cache.ehcache.EhCacheManager;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.spring.security.interceptor.AuthorizationAttributeSourceAdvisor;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.WebSecurityManager;
import org.apache.shiro.web.servlet.SimpleCookie;
import org.apache.shiro.web.session.mgt.WebSessionManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.framework.autoproxy.DefaultAdvisorAutoProxyCreator;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.data.redis.RedisProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Import;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import java.util.LinkedHashMap;
import java.util.Map;

@Configuration
@ConditionalOnBean(annotation = EnableShiroAutoConfiguration.class)
@EnableConfigurationProperties(value = {ShiroProperties.class, RedisProperties.class})
@Import(ShiroLifecycleBeanConfiguration.class)
public class ShiroAutoConfiguration {

    private static Logger logger = LoggerFactory.getLogger(ShiroAutoConfiguration.class);

	@Autowired
	private ShiroProperties shiroProperties;

	@Autowired
	private RedisProperties redisProperties;

	@Bean
	@ConditionalOnMissingBean(JedisConnectionFactory.class)
	public JedisConnectionFactory redisConnectionFactory() {
		JedisConnectionFactory redisConnectionFactory = new JedisConnectionFactory();
		redisConnectionFactory.setHostName(redisProperties.getHost());
		redisConnectionFactory.setPassword(redisProperties.getPassword());
		redisConnectionFactory.setPort(redisProperties.getPort());
		redisConnectionFactory.setDatabase(redisProperties.getDatabase());
		return redisConnectionFactory;
	}

	@Bean(name = "redisObjectTemplate")
	@ConditionalOnMissingBean(name = "redisObjectTemplate")
	public RedisTemplate<String, Object> redisObjectTemplate(RedisConnectionFactory redisConnectionFactory) {
		RedisTemplate<String, Object> template = new RedisTemplate<>();
		template.setConnectionFactory(redisConnectionFactory);
		template.setKeySerializer(new StringRedisSerializer());
		template.setValueSerializer(new RedisObjectSerializer());
		return template;
	}

	@Bean(name = "redisStringTemplate")
	@ConditionalOnMissingBean(name = "redisStringTemplate")
	public RedisTemplate<String, String> redisStringTemplate(RedisConnectionFactory redisConnectionFactory) {
		RedisTemplate<String, String> template = new RedisTemplate<>();
		template.setConnectionFactory(redisConnectionFactory);
		template.setKeySerializer(new StringRedisSerializer());
		template.setValueSerializer(new StringRedisSerializer());
		return template;
	}

	@Bean(name = "shiroRealm")
	@ConditionalOnMissingBean(name = "shiroRealm")
	@DependsOn("lifecycleBeanPostProcessor")
	public AuthorizingRealm shiroRealm() {
		Class<?> relmClass = shiroProperties.getRealm();
		return (AuthorizingRealm) BeanUtils.instantiate(relmClass);
	}

	@Bean(name = "shiroFilter")
	@ConditionalOnMissingBean
	public ShiroFilterFactoryBean shirFilter(WebSecurityManager shiroSecurityManager){
		ShiroFilterFactoryBean shiroFilterFactoryBean  = new ShiroFilterFactoryBean();
		shiroFilterFactoryBean.setSecurityManager(shiroSecurityManager);
		Map<String,String> filterChainDefinitionMap = new LinkedHashMap<>();
		if (null != shiroProperties.getFilterChainDefinitions()) {
			filterChainDefinitionMap.putAll(shiroProperties.getFilterChainDefinitions());
		}
		logger.info("过虑器配置: {}", filterChainDefinitionMap);
		shiroFilterFactoryBean.setLoginUrl(shiroProperties.getLoginUrl());
		shiroFilterFactoryBean.setUnauthorizedUrl(shiroProperties.getUnauthorizedUrl());
		shiroFilterFactoryBean.setFilterChainDefinitionMap(filterChainDefinitionMap);
		return shiroFilterFactoryBean;
	}

	@Bean(name="shiroSecurityManager")
	@ConditionalOnMissingBean(name = "shiroSecurityManager")
	public WebSecurityManager getWebSecurityManage(AuthorizingRealm shiroRealm, WebSessionManager shiroSessionManager){
		KingoldWebSecurityManager securityManager =  new KingoldWebSecurityManager();
		securityManager.setRealm(shiroRealm);
		securityManager.setCacheManager(ehCacheManager());
		securityManager.setSessionManager(shiroSessionManager);
		return securityManager;
	}

	@Bean(name="shiroSessionManager")
	@ConditionalOnMissingBean(name = "shiroSessionManager")
	public WebSessionManager getWebSessionManager() {
		KingoldWebSessionManager sessionManager = new KingoldWebSessionManager();
		sessionManager.setSessionDAO(redisSessionDAO());
		sessionManager.setCacheManager(ehCacheManager());
		sessionManager.setSessionValidationInterval(shiroProperties.getSessionValidationInterval());
		sessionManager.setGlobalSessionTimeout(shiroProperties.getSessionTimeout());
		sessionManager.setDeleteInvalidSessions(true);
		sessionManager.setSessionValidationSchedulerEnabled(shiroProperties.getSessionValidationEnabled().booleanValue());
		SimpleCookie cookie = new SimpleCookie(shiroProperties.getCookieName());
		cookie.setHttpOnly(true);
		String sessionMode = shiroProperties.getSessionMode();
		if (!Strings.isNullOrEmpty(sessionMode) && sessionMode.equalsIgnoreCase(ShiroSessionMode.MASTER)) {
			// 从模式不用指定域名
			String domain = shiroProperties.getCookieDomain();
			if (!Strings.isNullOrEmpty(domain)) {
				cookie.setDomain(domain);
			}
		}
		sessionManager.setSessionIdCookie(cookie);
		return sessionManager;
	}

	@Bean(name = "redisSessionDAO")
	@ConditionalOnMissingBean(name = "redisSessionDAO")
	public RedisSessionDAO redisSessionDAO() {
		return new RedisSessionDAO();
	}

	@Bean(name="ehCacheManager")
	public EhCacheManager ehCacheManager(){
		EhCacheManager cacheManager = new EhCacheManager();
		cacheManager.setCacheManagerConfigFile("classpath:ehcache-shiro.xml");
		return cacheManager;
	}

	@Bean(name="authorizationAttributeSourceAdvisor")
	public AuthorizationAttributeSourceAdvisor authorizationSourceAdvisor(WebSecurityManager shiroSecurityManager) {
		AuthorizationAttributeSourceAdvisor authorizationSourceAdvisor = new AuthorizationAttributeSourceAdvisor();
		authorizationSourceAdvisor.setSecurityManager(shiroSecurityManager);
		return authorizationSourceAdvisor;
	}

	@Bean(name = "defaultAdvisorAutoProxyCreator")
	@DependsOn("lifecycleBeanPostProcessor")
	public DefaultAdvisorAutoProxyCreator getDefaultAdvisorAutoProxyCreator() {
		DefaultAdvisorAutoProxyCreator advisorAutoProxyCreator = new DefaultAdvisorAutoProxyCreator();
		advisorAutoProxyCreator.setProxyTargetClass(false);
		return advisorAutoProxyCreator;
	}
}
