package cn.zjhf.kingold.shiro.security;

import cn.zjhf.kingold.shiro.autoconfigure.ShiroProperties;
import cn.zjhf.kingold.shiro.vo.UserVO;
import com.alibaba.fastjson.JSON;
import com.google.common.base.Strings;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.session.InvalidSessionException;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.SimplePrincipalCollection;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.subject.SubjectContext;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.apache.shiro.web.subject.support.DefaultWebSubjectContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

/**
 * 自定义SecurityManager实现
 *
 * Created by lutiehua on 2017/9/13.
 */
public class KingoldWebSecurityManager extends DefaultWebSecurityManager {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    @Autowired
    protected ShiroProperties shiroProperties;

    @Resource(name = "redisStringTemplate")
    protected RedisTemplate<String, String> redisStringTemplate;

    /**
     * 目前没有修改
     *
     * @param subjectContext
     * @return
     */
    @Override
    public Subject createSubject(SubjectContext subjectContext) {
        return super.createSubject(subjectContext);
    }

    /**
     * 目前没有修改
     *
     * @param context
     * @return
     */
    protected SubjectContext resolveSession(SubjectContext context) {
        return super.resolveSession(context);
    }

    /**
     * 目前没有修改
     *
     * @param context
     * @return
     * @throws InvalidSessionException
     */
    protected Session resolveContextSession(SubjectContext context) throws InvalidSessionException {
        return super.resolveContextSession(context);
    }

    /**
     * 解析用户信息
     *
     * @param context
     * @return
     */
    protected SubjectContext resolvePrincipals(SubjectContext context) {
        String sessionMode = shiroProperties.getSessionMode();
        if (Strings.isNullOrEmpty(sessionMode)) {
            throw new RuntimeException("sessionMode不能为空");
        }

        if (sessionMode.equalsIgnoreCase(ShiroSessionMode.MASTER)) {
            return super.resolvePrincipals(context);
        }

        if (!sessionMode.equalsIgnoreCase(ShiroSessionMode.SLAVE)) {
            throw new RuntimeException("sessionMode只能是master或者slave");
        }

        String sessionId = null;
        DefaultWebSubjectContext webSubjectContext = (DefaultWebSubjectContext)context;
        HttpServletRequest request = (HttpServletRequest)webSubjectContext.getServletRequest();
        Cookie[] cookies = request.getCookies();
        if (null != cookies) {
            for(Cookie cookie : cookies){
                if (cookie.getName().equalsIgnoreCase(shiroProperties.getCookieName())) {
                    sessionId = cookie.getValue();
                    break;
                }
            }
        }

        if (null == sessionId) {
            return super.resolvePrincipals(context);
        }

        String prefix = shiroProperties.getSessionKey();
        HashOperations<String, String, String> hashOperations = redisStringTemplate.opsForHash();
        String jsonString = hashOperations.get(prefix, sessionId);
        if (null == jsonString) {
            return super.resolvePrincipals(context);
        }

        UserVO user = JSON.parseObject(jsonString, UserVO.class);
        if (null == user) {
            return super.resolvePrincipals(context);
        }

        PrincipalCollection principals = new SimplePrincipalCollection();
        ((SimplePrincipalCollection)principals).add(user, "KingoldWebSecurityManager");

        SimpleAuthenticationInfo authenticationInfo = new SimpleAuthenticationInfo();
        authenticationInfo.setPrincipals(principals);
        authenticationInfo.setCredentials(user.getPassword());

        context.setAuthenticationInfo(authenticationInfo);
        context.setPrincipals(principals);

        return context;
    }
}
