package cn.zjhf.kingold.shiro.autoconfigure;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Configuration properties for Shiro.
 */
@ConfigurationProperties(prefix = "shiro")
public class ShiroProperties {

    /**
     * Cookie的名字
     */
    private String cookieName = "WEBID";

    /**
     * Cookie的域名
     */
    private String cookieDomain = ".zj-hf.cn";

    /**
     * 模式（默认slave模式，Session只读）
     */
    private String sessionMode = "slave";

    /**
     * 存储Session的Redis主键名称
     */
    private String sessionKey = "kingold-shiro-session:";

    /**
     * Session失效时间（默认30分钟）
     */
    private Integer sessionTimeout = 1800000;

    /**
     * 是否做Session失效检查（默认不做）
     */
    private Boolean sessionValidationEnabled = false;

    /**
     * Session失效检查时间间隔（默认1分钟）
     */
    private Integer sessionValidationInterval = 60000;

    /**
     * 自定义Realm
     */
    private Class<?> realm = null;

    /**
     * Session失效后自动登录的地址
     */
    private String loginUrl = "/api/security/login";

    /**
     * 未授权页面的显示地址
     */
    private String unauthorizedUrl = "/api/security/403";

    /**
     * 是否启用权限过滤
     */
    private Boolean permsEnabled = true;

    /**
     * 自定义过滤链（anon=匿名,authc=身份验证）
     *
     */
    private Map<String, String> filterChainDefinitions;

    public String getCookieName() {
        return cookieName;
    }

    public void setCookieName(String cookieName) {
        this.cookieName = cookieName;
    }

    public String getCookieDomain() {
        return cookieDomain;
    }

    public void setCookieDomain(String cookieDomain) {
        this.cookieDomain = cookieDomain;
    }

    public String getSessionMode() {
        return sessionMode;
    }

    public void setSessionMode(String sessionMode) {
        this.sessionMode = sessionMode;
    }

    public String getSessionKey() {
        return sessionKey;
    }

    public void setSessionKey(String sessionKey) {
        this.sessionKey = sessionKey;
    }

    public Integer getSessionTimeout() {
        return sessionTimeout;
    }

    public void setSessionTimeout(Integer sessionTimeout) {
        this.sessionTimeout = sessionTimeout;
    }

    public Integer getSessionValidationInterval() {
        return sessionValidationInterval;
    }

    public void setSessionValidationInterval(Integer sessionValidationInterval) {
        this.sessionValidationInterval = sessionValidationInterval;
    }

    public Class<?> getRealm() {
        return realm;
    }

    public void setRealm(Class<?> realm) {
        this.realm = realm;
    }

    public String getLoginUrl() {
        return loginUrl;
    }

    public void setLoginUrl(String loginUrl) {
        this.loginUrl = loginUrl;
    }

    public String getUnauthorizedUrl() {
        return unauthorizedUrl;
    }

    public void setUnauthorizedUrl(String unauthorizedUrl) {
        this.unauthorizedUrl = unauthorizedUrl;
    }

    public Map<String, String> getFilterChainDefinitions() {
        return filterChainDefinitions;
    }

    public void setFilterChainDefinitions(Map<String, String> filterChainDefinitions) {
        this.filterChainDefinitions = filterChainDefinitions;
    }

    public Boolean getPermsEnabled() {
        return permsEnabled;
    }

    public void setPermsEnabled(Boolean permsEnabled) {
        this.permsEnabled = permsEnabled;
    }

    public Boolean getSessionValidationEnabled() {
        return sessionValidationEnabled;
    }

    public void setSessionValidationEnabled(Boolean sessionValidationEnabled) {
        this.sessionValidationEnabled = sessionValidationEnabled;
    }
}
