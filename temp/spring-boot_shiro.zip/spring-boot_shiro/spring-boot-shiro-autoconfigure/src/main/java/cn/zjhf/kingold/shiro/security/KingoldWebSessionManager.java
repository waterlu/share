package cn.zjhf.kingold.shiro.security;

import cn.zjhf.kingold.shiro.autoconfigure.ShiroProperties;
import com.google.common.base.Strings;
import org.apache.shiro.session.ExpiredSessionException;
import org.apache.shiro.session.InvalidSessionException;
import org.apache.shiro.session.Session;
import org.apache.shiro.session.mgt.DefaultSessionKey;
import org.apache.shiro.session.mgt.SessionContext;
import org.apache.shiro.session.mgt.SessionKey;
import org.apache.shiro.web.servlet.ShiroHttpServletRequest;
import org.apache.shiro.web.session.mgt.DefaultWebSessionManager;
import org.apache.shiro.web.util.WebUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.Serializable;
import java.util.Collection;

/**
 * Created by lutiehua on 2017/9/13.
 */
public class KingoldWebSessionManager extends DefaultWebSessionManager {

    private static final Logger log = LoggerFactory.getLogger(KingoldWebSessionManager.class);

    @Autowired
    protected ShiroProperties shiroProperties;

    @Override
    protected void onStart(Session session, SessionContext context) {
        String sessionMode = shiroProperties.getSessionMode();
        if (Strings.isNullOrEmpty(sessionMode)) {
            throw new RuntimeException("sessionMode不能为空");
        }

        if (sessionMode.equalsIgnoreCase(ShiroSessionMode.MASTER)) {
            super.onStart(session, context);
            return;
        }

        if (!sessionMode.equalsIgnoreCase(ShiroSessionMode.SLAVE)) {
            throw new RuntimeException("sessionMode只能是master或者slave");
        }

        if(!WebUtils.isHttp(context)) {
            log.debug("SessionContext argument is not HTTP compatible or does not have an HTTP request/response pair. No session ID cookie will be set.");
        } else {
            HttpServletRequest request = WebUtils.getHttpRequest(context);
            HttpServletResponse response = WebUtils.getHttpResponse(context);
            if(this.isSessionIdCookieEnabled()) {
                Serializable sessionId = session.getId();
                log.info("sessionId={}", sessionId.toString());
            } else {
                log.debug("Session ID cookie is disabled.  No cookie has been set for new session with id {}", session.getId());
            }

            request.removeAttribute(ShiroHttpServletRequest.REFERENCED_SESSION_ID_SOURCE);
            request.setAttribute(ShiroHttpServletRequest.REFERENCED_SESSION_IS_NEW, Boolean.TRUE);
        }
    }

    @Override
    public void validateSessions() {
        super.validateSessions();
    }
}
