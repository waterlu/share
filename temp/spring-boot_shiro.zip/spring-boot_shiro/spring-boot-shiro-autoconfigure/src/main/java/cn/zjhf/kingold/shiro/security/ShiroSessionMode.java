package cn.zjhf.kingold.shiro.security;

/**
 * Created by lutiehua on 2017/9/16.
 */
public interface ShiroSessionMode {

    /**
     * 主模式，读写Session
     */
    String MASTER = "master";

    /**
     * 从模式，只读Session
     */
    String SLAVE = "slave";
}
