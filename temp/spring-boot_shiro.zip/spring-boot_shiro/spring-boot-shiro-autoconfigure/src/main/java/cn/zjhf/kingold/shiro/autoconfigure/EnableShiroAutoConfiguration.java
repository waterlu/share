package cn.zjhf.kingold.shiro.autoconfigure;

import java.lang.annotation.*;

/**
 * Annotation for Demo.
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
public @interface EnableShiroAutoConfiguration {
}
