package cn.zjhf.kingold.shiro.autoconfigure;

import org.apache.shiro.spring.LifecycleBeanPostProcessor;
import org.springframework.context.annotation.Bean;

/**
 * Created by lutiehua on 2017/9/18.
 */
public class ShiroLifecycleBeanConfiguration {

    @Bean(name = "lifecycleBeanPostProcessor")
    public LifecycleBeanPostProcessor lifecycleBeanPostProcessor() {
        return new LifecycleBeanPostProcessor();
    }

}
