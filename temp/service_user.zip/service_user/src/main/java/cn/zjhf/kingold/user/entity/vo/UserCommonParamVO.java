package cn.zjhf.kingold.user.entity.vo;

import cn.zjhf.kingold.common.param.ParamVO;

/**
 * Created by liuyao on 2017/11/14.
 */
public class UserCommonParamVO extends ParamVO {
    private String userUuid;

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }
}
