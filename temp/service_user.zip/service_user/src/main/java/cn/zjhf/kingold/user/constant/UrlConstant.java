package cn.zjhf.kingold.user.constant;

/**
 * Created by liuyao on 17/11/9.
 */
public interface UrlConstant {
    /**
     * 获取定期投资订单列表
     */
    String GET_TRADE_ORDER_LIST = "/tradeorder/list";

    String URL_PRODUCT_GET_FIXED_TERM_LIST = "/product/fixedIncome/list";

    String URL_TRADE_GET_REWARD_SUM_BY_INVITED_UUIDS = "/reward/list/invitedUuids";

    String URL_TRADE_GET_REWARD_LIST_ORDER_BY_SUM = "/reward/list/order/sum";



}
