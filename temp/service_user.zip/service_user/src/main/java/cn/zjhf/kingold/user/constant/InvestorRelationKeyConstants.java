package cn.zjhf.kingold.user.constant;

/**
 * Created by liuyao on 2017/5/26.
 */
public class InvestorRelationKeyConstants {
    public final static String RELATION_ID_LONG = "relationId";

    public final static String USER_UUID_STR = "userUuid";

    public final static String INVESTOR_TYPE = "investorType";

    public final static String INVITER_LEVEL_ONE_UUID_STR = "inviterLevelOneUuid";

    public final static String INVITER_LEVEL_TWO_UUID_STR = "inviterLevelTwoUuid";

    public final static String INVITER_LEVEL_THREE_UUID_STR = "inviterLevelThreeUuid";

    public final static String TOP_ORGANIZATION_UUID_STR = "topOrganizationUuid";

    public final static String TOP_ORGANIZATION_PATH_STR = "topOrganizationPath";

    public final static String TOP_UUID_STR = "topUuid";

    public final static String CREATE_TIME_DATE = "createTime";

    public final static String UPDATE_TIME_DATE = "updateTime";
}
