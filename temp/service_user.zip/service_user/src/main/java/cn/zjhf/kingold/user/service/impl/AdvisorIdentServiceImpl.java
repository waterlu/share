package cn.zjhf.kingold.user.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.user.constant.AdvisorAuthEnum;
import cn.zjhf.kingold.user.constant.UserParamMsg;
import cn.zjhf.kingold.user.persistence.dao.AdvisorIdentMapper;
import cn.zjhf.kingold.user.persistence.dao.AdvisorMapper;
import cn.zjhf.kingold.user.persistence.dao.BankInfoMapper;
import cn.zjhf.kingold.user.service.IAdvisorIdentService;
import cn.zjhf.kingold.user.service.IBankInfoService;
import cn.zjhf.kingold.user.utils.MapParamUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by wangxun on 2017/08/04.
 * Copyright by zjinv
 */
@Service
public class AdvisorIdentServiceImpl implements IAdvisorIdentService {
    private static final Logger LOGGER = LoggerFactory.getLogger(AdvisorIdentServiceImpl.class);
    @Autowired
    private AdvisorIdentMapper advisorIdentMapper;

    @Autowired
    private AdvisorMapper advisorMapper;

    @Override
    public Map get(Map params) throws BusinessException {

        Map ui = advisorIdentMapper.get(params);
        return ui;
    }

    @Override
    public int insert(Map params) throws BusinessException {

        return advisorIdentMapper.insert(params);

    }

    @Override
    public int update( Map params) throws BusinessException {
        return advisorIdentMapper.update(params);
    }

    @Override
    public Integer delete(Map params) throws BusinessException {
        int num = advisorIdentMapper.delete(params);
        return num;
    }

    @Override
    public List<Map> getList(Map userMap) throws BusinessException {

        List<Map> userList = advisorIdentMapper.getList(userMap);

        return userList;
    }

    @Override
    public int getCount(Map userMap) throws BusinessException {

        return advisorIdentMapper.getCount(userMap);

    }

    /**
     * 审核
     * 如果通过，同时设置理财师表名片为审核通过的名片
     * @param paramMap
     * @throws BusinessException
     */
    @Override
    @Transactional
    public void audit(Map<String, Object> paramMap) throws BusinessException {
        String userUuid = MapParamUtils.getStringInMap(paramMap,"userUuid");
        Map advisorIdentParams = new HashMap();
        advisorIdentParams.put("userUuid",userUuid);
        Map advisorIdentMap = advisorIdentMapper.get(advisorIdentParams);
        String advisorWorkCardUrl = MapParamUtils.getStringInMap(paramMap,"advisorWorkCardUrl");
        if(StringUtils.isBlank(userUuid)){
            throw new BusinessException(UserParamMsg.REQUEST_PARAM_ERROR_CODE, "error:param must contant 'userUuid'!", true);
        }
        //审核通过
        if(AdvisorAuthEnum.ADVISOR_AUTH_SUCCESS.getStatus() ==MapParamUtils.getIntInMap(paramMap,"aiStatus")){
            Map advisorParams = new HashMap();
            advisorParams.put("userUuid",userUuid);
            advisorParams.put("advisorWorkCardUrl",MapParamUtils.getStringInMap(advisorIdentMap,"advisorWorkCardUrl"));
            advisorParams.put("advisorAuthStatus", AdvisorAuthEnum.ADVISOR_AUTH_SUCCESS.getStatus());
            advisorMapper.update(advisorParams);

        }else  if(AdvisorAuthEnum.ADVISOR_AUTH_FAIL.getStatus() ==MapParamUtils.getIntInMap(paramMap,"aiStatus")){
            Map advisorParams = new HashMap();
            advisorParams.put("userUuid",userUuid);
            advisorParams.put("advisorWorkCardUrl"," ");
            advisorParams.put("advisorAuthStatus", AdvisorAuthEnum.ADVISOR_AUTH_FAIL.getStatus());
            advisorMapper.update(advisorParams);
        }else{
            throw new BusinessException(UserParamMsg.REQUEST_PARAM_ERROR_CODE ,UserParamMsg.REQUEST_PARAM_ERROR, true);
        }

        advisorIdentMapper.update(paramMap);
    }


}