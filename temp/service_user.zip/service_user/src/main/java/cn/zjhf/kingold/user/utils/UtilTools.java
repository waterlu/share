package cn.zjhf.kingold.user.utils;

import org.apache.commons.lang3.StringUtils;

/**
 * Created by DELL on 2017/6/20.
 */
public class UtilTools {

    /**
     * 手机号：186****5678。显示前3位和后4位，“*”代替中间其他位
     * @param param
     * @return
     */
    public static String encryptMobile(String param){
        if(StringUtils.isBlank(param)){
            return "";
        }else if(param.length() < 7){
            return param;
        }else{
            StringBuffer result  = new StringBuffer();
            result.append(param.substring(0,3));
            for(int i=0;i<param.length()-7;i++){
                result.append("*");
            }
            result.append(param.substring(param.length()-4,param.length()));
            return result.toString();
        }
    }

    /**
     * 身份证号：210281********2619。显示前6位和后4位，“*”代替中间其他位
     *
     * @param param
     * @return
     */
    public static String encryptIDCard(String param){
        int mixLength = 10 ;
        if(StringUtils.isBlank(param)){
            return "";
        }else if(param.length() < mixLength){
            return param;
        }else{
            StringBuffer result  = new StringBuffer();
            result.append(param.substring(0,6));
            for(int i=0;i<param.length()-mixLength;i++){
                result.append("*");
            }
            result.append(param.substring(param.length()-4,param.length()));
            return result.toString();
        }
    }

    /**
     * 银行卡号：6226********4451。显示前4位和后4位，。“*”代替中间其他位
     *
     * @param param
     * @return
     */
    public static String encryptBankIDCard(String param){
        int mixLength = 8 ;
        if(StringUtils.isBlank(param)){
            return "";
        }else if(param.length() < mixLength){
            return param;
        }else{
            StringBuffer result  = new StringBuffer();
            result.append(param.substring(0,4));
            for(int i=0;i<param.length()-mixLength;i++){
                result.append("*");
            }
            result.append(param.substring(param.length()-4,param.length()));
            return result.toString();
        }
    }

    public static boolean containsEmoji(String source) {
        int len = source.length();
        boolean isEmoji = false;
        for (int i = 0; i < len; i++) {
            char hs = source.charAt(i);
            if (0xd800 <= hs && hs <= 0xdbff) {
                if (source.length() > 1) {
                    char ls = source.charAt(i + 1);
                    int uc = ((hs - 0xd800) * 0x400) + (ls - 0xdc00) + 0x10000;
                    if (0x1d000 <= uc && uc <= 0x1f77f) {
                        return true;
                    }
                }
            } else {
                // non surrogate
                if (0x2100 <= hs && hs <= 0x27ff && hs != 0x263b) {
                    return true;
                } else if (0x2B05 <= hs && hs <= 0x2b07) {
                    return true;
                } else if (0x2934 <= hs && hs <= 0x2935) {
                    return true;
                } else if (0x3297 <= hs && hs <= 0x3299) {
                    return true;
                } else if (hs == 0xa9 || hs == 0xae || hs == 0x303d
                        || hs == 0x3030 || hs == 0x2b55 || hs == 0x2b1c
                        || hs == 0x2b1b || hs == 0x2b50 || hs == 0x231a) {
                    return true;
                }
                if (!isEmoji && source.length() > 1 && i < source.length() - 1) {
                    char ls = source.charAt(i + 1);
                    if (ls == 0x20e3) {
                        return true;
                    }
                }
            }
        }
        return isEmoji;
    }

    private static boolean isEmojiCharacter(char codePoint) {
        return (codePoint == 0x0) || (codePoint == 0x9) || (codePoint == 0xA)
                || (codePoint == 0xD)
                || ((codePoint >= 0x20) && (codePoint <= 0xD7FF))
                || ((codePoint >= 0xE000) && (codePoint <= 0xFFFD))
                || ((codePoint >= 0x10000) && (codePoint <= 0x10FFFF));
    }

    /**
     * 银行卡号：************4451。显示后4位，。“*”代替其他位
     *
     * @param param
     * @return
     */
    public static String encryptBankIDCard2(String param){
        int mixLength = 8 ;
        if(StringUtils.isBlank(param)){
            return "";
        }else if(param.length() < mixLength){
            return param;
        }else{
            StringBuffer result  = new StringBuffer();
//            result.append(param.substring(0,4));
            for(int i=0;i<param.length()-mixLength + 4;i++){
                result.append("*");
            }
            result.append(param.substring(param.length()-4,param.length()));
            return result.toString();
        }
    }
//    public static void main (String[] args){
//        System.out.println(UtilTools.encryptMobile("1234567890"));
//        System.out.println(UtilTools.encryptIDCard("1234567890123"));
//
//        System.out.println(UtilTools.encryptBankIDCard2("1234567890"));
//    }


}
