package cn.zjhf.kingold.user.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.user.entity.UserFeedback;

import java.util.Map;

/**
 * Created by liuyao on 17/8/23.
 */
public interface IUserFeedbackService {
    int create(UserFeedback userFeedback);

}
