package cn.zjhf.kingold.user.entity;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.user.constant.UserParamMsg;
import org.hibernate.validator.constraints.NotBlank;

/**
 * Created by liuyao on 2017/10/27.
 */
public class LoginParam extends ParamVO{

    @NotBlank(message = UserParamMsg.REQUEST_PARAM_ERROR)
    private String investorMobile;

    private String smsCode;

    private String loginDeviceId;

    private String loginDeviceOs;

    private String loginDeviceIp;

    private String loginChannelCode;

    private String loginVersionCode;

    private String loginDeviceType;

    private Integer loginMethod;

    private String campCode;

    private String inviterPhone;


    public String getInvestorMobile() {
        return investorMobile;
    }

    public void setInvestorMobile(String investorMobile) {
        this.investorMobile = investorMobile;
    }

    public String getSmsCode() {
        return smsCode;
    }

    public void setSmsCode(String smsCode) {
        this.smsCode = smsCode;
    }

    public String getLoginDeviceId() {
        return loginDeviceId;
    }

    public void setLoginDeviceId(String loginDeviceId) {
        this.loginDeviceId = loginDeviceId;
    }

    public String getLoginDeviceOs() {
        return loginDeviceOs;
    }

    public void setLoginDeviceOs(String loginDeviceOs) {
        this.loginDeviceOs = loginDeviceOs;
    }

    public String getLoginDeviceIp() {
        return loginDeviceIp;
    }

    public void setLoginDeviceIp(String loginDeviceIp) {
        this.loginDeviceIp = loginDeviceIp;
    }

    public String getLoginChannelCode() {
        return loginChannelCode;
    }

    public void setLoginChannelCode(String loginChannelCode) {
        this.loginChannelCode = loginChannelCode;
    }

    public String getLoginVersionCode() {
        return loginVersionCode;
    }

    public void setLoginVersionCode(String loginVersionCode) {
        this.loginVersionCode = loginVersionCode;
    }

    public String getLoginDeviceType() {
        return loginDeviceType;
    }

    public void setLoginDeviceType(String loginDeviceType) {
        this.loginDeviceType = loginDeviceType;
    }

    public Integer getLoginMethod() {
        return loginMethod;
    }

    public void setLoginMethod(Integer loginMethod) {
        this.loginMethod = loginMethod;
    }

    @Override
    public String toString() {
        return "LoginParam{" +
                "investorMobile='" + investorMobile + '\'' +
                ", smsCode='" + smsCode + '\'' +
                '}';
    }

    public String getCampCode() {
        return campCode;
    }

    public void setCampCode(String campCode) {
        this.campCode = campCode;
    }

    public String getInviterPhone() {
        return inviterPhone;
    }

    public void setInviterPhone(String inviterPhone) {
        this.inviterPhone = inviterPhone;
    }
}
