package cn.zjhf.kingold.user.constant;

/**
 * Created by liuyao on 2017/11/10.
 */
public enum RelationTypeEnum {
    SELF(10,"自己"),INVITER_LEVEL_ONE(11, "上级直接邀请人"), INVITER_LEVEL_TWO(12, "上上级邀请人"),
    INVITER_LEVEL_THREE(13, "上上上级邀请人");

    private int type;
    private String msg;

    RelationTypeEnum(int type, String msg) {
        this.type = type;
        this.msg = msg;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
