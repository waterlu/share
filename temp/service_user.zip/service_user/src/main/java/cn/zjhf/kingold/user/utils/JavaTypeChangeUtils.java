package cn.zjhf.kingold.user.utils;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by DELL on 2017/5/6.
 */
public class JavaTypeChangeUtils {
    public static String getString(Map map, String prop){
        if(map == null && prop == null){
            return null;
        }
        if(map.get(prop) == null ){
            return null;
        }
        String result = String.valueOf(map.get(prop));
        return result == null ? null:result;
    }
    public static Long getLong(Map map, String prop){
        if(map == null && prop == null){
            return null;
        }
        if(map.get(prop) == null ){
            return null;
        }
        Long result = Long.parseLong(String.valueOf(map.get(prop)));
        return result == null ? null:result;
    }

    public static void main(String[] args){
        System.out.println(JavaTypeChangeUtils.getString(new HashMap(),"aa"));
    }
}
