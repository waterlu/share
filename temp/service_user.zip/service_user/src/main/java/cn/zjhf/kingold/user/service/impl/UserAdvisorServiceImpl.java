package cn.zjhf.kingold.user.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.user.constant.*;
import cn.zjhf.kingold.user.persistence.dao.*;
import cn.zjhf.kingold.user.persistence.mq.producer.UserAuthProducer;
import cn.zjhf.kingold.user.persistence.mq.producer.UserBindCardProducer;
import cn.zjhf.kingold.user.persistence.mq.producer.UserRegisterProducer;
import cn.zjhf.kingold.user.service.IAdvisorTransactionService;
import cn.zjhf.kingold.user.service.IUserAdvisorService;
import cn.zjhf.kingold.user.task.LoginInfoUpdateTask;
import cn.zjhf.kingold.user.utils.EncryptUtils;
import cn.zjhf.kingold.user.utils.MapParamUtils;
import cn.zjhf.kingold.user.utils.UserPropertiesUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * Created by wangxun on 2016/11/04.
 * Copyright by zjinv
 */
@Service
public final class UserAdvisorServiceImpl implements IUserAdvisorService {

    @Autowired
    private UserMapper userMapper;
    @Autowired
    private AdvisorMapper advisorMapper;
    @Autowired
    private UserTokenMapper userTokenMapper;
    @Autowired
    private AdvisorRelationMapper advisorRelationMapper;
    @Autowired
    StringRedisTemplate stringRedisTemplate;
    @Autowired
    private IAdvisorTransactionService advisorTransactionService;
    @Autowired
    private LoginInfoUpdateTask loginInfoUpdateTask;
    @Autowired
    private UserCertificationMapper userCertificationMapper;
    @Autowired
    private IssuerMapper issuerMapper;
    @Autowired
    private UserAuthProducer userAuthProducer;
    @Autowired
    private UserBindCardProducer userBindCardProducer;
    @Autowired
    private UserRegisterProducer userRegisterProducer;

    @Value("${system.run.model}")
    public String runModel;
    @Value("${app.admin.verify.code}")
    public String adminVerifyCode;
    private final static Logger LOGGER = LoggerFactory.getLogger(UserAdvisorServiceImpl.class);


    private final static int ID_CARD_MIN_LENGTH  = 15;
    private final static int PAY_PWD_ERROR_MAX_TIME = 6;
    private final static int ONE_HOUR_SECOND = 60 * 60;
    private final static String REDIS_SMS_REGIST_CODE_KEY = "bussType_0";
    private final static String REDIS_SMS_RESET_LOGIN_PASSWORD_CODE_KEY = "bussType_1";
    private final static String REDIS_SMS_RESET_PAY_PASSWORD_CODE_KEY = "bussType_2";

    /**
     * 1. 判断手机号是否存在
     * 2. 判断邀请人手机是否存在
     * 3. 写入注册信息
     *
     * 运营后台创建用户
     *
     * @param mapParams 必填：advisorMobile，advisorUuid ，
                            选填：advisorRealName，advisorInviteCode
     * @return
     * @throws BusinessException
     */
    @Override
    public Map create(Map<String, Object> mapParams) throws BusinessException {


        mapParams.put("userLoginName", mapParams.get("advisorMobile"));

        //判断手机号是否存在
        Map regParam = new HashMap();
        regParam.put("advisorMobile", mapParams.get("advisorMobile"));
        Map advisorMap = advisorMapper.get(regParam);
        Map regUserParam = new HashMap();
        regUserParam.put("userLoginName", mapParams.get("advisorMobile"));
        Map userMap = userMapper.get(regUserParam);
        boolean isUserExist =( userMap != null);
        boolean isAdvisorExist =( advisorMap != null);
        if (isUserExist && isAdvisorExist ) {//注册过user
            throw new BusinessException(UserParamMsg.REGISTER_PHONE_IS_EXIST_CODE, UserParamMsg.REGISTER_PHONE_IS_EXIST, true);
        }

        String userUuid = UUID.randomUUID().toString().replace("-", "");
        if(isUserExist) {
            userUuid =  MapParamUtils.getStringInMap(userMap,"userUuid");
        }
        mapParams.put("userUuid", userUuid);

        //判断邀请码是否存在，设置邀请人uuid和mobile
        if (StringUtils.isBlank((String)mapParams.get("advisorInviteCode"))) {
            mapParams.put("advisorInviteCode",EncryptUtils.randomCode());
        }else {
            Map inviteParam = new HashMap();
            inviteParam.put("advisorInviteCode", mapParams.get("advisorInviteCode"));
            Map inviteMap = advisorMapper.get(inviteParam);
            if (inviteMap == null) {
                throw new BusinessException(UserParamMsg.INVITER_CODE_NOT_EXIST_CODE, UserParamMsg.INVITER_CODE_NOT_EXIST, true);
            }
            mapParams.put("inviterUuid", inviteMap.get("advisorUuid"));
            mapParams.put("inviterMobile", inviteMap.get("advisorMobile"));

            //获取邀请人 类型（专职理财师、兼职理财师）
            int inviterType = MapParamUtils.getIntInMap(inviteMap, "advisorType");
            String inviterUuid = (String) inviteMap.get(InvestorKeyConstants.USER_UUID_STR);
            mapParams.put(InvestorKeyConstants.INVITER_UUID, inviterUuid);
            mapParams.put(InvestorRelationKeyConstants.INVITER_LEVEL_ONE_UUID_STR, inviterUuid);

            if (inviterType == InvestorType.PROFESSION_INVESTOR) {
                mapParams.put(InvestorRelationKeyConstants.TOP_UUID_STR, inviterUuid);
                mapParams.put(InvestorRelationKeyConstants.TOP_ORGANIZATION_PATH_STR, inviteMap.get("dataOrgPath"));
                mapParams.put(InvestorRelationKeyConstants.TOP_ORGANIZATION_UUID_STR, inviteMap.get("dataUuid"));
            } else {
                initAdvisorRelation(mapParams, inviterUuid);
            }
        }

        // 写入注册信息
        String loginName = (String)mapParams.get("advisorRealName");

        mapParams.put("advisorRealName", StringUtils.isEmpty(loginName) ?
                mapParams.get("advisorMobile") : loginName);

        //密码加盐
        String userPassword = (String) mapParams.get(UserKeyConstants.USER_LOGIN_PASSWORD_STR);
        userPassword = EncryptUtils.encryptSalt(userPassword);
        mapParams.put(UserKeyConstants.USER_LOGIN_PASSWORD_STR, userPassword);
        advisorTransactionService.insertUserTransaction(mapParams,isUserExist);//插入理财师和用户表信息
        return getWithFilter(mapParams);
    }



    /**
     * 1. 判断手机号是否存在
     * 2. 判断邀请人手机是否存在
     * 3. 判断验证码是否正确
     * 4. 写入注册信息
     *
     * @param mapParams 必填：advisorMobile，advisorUuid ，advisorInviteCode
                            选填：advisorRealName
     * @return
     * @throws BusinessException
     */
    @Override
    public Map regist(Map<String, Object> mapParams) throws BusinessException {


        mapParams.put("userLoginName", mapParams.get("advisorMobile"));

        //判断手机号是否存在
        Map regParam = new HashMap();
        regParam.put("advisorMobile", mapParams.get("advisorMobile"));
        Map advisorMap = advisorMapper.get(regParam);
        Map regUserParam = new HashMap();
        regUserParam.put("userLoginName", mapParams.get("advisorMobile"));
        Map userMap = userMapper.get(regUserParam);
        boolean isUserExist =( userMap != null);
        boolean isAdvisorExist =( advisorMap != null);
        if (isUserExist && isAdvisorExist ) {//注册过user
            throw new BusinessException(UserParamMsg.REGISTER_PHONE_IS_EXIST_CODE, UserParamMsg.REGISTER_PHONE_IS_EXIST, true);
        }
        String userUuid = UUID.randomUUID().toString().replace("-", "");
        if(isUserExist) {
            userUuid =  MapParamUtils.getStringInMap(userMap,"userUuid");
        }
        mapParams.put("userUuid", userUuid);

        //判断验证码是否正确
        if (!isSmsVerify((String) mapParams.get(InvestorKeyConstants.INVESTOR_MOBILE_STR), (String) mapParams.get("callSystemID"),
                (String) mapParams.get("verifyCode"), REDIS_SMS_REGIST_CODE_KEY)) {
            throw new BusinessException(UserParamMsg.VERIFY_CODE_ERROR_CODE, UserParamMsg.VERIFY_CODE_ERROR, true);
        }
        //判断邀请码是否存在，设置邀请人uuid和mobile
        if (StringUtils.isBlank((String)mapParams.get("advisorInviteCode"))) {
            throw new BusinessException(UserParamMsg.INVITER_CODE_NOT_EXIST_CODE, UserParamMsg.INVITER_CODE_NOT_EXIST, true);
        }else {
            Map inviteParam = new HashMap();
            inviteParam.put("advisorInviteCode", mapParams.get("advisorInviteCode"));
            Map inviteMap = advisorMapper.get(inviteParam);
            if (inviteMap == null) {
                throw new BusinessException(UserParamMsg.INVITER_CODE_NOT_EXIST_CODE, UserParamMsg.INVITER_CODE_NOT_EXIST, true);
            }
            mapParams.put("inviterUuid", inviteMap.get("advisorUuid"));
            mapParams.put("inviterMobile", inviteMap.get("advisorMobile"));

            //获取邀请人 类型（专职理财师、兼职理财师）
            int inviterType = MapParamUtils.getIntInMap(inviteMap,"advisorType");
            String inviterUuid = (String)inviteMap.get(InvestorKeyConstants.USER_UUID_STR);
            mapParams.put(InvestorKeyConstants.INVITER_UUID, inviterUuid);
            mapParams.put(InvestorRelationKeyConstants.INVITER_LEVEL_ONE_UUID_STR, inviterUuid);

            if (inviterType == InvestorType.PROFESSION_INVESTOR) {
                mapParams.put(InvestorRelationKeyConstants.TOP_UUID_STR, inviterUuid);
                mapParams.put(InvestorRelationKeyConstants.TOP_ORGANIZATION_PATH_STR, inviteMap.get("dataOrgPath"));
                mapParams.put(InvestorRelationKeyConstants.TOP_ORGANIZATION_UUID_STR, inviteMap.get("dataUuid"));
            } else {
                initAdvisorRelation(mapParams, inviterUuid);
            }
        }

        // 写入注册信息
        String loginName = (String)mapParams.get("advisorRealName");

        mapParams.put("advisorRealName", StringUtils.isEmpty(loginName) ?
                mapParams.get("advisorMobile") : loginName);

        //密码加盐
        String userPassword = (String) mapParams.get(UserKeyConstants.USER_LOGIN_PASSWORD_STR);
        userPassword = EncryptUtils.encryptSalt(userPassword);
        mapParams.put(UserKeyConstants.USER_LOGIN_PASSWORD_STR, userPassword);
        //生成邀请码
        mapParams.put("advisorInviteCode",EncryptUtils.randomCode());

        advisorTransactionService.insertUserTransaction(mapParams,isUserExist);//插入理财师和用户表信息

        return getWithFilter(mapParams);
    }


    @Override
    public Map login(Map mapParams) throws BusinessException {
        Map userMap = getUserAndAdvisorAndCheck(mapParams, false);
        int userType = (Integer) userMap.get(UserKeyConstants.USER_TYPE_BYTE);
        mapParams.put(UserKeyConstants.USER_UUID_STR, userMap.get(UserKeyConstants.USER_UUID_STR));
        Map advisor = advisorMapper.get(mapParams);

        userMap.putAll(advisor);

        //判断密码是否一致
        String paramUserPassword = EncryptUtils.encryptSalt((String) mapParams.get(UserKeyConstants.USER_LOGIN_PASSWORD_STR));
        if (!userMap.get(UserKeyConstants.USER_LOGIN_PASSWORD_STR).equals(paramUserPassword)) {
            throw new BusinessException(UserParamMsg.LONGIN_PW_NOT_MATCH_CODE, UserParamMsg.LONGIN_PW_NOT_MATCH, true);
        }
        mapParams.put(UserKeyConstants.USER_UUID_STR, userMap.get(UserKeyConstants.USER_UUID_STR));
        //异步更新用户设备等信息。
        loginInfoUpdateTask.asyncUpdateLoginInfo(mapParams);
        userMap.putAll(mapParams);
        Map resultMap = UserPropertiesUtils.buildUserData(userMap);
        return resultMap;
    }

    @Override
    public Map getWithFilter(Map<String, Object> params) throws BusinessException {
        Map<String, Object> ui = getUserAndAdvisor(params, false);
        Map resultMap = UserPropertiesUtils.buildUserData(ui);
        return resultMap;
    }

    @Override
    public Map getWithFreezing(Map<String, Object> params) throws BusinessException {
        Map<String, Object> ui = getUserAndAdvisor(params, true);
        Map resultMap = UserPropertiesUtils.buildUserData(ui);
        return resultMap;
    }

    @Override
    public List<Map> getListWithFilter(Map<String, Object> params) throws BusinessException {
        Integer pageNo = params.get("pageNo") == null ? 1 : Integer.valueOf(params.get("pageNo").toString());
        Integer pageSize = params.get("pageSize") == null ? 20 : Integer.valueOf(params.get("pageSize").toString());
        params.put("offset", (pageNo-1) * pageSize);
        params.put("limit", pageSize);
        List<Map> ui = advisorMapper.getList(params);
        List<Map> resultList = new ArrayList<>();
        for (Map objectMap : ui) {
            Map resultMap = UserPropertiesUtils.buildUserData(objectMap);
            resultList.add(resultMap);
        }
        return resultList;
    }

    @Override
    public int getCountWithFilter(Map<String, Object> params) throws BusinessException {
        return advisorMapper.getCount(params);
    }

    @Override
    public Map getUserByUserId(String userId) throws BusinessException {
        Map<String, Object> params = new HashMap<>();
        params.put(UserKeyConstants.USER_ID_LONG,userId);
        Map<String, Object> user = getUserAndAdvisor(params, true);
        Map resultMap = UserPropertiesUtils.buildUserData(user);
        return resultMap;
    }


    @Override
    public int updateUserVerifyStatus(Map<String, Object> params) throws BusinessException {
        Map<String, Object> ui = getUserAndAdvisor(params, false);
        Integer verifyStatus = ui.get(UserKeyConstants.USER_VERIFY_STATUS_INT) == null ? 0 : Integer.valueOf(ui.get(UserKeyConstants.USER_VERIFY_STATUS_INT).toString());
        Integer updateStatus = params.get(UserKeyConstants.USER_VERIFY_STATUS_INT) == null ? 0 : Integer.valueOf(params.get(UserKeyConstants.USER_VERIFY_STATUS_INT).toString());
        if (updateStatus < verifyStatus) {
            return 1;
        }
        int count = userMapper.update(params);
//        UserMessage userMessage = new UserMessage();
//        userMessage.setInvestorMobile(ui.get(UserKeyConstants.USER_LOGIN_NAME_STR).toString());
//        userMessage.setUserUuid(ui.get(UserKeyConstants.USER_UUID_STR).toString());
//        if (updateStatus == UserVerifyStatus.USER_AUTH_SUCCESS.getStatus()) {
//            userAuthProducer.send(userMessage);
//        } else if (updateStatus == UserVerifyStatus.USER_BIND_CARD_SUCCESS.getStatus()) {
//            userBindCardProducer.send(userMessage);
//        }
        return count;
    }

    @Override
    public int update( Map params) throws BusinessException {
        if( StringUtils.isBlank((String)params.get(UserKeyConstants.USER_UUID_STR))) {
            Map user = getUserAndAdvisor(params, false);
            params.put(UserKeyConstants.USER_UUID_STR, user.get(UserKeyConstants.USER_UUID_STR));
        }
        List<Map> userTokenList = userTokenMapper.getList(params);
        userTokenList.forEach(userToken -> refreshTokenInfo((String) userToken.get("token"), params));
        return advisorTransactionService.updateUserTransaction(params);
    }




    /**
     * 重置用户密码
     *
     * @param
     * @return
     * @throws BusinessException
     */
    @Override
    public void resetUserPassword(Map<String, Object> mapParams) throws BusinessException {
        String userPhone = (String) mapParams.get("userLoginName");
        Map<String, Object> userMap = isPhoneExist(userPhone);
        if (userMap == null) {
            throw new BusinessException(UserParamMsg.REGISTER_PHONE_NOT_EXIST_CODE, UserParamMsg.REGISTER_PHONE_NOT_EXIST, true);
        }
        if (!isSmsVerify(userPhone, (String) mapParams.get("callSystemID"),
                (String) mapParams.get("verifyCode"), REDIS_SMS_RESET_LOGIN_PASSWORD_CODE_KEY)) {
            throw new BusinessException(UserParamMsg.VERIFY_CODE_ERROR_CODE, UserParamMsg.VERIFY_CODE_ERROR, true);
        }
        //4. 重置密码
        Map resetParam = new HashMap();
        resetParam.put(UserKeyConstants.USER_UUID_STR, userMap.get(UserKeyConstants.USER_UUID_STR));
        String userPassword = (String) mapParams.get(UserKeyConstants.USER_LOGIN_PASSWORD_STR);
        userPassword = EncryptUtils.encryptSalt(userPassword);
        resetParam.put(UserKeyConstants.USER_LOGIN_PASSWORD_STR, userPassword);
        int result = userMapper.updatePassword(resetParam);
        if (result == 0) {
            throw new BusinessException(UserParamMsg.INNER_ERROR_CODE, UserParamMsg.INNER_ERROR, true);
        }
    }

    @Override
    public void certName(Map<String, Object> paramMap) throws BusinessException {
        advisorMapper.update(paramMap);
    }

    @Override
    public void bindBankCard(Map<String, Object> paramMap) throws BusinessException {
        Map bindBankParams = new HashMap();

        bindBankParams.put("userUuid",MapParamUtils.getStringInMap(paramMap,"userUuid"));
        bindBankParams.put("bankCardNo",MapParamUtils.getStringInMap(paramMap,"bankCardNo"));
        bindBankParams.put("bankName",MapParamUtils.getStringInMap(paramMap,"bankName"));
        bindBankParams.put("bankAddress",MapParamUtils.getStringInMap(paramMap,"bankAddress"));
        bindBankParams.put("bankSubbranch",MapParamUtils.getStringInMap(paramMap,"bankSubbranch"));
        advisorMapper.update(bindBankParams);
    }



    @Override
    public List<Map<String, Object>> getCertification(String userUuid, Integer userCertificationType) {
        return userCertificationMapper.getByUserUuid(userUuid, userCertificationType);
    }

    @Override
    public int insertCertification(Map<String, Object> mapParams) throws BusinessException {
        int count = userCertificationMapper.insert(mapParams);
        return count;
    }

    /**
    * 初始化插入 advisorRelation 表中数据内容
    */
    private void initAdvisorRelation(Map<String, Object> params, String inviterUuid) {
        Map advisorRelationParams = new HashMap();
        advisorRelationParams.put("userUuid",inviterUuid);
        Map<String, Object> inviterRelation = advisorRelationMapper.get(advisorRelationParams);
        if (inviterRelation != null) {
            PutStringNotNull(params, InvestorRelationKeyConstants.INVITER_LEVEL_TWO_UUID_STR,
                    inviterRelation.get(InvestorRelationKeyConstants.INVITER_LEVEL_ONE_UUID_STR));
            PutStringNotNull(params, InvestorRelationKeyConstants.INVITER_LEVEL_THREE_UUID_STR,
                    inviterRelation.get(InvestorRelationKeyConstants.INVITER_LEVEL_TWO_UUID_STR));
            PutStringNotNull(params, InvestorRelationKeyConstants.TOP_UUID_STR,
                    inviterRelation.get(InvestorRelationKeyConstants.TOP_UUID_STR));
            PutStringNotNull(params, InvestorRelationKeyConstants.TOP_ORGANIZATION_PATH_STR,
                    inviterRelation.get(InvestorRelationKeyConstants.TOP_ORGANIZATION_PATH_STR));
            PutStringNotNull(params, InvestorRelationKeyConstants.TOP_ORGANIZATION_UUID_STR,
                    inviterRelation.get(InvestorRelationKeyConstants.TOP_ORGANIZATION_UUID_STR));
        }
    }

    /**
     * 获取用户和理财师表信息
     * @param params  选填：userUuid，userId，userLoginName，investorMobile
     * @param withFreezing
     * @return
     * @throws BusinessException
     */
    public Map getUserAndAdvisor(Map<String, Object> params, boolean withFreezing) throws BusinessException {
        Map userMap = userMapper.get(params);
        if (userMap == null || userMap.isEmpty()) {
            return new HashMap();
        }
        if ("1".equals(userMap.get(UserKeyConstants.USER_STATUS_INT).toString()) && !withFreezing) {
            throw new BusinessException(UserParamMsg.USER_IS_FREEZING_CODE, UserParamMsg.USER_IS_FREEZING, true);
        }

        params.put(UserKeyConstants.USER_UUID_STR, userMap.get(UserKeyConstants.USER_UUID_STR));

        Map advisor = advisorMapper.get(params);
        if(null != advisor) {
            userMap.putAll(advisor);
        }

        return userMap;
    }



    /**
     * 获取用户信息，如果不存在，则抛出异常。
     * @param params  选填：userUuid，userId，userLoginName，investorMobile
     * @param withFreezing
     * @return
     * @throws BusinessException
     */
    @Override
    public Map getUserAndAdvisorAndCheck(Map<String, Object> params, boolean withFreezing) throws BusinessException {
        Map userMap = userMapper.get(params);
        if (userMap == null || userMap.isEmpty()) {
            throw new BusinessException(UserParamMsg.NOT_FIND_USER_CODE, UserParamMsg.NOT_FIND_USER, true);
        }
        if ("1".equals(userMap.get(UserKeyConstants.USER_STATUS_INT).toString()) && !withFreezing) {
            throw new BusinessException(UserParamMsg.USER_IS_FREEZING_CODE, UserParamMsg.USER_IS_FREEZING, true);
        }

        params.put(UserKeyConstants.USER_UUID_STR, userMap.get(UserKeyConstants.USER_UUID_STR));

        Map advisor = advisorMapper.get(params);
        if(null != advisor) {
            userMap.putAll(advisor);
        }else {
            throw new BusinessException(UserParamMsg.NOT_FIND_USER_CODE, UserParamMsg.NOT_FIND_USER, true);
        }

        return userMap;
    }

    public void refreshTokenInfo(String token, Map mapParams) {
        HashOperations<String, String, String> hash = stringRedisTemplate.opsForHash();
        for (Object hashKey : mapParams.keySet()) {
            if (isCache2Token((String) hashKey)) {
                Object value =  mapParams.get(hashKey);
                if (value != null) {
                    hash.put(token, (String) hashKey, (String) mapParams.get(hashKey));
                }
            }
        }
    }

    private Map<String, Object> isPhoneExist(String userPhone) throws BusinessException {
        Map checkParam = new HashMap();
        checkParam.put(UserKeyConstants.USER_LOGIN_NAME_STR, userPhone);
        Map userMap = getUserAndAdvisor(checkParam, false);
        return userMap;
    }

    private boolean isSmsVerify(String userPhone, String callSystemId, String verifyCode, String type) {
        String smsVerifyCode = (String) stringRedisTemplate.opsForValue().get(userPhone + callSystemId + type);
        if (verifyCode == null || !verifyCode.equals(smsVerifyCode)) {
            LOGGER.info("isSmsVerify not equals. userPhone={}, verifyCodeParam={}, type={}, verifyCode={}",
                    userPhone, verifyCode,type, smsVerifyCode);
            if ("test".equals(runModel) && verifyCode.equals(adminVerifyCode)) {
                return true;
            } else {
                return false;
            }
        }
        return true;
    }

    private void PutStringNotNull( Map<String, Object> params, String key, Object o) {
        if (o == null || StringUtils.isEmpty(o.toString())) {
            return ;
        }
        String value = o.toString();
        params.put(key, value);
    }

    static Set<String> tokenProps = new HashSet(Arrays.asList(new String[]{"userId", "userUuid", "userType", "userStatus", "userPhone", "userGender", "userAvatar", "isInner", "isFullTime", "inviterUuid", "inviterPhone", "userPath", "userName", "userIdCardNumber", "riskAssessmentLevel", "userRegisterTime", "userRegisterChannelCode", "userRegisterChannelName", "userRegisterVersionCode", "userRegisterVersionName", "userRegisterDeviceId", "userRegisterDeviceType", "userRegisterDeviceName", "userRegisterDeviceOs", "userRegisterDeviceIp"
            , "userLoginTime", "userLoginChannelCode", "userLoginChannelName", "userLoginVersionCode", "userLoginVersion_name", "userLoginDeviceCode", "userOginDeviceType", "userLoginDeviceName", "userLoginDeviceOs", "userLoginDeviceIp", "deleteFlag", "createTime", "createBy", "updateTime", "updateBy", "signature", "isQualiInv", "userVerifyStatus", "parentInviterUuid", "parentInviterPhone"}));

    public boolean isCache2Token(String key) {

        return tokenProps.contains(key);
    }

}