package cn.zjhf.kingold.user.service;


import cn.zjhf.kingold.common.exception.BusinessException;

import java.util.List;
import java.util.Map;


/**
 * Created by wangxun on 2016/11/04.
 * Copyright by zjinv
 */
public interface IUserAdvisorService {

    Map login(Map<String, Object> mapParams) throws BusinessException;

    Map regist(Map<String, Object> mapParams) throws BusinessException;

    Map create(Map<String, Object> mapParams) throws BusinessException;

    Map getUserAndAdvisor(Map<String, Object> params, boolean withFreezing) throws BusinessException;

    Map getUserAndAdvisorAndCheck(Map<String, Object> params, boolean withFreezing) throws BusinessException;


    List<Map<String, Object>> getCertification(String userUuid, Integer userCertificationType);

    int insertCertification(Map<String, Object> mapParams) throws BusinessException;
    /**
     * 获取用户信息，过滤禁用用户
     *
     * @return 用户
     * @throws BusinessException 业务异常
     */
    Map getWithFilter(Map<String, Object> params) throws BusinessException;

    Map getWithFreezing(Map<String, Object> params) throws BusinessException;

    List<Map> getListWithFilter(Map<String, Object> params) throws BusinessException;

    int getCountWithFilter(Map<String, Object> params) throws BusinessException;

    Map getUserByUserId(String userId) throws BusinessException;

//    int insert(Map<String, Object> userInfo) throws BusinessException;

    int update(Map<String, Object> userInfo) throws BusinessException;

    int updateUserVerifyStatus(Map<String, Object> params) throws BusinessException;

    void resetUserPassword(Map<String, Object> userMap) throws BusinessException;


    void certName(Map<String, Object> paramMap) throws BusinessException;

    void bindBankCard(Map<String, Object> paramMap) throws BusinessException;


}