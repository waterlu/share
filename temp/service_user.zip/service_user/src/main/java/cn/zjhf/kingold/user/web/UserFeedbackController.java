package cn.zjhf.kingold.user.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.user.constant.InvestorKeyConstants;
import cn.zjhf.kingold.user.constant.UserParamMsg;
import cn.zjhf.kingold.user.entity.UserFeedback;
import cn.zjhf.kingold.user.service.IUserFeedbackService;
import cn.zjhf.kingold.user.service.IUserService;
import cn.zjhf.kingold.user.utils.RequestMapperConvert;
import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RestController
@RequestMapping(value = "/user/feedback")
public class UserFeedbackController {

    private final static Logger LOGGER = LoggerFactory.getLogger(UserFeedbackController.class);

    @Autowired
    private IUserFeedbackService userFeedbackService;

    /**
     * 插入认证信息
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    public ResponseResult createFeedBack(@RequestBody UserFeedback userFeedback) throws BusinessException {
        int result = userFeedbackService.create(userFeedback);
        return new ResponseResult("" ,ResponseCode.REQUEST_SUCCESS, "成功", result);
    }

}
