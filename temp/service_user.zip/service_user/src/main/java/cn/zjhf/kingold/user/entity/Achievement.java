package cn.zjhf.kingold.user.entity;

import java.math.BigDecimal;
import java.util.Date;

public class Achievement {
    private Long id;

    private String userUuid;

    private String orderUserUuid;

    private Integer relation;

    private String productType;

    private String orderBillCode;

    private BigDecimal orderAmount;

    private Date orderCreateTime;

    private BigDecimal achievementAmount;

    private Integer status;

    private Byte deleteFlag;

    private Date createTime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid == null ? null : userUuid.trim();
    }

    public String getOrderUserUuid() {
        return orderUserUuid;
    }

    public void setOrderUserUuid(String orderUserUuid) {
        this.orderUserUuid = orderUserUuid == null ? null : orderUserUuid.trim();
    }

    public Integer getRelation() {
        return relation;
    }

    public void setRelation(Integer relation) {
        this.relation = relation;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType == null ? null : productType.trim();
    }

    public BigDecimal getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(BigDecimal orderAmount) {
        this.orderAmount = orderAmount;
    }

    public Date getOrderCreateTime() {
        return orderCreateTime;
    }

    public void setOrderCreateTime(Date orderCreateTime) {
        this.orderCreateTime = orderCreateTime;
    }

    public BigDecimal getAchievementAmount() {
        return achievementAmount;
    }

    public void setAchievementAmount(BigDecimal achievementAmount) {
        this.achievementAmount = achievementAmount;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getOrderBillCode() {
        return orderBillCode;
    }

    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    @Override
    public String toString() {
        return "Achievement{" +
                "id=" + id +
                ", userUuid='" + userUuid + '\'' +
                ", orderUserUuid='" + orderUserUuid + '\'' +
                ", relation=" + relation +
                ", productType='" + productType + '\'' +
                ", orderAmount=" + orderAmount +
                ", orderCreateTime=" + orderCreateTime +
                ", achievementAmount=" + achievementAmount +
                ", status=" + status +
                '}';
    }
}