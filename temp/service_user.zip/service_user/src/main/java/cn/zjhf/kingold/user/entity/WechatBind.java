package cn.zjhf.kingold.user.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class WechatBind implements Serializable {
    /**
     * 自增主键
     */
    private Long wechatBindId;

    /**
     * 用户uuid
     */
    private String userUuid;

    /**
     * 绑定的微信openid
     */
    private String openId;

    /**
     *平台（1，金疙瘩微信平台   2，星耀微信平台)
     */
    private Integer platform;

    private Byte deleteFlag;

    private Date createTime;

    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public Long getWechatBindId() {
        return wechatBindId;
    }

    public void setWechatBindId(Long wechatBindId) {
        this.wechatBindId = wechatBindId;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public Integer getPlatform() {
        return platform;
    }

    public void setPlatform(Integer platform) {
        this.platform = platform;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}