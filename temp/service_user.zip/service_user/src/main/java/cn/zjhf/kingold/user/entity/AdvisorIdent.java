package cn.zjhf.kingold.user.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class AdvisorIdent implements Serializable {
    /**
     * 自增ID
     */
    private Long aiId;

    /**
     * 用户UUID
     */
    private String userUuid;

    /**
     * 用户真实姓名
     */
    private String advisorRealName;

    /**
     * 用户身份证号码
     */
    private String advisorIdCardNo;

    /**
     * 名片url
     */
    private String advisorWorkCardUrl;

    /**
     * 认证状态（ 0认证发起 ， 1认证通过 ，2 认证失败）
     */
    private Byte aiStatus;

    /**
     * 删除标识
     */
    private Byte deleteFlag;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public Long getAiId() {
        return aiId;
    }

    public void setAiId(Long aiId) {
        this.aiId = aiId;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getAdvisorRealName() {
        return advisorRealName;
    }

    public void setAdvisorRealName(String advisorRealName) {
        this.advisorRealName = advisorRealName;
    }

    public String getAdvisorIdCardNo() {
        return advisorIdCardNo;
    }

    public void setAdvisorIdCardNo(String advisorIdCardNo) {
        this.advisorIdCardNo = advisorIdCardNo;
    }

    public String getAdvisorWorkCardUrl() {
        return advisorWorkCardUrl;
    }

    public void setAdvisorWorkCardUrl(String advisorWorkCardUrl) {
        this.advisorWorkCardUrl = advisorWorkCardUrl;
    }

    public Byte getAiStatus() {
        return aiStatus;
    }

    public void setAiStatus(Byte aiStatus) {
        this.aiStatus = aiStatus;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}