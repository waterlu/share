package cn.zjhf.kingold.user.persistence.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface AdvisorIdentMapper {
    Map get(Map params);

    int insert(Map record);

    int update(Map experInfo);

    int delete(Map params);

    Integer getCount(Map paramMap);

    List<Map> getList(Map paramMap);
}