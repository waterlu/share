package cn.zjhf.kingold.user.service;


import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.user.dto.UpdateTradeStatusDTO;
import cn.zjhf.kingold.user.entity.LoginParam;
import cn.zjhf.kingold.user.entity.LoginRegiestParam;

import java.util.List;
import java.util.Map;


/**
 * Created by wangxun on 2016/11/04.
 * Copyright by zjinv
 */
public interface IUserService {

    Map getUser(Map<String, Object> params, boolean withFreezing) throws BusinessException;

    List<Map<String, Object>> getCertification(String userUuid, Integer userCertificationType);

    int insertCertification(Map<String, Object> mapParams) throws BusinessException;
    /**
     * 获取用户信息，过滤禁用用户
     *
     * @return 用户
     * @throws BusinessException 业务异常
     */
    Map getInvestorWithFilter(Map<String, Object> params) throws BusinessException;

    Map getUserByPhone(Map<String, Object> params) throws BusinessException;

    Map getInvestorWithFreezing(Map<String, Object> params) throws BusinessException;

    public Map getIssuerWithFilter(Map<String, Object> params) throws BusinessException;

    List<Map> getIssuerListWithFilter(Map<String, Object> params) throws BusinessException;

    List<Map> getInvestorListWithFilter(Map<String, Object> params) throws BusinessException;

    public List<String> getInvestorMobilePhoneListWithFilter(Map<String, Object> params) throws BusinessException;

    int getListCount(Map<String, Object> params) throws BusinessException;

    Map getUserByUserId(String userId) throws BusinessException;

    int insert(Map<String, Object> userInfo) throws BusinessException;

    int update(Map<String, Object> userInfo) throws BusinessException;

    int updateUserVerifyStatus(Map<String, Object> params) throws BusinessException;

    Map login(Map<String, Object> mapParams) throws BusinessException;

    Map regist(Map<String, Object> mapParams) throws BusinessException;

    Map create(Map<String, Object> mapParams) throws BusinessException;

    String resetUserPassword(Map<String, Object> userMap) throws BusinessException;

    void resetPayPassword(Map<String, Object> userMap) throws BusinessException;

    Map<String, Object> checkPayPassword(Map<String, Object> paramMap) throws BusinessException;

    void checkIdCard(Map<String, Object> paramMap) throws BusinessException;

    int initPayPassword(Map<String, Object> userMap) throws BusinessException;

    int fundInitPayPassword(Map<String, Object> userMap) throws BusinessException;

    int isInitPayPassword(String userUuid) throws BusinessException ;

    int clearCheckTime(Map<String, Object> mapParams) throws BusinessException;

    Map xyRegisterKingold(Map<String, Object> mapParams) throws BusinessException;

    public String getInvestorRisk(String userUuid) throws BusinessException ;

    Map smsLogin(LoginParam loginParam) throws BusinessException;

    Integer exist(String idCard) throws BusinessException;

    /**
     * 第三方登录
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    Map thirdLogin(Map params) throws BusinessException;

    /**
     * 活动登录
     * @param loginParam
     * @return
     * @throws BusinessException
     */
    Map campRegistLogin(LoginRegiestParam loginParam) throws BusinessException;

    /**
     * 获取用户-为活动登录使用
     * @param params
     * @param withFreezing
     * @return
     * @throws BusinessException
     */
    Map getUserForCamp(Map<String, Object> params, boolean withFreezing) throws BusinessException ;

    /**
     * 用户注册-为活动使用
     * @param mapParams
     * @return
     * @throws BusinessException
     */
    Map campUserRegist(Map<String, Object> mapParams,boolean isUserExist) throws BusinessException;

    /**
     * 用户注册登录-为开放平台使用
     * @param mapParams
     * @return
     * @throws BusinessException
     */
    Map openRegisterLogin(Map<String, Object> mapParams) throws BusinessException;


    /**
     * 获取用户-为开放平台登录使用
     * @param params
     * @param withFreezing
     * @return
     * @throws BusinessException
     */
    Map getUserForOpen(Map<String, Object> params, boolean withFreezing) throws BusinessException ;


    /**
     * 更新用户交易状态
     *
     * @param userUuid
     * @param param
     * @return
     */
    int updateTradeStatus(String userUuid, UpdateTradeStatusDTO param);

    /**
     * 恢复用户交易状态
     *
     * @param userUuid
     * @param param
     * @return
     */
    int restoreTradeStatus(String userUuid, UpdateTradeStatusDTO param);
}