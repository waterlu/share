package cn.zjhf.kingold.user.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.user.constant.UserParamMsg;
import cn.zjhf.kingold.user.persistence.dao.*;
import cn.zjhf.kingold.user.service.IAdvisorTransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;

/**
 * Created by liuyao on 2017/5/12.
 */
@Service
public class AdvisorTransactionServiceImpl implements IAdvisorTransactionService {

    @Autowired
    private UserMapper userMapper;
    @Autowired
    private AdvisorMapper advisorMapper;
    @Autowired
    private AdvisorRelationMapper advisorRelationMapper;

    @Override
    @Transactional(propagation= Propagation.REQUIRED)
    public void insertUserTransaction(Map<String, Object> insertMap,boolean isUserExist) throws BusinessException {
        int baseIn = 0;
        if(!isUserExist) {
            baseIn = userMapper.insert(insertMap);
        }else {
            baseIn = 1;
        }
        int advisorIn = advisorMapper.insert(insertMap);
        int relationIn = advisorRelationMapper.insert(insertMap);
        if (baseIn + advisorIn + relationIn != 3) {
            throw new BusinessException(UserParamMsg.INNER_ERROR_CODE, UserParamMsg.INNER_ERROR, true);
        }
    }

    @Override
    @Transactional(propagation= Propagation.REQUIRED)
    public int updateUserTransaction(Map<String, Object> updateMap) throws BusinessException {
        int baseIn = userMapper.update(updateMap);
        int advisorIn = advisorMapper.update(updateMap);
        return baseIn + advisorIn;
    }
}
