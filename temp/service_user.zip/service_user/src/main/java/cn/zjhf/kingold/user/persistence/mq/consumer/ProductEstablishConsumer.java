package cn.zjhf.kingold.user.persistence.mq.consumer;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.rocketmq.annotation.RocketMQConsumer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQConsumer;
import cn.zjhf.kingold.service_consumer.service.TradeServiceConsumer;
import cn.zjhf.kingold.user.constant.UrlConstant;
import cn.zjhf.kingold.user.entity.dto.OrderDTO;
import cn.zjhf.kingold.user.persistence.mq.message.ProductMessage;
import cn.zjhf.kingold.user.service.IAchievementService;
import cn.zjhf.kingold.user.utils.MapParamUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.*;

/**
 * Created by liuyao on 17/11/9.
 */
@RocketMQConsumer(topic = "product", tag = "establish")
public class ProductEstablishConsumer extends AbstractMQConsumer<ProductMessage> {
    @Autowired
    private TradeServiceConsumer tradeServiceConsumer;

    @Autowired
    private IAchievementService achievementService;

    public static final int ORDER_STATUS_CONFIRM  = 2;

    public static final String PRODUCT_FIX_INCOME_TYPE  = "FIXI";

    @Override
    public ResponseResult process(ProductMessage productEstablishMessage) throws BusinessException {
        ResponseResult result = new ResponseResult();
        result.setCode(ResponseCode.OK);
        result.setMsg(ResponseCode.OK_TEXT);
        try {
            //查询该产品所有的投资订单
            Map searchMap = new HashMap();
            searchMap.put("productUuid", productEstablishMessage.getProductUuid());
            searchMap.put("orderStatus", ORDER_STATUS_CONFIRM);

            ResponseResult orderResult = tradeServiceConsumer.get(UrlConstant.GET_TRADE_ORDER_LIST, searchMap);
            if (!orderResult.isSuccessful()) {
                throw new BusinessException(orderResult.getCode(), orderResult.getMsg(), true);
            }
            List<Map> orderList = (List<Map>) orderResult.getData();
            generateAchievement(orderList);
        } catch (Exception e) {
            logger.error("product establish generate achievement failed. message={}", productEstablishMessage, e);
            result.setCode(ResponseCode.EXCEPTION);
            result.setMsg(e.getMessage());
        }
        return result;
    }

    private void generateAchievement(List<Map> orderList) {
        for (Map order : orderList) {
            try {
                OrderDTO orderDTO = new OrderDTO();
                orderDTO.setOrderBillCode(MapParamUtils.getStringInMap(order,"orderBillCode"));
                orderDTO.setOrderAmount(MapParamUtils.getBigDecimalInMap(order,"orderAmount"));
                orderDTO.setOrderUserUuid(MapParamUtils.getStringInMap(order,"userUuid"));
                orderDTO.setProductType(PRODUCT_FIX_INCOME_TYPE);
                orderDTO.setOrderCreateTime(new Date((Long)order.get("createTime")));
                achievementService.generateAchievement(orderDTO);
            } catch (Exception e) {
                logger.error("generateAchievement failed.", e);
            }
        }
    }

}
