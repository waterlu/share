package cn.zjhf.kingold.user.persistence.dao;

import cn.zjhf.kingold.user.entity.UserOauth;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * @Author xiaody
 * @Description
 * @Date create in 17/10/30
 */
@Repository
public interface UserOauthMapper {

    int insert(UserOauth userOauth);

    int update(UserOauth userOauth);

    int unbind(@Param("userUuid") String userUuid, @Param("oauthType") Integer oauthType);

    List<UserOauth> getList(Map params);

}