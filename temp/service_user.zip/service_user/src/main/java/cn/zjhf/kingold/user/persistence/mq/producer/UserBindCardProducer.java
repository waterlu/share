package cn.zjhf.kingold.user.persistence.mq.producer;

import cn.zjhf.kingold.rocketmq.annotation.RocketMQProducer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQProducer;
import cn.zjhf.kingold.user.persistence.mq.message.UserBindCardMessage;

/**
 * Created by liuyao on 2017/7/14.
 */
@RocketMQProducer(topic = "user", tag = "bindCard")
public class UserBindCardProducer extends AbstractMQProducer<UserBindCardMessage>{
    
}

