package cn.zjhf.kingold.user.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.user.entity.UserOauth;
import cn.zjhf.kingold.user.entity.UserWechatHist;

import java.util.List;
import java.util.Map;

/**
 * @Author wangxun
 * @Description
 * @Date create in 18/1/3
 */
public interface IUserWechatHistService {

    /**
     * 插入或更新 一个微信用户信息
     *
     * @param params
     * @throws BusinessException
     */
    void upsert(Map params) throws BusinessException;



    /**
     * 通过授权id查询授权绑定信息
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    List<UserWechatHist> getList(Map params) throws BusinessException;
}
