package cn.zjhf.kingold.user.persistence.dao;

import cn.zjhf.kingold.user.entity.TradeStatusDO;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;


@Repository
public interface UserMapper {

    Map get(Map params);

    int insert(Map record);

    int update(Map userInfo);

    int updatePassword(Map userInfo);

    int delete(Map params);

    Integer getCount(Map userMap);

    List<Map> getList(Map userMap);

    int updateLoginInfo(Map userInfo);

    /**
     * 更新用户交易状态为已购买
     *
     * @param userUuid 用户UUID
     * @return
     */
    int updateTradePaidStatus(String userUuid);

    /**
     * 恢复用户交易状态
     *
     * @param tradeStatusDO
     * @return
     */
    int restoreTradeStatus(TradeStatusDO tradeStatusDO);
}