package cn.zjhf.kingold.user.constant;

/**
 * Created by liuyao on 2017/6/30.
 */
public enum AdvisorAuthEnum {
    ADVISOR_AUTH_SUCCESS(1, "认证成功"), ADVISOR_AUTH_FAIL(2, "认证失败");

    private int status;
    private String statusName;

    AdvisorAuthEnum(int status, String statusName) {
        this.status = status;
        this.statusName = statusName;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getStatusName() {
        return statusName;
    }

    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }
}
