package cn.zjhf.kingold.user.persistence.mq.message;

import cn.zjhf.kingold.rocketmq.base.MQMessage;

/**
 * Created by Xiaody on 17/7/27.
 */
public class WechatBindMessage implements MQMessage {
    private String userUuid;

    private String openId;

    private String mobile;

    private Integer platform;

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public Integer getPlatform() {
        return platform;
    }

    public void setPlatform(Integer platform) {
        this.platform = platform;
    }

    @Override
    public String getKey() {
        return userUuid;
    }
}
