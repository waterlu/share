package cn.zjhf.kingold.user.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;

/**
 * Created by liuyao on 2017/5/12.
 */
public interface IUserTransactionService {

    @Transactional(propagation= Propagation.REQUIRED)
    void insertUserTransaction(Map<String, Object> insertMap, boolean isUserExist) throws BusinessException;

    int updateUserTransaction(Map<String, Object> map) throws BusinessException;

    int upgradeUser(String userUuid) throws BusinessException;

}
