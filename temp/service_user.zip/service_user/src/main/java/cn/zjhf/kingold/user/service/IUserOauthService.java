package cn.zjhf.kingold.user.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.user.entity.UserOauth;

import java.util.List;
import java.util.Map;

/**
 * @Author xiaody
 * @Description
 * @Date create in 17/10/30
 */
public interface IUserOauthService {

    /**
     * 用户授权信息绑定手机号
     *
     * @param params
     * @throws BusinessException
     */
    void bind(Map params) throws BusinessException;

    /**
     * 用户授权信息解绑手机号
     *
     * @param params
     * @throws BusinessException
     */
    void unbind(Map params) throws BusinessException;

    /**
     * 通过授权id查询授权绑定信息
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    List<UserOauth> getList(Map params) throws BusinessException;

    /**
     * 根据用户uuid批量获取微信相关绑定信息
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    Map<String, UserOauth> getWechatInfo(Map params) throws BusinessException;

}
