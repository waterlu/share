package cn.zjhf.kingold.user.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.user.service.IWechatBindService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Created by Xiaody on 17/5/19.
 */
@RestController
@RequestMapping("/wechat")
public class WechatBindController {

    @Autowired
    private IWechatBindService wechatBindService;

    /**
     * 将传入的userUuid和openId绑定起来，用于之后微信自动登陆
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/bind", method = RequestMethod.POST)
    public ResponseResult bind(@RequestBody Map params) throws BusinessException {
        wechatBindService.bind(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用");
    }

    /**
     * 退出登录时解绑userUuid和openId
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/unbind", method = RequestMethod.POST)
    public ResponseResult unbind(@RequestBody Map params) throws BusinessException {
        wechatBindService.unbind(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用");
    }


    /**
     * 通过userUuid获取绑定信息
     *
     * @param userUuid
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/userUuid/{userUuid}", method = RequestMethod.GET)
    public ResponseResult getByUserUuid(@PathVariable("userUuid") String userUuid, @RequestParam Map params) throws BusinessException {
        Map map = wechatBindService.getByUserUuidAndPlatform(userUuid, Integer.parseInt(params.get("platform").toString()));
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", map);
    }

    /**
     * 通过openId获取绑定信息
     *
     * @param openId
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/openId/{openId}", method = RequestMethod.GET)
    public ResponseResult getByOpenId(@PathVariable("openId") String openId, @RequestParam Map params) throws BusinessException {
        Map map = wechatBindService.getByOpenIdAndPlatform(openId, Integer.parseInt(params.get("platform").toString()));
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", map);
    }


    /**
     * 获取list返回数据
     *
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public ResponseResult list(@RequestParam(value = "platform", defaultValue = "1") Integer platform,
                               @RequestParam(value = "startRow", defaultValue = "0") Integer startRow,
                               @RequestParam(value = "pageSize", defaultValue = "500") Integer pageSize) throws BusinessException {
        List<Map> map = wechatBindService.getList(platform, startRow, pageSize);
        return new ResponseResult("", ResponseCode.REQUEST_SUCCESS, "正常调用", map);
    }

}
