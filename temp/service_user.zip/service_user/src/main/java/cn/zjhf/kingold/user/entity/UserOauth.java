package cn.zjhf.kingold.user.entity;

import cn.zjhf.kingold.common.param.ParamVO;

import java.io.Serializable;
import java.util.Date;

/**
 * @author
 */
public class UserOauth extends ParamVO implements Serializable {
    private Long userOauthId;

    /**
     * 认证类型(1、微信，2、微博，10、微信公众号）
     */
    private Integer oauthType;

    /**
     * 用户uuid
     */
    private String userUuid;

    /**
     * 认证的第三方用户唯一id
     */
    private String oauthId;

    /**
     * 用户第三方昵称
     */
    private String nickName;

    /**
     * 用户第三方头像
     */
    private String headImageUrl;

    /**
     * 性别
     */
    private Integer sex;

    /**
     * 国家
     */
    private String country;

    /**
     * 省
     */
    private String province;

    /**
     * 城市
     */
    private String city;

    /**
     * 语言
     */
    private String language;

    /**
     * 用户手机号
     */
    private String userMobile;

    /**
     * 绑定是否开启（0、不开启，1、开启）
     */
    private Integer status;

    /**
     * 投资人类型（11普通投资人 12理财达人 19专职理财师）
     */
    private String investorType;

    private Integer deleteFlag;

    private Date createTime;

    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public Long getUserOauthId() {
        return userOauthId;
    }

    public void setUserOauthId(Long userOauthId) {
        this.userOauthId = userOauthId;
    }

    public Integer getOauthType() {
        return oauthType;
    }

    public void setOauthType(Integer oauthType) {
        this.oauthType = oauthType;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getOauthId() {
        return oauthId;
    }

    public void setOauthId(String oauthId) {
        this.oauthId = oauthId;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getHeadImageUrl() {
        return headImageUrl;
    }

    public void setHeadImageUrl(String headImageUrl) {
        this.headImageUrl = headImageUrl;
    }

    public String getUserMobile() {
        return userMobile;
    }

    public void setUserMobile(String userMobile) {
        this.userMobile = userMobile;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Integer deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getInvestorType() {
        return investorType;
    }

    public void setInvestorType(String investorType) {
        this.investorType = investorType;
    }

    @Override
    public String toString() {
        return "UserOauth{" +
                "userOauthId=" + userOauthId +
                ", oauthType=" + oauthType +
                ", userUuid='" + userUuid + '\'' +
                ", oauthId='" + oauthId + '\'' +
                ", nickName='" + nickName + '\'' +
                ", headImageUrl='" + headImageUrl + '\'' +
                ", sex=" + sex +
                ", country='" + country + '\'' +
                ", province='" + province + '\'' +
                ", city='" + city + '\'' +
                ", language='" + language + '\'' +
                ", userMobile='" + userMobile + '\'' +
                ", status=" + status +
                ", deleteFlag=" + deleteFlag +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                '}';
    }
}