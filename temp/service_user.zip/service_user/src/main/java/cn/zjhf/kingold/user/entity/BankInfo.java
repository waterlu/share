package cn.zjhf.kingold.user.entity;

import org.hibernate.validator.constraints.NotEmpty;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class BankInfo implements Serializable {
    private String biUuid;

    /**
     * 用户UUID
     */
    @NotEmpty
    private String userUuid;

    /**
     * 持卡人
     */
    private String userName;

    /**
     * 银行预留手机号
     */
    private String biUserMobile;

    /**
     * 银行卡号
     */
    private String biBankNo;

    /**
     * 银行名称
     */
    private String biBankName;

    /**
     * 银行所在地
     */
    private String biBankCity;

    /**
     * 开户支行
     */
    private String biSubbranch;

    /**
     * 备注
     */
    private String biRemark;

    /**
     * 是否银行卡实名审核状态0未审核，1审核，2银行卡有问题退回
     */
    private Byte biState;

    /**
     * 创建时间
     */
    @NotEmpty
    private Date createTime;

    /**
     * 更新时间
     */
    @NotEmpty
    private Date updateTime;

    /**
     * 删除标记 0未删除，1已删除
     */
    @NotEmpty
    private Byte deleteFlag;

    private static final long serialVersionUID = 1L;

    public String getBiUuid() {
        return biUuid;
    }

    public void setBiUuid(String biUuid) {
        this.biUuid = biUuid;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getBiUserMobile() {
        return biUserMobile;
    }

    public void setBiUserMobile(String biUserMobile) {
        this.biUserMobile = biUserMobile;
    }

    public String getBiBankNo() {
        return biBankNo;
    }

    public void setBiBankNo(String biBankNo) {
        this.biBankNo = biBankNo;
    }

    public String getBiBankName() {
        return biBankName;
    }

    public void setBiBankName(String biBankName) {
        this.biBankName = biBankName;
    }

    public String getBiBankCity() {
        return biBankCity;
    }

    public void setBiBankCity(String biBankCity) {
        this.biBankCity = biBankCity;
    }

    public String getBiSubbranch() {
        return biSubbranch;
    }

    public void setBiSubbranch(String biSubbranch) {
        this.biSubbranch = biSubbranch;
    }

    public String getBiRemark() {
        return biRemark;
    }

    public void setBiRemark(String biRemark) {
        this.biRemark = biRemark;
    }

    public Byte getBiState() {
        return biState;
    }

    public void setBiState(Byte biState) {
        this.biState = biState;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }
}