package cn.zjhf.kingold.user.persistence.dao;

import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * Created by liuyao on 2017/5/11.
 */
@Repository
public interface UserIssuerUnionMapper {
    Map get(Map params);

    List<Map> getList(Map params);
}
