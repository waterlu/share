package cn.zjhf.kingold.user.service;

import cn.zjhf.kingold.common.exception.BusinessException;

import java.util.List;
import java.util.Map;

/**
 * Created by Xiaody on 17/5/19.
 */
public interface IWechatBindService {
    void bind(Map map) throws BusinessException;

    void unbind(Map map) throws BusinessException;

    Map getByUserUuidAndPlatform(String userUuid, Integer platform) throws BusinessException;

    Map getByOpenIdAndPlatform(String openId, Integer platform) throws BusinessException;

    List<Map> getList(Integer platform, Integer offset, Integer limit) ;


}
