package cn.zjhf.kingold.user.persistence.dao;


import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
@Mapper
public interface TradeOrderMapper {
    Integer insert(Map map);

    Map get(@Param("orderBillCode") String orderBillCode);

    void update(Map map);

    List<Map> getList(Map map);

}