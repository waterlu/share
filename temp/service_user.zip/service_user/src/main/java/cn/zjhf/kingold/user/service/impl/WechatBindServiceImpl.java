package cn.zjhf.kingold.user.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.user.constant.UserParamMsg;
import cn.zjhf.kingold.user.entity.WechatBind;
import cn.zjhf.kingold.user.persistence.dao.InvestorMapper;
import cn.zjhf.kingold.user.persistence.dao.WechatBindMapper;
import cn.zjhf.kingold.user.persistence.mq.message.WechatBindMessage;
import cn.zjhf.kingold.user.persistence.mq.producer.WechatBindProducer;
import cn.zjhf.kingold.user.service.IUserService;
import cn.zjhf.kingold.user.service.IWechatBindService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Created by Xiaody on 17/5/19.
 */
@Service
public class WechatBindServiceImpl implements IWechatBindService {

    @Autowired
    private WechatBindMapper wechatBindMapper;

    @Autowired
    private WechatBindProducer wechatBindProducer;

    /**
     * 微信端登陆时将用户uuid和openid绑定起来
     *
     * @param map
     * @return
     */
    @Override
    public void bind(Map map) throws BusinessException {
        String userUuid = (String) map.get("userUuid");
        String openId = (String) map.get("openId");
        Integer platform = (Integer) map.get("platform");
        Map wechatBind = wechatBindMapper.getByUserUuidAndPlatform(userUuid, platform);
        if (wechatBind != null) {
            if (!wechatBind.get("openId").toString().equals(openId)) {
                throw new BusinessException(UserParamMsg.OPENID_NOT_MATCH_CODE, UserParamMsg.OPENID_NOT_MATCH_ERROR, true);
            }
        } else {
            Map wechatBind2 = getByOpenIdAndPlatform(openId, platform);
            if (wechatBind2 != null) {
                wechatBindMapper.deleteByOpenIdAndPlatform(openId, platform);
            }
            wechatBindMapper.insert(map);
            WechatBindMessage message = new WechatBindMessage();
            message.setUserUuid(userUuid);
            message.setOpenId(openId);
            message.setPlatform(platform);
            message.setMobile((String) map.get("mobile"));
            wechatBindProducer.send(message);
        }
    }

    /**
     * 用于用户退出登录时解绑
     * 传userUuid和platform则用userUuid和platform删除绑定信息
     * 传openId和platform则用openId和platform删除绑定信息
     *
     * @param map
     * @throws BusinessException
     */
    @Override
    public void unbind(Map map) throws BusinessException {
        if (map.containsKey("userUuid") && map.containsKey("platform")) {
            String userUuid = (String) map.get("userUuid");
            Integer platform = (Integer) map.get("platform");
            wechatBindMapper.deleteByUserUuidAndPlatform(userUuid, platform);
        } else if (map.containsKey("openId") && map.containsKey("platform")) {
            String openId = (String) map.get("openId");
            Integer platform = (Integer) map.get("platform");
            wechatBindMapper.deleteByOpenIdAndPlatform(openId, platform);
        } else {
            throw new BusinessException(UserParamMsg.REQUEST_PARAM_ERROR_CODE, UserParamMsg.REQUEST_PARAM_ERROR, true);
        }
    }

    /**
     * 通过用户uuid和platform获取绑定信息，没有时返回null
     *
     * @param userUuid
     * @return
     */
    @Override
    public Map getByUserUuidAndPlatform(String userUuid, Integer platform) throws BusinessException {
        return wechatBindMapper.getByUserUuidAndPlatform(userUuid, platform);
    }

    /**
     * 通过openid和platform获取绑定信息，没有时返回null
     *
     * @param openId
     * @return
     */
    @Override
    public Map getByOpenIdAndPlatform(String openId, Integer platform) throws BusinessException {
        return wechatBindMapper.getByOpenIdAndPlatform(openId, platform);
    }

    @Override
    public List<Map> getList(Integer platform, Integer offset, Integer limit) {

        return wechatBindMapper.getList(platform, offset, limit);
    }

}
