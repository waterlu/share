package cn.zjhf.kingold.user.persistence.dao;

import cn.zjhf.kingold.user.entity.InvestorMobileContact;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
@Repository
public interface InvestorMobileContactMapper {
    int deleteByPrimaryKey(Long id);

    int insert(InvestorMobileContact record);

    int batchInsert(@Param("list") List<InvestorMobileContact> list);

    int insertSelective(InvestorMobileContact record);

    InvestorMobileContact selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(InvestorMobileContact record);

    int updateByPrimaryKey(InvestorMobileContact record);
}