package cn.zjhf.kingold.user.entity;

import java.util.Date;

public class UserStatusLog {
    /**
     * 自增主键
     */
    private Long userStatusLogId;

    /**
     * 用户UUID
     */
    private String userUuid;

    /**
     * 1-认证状态 2-交易状态
     */
    private Integer statusType;

    /**
     * 变更前的状态
     */
    private Integer statusOld;

    /**
     * 变更后的状态
     */
    private Integer statusNew;

    /**
     * 变更时间
     */
    private Date changeTime;

    /**
     * 订单号
     */
    private String orderBillCode;

    private Integer deleteFlag;

    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 获取自增主键
     *
     * @return user_status_log_id - 自增主键
     */
    public Long getUserStatusLogId() {
        return userStatusLogId;
    }

    /**
     * 设置自增主键
     *
     * @param userStatusLogId 自增主键
     */
    public void setUserStatusLogId(Long userStatusLogId) {
        this.userStatusLogId = userStatusLogId;
    }

    /**
     * 获取用户UUID
     *
     * @return user_uuid - 用户UUID
     */
    public String getUserUuid() {
        return userUuid;
    }

    /**
     * 设置用户UUID
     *
     * @param userUuid 用户UUID
     */
    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    /**
     * 获取1-认证状态 2-交易状态
     *
     * @return status_type - 1-认证状态 2-交易状态
     */
    public Integer getStatusType() {
        return statusType;
    }

    /**
     * 设置1-认证状态 2-交易状态
     *
     * @param statusType 1-认证状态 2-交易状态
     */
    public void setStatusType(Integer statusType) {
        this.statusType = statusType;
    }

    /**
     * 获取变更前的状态
     *
     * @return status_old - 变更前的状态
     */
    public Integer getStatusOld() {
        return statusOld;
    }

    /**
     * 设置变更前的状态
     *
     * @param statusOld 变更前的状态
     */
    public void setStatusOld(Integer statusOld) {
        this.statusOld = statusOld;
    }

    /**
     * 获取变更后的状态
     *
     * @return status_new - 变更后的状态
     */
    public Integer getStatusNew() {
        return statusNew;
    }

    /**
     * 设置变更后的状态
     *
     * @param statusNew 变更后的状态
     */
    public void setStatusNew(Integer statusNew) {
        this.statusNew = statusNew;
    }

    /**
     * 获取变更时间
     *
     * @return change_time - 变更时间
     */
    public Date getChangeTime() {
        return changeTime;
    }

    /**
     * 设置变更时间
     *
     * @param changeTime 变更时间
     */
    public void setChangeTime(Date changeTime) {
        this.changeTime = changeTime;
    }

    /**
     * 获取订单号
     *
     * @return order_bill_code - 订单号
     */
    public String getOrderBillCode() {
        return orderBillCode;
    }

    /**
     * 设置订单号
     *
     * @param orderBillCode 订单号
     */
    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    /**
     * @return delete_flag
     */
    public Integer getDeleteFlag() {
        return deleteFlag;
    }

    /**
     * @param deleteFlag
     */
    public void setDeleteFlag(Integer deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    /**
     * @return create_time
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * @param createTime
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 获取更新时间
     *
     * @return update_time - 更新时间
     */
    public Date getUpdateTime() {
        return updateTime;
    }

    /**
     * 设置更新时间
     *
     * @param updateTime 更新时间
     */
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}