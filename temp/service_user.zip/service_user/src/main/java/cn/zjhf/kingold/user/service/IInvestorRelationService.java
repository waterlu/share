package cn.zjhf.kingold.user.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.user.entity.InvestorMobileContact;
import cn.zjhf.kingold.user.entity.UserWechatHist;

import java.util.List;
import java.util.Map;

/**
 * Created by Xiaody on 17/6/7.
 */
public interface IInvestorRelationService {

    /**
     * 获取用户关系信息
     *
     * @param userUuid
     * @return
     * @throws BusinessException
     */
    Map getInvestorRelation(String userUuid) throws BusinessException;


    /**
     * 获取用户好友
     * @param map
     * @return
     * @throws BusinessException
     */
    public List<Map> getRelationList(Map map) throws BusinessException;


    /**
     * 同时获取自己一级邀请和二级邀请的用户数量
     *
     * @param map
     * @return
     * @throws BusinessException
     */
    Map getRelationCount(Map map) throws BusinessException;

    /**
     * 根据查询条件获取自己一级邀请或者二级邀请的用户信息
     *
     * @param map
     * @return
     * @throws BusinessException
     */
    List<Map> getList(Map map) throws BusinessException;

    /**
     * 根据查询条件获取自己一级邀请或者二级邀请的用户数量
     *
     * @param map
     * @return
     * @throws BusinessException
     */
    Integer getCount(Map map) throws BusinessException;


    /**
     * 获取用户好友绑定了的openid
     *
     * @param map
     * @return
     * @throws BusinessException
     */
    List<Map> getRelationOpenid(Map map) throws BusinessException;

    /**
     * 根据电话
     * 获取个人信息
     * 获取上级，上上级，上上上级邀请人信息
     * 获取下级投资人列表，下级投资人对应下级数量
     * @param map
     * @return
     * @throws BusinessException
     */
    Map getRelationByMobile(Map map) throws BusinessException;

    /**
     * 获取金疙瘩好友电话和姓名，及银疙瘩数量
     * @param map userUuid 必填
     */
    List<Map> getDownOneInvestor(Map map);

    /**
     * 获取下级数量
     * @param map
     * @return
     */
    int getDownOneInvestorCount(Map map);

    /**
     * 保存通讯录
     * @return
     */
    int saveContact(List<InvestorMobileContact> contactList);

    Map getRelationSortByTime(Map map) throws BusinessException;

    Map getRelationSortByReward(Map sourceParam) throws BusinessException;

    List<UserWechatHist> getFatherAndSonAndSelfList(Map map) throws BusinessException;
}
