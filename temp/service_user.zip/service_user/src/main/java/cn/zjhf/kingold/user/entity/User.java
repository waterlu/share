package cn.zjhf.kingold.user.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class User implements Serializable {
    /**
     * 自增ID
     */
    private Long userId;

    /**
     * 用户UUID
     */
    private String userUuid;

    /**
     * 用户类型（1投资者 2产品发行方 9金疙瘩平台）
     */
    private Byte userType;

    /**
     * 用户登录名（可以是手机号码或其他）
     */
    private String userLoginName;

    /**
     * 用户登录密码（MD5）
     */
    private String userLoginPassword;

    /**
     * 用户交易密码（MD5）
     */
    private String userPayPassword;

    /**
     * 加密盐
     */
    private String encryptSalt;

    /**
     * 注册时间
     */
    private Date registerTime;

    /**
     * 注册渠道编码（默认：kingold）
     */
    private String registerChannelCode;

    /**
     * 注册分享页面来源
     */
    private String registerSharePageType;

    /**
     * 注册活动批次
     */
    private String registerActivityBatch;

    /**
     * 注册版本编码
     */
    private String registerVersionCode;

    /**
     * 注册设备ID
     */
    private String registerDeviceId;

    /**
     * 注册设备类型
     */
    private String registerDeviceType;

    /**
     * 注册设备名称
     */
    private String registerDeviceName;

    /**
     * 注册设备操作系统
     */
    private String registerDeviceOs;

    /**
     * 注册设备IP
     */
    private String registerDeviceIp;

    /**
     * 最后登录时间
     */
    private String loginTime;

    /**
     * 最后登录渠道编码（默认：kingold）
     */
    private String loginChannelCode;

    /**
     * 最后登录版本编码
     */
    private String loginVersionCode;

    /**
     * 最后登录设备ID
     */
    private String loginDeviceId;

    /**
     * 最后登录设备类型
     */
    private String loginDeviceType;

    /**
     * 最后登录设备操作系统
     */
    private String loginDeviceOs;

    /**
     * 最后登录设备IP
     */
    private String loginDeviceIp;

    /**
     * 数据签名
     */
    private String signature;

    /**
     * 删除标记
     */
    private Byte deleteFlag;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 用户状态（1表示冻结）
     */
    private Short userStatus;

    /**
     * 用户认证状态(0初始状态 1宝付注册成功 2授权成功 3绑卡成功 9密码设置完成，开户流程完成)
     */
    private Short userVerifyStatus;

    /**
     * 用户交易状态（充值完成：1，认购完成：2）
     */
    private Integer userTradeStatus;

    /**
     * 注册商户号
     */
    private String registerMerchantNum;

    /**
     * 最后登录商户号
     */
    private String loginMerchantNum;

    private static final long serialVersionUID = 1L;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public Byte getUserType() {
        return userType;
    }

    public void setUserType(Byte userType) {
        this.userType = userType;
    }

    public String getUserLoginName() {
        return userLoginName;
    }

    public void setUserLoginName(String userLoginName) {
        this.userLoginName = userLoginName;
    }

    public String getUserLoginPassword() {
        return userLoginPassword;
    }

    public void setUserLoginPassword(String userLoginPassword) {
        this.userLoginPassword = userLoginPassword;
    }

    public String getUserPayPassword() {
        return userPayPassword;
    }

    public void setUserPayPassword(String userPayPassword) {
        this.userPayPassword = userPayPassword;
    }

    public String getEncryptSalt() {
        return encryptSalt;
    }

    public void setEncryptSalt(String encryptSalt) {
        this.encryptSalt = encryptSalt;
    }

    public Date getRegisterTime() {
        return registerTime;
    }

    public void setRegisterTime(Date registerTime) {
        this.registerTime = registerTime;
    }

    public String getRegisterChannelCode() {
        return registerChannelCode;
    }

    public void setRegisterChannelCode(String registerChannelCode) {
        this.registerChannelCode = registerChannelCode;
    }

    public String getRegisterVersionCode() {
        return registerVersionCode;
    }

    public void setRegisterVersionCode(String registerVersionCode) {
        this.registerVersionCode = registerVersionCode;
    }

    public String getRegisterDeviceId() {
        return registerDeviceId;
    }

    public void setRegisterDeviceId(String registerDeviceId) {
        this.registerDeviceId = registerDeviceId;
    }

    public String getRegisterDeviceType() {
        return registerDeviceType;
    }

    public void setRegisterDeviceType(String registerDeviceType) {
        this.registerDeviceType = registerDeviceType;
    }

    public String getRegisterDeviceName() {
        return registerDeviceName;
    }

    public void setRegisterDeviceName(String registerDeviceName) {
        this.registerDeviceName = registerDeviceName;
    }

    public String getRegisterDeviceOs() {
        return registerDeviceOs;
    }

    public void setRegisterDeviceOs(String registerDeviceOs) {
        this.registerDeviceOs = registerDeviceOs;
    }

    public String getRegisterDeviceIp() {
        return registerDeviceIp;
    }

    public void setRegisterDeviceIp(String registerDeviceIp) {
        this.registerDeviceIp = registerDeviceIp;
    }

    public String getLoginTime() {
        return loginTime;
    }

    public void setLoginTime(String loginTime) {
        this.loginTime = loginTime;
    }

    public String getLoginChannelCode() {
        return loginChannelCode;
    }

    public void setLoginChannelCode(String loginChannelCode) {
        this.loginChannelCode = loginChannelCode;
    }

    public String getLoginVersionCode() {
        return loginVersionCode;
    }

    public void setLoginVersionCode(String loginVersionCode) {
        this.loginVersionCode = loginVersionCode;
    }

    public String getLoginDeviceId() {
        return loginDeviceId;
    }

    public void setLoginDeviceId(String loginDeviceId) {
        this.loginDeviceId = loginDeviceId;
    }

    public String getLoginDeviceType() {
        return loginDeviceType;
    }

    public void setLoginDeviceType(String loginDeviceType) {
        this.loginDeviceType = loginDeviceType;
    }

    public String getLoginDeviceOs() {
        return loginDeviceOs;
    }

    public void setLoginDeviceOs(String loginDeviceOs) {
        this.loginDeviceOs = loginDeviceOs;
    }

    public String getLoginDeviceIp() {
        return loginDeviceIp;
    }

    public void setLoginDeviceIp(String loginDeviceIp) {
        this.loginDeviceIp = loginDeviceIp;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Short getUserStatus() {
        return userStatus;
    }

    public void setUserStatus(Short userStatus) {
        this.userStatus = userStatus;
    }

    public Short getUserVerifyStatus() {
        return userVerifyStatus;
    }

    public void setUserVerifyStatus(Short userVerifyStatus) {
        this.userVerifyStatus = userVerifyStatus;
    }

    public Integer getUserTradeStatus() {
        return userTradeStatus;
    }

    public void setUserTradeStatus(Integer userTradeStatus) {
        this.userTradeStatus = userTradeStatus;
    }

    public String getRegisterMerchantNum() {
        return registerMerchantNum;
    }

    public void setRegisterMerchantNum(String registerMerchantNum) {
        this.registerMerchantNum = registerMerchantNum;
    }

    public String getLoginMerchantNum() {
        return loginMerchantNum;
    }

    public void setLoginMerchantNum(String loginMerchantNum) {
        this.loginMerchantNum = loginMerchantNum;
    }

    public String getRegisterSharePageType() {
        return registerSharePageType;
    }

    public void setRegisterSharePageType(String registerSharePageType) {
        this.registerSharePageType = registerSharePageType;
    }

    public String getRegisterActivityBatch() {
        return registerActivityBatch;
    }

    public void setRegisterActivityBatch(String registerActivityBatch) {
        this.registerActivityBatch = registerActivityBatch;
    }
}