package cn.zjhf.kingold.user.constant;

import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by liuyao on 2017/5/11.
 */
public class InvestorKeyConstants {
    public static final String INVESTOR_ID_LONG = "investorId";
    public static final String USER_UUID_STR = "userUuid";
    public static final String INVESTOR_ORGANIZATION_UUID_STR = "investorOrganizationUuid";
    public static final String INVESTOR_ORGANIZATION_PATH_STR = "investorOrganizationPath";
    public static final String INVESTOR_MOBILE_STR = "investorMobile";
    public static final String INVESTOR_GENDER_BYTE = "investorGender";
    public static final String INVESTOR_AVATAR_STR = "investorAvatar";
    public static final String INVESTOR_TYPE_BYTE = "investorType";
    public static final String IS_INNER_BYTE = "isInner";
    public static final String INVITER_UUID = "inviterUuid";
    public static final String INVESTOR_REAL_NAME_STR = "investorRealName";
    public static final String INVESTOR_ID_CARD_NO_STR = "investorIdCardNo";
    public static final String INVESTOR_REGION_CODE_STR = "investorRegionCode";
    public static final String INVESTOR_ADDRESS_STR = "investorAddress";
    public static final String IS_ELIGIBLE_INVESTOR_BYTE = "isEligibleInvestor";
    public static final String INVESTOR_RISK_SCORE_INT = "investorRiskScore";
    public static final String INVESTOR_RISK_TYPE_INT = "investorRiskType";
    public static final String INVESTOR_RISK_TYPE_STR = "investorRiskTypeDesc";
    public static final String MIN_RISK_LEVEL = "isMinRiskLevel";
    public static final String INVESTOR_RISK_LEVEL_INT = "investorRiskLevel";
    public static final String INVESTOR_RISK_VERSION_INT = "investorRiskVersion";
    public static final String INVESTOR_RISK_ANSWER_STR = "investorRiskAnswer";
    public static final String INVESTOR_RISK_PRODUCT_INT = "investorRiskProduct";
    public static final String SIGNATURE_STR = "signature";
    public static final String DELETE_FALG_Byte = "deleteFlag";
    public static final String CREATE_TIME_DATE = "createTime";
    public static final String UPDATE_TIME_DATE = "updateTime";

    public static final Map<String, String> riskMap0Start = new HashMap<String, String>();
    public static final Map<String, String> riskMap3Start = new HashMap<String, String>();


    static {
        riskMap0Start.put("0","1");
        riskMap0Start.put("1","2");
        riskMap0Start.put("2","3");
        riskMap0Start.put("3","4");
        riskMap0Start.put("4","5");
        riskMap3Start.put("3","1");
        riskMap3Start.put("2","2");
        riskMap3Start.put("1","3");
        riskMap3Start.put("0","4");

    }

    public static void main(String[] args) {
        String s = "2";
        if (StringUtils.isNotBlank(s)) {
            List<String> pfoStatusList = Arrays.asList(s.split("\\$\\$"));
            pfoStatusList.forEach(x -> System.out.println(x));
        }
    }
}
