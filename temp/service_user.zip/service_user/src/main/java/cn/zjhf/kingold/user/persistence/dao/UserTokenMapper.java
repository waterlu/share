package cn.zjhf.kingold.user.persistence.dao;

import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface UserTokenMapper {
    Map get(Map params);

    int insert(Map record);

    int update(Map userInfo);

    int delete(Map params);

    List<Map> getList(Map userMap);


    int getCount(Map userMap);
}