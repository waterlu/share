package cn.zjhf.kingold.user.constant;

/**
 * 募集方对象字段名字
 * @author liuyao
 * @create 2017-05-11 13:45
 **/
public class IssuerKeyConstants {
    public static final String USER_UUID_STR = "userUuid";
    public static final String USER_ISSUER_NAME_STR = "issuerName";
    public static final String LEGAL_PERSON_MOBILE_STR = "legalPersonMobile";



}
