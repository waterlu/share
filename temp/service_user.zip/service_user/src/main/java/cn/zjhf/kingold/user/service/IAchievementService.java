package cn.zjhf.kingold.user.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.user.entity.dto.OrderDTO;
import cn.zjhf.kingold.user.entity.dto.UpgradeAvailableDTO;

/**
 * Created by liuyao on 2017/11/9.
 */
public interface IAchievementService {

    int generateAchievement(OrderDTO orderDTO) throws Exception;

    UpgradeAvailableDTO moneyManageTalentProgress(String userUuid) throws BusinessException ;

    void upgradeTalentApply(String userUuid) throws BusinessException ;

}
