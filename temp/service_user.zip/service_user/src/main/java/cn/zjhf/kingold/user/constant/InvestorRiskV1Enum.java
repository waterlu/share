package cn.zjhf.kingold.user.constant;

/**
 * Created by liuyao on 2017/6/13.
 */
public enum InvestorRiskV1Enum {
    KEEP(1, "保守型", 11, 26), STEADY(2, "谨慎型", 27, 36),
    BALANCE(3, "稳健型", 37, 60), GROW(4, "积极型", 61, 75), RADICAL(5, "激进型", 76, 100);

    private Integer type;
    private String desc;
    private Integer min;
    private Integer max;

    InvestorRiskV1Enum(Integer type, String desc, Integer min, Integer max) {
        this.type = type;
        this.desc = desc;
        this.min = min;
        this.max = max;
    }

    public static InvestorRiskV1Enum getRiskEnum(Integer score) {
        for (InvestorRiskV1Enum risk: InvestorRiskV1Enum.values()) {
            if (score <= risk.max && score >= risk.min) {
                return risk;
            }
        }
        return KEEP;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public Integer getMin() {
        return min;
    }

    public void setMin(Integer min) {
        this.min = min;
    }

    public Integer getMax() {
        return max;
    }

    public void setMax(Integer max) {
        this.max = max;
    }
}
