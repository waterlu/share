package cn.zjhf.kingold.user.entity;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.user.constant.UserParamMsg;
import org.hibernate.validator.constraints.NotBlank;

/**
 * Created by liuyao on 2017/10/27.
 */
public class LoginRegiestParam extends ParamVO{

    @NotBlank(message = UserParamMsg.REQUEST_PARAM_ERROR)
    private String investorMobile;

    private String smsCode;

    private String loginDeviceId;

    private String loginDeviceOs;

    private String loginDeviceIp;

    private String loginChannelCode;

    private String loginVersionCode;

    private String loginDeviceType;

    private Integer loginMethod;

    private String campCode;

    private String inviterPhone;

    private String loginMerchantNum;

    private String registerMerchantNum;

    /**
     * 注册渠道编码（默认：kingold）
     */
    private String registerChannelCode;

    /**
     * 注册分享页面来源
     */
    private String registerSharePageType;

    /**
     * 注册活动批次
     */
    private String registerActivityBatch;

    /**
     * 注册版本编码
     */
    private String registerVersionCode;

    /**
     * 注册设备ID
     */
    private String registerDeviceId;

    /**
     * 注册设备类型
     */
    private String registerDeviceType;

    /**
     * 注册设备名称
     */
    private String registerDeviceName;

    /**
     * 注册设备操作系统
     */
    private String registerDeviceOs;

    /**
     * 注册设备IP
     */
    private String registerDeviceIp;



    public String getInvestorMobile() {
        return investorMobile;
    }

    public void setInvestorMobile(String investorMobile) {
        this.investorMobile = investorMobile;
    }

    public String getSmsCode() {
        return smsCode;
    }

    public void setSmsCode(String smsCode) {
        this.smsCode = smsCode;
    }

    public String getLoginDeviceId() {
        return loginDeviceId;
    }

    public void setLoginDeviceId(String loginDeviceId) {
        this.loginDeviceId = loginDeviceId;
    }

    public String getLoginDeviceOs() {
        return loginDeviceOs;
    }

    public void setLoginDeviceOs(String loginDeviceOs) {
        this.loginDeviceOs = loginDeviceOs;
    }

    public String getLoginDeviceIp() {
        return loginDeviceIp;
    }

    public void setLoginDeviceIp(String loginDeviceIp) {
        this.loginDeviceIp = loginDeviceIp;
    }

    public String getLoginChannelCode() {
        return loginChannelCode;
    }

    public void setLoginChannelCode(String loginChannelCode) {
        this.loginChannelCode = loginChannelCode;
    }

    public String getLoginVersionCode() {
        return loginVersionCode;
    }

    public void setLoginVersionCode(String loginVersionCode) {
        this.loginVersionCode = loginVersionCode;
    }

    public String getLoginDeviceType() {
        return loginDeviceType;
    }

    public void setLoginDeviceType(String loginDeviceType) {
        this.loginDeviceType = loginDeviceType;
    }

    public Integer getLoginMethod() {
        return loginMethod;
    }

    public void setLoginMethod(Integer loginMethod) {
        this.loginMethod = loginMethod;
    }

    @Override
    public String toString() {
        return "LoginParam{" +
                "investorMobile='" + investorMobile + '\'' +
                ", smsCode='" + smsCode + '\'' +
                '}';
    }

    public String getCampCode() {
        return campCode;
    }

    public void setCampCode(String campCode) {
        this.campCode = campCode;
    }

    public String getInviterPhone() {
        return inviterPhone;
    }

    public void setInviterPhone(String inviterPhone) {
        this.inviterPhone = inviterPhone;
    }

    public String getRegisterChannelCode() {
        return registerChannelCode;
    }

    public void setRegisterChannelCode(String registerChannelCode) {
        this.registerChannelCode = registerChannelCode;
    }

    public String getRegisterSharePageType() {
        return registerSharePageType;
    }

    public void setRegisterSharePageType(String registerSharePageType) {
        this.registerSharePageType = registerSharePageType;
    }

    public String getRegisterActivityBatch() {
        return registerActivityBatch;
    }

    public void setRegisterActivityBatch(String registerActivityBatch) {
        this.registerActivityBatch = registerActivityBatch;
    }

    public String getRegisterVersionCode() {
        return registerVersionCode;
    }

    public void setRegisterVersionCode(String registerVersionCode) {
        this.registerVersionCode = registerVersionCode;
    }

    public String getRegisterDeviceId() {
        return registerDeviceId;
    }

    public void setRegisterDeviceId(String registerDeviceId) {
        this.registerDeviceId = registerDeviceId;
    }

    public String getRegisterDeviceType() {
        return registerDeviceType;
    }

    public void setRegisterDeviceType(String registerDeviceType) {
        this.registerDeviceType = registerDeviceType;
    }

    public String getRegisterDeviceName() {
        return registerDeviceName;
    }

    public void setRegisterDeviceName(String registerDeviceName) {
        this.registerDeviceName = registerDeviceName;
    }

    public String getRegisterDeviceOs() {
        return registerDeviceOs;
    }

    public void setRegisterDeviceOs(String registerDeviceOs) {
        this.registerDeviceOs = registerDeviceOs;
    }

    public String getRegisterDeviceIp() {
        return registerDeviceIp;
    }

    public void setRegisterDeviceIp(String registerDeviceIp) {
        this.registerDeviceIp = registerDeviceIp;
    }

    public String getLoginMerchantNum() {
        return loginMerchantNum;
    }

    public void setLoginMerchantNum(String loginMerchantNum) {
        this.loginMerchantNum = loginMerchantNum;
    }

    public String getRegisterMerchantNum() {
        return registerMerchantNum;
    }

    public void setRegisterMerchantNum(String registerMerchantNum) {
        this.registerMerchantNum = registerMerchantNum;
    }
}
