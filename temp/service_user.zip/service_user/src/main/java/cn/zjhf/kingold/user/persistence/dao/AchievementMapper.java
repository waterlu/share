package cn.zjhf.kingold.user.persistence.dao;

import cn.zjhf.kingold.user.entity.Achievement;

import java.util.List;

public interface AchievementMapper {
    int deleteByPrimaryKey(Long id);

    int insert(Achievement record);

    int insertSelective(Achievement record);

    int batchInsert(List<Achievement> list);

    Achievement selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Achievement record);

    int updateByPrimaryKey(Achievement record);

    int getAchievementProgress(String userUuid);
}