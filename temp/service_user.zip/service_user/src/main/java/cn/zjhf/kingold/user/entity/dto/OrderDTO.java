package cn.zjhf.kingold.user.entity.dto;

import java.math.BigDecimal;
import java.util.Date;

public class OrderDTO {
    private Long id;

    private String orderBillCode;

    private String orderUserUuid;

    private String productType;

    private BigDecimal orderAmount;

    private Date orderCreateTime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getOrderUserUuid() {
        return orderUserUuid;
    }

    public void setOrderUserUuid(String orderUserUuid) {
        this.orderUserUuid = orderUserUuid == null ? null : orderUserUuid.trim();
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType == null ? null : productType.trim();
    }

    public BigDecimal getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(BigDecimal orderAmount) {
        this.orderAmount = orderAmount;
    }

    public Date getOrderCreateTime() {
        return orderCreateTime;
    }

    public void setOrderCreateTime(Date orderCreateTime) {
        this.orderCreateTime = orderCreateTime;
    }

    public String getOrderBillCode() {
        return orderBillCode;
    }

    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    @Override
    public String toString() {
        return "OrderDTO{" +
                "id=" + id +
                ", orderBillCode='" + orderBillCode + '\'' +
                ", orderUserUuid='" + orderUserUuid + '\'' +
                ", productType='" + productType + '\'' +
                ", orderAmount=" + orderAmount +
                ", orderCreateTime=" + orderCreateTime +
                '}';
    }
}