package cn.zjhf.kingold.user.persistence.dao;

import cn.zjhf.kingold.user.entity.UserStatusLog;
import org.springframework.stereotype.Repository;

/**
 * @author lutiehua
 * @date 2018-03-16
 *
 */
@Repository
public interface UserStatusLogMapper {

    /**
     * 添加
     *
     * @param userStatusLog
     * @return
     */
    int insert(UserStatusLog userStatusLog);

    /**
     * 查询
     *
     * @param billOrderCode
     * @return
     */
    UserStatusLog queryByOrderBillCode(String billOrderCode);

    /**
     * 删除
     *
     * @return
     */
    int deleteByOrderBillCode(String billOrderCode);
}