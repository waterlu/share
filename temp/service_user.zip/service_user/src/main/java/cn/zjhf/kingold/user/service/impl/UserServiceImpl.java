package cn.zjhf.kingold.user.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.user.constant.*;
import cn.zjhf.kingold.user.dto.UpdateTradeStatusDTO;
import cn.zjhf.kingold.user.entity.*;
import cn.zjhf.kingold.user.persistence.dao.*;
import cn.zjhf.kingold.user.persistence.mq.message.UserBindCardMessage;
import cn.zjhf.kingold.user.persistence.mq.message.UserMessage;
import cn.zjhf.kingold.user.persistence.mq.producer.UserAuthProducer;
import cn.zjhf.kingold.user.persistence.mq.producer.UserBindCardProducer;
import cn.zjhf.kingold.user.persistence.mq.producer.UserRegisterProducer;
import cn.zjhf.kingold.user.service.IUserOauthService;
import cn.zjhf.kingold.user.service.IUserService;
import cn.zjhf.kingold.user.service.IUserTransactionService;
import cn.zjhf.kingold.user.task.InvestorLoginInfoUpdateTask;
import cn.zjhf.kingold.user.utils.*;
import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import com.google.common.collect.ImmutableBiMap;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * Created by wangxun on 2016/11/04.
 * Copyright by zjinv
 */
@Service
public class UserServiceImpl implements IUserService {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private UserStatusLogMapper userStatusLogMapper;

    @Autowired
    private InvestorMapper investorMapper;
    @Autowired
    private UserTokenMapper userTokenMapper;
    @Autowired
    private UserInvestorUnionMapper userInvestorUnionMapper;
    @Autowired
    private InvestorRelationMapper investorRelationMapper;
    @Autowired
    private UserIssuerUnionMapper userIssuerUnionMapper;
    @Autowired
    StringRedisTemplate stringRedisTemplate;
    @Autowired
    private IUserTransactionService userTransactionService;
    @Autowired
    private InvestorLoginInfoUpdateTask investorLoginInfoUpdateTask;
    @Autowired
    private UserCertificationMapper userCertificationMapper;
    @Autowired
    private IssuerMapper issuerMapper;
    @Autowired
    private UserAuthProducer userAuthProducer;
    @Autowired
    private UserBindCardProducer userBindCardProducer;
    @Autowired
    private UserRegisterProducer userRegisterProducer;
    @Autowired
    private EnterpriseInvestorMapper enterpriseInvestorMapper;

    @Autowired
    private IUserOauthService userOauthService;

    @Value("${system.run.model}")
    public String runModel;
    @Value("${app.admin.verify.code}")
    public String adminVerifyCode;
    private final static Logger LOGGER = LoggerFactory.getLogger(UserServiceImpl.class);


    private final static int ID_CARD_MIN_LENGTH  = 15;
    private final static int PAY_PWD_ERROR_MAX_TIME = 6;
    private final static int ONE_HOUR_SECOND = 60 * 60;
    private final static String  REDIS_SMS_REGIST_CODE_KEY = "bussType_0";
    private final static String REDIS_SMS_RESET_LOGIN_PASSWORD_CODE_KEY = "bussType_1";
    private final static String REDIS_SMS_RESET_PAY_PASSWORD_CODE_KEY = "bussType_2";
    private final static String REDIS_SMS_LOGIN_CODE_KEY = "bussType_4";
    private final static String REDIS_CAMP_LOGIN_CODE_KEY = "bussType_5";
    private final static String REDIS_OPEN_LOGIN_CODE_KEY = "bussType_6";


    @Override
    public Map getInvestorWithFilter(Map<String, Object> params) throws BusinessException {
        Map<String, Object> ui = getUser(params, false);
        Map resultMap = UserPropertiesUtils.buildUserData(ui);
        return resultMap;
    }

    @Override
    public Map getUserByPhone(Map<String, Object> params) throws BusinessException {
        String userUuid = isPhoneExist(params.get(InvestorKeyConstants.INVESTOR_MOBILE_STR).toString());
        if (StringUtils.isBlank(userUuid)) {
            throw new BusinessException(UserParamMsg.NOT_FIND_USER_CODE, UserParamMsg.NOT_FIND_USER, true);
        }
        params.put(UserKeyConstants.USER_UUID_STR, userUuid);
        Map<String, Object> ui = getUser(params, false);
        Map resultMap = UserPropertiesUtils.buildUserData(ui);
        return resultMap;
    }

    @Override
    public Map getInvestorWithFreezing(Map<String, Object> params) throws BusinessException {
        Map<String, Object> ui = getUser(params, true);
        Map resultMap = UserPropertiesUtils.buildUserData(ui);
        return resultMap;
    }

    @Override
    public Map getIssuerWithFilter(Map<String, Object> params) throws BusinessException {
        Map<String, Object> ui = getUser(params, true);
        Map resultMap = UserPropertiesUtils.buildUserData(ui);
        return resultMap;
    }

    @Override
    public String getInvestorRisk(String userUuid) throws BusinessException {
        Map<String, Object> params = new HashMap<>();
        params.put("userUuid", userUuid);
        Map<String, Object> ui = getUser(params, true);
        if (ui.get(InvestorKeyConstants.INVESTOR_RISK_ANSWER_STR) == null || (Integer)ui.get(InvestorKeyConstants.INVESTOR_RISK_VERSION_INT) == 1) {
            return "";
        }
        String answer = ui.get(InvestorKeyConstants.INVESTOR_RISK_ANSWER_STR).toString();
        return answer.replace("$$", ",");

    }

    @Override
    public List<String> getInvestorMobilePhoneListWithFilter(Map<String, Object> params) throws BusinessException {
        List<String> allUuids = params.get("userUuids") == null ? null : (List<String>)params.get("userUuids");
        List<Map> ui = userInvestorUnionMapper.getList(params);
        Set<String> investorUuids = new HashSet<>();
        for (Map objectMap : ui) {
            investorUuids.add(objectMap.get(InvestorKeyConstants.USER_UUID_STR).toString());
        }
        List<String> enterpriseUuids = new ArrayList<>();
        if(allUuids !=null && allUuids.size() > 0){
            for (String uuid: allUuids) {
                if (!investorUuids.contains(uuid)) {
                    enterpriseUuids.add(uuid);
                }
            }
        }
        if (enterpriseUuids.size() > 0) {
            List<Map> enterpriseInfo = fillEnterpriseInfo(enterpriseUuids);
            ui.addAll(enterpriseInfo);
        }
        List<String> resultList = new ArrayList<>();
        for (Map objectMap : ui) {
            String mobilePhone = "";
            Map resultMap = UserPropertiesUtils.buildUserData(objectMap);
            if (resultMap.containsKey(InvestorKeyConstants.INVESTOR_MOBILE_STR)) {
                mobilePhone = (String) resultMap.get(InvestorKeyConstants.INVESTOR_MOBILE_STR);
            } else if (resultMap.containsKey(EnterpriseKeyConstants.LEGAL_PERSON_MOBILE_STR)) {
                mobilePhone = (String) resultMap.get(EnterpriseKeyConstants.LEGAL_PERSON_MOBILE_STR);
            }

            if((mobilePhone != null) && (mobilePhone.trim().length()>0)) {
                resultList.add(mobilePhone);
            }
        }
        return resultList;
    }

    @Override
    public List<Map> getInvestorListWithFilter(Map<String, Object> params) throws BusinessException {
        Integer pageNo = params.get("pageNo") == null ? 1 : Integer.valueOf(params.get("pageNo").toString());
        Integer pageSize = params.get("pageSize") == null ? 20 : Integer.valueOf(params.get("pageSize").toString());
        params.put("offset", (pageNo-1) * pageSize);
        params.put("limit", pageSize);
        List<String> allUuids = params.get("userUuids") == null ? null : (List<String>)params.get("userUuids");
        List<Map> ui = userInvestorUnionMapper.getList(params);
        Set<String> investorUuids = new HashSet<>();
        for (Map objectMap : ui) {
            investorUuids.add(objectMap.get(InvestorKeyConstants.USER_UUID_STR).toString());
        }
        List<String> enterpriseUuids = new ArrayList<>();
        if(allUuids !=null && allUuids.size() > 0){
            for (String uuid: allUuids) {
                if (!investorUuids.contains(uuid)) {
                    enterpriseUuids.add(uuid);
                }
            }
        }
        if (enterpriseUuids.size() > 0) {
            List<Map> enterpriseInfo = fillEnterpriseInfo(enterpriseUuids);
            ui.addAll(enterpriseInfo);
        }
        List<Map> resultList = new ArrayList<>();
        for (Map objectMap : ui) {
            Map resultMap = UserPropertiesUtils.buildUserData(objectMap);
            if (resultMap.containsKey(InvestorKeyConstants.INVESTOR_MOBILE_STR)) {
                resultMap.put("mobile", resultMap.get(InvestorKeyConstants.INVESTOR_MOBILE_STR));
            } else if (resultMap.containsKey(EnterpriseKeyConstants.LEGAL_PERSON_MOBILE_STR)) {
                resultMap.put("mobile", resultMap.get(EnterpriseKeyConstants.LEGAL_PERSON_MOBILE_STR));
            }
            resultList.add(resultMap);
        }
        return resultList;
    }

    @Override
    public int getListCount(Map<String, Object> params) throws BusinessException {
        return userInvestorUnionMapper.countList(params);
    }

    @Override
    public Map getUserByUserId(String userId) throws BusinessException {
        Map<String, Object> params = new HashMap<>();
        params.put(UserKeyConstants.USER_ID_LONG,userId);
        Map<String, Object> user = getUser(params, true);
        Map resultMap = UserPropertiesUtils.buildUserData(user);
        return resultMap;
    }


    @Override
    public List<Map> getIssuerListWithFilter(Map<String, Object> params) throws BusinessException {
        if (params.get(IssuerKeyConstants.USER_ISSUER_NAME_STR) != null) {
            String issuerName = params.get(IssuerKeyConstants.USER_ISSUER_NAME_STR).toString();
            //模糊查询拼装
            params.put(IssuerKeyConstants.USER_ISSUER_NAME_STR, "%" + issuerName + "%");
        }
        List<Map> ui = userIssuerUnionMapper.getList(params);
        List<Map> resultList = new ArrayList<>();
        for (Map objectMap : ui) {
            Map resultMap = UserPropertiesUtils.buildUserData(objectMap);
            resultList.add(resultMap);
        }
        return resultList;
    }

    @Override
    public int insert(Map<String, Object> params) throws BusinessException {
        String userPhone = (String) params.get("userPhone");
        if (StringUtils.isNotBlank(userPhone)) {
            Map paramTemp = new HashMap();
            paramTemp.put("userPhone",userPhone);
            if(null != userMapper.get(paramTemp)){
                throw new BusinessException(UserParamMsg.REGISTER_PHONE_IS_EXIST_CODE, UserParamMsg.REGISTER_PHONE_IS_EXIST,true);
            }
        }
        params.put("userUuid", UUID.randomUUID().toString().replace("-", ""));
        return userMapper.insert(params);
    }


    @Override
    public int update( Map params) throws BusinessException {
        if( StringUtils.isBlank((String)params.get(UserKeyConstants.USER_UUID_STR)) ||
                params.containsKey(UserKeyConstants.USER_VERIFY_STATUS_INT)) {
            Map user = getUser(params, false);
            params.put(UserKeyConstants.USER_UUID_STR, user.get(UserKeyConstants.USER_UUID_STR));
            if ((int)user.get(UserKeyConstants.USER_VERIFY_STATUS_INT) < UserVerifyStatus.USER_AUTH_SUCCESS.getStatus() &&
                    params.containsKey(UserKeyConstants.USER_VERIFY_STATUS_INT) &&
                    MapParamUtils.getIntInMap(params,UserKeyConstants.USER_VERIFY_STATUS_INT) == UserVerifyStatus.USER_AUTH_SUCCESS.getStatus()) {
                UserMessage userMessage = new UserMessage();
                userMessage.setInvestorMobile(user.get(UserKeyConstants.USER_LOGIN_NAME_STR).toString());
                userMessage.setUserUuid(user.get(UserKeyConstants.USER_UUID_STR).toString());
                userMessage.setMerchantNum(MapParamUtils.getStringInMap(params,"merchantNum"));
                userAuthProducer.send(userMessage);
            }
        }
        List<Map> userTokenList = userTokenMapper.getList(params);
        userTokenList.forEach(userToken -> refreshTokenInfo((String) userToken.get("token"), params));
        return userTransactionService.updateUserTransaction(params);
    }

    @Override
    public Map login(Map mapParams) throws BusinessException {
        Map userMap = getUserAndCheck(mapParams, false);

        Map investorParams = new HashMap();
        investorParams.put("userUuid",mapParams.get("userUuid"));

        Map investorResult = investorMapper.get(mapParams);
        if(MapUtils.isEmpty(userMap)) {
            throw new BusinessException(UserParamMsg.NOT_FIND_USER_CODE, UserParamMsg.NOT_FIND_USER, true);
        }
        int userType = (Integer) userMap.get(UserKeyConstants.USER_TYPE_BYTE);

        mapParams.put(UserKeyConstants.USER_UUID_STR, userMap.get(UserKeyConstants.USER_UUID_STR));

        //判断密码是否一致
        String paramUserPassword = EncryptUtils.encryptSalt((String) mapParams.get(UserKeyConstants.USER_LOGIN_PASSWORD_STR));
        //判断密码是不是星耀密码。
        String xyUserPassword = (String) mapParams.get(UserKeyConstants.USER_LOGIN_PASSWORD_STR);
        if (MapParamUtils.getStringInMap(userMap,UserKeyConstants.USER_LOGIN_PASSWORD_STR).length() == 56) {
            String inputPassword = HexSHA1.hex_sha1(xyUserPassword);
            String dbPassword = MapParamUtils.getStringInMap(userMap,UserKeyConstants.USER_LOGIN_PASSWORD_STR);
            if (!validatePassword(inputPassword,dbPassword)) {
                throw new BusinessException(UserParamMsg.LONGIN_PW_NOT_MATCH_CODE, UserParamMsg.LONGIN_PW_NOT_MATCH, true);
            }
        }else {
            //判断密码是否一致,密码是不是金疙瘩用户密码。
            if (!userMap.get(UserKeyConstants.USER_LOGIN_PASSWORD_STR).equals(paramUserPassword)) {
                throw new BusinessException(UserParamMsg.LONGIN_PW_NOT_MATCH_CODE, UserParamMsg.LONGIN_PW_NOT_MATCH, true);
            }
        }


        mapParams.put(UserKeyConstants.USER_UUID_STR, userMap.get(UserKeyConstants.USER_UUID_STR));
        mapParams.put("loginMethod",LoginMethodEnum.PASSWORD.getStatus());

        //增加第三方登录绑定手机号
        if(mapParams.containsKey("oauthId")){
            mapParams.put("loginMethod", "1".equals(MapParamUtils.getStringInMap(mapParams, "oauthType"))
                    ? LoginMethodEnum.THIRD_WECHAT.getStatus() : LoginMethodEnum.THIRD_WEIBO.getStatus());

            mapParams.put("userMobile",MapParamUtils.getStringInMap(userMap,"userLoginName"));
            userOauthService.bind(mapParams);
        }

        investorLoginInfoUpdateTask.asyncUpdateLoginInfo(mapParams);
        userMap.putAll(mapParams);
        Map resultMap = UserPropertiesUtils.buildUserData(userMap);
        return resultMap;
    }

    @Override
    public Map smsLogin(LoginParam loginParam) throws BusinessException {
        Map<String, Object> param = new HashMap<>();
        param.put(UserKeyConstants.USER_LOGIN_NAME_STR, loginParam.getInvestorMobile());
        Map userMap = getUserAndCheck(param, false);
        //3. 判断验证码是否正确
        if (!isSmsVerify(loginParam.getInvestorMobile(), loginParam.getCallSystemID(),loginParam.getSmsCode(), REDIS_SMS_LOGIN_CODE_KEY)) {
            throw new BusinessException(UserParamMsg.VERIFY_CODE_ERROR_CODE, UserParamMsg.VERIFY_CODE_ERROR, true);
        }
        loginParam.setLoginMethod(LoginMethodEnum.SMS.getStatus());
        Map<String, Object> loginMap = MapParamUtils.obj2Map(loginParam);
        investorLoginInfoUpdateTask.asyncUpdateLoginInfo(loginMap);
        Map resultMap = UserPropertiesUtils.buildUserData(userMap);
        return resultMap;
    }

    @Override
    public Integer exist(String idCard) throws BusinessException {
        Integer result = investorMapper.count(ImmutableBiMap.of("investorIdCardNo",idCard));
        return result > 0 ? 1 : 0;
    }


    /**
     * 1.判断验证码是否正确
     * 2.查找用户信息
     * @param loginParam
     * @return
     * @throws BusinessException
     */
    @Override
    public Map campRegistLogin(LoginRegiestParam loginParam) throws BusinessException {
        Map<String, Object> loginMap = MapParamUtils.obj2Map(loginParam);
        loginMap.put(UserKeyConstants.USER_LOGIN_NAME_STR, loginParam.getInvestorMobile());
        if (!isCampVerify(loginParam.getInvestorMobile(), loginParam.getCallSystemID(),loginParam.getCampCode(), REDIS_CAMP_LOGIN_CODE_KEY)) {
            throw new BusinessException(UserParamMsg.VERIFY_CODE_ERROR_CODE, UserParamMsg.VERIFY_CODE_ERROR, true);
        }
        Map userMap = getUserForCamp(loginMap, false);
        loginMap.put("userUuid",MapParamUtils.getStringInMap(userMap,"userUuid"));
        loginMap.put("loginMethod",  LoginMethodEnum.CAMP_WEIBO.getStatus());
        investorLoginInfoUpdateTask.asyncUpdateLoginInfo(loginMap);
        Map resultMap = UserPropertiesUtils.buildUserData(userMap);
        return resultMap;
    }

    @Override
    public Map thirdLogin(Map params) throws BusinessException {
        params.put("status", 1);
        List<UserOauth> userOauthList = userOauthService.getList(params);
        if (userOauthList.size() == 0) {
            throw new BusinessException(UserParamMsg.THIRD_NOT_BIND_MOBILE_CODE, UserParamMsg.THIRD_NOT_BIND_MOBILE_MSG, true);
        }
        Map userParam = new HashMap();
        userParam.put("userUuid", userOauthList.get(0).getUserUuid());
        Map userMap = getUser(userParam, false);

        params.put("userUuid",MapParamUtils.getStringInMap(userMap,"userUuid"));
        params.put("loginMethod", "1".equals(MapParamUtils.getStringInMap(params, "oauthType"))
                ? LoginMethodEnum.THIRD_WECHAT.getStatus() : LoginMethodEnum.THIRD_WEIBO.getStatus());
        investorLoginInfoUpdateTask.asyncUpdateLoginInfo(params);
        Map resultMap = UserPropertiesUtils.buildUserData(userMap);
        return resultMap;
    }

    /**
     * 验证密码
     * @param plainPassword 明文密码
     * @param password 密文密码
     * @return 验证成功返回true
     */
    public static boolean validatePassword(String plainPassword, String password) {

        String HASH_ALGORITHM = "SHA-1";
        int HASH_INTERATIONS = 1024;
        int SALT_SIZE = 8;
        String plain = Encodes.unescapeHtml(plainPassword);
        byte[] salt = Encodes.decodeHex(password.substring(0,16));
        byte[] hashPassword = Digests.sha1(plain.getBytes(), salt, HASH_INTERATIONS);
        return password.equals(Encodes.encodeHex(salt)+Encodes.encodeHex(hashPassword));
    }


    /**
     * 1. 判断手机号是否存在
     * 2. 判断邀请人手机是否存在
     * 3. 写入注册信息
     *
     * 运营后台创建用户
     *
     * @param mapParams
     * @return
     * @throws BusinessException
     */
    @Override
    public Map create(Map<String, Object> mapParams) throws BusinessException {
        // 判断手机号是否存在
        Map regParam = new HashMap();
        regParam.put(InvestorKeyConstants.INVESTOR_MOBILE_STR, mapParams.get(InvestorKeyConstants.INVESTOR_MOBILE_STR));
        Map investorMap = investorMapper.get(regParam);
        Map regUserParam = new HashMap();
        regUserParam.put(InvestorKeyConstants.INVESTOR_MOBILE_STR, mapParams.get(InvestorKeyConstants.INVESTOR_MOBILE_STR));
        Map userMap = userMapper.get(regUserParam);
        boolean isUserExist =( userMap != null);
        boolean isInvestorExist =( investorMap != null);
        if (isUserExist && isInvestorExist ) {//注册过user和注册过advisor
            throw new BusinessException(UserParamMsg.REGISTER_PHONE_IS_EXIST_CODE, UserParamMsg.REGISTER_PHONE_IS_EXIST, true);
        }
        String userUuid = UUID.randomUUID().toString().replace("-", "");
        if(isUserExist) {
            userUuid =  MapParamUtils.getStringInMap(userMap,"userUuid");
        }
        mapParams.put("userUuid", userUuid);
         // 判断邀请人手机是否存在
        if (mapParams.get("inviterPhone") != null) {
            Map inviteParam = new HashMap();
            inviteParam.put(InvestorKeyConstants.INVESTOR_MOBILE_STR, mapParams.get("inviterPhone"));
            Map inviteMap = investorMapper.get(inviteParam);
            if (inviteMap == null) {
                throw new BusinessException(UserParamMsg.INVITER_PHONE_NOT_EXIST_CODE, UserParamMsg.INVITER_PHONE_NOT_EXIST, true);
            }
            mapParams.put(InvestorKeyConstants.INVITER_UUID, inviteMap.get(InvestorKeyConstants.USER_UUID_STR));
        }
        //3. 写入注册信息
        String loginName = (String)mapParams.get(UserKeyConstants.USER_LOGIN_NAME_STR);
        mapParams.put(UserKeyConstants.USER_UUID_STR, userUuid);
        mapParams.put(UserKeyConstants.USER_LOGIN_NAME_STR, StringUtils.isEmpty(loginName) ?
                mapParams.get(InvestorKeyConstants.INVESTOR_MOBILE_STR) : loginName);

        //密码加盐
        String userPassword = (String) mapParams.get(UserKeyConstants.USER_LOGIN_PASSWORD_STR);
        userPassword = EncryptUtils.encryptSalt(userPassword);
        mapParams.put(UserKeyConstants.USER_LOGIN_PASSWORD_STR, userPassword);
        userTransactionService.insertUserTransaction(mapParams,isUserExist);//插入投资人和用户表信息
        return getInvestorWithFilter(mapParams);
    }

    /**
     * 1. 判断手机号是否存在
     * 2. 判断邀请人手机是否存在
     * 3. 判断验证码是否正确
     * 4. 写入注册信息
     *
     * @param mapParams
     * @return
     * @throws BusinessException
     */
    @Override
    public Map regist(Map<String, Object> mapParams) throws BusinessException {
        // 判断手机号是否存在
        Map regParam = new HashMap();
        regParam.put(InvestorKeyConstants.INVESTOR_MOBILE_STR, mapParams.get(InvestorKeyConstants.INVESTOR_MOBILE_STR));
        Map investorMap = investorMapper.get(regParam);

        Map regUserParam = new HashMap();
        regUserParam.put(InvestorKeyConstants.INVESTOR_MOBILE_STR, mapParams.get(InvestorKeyConstants.INVESTOR_MOBILE_STR));
        Map userMap = userMapper.get(regUserParam);
        boolean isUserExist =( userMap != null);
        boolean isInvestorExist =( investorMap != null);
        if (isUserExist && isInvestorExist ) {//注册过user和注册过advisor
            throw new BusinessException(UserParamMsg.REGISTER_PHONE_IS_EXIST_CODE, UserParamMsg.REGISTER_PHONE_IS_EXIST, true);
        }
        String userUuid = UUID.randomUUID().toString().replace("-", "");
        if(isUserExist) {
            userUuid =  MapParamUtils.getStringInMap(userMap,"userUuid");
        }
        mapParams.put("userUuid", userUuid);

        //2. 邀请人逻辑处理
        boolean hasInviter = false;
        String inviterUuid = "";
        if (mapParams.get("inviterPhone") != null) {
            Map inviteParam = new HashMap();
            inviteParam.put(InvestorKeyConstants.INVESTOR_MOBILE_STR, mapParams.get("inviterPhone"));
            Map inviteMap = investorMapper.get(inviteParam);
            if (inviteMap == null) {
                throw new BusinessException(UserParamMsg.INVITER_PHONE_NOT_EXIST_CODE, UserParamMsg.INVITER_PHONE_NOT_EXIST, true);
            }
            hasInviter = true;
            int inviterType = (int)inviteMap.get(InvestorKeyConstants.INVESTOR_TYPE_BYTE);
            inviterUuid = (String)inviteMap.get(InvestorKeyConstants.USER_UUID_STR);
            mapParams.put(InvestorKeyConstants.INVITER_UUID, inviterUuid);
            mapParams.put(InvestorRelationKeyConstants.INVITER_LEVEL_ONE_UUID_STR, inviterUuid);

            if (inviterType == InvestorType.PROFESSION_INVESTOR) {
                mapParams.put(InvestorRelationKeyConstants.TOP_UUID_STR, inviterUuid);
                mapParams.put(InvestorRelationKeyConstants.TOP_ORGANIZATION_PATH_STR, inviteMap.get(InvestorKeyConstants.INVESTOR_ORGANIZATION_PATH_STR));
                mapParams.put(InvestorRelationKeyConstants.TOP_ORGANIZATION_UUID_STR, inviteMap.get(InvestorKeyConstants.INVESTOR_ORGANIZATION_UUID_STR));
            } else {
                doCommon(mapParams, inviterUuid);
            }
        }
        //3. 判断验证码是否正确
        if (!isSmsVerify((String) mapParams.get(InvestorKeyConstants.INVESTOR_MOBILE_STR), (String) mapParams.get("callSystemID"),
                (String) mapParams.get("verifyCode"), REDIS_SMS_REGIST_CODE_KEY)) {
            throw new BusinessException(UserParamMsg.VERIFY_CODE_ERROR_CODE, UserParamMsg.VERIFY_CODE_ERROR, true);
        }
        //4. 写入注册信息
        String loginName = (String)mapParams.get(UserKeyConstants.USER_LOGIN_NAME_STR);
        mapParams.put(UserKeyConstants.USER_UUID_STR, userUuid);
        mapParams.put(UserKeyConstants.USER_LOGIN_NAME_STR, StringUtils.isEmpty(loginName) ?
                mapParams.get(InvestorKeyConstants.INVESTOR_MOBILE_STR) : loginName);

        //密码加盐
        String userPassword = (String) mapParams.get(UserKeyConstants.USER_LOGIN_PASSWORD_STR);
        userPassword = EncryptUtils.encryptSalt(userPassword);
        mapParams.put(UserKeyConstants.USER_LOGIN_PASSWORD_STR, userPassword);
        //插入投资人和用户表信息
        userTransactionService.insertUserTransaction(mapParams,isUserExist);
        UserMessage userMessage = new UserMessage();
        userMessage.setInvestorMobile(mapParams.get(InvestorKeyConstants.INVESTOR_MOBILE_STR).toString());
        userMessage.setUserUuid(userUuid);
        userMessage.setRegisterChannelCode(MapParamUtils.getStringInMap(mapParams,"registerChannelCode"));
        if(StringUtils.isNotBlank(inviterUuid)){
            userMessage.setInviterUuid(inviterUuid);
        }
        userRegisterProducer.send(userMessage);

        //增加第三方登录绑定手机号
        if(mapParams.containsKey("oauthId")){
            mapParams.put("userMobile",MapParamUtils.getStringInMap(mapParams,"investorMobile"));
            userOauthService.bind(mapParams);
        }
        return getInvestorWithFilter(mapParams);
    }


    /**
     * 活动平台写入注册信息,兼容星耀用户登录
     * @param mapParams
     * @return
     * @throws BusinessException
     */
    @Override
    public Map campUserRegist(Map<String, Object> mapParams,boolean isUserExist) throws BusinessException {
        String userUuid = "";
        if(isUserExist){
            userUuid = (String)mapParams.get(UserKeyConstants.USER_UUID_STR);
        }else{
            userUuid = UUID.randomUUID().toString().replace("-", "");
        }
        mapParams.put("userUuid", userUuid);

        //邀请人逻辑处理
        boolean hasInviter = false;
        String inviterUuid = "";
        if (mapParams.get("inviterPhone") != null) {
            Map inviteParam = new HashMap();
            inviteParam.put(InvestorKeyConstants.INVESTOR_MOBILE_STR, mapParams.get("inviterPhone"));
            Map inviteMap = investorMapper.get(inviteParam);
            if (inviteMap == null) {
                throw new BusinessException(UserParamMsg.INVITER_PHONE_NOT_EXIST_CODE, UserParamMsg.INVITER_PHONE_NOT_EXIST, true);
            }
            hasInviter = true;
            int inviterType = (int)inviteMap.get(InvestorKeyConstants.INVESTOR_TYPE_BYTE);
            inviterUuid = (String)inviteMap.get(InvestorKeyConstants.USER_UUID_STR);
            mapParams.put(InvestorKeyConstants.INVITER_UUID, inviterUuid);
            mapParams.put(InvestorRelationKeyConstants.INVITER_LEVEL_ONE_UUID_STR, inviterUuid);

            if (inviterType == InvestorType.PROFESSION_INVESTOR) {
                mapParams.put(InvestorRelationKeyConstants.TOP_UUID_STR, inviterUuid);
                mapParams.put(InvestorRelationKeyConstants.TOP_ORGANIZATION_PATH_STR, inviteMap.get(InvestorKeyConstants.INVESTOR_ORGANIZATION_PATH_STR));
                mapParams.put(InvestorRelationKeyConstants.TOP_ORGANIZATION_UUID_STR, inviteMap.get(InvestorKeyConstants.INVESTOR_ORGANIZATION_UUID_STR));
            } else {
                doCommon(mapParams, inviterUuid);
            }
        }

        //写入注册信息
        String loginName = (String)mapParams.get(UserKeyConstants.USER_LOGIN_NAME_STR);
        mapParams.put(UserKeyConstants.USER_UUID_STR, userUuid);
        mapParams.put(UserKeyConstants.USER_LOGIN_NAME_STR, StringUtils.isEmpty(loginName) ?
                mapParams.get(InvestorKeyConstants.INVESTOR_MOBILE_STR) : loginName);

        //密码加盐(随机生成6位密码（数字+字母）)
        String userPassword = DataUtils.createRandomCharData(6);
        userPassword = EncryptUtils.encryptSalt(userPassword);
        mapParams.put(UserKeyConstants.USER_LOGIN_PASSWORD_STR, userPassword);

        mapParams.put("registerMerchantNum",mapParams.get("loginMerchantNum"));

        //插入投资人和用户表信息
        userTransactionService.insertUserTransaction(mapParams,isUserExist);
        UserMessage userMessage = new UserMessage();
        userMessage.setInvestorMobile(mapParams.get(InvestorKeyConstants.INVESTOR_MOBILE_STR).toString());
        userMessage.setUserUuid(userUuid);
        if(StringUtils.isNotBlank(inviterUuid)){
            userMessage.setInviterUuid(inviterUuid);
        }
        userMessage.setRegisterChannelCode(MapParamUtils.getStringInMap(mapParams,"registerChannelCode"));
        userRegisterProducer.send(userMessage);

        //增加第三方登录绑定手机号
        if(mapParams.containsKey("oauthId")){
            mapParams.put("userMobile",MapParamUtils.getStringInMap(mapParams,"investorMobile"));
            userOauthService.bind(mapParams);
        }
        Map resultMap = getInvestorWithFilter(mapParams);
        //操作标识
        resultMap.put("operFlag","regist");
        return resultMap;
    }

    @Override
    public Map openRegisterLogin(Map<String, Object> loginMap) throws BusinessException {
        loginMap.put(UserKeyConstants.USER_LOGIN_NAME_STR, MapParamUtils.getStringInMap(loginMap,"investorMobile"));
        if (!isOpenVerify(MapParamUtils.getStringInMap(loginMap, "investorMobile"), MapParamUtils.getStringInMap
                (loginMap, "callSystemID"), MapParamUtils.getStringInMap(loginMap, "verifyCode"),
                REDIS_OPEN_LOGIN_CODE_KEY)) {
            throw new BusinessException(UserParamMsg.VERIFY_CODE_ERROR_CODE, UserParamMsg.VERIFY_CODE_ERROR, true);
        }
        Map userMap = getUserForOpen(loginMap, false);
        loginMap.put("userUuid",MapParamUtils.getStringInMap(userMap,"userUuid"));
        loginMap.put("loginMethod",  LoginMethodEnum.OPEN_PLATFORM.getStatus());
        investorLoginInfoUpdateTask.asyncUpdateLoginInfo(loginMap);
        Map resultMap = UserPropertiesUtils.buildUserData(userMap);
        return resultMap;
    }

    @Override
    public Map getUserForOpen(Map<String, Object> params, boolean withFreezing) throws BusinessException {
        Map userMap = userMapper.get(params);
        Map regParam = new HashMap();
        regParam.put(InvestorKeyConstants.INVESTOR_MOBILE_STR, params.get(InvestorKeyConstants.INVESTOR_MOBILE_STR));
        Map investorMap = investorMapper.get(params);
        boolean isUserExist = ( userMap != null);
        boolean isInvestorExist = ( investorMap != null);
        if ( !isUserExist && !isInvestorExist ) {
            //向数据库表新增此用户，调用注册接口
            return this.openUserRegist(params,false);
        }else if( isUserExist && !isInvestorExist){
            //向数据库表新增此用户，调用注册接口
            params.put(UserKeyConstants.USER_UUID_STR, userMap.get(UserKeyConstants.USER_UUID_STR));
            return this.openUserRegist(params,true);
        }else{
            //冻结用户
            if (!withFreezing && UserStatusConstants.USER_STATUS_FREEZE.equals(userMap.get(UserKeyConstants
                    .USER_STATUS_INT).toString())) {
                throw new BusinessException(UserParamMsg.USER_IS_FREEZING_CODE, UserParamMsg.USER_IS_FREEZING, true);
            }
            int userType = (Integer) userMap.get(UserKeyConstants.USER_TYPE_BYTE);
            params.put(UserKeyConstants.USER_UUID_STR, userMap.get(UserKeyConstants.USER_UUID_STR));
            Map<String, Object> son;
            if (userType == UserTypeEnum.USER_INVESTOR_TYPE.getUserType()) {
                son = investorMapper.get(params);
                if (son == null) {
                    throw new BusinessException(UserParamMsg.NOT_FIND_USER_CODE, UserParamMsg.NOT_FIND_USER, true);
                } else {
                    son.put("mobile", son.get(InvestorKeyConstants.INVESTOR_MOBILE_STR));
                }
            } else if (userType == UserTypeEnum.USER_ISSUER_TYPE.getUserType()) {
                son = issuerMapper.get(params);
                son.put("mobile", son.get(IssuerKeyConstants.LEGAL_PERSON_MOBILE_STR));
            } else {
                son = enterpriseInvestorMapper.get(params);
                son.put("mobile", son.get(EnterpriseKeyConstants.LEGAL_PERSON_MOBILE_STR));
            }
            userMap.putAll(son);
            int isSetPayPassword = userMap.get(UserKeyConstants.USER_PAY_PASSWORD_STR) == null ? 0 : 1;
            userMap.put("isSetPayPassword", isSetPayPassword);
            userMap.put("operFlag", "login");
            return userMap;
        }
    }


    /**
     * 开放平台写入注册信息,兼容星耀用户登录
     * @param params
     * @return
     * @throws BusinessException
     */
    private Map openUserRegist(Map<String, Object> params,boolean isUserExist) throws BusinessException {
        String userUuid = "";
        if (isUserExist) {
            userUuid = (String) params.get(UserKeyConstants.USER_UUID_STR);
        } else {
            userUuid = UUID.randomUUID().toString().replace("-", "");
        }
        params.put("userUuid", userUuid);

        //邀请人逻辑处理
        boolean hasInviter = false;
        String inviterUuid = "";
        if (params.get("inviterPhone") != null) {
            Map inviteParam = new HashMap();
            inviteParam.put(InvestorKeyConstants.INVESTOR_MOBILE_STR, params.get("inviterPhone"));
            Map inviteMap = investorMapper.get(inviteParam);
            if (inviteMap == null) {
                throw new BusinessException(UserParamMsg.INVITER_PHONE_NOT_EXIST_CODE, UserParamMsg.INVITER_PHONE_NOT_EXIST, true);
            }
            hasInviter = true;
            int inviterType = (int)inviteMap.get(InvestorKeyConstants.INVESTOR_TYPE_BYTE);
            inviterUuid = (String)inviteMap.get(InvestorKeyConstants.USER_UUID_STR);
            params.put(InvestorRelationKeyConstants.INVITER_LEVEL_ONE_UUID_STR, inviterUuid);
            params.put(InvestorKeyConstants.INVITER_UUID, inviterUuid);

            if (inviterType == InvestorType.PROFESSION_INVESTOR) {
                params.put(InvestorRelationKeyConstants.TOP_UUID_STR, inviterUuid);
                params.put(InvestorRelationKeyConstants.TOP_ORGANIZATION_UUID_STR, inviteMap.get(InvestorKeyConstants.INVESTOR_ORGANIZATION_UUID_STR));
                params.put(InvestorRelationKeyConstants.TOP_ORGANIZATION_PATH_STR, inviteMap.get(InvestorKeyConstants.INVESTOR_ORGANIZATION_PATH_STR));
            } else {
                doCommon(params, inviterUuid);
            }
        }

        //写入注册信息
        String loginName = (String)params.get(UserKeyConstants.USER_LOGIN_NAME_STR);
        params.put(UserKeyConstants.USER_UUID_STR, userUuid);
        params.put(UserKeyConstants.USER_LOGIN_NAME_STR, StringUtils.isEmpty(loginName) ?
                params.get(InvestorKeyConstants.INVESTOR_MOBILE_STR) : loginName);

        //密码加盐(随机生成6位密码（数字+字母）)
        String userPassword = DataUtils.createRandomCharData(6);
        userPassword = EncryptUtils.encryptSalt(userPassword);
        params.put(UserKeyConstants.USER_LOGIN_PASSWORD_STR, userPassword);

        params.put("registerMerchantNum",params.get("loginMerchantNum"));

        //插入投资人和用户表信息
        userTransactionService.insertUserTransaction(params,isUserExist);

        UserMessage userMessage = new UserMessage();
        userMessage.setInvestorMobile(params.get(InvestorKeyConstants.INVESTOR_MOBILE_STR).toString());
        userMessage.setUserUuid(userUuid);
        if(StringUtils.isNotBlank(inviterUuid)){
            userMessage.setInviterUuid(inviterUuid);
        }
        userMessage.setRegisterChannelCode(MapParamUtils.getStringInMap(params,"registerChannelCode"));
        userMessage.setMerchantNum(MapParamUtils.getStringInMap(params,"loginMerchantNum"));
        userRegisterProducer.send(userMessage);

        Map resultMap = getInvestorWithFilter(params);
        //操作标识
        resultMap.put("operFlag","regist");
        return resultMap;
    }

    /**
     * 更新用户交易状态
     *
     * @param userUuid
     * @param param
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int updateTradeStatus(String userUuid, UpdateTradeStatusDTO param) {
        // 处理交易状态变更
        if (param.getUserStatus() == UserTradeStatus.FIXI_ORDER_PAID_COMPLETE) {
            // 读取当前交易状态
            Map<String, Object> queryParam = new HashMap<>(8);
            queryParam.put("userUuid", userUuid);
            Map<String, Object> userInfo = userMapper.get(queryParam);
            int oldTradeStatus = MapParamUtils.getIntInMap(userInfo, "userTradeStatus");

            // 更新交易状态
            int row = userMapper.updateTradePaidStatus(userUuid);
            if (row > 0) {
                // 更新成功，记录日志
                String orderBillCode = param.getOrderBillCode();
                UserStatusLog log = new UserStatusLog();
                // 1=认证状态 2=交易状态
                log.setStatusType(2);
                log.setStatusOld(oldTradeStatus);
                log.setStatusNew(UserTradeStatus.FIXI_ORDER_PAID_COMPLETE);
                log.setUserUuid(userUuid);
                log.setOrderBillCode(orderBillCode);
                log.setChangeTime(new Date());
                userStatusLogMapper.insert(log);
                return row;
            }
        }

        return 0;
    }

    /**
     * 恢复用户交易状态
     *
     * @param userUuid
     * @param param
     * @return
     */
    @Override
    public int restoreTradeStatus(String userUuid, UpdateTradeStatusDTO param) {
        String orderBillCode = param.getOrderBillCode();
        UserStatusLog log = userStatusLogMapper.queryByOrderBillCode(orderBillCode);
        if (null != log) {
            LOGGER.info("处理订单[{}]引起的状态改变", orderBillCode);
            TradeStatusDO tradeStatusDO = new TradeStatusDO();
            tradeStatusDO.setUserUuid(userUuid);
            tradeStatusDO.setOldStatus(log.getStatusOld());
            tradeStatusDO.setNewStatus(log.getStatusNew());
            return userMapper.restoreTradeStatus(tradeStatusDO);
        }

        return 0;
    }

    /**
     * 重置用户密码
     *
     * @param
     * @return
     * @throws BusinessException
     */
    @Override
    public String resetUserPassword(Map<String, Object> mapParams) throws BusinessException {
        String userPhone = (String) mapParams.get(InvestorKeyConstants.INVESTOR_MOBILE_STR);
        String userUuid = isPhoneExist(userPhone);
        if (StringUtils.isBlank(userUuid)) {
            throw new BusinessException(UserParamMsg.REGISTER_PHONE_NOT_EXIST_CODE, UserParamMsg.REGISTER_PHONE_NOT_EXIST, true);
        }
        if (!isSmsVerify(userPhone, (String) mapParams.get("callSystemID"),
                (String) mapParams.get("verifyCode"), REDIS_SMS_RESET_LOGIN_PASSWORD_CODE_KEY)) {
            throw new BusinessException(UserParamMsg.VERIFY_CODE_ERROR_CODE, UserParamMsg.VERIFY_CODE_ERROR, true);
        }
        //4. 重置密码
        Map resetParam = new HashMap();

        resetParam.put(UserKeyConstants.USER_UUID_STR, userUuid);
        String userPassword = (String) mapParams.get(UserKeyConstants.USER_LOGIN_PASSWORD_STR);
        userPassword = EncryptUtils.encryptSalt(userPassword);
        resetParam.put(UserKeyConstants.USER_LOGIN_PASSWORD_STR, userPassword);
        int result = userMapper.updatePassword(resetParam);
        if (result == 0) {
            throw new BusinessException(UserParamMsg.INNER_ERROR_CODE, UserParamMsg.INNER_ERROR, true);
        }
        return userUuid;
    }

    /**
     * 重置交易密码
     *
     * @param
     * @return
     * @throws BusinessException
     */
    @Override
    public void resetPayPassword(Map<String, Object> mapParams) throws BusinessException {
        String userUuid = isPhoneExist((String)mapParams.get(InvestorKeyConstants.INVESTOR_MOBILE_STR));
        if (userUuid == null) {
            throw new BusinessException(UserParamMsg.REGISTER_PHONE_NOT_EXIST_CODE, UserParamMsg.REGISTER_PHONE_NOT_EXIST, true);
        }

        Map requestParam = new HashMap();
        requestParam.put(UserKeyConstants.USER_UUID_STR, userUuid);
        Map userMap = getUser(requestParam, false);
        if (mapParams.get("preUserPayPassword") != null) {
            String prePassword = EncryptUtils.encryptSalt((String)mapParams.get("preUserPayPassword"));
            String userPayPassword = (String)userMap.get(UserKeyConstants.USER_PAY_PASSWORD_STR);
            if (!prePassword.equals(userPayPassword)) {
                throw new BusinessException(UserParamMsg.PRE_PAY_PW_ERROR_CODE, UserParamMsg.PRE_PAY_PW_ERROR, true);
            }
        }
        if (mapParams.get("idCardTail") != null) {
            String idCardRequestTail = (String) mapParams.get("idCardTail");
            if (!isIdCardTailMatch(idCardRequestTail, (String) userMap.get(InvestorKeyConstants.INVESTOR_ID_CARD_NO_STR))) {
                throw new BusinessException(UserParamMsg.ID_CARD_NOT_MATCH_CODE, UserParamMsg.ID_CARD_NOT_MATCH, true);
            }
        } else if (mapParams.get("idCard") != null) {
            if (!mapParams.get("idCard").toString().equals(userMap.get(EnterpriseKeyConstants.LEGAL_PERSON_ID_CARD_STR))) {
                throw new BusinessException(UserParamMsg.ID_CARD_NOT_MATCH_CODE, UserParamMsg.ID_CARD_NOT_MATCH, true);
            }
        }
        if (!isSmsVerify((String) mapParams.get(InvestorKeyConstants.INVESTOR_MOBILE_STR), (String) mapParams.get("callSystemID"),
                (String) mapParams.get("verifyCode"), REDIS_SMS_RESET_PAY_PASSWORD_CODE_KEY)) {
            throw new BusinessException(UserParamMsg.VERIFY_CODE_ERROR_CODE, UserParamMsg.VERIFY_CODE_ERROR, true);
        }
        Map resetParam = new HashMap();
        resetParam.put(UserKeyConstants.USER_UUID_STR, userMap.get(UserKeyConstants.USER_UUID_STR));
        String payPassword = (String) mapParams.get(UserKeyConstants.USER_PAY_PASSWORD_STR);
        payPassword = EncryptUtils.encryptSalt(payPassword);
        resetParam.put(UserKeyConstants.USER_PAY_PASSWORD_STR, payPassword);
        int result = userMapper.updatePassword(resetParam);
        //clear check password error state
        String redisKey = userMap.get(UserKeyConstants.USER_UUID_STR) + UserKeyConstants.USER_PAY_PASSWORD_STR;
        stringRedisTemplate.delete(redisKey);
        if (result == 0) {
            throw new BusinessException(UserParamMsg.INNER_ERROR_CODE, UserParamMsg.INNER_ERROR, true);
        }
    }

    @Override
    public Map<String, Object> checkPayPassword(Map<String, Object> mapParams) throws BusinessException {
        Map user = getUser(mapParams, false);
        //判断密码是否一致
        String paramUserPassword = EncryptUtils.encryptSalt((String) mapParams.get(UserKeyConstants.USER_PAY_PASSWORD_STR));
        if (user.get(UserKeyConstants.USER_PAY_PASSWORD_STR) == null) {
            throw new BusinessException(UserParamMsg.PAY_PW_NOT_EXIST_CODE, UserParamMsg.PAY_PW_NOT_EXIST, true);
        }
        Map<String, Object> result;
        String redisKey = user.get(UserKeyConstants.USER_UUID_STR) + UserKeyConstants.USER_PAY_PASSWORD_STR;
        if (!user.get(UserKeyConstants.USER_PAY_PASSWORD_STR).equals(paramUserPassword)) {
           result = errorPayInput( redisKey);
        } else {
            result = correctPayInput( redisKey);
        }
        return result;
    }

    private Map<String, Object> errorPayInput(String redisKey) {
        Map<String, Object> result = new HashMap<>();
        String strTimes = stringRedisTemplate.opsForValue().get(redisKey);
        int errorTimes = StringUtils.isEmpty(strTimes) ? 1 : Integer.valueOf(strTimes) + 1;
        if (errorTimes < PAY_PWD_ERROR_MAX_TIME) {
            stringRedisTemplate.opsForValue().set(redisKey, String.valueOf(errorTimes));
            result.put("errorCount", errorTimes);
        } else if (errorTimes == PAY_PWD_ERROR_MAX_TIME ) {
            stringRedisTemplate.opsForValue().set(redisKey, String.valueOf(errorTimes), 12, TimeUnit.HOURS);
            result.put("time", 12 * ONE_HOUR_SECOND);
            result.put("errorCount", PAY_PWD_ERROR_MAX_TIME);
        } else {
            result.put("time", stringRedisTemplate.getExpire(redisKey, TimeUnit.SECONDS));
            result.put("errorCount", PAY_PWD_ERROR_MAX_TIME);
        }
        return result;
    }

    private Map<String, Object> correctPayInput(String redisKey) {
        Map<String, Object> result = new HashMap<>();
        String strTimes = stringRedisTemplate.opsForValue().get(redisKey);
        int errorTimes = StringUtils.isEmpty(strTimes) ? 0 : Integer.valueOf(strTimes);
        if (errorTimes < PAY_PWD_ERROR_MAX_TIME) {
            stringRedisTemplate.delete(redisKey);
        } else {
            result.put("errorCount", PAY_PWD_ERROR_MAX_TIME);
            result.put("time", stringRedisTemplate.getExpire(redisKey, TimeUnit.SECONDS));
        }
        return result;
    }

    /**
     * 验证身份证号
     *
     * @param paramMap
     * @throws BusinessException
     */
    @Override
    public void checkIdCard(Map<String, Object> paramMap) throws BusinessException {
        Map result = investorMapper.get(paramMap);
        String idCard = (String) result.get(InvestorKeyConstants.INVESTOR_ID_CARD_NO_STR);
        if (StringUtils.isEmpty(idCard) || idCard.length() < ID_CARD_MIN_LENGTH) {
            throw new BusinessException(UserParamMsg.REGISTER_ID_CARD_NOT_EXIST_CODE, UserParamMsg.REGISTER_ID_CARD_NOT_EXIST, true);
        }
        String idCardRequestTail = (String) paramMap.get("idCardTail");
        if (!isIdCardTailMatch(idCardRequestTail, idCard)) {
            throw new BusinessException(UserParamMsg.ID_CARD_NOT_MATCH_CODE, UserParamMsg.ID_CARD_NOT_MATCH, true);
        }
    }

    @Override
    public int updateUserVerifyStatus(Map<String, Object> params) throws BusinessException {
        Map<String, Object> ui = getUser(params, false);
        Integer verifyStatus = ui.get(UserKeyConstants.USER_VERIFY_STATUS_INT) == null ? 0 : Integer.valueOf(ui.get(UserKeyConstants.USER_VERIFY_STATUS_INT).toString());
        Integer updateStatus = params.get(UserKeyConstants.USER_VERIFY_STATUS_INT) == null ? 0 : Integer.valueOf(params.get(UserKeyConstants.USER_VERIFY_STATUS_INT).toString());
        if (updateStatus < verifyStatus) {
            return 1;
        }
        //处理交易密码已经设置问题
        if (updateStatus == UserVerifyStatus.USER_BIND_CARD_SUCCESS.getStatus() && ui.get(UserKeyConstants.USER_PAY_PASSWORD_STR) != null) {
            params.put(UserKeyConstants.USER_VERIFY_STATUS_INT,UserVerifyStatus.OPEN_ACCOUNT_SUCCESS.getStatus());
        }
        int count = userMapper.update(params);

        if (updateStatus == UserVerifyStatus.USER_AUTH_SUCCESS.getStatus()) {
            UserMessage userMessage = new UserMessage();
            userMessage.setInvestorMobile(ui.get(UserKeyConstants.USER_LOGIN_NAME_STR).toString());
            userMessage.setUserUuid(ui.get(UserKeyConstants.USER_UUID_STR).toString());
            userMessage.setMerchantNum(MapParamUtils.getStringInMap(params,"merchantNum"));
            LOGGER.info("userAuthProducer.send(userMessage): {}", userMessage.toString());
            userAuthProducer.send(userMessage);
        } else if (updateStatus == UserVerifyStatus.USER_BIND_CARD_SUCCESS.getStatus()) {
            UserBindCardMessage userMessage = new UserBindCardMessage();
            userMessage.setInvestorMobile(ui.get(UserKeyConstants.USER_LOGIN_NAME_STR).toString());
            userMessage.setUserUuid(ui.get(UserKeyConstants.USER_UUID_STR).toString());
            userMessage.setUserName(ui.get(InvestorKeyConstants.INVESTOR_REAL_NAME_STR).toString());
            userMessage.setMerchantNum(MapParamUtils.getStringInMap(params,"merchantNum"));
            LOGGER.info("userBindCardProducer.send(userMessage): {}", userMessage.toString());
            userBindCardProducer.send(userMessage);
        }
        return count;
    }

    /**
     * 金疙瘩开户初始化交易密码
     * 需要验证步骤
     * @param
     * @return
     * @throws BusinessException
     */
    @Override
    public int initPayPassword(Map<String, Object> mapParams) throws BusinessException {
        Map<String, Object> resetParam = new HashMap();
        resetParam.put(UserKeyConstants.USER_UUID_STR, mapParams.get(UserKeyConstants.USER_UUID_STR));
        Map<String, Object> user = getUser(resetParam, false);
        Integer verifyCode = (Integer) user.get(UserKeyConstants.USER_VERIFY_STATUS_INT);
        if (verifyCode == null || Integer.valueOf(verifyCode) != 3) {
            throw new BusinessException(UserParamMsg.USER_NOT_TIE_ON_CARD_CODE, UserParamMsg.USER_NOT_TIE_ON_CARD, true);
        }
        if (StringUtils.isNotBlank((String) mapParams.get(UserKeyConstants.USER_PAY_PASSWORD_STR)) ) {
            String payPassword = (String) mapParams.get(UserKeyConstants.USER_PAY_PASSWORD_STR);
            payPassword = EncryptUtils.encryptSalt(payPassword);
            resetParam.put(UserKeyConstants.USER_PAY_PASSWORD_STR, payPassword);
            resetParam.put(UserKeyConstants.USER_VERIFY_STATUS_INT, 9);
        }
        int result = userMapper.updatePassword(resetParam);
        return result;
    }

    /**
     * 基金初始化交易密码
     * 不需要验证步骤
     * @param
     * @return
     * @throws BusinessException
     */
    @Override
    public int fundInitPayPassword(Map<String, Object> mapParams) throws BusinessException {
        Map<String, Object> resetParam = new HashMap();
        resetParam.put(UserKeyConstants.USER_UUID_STR, mapParams.get(UserKeyConstants.USER_UUID_STR));
        Map<String, Object> user = getUser(resetParam, false);
        if (user.get(UserKeyConstants.USER_PAY_PASSWORD_STR) !=  null) {
            return 0;
        }

        String payPassword = (String) mapParams.get(UserKeyConstants.USER_PAY_PASSWORD_STR);
        payPassword = EncryptUtils.encryptSalt(payPassword);
        resetParam.put(UserKeyConstants.USER_PAY_PASSWORD_STR, payPassword);
        if ((Integer)user.get(UserKeyConstants.USER_VERIFY_STATUS_INT) == 3) {
            resetParam.put(UserKeyConstants.USER_VERIFY_STATUS_INT, 9);
        }
        int result = userMapper.updatePassword(resetParam);
        return result;
    }

    /**
     * 检查是否设置交易密码
     *
     * @param
     * @return
     * @throws BusinessException
     */
    @Override
    public int isInitPayPassword(String userUuid) throws BusinessException {
        Map<String, Object> resetParam = new HashMap();
        resetParam.put(UserKeyConstants.USER_UUID_STR, userUuid);
        Map<String, Object> user = getUser(resetParam, false);
        return user.get(UserKeyConstants.USER_PAY_PASSWORD_STR) ==  null ? 0 : 1;
    }

    @Override
    public int clearCheckTime(Map<String, Object> mapParams) throws BusinessException {
        Map user = getUser(mapParams, false);
        String redisKey = user.get(UserKeyConstants.USER_UUID_STR) + UserKeyConstants.USER_PAY_PASSWORD_STR;
        stringRedisTemplate.opsForValue().set(redisKey, String.valueOf(mapParams.get("errorCount")));
        stringRedisTemplate.expire(redisKey, Long.valueOf(mapParams.get("time").toString()), TimeUnit.SECONDS);
        return 1;
    }

    @Override
    public Map xyRegisterKingold(Map<String, Object> mapParams) throws BusinessException {
        // 判断手机号是否存在
        Map regParam = new HashMap();
        regParam.put(InvestorKeyConstants.INVESTOR_MOBILE_STR, mapParams.get(InvestorKeyConstants.INVESTOR_MOBILE_STR));
        Map investorMap = investorMapper.get(regParam);

        Map regUserParam = new HashMap();
        regUserParam.put(InvestorKeyConstants.INVESTOR_MOBILE_STR, mapParams.get(InvestorKeyConstants.INVESTOR_MOBILE_STR));
        Map userMap = userMapper.get(regUserParam);
        boolean isUserExist =( userMap != null);
        boolean isInvestorExist =( investorMap != null);
        if (isUserExist && isInvestorExist ) {//investor
            throw new BusinessException(UserParamMsg.REGISTER_PHONE_IS_EXIST_CODE, UserParamMsg.REGISTER_PHONE_IS_EXIST, true);
        }
        String userUuid = UUID.randomUUID().toString().replace("-", "");
        if(isUserExist) {
            userUuid =  MapParamUtils.getStringInMap(userMap,"userUuid");
        }
        mapParams.put("userUuid", userUuid);

        boolean hasInviter = false;

        //2. 写入注册信息
        String loginName = (String)mapParams.get(UserKeyConstants.USER_LOGIN_NAME_STR);
        mapParams.put(UserKeyConstants.USER_UUID_STR, userUuid);
        mapParams.put(UserKeyConstants.USER_LOGIN_NAME_STR, StringUtils.isEmpty(loginName) ?
                mapParams.get(InvestorKeyConstants.INVESTOR_MOBILE_STR) : loginName);

        userTransactionService.insertUserTransaction(mapParams,isUserExist);//插入投资人和用户表信息
        //发送注册mq消息
        UserMessage userMessage = new UserMessage();
        userMessage.setInvestorMobile(mapParams.get(InvestorKeyConstants.INVESTOR_MOBILE_STR).toString());
        userMessage.setUserUuid(userUuid);
        userMessage.setRegisterChannelCode(MapParamUtils.getStringInMap(mapParams,"registerChannelCode"));
        userRegisterProducer.send(userMessage);
        return getInvestorWithFilter(mapParams);
    }

    @Override
    public List<Map<String, Object>> getCertification(String userUuid, Integer userCertificationType) {
        return userCertificationMapper.getByUserUuid(userUuid, userCertificationType);
    }


    private void refreshOneRisk(Map one) {
        String userUuid = (String) one.get(InvestorKeyConstants.USER_UUID_STR);
        Object score = one.get(InvestorKeyConstants.INVESTOR_RISK_SCORE_INT);
        if (score == null || Integer.valueOf(score.toString()) <= 0) {
            return;
        }
        int version  = (int)one.get(InvestorKeyConstants.INVESTOR_RISK_VERSION_INT);
        if (version < 2) {
            return;
        }
        String answer = one.get(InvestorKeyConstants.INVESTOR_RISK_ANSWER_STR).toString();
        List<String> scores = Lists.newArrayList(Splitter.on("$$").trimResults().omitEmptyStrings().split(answer));
        List<String> result = new ArrayList<>();
        for (int j = 0; j < scores.size(); j++) {
            String data = null;
            if (j == 0 || j == 7 || j== 8) {

                data = InvestorKeyConstants.riskMap0Start.get(scores.get(j));
            } else if (j == 9){
                data = InvestorKeyConstants.riskMap3Start.get(scores.get(j));
            } else {
                data = scores.get(j);
            }
            if (data == null) {
                LOGGER.info("refresh user {} contains null. before={}",one.get(InvestorKeyConstants.INVESTOR_MOBILE_STR), answer);
                return;
            }
            result.add(data);
        }
        String refreshAnswer = Joiner.on("$$").join(result);
        Map<String, String> oneParam = new HashMap<>();
        oneParam.put("userUuid",userUuid);
        oneParam.put("investorRiskAnswer", refreshAnswer);
        LOGGER.info("refresh user {} risk answer. before={}, after={}",one.get(InvestorKeyConstants.INVESTOR_MOBILE_STR), answer, refreshAnswer);
        investorMapper.update(oneParam);
    }

    @Override
    public int insertCertification(Map<String, Object> mapParams) throws BusinessException {
        int count = userCertificationMapper.insert(mapParams);
        return count;
    }

    private void doCommon(Map<String, Object> params, String inviterUuid) {
        Map<String, Object> inviterRelation = investorRelationMapper.get(inviterUuid);
        if (inviterRelation != null) {
            PutStringNotNull(params, InvestorRelationKeyConstants.INVITER_LEVEL_TWO_UUID_STR,
                    inviterRelation.get(InvestorRelationKeyConstants.INVITER_LEVEL_ONE_UUID_STR));
            PutStringNotNull(params, InvestorRelationKeyConstants.INVITER_LEVEL_THREE_UUID_STR,
                    inviterRelation.get(InvestorRelationKeyConstants.INVITER_LEVEL_TWO_UUID_STR));
            PutStringNotNull(params, InvestorRelationKeyConstants.TOP_UUID_STR,
                    inviterRelation.get(InvestorRelationKeyConstants.TOP_UUID_STR));
            PutStringNotNull(params, InvestorRelationKeyConstants.TOP_ORGANIZATION_PATH_STR,
                    inviterRelation.get(InvestorRelationKeyConstants.TOP_ORGANIZATION_PATH_STR));
            PutStringNotNull(params, InvestorRelationKeyConstants.TOP_ORGANIZATION_UUID_STR,
                    inviterRelation.get(InvestorRelationKeyConstants.TOP_ORGANIZATION_UUID_STR));
        }
    }

    private List<Map> fillEnterpriseInfo(List<String> uuids) {
        Map<String, Object> params = new HashMap<>();
        params.put("uuids", uuids);
        List<Map> enterpriseInfo = enterpriseInvestorMapper.getList(params);
        return enterpriseInfo;
    }

    @Override
    public Map getUser(Map<String, Object> params, boolean withFreezing) throws BusinessException {
        Map userMap = userMapper.get(params);
        if (userMap == null || userMap.isEmpty()) {
            throw new BusinessException(UserParamMsg.NOT_FIND_USER_CODE, UserParamMsg.NOT_FIND_USER, true);
        }
        if ("1".equals(userMap.get(UserKeyConstants.USER_STATUS_INT).toString()) && !withFreezing) {
            throw new BusinessException(UserParamMsg.USER_IS_FREEZING_CODE, UserParamMsg.USER_IS_FREEZING, true);
        }

        int userType = (Integer) userMap.get(UserKeyConstants.USER_TYPE_BYTE);
        params.put(UserKeyConstants.USER_UUID_STR, userMap.get(UserKeyConstants.USER_UUID_STR));
        Map<String, Object> son;
        if (userType == UserTypeEnum.USER_INVESTOR_TYPE.getUserType()) {
            son = investorMapper.get(params);
            son.put("mobile", son.get(InvestorKeyConstants.INVESTOR_MOBILE_STR));
        } else if (userType == UserTypeEnum.USER_ISSUER_TYPE.getUserType()){
            son = issuerMapper.get(params);
            son.put("mobile", son.get(IssuerKeyConstants.LEGAL_PERSON_MOBILE_STR));
        } else {
            son = enterpriseInvestorMapper.get(params);
            son.put("mobile", son.get(EnterpriseKeyConstants.LEGAL_PERSON_MOBILE_STR));
        }
        userMap.putAll(son);
        int isSetPayPassword = userMap.get(UserKeyConstants.USER_PAY_PASSWORD_STR) ==  null ? 0 : 1;
        userMap.put("isSetPayPassword", isSetPayPassword);

        return userMap;
    }


    @Override
    public Map getUserForCamp(Map<String, Object> params, boolean withFreezing) throws BusinessException {
        Map userMap = userMapper.get(params);
        Map regParam = new HashMap();
        regParam.put(InvestorKeyConstants.INVESTOR_MOBILE_STR, params.get(InvestorKeyConstants.INVESTOR_MOBILE_STR));
        Map investorMap = investorMapper.get(params);
        boolean isUserExist = ( userMap == null);
        boolean isInvestorExist = ( investorMap == null);
        if ( isUserExist && isInvestorExist ) {
            //向数据库表新增此用户，调用注册接口
            return this.campUserRegist(params,false);
        }else if( !isUserExist && isInvestorExist){
            //向数据库表新增此用户，调用注册接口
            params.put(UserKeyConstants.USER_UUID_STR, userMap.get(UserKeyConstants.USER_UUID_STR));
            return this.campUserRegist(params,true);
        }else{
            //冻结用户
            if (UserStatusConstants.USER_STATUS_FREEZE.equals(userMap.get(UserKeyConstants.USER_STATUS_INT).toString()) && !withFreezing) {
                throw new BusinessException(UserParamMsg.USER_IS_FREEZING_CODE, UserParamMsg.USER_IS_FREEZING, true);
            }
            int userType = (Integer) userMap.get(UserKeyConstants.USER_TYPE_BYTE);
            params.put(UserKeyConstants.USER_UUID_STR, userMap.get(UserKeyConstants.USER_UUID_STR));
            Map<String, Object> son;
            if (userType == UserTypeEnum.USER_INVESTOR_TYPE.getUserType()) {
                son = investorMapper.get(params);
                if(son == null) {
                    throw new BusinessException(UserParamMsg.NOT_FIND_USER_CODE, UserParamMsg.NOT_FIND_USER, true);
                }else {
                    son.put("mobile", son.get(InvestorKeyConstants.INVESTOR_MOBILE_STR));
                }
            }else if (userType == UserTypeEnum.USER_ISSUER_TYPE.getUserType()){
                son = issuerMapper.get(params);
                son.put("mobile", son.get(IssuerKeyConstants.LEGAL_PERSON_MOBILE_STR));
            } else {
                son = enterpriseInvestorMapper.get(params);
                son.put("mobile", son.get(EnterpriseKeyConstants.LEGAL_PERSON_MOBILE_STR));
            }
            userMap.putAll(son);
            int isSetPayPassword = userMap.get(UserKeyConstants.USER_PAY_PASSWORD_STR) ==  null ? 0 : 1;
            userMap.put("isSetPayPassword", isSetPayPassword);
            userMap.put("operFlag","login");
            return userMap;
        }
    }


    /**
    * 获取用户信息，如果不存在，则抛出异常。
    */
    public Map getUserAndCheck(Map<String, Object> params, boolean withFreezing) throws BusinessException {
        Map userMap = userMapper.get(params);
        if (userMap == null || userMap.isEmpty()) {
            throw new BusinessException(UserParamMsg.NOT_FIND_USER_CODE, UserParamMsg.NOT_FIND_USER, true);
        }
        if ("1".equals(userMap.get(UserKeyConstants.USER_STATUS_INT).toString()) && !withFreezing) {
            throw new BusinessException(UserParamMsg.USER_IS_FREEZING_CODE, UserParamMsg.USER_IS_FREEZING, true);
        }

        int userType = (Integer) userMap.get(UserKeyConstants.USER_TYPE_BYTE);
        params.put(UserKeyConstants.USER_UUID_STR, userMap.get(UserKeyConstants.USER_UUID_STR));
        Map<String, Object> son;
        if (userType == UserTypeEnum.USER_INVESTOR_TYPE.getUserType()) {
            son = investorMapper.get(params);
            if(son == null) {//兼容星耀用户登录
                throw new BusinessException(UserParamMsg.NOT_FIND_USER_CODE, UserParamMsg.NOT_FIND_USER, true);
            }else {
                son.put("mobile", son.get(InvestorKeyConstants.INVESTOR_MOBILE_STR));
            }
        } else if (userType == UserTypeEnum.USER_ISSUER_TYPE.getUserType()){
            son = issuerMapper.get(params);
            son.put("mobile", son.get(IssuerKeyConstants.LEGAL_PERSON_MOBILE_STR));
        } else {
            son = enterpriseInvestorMapper.get(params);
            son.put("mobile", son.get(EnterpriseKeyConstants.LEGAL_PERSON_MOBILE_STR));
        }
        userMap.putAll(son);
        int isSetPayPassword = userMap.get(UserKeyConstants.USER_PAY_PASSWORD_STR) ==  null ? 0 : 1;
        userMap.put("isSetPayPassword", isSetPayPassword);

        return userMap;
    }


    public void refreshTokenInfo(String token, Map mapParams) {
        HashOperations<String, String, String> hash = stringRedisTemplate.opsForHash();
        for (Object hashKey : mapParams.keySet()) {
            if (isCache2Token((String) hashKey)) {
                Object value =  mapParams.get(hashKey);
                if (value != null) {
                    hash.put(token, (String) hashKey, (String) mapParams.get(hashKey));
                }
            }
        }
    }

    private boolean isIdCardTailMatch(String requestCardTail, String matchCard) {
        if (StringUtils.isEmpty(requestCardTail) || StringUtils.isEmpty(matchCard) ||
                !requestCardTail.toLowerCase().equals(matchCard.substring(matchCard.length() - 4, matchCard.length()).toLowerCase())) {
            LOGGER.info("isIdCardTailMatch match failed. requestCardTail={}, matchCard={}", requestCardTail, matchCard);
            return false;
        }
        return true;
    }

    private String isPhoneExist(String userPhone) throws BusinessException {
        Map checkParam = new HashMap();
        Map userMap;
        checkParam.put(EnterpriseKeyConstants.LEGAL_PERSON_MOBILE_STR, userPhone);
        checkParam.put(InvestorKeyConstants.INVESTOR_MOBILE_STR, userPhone);
        userMap = investorMapper.get(checkParam);
        if (userMap != null)
            return userMap.get(UserKeyConstants.USER_UUID_STR).toString();
        userMap = issuerMapper.get(checkParam);
        if (userMap != null)
            return userMap.get(UserKeyConstants.USER_UUID_STR).toString();
        userMap = enterpriseInvestorMapper.get(checkParam);
        if (userMap != null)
            return userMap.get(UserKeyConstants.USER_UUID_STR).toString();

        return null;
    }

    private boolean isSmsVerify(String userPhone, String callSystemId, String verifyCode, String type) {
        String smsVerifyCode = (String) stringRedisTemplate.opsForValue().get(userPhone + callSystemId + type);
        if (verifyCode == null || !verifyCode.equals(smsVerifyCode)) {
            LOGGER.info("isSmsVerify not equals. userPhone={}, verifyCodeParam={}, type={}, verifyCode={}",
                    userPhone, verifyCode,type, smsVerifyCode);
            if ("test".equals(runModel) && verifyCode.equals(adminVerifyCode)) {
                return true;
            } else {
                return false;
            }
        }
        return true;
    }

    private boolean isCampVerify(String userPhone, String callSystemId, String verifyCode, String type) {
        String campVerifyCode = stringRedisTemplate.opsForValue().get(userPhone + callSystemId + type);
        if (verifyCode == null || !verifyCode.equals(campVerifyCode)) {
            LOGGER.info("isCampVerify not equals. userPhone={}, verifyCodeParam={}, type={}, verifyCode={}",userPhone, verifyCode,type, campVerifyCode);
            if ("test".equals(runModel) && verifyCode.equals(adminVerifyCode)) {
                return true;
            } else {
                return false;
            }
        }
        return true;
    }

    private boolean isOpenVerify(String userPhone, String callSystemId, String verifyCode, String type) {
        String openVerifyCode = stringRedisTemplate.opsForValue().get(userPhone + callSystemId + type);
        if (verifyCode == null || !verifyCode.equals(openVerifyCode)) {
            LOGGER.info("isOpenVerify not equals. userPhone={}, verifyCodeParam={}, type={}, verifyCode={}",
                    userPhone, verifyCode, type, openVerifyCode);
            if ("test".equals(runModel) && verifyCode.equals(adminVerifyCode)) {
                return true;
            } else {
                return false;
            }
        }
        return true;
    }

    private void PutStringNotNull( Map<String, Object> params, String key, Object o) {
        if (o == null || StringUtils.isEmpty(o.toString())) {
            return ;
        }
        String value = o.toString();
        params.put(key, value);
    }

    static Set<String> tokenProps = new HashSet(Arrays.asList(new String[]{"userId", "userUuid", "userType", "userStatus", "userPhone", "userGender", "userAvatar", "isInner", "isFullTime", "inviterUuid", "inviterPhone", "userPath", "userName", "userIdCardNumber", "riskAssessmentLevel", "userRegisterTime", "userRegisterChannelCode", "userRegisterChannelName", "userRegisterVersionCode", "userRegisterVersionName", "userRegisterDeviceId", "userRegisterDeviceType", "userRegisterDeviceName", "userRegisterDeviceOs", "userRegisterDeviceIp"
            , "userLoginTime", "userLoginChannelCode", "userLoginChannelName", "userLoginVersionCode", "userLoginVersion_name", "userLoginDeviceCode", "userOginDeviceType", "userLoginDeviceName", "userLoginDeviceOs", "userLoginDeviceIp", "deleteFlag", "createTime", "createBy", "updateTime", "updateBy", "signature", "isQualiInv", "userVerifyStatus", "parentInviterUuid", "parentInviterPhone","investorIdCardNo","investorRealName"}));

    public boolean isCache2Token(String key) {

        return tokenProps.contains(key);
    }

}