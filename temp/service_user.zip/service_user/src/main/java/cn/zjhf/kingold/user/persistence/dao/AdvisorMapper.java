package cn.zjhf.kingold.user.persistence.dao;

import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface AdvisorMapper {
    Map get(Map params);

    int insert(Map record);

    int update(Map experInfo);

    int delete(Map params);

    Integer getCount(Map paramMap);

    List<Map> getList(Map paramMap);
}