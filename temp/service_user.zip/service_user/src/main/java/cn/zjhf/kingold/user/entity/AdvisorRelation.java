package cn.zjhf.kingold.user.entity;

import org.hibernate.validator.constraints.NotEmpty;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class AdvisorRelation implements Serializable {
    /**
     * 自增ID
     */
    private Long advisorRelationId;

    /**
     * 用户主表UUID
     */
    @NotEmpty
    private String advisorUuid;

    /**
     * 直接邀请人用户UUID
     */
    private String inviterLevelOneUuid;

    /**
     * 上上级邀请人用户UUID
     */
    private String inviterLevelTwoUuid;

    /**
     * 上上上邀请人用户UUID
     */
    private String inviterLevelThreeUuid;

    /**
     * 顶层专职理财师用户UUID
     */
    private String topUuid;

    /**
     * 顶级理财师组织结构
     */
    private String topOrganizationPath;

    /**
     * 顶级理财师机构id
     */
    private String topOrganizationUuid;

    /**
     * 删除标记
     */
    @NotEmpty
    private Byte deleteFlag;

    /**
     * 创建时间
     */
    @NotEmpty
    private Date createTime;

    /**
     * 更新时间
     */
    @NotEmpty
    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public Long getAdvisorRelationId() {
        return advisorRelationId;
    }

    public void setAdvisorRelationId(Long advisorRelationId) {
        this.advisorRelationId = advisorRelationId;
    }

    public String getAdvisorUuid() {
        return advisorUuid;
    }

    public void setAdvisorUuid(String advisorUuid) {
        this.advisorUuid = advisorUuid;
    }

    public String getInviterLevelOneUuid() {
        return inviterLevelOneUuid;
    }

    public void setInviterLevelOneUuid(String inviterLevelOneUuid) {
        this.inviterLevelOneUuid = inviterLevelOneUuid;
    }

    public String getInviterLevelTwoUuid() {
        return inviterLevelTwoUuid;
    }

    public void setInviterLevelTwoUuid(String inviterLevelTwoUuid) {
        this.inviterLevelTwoUuid = inviterLevelTwoUuid;
    }

    public String getInviterLevelThreeUuid() {
        return inviterLevelThreeUuid;
    }

    public void setInviterLevelThreeUuid(String inviterLevelThreeUuid) {
        this.inviterLevelThreeUuid = inviterLevelThreeUuid;
    }

    public String getTopUuid() {
        return topUuid;
    }

    public void setTopUuid(String topUuid) {
        this.topUuid = topUuid;
    }

    public String getTopOrganizationPath() {
        return topOrganizationPath;
    }

    public void setTopOrganizationPath(String topOrganizationPath) {
        this.topOrganizationPath = topOrganizationPath;
    }

    public String getTopOrganizationUuid() {
        return topOrganizationUuid;
    }

    public void setTopOrganizationUuid(String topOrganizationUuid) {
        this.topOrganizationUuid = topOrganizationUuid;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}