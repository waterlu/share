package cn.zjhf.kingold.user.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.user.constant.InvestorKeyConstants;
import cn.zjhf.kingold.user.constant.UserParamMsg;
import cn.zjhf.kingold.user.constant.UserTradeStatus;
import cn.zjhf.kingold.user.dto.UpdateTradeStatusDTO;
import cn.zjhf.kingold.user.entity.LoginParam;
import cn.zjhf.kingold.user.entity.LoginRegiestParam;
import cn.zjhf.kingold.user.service.IUserService;
import cn.zjhf.kingold.user.utils.MapParamUtils;
import cn.zjhf.kingold.user.utils.RequestMapperConvert;
import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by lu on 2017/3/13.
 * <p>
 * 接口文档：{@see <a href="http://10.10.10.6/doc/general/wikis/user_interface_app</a>}
 */

@RestController
@RequestMapping(value = "/user")
public class UserController {

    private final static Logger LOGGER = LoggerFactory.getLogger(UserController.class);
    @Autowired
    private IUserService userInfoMapService;

    /**
     * 用户登录
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/login")
    public ResponseResult login(@RequestBody Map<String, Object> paramMap) throws BusinessException {

        RequestMapperConvert.initParam(paramMap);
        Map userMap = userInfoMapService.login(paramMap);
        return new ResponseResult((String) paramMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", userMap);
    }

    /**
     * 用户手机验证码登录
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/smsLogin")
    public ResponseResult smsLogin(@RequestBody LoginParam loginParam) throws BusinessException {
        Map userMap = userInfoMapService.smsLogin(loginParam);
        return new ResponseResult(loginParam.getTraceID(), ResponseCode.REQUEST_SUCCESS, "成功", userMap);
    }


    /**
     * 用户第三方登录
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/thirdLogin")
    public ResponseResult thirdLogin(@RequestBody Map params) throws BusinessException {
        Map userMap = userInfoMapService.thirdLogin(params);
        return new ResponseResult(MapParamUtils.getStringInMap(params,"traceID"), ResponseCode.REQUEST_SUCCESS, "成功", userMap);
    }

    /**
     * 用户第三方登录
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/openRegisterLogin")
    public ResponseResult openRegisterLogin(@RequestBody Map params) throws BusinessException {
        Map userMap = userInfoMapService.openRegisterLogin(params);
        return new ResponseResult(MapParamUtils.getStringInMap(params,"traceID"), ResponseCode.REQUEST_SUCCESS, "成功", userMap);
    }


    /**
     * 活动用（用户手机验证码登录）
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/campRegistLogin", method = {RequestMethod.POST})
    @ResponseBody
    public ResponseResult campRegistLogin(@RequestBody LoginRegiestParam loginParam) throws BusinessException {
        Map userMap = userInfoMapService.campRegistLogin(loginParam);
        return new ResponseResult(loginParam.getTraceID(), ResponseCode.REQUEST_SUCCESS, "成功", userMap);
    }


    /**
     * 用户注册
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/regist", method = {RequestMethod.POST})
    @ResponseBody
    public ResponseResult regist(@RequestBody Map<String, Object> paramMap) throws BusinessException {
        RequestMapperConvert.initParam(paramMap);
        Map userMap = userInfoMapService.regist(paramMap);
        return new ResponseResult((String) paramMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", userMap);
    }

    /**
     * 运营创建用户
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/create", method = {RequestMethod.POST})
    @ResponseBody
    public ResponseResult create(@RequestBody Map<String, Object> paramMap) throws BusinessException {
        RequestMapperConvert.initParam(paramMap);
        Map userMap = userInfoMapService.create(paramMap);
        return new ResponseResult((String) paramMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", userMap);
    }

    /**
     * 查找用户信息
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/{userUuid}", method = RequestMethod.GET)
    public ResponseResult getUser(@PathVariable("userUuid") String userUuid, @RequestParam Map<String, Object> paramMap) throws BusinessException {
        RequestMapperConvert.initParam(paramMap);
        paramMap.put("userUuid", userUuid);
        Integer withoutFilter = paramMap.get("withoutFilter") == null ? null : Integer.valueOf(paramMap.get("withoutFilter").toString());
        Map ui;
        if (withoutFilter != null && withoutFilter == 1 ) {
            ui = userInfoMapService.getInvestorWithFreezing(paramMap);
        } else {
            ui = userInfoMapService.getInvestorWithFilter(paramMap);
        }
        return new ResponseResult((String) paramMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", ui);
    }

    /**
     * 查找用户信息
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "issuer/{userUuid}", method = RequestMethod.GET)
    public ResponseResult getIssuer(@PathVariable("userUuid") String userUuid, @RequestParam Map<String, Object> paramMap) throws BusinessException {
        RequestMapperConvert.initParam(paramMap);
        paramMap.put("userUuid", userUuid);
        Map ui;
        ui = userInfoMapService.getIssuerWithFilter(paramMap);
        return new ResponseResult((String) paramMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", ui);
    }

    /**
     * 查找募集方列表
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/issuer/list", method = RequestMethod.GET)
    public ResponseResult getIssuerList(@RequestParam Map<String, Object> paramMap) throws BusinessException {
        RequestMapperConvert.initParam(paramMap);
        String userUuids = paramMap.get("userUuids") == null ? null : (String)paramMap.get("userUuids");
        if (userUuids != null) {
            List<String> uuids = splitData((String) paramMap.get("userUuids"));
            paramMap.put("userUuids", uuids);
        }
        List<Map> ui = userInfoMapService.getIssuerListWithFilter(paramMap);
        return new ResponseResult((String) paramMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", ui);
    }

    /**
     * 查找用户手机号列表
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/investor/mobilephonelist", method = RequestMethod.GET)
    public ResponseResult getUerMobilePhoneList(@RequestParam Map<String, Object> paramMap) throws BusinessException {
        RequestMapperConvert.initParam(paramMap);
        String userUuids = paramMap.get("userUuids") == null ? null : (String)paramMap.get("userUuids");
        String userTradeStatusList = paramMap.get("userTradeStatusList") == null ? null : (String)paramMap.get("userTradeStatusList");
        String userVerifyStatusList = paramMap.get("userVerifyStatusList") == null ? null : (String)paramMap.get("userVerifyStatusList");
        if (userUuids != null) {
            List<String> uuids = splitData((String) paramMap.get("userUuids"));
            paramMap.put("userUuids", uuids);
        }
        if (userTradeStatusList != null) {
            List<String> tradeStatusList = splitData((String) paramMap.get("userTradeStatusList"));
            paramMap.put("tradeStatusList", tradeStatusList);
        }
        if (userVerifyStatusList != null) {
            List<String> verifyStatusList = splitData((String) paramMap.get("userVerifyStatusList"));
            paramMap.put("verifyStatusList", verifyStatusList);
        }
        List<String> ui = userInfoMapService.getInvestorMobilePhoneListWithFilter(paramMap);
        return new ResponseResult((String) paramMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", ui);
    }

    /**
     * 查找用户列表
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/investor/list", method = RequestMethod.GET)
    public ResponseResult getUerList(@RequestParam Map<String, Object> paramMap) throws BusinessException {
        RequestMapperConvert.initParam(paramMap);
        String userUuids = paramMap.get("userUuids") == null ? null : (String)paramMap.get("userUuids");
        String userTradeStatusList = paramMap.get("userTradeStatusList") == null ? null : (String)paramMap.get("userTradeStatusList");
        String userVerifyStatusList = paramMap.get("userVerifyStatusList") == null ? null : (String)paramMap.get("userVerifyStatusList");
        if (userUuids != null) {
            List<String> uuids = splitData((String) paramMap.get("userUuids"));
            paramMap.put("userUuids", uuids);
        }
        if (userTradeStatusList != null) {
            List<String> tradeStatusList = splitData((String) paramMap.get("userTradeStatusList"));
            paramMap.put("tradeStatusList", tradeStatusList);
        }
        if (userVerifyStatusList != null) {
            List<String> verifyStatusList = splitData((String) paramMap.get("userVerifyStatusList"));
            paramMap.put("verifyStatusList", verifyStatusList);
        }
        List<Map> ui = userInfoMapService.getInvestorListWithFilter(paramMap);
        return new ResponseResult((String) paramMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", ui);
    }

    /**
     * 查找用户列表
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/investor/list/mobiles", method = RequestMethod.GET)
    public ResponseResult getUerListByMobiles(@RequestParam Map<String, Object> paramMap) throws BusinessException {
        RequestMapperConvert.initParam(paramMap);
        String mobiles = paramMap.get("mobiles") == null ? null : (String)paramMap.get("mobiles");
        List<String> mobileList = Lists.newArrayList(Splitter.on("$$").trimResults().omitEmptyStrings().split(mobiles));
        paramMap.put("mobiles", mobileList);
        List<Map> ui = userInfoMapService.getInvestorListWithFilter(paramMap);
        return new ResponseResult((String) paramMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", ui);
    }


    /**
     * 根据条件获取分页总数,和list接口结合使用
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/investor/count", method = RequestMethod.GET)
    public ResponseResult getUerListCount(@RequestParam Map<String, Object> paramMap) throws BusinessException {
        RequestMapperConvert.initParam(paramMap);
        String userUuids = paramMap.get("userUuids") == null ? null : (String)paramMap.get("userUuids");
        String userTradeStatusList = paramMap.get("userTradeStatusList") == null ? null : (String)paramMap.get("userTradeStatusList");
        String userVerifyStatusList = paramMap.get("userVerifyStatusList") == null ? null : (String)paramMap.get("userVerifyStatusList");
        if (userUuids != null) {
            List<String> uuids = splitData((String) paramMap.get("userUuids"));
            paramMap.put("userUuids", uuids);
        }
        if (userTradeStatusList != null) {
            List<String> tradeStatusList = splitData((String) paramMap.get("userTradeStatusList"));
            paramMap.put("tradeStatusList", tradeStatusList);
        }
        if (userVerifyStatusList != null) {
            List<String> verifyStatusList = splitData((String) paramMap.get("userVerifyStatusList"));
            paramMap.put("verifyStatusList", verifyStatusList);
        }
        int count = userInfoMapService.getListCount(paramMap);
        return new ResponseResult((String) paramMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", count);
    }

    /**
     * 根据用户id获取用户信息
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/id/{userId}", method = RequestMethod.GET)
    public ResponseResult getUserById(@PathVariable("userId") String userId, @RequestParam("traceID") String traceId) throws BusinessException {
        Map<String, Object> user = userInfoMapService.getUserByUserId(userId);
        return new ResponseResult(traceId, ResponseCode.REQUEST_SUCCESS, "成功", user);
    }

    /**
     * 根据手机号查找用户信息
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/phone/{investorMobile}", method = RequestMethod.GET)
    public ResponseResult getUserByPhone(@PathVariable("investorMobile") String investorMobile, @RequestParam Map<String, Object> paramMap) throws BusinessException {
        LOGGER.info("getUserByPhone:investorMobile="+investorMobile);
        RequestMapperConvert.initParam(paramMap);
        paramMap.put(InvestorKeyConstants.INVESTOR_MOBILE_STR, investorMobile);
        Map ui = userInfoMapService.getUserByPhone(paramMap);
        LOGGER.info("getUserByPhone:ui="+ui);
        return new ResponseResult((String) paramMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", ui);
    }

    /**
     * 根据uuid 更新用户信息
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException {@link BusinessException} 业务封装异常
     */
    @RequestMapping(value = "/{userUuid}", method = RequestMethod.PUT)
    public ResponseResult updateUserByMap(@PathVariable("userUuid") String userUuid, @RequestBody Map<String, Object> userMap) throws BusinessException {
        RequestMapperConvert.initParam(userMap);
        userMap.put("userUuid", userUuid);
        int num = userInfoMapService.update(userMap);
        return new ResponseResult((String) userMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", num);
    }

    /**
     * 根据userId 更新用户信息用户认证状态（宝付回调）
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException {@link BusinessException} 业务封装异常
     */
    @RequestMapping(value = "/userAuthSuccess/{userId}", method = RequestMethod.PUT)
    public ResponseResult userAuthSuccess(@PathVariable("userId") String userId, @RequestBody Map<String, Object> userMap) throws BusinessException {
        RequestMapperConvert.initParam(userMap);
        userMap.put("userId", userId);
        int num = userInfoMapService.updateUserVerifyStatus(userMap);
        return new ResponseResult((String) userMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", num);
    }

    /**
     * 更新用户状态（绑卡）
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException {@link BusinessException} 业务封装异常
     */
    @RequestMapping(value = "/verifyStatus/{userUuid}", method = RequestMethod.PUT)
    public ResponseResult verifyStatus(@RequestBody Map<String, Object> userMap) throws BusinessException {
        RequestMapperConvert.initParam(userMap);
        int num = userInfoMapService.updateUserVerifyStatus(userMap);
        return new ResponseResult((String) userMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", num);
    }

    /**
     * 重置用户密码
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/resetUserPassword", method = RequestMethod.PUT)
    public ResponseResult resetUserPw(@RequestBody Map<String, Object> userMap) throws BusinessException {
        RequestMapperConvert.initParam(userMap);
        String userUuid = userInfoMapService.resetUserPassword(userMap);
        return new ResponseResult((String) userMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", userUuid);
    }

    /**
     * 重置交易密码
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/resetPayPassword", method = RequestMethod.PUT)
    public ResponseResult resetPayPw(@RequestBody Map<String, Object> userMap) throws BusinessException {
        RequestMapperConvert.initParam(userMap);
        //交易密码和登录密码在同一个服务修改。
        userInfoMapService.resetPayPassword(userMap);
        return new ResponseResult((String) userMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功");
    }

    /**
     * 初始化交易密码
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/initPayPassword", method = RequestMethod.PUT)
    public ResponseResult initPayPw(@RequestBody Map<String, Object> userMap) throws BusinessException {
        RequestMapperConvert.initParam(userMap);
        userInfoMapService.initPayPassword(userMap);
        return new ResponseResult((String) userMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功");
    }

    /**
     * 基金初始化交易密码
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/fund/initPayPassword", method = RequestMethod.PUT)
    public ResponseResult fundInitPayPw(@RequestBody Map<String, Object> userMap) throws BusinessException {
        RequestMapperConvert.initParam(userMap);
        int result = userInfoMapService.fundInitPayPassword(userMap);
        return new ResponseResult((String) userMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", result);
    }

    /**
     * 是否设置过交易密码
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/isInitPayPassword", method = RequestMethod.GET)
    public ResponseResult isPayPassword(@RequestParam("userUuid") String userUuid,
                                        @RequestParam(value = "traceID") String traceID) throws BusinessException {
        int result = userInfoMapService.isInitPayPassword(userUuid);
        return new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS, "成功", result);
    }

    /**
     * 更新用户认证状态
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/updateUserVerifyStatus", method = RequestMethod.PUT)
    public ResponseResult updateUserVerifyStatus(@RequestBody Map<String, Object> paramMap) throws BusinessException {
        RequestMapperConvert.initParam(paramMap);
        Map<String, Object> param = new HashMap();
        param.put("userId", paramMap.get("userId"));
        param.put("userUuid", paramMap.get("userUuid"));
        Map userMap = userInfoMapService.getInvestorWithFilter(param);
        if (StringUtils.isNotBlank(String.valueOf(paramMap.get("userVerifyStatus"))) && userMap.get("userVerifyStatus") != null) {
            if ((int) userMap.get("userVerifyStatus") <= Integer.parseInt((String) paramMap.get("userVerifyStatus"))) {
                param.put("userVerifyStatus", paramMap.get("userVerifyStatus"));

                return new ResponseResult((String) paramMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用");
            } else {
                return new ResponseResult((String) paramMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "警告：因为用户当前认证状态大于设置状态，所以状态没有发生改变");
            }
        }
        throw new BusinessException(UserParamMsg.REQUEST_PARAM_ERROR_CODE, UserParamMsg.REQUEST_PARAM_ERROR, true);
    }

    /**
     * 检查支付密码
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/checkPayPassword", method = RequestMethod.POST)
    public ResponseResult checkPayPw(@RequestBody Map<String, Object> paramMap) throws BusinessException {
        RequestMapperConvert.initParam(paramMap);
        Map<String, Object> result = userInfoMapService.checkPayPassword(paramMap);
        Integer errorTime = (Integer)result.get("errorCount");
        if (errorTime != null && errorTime < 6 ) {
            return new ResponseResult((String) paramMap.get("traceID"), UserParamMsg.PAY_PW_ERROR_CODE, UserParamMsg.PAY_PW_ERROR, result);
        } else if (errorTime != null && errorTime >= 6 ) {
            return new ResponseResult((String) paramMap.get("traceID"), UserParamMsg.PAY_PW_ERROR_OVERLOAD_CODE, UserParamMsg.PAY_PW_OVERLOAD_ERROR, result);
        } else {
            return new ResponseResult((String) paramMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", result);
        }
    }


    /**
     * 检查身份证
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/checkIdCard", method = RequestMethod.POST)
    public ResponseResult checkUserIdCard(@RequestBody Map<String, Object> paramMap) throws BusinessException {
        RequestMapperConvert.initParam(paramMap);
        userInfoMapService.checkIdCard(paramMap);
        return new ResponseResult((String) paramMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用");
    }

    /**
     * 获取认证信息
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/certification/{userUuid}", method = RequestMethod.GET)
    public ResponseResult getCertification(@PathVariable("userUuid") String userUuid,
                                           @RequestParam(value = "traceID") String traceID,
                                           @RequestParam(value = "userCertificationType", required = false) Integer userCertificationType) throws BusinessException {
        List<Map<String, Object>> certifications = userInfoMapService.getCertification(userUuid, userCertificationType);
        return new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS, "成功", certifications);
    }

    /**
     * 插入认证信息
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/certification", method = RequestMethod.POST)
    public ResponseResult getCertification(@RequestBody Map<String, Object> paramMap) throws BusinessException {
        int certification = userInfoMapService.insertCertification(paramMap);
        return new ResponseResult((String) paramMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", certification);
    }

    /**
     * 插入认证信息
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/risk", method = RequestMethod.GET)
    public ResponseResult getRisk(@RequestParam("userUuid") String userUuid,
                                  @RequestParam(value = "traceID") String traceID) throws BusinessException {
        String result = userInfoMapService.getInvestorRisk(userUuid);
        return new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS, "成功", result);
    }

    /**
     * 插入认证信息
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/exist", method = RequestMethod.GET)
    public ResponseResult exist(@RequestParam("userIdCardNumber") String userIdCardNumber,
                                  @RequestParam(value = "traceID") String traceID) throws BusinessException {
        Integer result = userInfoMapService.exist(userIdCardNumber);
        return new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS, "成功", result);
    }


    /**
     * 从星耀注册金疙瘩
     *
     * @param paramMap
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/xyRegisterKingold", method = RequestMethod.POST)
    public ResponseResult xyRegisterKingold(@RequestBody Map<String, Object> paramMap) throws BusinessException {
        Map map = userInfoMapService.xyRegisterKingold(paramMap);
        return new ResponseResult((String) paramMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", map);
    }

    /**
     * 更新用户交易状态
     *
     * @param userUuid
     * @param param
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/{userUuid}/updateTradeStatus", method = RequestMethod.PUT)
    public ResponseResult updateTradeStatus(@PathVariable("userUuid") String userUuid,
                                            @RequestBody UpdateTradeStatusDTO param) throws BusinessException {
        param.setUserStatus(UserTradeStatus.FIXI_ORDER_PAID_COMPLETE);
        int num = userInfoMapService.updateTradeStatus(userUuid, param);
        return new ResponseResult(param.getTraceID(), ResponseCode.REQUEST_SUCCESS, "成功", num);
    }


    private List<String> splitData(String data) {
        String[] datas = data.split("\\$\\$");
        return  Arrays.asList(datas);
    }


}
