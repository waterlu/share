package cn.zjhf.kingold.user.persistence.mq.message;

import cn.zjhf.kingold.rocketmq.base.MQMessage;

/**
 * 用户绑卡消息
 *
 * Created by 王勋
 */
public class UserBindCardMessage implements MQMessage {
    private String userUuid;

    private String investorMobile;

    private String userName;

    private String merchantNum;

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getInvestorMobile() {
        return investorMobile;
    }

    public void setInvestorMobile(String investorMobile) {
        this.investorMobile = investorMobile;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getMerchantNum() {
        return merchantNum;
    }

    public void setMerchantNum(String merchantNum) {
        this.merchantNum = merchantNum;
    }

    @Override
    public String getKey() {
        return userUuid;
    }
}
