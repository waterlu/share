package cn.zjhf.kingold.user.persistence.mq.message;

import cn.zjhf.kingold.rocketmq.base.MQMessage;

/**
 * 用户注册成功消息
 *
 *
 * Created by lutiehua on 2017/7/14.
 */
public class UserMessage implements MQMessage {
    private String userUuid;

    private String investorMobile;

    private String inviterUuid;

    private String registerChannelCode;

    private String merchantNum;

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getInvestorMobile() {
        return investorMobile;
    }

    public void setInvestorMobile(String investorMobile) {
        this.investorMobile = investorMobile;
    }

    public String getInviterUuid() {
        return inviterUuid;
    }

    public void setInviterUuid(String inviterUuid) {
        this.inviterUuid = inviterUuid;
    }

    public String getRegisterChannelCode() {
        return registerChannelCode;
    }

    public void setRegisterChannelCode(String registerChannelCode) {
        this.registerChannelCode = registerChannelCode;
    }

    public String getMerchantNum() {
        return merchantNum;
    }

    public void setMerchantNum(String merchantNum) {
        this.merchantNum = merchantNum;
    }

    @Override
    public String getKey() {
        return userUuid;
    }

    @Override
    public String toString() {
        return "UserMessage{" +
                "userUuid='" + userUuid + '\'' +
                ", investorMobile='" + investorMobile + '\'' +
                ", inviterUuid='" + inviterUuid + '\'' +
                ", registerChannelCode='" + registerChannelCode + '\'' +
                ", merchantNum='" + merchantNum + '\'' +
                '}';
    }
}
