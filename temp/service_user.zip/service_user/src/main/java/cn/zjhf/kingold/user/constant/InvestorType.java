package cn.zjhf.kingold.user.constant;

/**
 * Created by liuyao on 17/3/20.
 */

public class InvestorType {

    //专职理财师
    public static final int PROFESSION_INVESTOR = 19;
    //普通理财师
    public static final int COMMON_INVESTOR = 11;
    //理财达人
    public static final int MONEY_MANAGE_TALENT = 12;

}

