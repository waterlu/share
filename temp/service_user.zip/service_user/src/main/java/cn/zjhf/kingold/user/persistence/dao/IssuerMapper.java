package cn.zjhf.kingold.user.persistence.dao;

import org.springframework.stereotype.Repository;

import java.util.Map;

/**
 * Created by liuyao on 2017/6/30.
 */

@Repository
public interface IssuerMapper {
    Map<String, Object> get(Map param);
}
