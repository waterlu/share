package cn.zjhf.kingold.user.persistence.dao;

import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * Created by liuyao on 2017/5/11.
 */
@Repository
public interface InvestorMapper {
    int insert(Map record);

    Map get(Map params);

    Integer count(Map params);

    int update(Map investorInfo);

    List<Map> getList(Map params);

}
