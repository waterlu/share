package cn.zjhf.kingold.user.constant;

/**
 * 企业投资者对象字段名字
 * @author liuyao
 * @create 2017-08-18 13:45
 **/
public class EnterpriseKeyConstants {
    public static final String USER_UUID_STR = "userUuid";
    public static final String USER_ISSUER_NAME_STR = "enterpriseName";
    public static final String LEGAL_PERSON_MOBILE_STR = "legalPersonMobile";
    public static final String LEGAL_PERSON_ID_CARD_STR = "legalPersonIdCardNo";



}
