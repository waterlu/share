package cn.zjhf.kingold.user.persistence.dao;

import cn.zjhf.kingold.user.entity.InvestorChangeLog;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface InvestorChangeLogMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(InvestorChangeLog record);

    int insertSelective(InvestorChangeLog record);

    InvestorChangeLog selectByPrimaryKey(Integer id);

    InvestorChangeLog selectByUserUuid(String userUuid);


    int updateByPrimaryKeySelective(InvestorChangeLog record);

    int updateByPrimaryKey(InvestorChangeLog record);
}