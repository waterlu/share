package cn.zjhf.kingold.user.service.impl;

import cn.zjhf.kingold.user.entity.UserFeedback;
import cn.zjhf.kingold.user.persistence.dao.UserFeedbackMapper;
import cn.zjhf.kingold.user.service.IUserFeedbackService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/**
 * Created by liuyao on 2017/8/24.
 */
@Service
public class UserFeedbackServiceImpl implements IUserFeedbackService {
    private static final Logger LOGGER = LoggerFactory.getLogger(UserFeedbackServiceImpl.class);

    @Autowired
    public UserFeedbackMapper userFeedbackMapper;

    @Override
    public int create(UserFeedback userFeedback) {
        return userFeedbackMapper.insert(userFeedback);
    }
}