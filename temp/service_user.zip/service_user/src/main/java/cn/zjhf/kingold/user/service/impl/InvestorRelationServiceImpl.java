package cn.zjhf.kingold.user.service.impl;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.service_consumer.service.TradeServiceConsumer;
import cn.zjhf.kingold.user.constant.*;
import cn.zjhf.kingold.user.constant.InvestorKeyConstants;
import cn.zjhf.kingold.user.constant.InvestorRelationKeyConstants;
import cn.zjhf.kingold.user.constant.InvestorType;
import cn.zjhf.kingold.user.entity.InvestorMobileContact;
import cn.zjhf.kingold.user.entity.UserWechatHist;
import cn.zjhf.kingold.user.persistence.dao.InvestorMapper;
import cn.zjhf.kingold.user.persistence.dao.InvestorMobileContactMapper;
import cn.zjhf.kingold.user.persistence.dao.InvestorRelationMapper;
import cn.zjhf.kingold.user.service.IInvestorRelationService;
import cn.zjhf.kingold.user.service.IUserService;
import cn.zjhf.kingold.user.service.IUserWechatHistService;
import cn.zjhf.kingold.user.utils.MapParamUtils;
import cn.zjhf.kingold.user.utils.UserPropertiesUtils;
import cn.zjhf.kingold.user.utils.UtilTools;
import com.google.common.base.Function;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import org.apache.commons.collections4.map.HashedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;


/**
 * Created by Xiaody on 17/6/7.
 */
@Service
public class InvestorRelationServiceImpl implements IInvestorRelationService {

    @Autowired
    private InvestorRelationMapper investorRelationMapper;

    @Autowired
    private IUserService userService;

    @Autowired
    private InvestorMapper investorMapper;

    @Autowired
    private InvestorMobileContactMapper investorMobileContactMapper;

    @Autowired
    IUserWechatHistService userWechatHistService;

    @Autowired
    private TradeServiceConsumer tradeServiceConsumer;

    private final static BigDecimal ZERO_NUMBER = new BigDecimal(0).setScale(2, BigDecimal.ROUND_DOWN);

    private final Logger LOGGER = LoggerFactory.getLogger(InvestorRelationServiceImpl.class);

    /**
     * 获取用户关系信息
     * @param userUuid
     * @return
     * @throws BusinessException
     */
    @Override
    public Map getInvestorRelation(String userUuid) throws BusinessException {
        Map<String, Object> relation =  investorRelationMapper.get(userUuid);
        if (relation == null || relation.get(InvestorRelationKeyConstants.TOP_UUID_STR) == null) {
            Map<String, Object> params = new HashMap<>();
            params.put(InvestorKeyConstants.USER_UUID_STR, userUuid);
            Map investor = userService.getUser(params, false);
            if (investor.get(InvestorKeyConstants.INVESTOR_TYPE_BYTE) != null &&
                    Integer.valueOf(investor.get(InvestorKeyConstants.INVESTOR_TYPE_BYTE).toString()) == InvestorType.PROFESSION_INVESTOR) {
                if (relation == null) {
                    relation = new HashMap<>();
                }
                relation.put(InvestorRelationKeyConstants.TOP_UUID_STR, userUuid);
            }
        }
        return UserPropertiesUtils.buildUserData(relation);
    }

    /**
     * 同时获取自己好友用户数量
     *
     * @param map
     * @return
     * @throws BusinessException
     */
    @Override
    public Map getRelationCount(Map map) throws BusinessException {
        String userUuid = map.remove("userUuid").toString();
        //查询一级邀请用户的数量
        map.put("inviterLevelOneUuid", userUuid);
        Integer levelOneCount = investorRelationMapper.getCount(map);
        //查询二级邀请用户的数量
        map.remove("inviterLevelOneUuid");
        map.put("inviterLevelTwoUuid", userUuid);
        Integer levelTwoCount = investorRelationMapper.getCount(map);
        //查询三级邀请用户的数量
        map.remove("inviterLevelTwoUuid");
        map.put("inviterLevelThreeUuid", userUuid);
        Integer levelThreeCount = investorRelationMapper.getCount(map);

        Map retMap = new HashMap();
        retMap.put("levelOneCount", levelOneCount);
        retMap.put("levelTwoCount", levelTwoCount);
        retMap.put("levelThreeCount", levelThreeCount);
        return retMap;
    }

    /**
     * 同时获取自己好友用户
     *
     * @param map
     * @return
     * @throws BusinessException
     */
    @Override
    public List<Map> getRelationList(Map map) throws BusinessException {
        List<String> userUuids = investorRelationMapper.getAllRelation(map);
        if (CollectionUtils.isEmpty(userUuids)) {
            return Collections.EMPTY_LIST;
        }
        Map<String, Object> params = new HashMap<>();
        params.put("userUuids", userUuids);
        params.put("pageNo", 1);
        params.put("pageSize", 10000);
        List<Map> users = userService.getInvestorListWithFilter(params);
        return users;
    }

    /**
     * 根据查询条件获取自己一级邀请或者二级邀请的用户信息
     *
     * @param map
     * @return
     * @throws BusinessException
     */
    @Override
    public List<Map> getList(Map map) throws BusinessException {
        List<Map> relationList = investorRelationMapper.getList(map);
        List<String> userUuids = new ArrayList<>();
        relationList.forEach(relation -> userUuids.add(relation.get("userUuid").toString()));
        if(userUuids.size()==0){
            return new ArrayList<>();
        }
        Map userMap = new HashMap();
        userMap.put("userUuids", userUuids);
        userMap.put("orderBy"," register_time desc");
        return userService.getInvestorListWithFilter(userMap);
    }

    /**
     * 根据查询条件获取自己一级邀请或者二级邀请的用户信息
     *
     * @param map
     * @return
     * @throws BusinessException
     */
    @Override
    public Integer getCount(Map map) throws BusinessException {
        return investorRelationMapper.getCount(map);
    }

    @Override
    public List<Map> getRelationOpenid(Map map) throws BusinessException {
        return investorRelationMapper.getRelationOpenid(map);
    }

    @Override
    public Map getRelationByMobile(Map map) throws BusinessException{
        LOGGER.info("getRelationByMobile start:{}",map);
        Map responseMap = new HashedMap();
        //1.获取投资人信息
        Map investorMap = investorMapper.get(map);
        if (investorMap == null){
            throw new BusinessException(ResponseCode.PARAM_ERROR, "没有该用户!");
        }
        String investorMobile = investorMap.get("investorMobile") == null ? null : investorMap.get("investorMobile").toString();
        responseMap.put("investorMobile", investorMobile == null ? null : UtilTools.encryptMobile(investorMobile));
        responseMap.put("investorRealName", investorMap.get("investorRealName"));
        //2.上三级邀请人
        List<Map> upThreeInvestorList = investorRelationMapper.getUpThreeInvestor(map);
        upThreeInvestorList.forEach(upThreeMap->upThreeMap.put("investorMobile", UtilTools.encryptMobile(upThreeMap.get("investorMobile").toString())));
        responseMap.put("upThreeInvestorList", upThreeInvestorList);

        //金银铜好友数量
        String userUuid = investorMap.get("userUuid").toString();
        int goldCount = investorRelationMapper.getGoldCount(userUuid);
        int silverCount = investorRelationMapper.getSilverCount(userUuid);
        int copperCount = investorRelationMapper.getCopperCount(userUuid);
        responseMap.put("goldCount",goldCount);
        responseMap.put("silverCount",silverCount);
        responseMap.put("copperCount",copperCount);

        //4.下级好友列表及下级好友的下级数量
        Integer pageNo = (map.get("pageNo") == null ? 1 : Integer.valueOf(map.get("pageNo").toString()));
        Integer pageSize = (map.get("pageSize") == null ? 20 : Integer.valueOf(map.get("pageSize").toString()));
        Map param = new HashedMap();
        param.put("startRow", (pageNo - 1) * pageSize);
        param.put("pageSize", pageSize);
        param.put("userUuid", investorMap.get("userUuid"));
        List<Map> downOneInvestorList = investorRelationMapper.getDownOneInvestor(param);
        int downOneInvestorCount = investorRelationMapper.getDownOneInvestorCount(param);
        downOneInvestorList.forEach(downOneMap->downOneMap.put("investorMobile", UtilTools.encryptMobile(downOneMap.get("investorMobile").toString())));
        responseMap.put("downOneInvestorList", downOneInvestorList);
        responseMap.put("downOneInvestorCount", downOneInvestorCount);
        LOGGER.info("getRelationByMobile end: investorMobile={} goldCount={} silverCount={} copperCount={} downOneInvestorCount={}",investorMobile,goldCount,silverCount,copperCount,downOneInvestorCount);
        return responseMap;
    }


    @Override
    public Map getRelationSortByTime(Map map) throws BusinessException{
        String levelOneUuid = MapParamUtils.getStringInMap(map, InvestorRelationKeyConstants.INVITER_LEVEL_ONE_UUID_STR);
        int count = getCount(map);
        if (count <=0) {
            return Collections.EMPTY_MAP;
        }
        List<Map> relationList = getList(map);
        String invitedUserUuidList = "";
        for (Map one : relationList) {
            invitedUserUuidList = invitedUserUuidList + MapParamUtils.getStringInMap(one, UserKeyConstants.USER_UUID_STR) + "$$";
        }

        //获取好友贡献的奖励列表
        map.put("invitedUuids", invitedUserUuidList);
        map.put("userUuid", levelOneUuid);
        ResponseResult orderResult = tradeServiceConsumer.get(UrlConstant.URL_TRADE_GET_REWARD_SUM_BY_INVITED_UUIDS, map);
        if (!orderResult.isSuccessful()) {
            throw new BusinessException(orderResult.getCode(), orderResult.getMsg(), true);
        }

        //组装好友的奖励数据
        Map<String, BigDecimal> rewardMap = (Map<String, BigDecimal>) orderResult.getData();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-M-d");
        for (Map one : relationList) {
            String friendUuid = MapParamUtils.getStringInMap(one, UserKeyConstants.USER_UUID_STR);
            one.put(UserKeyConstants.REGISTER_TIME_DATE, dateFormat.format((Date)one.get(UserKeyConstants.REGISTER_TIME_DATE)));
            one.put("rewardTotal", ZERO_NUMBER);
            if (rewardMap.containsKey(friendUuid)) {
                one.put("rewardTotal", rewardMap.get(friendUuid).setScale(2, BigDecimal.ROUND_DOWN));
            }
        }
        Map<String, Object> result = new HashMap<>();
        result.put("list", relationList);
        result.put("count", count);
        return result;
    }

    @Override
    public Map getRelationSortByReward(Map sourceParam) throws BusinessException{
        String levelOneUuid = MapParamUtils.getStringInMap(sourceParam, InvestorRelationKeyConstants.INVITER_LEVEL_ONE_UUID_STR);
        int count = getCount(sourceParam);
        if (count <=0) {
            return Collections.EMPTY_MAP;
        }

        //获取好友奖励列表，根据好友奖励贡献排序
        Map<String, Object> rewardParam = new HashMap<>();
        rewardParam.put(UserKeyConstants.USER_UUID_STR, levelOneUuid);
        rewardParam.put("startRow", MapParamUtils.getIntInMap(sourceParam, "startRow"));
        rewardParam.put("pageSize", MapParamUtils.getIntInMap(sourceParam, "pageSize"));
        rewardParam.put("isInvest", MapParamUtils.getIntInMap(sourceParam, "isInvest"));

        ResponseResult orderResult = tradeServiceConsumer.get(UrlConstant.URL_TRADE_GET_REWARD_LIST_ORDER_BY_SUM, rewardParam);
        if (!orderResult.isSuccessful()) {
            throw new BusinessException(orderResult.getCode(), orderResult.getMsg(), true);
        }
        List<Map> rewardList = (List<Map>) orderResult.getData();
        List<String> userUuids = new ArrayList<>();
        for (Map reward : rewardList) {
            userUuids.add(MapParamUtils.getStringInMap(reward, "beInvitedUserUuid"));
        }
        Map<String, Object> userListParam = new HashMap<>();
        if (userUuids.size() > 0) {
            userListParam.put("userUuids", userUuids);
        }
        //补充好友信息
        List<Map> userList = userService.getInvestorListWithFilter(userListParam);
        Map<String,Map> userMap = Maps.uniqueIndex(userList, user -> MapParamUtils.getStringInMap(user, UserKeyConstants.USER_UUID_STR));
        for (Map reward : rewardList) {
            String invitedUuid = MapParamUtils.getStringInMap(reward, "beInvitedUserUuid");
            if (userMap.containsKey(invitedUuid)) {
                reward.putAll(userMap.get(invitedUuid));
            }
        }

        //补充不足一页剩余数据
        if (rewardList.size() < MapParamUtils.getIntInMap(sourceParam, "pageSize") &&
                MapParamUtils.getIntInMap(sourceParam, UserKeyConstants.USER_TRADE_STATUS_INT) != UserTradeStatus.FIXI_ORDER_PAID_COMPLETE) {
            Map<String, Object> supplyParam = buildSupplyRelationParam(levelOneUuid,rewardList.size(), sourceParam);
            List<Map> supplyList = getList(supplyParam);
            rewardList.addAll(supplyList);
        }

        //组装好友的奖励数据
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        for (Map one : rewardList) {
            one.put(UserKeyConstants.REGISTER_TIME_DATE, dateFormat.format((Date)one.get(UserKeyConstants.REGISTER_TIME_DATE)));
            if (!one.containsKey("rewardTotal")) {
                one.put("rewardTotal", ZERO_NUMBER);
            }
        }
        Map<String, Object> result = new HashMap<>();
        result.put("list", rewardList);
        result.put("count", count);
        return result;
    }

    private Map buildSupplyRelationParam(String levelOneUserUuid, int rewardLen, Map sourceParam) throws BusinessException {
        Map<String, Object> relationParam = new HashMap<>();
        relationParam.put(UserKeyConstants.USER_TRADE_STATUS_INT, UserTradeStatus.FIXI_ORDER_PAID_COMPLETE);
        relationParam.put(InvestorRelationKeyConstants.INVITER_LEVEL_ONE_UUID_STR, levelOneUserUuid);
        Integer investCount = getCount(relationParam);
        int reqStartRow = MapParamUtils.getIntInMap(sourceParam, "startRow");
        int reqPageSize = MapParamUtils.getIntInMap(sourceParam, "pageSize");
        int dbStartRow = 0;
        if (reqStartRow - investCount > 0) {
            dbStartRow = reqStartRow - investCount;
        }
        int dbPageSize = reqPageSize - rewardLen;
        Map<String, Object> supplyParam = new HashMap<>();
        supplyParam.put("startRow", dbStartRow);
        supplyParam.put("pageSize", dbPageSize);
        supplyParam.put(UserKeyConstants.USER_TRADE_STATUS_INT, UserTradeStatus.RECHARGE_COMPLETE);
        supplyParam.put(InvestorRelationKeyConstants.INVITER_LEVEL_ONE_UUID_STR, levelOneUserUuid);
        return supplyParam;
    }

    @Override
    public List<Map> getDownOneInvestor(Map map){
        return investorRelationMapper.getDownOneInvestor(map);
    }

    @Override
    public int getDownOneInvestorCount(Map map){
        return investorRelationMapper.getDownOneInvestorCount(map);
    }

    /**
     * 保存通讯录
     *
     * @return
     * @throws BusinessException
     */
    @Override
    public int saveContact(List<InvestorMobileContact> contactList){
        Iterator<InvestorMobileContact> it = contactList.iterator();
        while (it.hasNext()) {
            InvestorMobileContact contact = it.next();
            if (UtilTools.containsEmoji(contact.getContactName())) {
                it.remove();
            }
        }
        return investorMobileContactMapper.batchInsert(contactList);
    }

    /**
     * 获取用户关系下 父亲，儿子，自己的头像和昵称。如果没有昵称用实名，没有实名用电话
     * @param map userUuid是必填项。startRow 开始项，pageSize 每页显示数量
     * @return
     * @throws BusinessException
     */
    @Override
    public List<UserWechatHist> getFatherAndSonAndSelfList(Map map) throws BusinessException {

        if(org.apache.commons.lang3.StringUtils.isBlank(MapParamUtils.getStringInMap(map,"userUuid"))  ){
            throw new BusinessException(UserParamMsg.REQUEST_PARAM_ERROR_CODE, "参数 userUuid 不能为空！", true);
        }

        List<UserWechatHist> resultList = new ArrayList<>();
        List<Map>  investRelationList = investorRelationMapper.getFatherAndSonAndSelfList(map);
        String userUuids = "";
        for(Map investRelation : investRelationList){
            userUuids = userUuids + "," + MapParamUtils.getStringInMap(investRelation,"userUuid");
        }
        Map userWechatHistParams = new HashMap();
        userWechatHistParams.put("userUuids",userUuids);
        List<UserWechatHist> userWechatHistList = userWechatHistService.getList(userWechatHistParams);
        for(Map investRelation : investRelationList){
            for(UserWechatHist userWechatHist : userWechatHistList){
                if(MapParamUtils.getStringInMap(investRelation,"userUuid").equals(userWechatHist.getUserUuid())){
                    resultList.add(userWechatHist);
                    break;
                }
            }
        }
        return resultList;
    }

}
