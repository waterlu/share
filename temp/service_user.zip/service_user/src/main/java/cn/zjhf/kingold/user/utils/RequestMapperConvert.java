package cn.zjhf.kingold.user.utils;

import cn.zjhf.kingold.common.utils.MapRemoveNullUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by wangxun on 2017/4/19.
 */
public class RequestMapperConvert {

    /**
     * 对params参数中增加一些标准数据
     * <p>
     * 注意： 此方法会将所有params中的value修改成string类型。所以禁止直接将不能转化成string类型的value作为参数。
     *
     * @param params
     */
    public static void initParam(Map<String, Object> params) {
        //修改所有params中value为字符串
        for (String key : params.keySet()) {
            Object value = params.get(key);
            if (value != null) {
                params.put(key, value.toString());
            }
        }

        //设置分页默认值
        if (params.get("pageSize") == null) {
            params.put("pageSize", 20);
        }
        if (params.get("startRow") == null) {
            params.put("startRow", 0);
        }

    }


    public static void initBankInfoParam(Map params) {

        String userUuid = (String) params.get("userUuid");
        if (StringUtils.isNotBlank(userUuid)) {
            List<String> userUuidList = Arrays.asList(userUuid.split("\\$\\$"));
            params.put("userUuidList", userUuidList);
        }
    }

    public static void initAdvisorRelationParam(Map params) {

        String userUuid = (String) params.get("userUuid");
        if (StringUtils.isNotBlank(userUuid)) {
            List<String> userUuidList = Arrays.asList(userUuid.split("\\$\\$"));
            params.put("userUuidList", userUuidList);
        }

    }

    public static void initAdvisorParam(Map params) {
        String userUuid = (String) params.get("userUuid");
        if (StringUtils.isNotBlank(userUuid)) {
            List<String> userUuidList = Arrays.asList(userUuid.split("\\$\\$"));
            params.put("userUuidList", userUuidList);
        }
    }
}


