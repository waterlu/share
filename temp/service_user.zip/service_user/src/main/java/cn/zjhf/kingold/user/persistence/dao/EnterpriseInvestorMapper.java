package cn.zjhf.kingold.user.persistence.dao;

import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * Created by liuyao on 2017/8/22.
 */

@Repository
public interface EnterpriseInvestorMapper {
    Map<String, Object> get(Map param);

    List<Map> getList(Map param);

}
