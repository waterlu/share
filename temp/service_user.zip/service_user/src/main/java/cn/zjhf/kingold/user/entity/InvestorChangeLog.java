package cn.zjhf.kingold.user.entity;

import java.util.Date;

public class InvestorChangeLog {
    private Integer id;

    private String userUuid;

    private Integer beforeUserType;

    private Integer afterUserType;

    private Integer changeType;

    private String changeReason;

    private Byte deleteFlag;

    private Date createTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid == null ? null : userUuid.trim();
    }

    public Integer getBeforeUserType() {
        return beforeUserType;
    }

    public void setBeforeUserType(Integer beforeUserType) {
        this.beforeUserType = beforeUserType;
    }

    public Integer getAfterUserType() {
        return afterUserType;
    }

    public void setAfterUserType(Integer afterUserType) {
        this.afterUserType = afterUserType;
    }

    public Integer getChangeType() {
        return changeType;
    }

    public void setChangeType(Integer changeType) {
        this.changeType = changeType;
    }

    public String getChangeReason() {
        return changeReason;
    }

    public void setChangeReason(String changeReason) {
        this.changeReason = changeReason == null ? null : changeReason.trim();
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}