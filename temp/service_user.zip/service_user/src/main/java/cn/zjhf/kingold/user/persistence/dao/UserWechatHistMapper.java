package cn.zjhf.kingold.user.persistence.dao;

import cn.zjhf.kingold.user.entity.UserWechatHist;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * @Author xiaody
 * @Description
 * @Date create in 17/10/30
 */
@Repository
public interface UserWechatHistMapper {

    int insert(Map userWechatHist);

    int update(Map userWechatHist);


    List<UserWechatHist> getList(Map params);

}