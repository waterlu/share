package cn.zjhf.kingold.user.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.user.persistence.dao.UserTokenMapper;
import cn.zjhf.kingold.user.service.IUserTokenService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Created by wangxun on 2016/11/04.
 * Copyright by zjinv
 */
@Service
public class UserTokenServiceImpl implements IUserTokenService {
    private static final Logger LOGGER = LoggerFactory.getLogger(UserTokenServiceImpl.class);
    @Autowired
    private UserTokenMapper userTokenMapper;

    @Value("${system.run.model}")
    public String runModel ;

    @Value("${app.admin.verify.code}")
    public String adminVerifyCode;


    @Autowired
    StringRedisTemplate stringRedisTemplate;




    @Override
    public Map get(Map params) throws BusinessException {

        Map ui = userTokenMapper.get(params);
        return ui;
    }

    @Override
    public int insert(Map params) throws BusinessException {

        return userTokenMapper.insert(params);

    }

    @Override
    public int update( Map params) throws BusinessException {
        return userTokenMapper.update(params);
    }

    @Override
    public Integer delete(Map params) throws BusinessException {
        int num = userTokenMapper.delete(params);
        return num;
    }

    @Override
    public List<Map> getList(Map userMap) throws BusinessException {

        List<Map> userList = userTokenMapper.getList(userMap);

        return userList;
    }

    @Override
    public int getCount(Map userMap) throws BusinessException {

        return userTokenMapper.getCount(userMap);

    }

    @Override
    public int logout(Map paramMap) throws BusinessException {
        List<Map> userTokenList = userTokenMapper.getList(paramMap);
        int resultNum = 0;
        for(Map map : userTokenList){
            String token = (String)map.get("token");
            if(StringUtils.isNotBlank(token) ){
                LOGGER.info("remove token:"+token);
                //清除 redis token
                stringRedisTemplate.delete(token);
                resultNum++;
            }
        }
        delete(paramMap);
        return resultNum;
    }


}