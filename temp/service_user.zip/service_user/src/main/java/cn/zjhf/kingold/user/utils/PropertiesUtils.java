package cn.zjhf.kingold.user.utils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by RenXiongchang on 2016/11/8.
 * Copyright by mofanghr
 */
public class PropertiesUtils {

    /**
     * 获取需要的属性
     *
     * @param sourceMap  源属性
     * @param properties 需要的属性列表
     * @return 需要的属性
     */
    public static Map getNeedProperties(Map sourceMap, List properties) {

        if (properties != null && properties.size() > 0) {
            if (sourceMap != null) {
                Map needMap = new HashMap<>();
                //只返回需要的属性
                for (Object property : properties) {
                    if (null != sourceMap.get(property)) {
                        needMap.put(property, sourceMap.get(property));
                    }
                }
                return needMap;
            } else {
                return null;
            }
        } else {
            return sourceMap;
        }
    }



}
