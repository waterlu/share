package cn.zjhf.kingold.user.entity;

import org.hibernate.validator.constraints.NotEmpty;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */

public class Advisor implements Serializable {
    /**
     * 自增ID
     */
    private Long advisorId;

    /**
     * 用户主表UUID
     */
    @NotEmpty
    private String userUuid;


    /**
     * 投资人手机号码
     */
    @NotEmpty
    private String advisorMobile;

    /**
     * 性别 男0 女1
     */
    private Byte advisorGender;

    /**
     * 头像
     */
    private String advisorAvatar;

    /**
     * 理财师类型 投资人类型（11普通投资人 12理财顾问 19专职理财师）
     */
    private Byte advisorType;

    /**
     * 是否公司内部投资者
     */
    private Byte isInner;

    /**
     * 上一级邀请人理财师UUID
     */
    private String inviterUuid;

    /**
     * 用户真实姓名
     */
    private String advisorRealName;

    /**
     * 用户身份证号码
     */
    private String advisorIdCardNo;

    /**
     * 用户所在地区编码
     */
    private String advisorRegionCode;

    /**
     * 用户详细住址
     */
    private String advisorAddress;

    /**
     * 是否合格投资者
     */
    private Byte isEligibleAdvisor;

    /**
     * 风险评测版本
     */
    private Integer advisorRiskVersion;

    /**
     * 风险评测等级
     */
    private Integer advisorRiskScore;

    /**
     * 风险评测结果
     */
    private String advisorRiskAnswer;

    /**
     * 邀请码
     */
    private String advisorInviteCode;

    /**
     * 数据签名
     */
    private String signature;

    /**
     * 删除标记
     */
    @NotEmpty
    private Byte deleteFlag;

    /**
     * 创建时间
     */
    @NotEmpty
    private Date createTime;

    /**
     * 更新时间
     */
    @NotEmpty
    private Date updateTime;

    /**
     * 是否专职 
     */
    private Byte isFullTime;

    /**
     * 是否客服
     */
    private Byte isCustomerService;

    /**
     * 邀请人手机号
     */
    private String inviterMobile;

    /**
     * 银行卡号
     */
    private String bankCardNo;

    /**
     * 开户行
     */
    private String bankName;

    /**
     * 开户行所在地
     */
    private String bankAddress;

    /**
     * 开户支行
     */
    private String bankSubbranch;

    /**
     * 实名认证状态  未认证0 已实名认证1  已名片认证2 认证通过3 认证失败9
     */
    private Byte advisorAuthStatus;

    /**
     * 名片url
     */
    private String advisorWorkCardUrl;
    /**
     * 数据来源
     */
    private String advisorSource;

    /**
     * 状态 正常0 冻结1
     */
    private Byte advisorStatus;

    /**
     * 数据拥有者组织路径
     */
    private String dataOrgPath;

    /**
     * 数据拥有者uuid
     */
    private String dataUuid;

    private static final long serialVersionUID = 1L;


    public Byte getAdvisorType() {
        return advisorType;
    }

    public void setAdvisorType(Byte advisorType) {
        this.advisorType = advisorType;
    }

    public Long getAdvisorId() {
        return advisorId;
    }

    public void setAdvisorId(Long advisorId) {
        this.advisorId = advisorId;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }


    public String getAdvisorMobile() {
        return advisorMobile;
    }

    public void setAdvisorMobile(String advisorMobile) {
        this.advisorMobile = advisorMobile;
    }

    public Byte getAdvisorGender() {
        return advisorGender;
    }

    public void setAdvisorGender(Byte advisorGender) {
        this.advisorGender = advisorGender;
    }

    public String getAdvisorAvatar() {
        return advisorAvatar;
    }

    public void setAdvisorAvatar(String advisorAvatar) {
        this.advisorAvatar = advisorAvatar;
    }

    public Byte getIsInner() {
        return isInner;
    }

    public void setIsInner(Byte isInner) {
        this.isInner = isInner;
    }

    public String getInviterUuid() {
        return inviterUuid;
    }

    public void setInviterUuid(String inviterUuid) {
        this.inviterUuid = inviterUuid;
    }

    public String getAdvisorRealName() {
        return advisorRealName;
    }

    public void setAdvisorRealName(String advisorRealName) {
        this.advisorRealName = advisorRealName;
    }

    public String getAdvisorIdCardNo() {
        return advisorIdCardNo;
    }

    public void setAdvisorIdCardNo(String advisorIdCardNo) {
        this.advisorIdCardNo = advisorIdCardNo;
    }

    public String getAdvisorRegionCode() {
        return advisorRegionCode;
    }

    public void setAdvisorRegionCode(String advisorRegionCode) {
        this.advisorRegionCode = advisorRegionCode;
    }

    public String getAdvisorAddress() {
        return advisorAddress;
    }

    public void setAdvisorAddress(String advisorAddress) {
        this.advisorAddress = advisorAddress;
    }

    public Byte getIsEligibleAdvisor() {
        return isEligibleAdvisor;
    }

    public void setIsEligibleAdvisor(Byte isEligibleAdvisor) {
        this.isEligibleAdvisor = isEligibleAdvisor;
    }

    public Integer getAdvisorRiskVersion() {
        return advisorRiskVersion;
    }

    public void setAdvisorRiskVersion(Integer advisorRiskVersion) {
        this.advisorRiskVersion = advisorRiskVersion;
    }

    public Integer getAdvisorRiskScore() {
        return advisorRiskScore;
    }

    public void setAdvisorRiskScore(Integer advisorRiskScore) {
        this.advisorRiskScore = advisorRiskScore;
    }

    public String getAdvisorRiskAnswer() {
        return advisorRiskAnswer;
    }

    public void setAdvisorRiskAnswer(String advisorRiskAnswer) {
        this.advisorRiskAnswer = advisorRiskAnswer;
    }

    public String getAdvisorInviteCode() {
        return advisorInviteCode;
    }

    public void setAdvisorInviteCode(String advisorInviteCode) {
        this.advisorInviteCode = advisorInviteCode;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Byte getIsFullTime() {
        return isFullTime;
    }

    public void setIsFullTime(Byte isFullTime) {
        this.isFullTime = isFullTime;
    }

    public Byte getIsCustomerService() {
        return isCustomerService;
    }

    public void setIsCustomerService(Byte isCustomerService) {
        this.isCustomerService = isCustomerService;
    }

    public String getInviterMobile() {
        return inviterMobile;
    }

    public void setInviterMobile(String inviterMobile) {
        this.inviterMobile = inviterMobile;
    }

    public String getBankCardNo() {
        return bankCardNo;
    }

    public void setBankCardNo(String bankCardNo) {
        this.bankCardNo = bankCardNo;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getBankAddress() {
        return bankAddress;
    }

    public void setBankAddress(String bankAddress) {
        this.bankAddress = bankAddress;
    }

    public String getBankSubbranch() {
        return bankSubbranch;
    }

    public void setBankSubbranch(String bankSubbranch) {
        this.bankSubbranch = bankSubbranch;
    }

    public Byte getAdvisorAuthStatus() {
        return advisorAuthStatus;
    }

    public void setAdvisorAuthStatus(Byte advisorAuthStatus) {
        this.advisorAuthStatus = advisorAuthStatus;
    }

    public String getAdvisorSource() {
        return advisorSource;
    }

    public void setAdvisorSource(String advisorSource) {
        this.advisorSource = advisorSource;
    }

    public Byte getAdvisorStatus() {
        return advisorStatus;
    }

    public void setAdvisorStatus(Byte advisorStatus) {
        this.advisorStatus = advisorStatus;
    }

    public String getDataOrgPath() {
        return dataOrgPath;
    }

    public void setDataOrgPath(String dataOrgPath) {
        this.dataOrgPath = dataOrgPath;
    }

    public String getDataUuid() {
        return dataUuid;
    }

    public void setDataUuid(String dataUuid) {
        this.dataUuid = dataUuid;
    }
}