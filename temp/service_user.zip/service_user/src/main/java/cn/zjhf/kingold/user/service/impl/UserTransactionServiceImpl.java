package cn.zjhf.kingold.user.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.user.constant.InvestorRelationKeyConstants;
import cn.zjhf.kingold.user.constant.InvestorType;
import cn.zjhf.kingold.user.constant.UserParamMsg;
import cn.zjhf.kingold.user.constant.UserTypeEnum;
import cn.zjhf.kingold.user.entity.InvestorChangeLog;
import cn.zjhf.kingold.user.persistence.dao.*;
import cn.zjhf.kingold.user.service.IAdvisorTransactionService;
import cn.zjhf.kingold.user.service.IUserTransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by liuyao on 2017/5/12.
 */
@Service
public class UserTransactionServiceImpl implements IUserTransactionService {

    @Autowired
    private UserMapper userMapper;
    @Autowired
    private InvestorMapper investorMapper;
    @Autowired
    private InvestorRelationMapper investorRelationMapper;
    @Autowired
    private InvestorChangeLogMapper investorChangeLogMapper;

    @Override
    @Transactional(propagation= Propagation.REQUIRED)
    public void insertUserTransaction(Map<String, Object> insertMap, boolean isUserExist) throws BusinessException {
        int baseIn = 0;
        if(!isUserExist) {
            baseIn = userMapper.insert(insertMap);
        }else {
            baseIn = 1;
        }
        int investorIn = investorMapper.insert(insertMap);
        int relationIn = investorRelationMapper.insert(insertMap);
        if (baseIn + investorIn + relationIn != 3) {
            throw new BusinessException(UserParamMsg.INNER_ERROR_CODE, UserParamMsg.INNER_ERROR, true);
        }
    }

    @Override
    @Transactional(propagation= Propagation.REQUIRED)
    public int upgradeUser(String userUuid) throws BusinessException {
        Map<String, Object> updateParam = new HashMap<>();
        updateParam.put(InvestorRelationKeyConstants.USER_UUID_STR, userUuid);
        updateParam.put(InvestorRelationKeyConstants.INVESTOR_TYPE, InvestorType.MONEY_MANAGE_TALENT);
        int updateCount = investorMapper.update(updateParam);
        InvestorChangeLog investorChangeLog = new InvestorChangeLog();
        investorChangeLog.setUserUuid(userUuid);
        investorChangeLog.setBeforeUserType(InvestorType.COMMON_INVESTOR);
        investorChangeLog.setAfterUserType(InvestorType.MONEY_MANAGE_TALENT);
        investorChangeLog.setChangeReason("用户完成绑卡且投资金疙瘩好友超过10人，升级成理财达人");
        int insertCount = investorChangeLogMapper.insertSelective(investorChangeLog);
        return insertCount + updateCount;
    }

    @Override
    @Transactional(propagation= Propagation.REQUIRED)
    public int updateUserTransaction(Map<String, Object> updateMap) throws BusinessException {
        int baseIn = userMapper.update(updateMap);
        int investorIn = investorMapper.update(updateMap);
        return baseIn + investorIn;
    }
}
