package cn.zjhf.kingold.user.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.user.persistence.dao.BankInfoMapper;
import cn.zjhf.kingold.user.service.IBankInfoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Created by wangxun on 2017/08/04.
 * Copyright by zjinv
 */
@Service
public class BankInfoServiceImpl implements IBankInfoService {
    private static final Logger LOGGER = LoggerFactory.getLogger(BankInfoServiceImpl.class);
    @Autowired
    private BankInfoMapper bankInfoMapper;


    @Override
    public Map get(Map params) throws BusinessException {

        Map ui = bankInfoMapper.get(params);
        return ui;
    }

    @Override
    public int insert(Map params) throws BusinessException {

        return bankInfoMapper.insert(params);

    }

    @Override
    public int update( Map params) throws BusinessException {
        return bankInfoMapper.update(params);
    }

    @Override
    public Integer delete(Map params) throws BusinessException {
        int num = bankInfoMapper.delete(params);
        return num;
    }

    @Override
    public List<Map> getList(Map userMap) throws BusinessException {

        List<Map> userList = bankInfoMapper.getList(userMap);

        return userList;
    }

    @Override
    public int getCount(Map userMap) throws BusinessException {

        return bankInfoMapper.getCount(userMap);

    }




}