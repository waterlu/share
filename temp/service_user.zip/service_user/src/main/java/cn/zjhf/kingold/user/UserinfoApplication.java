package cn.zjhf.kingold.user;

import cn.zjhf.kingold.rocketmq.annotation.EnableRocketMQConfiguration;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("cn.zjhf.kingold.user.persistence.dao")
@EnableRocketMQConfiguration
public class UserinfoApplication {


	public static void main(String[] args) {
		SpringApplication.run(UserinfoApplication.class, args);
	}

}
