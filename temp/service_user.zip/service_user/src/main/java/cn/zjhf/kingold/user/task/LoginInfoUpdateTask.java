package cn.zjhf.kingold.user.task;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.user.constant.UserParamMsg;
import cn.zjhf.kingold.user.persistence.dao.UserMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Created by liuyao on 2017/5/26.
 */
@Component
public class LoginInfoUpdateTask {

    @Autowired
    private UserMapper userMapper;

    private final static Logger LOGGER = LoggerFactory.getLogger(LoginInfoUpdateTask.class);


    @Async("IoBusyExecutor")
    public void asyncUpdateLoginInfo(Map params) throws BusinessException{
        int num = userMapper.updateLoginInfo(params);
        if (num < 1) {
            LOGGER.error("asyncUpdateLoginInfo update info. params={}", params);
            throw new BusinessException(UserParamMsg.INNER_ERROR_CODE, UserParamMsg.INNER_ERROR, true);
        }
    }
}
