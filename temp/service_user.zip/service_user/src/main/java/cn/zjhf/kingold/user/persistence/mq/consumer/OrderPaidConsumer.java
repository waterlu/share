package cn.zjhf.kingold.user.persistence.mq.consumer;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.rocketmq.annotation.RocketMQConsumer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQConsumer;
import cn.zjhf.kingold.user.persistence.dao.UserMapper;
import cn.zjhf.kingold.user.persistence.mq.message.OrderPaidMessage;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 消息订单认购成功消息
 *
 * @author lutiehua
 * @date 2018/3/13
 */
@RocketMQConsumer(topic = "order", tag = "paid")
public class OrderPaidConsumer extends AbstractMQConsumer<OrderPaidMessage> {

    @Autowired
    private UserMapper userMapper;

    @Override
    public ResponseResult process(OrderPaidMessage orderPaidMessage) throws BusinessException {
        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        String userUuid = orderPaidMessage.getUserUuid();
        // 更新用户交易状态
        // 即使没有更新数据库内容，也返回成功
        int row = userMapper.updateTradePaidStatus(userUuid);
        responseResult.setData(row);
        return responseResult;
    }
}
