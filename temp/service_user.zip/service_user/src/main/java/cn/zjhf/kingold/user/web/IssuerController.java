package cn.zjhf.kingold.user.web;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by liuyao on 2017/7/1.
 */

@RestController
@RequestMapping(value = "/user/issuer")
public class IssuerController {
}
