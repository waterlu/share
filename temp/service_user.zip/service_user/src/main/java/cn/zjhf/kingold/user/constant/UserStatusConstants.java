package cn.zjhf.kingold.user.constant;

/**
 * Created by lijing on 17/12/01.
 */

public class UserStatusConstants {

    //用户状态 1.冻结
    public static final String USER_STATUS_FREEZE = "1";

}

