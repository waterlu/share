package cn.zjhf.kingold.user.persistence.dao;

import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface WechatBindMapper {
    Integer insert(Map map);

    Map getByUserUuidAndPlatform(@Param("userUuid") String userUuid, @Param("platform") Integer platform);

    Map getByOpenIdAndPlatform(@Param("openId") String openId, @Param("platform") Integer platform);

    void deleteByUserUuidAndPlatform(@Param("userUuid") String userUuid, @Param("platform") Integer platform);

    List<Map> getList(@Param("platform") Integer platform, @Param("offset") Integer offset, @Param("limit") Integer limit);

    void deleteByOpenIdAndPlatform(@Param("openId") String openId, @Param("platform") Integer platform);

    void update(Map map);
}