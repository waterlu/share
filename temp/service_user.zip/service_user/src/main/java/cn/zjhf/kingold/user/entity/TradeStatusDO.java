package cn.zjhf.kingold.user.entity;

/**
 * @author lutiehua
 * @date 2018/3/16
 */
public class TradeStatusDO {

    /**
     * 用户UUID
     */
    private String userUuid;

    /**
     * 旧状态
     */
    private Integer oldStatus;

    /**
     * 新状态
     */
    private Integer newStatus;

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public Integer getOldStatus() {
        return oldStatus;
    }

    public void setOldStatus(Integer oldStatus) {
        this.oldStatus = oldStatus;
    }

    public Integer getNewStatus() {
        return newStatus;
    }

    public void setNewStatus(Integer newStatus) {
        this.newStatus = newStatus;
    }

}
