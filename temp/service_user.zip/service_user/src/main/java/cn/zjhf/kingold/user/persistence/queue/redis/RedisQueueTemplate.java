//package cn.zjhf.kingold.user.persistence.queue.redis;//package cn.zjhf.kingold.demo.persistence.queue.redis;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.dao.DataAccessException;
//import org.springframework.data.redis.connection.RedisConnection;
//import org.springframework.data.redis.core.RedisCallback;
//import org.springframework.data.redis.core.RedisTemplate;
//
///**
// * Redis 消息队列-模式
// * @author Wangxun
// * @date 2016-11-29
// */
//@Configuration
//public class RedisQueueTemplate {
//  private static final Logger LOGGER = LoggerFactory.getLogger(RedisQueueTemplate.class);
//  @Autowired
//  private RedisTemplate redisTemplate;
//
//
//  /**
//   *  发送消息进队列
//   * @param key   消息队列名称
//   * @param value value 消息内容
//   * @return
//   */
//  public Long putToQueue(final String key, final String value) {
//          LOGGER.info("发送消息进队列 key={},value={}",key,value);
//    Long l = (Long) this.getRedisTemplate().execute(new RedisCallback<Object>() {
//      public Object doInRedis(RedisConnection connection)
//          throws DataAccessException {
//        return connection.lPush(key.getBytes(), value.getBytes());
//      }
//    });
//    return l;
//  }
//
//
//  /**
//   * 从指定key中读取消息
//   * @param key  消息队列名称
//   * @return
//   */
//  public String getFromQueue(final String key) {
//    LOGGER.info("从指定队列key获取消息 key={}",key);
//    byte[] b = (byte[]) this.getRedisTemplate().execute(new RedisCallback<Object>() {
//      public Object doInRedis(RedisConnection connection)
//          throws DataAccessException {
//        return connection.lPop(key.getBytes());
//      }
//    });
//    if(b != null){
//      return new String(b);
//    }
//    return null;
//  }
//
//
//  public RedisTemplate getRedisTemplate() {
//    return redisTemplate;
//  }
//
//  public void setRedisTemplate(RedisTemplate redisTemplate) {
//    this.redisTemplate = redisTemplate;
//  }
//}
