package cn.zjhf.kingold.user.utils;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;

/**
 * Created by liuyao on 2017/11/9.
 */
public class ObjectUtil {

    /**
     * 赋值相同属性
     * @param source
     * @param target
     * @throws Exception
     */
    public static void copy(Object source, Object target) throws Exception{
        Class sourceClass = source.getClass();
        Class targetClass = target.getClass();

        Field[] sourceFields = sourceClass.getDeclaredFields();
        Field[] targetFields = targetClass.getDeclaredFields();
        List<Field> fieldList = Arrays.asList(targetFields);

        ImmutableMap<String, Field> targetMap = Maps.uniqueIndex(fieldList,field -> field.getName());

        for(Field sourceField : sourceFields){
            String name = sourceField.getName();
            if (targetMap.containsKey(name)) {
                Class type = sourceField.getType();
                String methodName = name.substring(0, 1).toUpperCase() + name.substring(1);
                Method getMethod = sourceClass.getMethod("get" + methodName);
                Object value = getMethod.invoke(source);
                Method setMethod = targetClass.getMethod("set" + methodName, type);
                setMethod.invoke(target, value);
            }
        }
    }
}
