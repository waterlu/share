package cn.zjhf.kingold.user.service;

import cn.zjhf.kingold.common.exception.BusinessException;

import java.util.Map;

/**
 * Created by wangxun on 2017/5/12.
 */
public interface IAdvisorTransactionService {
    void insertUserTransaction(Map<String, Object> map,boolean isUserExist) throws BusinessException;
    int updateUserTransaction(Map<String, Object> map) throws BusinessException;

}
