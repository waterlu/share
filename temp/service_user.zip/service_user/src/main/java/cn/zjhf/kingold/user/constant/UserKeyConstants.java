package cn.zjhf.kingold.user.constant;

/**
 * 用户对象字段名字
 * @author liuyao
 * @create 2017-05-11 13:45
 **/
public class UserKeyConstants {
    public static final String USER_ID_LONG = "userId";
    public static final String USER_UUID_STR = "userUuid";
    public static final String USER_TYPE_BYTE = "userType";
    public static final String USER_LOGIN_NAME_STR = "userLoginName";
    public static final String USER_LOGIN_PASSWORD_STR = "userLoginPassword";
    public static final String USER_PAY_PASSWORD_STR = "userPayPassword";
    public static final String ENCRYPT_SALT_STR = "encryptSalt";
    public static final String REGISTER_TIME_DATE = "registerTime";
    public static final String REGISTER_CHANNEL_CODE_STR = "registerChannelCode";
    public static final String REGISTER_VERSION_CODE_STR = "registerVersionCode";
    public static final String REGISTER_DEVICE_ID_STR = "registerDeviceId";
    public static final String REGISTER_DEVICE_TYPE_STR = "registerDeviceType";
    public static final String REGISTER_DEVICE_NAME_STR = "registerDeviceName";
    public static final String REGISTER_DEVICE_OS_STR = "registerDeviceOs";
    public static final String REGISTER_DEVICE_IP_STR = "registerDeviceIp";
    public static final String LOGIN_TIME_STR = "loginTime";
    public static final String LOGIN_CHANNEL_CODE_STR = "loginChannelCode";
    public static final String LOGIN_VERSION_CODE_STR = "loginVersionCode";
    public static final String LOGIN_DEVICE_ID_STR = "loginDeviceId";
    public static final String LOGIN_DEVICE_TYPE_STR = "loginDeviceType";
    public static final String LOGIN_DEVICE_OS_STR = "loginDeviceOs";
    public static final String LOGIN_DEVICE_IP_STR = "loginDeviceIp";
    public static final String SIGNATURE_STR = "signature";
    public static final String DELETE_FLAG_BYTE = "deleteFlag";
    public static final String CREATE_TIME_DATE = "createTime";
    public static final String UPDATE_TIME_DATE = "updateTime";
    public static final String USER_STATUS_INT = "userStatus";
    public static final String USER_VERIFY_STATUS_INT = "userVerifyStatus";
    public static final String USER_TRADE_STATUS_INT = "userTradeStatus";


}
