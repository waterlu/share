package cn.zjhf.kingold.user.persistence.mq.producer;

import cn.zjhf.kingold.rocketmq.annotation.RocketMQProducer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQProducer;
import cn.zjhf.kingold.user.persistence.mq.message.UserMessage;

/**
 * Created by liuyao on 2017/7/14.
 */
@RocketMQProducer(topic = "user", tag = "register")
public class UserRegisterProducer extends AbstractMQProducer<UserMessage>{
    
}

