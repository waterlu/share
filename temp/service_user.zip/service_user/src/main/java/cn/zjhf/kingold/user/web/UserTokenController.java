package cn.zjhf.kingold.user.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.user.service.IUserTokenService;
import cn.zjhf.kingold.user.utils.RequestMapperConvert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Created by lu on 2017/3/13.
 */
@RestController
@RequestMapping(value = "/usertoken")
public class UserTokenController {

    @Autowired
    private IUserTokenService userTokenService;
    @Autowired
    private StringRedisTemplate redisTemplate;

    /**
     * 创建userToken
     *
     * @param paramMap
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "", method = RequestMethod.POST)
    public ResponseResult createUserToken(@RequestBody Map paramMap) throws BusinessException {
        RequestMapperConvert.initParam(paramMap);
        List<Map> userList = userTokenService.getList(paramMap);
        for (Map userTokenMap : userList) {
            redisTemplate.delete((String) userTokenMap.get("token"));
        }
        //清除历史token数据
        userTokenService.delete(paramMap);
        userTokenService.insert(paramMap);
        return new ResponseResult((String) paramMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功");
    }


    /**
     * 查找用户信息
     *
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public ResponseResult getList(@RequestParam Map paramMap) throws BusinessException {
        RequestMapperConvert.initParam(paramMap);
        List<Map> userList = userTokenService.getList(paramMap);
        return new ResponseResult((String) paramMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", userList);
    }

    /**
     * 踢出用户
     *
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/logout", method = RequestMethod.GET)
    public ResponseResult logout(@RequestParam Map paramMap) throws BusinessException {
        RequestMapperConvert.initParam(paramMap);
        int num = userTokenService.logout(paramMap);
        return new ResponseResult((String) paramMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", num);
    }

}
