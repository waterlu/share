package cn.zjhf.kingold.user.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by zhangyijie on 2017/5/16.
 */
public class DataUtils {
    private static final Logger logger = LoggerFactory.getLogger(DataUtils.class);

    public static final String LINEBREAK = "\r\n";

    public static boolean isNotEmpty(String value) {
        if (value != null) {
            if (value.trim().length() > 0) {
                return true;
            }
        }

        return false;
    }

    public static List<String> split(String value, String regex) {
        String[] items = value.split(regex);
        List<String> ret = new ArrayList<String>();
        for (String item : items) {
            ret.add(item);
        }

        return ret;
    }

    public static boolean isContain(int value, int... optValues) {
        if (optValues != null) {
            for (int optValue : optValues) {
                if (value == optValue) {
                    return true;
                }
            }
        }

        return false;
    }

    public static boolean isContain(String value, String... optValues) {
        if (optValues != null) {
            for (String optValue : optValues) {
                if (value.equals(optValue)) {
                    return true;
                }
            }
        }

        return false;
    }

    public static boolean isEmpty(String value) {
        return !isNotEmpty(value);
    }


    public static <T> String listToStr(List<T> items) {
        StringBuilder str = new StringBuilder("");
        if (items == null)
            return str.toString();

        int len = items.size();
        if (len == 0) {
            logger.debug("空列表");
        }

        for (int i = 0; i < len; i++) {
            if (null != items.get(i)) {
                str.append(items.get(i).toString());

                if (i != (len - 1)) {
                    str.append(", ");
                }
            } else {
                logger.debug("null");
            }
        }

        return str.toString();
    }

    public static String toString(List<List<String>> value) {
        StringBuilder sb = new StringBuilder("\r\n");

        for (List<String> items : value) {
            for (String item : items) {
                if (DataUtils.isEmpty(item)) {
                    item = "null";
                }

                sb.append(item).append("\t");
            }

            sb.append("\r\n");
        }

        return sb.toString();
    }

    //double的输出不要输出成科学计数法
    public static String toString(double value) {
        if (Double.isNaN(value))
            return "0";

        return AmountUtils.toString(value);
    }

    //Date不要输出成恶心的格式
    public static String toString(Date value) {
        if (null == value)
            return "1900-01-01 00:00:00";

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.format(value);
    }

    //BigDecimal的输出不要输出成科学计数法
    public static String toString(BigDecimal value) {
        if (null == value)
            return "0";

        return AmountUtils.toString(value);
    }

    public static String toString(Object obj) {
        if (obj instanceof Double) {
            return toString((double) obj);
        } else if (obj instanceof BigDecimal) {
            return toString((BigDecimal) obj);
        } else if (obj instanceof Date) {
            return toString((Date) obj);
        } else if (obj instanceof Map) {
            return toString((Map) obj);
        } else if (obj instanceof List) {
            return listToStr((List) obj);
        }

        return (obj != null) ? obj.toString() : "null";
    }

    public static String toString(Map map) {
        final String interStr = ", ";
        StringBuilder sb = new StringBuilder();

        List<Object> keys = new ArrayList<Object>(map.keySet());
        int count = keys.size();
        for (int i = 0; i < count; i++) {
            Object key = keys.get(i);
            sb.append(DataUtils.toString(key) + ":[" + DataUtils.toString(map.get(key)) + "]");

            if (i != (count - 1)) {
                sb.append(interStr);
            }
        }

        return sb.toString();
    }

    public static String createRandomCharData(int length) {
        StringBuilder numStr = new StringBuilder();
        //随机用以下三个随机生成器
        Random rand = new Random();
        Random randData = new Random();
        int data = 0;
        for (int i = 0; i < length; i++) {
            int index = rand.nextInt(3);
            //目的是随机选择生成数字，大小写字母
            switch (index) {
                case 0:
                    //仅仅会生成0~9
                    data = randData.nextInt(10);
                    numStr.append(data);
                    break;
                case 1:
                    //保证只会产生65~90之间的整数
                    data = randData.nextInt(26) + 65;
                    numStr.append((char) data);
                    break;
                case 2:
                    //保证只会产生97~122之间的整数
                    data = randData.nextInt(26) + 97;
                    numStr.append((char) data);
                    break;
            }
        }
        return  numStr.toString();
    }

    public static String toLog(String name, Object velue) {
        return (new StringBuilder(toString(name)).append(":").append(toString(velue))).append(" ").toString();
    }

    public static String toString(Object obj1, Object obj2) {
        return (new StringBuilder(toString(obj1)).append(", ").append(toString(obj2))).toString();
    }
}
