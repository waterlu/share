package cn.zjhf.kingold.user.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.user.entity.InvestorMobileContact;
import cn.zjhf.kingold.user.entity.UserWechatHist;
import cn.zjhf.kingold.user.service.IInvestorRelationService;
import cn.zjhf.kingold.user.utils.DataUtils;
import cn.zjhf.kingold.user.utils.RequestMapperConvert;
import cn.zjhf.kingold.user.utils.UtilTools;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.collections4.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by Xiaody on 17/6/7.
 */
@RestController
@RequestMapping("/investorRelation")
public class InvestorRelationController {

    @Autowired
    private IInvestorRelationService investorRelationService;

    /**
     * 获取用户关系
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/{userUuid}", method = RequestMethod.GET)
    public ResponseResult getInvestorRelation(@PathVariable("userUuid") String userUuid,
                                              @RequestParam(value = "traceID") String traceID) throws BusinessException {
        Map<String, Object> relation = investorRelationService.getInvestorRelation(userUuid);
        return new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS, "成功", relation);
    }


    /**
     * 根据查询条件获取自己一级邀请或者二级邀请的用户信息
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/list")
    public ResponseResult getList(@RequestParam Map params) throws BusinessException {
        RequestMapperConvert.initParam(params);
        List<Map> list = investorRelationService.getList(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", list);
    }


    /**
     * 根据查询条件获取自己一级邀请或者二级邀请的用户数量
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/count")
    public ResponseResult getCount(@RequestParam Map params) throws BusinessException {
        RequestMapperConvert.initParam(params);
        Integer count = investorRelationService.getCount(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", count);
    }

    /**
     * 获取所有好友用户数据
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/allRelation")
    public ResponseResult getAllRelation(@RequestParam Map params) throws BusinessException {
        RequestMapperConvert.initParam(params);
        List<Map> map = investorRelationService.getRelationList(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", map);
    }

    /**
     * 获取所有好友数量
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/allCount")
    public ResponseResult getRelationCount(@RequestParam Map params) throws BusinessException {
        RequestMapperConvert.initParam(params);
        Map map = investorRelationService.getRelationCount(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", map);
    }


    /**
     * 获取自己好友绑定了微信openid的用户
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/openid/list")
    public ResponseResult getOpenid(@RequestParam Map params) throws BusinessException {
        List<Map> list = investorRelationService.getRelationOpenid(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", list);
    }

    /**
     * 根据手机号获取investor 上下级关系数据
     * @param params 必填investorMobile
     */
    @RequestMapping(value = "/getRelationByMobile", method = RequestMethod.GET)
    public ResponseResult getRelationByMobile(@RequestParam Map params) throws BusinessException{

        if (params.get("investorMobile") == null){
            return new ResponseResult((String) params.get("traceID"), ResponseCode.PARAM_ERROR, ResponseCode.PARAM_ERROR_TEXT, params);
        }
        Map responseMap = investorRelationService.getRelationByMobile(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.OK, ResponseCode.OK_TEXT, responseMap);
    }

    /**
     * 保存通讯录信息
     */
    @RequestMapping(value = "/saveContact", method = RequestMethod.POST)
    public ResponseResult saveContact(@RequestBody Map params) throws BusinessException{

        if (params.get("userUuid") == null || params.get("contacts") == null || params.get("investorMobile") == null ){
            return new ResponseResult((String) params.get("traceID"), ResponseCode.PARAM_ERROR, ResponseCode.PARAM_ERROR_TEXT, params);
        }
        List<InvestorMobileContact> contactList = new ArrayList<>();
        JSONArray contactJa = JSONArray.parseArray(params.get("contacts").toString());
        for (int i = 0; i < contactJa.size(); ++i) {
            InvestorMobileContact investorMobileContact = JSON.parseObject(contactJa.get(i).toString(), InvestorMobileContact.class);
            investorMobileContact.setUserUuid(params.get("userUuid").toString());
            investorMobileContact.setInvestorMobile(params.get("investorMobile").toString());
            contactList.add(investorMobileContact);
        }

        int count = investorRelationService.saveContact(contactList);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.OK, ResponseCode.OK_TEXT, count);
    }

    /**
     * 根据投资人uuid查找下级信息和对应的下级数量
     * @param params 必填userUuid
     */
    @RequestMapping(value = "/getDownOneList", method = RequestMethod.GET)
    public ResponseResult getDownOneList(@RequestParam Map params) throws BusinessException{

        Integer pageNo = (params.get("pageNo") == null ? 1 : Integer.valueOf(params.get("pageNo").toString()));
        Integer pageSize = (params.get("pageSize") == null ? 20 : Integer.valueOf(params.get("pageSize").toString()));
        params.put("startRow", (pageNo - 1) * pageSize);
        params.put("pageSize", pageSize);
        if (params.get("userUuid") == null){
            return new ResponseResult((String) params.get("traceID"), ResponseCode.PARAM_ERROR, ResponseCode.PARAM_ERROR_TEXT, params);
        }
        List<Map> responseMap = investorRelationService.getDownOneInvestor(params);
        responseMap.forEach(downOneMap->downOneMap.put("investorMobile", UtilTools.encryptMobile(downOneMap.get("investorMobile").toString())));
        int downOneInvestorCount = investorRelationService.getDownOneInvestorCount(params);
        Map result = new HashedMap();
        result.put("downOneInvestorCount", downOneInvestorCount);
        result.put("downOneInvestorList", responseMap);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.OK, ResponseCode.OK_TEXT, result);
    }

    /**
     * 获取金疙瘩好友列表
     * param :inviterLevelOneUuid 一级邀请人uuid
     *        startRow
     *        pageSize
     *        userTradeStatus
     */
    @RequestMapping(value = "/getGoldRelationSortByTime", method = RequestMethod.GET)
    public ResponseResult getGoldRelationSortByTime(@RequestParam Map params) throws BusinessException{
        Map result = investorRelationService.getRelationSortByTime(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.OK, ResponseCode.OK_TEXT, result);
    }

    /**
     * 获取金疙瘩好友列表
     * param :inviterLevelOneUuid 一级邀请人uuid
     *        startRow
     *        pageSize
     *        userTradeStatus
     */
    @RequestMapping(value = "/getGoldRelationSortByReward", method = RequestMethod.GET)
    public ResponseResult getGoldRelationSortByReward(@RequestParam Map params) throws BusinessException{
        Map result = investorRelationService.getRelationSortByReward(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.OK, ResponseCode.OK_TEXT, result);
    }

    /**
     * 获取用户关系下 父亲，儿子，自己的头像和昵称。如果没有昵称用实名，没有实名用电话
     * @param params userUuid是必填项。startRow 开始项，pageSize 每页显示数量
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/getFatherAndSonAndSelfList")
    public ResponseResult getFatherAndSonAndSelfList(@RequestParam Map params) throws BusinessException {
        RequestMapperConvert.initParam(params);
        List<UserWechatHist> map = investorRelationService.getFatherAndSonAndSelfList(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", map);
    }



}
