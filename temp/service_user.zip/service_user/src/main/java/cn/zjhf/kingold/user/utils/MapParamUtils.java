package cn.zjhf.kingold.user.utils;

import org.apache.commons.collections4.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by DELL on 2017/5/15.
 */
public class MapParamUtils {

    private final static Logger LOGGER = LoggerFactory.getLogger(MapParamUtils.class);

    public static String getStringInMap(Map params, String key){
        if(MapUtils.isEmpty(params) || params.get(key) == null){
            return "";
        }

        return params.get(key).toString();

    }

    public static int getIntInMap(Map params,String key){
        if(MapUtils.isEmpty(params) || params.get(key) == null){
            return 0;
        }

        return Integer.parseInt(params.get(key).toString());

    }

    public static long getLongInMap(Map params,String key){
        if(MapUtils.isEmpty(params) || params.get(key) == null){
            return 0;
        }

        return Long.parseLong(params.get(key).toString());

    }

    public static double getDoubleInMap(Map params,String key){
        if(MapUtils.isEmpty(params) || params.get(key) == null){
            return 0;
        }

        return Double.parseDouble(params.get(key).toString());

    }


    public static BigDecimal getBigDecimalInMap(Map params, String key){
        if(MapUtils.isEmpty(params) || params.get(key) == null){
            return new BigDecimal(0);
        }

        return new BigDecimal(params.get(key).toString());

    }



    public static byte getByteInMap(Map params,String key){
        if(MapUtils.isEmpty(params) || params.get(key) == null){
            return 0;
        }

        return Byte.parseByte(params.get(key).toString());

    }

    public static Map<String, Object> obj2Map(Object obj) {
        Map<String, Object> map = new HashMap<>();
        Field[] fields = obj.getClass().getDeclaredFields();
        for (int i = 0, len = fields.length; i < len; i++) {
            String varName = fields[i].getName();
            try {
                boolean accessFlag = fields[i].isAccessible();
                fields[i].setAccessible(true);
                Object o = fields[i].get(obj);
                if (o != null)
                    map.put(varName, o);
                fields[i].setAccessible(accessFlag);
            } catch (Exception e) {
                LOGGER.error("obj2Map failed. obj={}", obj, e);
            }
        }
        return map;
    }

    public static Object map2Obj(Map<String, Object> map, Class<?> beanClass) {
        if (map == null)
            return null;
        Object obj = null;
        try {
            obj = beanClass.newInstance();

            Field[] fields = obj.getClass().getDeclaredFields();
            for (Field field : fields) {
                int mod = field.getModifiers();
                if (Modifier.isStatic(mod) || Modifier.isFinal(mod)) {
                    continue;
                }

                field.setAccessible(true);
                if (map.get(field.getName()) != null) {
                    Class<?> type = field.getType();
                    if (type.equals(Integer.class)) {
                        field.set(obj, Integer.parseInt(map.get(field.getName()).toString()));
                    } else if (type.equals(Long.class)) {
                        field.set(obj, Long.parseLong(map.get(field.getName()).toString()));
                    } else {
                        field.set(obj, map.get(field.getName()));
                    }
                }

            }
        } catch (Exception e) {
            LOGGER.error("map2Obj failed. map={}", map, e);
        }
        return obj;
    }
}
