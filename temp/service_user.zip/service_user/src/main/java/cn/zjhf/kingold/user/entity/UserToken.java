package cn.zjhf.kingold.user.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class UserToken implements Serializable {
    private Long userTokenId;

    private String userUuid;

    private String token;

    private Date createTime;

    private static final long serialVersionUID = 1L;

    public Long getUserTokenId() {
        return userTokenId;
    }

    public void setUserTokenId(Long userTokenId) {
        this.userTokenId = userTokenId;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}