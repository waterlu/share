package cn.zjhf.kingold.user.constant;

/**
 * Created by likenice on 17/3/20.+
 * 1000~1599 : user,investor,issuer 异常编码。
 * 6000~6999 : user,investor,issuer 异常编码。
 */

public class UserParamMsg {
    public static final String REQUEST_PROPERTIES_IS_NOT_EXIST = "param:properties is not exist!";


    public static final int REQUEST_PARAM_ERROR_CODE = -1;
    public static final String REQUEST_PARAM_ERROR = "入参参数错误";


    public static final int SUCCESS_CODE = 200;
    public static final String SUCCESS = "发送成功";


    public static final int INNER_ERROR_CODE = 500;
    public static final String INNER_ERROR = "系统异常";


    public static final int SEND_ERROR_CODE = 1001;
    public static final String SEND_ERROR = "发送失败";

    public static final int VERIFY_CODE_ERROR_CODE = 1002;
    public static final String VERIFY_CODE_ERROR = "验证码错误";

    public static final int SEND_OUT_LIMIT_CODE = 1003;
    public static final String SEND_OUT_LIMIT = "超过发送次数";

    public static final int IMAGE_CODE_ERROR_CODE = 1004;
    public static final String IMAGE_CODE_ERROR = "失败次数过多，请输入图形验证码";


    public static final int REGISTER_PHONE_IS_EXIST_CODE = 1101;
    public static final String REGISTER_PHONE_IS_EXIST = "注册人手机号已经存在";

    public static final int INVITER_PHONE_NOT_EXIST_CODE = 1102;
    public static final String INVITER_PHONE_NOT_EXIST = "邀请人手机号不存在";


    public static final int REGISTER_PHONE_NOT_EXIST_CODE = 1103;
    public static final String REGISTER_PHONE_NOT_EXIST = "注册人手机号不存在";

    public static final int REGISTER_ID_CARD_NOT_EXIST_CODE = 1104;
    public static final String REGISTER_ID_CARD_NOT_EXIST = "注册人身份证号不存在";

    public static final int ID_CARD_NOT_MATCH_CODE = 1105;
    public static final String ID_CARD_NOT_MATCH = "身份证号与原身份证号不匹配";

    public static final int BANK_CARD_PHONE_NOT_MATCH_CODE = 1106;
    public static final String BANK_CARD_PHONE_NOT_MATCH = "持卡人，银行卡，预留手机号不匹配";

    public static final int CURR_USER_NAME_ID_CARD_NOT_MATCH_CODE = 1107;
    public static final String CURR_USER_NAME_ID_CARD_NOT_MATCH = "当前用户、姓名、身份证 不匹配";



    public static final int PAY_PW_ERROR_CODE = 1108;
    public static final String PAY_PW_ERROR = "交易密码错误";

    public static final int USER_IS_FREEZING_CODE = 1109;
    public static final String USER_IS_FREEZING = "当前用户已被禁用";

    public static final int LONGIN_PW_NOT_MATCH_CODE = 1110;
    public static final String LONGIN_PW_NOT_MATCH = "用户名、密码错误";

    public static final int TOKEN_TIMEOUT_CODE = 1111;
    public static final String TOKEN_TIMEOUT = "token已失效";

    public static final int NOT_FIND_USER_CODE = 1112;
    public static final String NOT_FIND_USER = "用户不存在";

    public static final int USER_HAS_EXIST_CODE = 1113;
    public static final String USER_HAS_EXIST = "用户已经存在";

    public static final int PAY_PW_NOT_MATCH_CODE = 1114;
    public static final String PAY_PW_NOT_MATCH = "支付密码错误";

    public static final int PAY_PW_NOT_EXIST_CODE = 1115;
    public static final String PAY_PW_NOT_EXIST= "支付密码没有设置";

    public static final int PAY_PW_INPUT_ERROR_OVER_CODE = 1116;
    public static final String PAY_PW_INPUT_ERROR_OVER = "支付密码错误次数过多";

    public static final int USER_NOT_OPEN_ACCOUNT_CODE = 1117;
    public static final String USER_NOT_OPEN_ACCOUNT = "用户还没有开户";

    public static final int USER_NOT_TIE_ON_CARD_CODE = 1118;
    public static final String USER_NOT_TIE_ON_CARD = "用户还没有绑卡";

    public static final int PAY_PW_ERROR_OVERLOAD_CODE = 1119;
    public static final String PAY_PW_OVERLOAD_ERROR = "交易密码错误次数过多，重置密码或者12小时后解冻";

    public static final int OPENID_NOT_MATCH_CODE = 1120;
    public static final String OPENID_NOT_MATCH_ERROR = "异常登录 ！该手机号绑定的微信账号与当前微信账号不匹配";

    public static final int USER_UPGRADE_TALENT_ERROR_CODE = 1121;
    public static final String USER_UPGRADE_TALENT_ERROR_MSG = "不满足开启达人特权条件";

    public static final int THIRD_NOT_BIND_MOBILE_CODE = 1122;
    public static final String THIRD_NOT_BIND_MOBILE_MSG = "尚未绑定手机号，请先绑定手机号";

//==================================以下是advisor相关异常=================================

    public static final int INVITER_CODE_NOT_EXIST_CODE = 1601;
    public static final String INVITER_CODE_NOT_EXIST = "邀请码不存在";

    public static final int PRE_PAY_PW_ERROR_CODE = 1121;
    public static final String PRE_PAY_PW_ERROR = "原密码不匹配";

}

