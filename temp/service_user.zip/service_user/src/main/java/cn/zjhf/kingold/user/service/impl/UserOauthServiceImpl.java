package cn.zjhf.kingold.user.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.service_consumer.service.CoinServiceConsumer;
import cn.zjhf.kingold.user.constant.UserParamMsg;
import cn.zjhf.kingold.user.entity.UserOauth;
import cn.zjhf.kingold.user.persistence.dao.UserOauthMapper;
import cn.zjhf.kingold.user.service.IUserOauthService;
import cn.zjhf.kingold.user.service.IUserService;
import cn.zjhf.kingold.user.utils.MapParamUtils;
import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @Author xiaody
 * @Description
 * @Date create in 17/10/30
 */
@Service
public class UserOauthServiceImpl implements IUserOauthService {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserOauthServiceImpl.class);

    @Autowired
    private UserOauthMapper userOauthMapper;

    @Autowired
    private IUserService userService;

    @Autowired
    private CoinServiceConsumer coinServiceConsumer;

    private static Splitter splitter = Splitter.on(",");

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void bind(Map params) throws BusinessException {
        params.put("nickName", nickNameUrlEncode(MapParamUtils.getStringInMap(params, "nickName")));
        //查询该oauthId是否已经绑定过账号，绑定过则解绑
        Map map = new HashMap<>(2);
        map.put("oauthId", MapParamUtils.getStringInMap(params, "oauthId"));
        map.put("status", 1);
        List<UserOauth> list = getList(map);
        if (list.size() > 0) {
            list.forEach(item -> {
                UserOauth update = new UserOauth();
                update.setUserOauthId(item.getUserOauthId());
                update.setStatus(0);
                userOauthMapper.update(update);
            });
        }

        Map oauthMap = new HashMap(2);
        oauthMap.put("userUuid", MapParamUtils.getStringInMap(params, "userUuid"));
        oauthMap.put("oauthType", MapParamUtils.getStringInMap(params, "oauthType"));

        UserOauth userOauth = (UserOauth) MapParamUtils.map2Obj(params, UserOauth.class);
        List<UserOauth> userOauthList = getList(oauthMap);
        //之前没绑定过就插入
        if (userOauthList.size() == 0) {
            userOauthMapper.insert(userOauth);
        } else {//之前绑定过就更新
            userOauth.setUserOauthId(userOauthList.get(0).getUserOauthId());
            userOauth.setStatus(1);
            userOauth.setNickName(userOauth.getNickName());
            userOauthMapper.update(userOauth);
        }

        //更新coin中的昵称头像
        if ("1".equals(MapParamUtils.getStringInMap(params, "oauthType"))
                || "10".equals(MapParamUtils.getStringInMap(params, "oauthType"))) {
            params.put("openId", MapParamUtils.getStringInMap(params, "oauthId"));
            params.put("investorMobile", MapParamUtils.getStringInMap(params, "userMobile"));
            coinServiceConsumer.post("/coin", params);
        }

    }

    @Override
    public void unbind(Map params) throws BusinessException {
        userOauthMapper.unbind(MapParamUtils.getStringInMap(params, "userUuid"), MapParamUtils.getIntInMap(params,
                "oauthType"));
    }

    @Override
    public List<UserOauth> getList(Map params) throws BusinessException {
        List<UserOauth> list = userOauthMapper.getList(params);
        list.forEach(this::nickNameUrlDecode);
        return list;
    }

    @Override
    public Map<String, UserOauth> getWechatInfo(Map params) throws BusinessException {
        String userUuids = MapParamUtils.getStringInMap(params, "userUuids");
        if (StringUtils.isBlank(userUuids)) {
            throw new BusinessException(UserParamMsg.REQUEST_PARAM_ERROR_CODE, "参数 userUuids 不能为空！", true);
        }

        List<String> userUuidList = splitter.splitToList(userUuids);

        Map<String, Object> investorParams = new HashMap<>(1);
        investorParams.put("userUuids", userUuidList);
        List<Map> userList = userService.getInvestorListWithFilter(investorParams);
        Map<String, Map> userMap = userList.stream().collect(Collectors.toMap(item -> MapParamUtils.getStringInMap
                (item, "userUuid"), Function.identity()));

        //只查询微信授权和微信公众号的
        params.put("oauthTypeList", Lists.newArrayList(1, 10));
        params.put("status", 1);
        params.put("userUuidList", userUuidList);
        List<UserOauth> userOauthList = userOauthMapper.getList(params);
        userOauthList.forEach(this::nickNameUrlDecode);

        Map<String, Optional<UserOauth>> userOauthMap = userOauthList.stream().collect(Collectors.groupingBy
                (UserOauth::getUserUuid, Collectors.maxBy(Comparator.comparing(UserOauth::getUpdateTime))));
        Map<String, UserOauth> retMap = Maps.newHashMap();


        userUuidList.forEach(userUuid -> {
            Optional<UserOauth> userOauthOptional = userOauthMap.get(userUuid);
            Map user = userMap.get(userUuid);

            String investorRealName = MapParamUtils.getStringInMap(user, "investorRealName");
            String investorMobile = MapParamUtils.getStringInMap(user, "investorMobile");
            String investorType = MapParamUtils.getStringInMap(user, "investorType");

            if (userOauthOptional != null && userOauthOptional.isPresent()) {
                UserOauth userOauth = userOauthOptional.get();
                userOauth.setInvestorType(investorType);
                if (StringUtils.isBlank(userOauth.getNickName())) {
                    userOauth.setNickName(StringUtils.isNotBlank(investorRealName) ? investorRealName : investorMobile);
                }
                if (StringUtils.isBlank(userOauth.getHeadImageUrl())) {
                    userOauth.setHeadImageUrl("");
                }
                retMap.put(userUuid, userOauth);
            } else {
                UserOauth userOauth = new UserOauth();
                userOauth.setUserUuid(userUuid);
                userOauth.setNickName(StringUtils.isNotBlank(investorRealName) ? investorRealName : investorMobile);
                userOauth.setHeadImageUrl("");
                userOauth.setInvestorType(investorType);
                retMap.put(userUuid, userOauth);
            }
        });
        return retMap;
    }


    /**
     * 对昵称编码
     *
     * @param nickName
     */
    private String nickNameUrlEncode(String nickName) {
        if (StringUtils.isNotBlank(nickName)) {
            try {
                return URLEncoder.encode(nickName, "utf8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                LOGGER.error("nickname url encode failed. ", e);
            }
        }
        return null;
    }


    /**
     * 对昵称解码
     *
     * @param userOauth
     */
    private void nickNameUrlDecode(UserOauth userOauth) {
        String nickName = userOauth.getNickName();
        if (StringUtils.isNotBlank(nickName)) {
            try {
                userOauth.setNickName(URLDecoder.decode(nickName, "utf8"));
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                LOGGER.error("nickname url decode failed. ", e);
            }
        }
    }

}
