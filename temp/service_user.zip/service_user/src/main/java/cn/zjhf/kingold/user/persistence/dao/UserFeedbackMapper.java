package cn.zjhf.kingold.user.persistence.dao;


import cn.zjhf.kingold.user.entity.UserFeedback;
import org.springframework.stereotype.Repository;

@Repository
public interface UserFeedbackMapper {

    int insert(UserFeedback userFeedback);

}