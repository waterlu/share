package cn.zjhf.kingold.user.constant;

/**
 * Created by liuyao on 17/12/04.
 */

public class UserTradeStatus {

    //充值完成
    public static final int RECHARGE_COMPLETE = 1;
    //定期理财认购完成
    public static final int FIXI_ORDER_PAID_COMPLETE = 2;
}

