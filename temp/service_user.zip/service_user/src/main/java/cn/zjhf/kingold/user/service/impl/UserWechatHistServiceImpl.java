package cn.zjhf.kingold.user.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.user.constant.UserParamMsg;
import cn.zjhf.kingold.user.entity.UserOauth;
import cn.zjhf.kingold.user.entity.UserWechatHist;
import cn.zjhf.kingold.user.persistence.dao.UserOauthMapper;
import cn.zjhf.kingold.user.persistence.dao.UserWechatHistMapper;
import cn.zjhf.kingold.user.service.IUserOauthService;
import cn.zjhf.kingold.user.service.IUserService;
import cn.zjhf.kingold.user.service.IUserWechatHistService;
import cn.zjhf.kingold.user.utils.MapParamUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * @Author wangxun
 * @Description
 * @Date create in 18/1/3
 */
@Service
public class UserWechatHistServiceImpl implements IUserWechatHistService {

    @Autowired
    private UserWechatHistMapper userWechatHistMapper;

    @Autowired
    private IUserService userService;

    @Transactional
    @Override
    public void upsert(Map params) throws BusinessException {

        if(StringUtils.isBlank(MapParamUtils.getStringInMap(params, "userUuid"))){
            throw new BusinessException(UserParamMsg.REQUEST_PARAM_ERROR_CODE, "参数userUuid是必填项", true);
        }

        //查询userUuid是否存在，
        Map map = new HashMap<>();
        map.put("userUuid", MapParamUtils.getStringInMap(params, "userUuid"));
        List<UserWechatHist> userWechatHists = userWechatHistMapper.getList(map);
//       如果userUuid不存在，则插入。
        if(CollectionUtils.isEmpty(userWechatHists)){
            userWechatHistMapper.insert(params);
        }else {// 如果存在，则更新
            userWechatHistMapper.update(params);
        }

    }

    @Override
    public List<UserWechatHist> getList(Map params) throws BusinessException {
        String userUuids = MapParamUtils.getStringInMap(params,"userUuids");
        List<String> userUuidList = new ArrayList<>();
        if(StringUtils.isNotBlank(userUuids)){
            userUuidList = Arrays.asList(userUuids.split(","));
            params.put("userUuidList",userUuidList);
        }
        if(StringUtils.isBlank(userUuids)  ){
            throw new BusinessException(UserParamMsg.REQUEST_PARAM_ERROR_CODE, "参数 userUuids 不能为空！", true);
        }

        Map<String,Object> investorParams = new HashMap<>();
        investorParams.put("userUuids",userUuidList);
        List<Map> userList = userService.getInvestorListWithFilter(investorParams);

        List<UserWechatHist> userWechatList = userWechatHistMapper.getList(params);
        List<UserWechatHist> resultList = new ArrayList<>();
        for(String userUuidTemp : userUuidList){
            UserWechatHist userWechatHist = null;
            for(UserWechatHist userWechatTemp :userWechatList){
                if(userWechatTemp.getUserUuid().equals(userUuidTemp)){

                    userWechatHist = userWechatTemp ;
                }
            }
            if(userWechatHist == null){//当前userUUid没有找到绑定的微信头像和昵称
                userWechatHist = new UserWechatHist();
                for(Map userTemp :userList){

                    if(MapParamUtils.getStringInMap(userTemp,"userUuid").equals(userUuidTemp)){
                        String investorRealName = MapParamUtils.getStringInMap(userTemp,"investorRealName");
                        String investorMobile = MapParamUtils.getStringInMap(userTemp,"investorMobile");
                        String investorType = MapParamUtils.getStringInMap(userTemp,"investorType");


                        //如果有实名认证，用实名认证姓名。
                        if(StringUtils.isNotBlank(investorRealName)){
                            userWechatHist.setNickName(investorRealName);
                        }else{//没有实名认证，用电话
                            userWechatHist.setNickName(investorMobile);
                        }
                        userWechatHist.setInvestorType(investorType);
                        userWechatHist.setHeadImageUrl("");
                        userWechatHist.setUserUuid(userUuidTemp);
                    }
                }
            }
            resultList.add(userWechatHist);
        }

        return resultList;
    }
}
