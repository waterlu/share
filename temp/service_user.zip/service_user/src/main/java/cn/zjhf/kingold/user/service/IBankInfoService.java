package cn.zjhf.kingold.user.service;


import cn.zjhf.kingold.common.exception.BusinessException;

import java.util.List;
import java.util.Map;


/**
 * Created by wangxun on 2017/08/04.
 * Copyright by wangxun
 */
public interface IBankInfoService {


    public Map get(Map params) throws BusinessException;

    public int insert(Map userInfo) throws BusinessException;

    public int update(Map userInfo) throws BusinessException;

    public Integer delete(Map params) throws BusinessException;

    List<Map> getList(Map userMap) throws BusinessException;


    int getCount(Map userMap) throws BusinessException;

}