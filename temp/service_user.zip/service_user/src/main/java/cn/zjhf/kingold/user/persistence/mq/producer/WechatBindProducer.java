package cn.zjhf.kingold.user.persistence.mq.producer;

import cn.zjhf.kingold.rocketmq.annotation.RocketMQProducer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQProducer;
import cn.zjhf.kingold.user.persistence.mq.message.WechatBindMessage;

/**
 * Created by Xiaody on 17/7/27.
 */
@RocketMQProducer(topic = "user",tag = "bindWechat")
public class WechatBindProducer extends AbstractMQProducer<WechatBindMessage> {
}
