package cn.zjhf.kingold.user.persistence.dao;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;


@Repository
public interface UserCertificationMapper {

    List<Map<String, Object>> getByUserUuid(@Param("userUuid") String userUuid,@Param("userCertificationType") Integer userCertificationType);

    int insert(Map<String, Object> userMap);

}