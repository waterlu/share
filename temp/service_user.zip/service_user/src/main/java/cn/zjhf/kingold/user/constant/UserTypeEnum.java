package cn.zjhf.kingold.user.constant;

/**
 * Created by liuyao on 2017/6/30.
 */
public enum UserTypeEnum {
    USER_INVESTOR_TYPE(1, "普通用户"), USER_ISSUER_TYPE(2, "募集方"), ENTERPRISE_INVESTOR_TYPE(3, "企业投资人");

    private int userType;
    private String userTypeMsg;

    UserTypeEnum(int userType, String userTypeMsg) {
        this.userType = userType;
        this.userTypeMsg = userTypeMsg;
    }

    public static UserTypeEnum getUserTypeEnum(Integer type) {
        if (type == null) return USER_INVESTOR_TYPE;

        for (UserTypeEnum userTypeEnum: UserTypeEnum.values()) {
            if (userTypeEnum.getUserType() == type) {
                return userTypeEnum;
            }
        }
        return USER_INVESTOR_TYPE;
    }

    public int getUserType() {
        return userType;
    }

    public void setUserType(int userType) {
        this.userType = userType;
    }

    public String getUserTypeMsg() {
        return userTypeMsg;
    }

    public void setUserTypeMsg(String userTypeMsg) {
        this.userTypeMsg = userTypeMsg;
    }
}
