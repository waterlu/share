package cn.zjhf.kingold.user.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.user.constant.UserParamMsg;
import cn.zjhf.kingold.user.entity.UserOauth;
import cn.zjhf.kingold.user.entity.UserWechatHist;
import cn.zjhf.kingold.user.service.IUserOauthService;
import cn.zjhf.kingold.user.service.IUserService;
import cn.zjhf.kingold.user.service.IUserWechatHistService;
import cn.zjhf.kingold.user.utils.MapParamUtils;
import cn.zjhf.kingold.user.utils.RequestMapperConvert;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * @Author xiaody
 * @Description
 * @Date create in 17/10/30
 */

@RestController
@RequestMapping(value = "/userWechatHist")
public class UserWechatHistController {

    private final static Logger LOGGER = LoggerFactory.getLogger(UserWechatHistController.class);

    @Autowired
    private IUserWechatHistService userWechatHistService;

    @Autowired
    private IUserService userService;
    /**
     * 微信头像和昵称信息绑定绑定
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @PostMapping(value = "/upsert")
    public ResponseResult upsert(@RequestBody Map params) throws BusinessException {
        String userUuid = MapParamUtils.getStringInMap(params,"userUuid");
        if( StringUtils.isBlank(userUuid) ){
            throw new BusinessException(UserParamMsg.REQUEST_PARAM_ERROR_CODE, "参数userUuid是必填项", true);
        }

        userWechatHistService.upsert(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功");
    }

    /**
     * 获取用户头像和昵称（优先顺序：用微信的头像和昵称，默认头像和实名信息，默认头像和电话号码）
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @GetMapping(value = "/list")
    public ResponseResult getList(@RequestParam Map params) throws BusinessException {

        RequestMapperConvert.initParam(params);

        List<UserWechatHist> userWechatList = userWechatHistService.getList(params);

        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", userWechatList);
    }

}
