package cn.zjhf.kingold.user.constant;

/**
 * Created by liuyao on 2017/10/27.
 */
public enum LoginMethodEnum {
    PASSWORD(1, "密码登录"), SMS(2, "短信登录"), THIRD_WECHAT(3, "微信第三方"), THIRD_WEIBO(4, "微博第三方"),CAMP_WEIBO(5, "活动登录"),
    OPEN_PLATFORM(6, "开放平台登录");

    private int status;
    private String desc;

    LoginMethodEnum(int status, String desc) {
        this.status = status;
        this.desc = desc;
    }

    public static LoginMethodEnum getLoginMethodEnum(Integer status) {
        for (LoginMethodEnum method: LoginMethodEnum.values()) {
            if (method.getStatus() == status) {
                return method;
            }
        }
        return PASSWORD;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
