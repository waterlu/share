package cn.zjhf.kingold.user.utils;

import cn.zjhf.kingold.user.constant.InvestorKeyConstants;
import cn.zjhf.kingold.user.constant.InvestorRiskEnum;
import cn.zjhf.kingold.user.constant.InvestorRiskV1Enum;
import cn.zjhf.kingold.user.constant.UserKeyConstants;
import com.google.common.base.Splitter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;

import java.util.*;

public class UserPropertiesUtils {

    public final static Set<String> sensitiveData = new HashSet<>();

    static {
        sensitiveData.add(UserKeyConstants.USER_LOGIN_PASSWORD_STR);
        sensitiveData.add(UserKeyConstants.USER_PAY_PASSWORD_STR);
        sensitiveData.add(UserKeyConstants.ENCRYPT_SALT_STR);
        sensitiveData.add(UserKeyConstants.SIGNATURE_STR);
        sensitiveData.add(InvestorKeyConstants.INVESTOR_ADDRESS_STR);
        sensitiveData.add(InvestorKeyConstants.INVESTOR_RISK_ANSWER_STR);
    }

    public final static Set<String> innerData = new HashSet<>();
    static {
        innerData.add(UserKeyConstants.DELETE_FLAG_BYTE);
    }

    public final static Set<String> maskData = new HashSet<>();
    static {
        //maskData.add(InvestorKeyConstants.INVESTOR_ID_CARD_NO_STR);
    }

    /**
     * 获取需要的属性
     *
     * @param sourceMap  源属性
     * @param properties 需要的属性列表
     * @return 需要的属性
     */
    public static Map getNeedProperties(Map sourceMap, List<String> properties) {
        if (CollectionUtils.isEmpty(properties)) {
            return sourceMap;
        }
        if (sourceMap != null) {
            Map needMap = new HashMap<>();
            //只返回需要的属性
            for (Object property : properties) {
                if (null != sourceMap.get(property)) {
                    needMap.put(property, sourceMap.get(property).toString());
                }
            }
            return needMap;
        } else {
            return null;
        }
    }

    /**
     * 过滤完敏感信息的属性,映射不同版本属性
     *
     * @param sourceMap 源属性
     * @return
     */

    public static Map buildUserData(Map<String, Object> sourceMap) {
        if (sourceMap == null) {
            return Collections.EMPTY_MAP;
        }
        fillData(sourceMap);
        Map<String, Object> filterMap = new HashMap<>();
        for (Map.Entry<String, Object> entry : sourceMap.entrySet()) {
            if (sensitiveData.contains(entry.getKey()) || innerData.contains(entry.getKey())) {
                continue;
            }
            filterMap.put(entry.getKey(), maskOperation(entry.getKey(), entry.getValue()));
            String value = PropertyDescriptionUtils.getUserInfoDic(entry.getKey(), entry.getValue().toString());
            if (StringUtils.isNotEmpty(value)) {
                filterMap.put(entry.getKey() + "Desc", value);
            }
        }
        return filterMap;
    }

    private static void fillData(Map<String, Object> sourceMap) {

        if (sourceMap.get(InvestorKeyConstants.INVESTOR_RISK_SCORE_INT) == null ||
                Integer.valueOf(sourceMap.get(InvestorKeyConstants.INVESTOR_RISK_SCORE_INT).toString()) == 0) {
            return ;
        }
        Integer score = Integer.valueOf(sourceMap.get(InvestorKeyConstants.INVESTOR_RISK_SCORE_INT).toString());
        Integer version = Integer.valueOf(sourceMap.get(InvestorKeyConstants.INVESTOR_RISK_VERSION_INT).toString());
        String answer = sourceMap.get(InvestorKeyConstants.INVESTOR_RISK_ANSWER_STR).toString();


        if (version == 1) {
            InvestorRiskV1Enum riskEnum = InvestorRiskV1Enum.getRiskEnum(score);
            sourceMap.put(InvestorKeyConstants.INVESTOR_RISK_LEVEL_INT, riskEnum.getType());
            sourceMap.put(InvestorKeyConstants.INVESTOR_RISK_PRODUCT_INT, riskEnum.getType());
            sourceMap.put(InvestorKeyConstants.INVESTOR_RISK_TYPE_INT, riskEnum.getType());
            sourceMap.put(InvestorKeyConstants.INVESTOR_RISK_TYPE_STR, riskEnum.getDesc());
            //最低投资者类型判断
            //用户保守型且结果中如果有任一一道题答案为0分，则用户的风险承受类型为最低风险承受能力的投资者
            if (answer.contains("0") && Integer.valueOf(sourceMap.get(InvestorKeyConstants.INVESTOR_RISK_TYPE_INT).toString()) == 1) {
                sourceMap.put(InvestorKeyConstants.MIN_RISK_LEVEL, 1);
                sourceMap.put(InvestorKeyConstants.INVESTOR_RISK_TYPE_STR, "最低风险型");
            } else {
                sourceMap.put(InvestorKeyConstants.MIN_RISK_LEVEL, 0);
            }
        } else {
            InvestorRiskEnum riskEnum = InvestorRiskEnum.getRiskEnum(score);
            sourceMap.put(InvestorKeyConstants.INVESTOR_RISK_LEVEL_INT, riskEnum.getType());
            sourceMap.put(InvestorKeyConstants.INVESTOR_RISK_PRODUCT_INT, riskEnum.getType());
            sourceMap.put(InvestorKeyConstants.INVESTOR_RISK_TYPE_INT, riskEnum.getType());
            sourceMap.put(InvestorKeyConstants.INVESTOR_RISK_TYPE_STR, riskEnum.getDesc());
            List<String> answerList = Lists.newArrayList(Splitter.on("$$").trimResults().omitEmptyStrings().split(answer));
            //第1，8，9题第一选项为0分
            if (answerList != null && answerList.size() == 10 && Integer.valueOf(sourceMap.get(InvestorKeyConstants.INVESTOR_RISK_TYPE_INT).toString()) == 1 &&
                    ("1".equals(answerList.get(0)) || "1".equals(answerList.get(7)) || "1".equals(answerList.get(8)))) {
                sourceMap.put(InvestorKeyConstants.MIN_RISK_LEVEL, 1);
                sourceMap.put(InvestorKeyConstants.INVESTOR_RISK_TYPE_STR, "最低风险型");
            } else {
                sourceMap.put(InvestorKeyConstants.MIN_RISK_LEVEL, 0);
            }
        }


    }


    private static Object maskOperation(String key, Object value) {
        if (maskData.contains(key)) {
            switch (key) {
                case InvestorKeyConstants.INVESTOR_ID_CARD_NO_STR:
                    return value.toString().replaceAll("(?<=\\d{2})\\d(?=\\w{2})", "*");
                default:
                    return value;
            }
        }
        return value;
    }
}
