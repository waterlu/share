package cn.zjhf.kingold.user.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.user.persistence.dao.*;
import cn.zjhf.kingold.user.service.IAdvisorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Created by wangxun on 2016/11/04.
 * Copyright by zjinv
 */
@Service
public final class AdvisorServiceImpl implements IAdvisorService {

    @Autowired
    private AdvisorMapper advisorMapper;


    @Override
    public Map get(Map params) throws BusinessException {

        Map ui = advisorMapper.get(params);
        return ui;
    }

    @Override
    public int insert(Map params) throws BusinessException {
        return advisorMapper.insert(params);
    }

    @Override
    public int update( Map params) throws BusinessException {
        return advisorMapper.update(params);
    }

    @Override
    public Integer delete(Map params) throws BusinessException {
        int num = advisorMapper.delete(params);
        return num;
    }

    @Override
    public List<Map> getList(Map userMap) throws BusinessException {

        List<Map> userList = advisorMapper.getList(userMap);

        return userList;
    }

    @Override
    public int getCount(Map userMap) throws BusinessException {

        return advisorMapper.getCount(userMap);

    }

}