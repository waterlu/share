package cn.zjhf.kingold.user.entity.dto;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;
import java.util.Date;

/**
 * Created by liuyao on 2017/11/13.
 */
public class UpgradeAvailableDTO {
    public String userUuid;

    public Integer relationInvestCount;

    public Integer availableUpgrade;

    public Date upgradeDate;

    public Integer beforeUpgradeType;

    public Integer afterUpgradeType;

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public Integer getRelationInvestCount() {
        return relationInvestCount;
    }

    public void setRelationInvestCount(Integer relationInvestCount) {
        this.relationInvestCount = relationInvestCount;
    }

    public Integer getAvailableUpgrade() {
        return availableUpgrade;
    }

    public void setAvailableUpgrade(Integer availableUpgrade) {
        this.availableUpgrade = availableUpgrade;
    }

    public Integer getBeforeUpgradeType() {
        return beforeUpgradeType;
    }

    public void setBeforeUpgradeType(Integer beforeUpgradeType) {
        this.beforeUpgradeType = beforeUpgradeType;
    }

    public Integer getAfterUpgradeType() {
        return afterUpgradeType;
    }

    public void setAfterUpgradeType(Integer afterUpgradeType) {
        this.afterUpgradeType = afterUpgradeType;
    }

    public Date getUpgradeDate() {
        return upgradeDate;
    }

    public void setUpgradeDate(Date upgradeDate) {
        this.upgradeDate = upgradeDate;
    }
}
