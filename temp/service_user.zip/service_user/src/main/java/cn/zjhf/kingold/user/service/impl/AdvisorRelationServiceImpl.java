package cn.zjhf.kingold.user.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.user.persistence.dao.AdvisorRelationMapper;
import cn.zjhf.kingold.user.persistence.dao.BankInfoMapper;
import cn.zjhf.kingold.user.service.IAdvisorRelationService;
import cn.zjhf.kingold.user.service.IBankInfoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Created by wangxun on 2017/08/04.
 * Copyright by zjinv
 */
@Service
public class AdvisorRelationServiceImpl implements IAdvisorRelationService {
    private static final Logger LOGGER = LoggerFactory.getLogger(AdvisorRelationServiceImpl.class);
    @Autowired
    private AdvisorRelationMapper advisorRelationMapper;


    @Override
    public Map get(Map params) throws BusinessException {

        Map ui = advisorRelationMapper.get(params);
        return ui;
    }

    @Override
    public int insert(Map params) throws BusinessException {

        return advisorRelationMapper.insert(params);

    }

    @Override
    public int update( Map params) throws BusinessException {
        return advisorRelationMapper.update(params);
    }

    @Override
    public Integer delete(Map params) throws BusinessException {
        int num = advisorRelationMapper.delete(params);
        return num;
    }

    @Override
    public List<Map> getList(Map userMap) throws BusinessException {

        List<Map> userList = advisorRelationMapper.getList(userMap);

        return userList;
    }

    @Override
    public int getCount(Map userMap) throws BusinessException {

        return advisorRelationMapper.getCount(userMap);

    }




}