package cn.zjhf.kingold.user.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.user.entity.dto.UpgradeAvailableDTO;
import cn.zjhf.kingold.user.entity.vo.UserCommonParamVO;
import cn.zjhf.kingold.user.service.IAchievementService;
import cn.zjhf.kingold.user.service.IInvestorRelationService;
import cn.zjhf.kingold.user.utils.RequestMapperConvert;
import cn.zjhf.kingold.user.utils.UtilTools;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Created by liuyao on 17/11/13.
 */
@RestController
@RequestMapping("/user/achievement")
public class UserAchievementController {

    @Autowired
    private IAchievementService achievementService;

    /**
     * 用户升级理财达人
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/upgradeTalentApply", method = RequestMethod.POST)
    public ResponseResult upgradeApply(@RequestBody UserCommonParamVO userCommonParamVO) throws BusinessException {
        achievementService.upgradeTalentApply(userCommonParamVO.getUserUuid());
        return new ResponseResult(userCommonParamVO.getTraceID(), ResponseCode.REQUEST_SUCCESS, "成功");
    }


    /**
     *  获取用户业绩
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @RequestMapping(value = "/{userUuid}", method = RequestMethod.GET)
    public ResponseResult getAchievement(@PathVariable("userUuid") String userUuid,
                                         @RequestParam(value = "traceID") String traceID) throws BusinessException {

        UpgradeAvailableDTO upgradeAvailableDTO = achievementService.moneyManageTalentProgress(userUuid);
        return new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS, "成功", upgradeAvailableDTO);
    }


}
