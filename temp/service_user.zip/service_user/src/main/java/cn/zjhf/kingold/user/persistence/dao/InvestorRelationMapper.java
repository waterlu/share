package cn.zjhf.kingold.user.persistence.dao;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * Created by liuyao on 2017/5/11.
 */
@Repository
public interface InvestorRelationMapper {

    int insert(Map<String, Object> params);

    Map<String, Object> get(@Param("userUuid") String userUuid);

    List<Map> getList(Map map);

    List<String> getAllRelation(Map map);

    Integer getCount(Map map);

    List<Map> getRelationOpenid(Map map);

    /**
     * 上3级邀请人电话和姓名
     * @param map investorMobile 必填
     */
    List<Map> getUpThreeInvestor(Map map);

    /**
     * 获取金疙瘩好友电话和姓名，及银疙瘩数量
     * @param map userUuid 必填
     */
    List<Map> getDownOneInvestor(Map map);

    /**
     * 获取下级数量
     * @param map
     * @return
     */
    int getDownOneInvestorCount(Map map);

    /**
     * 获取金疙瘩好友数量
     * @param userUuid
     * @return
     */
    int getGoldCount(@Param("userUuid") String userUuid);

    /**
     * 获取银疙瘩好友数量
     * @param userUuid
     * @return
     */
    int getSilverCount(@Param("userUuid") String userUuid);

    /**
     * 获取铜疙瘩好友数量
     * @param userUuid
     * @return
     */
    int getCopperCount(@Param("userUuid") String userUuid);

    /**
     * 获取自己的父类，子类和自己的uuid
     * @param map userUuid 必填
     */
    List<Map> getFatherAndSonAndSelfList(Map map);

    /**
     * 获取自己的父类，子类和自己的uuid 的总数量
     * @param map userUuid 必填
     */
    int getFatherAndSonAndSelfCount(Map map);

}
