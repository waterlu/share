package cn.zjhf.kingold.user.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.service_consumer.service.ProductServiceConsumer;
import cn.zjhf.kingold.user.constant.*;
import cn.zjhf.kingold.user.entity.Achievement;
import cn.zjhf.kingold.user.entity.InvestorChangeLog;
import cn.zjhf.kingold.user.entity.dto.OrderDTO;
import cn.zjhf.kingold.user.entity.dto.UpgradeAvailableDTO;
import cn.zjhf.kingold.user.persistence.dao.AchievementMapper;
import cn.zjhf.kingold.user.persistence.dao.InvestorChangeLogMapper;
import cn.zjhf.kingold.user.persistence.dao.TradeOrderMapper;
import cn.zjhf.kingold.user.service.IAchievementService;
import cn.zjhf.kingold.user.service.IInvestorRelationService;
import cn.zjhf.kingold.user.service.IUserService;
import cn.zjhf.kingold.user.service.IUserTransactionService;
import cn.zjhf.kingold.user.utils.MapParamUtils;
import cn.zjhf.kingold.user.utils.ObjectUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Created by liuyao on 2017/11/9.
 */
@Service
public class AchievementServiceImpl implements IAchievementService {

    @Autowired
    private AchievementMapper achievementMapper;
    @Autowired
    private IInvestorRelationService investorRelationService;
    @Autowired
    private IUserService userService;
    @Autowired
    private IUserTransactionService userTransactionService;
    @Autowired
    private TradeOrderMapper tradeOrderMapper;
    @Autowired
    private ProductServiceConsumer productServiceConsumer;
    @Autowired
    private InvestorChangeLogMapper investorChangeLogMapper;

    private final static Logger LOGGER = LoggerFactory.getLogger(AchievementServiceImpl.class);
    private final static Integer MONEY_MANAGE_TALENT_PROGRESS_COMPLETE_COUNT = 10;

    @Override
    public int generateAchievement(OrderDTO orderDTO) throws BusinessException {
        Map<String, Object> relation = investorRelationService.getInvestorRelation(orderDTO.getOrderUserUuid());
        List<Achievement> achievementList = buildAchievementBaseOnRelation(relation, orderDTO);
        if (CollectionUtils.isEmpty(achievementList)) {
            return 0;
        }
        int insertCount = achievementMapper.batchInsert(achievementList);
        LOGGER.info("generateAchievement success. insertCount={}, listCount={}", insertCount, achievementList.size());
        return insertCount;
    }

    @Override
    public UpgradeAvailableDTO moneyManageTalentProgress(String userUuid) throws BusinessException {
        UpgradeAvailableDTO upgradeAvailableDTO = new UpgradeAvailableDTO();
        int count = achievementMapper.getAchievementProgress(userUuid);
        upgradeAvailableDTO.setUserUuid(userUuid);
        upgradeAvailableDTO.setRelationInvestCount(count);
        upgradeAvailableDTO.setAvailableUpgrade(0);
        if (count < MONEY_MANAGE_TALENT_PROGRESS_COMPLETE_COUNT) {
            return upgradeAvailableDTO;
        }
        Map<String, Object> params = new HashMap<>();
        params.put(UserKeyConstants.USER_UUID_STR,userUuid);
        Map user = userService.getUser(params, false);
        // 绑卡且不是理财达人
        if (MapParamUtils.getIntInMap(user, UserKeyConstants.USER_VERIFY_STATUS_INT) >= UserVerifyStatus.USER_BIND_CARD_SUCCESS.getStatus()  &&
                MapParamUtils.getIntInMap(user, InvestorKeyConstants.INVESTOR_TYPE_BYTE) < InvestorType.MONEY_MANAGE_TALENT) {
            upgradeAvailableDTO.setAvailableUpgrade(1);
        }
        //如果是理财达人，设置开启时间
        if (MapParamUtils.getIntInMap(user, InvestorKeyConstants.INVESTOR_TYPE_BYTE) == InvestorType.MONEY_MANAGE_TALENT) {
            InvestorChangeLog investorChangeLog = investorChangeLogMapper.selectByUserUuid(MapParamUtils.getStringInMap(user, UserKeyConstants.USER_UUID_STR));
            if (investorChangeLog != null) {
                upgradeAvailableDTO.setUpgradeDate(investorChangeLog.getCreateTime());
            } else {
                upgradeAvailableDTO.setUpgradeDate(new Date());
            }
        }
        return upgradeAvailableDTO;
    }

    @Override
    public void upgradeTalentApply(String userUuid) throws BusinessException {
        UpgradeAvailableDTO upgradeAvailableDTO = moneyManageTalentProgress(userUuid);
        if (upgradeAvailableDTO.getAvailableUpgrade() == 0) {
            throw new BusinessException(UserParamMsg.USER_UPGRADE_TALENT_ERROR_CODE, UserParamMsg.USER_UPGRADE_TALENT_ERROR_MSG, true);
        }
        int count = userTransactionService.upgradeUser(userUuid);
        LOGGER.info("upgradeTalentApply success. effectCount={}", count);
    }

    private List<Achievement> buildAchievementBaseOnRelation(Map<String, Object> relation, OrderDTO orderDTO) {
        List<Achievement> result = new ArrayList<>();
        try {
            buildAchievementCommonData(relation.get(InvestorRelationKeyConstants.INVITER_LEVEL_ONE_UUID_STR),
                    RelationTypeEnum.INVITER_LEVEL_ONE, orderDTO, result);
            buildAchievementCommonData(relation.get(InvestorRelationKeyConstants.INVITER_LEVEL_TWO_UUID_STR),
                    RelationTypeEnum.INVITER_LEVEL_TWO, orderDTO, result);
            buildAchievementCommonData(relation.get(InvestorRelationKeyConstants.INVITER_LEVEL_THREE_UUID_STR),
                    RelationTypeEnum.INVITER_LEVEL_THREE, orderDTO, result);
            buildAchievementCommonData(orderDTO.getOrderUserUuid(),
                    RelationTypeEnum.SELF, orderDTO, result);
        } catch (Exception e) {
            LOGGER.error("buildAchievementBaseOnRelation failed. order={}", orderDTO, e);
        }
        return result;
    }

    private void buildAchievementCommonData(Object inviterUuid, RelationTypeEnum relationTypeEnum, OrderDTO orderDTO,
                                            List<Achievement> sourceList) throws Exception {
        if (inviterUuid == null) return;
        Achievement achievement = new Achievement();
        ObjectUtil.copy(orderDTO, achievement);
        achievement.setRelation(relationTypeEnum.getType());
        achievement.setAchievementAmount(orderDTO.getOrderAmount());
        achievement.setUserUuid(inviterUuid.toString());
        sourceList.add(achievement);
    }
}
