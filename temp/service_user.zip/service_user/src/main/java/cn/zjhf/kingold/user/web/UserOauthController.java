package cn.zjhf.kingold.user.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.user.entity.UserOauth;
import cn.zjhf.kingold.user.service.IUserOauthService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * @Author xiaody
 * @Description
 * @Date create in 17/10/30
 */

@RestController
@RequestMapping(value = "/userOauth")
public class UserOauthController {

    private final static Logger LOGGER = LoggerFactory.getLogger(UserOauthController.class);

    @Autowired
    private IUserOauthService userOauthService;

    /**
     * 用户解绑第三方授权绑定
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @PostMapping(value = "/unbind")
    public ResponseResult unbind(@RequestBody Map params) throws BusinessException {

        userOauthService.unbind(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功");
    }

    /**
     * 用户第三方授权绑定
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @PostMapping(value = "/bind")
    public ResponseResult bind(@RequestBody Map params) throws BusinessException {
        userOauthService.bind(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功");
    }

    /**
     * 获取用户第三方授权绑定
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @GetMapping(value = "/list")
    public ResponseResult getList(@RequestParam Map params) throws BusinessException {
        List<UserOauth> userOauthList = userOauthService.getList(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", userOauthList);
    }


    /**
     * 根据用户uuid批量获取微信相关绑定信息
     *
     * @return {@link ResponseResult} 统一返回结构
     * @throws BusinessException 业务封装异常
     */
    @GetMapping(value = "/getWechatInfo")
    public ResponseResult getWechatInfo(@RequestParam Map params) throws BusinessException {
        Map<String, UserOauth> userOauthMap = userOauthService.getWechatInfo(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", userOauthMap);
    }
}
