###############################
# 增加用户状态变更表
###############################
CREATE TABLE `user_status_log` (
  `user_status_log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `user_uuid` char(32) NOT NULL COMMENT '用户UUID',
  `status_type` tinyint(4) NOT NULL COMMENT '1-认证状态 2-交易状态',
  `status_old` tinyint(4) NOT NULL COMMENT '变更前的状态',
  `status_new` tinyint(4) NOT NULL COMMENT '变更后的状态',
  `change_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '变更时间',
  `order_bill_code` varchar(32) DEFAULT NULL COMMENT '订单号',
  `delete_flag` tinyint(4) NOT NULL DEFAULT '0',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`user_status_log_id`),
  KEY `idx_user_status_log_user_uuid` (`user_uuid`),
  KEY `idx_user_status_log_order_bill_code` (`order_bill_code`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='用户状态变更日志';