package cn.zjhf.kingold.user.service.impl;

import cn.zjhf.kingold.user.UserinfoApplication;
import cn.zjhf.kingold.user.persistence.mq.consumer.ProductEstablishConsumer;
import cn.zjhf.kingold.user.persistence.mq.message.ProductMessage;
import cn.zjhf.kingold.user.service.IAchievementService;
import cn.zjhf.kingold.user.service.IUserService;
import cn.zjhf.kingold.user.utils.JavaTypeChangeUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by DELL on 2017/5/6.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = UserinfoApplication.class)
public class AchievementTest {


    @Autowired
    IAchievementService achievementService;


    @Test
    public void testAll() throws Exception {

    }



}