package cn.zjhf.kingold.user;

import cn.zjhf.kingold.user.utils.EncryptUtils;
import org.junit.Test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by DELL on 2017/5/10.
 */
public class LocalTest {
    @Test
    public void contextLoads() {
        String answer = "1$$3$$1$$4$$2$$3$$2$$2$$1$$1";
        String result = answer.replace("$$", ",");

        System.out.println(result + "---"+ answer);
    }


}
