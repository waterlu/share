package cn.zjhf.kingold.user.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.user.UserinfoApplication;
import cn.zjhf.kingold.user.constant.InvestorRelationKeyConstants;
import cn.zjhf.kingold.user.persistence.mq.consumer.ProductEstablishConsumer;
import cn.zjhf.kingold.user.persistence.mq.message.ProductMessage;
import cn.zjhf.kingold.user.service.IInvestorRelationService;
import cn.zjhf.kingold.user.service.IUserService;
import cn.zjhf.kingold.user.utils.JavaTypeChangeUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by DELL on 2017/5/6.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = UserinfoApplication.class)
public class UserServiceImplTest {

    @Autowired
    IUserService userService;

    @Autowired
    ProductEstablishConsumer productEstablishConsumer;

    @Autowired
    IInvestorRelationService investorRelationService;

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }


    @Test
    @Transactional
    public void testAll() throws Exception {

//        Long id = insert();
//        update(id);
//        get(id);
//        getList();
//        getCount();

        Map mapParams = new HashMap<>();
        mapParams.put("investorMobile","19900000000");
        mapParams.put("verifyCode","0000");
        mapParams.put("userLoginPassword","123456");
//        mapParams.put("inviterPhone","");
        userService.regist( mapParams);
        Map map1Params = new HashMap<>();
        map1Params.put("investorMobile","19900000000");
        map1Params.put("verifyCode","0000");
        map1Params.put("userLoginPassword","123456");

        Map userMap = userService.login(map1Params);

        Map map2Params = new HashMap<>();
        map2Params.put("investorMobile","19900000000");
        map2Params.put("verifyCode","0000");
        map2Params.put("userPayPassword","123456");

//        userService.resetUserPw(map2Params);

        Map map3Params = new HashMap<>();

        map3Params.put("userPayPassword","123456");
        map3Params.put("userUuid",userMap.get("userUuid"));
        //userService.initPayPw( map3Params);
       // userService.checkPayPw(map3Params);

    }

//    @Test
    public void get(Long id) throws Exception {
        Map getParams = new HashMap<>();
        getParams.put("userTokenId",id);
        Map userTokenMap = userService.getInvestorWithFilter(getParams);
        Assert.assertNotNull(userTokenMap.get("token"));
    }

//    @Test
    public Long insert() throws Exception {
        Map params = new HashMap<>();
        params.put("userUuid","userUuid_test");
        params.put("token","token_test");
        params.put("investorMobile","user_phone");
        int num = userService.insert(params);
        System.out.println("uesrTokenId:"+params.get("userTokenId"));
        Assert.assertNotNull(params.get("userTokenId"));

        Assert.assertEquals(num , 1);
        return JavaTypeChangeUtils.getLong(params,"userTokenId");
    }

//    @Test
    public void update(Long id) throws Exception {
        Map params = new HashMap<>();
        params.put("userUuid","userUuid_test");
        params.put("token","token_test_change");
        params.put("userTokenId",id);

        int num = userService.update(params);
        Map getParams = new HashMap<>();
        getParams.put("userTokenId",id);
        Map userTokenMap = userService.getInvestorWithFilter(getParams);
        System.out.println("uesrTokenId:"+params.get("userTokenId"));
        Assert.assertEquals(params.get("token"),userTokenMap.get("token"));
        Assert.assertEquals(num , 1);
    }

    @Test
    public void productEstablish() throws Exception {
        ProductMessage productMessage = new ProductMessage();
        productMessage.setProductUuid("c7c9fb57866242f99814fdd022e5b415");
        productEstablishConsumer.process(productMessage);
    }

    @Test
    public void getGoldRelation() throws Exception {
        Map param = new HashMap();
        param.put("startRow",0);
        param.put("pageSize",20);
       // param.put("userTradeStatus", 0);
        param.put("inviterLevelOneUuid","d62bae4308a048249dc4ee5d8542ae38");
        //investorRelationService.getRelationSortByTime(param);
        investorRelationService.getRelationSortByReward(param);

    }


}