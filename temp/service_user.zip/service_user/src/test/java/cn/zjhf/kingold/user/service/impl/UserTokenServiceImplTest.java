package cn.zjhf.kingold.user.service.impl;

import cn.zjhf.kingold.user.UserinfoApplication;
import cn.zjhf.kingold.user.service.IUserTokenService;
import cn.zjhf.kingold.user.utils.JavaTypeChangeUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;

/**
 * Created by DELL on 2017/5/6.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = UserinfoApplication.class)
public class UserTokenServiceImplTest {

    @Autowired
    IUserTokenService userTokenService;

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }


    @Test
    @Transactional
    public void testAll() throws Exception {

        Long id = insert();
        update(id);
        get(id);
        getList();
        getCount();
        //logout("investorMobile");

    }

//    @Test
    public void get(Long id) throws Exception {
        Map getParams = new HashMap<>();
        getParams.put("userTokenId",id);
        Map userTokenMap = userTokenService.get(getParams);
        Assert.assertNotNull(userTokenMap.get("token"));
    }

//    @Test
    public Long insert() throws Exception {
        Map params = new HashMap<>();
        params.put("userUuid","userUuid_test");
        params.put("token","token_test");
        params.put("userPhone","user_phone");
        int num = userTokenService.insert(params);
        System.out.println("uesrTokenId:"+params.get("userTokenId"));
        Assert.assertNotNull(params.get("userTokenId"));

        Assert.assertEquals(num , 1);
        return JavaTypeChangeUtils.getLong(params,"userTokenId");
    }

//    @Test
    public void update(Long id) throws Exception {
        Map params = new HashMap<>();
        params.put("userUuid","userUuid_test");
        params.put("token","token_test_change");
        params.put("userTokenId",id);

        int num = userTokenService.update(params);
        Map getParams = new HashMap<>();
        getParams.put("userTokenId",id);
        Map userTokenMap = userTokenService.get(getParams);
        System.out.println("uesrTokenId:"+params.get("userTokenId"));
        Assert.assertEquals(params.get("token"),userTokenMap.get("token"));
        Assert.assertEquals(num , 1);
    }

//    @Test
    public void delete(Long id) throws Exception {
        Map params = new HashMap<>();
        params.put("userTokenId",id);
        int num = userTokenService.delete(params);
        Assert.assertEquals(num , 1);
    }

//    @Test
    public void getList() throws Exception {
        Map params = new HashMap<>();
        params.put("userUuid","userUuid_test");
        params.put("token","token_test");

        List<Map> resultList = userTokenService.getList(params);
        Assert.assertEquals(resultList.size() , 1);


    }

    //    @Test
    public void getCount() throws Exception {
        Map params = new HashMap<>();
        params.put("userUuid","userUuid_test");
        params.put("token","token_test");

        int num = userTokenService.getCount(params);
        Assert.assertEquals(num , 1);
    }

//    @Test
    public void logout(String userPhone) throws Exception {
        Map params = new HashMap<>();
        params.put("userPhone",userPhone);
        int num = userTokenService.logout(params);
        Assert.assertEquals(num , 1);

    }

}