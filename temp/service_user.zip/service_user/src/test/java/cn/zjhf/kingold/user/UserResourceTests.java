package cn.zjhf.kingold.user;

import cn.zjhf.kingold.user.dto.UpdateTradeStatusDTO;
import com.alibaba.fastjson.JSON;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

import java.math.BigDecimal;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * @author lutiehua
 * @date 2018/3/16
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@WebAppConfiguration
@Transactional
public class UserResourceTests {

    private final Logger logger = LoggerFactory.getLogger(UserResourceTests.class);

    private MockMvc mvc;

    @Autowired
    protected WebApplicationContext wac;

    @Before
    public void setUp() throws Exception {
        mvc = MockMvcBuilders.webAppContextSetup(wac).build();
    }

    /**
     * 测试更新用户交易状态
     */
    @Test
    public void testUpdateTradeStatus() throws Exception {
        String callSystemID = "1001";
        String tradeID = "9dc9805a-2220-11e8-9955-00163e32c6dd";
        String user_uuid = "c675171a4be543fcb7ab9e7d00b39d5b";
        String orderBillCode = "POX201803161326205886577";

        // REST资源访问地址
        String uri = String.format("/user/%s/updateTradeStatus", user_uuid);

        // 参数
        UpdateTradeStatusDTO updateTradeStatusDTO = new UpdateTradeStatusDTO();
        updateTradeStatusDTO.setTraceID(tradeID);
        updateTradeStatusDTO.setCallSystemID(callSystemID);
        updateTradeStatusDTO.setOrderBillCode(orderBillCode);

        // HTTP PUT 请求
        RequestBuilder request = MockMvcRequestBuilders.put(uri)
                .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
                .content(JSON.toJSONString(updateTradeStatusDTO));
        // 发送请求
        ResultActions resultActions = mvc.perform(request);

        // 设置返回数据编码格式
        resultActions.andReturn().getResponse().setCharacterEncoding("UTF-8");

        // 输出返回值
        String response = resultActions.andReturn().getResponse().getContentAsString();
        logger.info(response);

        // 校验返回值（相当于Assert），失败报错
        // HTTP.code = 200
        // "code":200
        // "data":1
        resultActions.andExpect(status().isOk())
                .andExpect(jsonPath("code").value("200"));
    }

}
