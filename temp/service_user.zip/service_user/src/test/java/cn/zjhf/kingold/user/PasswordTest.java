package cn.zjhf.kingold.user;

import cn.zjhf.kingold.user.utils.*;

public class PasswordTest {

    public static void getPassword(){

    }

    public static void checkPassword(){
        //判断密码是否一致,密码是不是金疙瘩用户密码。
        String salt = "250c30626b867cd9";
        String paramUserPassword = EncryptUtils.encryptSalt("2112868");
//        if (!userMap.get(UserKeyConstants.USER_LOGIN_PASSWORD_STR).equals(paramUserPassword)) {
        //判断密码是不是星耀密码。
        if (!validatePassword(paramUserPassword, "250c30626b867cd9ff900f07b153a2248ae3d4316a5b12560ba27836")) {
            System.out.println("error!!!");
        }else{
            System.out.println("success");
        }
//        }
    }
    public static  boolean validatePassword(String plainPassword, String password) {
        String plain = Encodes.unescapeHtml(plainPassword);
        byte[] salt = Encodes.decodeHex(password.substring(0,16));
        byte[] hashPassword = Digests.sha1(plain.getBytes(), salt, 1024);
        return password.equals(Encodes.encodeHex(salt)+Encodes.encodeHex(hashPassword));
    }

    public static void main(String[] args){
//        System.out.println(Encodes.encodeHex(Encodes.decodeHex("250c30626b867cd9")));
//
//        System.out.println("password:"+PasswordTest.entryptPassword("2112868"));
        String inputPassword = HexSHA1.hex_sha1("2112868");
        String dbPassword = "250c30626b867cd9ff900f07b153a2248ae3d4316a5b12560ba27836";
        System.out.println(inputPassword);
        System.out.println(dbPassword);
        System.out.println(validatePassword(inputPassword,dbPassword));
    }
}
