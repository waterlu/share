# version

## 1.0.0

基于Spring Boot Admin实现基本的服务监控