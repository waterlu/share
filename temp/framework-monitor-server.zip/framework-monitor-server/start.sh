#!/bin/bash
nohup java -server -Xms128m -Xmx128m -jar target/framework-monitor-server-1.0.0.jar > /dev/null 2>&1 &