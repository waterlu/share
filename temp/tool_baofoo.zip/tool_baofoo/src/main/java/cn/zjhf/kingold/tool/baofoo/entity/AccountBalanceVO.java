package cn.zjhf.kingold.tool.baofoo.entity;

/**
 * Created by DELL on 2017/4/18.
 */
public class AccountBalanceVO {

    private String userID;

    private String merchantID;

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getMerchantID() {
        return merchantID;
    }

    public void setMerchantID(String merchantID) {
        this.merchantID = merchantID;
    }


}
