package cn.zjhf.kingold.tool.baofoo.entity;

/**
 * Created by DELL on 2017/4/18.
 */
public class RegisterPageVO {
    private String bfAccount;

    private String name;

    private String idCard;

    private String userID;

    public String getBfAccount() {
        return bfAccount;
    }

    public void setBfAccount(String bfAccount) {
        this.bfAccount = bfAccount;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }
}
