package cn.zjhf.kingold.tool.baofoo.api;

/**
 * Created by lutiehua on 2017/5/3.
 */
public interface BaoFooCode {

    String OK = "CSD000";

    String WITHDRAW_INIT = "0";

    String WITHDRAW_SUCCESS = "1";

    String WITHDRAW_ERROR = "-1";

    String WITHDRAW_PENDING = "5";

    int WITHDRAW_INIT_STATE = 0;

    int WITHDRAW_SUCCESS_STATE = 1;

    int WITHDRAW_ERROR_STATE = -1;

    int WITHDRAW_PENDING_STATE = 5;
}
