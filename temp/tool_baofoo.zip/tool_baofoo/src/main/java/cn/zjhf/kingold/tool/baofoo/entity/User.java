package cn.zjhf.kingold.tool.baofoo.entity;

/**
 * @author lu
 * @date 2018/5/9
 */
public class User {

    private long userId;

    private String userUuid;

}
