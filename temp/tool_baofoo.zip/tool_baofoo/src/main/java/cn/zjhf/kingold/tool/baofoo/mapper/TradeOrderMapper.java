package cn.zjhf.kingold.tool.baofoo.mapper;

import cn.zjhf.kingold.tool.baofoo.entity.TradeOrder;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author lu
 * @date 2018/5/9
 */
@Repository
public interface TradeOrderMapper {

    /**
     * 读取产品信息
     *
     * @param productUuid
     * @return
     */
    List<TradeOrder> selectByProductUuid(String productUuid);

    /**
     *
     * @param productUuid
     * @return
     */
    int updateCancelStatus(String productUuid);
}
