package cn.zjhf.kingold.tool.baofoo.entity;

import java.util.List;

/**
 * Created by lutiehua on 2017/4/19.
 */
public class InvestVO {

    private String merchantID;

    private String userID;

    private String orderID;

    private String productUUID;

    private String productID;

    private String productName;

    private String borrowerID;

    private Double amount;

    private Double fee;

    public List<TradeOrder> getUserList() {
        return userList;
    }

    public void setUserList(List<TradeOrder> userList) {
        this.userList = userList;
    }

    private List<TradeOrder> userList;

    public String getProductUUID() {
        return productUUID;
    }

    public void setProductUUID(String productUUID) {
        this.productUUID = productUUID;
    }

    public String getMerchantID() {
        return merchantID;
    }

    public void setMerchantID(String merchantID) {
        this.merchantID = merchantID;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getOrderID() {
        return orderID;
    }

    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    public String getProductID() {
        return productID;
    }

    public void setProductID(String productID) {
        this.productID = productID;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getBorrowerID() {
        return borrowerID;
    }

    public void setBorrowerID(String borrowerID) {
        this.borrowerID = borrowerID;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public Double getFee() {
        return fee;
    }

    public void setFee(Double fee) {
        this.fee = fee;
    }

}
