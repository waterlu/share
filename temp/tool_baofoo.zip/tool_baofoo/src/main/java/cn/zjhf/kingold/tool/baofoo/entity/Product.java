package cn.zjhf.kingold.tool.baofoo.entity;

/**
 * @author lu
 * @date 2018/5/9
 */
public class Product {

    private long productId;

    private String productUuid;

    private String productName;

    private String payeeUserUuid;

    private String payeeAccountUuid;

    private long accountNo;

    private String accountType;

    public long getProductId() {
        return productId;
    }

    public void setProductId(long productId) {
        this.productId = productId;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getPayeeAccountUuid() {
        return payeeAccountUuid;
    }

    public void setPayeeAccountUuid(String payeeAccountUuid) {
        this.payeeAccountUuid = payeeAccountUuid;
    }

    public long getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(long accountNo) {
        this.accountNo = accountNo;
    }

    public String getPayeeUserUuid() {
        return payeeUserUuid;
    }

    public void setPayeeUserUuid(String payeeUserUuid) {
        this.payeeUserUuid = payeeUserUuid;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }
}
