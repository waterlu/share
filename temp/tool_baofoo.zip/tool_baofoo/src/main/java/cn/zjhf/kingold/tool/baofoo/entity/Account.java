package cn.zjhf.kingold.tool.baofoo.entity;

/**
 * @author lu
 * @date 2018/5/10
 */
public class Account {

    private String userUuid;

    private String accountUuid;

    private String accountType;

    private Long accountNo;


    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getAccountUuid() {
        return accountUuid;
    }

    public void setAccountUuid(String accountUuid) {
        this.accountUuid = accountUuid;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public Long getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(Long account_No) {
        this.accountNo = account_No;
    }
}
