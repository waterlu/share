package cn.zjhf.kingold.tool.baofoo.entity;

/**
 * Created by lutiehua on 2017/4/18.
 */
public class AddBankCardVO {
    private String userID;
    private String mobile;
    private String bankNo;
    private String validateCode;

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getBankNo() {
        return bankNo;
    }

    public void setBankNo(String bankNo) {
        this.bankNo = bankNo;
    }

    public String getValidateCode() {
        return validateCode;
    }

    public void setValidateCode(String validateCode) {
        this.validateCode = validateCode;
    }
}
