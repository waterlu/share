package cn.zjhf.kingold.tool.baofoo.service.impl;

import cn.zjhf.kingold.tool.baofoo.api.BaoFooResponse;
import cn.zjhf.kingold.tool.baofoo.entity.*;
import cn.zjhf.kingold.tool.baofoo.mapper.AccountMapper;
import cn.zjhf.kingold.tool.baofoo.mapper.ProductMapper;
import cn.zjhf.kingold.tool.baofoo.mapper.TradeOrderMapper;
import cn.zjhf.kingold.tool.baofoo.service.ProductService;
import cn.zjhf.kingold.tool.baofoo.util.BizUtil;
import cn.zjhf.kingold.tool.baofoo.util.EncryptUtil;
import cn.zjhf.kingold.tool.baofoo.util.XmlTool;
import com.alibaba.fastjson.JSONObject;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author lu
 * @date 2018/5/9
 */
@Service
public class ProductServiceImpl implements ProductService {

    private Logger logger = LoggerFactory.getLogger(ProductServiceImpl.class);

    @Autowired
    private OkHttpClient okHttpClient;

    @Autowired
    private EncryptUtil encryptUtil;

    @Autowired
    private ProductMapper productMapper;

    @Autowired
    private TradeOrderMapper tradeOrderMapper;

    @Autowired
    private AccountMapper accountMapper;

    @Value("${baofoo.url}")
    private String baofooUrl;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public synchronized String cancelProduct(CancelProjectVO param) throws Exception {
        String productUUID = param.getProductUUID();
        if (null == productUUID || productUUID.length() == 0) {
            throw new Exception("productUUID不能为空");
        }

        String requestParams = param.getRequestParams();
        if (null == requestParams || requestParams.length() == 0) {
            throw new Exception("请求参数不能为空");
        }

        String orderId = param.getOrderId();
        if (null == orderId || orderId.length() == 0) {
            throw new Exception("订单编号不能为空");
        }

        // 读取产品信息
        List<Product> productList = productMapper.selectByProductUuid(productUUID);
        Product product = productList.get(0);
        if (null == product) {
            throw new Exception("读取产品信息失败");
        }

        // 募集方信息
        String payeeUserUUID = product.getPayeeUserUuid();
        String payeeAccountUuid = product.getPayeeAccountUuid();
        Long payeeAccountNo = product.getAccountNo();
        String payeeAccontType = product.getAccountType();

        // 读取订单信息
        List<TradeOrder> tradeOrderList = tradeOrderMapper.selectByProductUuid(productUUID);
        if(tradeOrderList.size() == 0) {
            throw new Exception("读取订单信息失败");
        }

        // 读取平台账户信息
        Account platformAccount = accountMapper.getPlatformAccount();

        String tradeType = "RFX";

        // 更新产品状态为21-已作废
        int row = productMapper.updateCancelStatus(productUUID);
        if (row == 0) {
            throw new Exception("更新产品状态失败");
        }

        // 更新订单状态为9-已撤销
        row = tradeOrderMapper.updateCancelStatus(productUUID);
        if (row == 0) {
            throw new Exception("更新订单状态失败");
        }

        BigDecimal platformAmount = BigDecimal.ZERO;

        for (TradeOrder tradeOrder : tradeOrderList) {
            // 投资人信息
            String userUuid = tradeOrder.getUserUuid();
            String accountUuid = tradeOrder.getAccountUuid();
            Long accountNo = tradeOrder.getAccountNo();
            String accountType = "21";
            BigDecimal amount = tradeOrder.getPaidAmount();
            String orderBillCode = tradeOrder.getOrderBillCode();
            String remark = String.format("订单[%s]退款", orderBillCode);

            // 添加投资人账户流水
            AccountTransaction transaction = new AccountTransaction();
            transaction.setUserUuid(userUuid);
            transaction.setAccountUuid(accountUuid);
            transaction.setAccountNo(accountNo);
            transaction.setAccountType(accountType);
            transaction.setOppoUserUuid(payeeUserUUID);
            transaction.setOppoAccountUuid(payeeAccountUuid);
            transaction.setOppoAccountNo(payeeAccountNo);
            transaction.setAccountTransactionUuid(BizUtil.generateUUID());
            transaction.setTradeType(tradeType);
            transaction.setTransactionBillCode(BizUtil.generateOrderBillCode(tradeType));
            transaction.setTransactionAmount(amount);
            transaction.setRemark(remark);
            transaction.setTradeOrderBillCodeExtend(orderId);
            row = accountMapper.addTransaction(transaction);
            if (row == 0) {
                throw new Exception("添加账户[" + accountUuid + "]流水失败");
            }

            // 更新投资人账户余额
            Map<String, Object> updateCashParam = new HashMap(4);
            updateCashParam.put("accountUuid", accountUuid);
            updateCashParam.put("amount", amount);
            row = accountMapper.updateAmount(updateCashParam);
            if (row == 0) {
                throw new Exception("更新账户[" + accountUuid + "]余额失败");
            }

            // 减平台账户余额
            platformAmount = platformAmount.subtract(amount);
        }

        // 添加平台账户流水
        AccountTransaction transaction = new AccountTransaction();
        transaction.setUserUuid(platformAccount.getUserUuid());
        transaction.setAccountUuid(platformAccount.getAccountUuid());
        transaction.setAccountNo(platformAccount.getAccountNo());
        transaction.setAccountType(platformAccount.getAccountType());
        transaction.setAccountTransactionUuid(BizUtil.generateUUID());
        transaction.setTradeType(tradeType);
        transaction.setTransactionBillCode(BizUtil.generateOrderBillCode(tradeType));
        transaction.setTransactionAmount(platformAmount);
        transaction.setRemark("产品[" + productUUID + "]流标");
        transaction.setTradeOrderBillCodeExtend(orderId);
        row = accountMapper.addTransaction(transaction);
        if (row == 0) {
            throw new Exception("添加账户[" + payeeAccountUuid + "]流水失败");
        }

        // 更新平台账户余额
        Map<String, Object> updatePlatformCashParam = new HashMap(4);
        updatePlatformCashParam.put("accountUuid", payeeAccountUuid);
        updatePlatformCashParam.put("amount", platformAmount);
        row = accountMapper.updatePlatformAmount(updatePlatformCashParam);
        if (row == 0) {
            throw new Exception("更新账户[" + payeeAccountUuid + "]余额失败");
        }

        // 流标操作
        String merchantID = param.getMerchantID();
        String terminalID = param.getTerminalID();
        String requestUrl = baofooUrl + "/p2pRequest.do";
        String result = invokeCustodyHttpRequest(merchantID, terminalID, requestUrl, requestParams);
        JSONObject jsonObject = XmlTool.xml2Json(result);
        BaoFooResponse baoFooResponse = jsonObject.toJavaObject(BaoFooResponse.class);
        if (!baoFooResponse.isSuccessful()) {
            throw new Exception("宝付操作失败，错误码=[" + baoFooResponse.getCode() + "]");
        }

        return "OK";
    }

    /**
     * 宝付接口
     *
     * @param merchantID
     * @param terminalID
     * @param requestUrl
     * @param requestParams
     * @return
     * @throws Exception
     */
    private String invokeCustodyHttpRequest(String merchantID, String terminalID, String requestUrl, String requestParams) throws Exception {
        String sign = encryptUtil.encryptMD5(requestParams);

        logger.info("merchant_id=" + merchantID);
        logger.info("terminal_id=" + terminalID);
        logger.info("requestParams=" + requestParams);
        logger.info("sing=" + sign);

        FormBody formBody = new FormBody.Builder()
                .add("merchant_id", merchantID)
                .add("terminal_id", terminalID)
                .add("requestParams", requestParams)
                .add("sign", sign)
                .build();
        Request request = new Request.Builder()
                .url(requestUrl)
                .post(formBody)
                .build();
        Response response = okHttpClient.newCall(request).execute();
        if (response.isSuccessful()) {
            String result = response.body().string();
            logger.info("result=" + result);
            return result;
        } else {
            throw new Exception("Unexpected code: " + response);
        }
    }
}
