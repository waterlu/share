package cn.zjhf.kingold.tool.baofoo.entity;

import java.math.BigDecimal;

/**
 * @author lu
 * @date 2018/5/9
 */
public class TradeVO {

    private long userId;

    private String userUuid;

    private BigDecimal amount;

    private BigDecimal paidAmount;

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getPaidAmount() {
        return paidAmount;
    }

    public void setPaidAmount(BigDecimal paidAmount) {
        this.paidAmount = paidAmount;
    }
}
