package cn.zjhf.kingold.tool.baofoo.entity;

import java.math.BigDecimal;

/**
 * @author lu
 * @date 2018/5/9
 */
public class AccountTransaction {

    private String accountTransactionUuid;

    private String transactionBillCode;

    private String userUuid;

    private String accountUuid;

    private Long accountNo;

    private String oppoUserUuid;

    private String oppoAccountUuid;

    private Long oppoAccountNo;

    private BigDecimal transactionAmount;

    private String tradeType = "RFX";

    private String remark;

    private String accountType;

    public String getTradeOrderBillCodeExtend() {
        return tradeOrderBillCodeExtend;
    }

    public void setTradeOrderBillCodeExtend(String tradeOrderBillCodeExtend) {
        this.tradeOrderBillCodeExtend = tradeOrderBillCodeExtend;
    }

    private String tradeOrderBillCodeExtend;

    public String getAccountTransactionUuid() {
        return accountTransactionUuid;
    }

    public void setAccountTransactionUuid(String accountTransactionUuid) {
        this.accountTransactionUuid = accountTransactionUuid;
    }

    public String getTransactionBillCode() {
        return transactionBillCode;
    }

    public void setTransactionBillCode(String transactionBillCode) {
        this.transactionBillCode = transactionBillCode;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getAccountUuid() {
        return accountUuid;
    }

    public void setAccountUuid(String accountUuid) {
        this.accountUuid = accountUuid;
    }

    public Long getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(Long accountNo) {
        this.accountNo = accountNo;
    }

    public String getOppoUserUuid() {
        return oppoUserUuid;
    }

    public void setOppoUserUuid(String oppoUserUuid) {
        this.oppoUserUuid = oppoUserUuid;
    }

    public String getOppoAccountUuid() {
        return oppoAccountUuid;
    }

    public void setOppoAccountUuid(String oppoAccountUuid) {
        this.oppoAccountUuid = oppoAccountUuid;
    }

    public Long getOppoAccountNo() {
        return oppoAccountNo;
    }

    public void setOppoAccountNo(Long oppoAccountNo) {
        this.oppoAccountNo = oppoAccountNo;
    }

    public BigDecimal getTransactionAmount() {
        return transactionAmount;
    }

    public void setTransactionAmount(BigDecimal transactionAmount) {
        this.transactionAmount = transactionAmount;
    }

    public String getTradeType() {
        return tradeType;
    }

    public void setTradeType(String tradeType) {
        this.tradeType = tradeType;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }
}
