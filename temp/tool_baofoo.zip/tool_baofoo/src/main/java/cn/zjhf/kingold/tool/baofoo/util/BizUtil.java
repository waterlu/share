package cn.zjhf.kingold.tool.baofoo.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

/**
 * @author lu
 * @date 2018/5/9
 */
public class BizUtil {

    public static String generateUUID() {
        return UUID.randomUUID().toString().replaceAll("-", "");
    }

    public static String generateOrderBillCode(String prefix) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        Date now = new Date();
        String timeString = dateFormat.format(now);
        int randomNumber = RandUtil.getRandomNumbers(10000);
        String postfix = String.format("%04d", randomNumber);
        String billCode = prefix + timeString + postfix;
        return billCode;
    }

}
