package cn.zjhf.kingold.tool.baofoo.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * @author lu
 * @date 2018/5/9
 */
@Component
public class EncryptUtil {

    @Value("${baofoo.password}")
    private String password;

    public String encryptAES(String content) {
        try {
            String key = password;
            String iv = password;
            Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
            int blockSize = cipher.getBlockSize();
            byte [] data = content.trim().getBytes("utf-8");
            int plainLength = data.length;
            if (plainLength % blockSize != 0) {
                plainLength += blockSize - (plainLength % blockSize);
            }
            byte [] plainText = new byte[plainLength];
            System.arraycopy(data, 0, plainText, 0, data.length);
            SecretKeySpec keySpec = new SecretKeySpec(key.getBytes(), "AES");
            IvParameterSpec ivSpec = new IvParameterSpec(iv.getBytes());
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);
            byte [] encryptText = cipher.doFinal(plainText);
            return byte2hex(encryptText);
        } catch (Exception e) {
            e.printStackTrace();
            return e.getMessage();
        }
    }

    public String encryptMD5(String content) {
        content += "~|~" + password;
        String result = "";
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(content.getBytes());
            byte b[] = md.digest();
            int i;
            StringBuffer buf = new StringBuffer("");
            for (int offset = 0; offset < b.length; offset++) {
                i = b[offset];
                if (i < 0) {
                    i += 256;
                }
                if (i < 16) {
                    buf.append("0");
                }
                buf.append(Integer.toHexString(i));
            }
            //result = buf.toString().substring(8, 24);
            result = buf.toString();
        } catch (NoSuchAlgorithmException e) {
            System.out.println(e);
        }
        return result;
    }

    private String byte2hex(byte[] b) {
        String hs = "";
        String tmp = "";
        for (int n = 0; n < b.length; n++) {
            tmp = (Integer.toHexString(b[n] & 0XFF));
            if (tmp.length() == 1) {
                hs = hs + "0" + tmp;
            } else {
                hs = hs + tmp;
            }
        }
        return hs;
    }

}
