package cn.zjhf.kingold.tool.baofoo.mapper;

import cn.zjhf.kingold.tool.baofoo.entity.Account;
import cn.zjhf.kingold.tool.baofoo.entity.AccountTransaction;
import cn.zjhf.kingold.tool.baofoo.entity.Product;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * @author lu
 * @date 2018/5/9
 */
@Repository
public interface AccountMapper {

    /**
     * 写流水
     *
     * @param transaction
     * @return
     */
    int addTransaction(AccountTransaction transaction);

    /**
     * 增加现金余额
     *
     * @param param
     * @return
     */
    int updateAmount(Map<String, Object> param);

    /**
     * 减少平台衔
     *
     * @param param
     * @return
     */
    int updatePlatformAmount(Map<String, Object> param);

    /**
     *
     * @return
     */
    Account getPlatformAccount();
}
