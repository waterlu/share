package cn.zjhf.kingold.tool.baofoo.entity;

import java.util.ArrayList;
import java.util.List;

/**
 * @author lu
 * @date 2018/5/9
 */
public class ProductVO extends Product {

    public List<TradeOrder> getUserList() {
        return userList;
    }

    public void setUserList(List<TradeOrder> userList) {
        this.userList = userList;
    }

    List<TradeOrder> userList = new ArrayList<>();

    public void addUser(TradeOrder user) {
        userList.add(user);
    }
}