package cn.zjhf.kingold.tool.baofoo.entity;

/**
 * Created by DELL on 2017/4/18.
 */
public class IssueRegisterPageVO {
    private String bfAccount;

    private String name;

    private String idCard;

    private String userID;

    private String license;

    private String returnUrl;

    private String enterpriseName;

    private String email;

    public String getBfAccount() {
        return bfAccount;
    }

    public void setBfAccount(String bfAccount) {
        this.bfAccount = bfAccount;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getLicense() {
        return license;
    }

    public void setLicense(String license) {
        this.license = license;
    }

    public String getReturnUrl() {
        return returnUrl;
    }

    public void setReturnUrl(String returnUrl) {
        this.returnUrl = returnUrl;
    }

    public String getEnterpriseName() {
        return enterpriseName;
    }

    public void setEnterpriseName(String enterpriseName) {
        this.enterpriseName = enterpriseName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
