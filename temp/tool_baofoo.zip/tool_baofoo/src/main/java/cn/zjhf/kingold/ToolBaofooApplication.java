package cn.zjhf.kingold;

import okhttp3.OkHttpClient;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;

import java.util.concurrent.TimeUnit;

@SpringBootApplication
@MapperScan("cn.zjhf.kingold.tool.baofoo.mapper")
public class ToolBaofooApplication {

	public static void main(String[] args) {
		SpringApplication.run(ToolBaofooApplication.class, args);
	}

	@Bean
	@ConditionalOnMissingBean(name = "okHttpClient")
	public OkHttpClient okHttpClient() {
		OkHttpClient okHttpClient = new OkHttpClient.Builder()
				.connectTimeout(30, TimeUnit.SECONDS)
				.readTimeout(30, TimeUnit.SECONDS)
				.writeTimeout(30, TimeUnit.SECONDS)
				.build();
		return okHttpClient;
	}

}
