package cn.zjhf.kingold.tool.baofoo.service;

import cn.zjhf.kingold.tool.baofoo.entity.CancelProjectVO;

/**
 * @author lu
 * @date 2018/5/9
 */
public interface ProductService {

    String cancelProduct(CancelProjectVO param) throws Exception;

}
