package cn.zjhf.kingold.tool.baofoo.api;

import cn.zjhf.kingold.tool.baofoo.entity.*;
import cn.zjhf.kingold.tool.baofoo.mapper.ProductMapper;
import cn.zjhf.kingold.tool.baofoo.mapper.TradeOrderMapper;
import cn.zjhf.kingold.tool.baofoo.service.ProductService;
import cn.zjhf.kingold.tool.baofoo.util.EncryptUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by lutiehua on 2017/4/17.
 */
@RestController
@RequestMapping("/v1/pay")
public class PayController {

    /**
     * 1.页面注册
     */
    private String REGISTER_PAGE_DATA = "<?xml version='1.0' encoding='UTF-8'?>" +
            "<custody_req>" +
            "<bf_account>#bfAccount</bf_account>" +
            "<name>#name</name>" +
            "<id_card>#idCard</id_card>" +
            "<user_id>#userID</user_id>" +
            "<return_url>http://www.test.com/ser_url</return_url>" +
            "<page_url>http://www.test.com</page_url>" +
            "</custody_req>";

    /**
     * 1.企业页面注册
     */
    private String ISSUE_REGISTER_PAGE_DATA = "<?xml version='1.0' encoding='UTF-8'?>" +
            "<custody_req>" +
            "<bf_account>#email</bf_account>" +
            "<name>#name</name>" +
            "<id_card>#idCard</id_card>" +
            "<user_id>#userID</user_id>" +
            "<return_url>#returnUrl</return_url>" +
            "<license>#license</license>" +
            "<mobile>#bfAccount</mobile>" +
            "<enterprise_name>#enterpriseName</enterprise_name>" +
            "<page_url>http://www.test.com</page_url>" +
            "</custody_req>";

    /**
     * 页面注册
     *
     * @param vo
     * @return
     */
    @RequestMapping(value = "/aesRegisterPage", method = RequestMethod.POST)
    public Map<String, String> aesRegisterPage(@RequestBody RegisterPageVO vo) {
        Map<String, String> result = new HashMap<>();
        String template = aesRegisterCommon(REGISTER_PAGE_DATA, vo);
        result.put("aes", template);
        return result;
    }

    /**
     * 企业用户页面注册
     *
     * @param vo
     * @return
     */
    @RequestMapping(value = "/aesIssueRegisterPage", method = RequestMethod.POST)
    public Map<String, String> aesIssueRegisterPage(@RequestBody IssueRegisterPageVO vo) {
        Map<String, String> result = new HashMap<>();
        String template = aesIssueRegisterCommon(ISSUE_REGISTER_PAGE_DATA, vo);
        result.put("aes", template);
        return result;
    }

    /**
     * 2.服务器注册
     * userID 201704181507
     */
    private String REGISTER_DATA = "<?xml version='1.0' encoding='UTF-8'?>" +
            "<custody_req>" +
            "<has_bf_account>0</has_bf_account>" +
            "<bf_account>#bfAccount</bf_account>" +
            "<user_id>#userID</user_id>" +
            "<real_name>#name</real_name>" +
            "<id_card>#idCard</id_card>" +
            "<bind_code>0</bind_code>" +
            "<account_type>1</account_type>" +
            "</custody_req>";

    /**
     * 服务器注册
     *
     * @param vo
     * @return
     */
    @RequestMapping(value = "/aesRegister", method = RequestMethod.POST)
    public Map<String, String> aesRegister(@RequestBody RegisterPageVO vo) {
        Map<String, String> result = new HashMap<>();
        String template = aesRegisterCommon(REGISTER_DATA, vo);
        result.put("aes", template);
        return result;
    }

    private String aesRegisterCommon(String template, RegisterPageVO vo) {
        template = template.replaceAll("#bfAccount", vo.getBfAccount());
        template = template.replaceAll("#name", vo.getName());
        template = template.replaceAll("#idCard", vo.getIdCard());
        template = template.replaceAll("#userID", vo.getUserID());
        template = encryptUtil.encryptAES(template);
        return template;
    }

    private String aesIssueRegisterCommon(String template, IssueRegisterPageVO vo) {
        template = template.replaceAll("#bfAccount", vo.getBfAccount());
        template = template.replaceAll("#name", vo.getName());
        template = template.replaceAll("#idCard", vo.getIdCard());
        template = template.replaceAll("#userID", vo.getUserID());
        template = template.replaceAll("#license", vo.getLicense());
        template = template.replaceAll("#returnUrl", vo.getReturnUrl());
        template = template.replaceAll("#enterpriseName", vo.getEnterpriseName());
        template = template.replaceAll("#email", vo.getEmail());


        template = encryptUtil.encryptAES(template);
        return template;
    }

    /**
     * 4.7 充值
     */
    private String RECHARGE_PAGE_DATA = "<?xml version='1.0' encoding='UTF-8'?>" +
            "<custody_req>" +
            "<merchant_id>#merchantID</merchant_id>" +
            "<user_id>#userID</user_id>" +
            "<order_id>#orderID</order_id>" +
            "<amount>#amount</amount>" +
            "<fee>0</fee>" +
            "<fee_taken_on>1</fee_taken_on>" +
            "<additional_info></additional_info>" +
            "<page_url>http://www.baidu.com</page_url>" +
            "<return_url>#returnUrl</return_url>" +
            "</custody_req>";

    /**
     * 网银充值
     *
     * @param vo
     * @return
     */
    @RequestMapping(value = "/aesRechargePage", method = RequestMethod.POST)
    public Map<String, String> aesRechargePage(@RequestBody RechargePageVO vo) {
        Map<String, String> result = new HashMap<>();
        String template = RECHARGE_PAGE_DATA;
        template = template.replaceAll("#merchantID", vo.getMerchantID());
        template = template.replaceAll("#userID", vo.getUserID());
        template = template.replaceAll("#orderID", vo.getOrderID());
        template = template.replaceAll("#returnUrl", vo.getReturnUrl());
        template = template.replaceAll("#amount", String.valueOf(vo.getAmount()));
        // 这个不能加密，有点变态
//        template = encryptAES(template);
        result.put("aes", template);
        return result;
    }


    /**
     * 4.18 绑卡
     */
    private String ADD_BANK_CARD_DATA = "<?xml version='1.0' encoding='UTF-8' ?>" +
            "<custody_req>" +
            "<user_id>#userID</user_id>" +
            "<mobile>#mobile</mobile>" +
            "<bank_no>#bankNo</bank_no>" +
            "<validate_code>#validateCode</validate_code>" +
            "</custody_req>";

    /**
     * 绑定银行卡
     *
     * @return
     */
    @RequestMapping(value = "/aesAddBankCard", method = RequestMethod.POST)
    public Map<String, String> aesAddBankCard(@RequestBody AddBankCardVO vo) {
        Map<String, String> result = new HashMap<>();
        String template = ADD_BANK_CARD_DATA;
        template = template.replaceAll("#userID", vo.getUserID());
        template = template.replaceAll("#mobile", vo.getMobile());
        template = template.replaceAll("#bankNo", vo.getBankNo());
        template = template.replaceAll("#validateCode", vo.getValidateCode());
        template = encryptUtil.encryptAES(template);
        result.put("aes", template);
        return result;
    }

    /**
     * 4.5 账户余额
     */
    private String ACCOUNT_BALANCE_DATA = "<?xml version='1.0' encoding='UTF-8'?>" +
            "<custody_req>" +
            "<merchant_id>#merchantID</merchant_id>" +
            "<user_id>#userID</user_id>" +
            "</custody_req>";

    /**
     * 查询余额
     *
     * @return
     */
    @RequestMapping(value = "/aesAccountBalance", method = RequestMethod.POST)
    public Map<String, String> aesAccountBalance(@RequestBody AccountBalanceVO vo) {
        Map<String, String> result = new HashMap<>();
        String template = ACCOUNT_BALANCE_DATA;
        template = template.replaceAll("#merchantID", vo.getMerchantID());
        template = template.replaceAll("#userID", vo.getUserID());
//        不加密
//        template = encryptAES(template);
        result.put("aes", template);
        return result;
    }


    /**
     * 4.5 查询流水
     */
    private String ACCOUNT_TRANSCATION_QUERY = "<?xml version='1.0' encoding='UTF-8'?>" +
                    "<custody_req>" +
                    "<type>#type</type>" +
                    "<start_time>#startTime</start_time>" +
                    "<end_time>#endTime</end_time>" +
                    "</custody_req>";

    /**
     * 4.5 查询流水
     */
    private String ACCOUNT_TRANSCATION_QUERY_ORDER = "<?xml version='1.0' encoding='UTF-8'?>" +
            "<custody_req>" +
            "<type>#type</type>" +
            "<order_id>#orderId</order_id>" +
            "</custody_req>";

    private String ACCOUNT_TRANSACTION_INFO = "<?xml version='1.0' encoding='UTF-8'?>" +
            "<custody_req>" +
            "<type>8</type>" +
            "<user_id>#userID</user_id>" +
            "</custody_req>";

    /**
     * 4.5 查询流水
     */
    private String ACCOUNT_TRANSCATION_EXCEL_QUERY = "<?xml version='1.0' encoding='UTF-8'?>" +
            "<custody_req>" +
            "<start_time>#startTime</start_time>" +
            "<end_time>#endTime</end_time>" +
            "</custody_req>";

    /**
     * 查询流水
     *
     * @return
     */
    @RequestMapping(value = "/queryByOrderId", method = RequestMethod.POST)
    public Map<String, String> queryByOrderId(@RequestBody Map paramMap) {
        Map<String, String> result = new HashMap<>();
        String template = ACCOUNT_TRANSCATION_QUERY_ORDER;
        template = template.replaceAll("#type",  paramMap.get("type").toString());
        template = template.replaceAll("#orderId", paramMap.get("orderId").toString());
        result.put("aes", template);
        return result;
    }

    /**
     * 查询流水
     *
     * @return
     */
    @RequestMapping(value = "/queryByTime", method = RequestMethod.POST)
    public Map<String, String> queryByTime(@RequestBody Map paramMap) {
        Map<String, String> result = new HashMap<>();
        String template = ACCOUNT_TRANSCATION_QUERY;
        template = template.replaceAll("#type",  paramMap.get("type").toString());
        template = template.replaceAll("#startTime", paramMap.get("startTime").toString());
        template = template.replaceAll("#endTime", paramMap.get("endTime").toString());
        result.put("aes", template);
        return result;
    }

    /**
     * 查询用户
     *
     * @param paramMap
     * @return
     */
    @RequestMapping(value = "/queryUserInfo", method = RequestMethod.POST)
    public Map<String, String> queryUserInfo(@RequestBody Map paramMap) {
        Map<String, String> result = new HashMap<>();
        String template = ACCOUNT_TRANSACTION_INFO;
        template = template.replaceAll("#userID", paramMap.get("userID").toString());
        result.put("aes", template);
        return result;
    }


    @RequestMapping(value = "/aesExportExcel", method = RequestMethod.POST)
    public Map<String, String> aesExportExcel(@RequestBody Map paramMap) {
        Map<String, String> result = new HashMap<>();
        String template = ACCOUNT_TRANSCATION_EXCEL_QUERY;
        template = template.replaceAll("#startTime", paramMap.get("startTime").toString());
        template = template.replaceAll("#endTime", paramMap.get("endTime").toString());
        result.put("aes", template);
        return result;
    }

    @RequestMapping(value = "/aesAccountTransaction", method = RequestMethod.POST)
    public Map<String, String> aesAccountTransaction(@RequestBody Map paramMap) {
        Map<String, String> result = new HashMap<>();
        String template;
        if(paramMap.get("type") == null || StringUtils.isEmpty(paramMap.get("type").toString())) {
            template = ACCOUNT_TRANSCATION_EXCEL_QUERY;
            template = template.replaceAll("#startTime", paramMap.get("startTime").toString());
            template = template.replaceAll("#endTime", paramMap.get("endTime").toString());
        } else if (paramMap.get("orderId") == null || StringUtils.isEmpty(paramMap.get("orderId").toString())) {
            template = ACCOUNT_TRANSCATION_QUERY;
            template = template.replaceAll("#type",  paramMap.get("type").toString());
            template = template.replaceAll("#startTime", paramMap.get("startTime").toString());
            template = template.replaceAll("#endTime", paramMap.get("endTime").toString());
        } else {
            template = ACCOUNT_TRANSCATION_QUERY_ORDER;
            template = template.replaceAll("#type",  paramMap.get("type").toString());
            template = template.replaceAll("#orderId", paramMap.get("orderId").toString());
        }
        result.put("aes", template);
        return result;
    }

    /**
     * 4.16 投标
     */
    private String PROJECT_INVEST_DATA = "<?xml version='1.0' encoding='UTF-8'?>" +
            "<custody_req>" +
            "<action_type>1</action_type>" +
            "<merchant_id>#merchatID</merchant_id>" +
            "<order_id>#orderID</order_id>" +
            "<cus_id>#productID</cus_id>" +
            "<cus_name>#productName</cus_name>" +
            "<brw_id>#borrowerID</brw_id>" +
            "<req_time>#reqTime</req_time>" +
            "<actions><action>" +
            "<user_id>#userID</user_id>" +
            "<user_name></user_name>" +
            "<amount>#amount</amount>" +
            "</action></actions>" +
            "<fee>0.00</fee>" +
            "</custody_req>";

    /**
     * 投标
     *
     * @return
     */
    @RequestMapping(value = "/aesInvest", method = RequestMethod.POST)
    public Map<String, String> aesInvest(@RequestBody InvestVO vo) {
        Map<String, String> result = new HashMap<>();
        String template = PROJECT_INVEST_DATA;
        template = template.replaceAll("#merchatID", vo.getMerchantID());
        template = template.replaceAll("#orderID", vo.getOrderID());
        template = template.replaceAll("#productID", vo.getProductID());
        template = template.replaceAll("#productName", vo.getProductName());
        template = template.replaceAll("#borrowerID", vo.getBorrowerID());
        template = template.replaceAll("#reqTime", String.valueOf(System.currentTimeMillis()));
        template = template.replaceAll("#userID", vo.getUserID());
        template = template.replaceAll("#amount", String.valueOf(vo.getAmount()));
        result.put("aes", template);
        return result;
    }

    /**
     * 4.16 满标
     */
    private String PROJECT_PAY_DATA = "<?xml version='1.0' encoding='UTF-8'?>" +
            "<custody_req>" +
            "<action_type>2</action_type>" +
            "<merchant_id>#merchatID</merchant_id>" +
            "<order_id>#orderID</order_id>" +
            "<cus_id>#productID</cus_id>" +
            "<cus_name>#productName</cus_name>" +
            "<brw_id>#borrowerID</brw_id>" +
            "<req_time>#reqTime</req_time>" +
            "<actions><action>" +
            "<user_id>#borrowerID</user_id>" +
            "<amount>#amount</amount>" +
            "<is_voucher>0</is_voucher>" +
            "</action></actions>" +
            "<fee>#fee</fee>" +
            "</custody_req>";

    /**
     * 满标
     *
     * @return
     */
    @RequestMapping(value = "/aesPay", method = RequestMethod.POST)
    public Map<String, String> aesPay(@RequestBody InvestVO vo) {
        Map<String, String> result = new HashMap<>();
        String template = PROJECT_PAY_DATA;
        template = template.replaceAll("#merchatID", vo.getMerchantID());
        template = template.replaceAll("#orderID", vo.getOrderID());
        template = template.replaceAll("#productID", vo.getProductID());
        template = template.replaceAll("#productName", vo.getProductName());
        template = template.replaceAll("#borrowerID", vo.getBorrowerID());
        template = template.replaceAll("#reqTime", String.valueOf(System.currentTimeMillis()));
        template = template.replaceAll("#amount", String.valueOf(vo.getAmount()));
        template = template.replaceAll("#fee", String.valueOf(vo.getFee()));
        result.put("aes", template);
        return result;
    }

    @Autowired
    private ProductMapper productMapper;

    @Autowired
    private TradeOrderMapper tradeOrderMapper;

    /**
     * 流标前读取产品信息
     *
     * @param productUUID
     * @return
     */
    @RequestMapping(value = "/product", method = RequestMethod.GET)
    public ProductVO getProductInfo(@RequestParam String productUUID) {
        List<Product> productList = productMapper.selectByProductUuid(productUUID);
        Product product = productList.get(0);
        ProductVO productVO = new ProductVO();
        productVO.setAccountNo(product.getAccountNo());
        productVO.setPayeeAccountUuid(product.getPayeeAccountUuid());
        productVO.setProductId(product.getProductId());
        productVO.setProductName(product.getProductName());
        productVO.setProductUuid(product.getProductUuid());

        List<TradeOrder> tradeOrderList = tradeOrderMapper.selectByProductUuid(productUUID);
        productVO.setUserList(tradeOrderList);

        return productVO;
    }

    /**
     * 流标
     */
    private String PROJECT_CANCEL_DATA = "<?xml version='1.0' encoding='UTF-8'?>" +
            "<custody_req>" +
            "<merchant_id>#merchatID</merchant_id>" +
            "<action_type>3</action_type>" +
            "<order_id>#orderID</order_id>" +
            "<cus_id>#productID</cus_id>" +
            "<cus_name>#productName</cus_name>" +
            "<brw_id>#borrowerID</brw_id>" +
            "<req_time>#reqTime</req_time>" +
            "<actions>#actionList</actions>" +
            "<fee>0</fee>" +
            "</custody_req>";

    /**
     * 流标参数
     *
     * @return
     */
    @RequestMapping(value = "/aesCancelProduct", method = RequestMethod.POST)
    public Map<String, String> aesCancelProduct(@RequestBody InvestVO vo) {
        Map<String, String> result = new HashMap<>();

        StringBuffer buffer = new StringBuffer();
        for (TradeOrder tradeOrder : vo.getUserList()) {
            buffer.append("<action>");
            buffer.append("<user_id>");
            buffer.append(tradeOrder.getAccountNo());
            buffer.append("</user_id>");
            buffer.append("<amount>");
            buffer.append(tradeOrder.getPaidAmount());
            buffer.append("</amount>");
            buffer.append("</action>");
        }

        String template = PROJECT_CANCEL_DATA;
        template = template.replaceAll("#merchatID", vo.getMerchantID());
        template = template.replaceAll("#orderID", vo.getOrderID());
        template = template.replaceAll("#productID", vo.getProductID());
        template = template.replaceAll("#productName", vo.getProductName());
        template = template.replaceAll("#borrowerID", vo.getBorrowerID());
        template = template.replaceAll("#reqTime", String.valueOf(System.currentTimeMillis()));
        template = template.replaceAll("#actionList", buffer.toString());
        template = template.replaceAll("#fee", String.valueOf(vo.getFee()));
        result.put("aes", template);
        return result;
    }

    @Autowired
    private ProductService productService;

    @RequestMapping(value = "/cancelProject", method = RequestMethod.POST)
    public Map<String, String> cancelProject(@RequestBody CancelProjectVO param){
        try {
            String message = productService.cancelProduct(param);
            Map<String, String> result = new HashMap<>();
            result.put("data",  message);
            return result;
        } catch (Exception e) {
            Map<String, String> result = new HashMap<>();
            result.put("data",  e.getMessage());
            return result;
        }
    }

    /**
     * 4.14 转账
     */
    private String TRANSFER_DATA = "<?xml version='1.0' encoding='UTF-8'?>" +
            "<custody_req>" +
            "<merchant_id>#merchatID</merchant_id>" +
            "<order_id>#orderID</order_id>" +
            "<payer_user_id>#merchatID</payer_user_id>" +
            "<payee_user_id>#userID</payee_user_id>" +
            "<payer_type>1</payer_type>" +
            "<payee_type>0</payee_type>" +
            "<amount>#amount</amount>" +
            "<fee>0</fee>" +
            "<fee_taken_on>0</fee_taken_on>" +
            "<req_time>#reqTime</req_time>" +
            "</custody_req>";

    /**
     * 转账
     * @param vo
     * @return
     */
    @RequestMapping(value = "/aesTransfer", method = RequestMethod.POST)
    public Map<String, String> aesTransfer(@RequestBody TransferVO vo) {
        Map<String, String> result = new HashMap<>();
        String template = TRANSFER_DATA;
        template = template.replaceAll("#merchatID", vo.getMerchantID());
        template = template.replaceAll("#orderID", vo.getOrderID());
        template = template.replaceAll("#userID", vo.getUserID());
        template = template.replaceAll("#reqTime", String.valueOf(System.currentTimeMillis()));
        template = template.replaceAll("#amount", String.valueOf(vo.getAmount()));
        result.put("aes", template);
        return result;
    }

    private String TRANSFER_2_PLATFORM_DATA = "<?xml version='1.0' encoding='UTF-8'?>" +
            "<custody_req>" +
            "<merchant_id>#merchatID</merchant_id>" +
            "<order_id>#orderID</order_id>" +
            "<payer_user_id>#userID</payer_user_id>" +
            "<payee_user_id>#merchatID</payee_user_id>" +
            "<payer_type>0</payer_type>" +
            "<payee_type>1</payee_type>" +
            "<amount>#amount</amount>" +
            "<fee>0</fee>" +
            "<fee_taken_on>1</fee_taken_on>" +
            "<req_time>#reqTime</req_time>" +
            "</custody_req>";

    @RequestMapping(value = "/aesTransferToPlatform", method = RequestMethod.POST)
    public Map<String, String> aesTransferToPlatform(@RequestBody TransferVO vo) {
        Map<String, String> result = new HashMap<>();
        String template = TRANSFER_2_PLATFORM_DATA;
        template = template.replaceAll("#merchatID", vo.getMerchantID());
        template = template.replaceAll("#orderID", vo.getOrderID());
        template = template.replaceAll("#userID", vo.getUserID());
        template = template.replaceAll("#reqTime", String.valueOf(System.currentTimeMillis()));
        template = template.replaceAll("#amount", String.valueOf(vo.getAmount()));
        result.put("aes", template);
        return result;
    }


    private AtomicInteger sequence = new AtomicInteger(0);

    /**
     * 生成订单号
     *
     * @return
     */
    @RequestMapping(value = "/order", method = RequestMethod.GET)
    public Map<String, String> order() {
        Map<String, String> result = new HashMap<>();
//        String orderId = UUID.randomUUID().toString();
//        orderId = orderId.replaceAll("-", "");

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        Date now = new Date();
        String timeString = dateFormat.format(now);
        int seq = sequence.incrementAndGet();
        if (seq >= 999) {
            sequence = new AtomicInteger(0);
        }
        String orderId = String.format("%s%03d", timeString, seq);
        result.put("order", orderId);
        return result;
    }

    @Autowired
    private EncryptUtil encryptUtil;

    /**
     * 数字签名
     *
     * @param content
     * @return
     */
    @RequestMapping(value = "/sign", method = RequestMethod.GET)
    public Map<String, String> sign(@RequestParam String content) {
        Map<String, String> result = new HashMap<>();
        result.put("md5", encryptUtil.encryptMD5(content));
        return result;
    }

}
