var module = app;
module.controller('authController', ['$scope', '$http','Notification',function ($scope, $http,Notification) {
    $scope.merchantID = "100000675";
    $scope.terminalID = "100000701";
    $scope.userID = "6100000000000";
    // 回调通知地址
    $scope.serviceURL = "";
    $scope.serviceURLList = [
        "http://218.240.154.251:6630/baofoo/notification/auth", // 开发环境
        "http://notify-test.zj-hf.cn/baofoo/notification/auth"  // 测试环境
    ];
    $scope.pageURL = "http://www.baidu.com";
} ]);