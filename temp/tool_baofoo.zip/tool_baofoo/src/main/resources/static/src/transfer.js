var module = app;
module.controller('transferController', ['$scope', '$http','Notification',function ($scope, $http,Notification) {
    // 测试环境
    // $scope.merchantID = "100000675";
    // $scope.terminalID = "100000701";

    // 预上线环境
    // $scope.merchantID = "1172380";
    // $scope.terminalID = "34865";

    // 生产环境
    $scope.merchantID = "1177929";
    $scope.terminalID = "35265";
    // $scope.terminalID = "35497";

    $scope.userID = "110128";
    $scope.orderID = "";
    $scope.amount = "0";
    $scope.requestParam = "";
    $scope.sign = "";

    $scope.generateOrder = function () {
        $http.get('/v1/pay/order').success(function (data) {
            console.log("data.order=" + data.order);
            $scope.orderID = data.order;
        }).error(function (data) {
            console.log('error:' + data);
        });
    };

    $scope.encryptTransferParam = function() {
        if ($scope.userID == "" || $scope.orderID == "" || $scope.amount == "") {
            alert('用户编号/订单编号/金额都不能为空!');
            return;
        }
        $http(
            {
                method: "POST",
                url: "/v1/pay/aesTransferToPlatform",
                data: {
                    "merchantID": $scope.merchantID,
                    "userID": $scope.userID,
                    "orderID": $scope.orderID,
                    "amount": $scope.amount
                }
            }).success(function (data) {
            console.log("data.aes=" + data.aes);
            $scope.requestParam = data.aes;
        }).error(function (data) {
            console.log('error:' + data);
        });
    };

    $scope.encryptSign = function(){
        if ($scope.requestParam == "") {
            alert('请求参数不能为空，请先生成加密的请求参数');
        } else {
            $http.get('/v1/pay/sign?content=' + $scope.requestParam).success(function (data) {
                console.log("data.md5=" + data.md5);
                $scope.sign = data.md5;
            }).error(function (data) {
                console.log('error:' + data);
            });
        }
    };



} ]);