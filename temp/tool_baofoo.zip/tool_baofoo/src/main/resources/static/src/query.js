var module = app;
module.controller('queryController', ['$scope', '$http','Notification',function ($scope, $http,Notification) {
    // 测试环境
    // $scope.merchantID = "100000675";
    // $scope.terminalID = "100000701";

    // 预上线环境
    $scope.merchantID = "1172380";
    $scope.terminalID = "34865";

    $scope.userID = "6100000000000";
    $scope.requestParam = "";
    $scope.sign = "";
    $scope.startTime = moment().subtract(24, 'hour').format('YYYY-MM-DD HH:mm');
    $scope.endTime = moment().format('YYYY-MM-DD HH:mm');
    $scope.timepickerOptions ={format: 'YYYY-MM-DD HH:mm', showClear: true};
    $scope.type1 = "";
    $scope.type2 = "";

    /**
     * 查询类型
     *
     * @type {[*]}
     */
    $scope.types = [
        {value : "1", name : "投资"},
        {value : "2", name : "放款"},
        {value : "3", name : "退款"},
        {value : "4", name : "还款"},
        {value : "5", name : "充值"},
        {value : "6", name : "提现"},
        {value : "7", name : "转账"}
    ];

    /**
     * 账户余额
     */
    $scope.encryptAccountBalanceParam = function() {
        if ($scope.userID == "") {
            alert('用户编号不能为空!');
            return;
        }
        $http(
            {
                method: "POST",
                url: "/v1/pay/aesAccountBalance",
                data: {
                    "merchantID": $scope.merchantID,
                    "userID": $scope.userID
                }
            }).success(function (data) {
            console.log("data.aes=" + data.aes);
            $scope.requestParam = data.aes;
        }).error(function (data) {
            console.log('error:' + data);
        });
    };

    /**
     * 查询订单
     */
    $scope.encryptQueryByOrderId = function() {
        if ($scope.type == "") {
            alert('查询类型不能为空!');
            return;
        }
        $http(
            {
                method: "POST",
                url: "/v1/pay/queryByOrderId",
                data: {
                    "type": $scope.type1,
                    "orderId": $scope.orderID
                }
            }).success(function (data) {
            console.log("data.aes=" + data.aes);
            $scope.requestParam = data.aes;
        }).error(function (data) {
            console.log('error:' + data);
        });
    };

    /**
     * 时间段查询
     */
    $scope.encryptQueryByTime = function() {
        if ($scope.type == "") {
            alert('查询类型不能为空!');
            return;
        }
        $http(
            {
                method: "POST",
                url: "/v1/pay/queryByTime",
                data: {
                    "type": $scope.type2,
                    "startTime": $scope.startTime.valueOf(),
                    "endTime": $scope.endTime.valueOf()
                }
            }).success(function (data) {
            console.log("data.aes=" + data.aes);
            $scope.requestParam = data.aes;
        }).error(function (data) {
            console.log('error:' + data);
        });
    };

    /**
     * 用户信息
     */
    $scope.encryptUserInfoParam = function() {
        if ($scope.type == "") {
            alert('查询类型不能为空!');
            return;
        }
        $http(
            {
                method: "POST",
                url: "/v1/pay/queryUserInfo",
                data: {
                    "userID": $scope.userID
                }
            }).success(function (data) {
            console.log("data.aes=" + data.aes);
            $scope.requestParam = data.aes;
        }).error(function (data) {
            console.log('error:' + data);
        });
    };



    /**
     * 数字签名
     */
    $scope.encryptSign = function(){
        if ($scope.requestParam == "") {
            alert('请求参数不能为空，请先生成加密的请求参数');
        } else {
            $http.get('/v1/pay/sign?content=' + $scope.requestParam).success(function (data) {
                console.log("data.md5=" + data.md5);
                $scope.sign = data.md5;
            }).error(function (data) {
                console.log('error:' + data);
            });
        }
    };

} ]);