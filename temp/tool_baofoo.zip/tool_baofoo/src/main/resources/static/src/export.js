var module = app;
module.controller('exportController', ['$scope', '$http','Notification',function ($scope, $http,Notification) {
    $scope.merchantID = "100000675";
    $scope.terminalID = "100000701";
    $scope.startTime = moment().subtract(24, 'hour').format('YYYY-MM-DD HH:mm');
    $scope.endTime = moment().format('YYYY-MM-DD HH:mm');
    $scope.timepickerOptions ={format: 'YYYY-MM-DD HH:mm', showClear: true};

    $scope.encryptAccountTransactionExcelQuery  = function() {
        $http(
            {
                method: "POST",
                url: "/v1/pay/aesExportExcel",
                data: {
                    "startTime": $scope.startTime.valueOf(),
                    "endTime": $scope.endTime.valueOf()
                }
            }).success(function (data) {
            console.log("data.aes=" + data.aes);
            $scope.requestParam = data.aes;
        }).error(function (data) {
            console.log('error:' + data);
        });
    };

    /**
     * 数字签名
     */
    $scope.encryptSign = function(){
        if ($scope.requestParam == "") {
            alert('请求参数不能为空，请先生成加密的请求参数');
        } else {
            $http.get('/v1/pay/sign?content=' + $scope.requestParam).success(function (data) {
                console.log("data.md5=" + data.md5);
                $scope.sign = data.md5;
            }).error(function (data) {
                console.log('error:' + data);
            });
        }
    };



} ]);