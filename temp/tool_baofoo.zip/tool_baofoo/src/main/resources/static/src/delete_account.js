var module = app;
module.controller('deleteAccountController', ['$scope', '$http','Notification',function ($scope, $http,Notification) {
    $scope.mobile = "";

} ]);