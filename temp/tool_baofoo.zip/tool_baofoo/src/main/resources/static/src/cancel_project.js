var module = app;
module.controller('cancelProjectController', ['$scope', '$http','Notification',function ($scope, $http,Notification) {
    // 测试环境
    // $scope.merchantID = "100000675";
    // $scope.terminalID = "100000701";

    // 预上线环境
    $scope.merchantID = "1172380";
    $scope.terminalID = "34865";

    $scope.productID = "";
    $scope.productUUID = "";
    $scope.productName = "";
    $scope.borrowerID = "";
    $scope.userID = "";
    $scope.orderID = "";
    $scope.amount = "";
    $scope.requestParam = "";
    $scope.sign = "";
    $scope.users = [];

    $scope.queryProductInfo = function () {
        $http.get('/v1/pay/product?productUUID=' + $scope.productUUID).success(function (data) {
            console.log('info:' + data);
            $scope.productID = data.productId;
            $scope.productName = data.productName;
            $scope.borrowerID = data.accountNo;
            $scope.users = data.userList;
            console.log('users:' + $scope.users);
        }).error(function (data) {
            console.log('error:' + data);
        });
    };

    $scope.generateOrder = function () {
        $http.get('/v1/pay/order').success(function (data) {
            console.log("data.order=" + data.order);
            $scope.orderID = data.order;
        }).error(function (data) {
            console.log('error:' + data);
        });
    };

    $scope.encryptCancelProjectParam = function() {
        if ($scope.users == "" || $scope.orderID == "") {
            alert('用户/订单编号不能为空!');
            return;
        }
        $http(
            {
                method: "POST",
                url: "/v1/pay/aesCancelProduct",
                data: {
                    "merchantID": $scope.merchantID,
                    "orderID": $scope.orderID,
                    "productID": $scope.productID,
                    "productUUID": $scope.productUUID,
                    "productName": $scope.productName,
                    "borrowerID": $scope.borrowerID,
                    "userList": $scope.users
                }
            }).success(function (data) {
            console.log("data.aes=" + data.aes);
            $scope.requestParam = data.aes;
        }).error(function (data) {
            console.log('error:' + data);
        });
    };

    $scope.cancelProject = function() {
        $http(
            {
                method: "POST",
                url: "/v1/pay/cancelProject",
                data: {
                    "merchantID": $scope.merchantID,
                    "terminalID": $scope.terminalID,
                    "orderId": $scope.orderID,
                    "productUUID": $scope.productUUID,
                    "requestParams" : $scope.requestParam
                }
            }).success(function (data) {
            console.log('data:' + data.data);
            window.alert(data.data);
        }).error(function (data) {
            console.log('error:' + data.data);
            window.alert(data.data);
        });
    };

    $scope.encryptSign = function(){
        if ($scope.requestParam == "") {
            alert('请求参数不能为空，请先生成加密的请求参数');
        } else {
            $http.get('/v1/pay/sign?content=' + $scope.requestParam).success(function (data) {
                console.log("data.md5=" + data.md5);
                $scope.sign = data.md5;
            }).error(function (data) {
                console.log('error:' + data);
            });
        }
    };



} ]);