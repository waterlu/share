package cn.zjhf.tool.quicker.model;

/**
 * Created by lutiehua on 2017/9/26.
 */
public class JavaImport {

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
