package cn.zjhf.tool.quicker.model;

import lombok.Data;

/**
 * Created by lutiehua on 2017/11/10.
 */
@Data
public class Log4j2Model extends DataModel {

    private String name;

    private String mapperPackage;

}
