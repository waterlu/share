package cn.zjhf.tool.quicker.model;

/**
 * Created by lutiehua on 2017/9/26.
 */
public class JavaMethod {
}
