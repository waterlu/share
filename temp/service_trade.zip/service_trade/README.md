# APP端接口-账户

**交易类接口**    
* [宝付授权回调通知接口](#宝付授权回调通知接口)
**宝付账户**    
* [发送宝付授权验证码](#发送宝付授权验证码)
* [绑卡](#绑卡) 
* [获取绑卡信息](#获取绑卡信息)
* [新增宝付账户](#新增宝付账户) 
* [获取宝付账户](#获取宝付账户) 
* [修改宝付账户](#修改宝付账户) 
* [冻结宝付账户](#冻结宝付账户) 
* [获取宝付账户列表](#获取账户流水列表)
* [获取宝付账户总数](#获取账户流水总数)
**平台账户** 
* [获取账户](#获取账户) 
* [新增账户](#新增账户) 
* [修改账户](#修改账户) 
* [冻结账户](#冻结账户) 
* [获取账户列表](#获取账户流水列表)
* [获取账户总数](#获取账户流水总数)
**平台账户流水**
* [获取账户流水](#获取账户) 
* [获取账户流水列表](#获取账户流水列表)
* [获取账户流水总数](#获取账户流水总数)

---
# 公共参数

**公共入参**
>所有接口均需要传入一个参数：callSystemID，表示调用来源类型。详见：http://10.10.10.6/doc/general/wikis/callsystemidlist

**公共域名：**
> [domain] : http://app.kingold.zj-inv.cn/v1 

> [dev domain] : http://10.10.10.6:8050/v1 

**公共code码**

> -1: 入参参数错误

> 200: 发送成功

> 500: 系统异常

**自定义code码**


# 交易类接口

## 宝付授权回调通知接口

- 服务地址

/trade/baofoo/notification/auth

- 参数

| 名称 | 类型 | 说明 |
| :-- |:--|:--|
| result | String | 结果 |
| sign | String | 数据签名 |

   
# 发送宝付授权验证码
 
**1. 接口描述**
 
>  需要用户登录
>  
>  通知宝付，根据token获取指定的一个userId，从而给此用户发送授权验证码
     
**2.  接口信息**
> uri：  /trade/baofoo/validation
> 
> 访问类型：GET

**3. 请求参数**

|  参数名  |  类型  |  是否必传  |  说明  |
|  ---  |  ---  |  ---  |  ---  |
| userID  | long |  是  | 就是宝付中的用户id（accountId）  |
| type | int |  是  | 目前只能传入：1（绑定银行卡）  |

**4. 请求示例**

> /sendBaofooAuthSMS

**5.返回报文**
```
{
  "code": 200,
  "msg": "成功",
  "traceID": "306f3f07-e6a9-4de7-98ff-ea8f1f0d5eaa",
  "data": {}
}
```

**6. 异常情况**

>  同：宝付异常编码

***


# 新增宝付账户
 
**1. 接口描述**
 
>  新增一个宝付账户。涉及表： account、account_baofoo_custody
>  
     
**2.  接口信息**
> uri：  /accountbaofoo
> 
> 访问类型：POST

**3. 请求参数**

|  参数名  |  类型  |  是否必传  |  说明  |
|  ---  |  ---  |  ---  |  ---  |
|  account和account_baofoo_custody 表中字段（转化为首字母小写的驼峰写法）|  String   |  否  | account和account_baofoo_custody 表中字段（转化为首字母小写的驼峰写法）  |

**4. 请求示例**


**5.返回报文**
```
{
  "code": 200,
  "msg": "成功",
  "traceID": "306f3f07-e6a9-4de7-98ff-ea8f1f0d5eaa",
  "data": "dfef3f07e6evde98ffd2"
}
```

**6. 异常情况**


***


# 绑卡
 
**1. 接口描述**
 
>  获取宝付账户表中bank_card_info(数组)插入一条信息，涉及表：account_baofoo_custody.bank_card_info
>  同时会验证 bank_card_info中 
>  
     
**2.  接口信息**
> uri：  /accountbaofoo/bindBankCard
> 
> 访问类型：PUT

**3. 请求参数**

|  参数名  |  类型  |  是否必传  |  说明  |
|  ---  |  ---  |  ---  |  ---  |
|   userUuid/userId/accountUuid |  String  |  是  |  用户uuid/宝付id/账号id  |
|   bankUserPhone|  String  |  是  |  用户电话|
|   bankUserCardNo|  String  |  是  |  用户银行卡|
|   bankUserIDCardNo|  String  |  是  |  用户身份证号|
|   userName|  String  |  是  |  用户名|
|   verifyCode|  String  |  是  |  宝付短信验证码 |


**4. 请求示例**

> /accountbaofoo/bindBankCard?callSystemID=1001

**5.返回报文**
```
{
  "code": 200,
  "msg": "成功",
  "traceID": "6ab86751-30c5-11e7-adb4-005056c00008",
  "data": {}
}
```

**6. 异常情况**


***




# 获取绑卡信息
 
**1. 接口描述**
 
>  获取宝付账户表中bank_card_info(数组)的第一条信息，涉及表：account_baofoo_custody.bank_card_info
>  
>  
     
**2.  接口信息**
> uri：  /accountbaofoo/bindBankCard
> 
> 访问类型：GET

**3. 请求参数**

|  参数名  |  类型  |  是否必传  |  说明  |
|  ---  |  ---  |  ---  |  ---  |
|   accountUuid/userUuid/accountNo |  String  |  是  |  查询条件 accountUuid或userUuid或accountNo  |


**4. 请求示例**

> /getUserBankCardInfo?callSystemID=1001

**5.返回报文**
```
{
  "code": 200,
  "msg": "成功",
  "traceID": "6ab86751-30c5-11e7-adb4-005056c00008",
  "data": {
    "bankUserName": "王勋",
    "bankUserIDCardNo": "130604198311121816",
    "bankUserPhone": "13567657078",
    "bankUserCardNo": "654587898787847"
  }
}
```

**6. 异常情况**


***





# 修改宝付账户(待实现)
 
**1. 接口描述**
 
>  根据account_uuid/user_uuid/account_no 修改宝付账户属性信息。涉及表：account、account_baofoo_custody
>  
     
**2.  接口信息**
> uri：  /accountbaofoo
> 
> 访问类型：PUT

**3. 请求参数**

|  参数名  |  类型  |  是否必传  |  说明  |
|  ---  |  ---  |  ---  |  ---  |
|   accountUuid/userUuid/accountNo |  String  |  是  |  查询条件 accountUuid或userUuid或accountNo  |
|  account和account_baofoo_custody 表中字段（转化为首字母小写的驼峰写法）|  String   |  否  | account和account_baofoo_custody 表中字段（转化为首字母小写的驼峰写法）  |

**4. 请求示例**


**5.返回报文**
```
{
  "code": 200,
  "msg": "成功",
  "traceID": "306f3f07-e6a9-4de7-98ff-ea8f1f0d5eaa",
  "data": "dfef3f07e6evde98ffd2"
}
```

**6. 异常情况**


***


# 冻结宝付账户(待实现)
 
**1. 接口描述**
 
>  根据account_uuid/user_uuid/account_no 冻结宝付账户。涉及表：account_baofoo_custody
>  
     
**2.  接口信息**
> uri：  /accountbaofoo/freeze
> 
> 访问类型：PUT

**3. 请求参数**

|  参数名  |  类型  |  是否必传  |  说明  |
|  ---  |  ---  |  ---  |  ---  |
|   accountUuid/userUuid/accountNo |  String  |  是  |  查询条件 accountUuid或userUuid或accountNo  |


**4. 请求示例**


**5.返回报文**
```
{
  "code": 200,
  "msg": "成功",
  "traceID": "306f3f07-e6a9-4de7-98ff-ea8f1f0d5eaa",
  "data": {}
}
```

**6. 异常情况**


***


# 获取宝付账户
 
**1. 接口描述**
 
>  获取账户信息
>  
>  
     
**2.  接口信息**
> uri：  /getAccountBaofoo
> 
> 访问类型：GET

**3. 请求参数**

|  参数名  |  类型  |  是否必传  |  说明  |
|  ---  |  ---  |  ---  |  ---  |
|  accountUuid/accountNo / userUuid | String | 是  | 账户UUID/ 宝付ID / 用户UUID |
|  properties | String | 否  | 需要返回的属性，多个属性用$$分割 |
|  desc | String | 否  | 需要将可以映射成字典的属性进行映射，可以选参数：simpleName/defaultName/fullName |


**4. 请求示例**

> /getAccountBaofoo?callSystemID=1001&accountNo=123456&properties=accountUuid$$accountAuthStatus&desc=defaultName

**5.返回报文**
```
{
  "code": 200,
  "msg": "成功",
  "traceID": "ab93de00-30c3-11e7-a743-005056c00008",
  "data": {
    "accountAuthStatus": 0,
    "accountUuid": "31b5006593f74d27bdbdfa96436ea091"
  }
}
```

**6. 异常情况**


***



# 获取账户流水列表
 
**1. 接口描述**
 
>  获取账户流水列表 
>  
>  
     
**2.  接口信息**
> uri：  /accounttransaction/list
> 
> 访问类型：GET

**3. 请求参数**

|  参数名  |  类型  |  是否必传  |  说明  |
|  ---  |  ---  |  ---  |  ---  |
|  accountUuid | String | 是  | 账户UUID |
|  tradeTypes| String | 是  | 交易类别（多个用$$分割），具体见下面列表|
|  properties | String | 否  | 需要返回的属性，多个属性用$$分割 |
|  desc | String | 否  | 需要将可以映射成字典的属性进行映射，可以选参数：simpleName/defaultName/fullName |
|  orderBy | String | 否  | 排序规则 ，默认create_time desc|
|  startRow | String | 否  | 开始显示位置，默认：0 |
|  pageSize | String | 否  | 每页显示数量，默认：20 |

**交易类别如下**：
```
订单:POX 
投资单:INX
放款单:PAX
退款单:RFX
产品到期_融资方返还本金:RPX
充值单:RCX
提现单:WDX
日常_充值提现手续费_平台:WFS
日常_充值提现手续费_投资者:WFA
产品到期_融资方返还收益:IPX
产品到期_平台返还营销加息:AIX
宝付成立_客户资金:AAX
宝付成立_平台营销费用:MAX
产品成立_平台佣金:MAX
产品成立_平台佣金:CPS
产品成立_理财顾问业绩:CPA
产品成立_1度邀请奖励佣金:CPO
产品成立_2度邀请奖励佣金:CPT
产品成立_私募服务津贴:CPP
活动奖励:CPE
```
**4. 请求示例**

> /getAccountTransactionList?callSystemID=1001&tradeTypes=CPO$$CPE&properties=accountUuid$$transactionTime$$tradeType$$transactionAmount&desc=defaultName&startRow=0&pageSize=20

**5.返回报文**
```
{
  "code": 200,
  "msg": "成功",
  "traceID": "bdcb9370-30c7-11e7-88cd-005056c00008",
  "data": [
    {
      "transactionTime": 1493902513000,
      "accountUuid": "036133286de848499fdf9539458ce15f"
    },
    {
      "transactionTime": 1493876439000,
      "accountUuid": "036133286de848499fdf9539458ce15f"
    }
 ]
}
```

**6. 异常情况**


***


# 获取账户流水总数
 
    同：获取账户流水列表



