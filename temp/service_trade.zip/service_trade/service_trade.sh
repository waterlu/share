#!/bin/bash

#start函数
start(){
        echo "starting service_trade"
        nohup java -jar -Xdebug -Xrunjdwp:transport=dt_socket,server=y,suspend=n,address=9528 target/service_trade-1.0.jar --spring.profiles.active=$system_env >/dev/null 2>&1 &
        echo "service_trade start ok"
}

#stop函数
stop(){
        PID=$(ps -ef | grep service_trade-1.0.jar  | grep -v grep | awk '{ print $2 }')
        if [ -z $PID ]
        then
            echo "service_trade is already stopped"
        else
            echo kill $PID
            kill $PID
            echo "service_trade stop ok"
        fi
}

#status函数
status(){
        PID=$(ps -ef | grep service_trade-1.0.jar  | grep -v grep | awk '{ print $2 }')
        if [ -z $PID ]
        then
            echo "service_trade is already stopped"
        else
            ps -ef | grep service_trade-1.0.jar  | grep -v grep
        fi
}

#restart函数
restart(){
        stop
        sleep 2
        start
}

#log函数
log(){
     tail -f /tmp/service_trade.log
}

case "$1" in
     "start")
          start
          ;;
     "stop")
          stop
          ;;
     "status")
          status
          ;;
     "restart")
          restart
          ;;
     "log")
          log
          ;;
     *)
          echo "用法：$0 start|stop|status|restart|log"
          ;;
esac