package cn.zjhf.kingold.trade.dto;

/**
 * 定期产品信息
 *
 * Created by lutiehua on 2017/5/27.
 */
public class ProductFTDto {

    /**
     * 产品UUID
     */
    private String productUuid;

    /**
     * 产品类型
     */
    private String productType;

    /**
     * 产品编码
     */
    private String productCode;

    /**
     * 产品名称
     */
    private String productName;

    /**
     * 产品简称
     */
    private String productAbbrName;

    /**
     * 产品期限
     */
    private Integer productPeriod;

    /**
     * 产品期限类型
     */
    private String productPeriodType;

    /**
     * 奖励佣金设置
     *
     * @return
     */
    private String productAward;

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductAbbrName() {
        return productAbbrName;
    }

    public void setProductAbbrName(String productAbbrName) {
        this.productAbbrName = productAbbrName;
    }

    public Integer getProductPeriod() {
        return productPeriod;
    }

    public void setProductPeriod(Integer productPeriod) {
        this.productPeriod = productPeriod;
    }

    public String getProductPeriodType() {
        return productPeriodType;
    }

    public void setProductPeriodType(String productPeriodType) {
        this.productPeriodType = productPeriodType;
    }

    public String getProductAward() {
        return productAward;
    }

    public void setProductAward(String productAward) {
        this.productAward = productAward;
    }
}
