package cn.zjhf.kingold.trade.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.entity.InVO.*;
import cn.zjhf.kingold.trade.entity.OutVO.CommItemListVO;
import cn.zjhf.kingold.trade.entity.OutVO.CommReportDataVO;
import cn.zjhf.kingold.trade.entity.OutVO.ProductRewardItemListVO;
import cn.zjhf.kingold.trade.entity.OutVO.ProductRewardSummaryListVO;
import cn.zjhf.kingold.trade.service.IPayService;
import cn.zjhf.kingold.trade.service.IReconciliationService;
import cn.zjhf.kingold.trade.service.IReportService;
import cn.zjhf.kingold.trade.utils.DataUtils;
import cn.zjhf.kingold.trade.utils.StringOrDate;
import cn.zjhf.kingold.trade.vo.ProductRewardSummaryReportVO;
import com.alibaba.fastjson.JSON;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by zhangyijie on 2017/6/5.
 */
@RestController
@RequestMapping(value = "/reportcontroller")
public class ReportController {
    protected static final Logger logger = LoggerFactory.getLogger(ReportController.class);

    @Autowired
    IReportService reportService;

    @Autowired
    IReconciliationService reconciliationService;

    private ResponseResult creatOKRespResult(String traceID) {
        ResponseResult respResult = new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS,"成功");
        return respResult;
    }

    private ResponseResult creatOKRespResult(String traceID, Object data) {
        ResponseResult respResult = new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS,"成功", data);
        return respResult;
    }

    /**
     * Step1 产品奖励记录_查询
     * 报表管理/财务/活动费用计税表
     * @param param
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/lstProductRewardSummaryItems", method = RequestMethod.GET)
    public ResponseResult lstProductRewardSummaryItems(@RequestParam Map<String, Object> param) throws BusinessException {
        String jsonString = JSON.toJSONString(param);
        LstProductRewardSummaryItemsVO lstProductRewardSummaryItemsVO = JSON.parseObject(jsonString, LstProductRewardSummaryItemsVO.class);
        logger.info("lstProductRewardSummaryItems start: " + DataUtils.toString(lstProductRewardSummaryItemsVO));

        ProductRewardSummaryListVO productRewardSummaryListVO = reportService.lstProductRewardSummaryItems(lstProductRewardSummaryItemsVO);

        logger.info("lstProductRewardSummaryItems end: " + DataUtils.toString(lstProductRewardSummaryItemsVO.getTraceID(), productRewardSummaryListVO));
        return creatOKRespResult(lstProductRewardSummaryItemsVO.getTraceID(), productRewardSummaryListVO);
    }

    /**
     * 报表管理/产品/产品收支明细表
     * @param param
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/expenditureDetailsReport", method = RequestMethod.GET)
    public ResponseResult expenditureDetailsReport(@RequestParam Map<String, Object> param) throws BusinessException {
        String jsonString = JSON.toJSONString(param);
        LstProductRewardSummaryItemsVO vo = JSON.parseObject(jsonString, LstProductRewardSummaryItemsVO.class);
        logger.info("expenditureDetailsReport start:{} " ,vo);
        CommItemListVO<ProductRewardSummaryReportVO> reportVO = reportService.getExpenditureDetailsReport(vo);
        logger.info("expenditureDetailsReport end: {}", DataUtils.toString(vo.getTraceID(), reportVO));
        return creatOKRespResult(vo.getTraceID(), reportVO);
    }

    /**
     * Step2 产品奖励记录_批量报税审核
     * @param productRewardSummaryBatchAuditVO
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/productRewardSummaryBatchIncomeTaxAudit", method = RequestMethod.PUT)
    public ResponseResult productRewardSummaryBatchIncomeTaxAudit(@RequestBody ProductRewardSummaryBatchAuditVO productRewardSummaryBatchAuditVO) throws BusinessException {
        logger.info("productRewardSummaryBatchIncomeTaxAudit start: " + DataUtils.toString(productRewardSummaryBatchAuditVO));

        DataUtils.checkParam(productRewardSummaryBatchAuditVO.getProductUuidList());
        int count = reportService.productRewardSummaryBatchIncomeTaxAudit(productRewardSummaryBatchAuditVO);

        logger.info("productRewardSummaryBatchIncomeTaxAudit end: " + DataUtils.toString(productRewardSummaryBatchAuditVO.getTraceID(), count));
        return creatOKRespResult(productRewardSummaryBatchAuditVO.getTraceID(), count);
    }

    /**
     * Step3 产品奖励记录_批量报税(结算)
     * @param productRewardSummaryBatchAuditVO
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/productRewardSummaryBatchIncomeTaxClear", method = RequestMethod.PUT)
    public ResponseResult productRewardSummaryBatchIncomeTaxClear(@RequestBody ProductRewardSummaryBatchAuditVO productRewardSummaryBatchAuditVO) throws BusinessException {
        logger.info("productRewardSummaryBatchIncomeTaxClear start: " + DataUtils.toString(productRewardSummaryBatchAuditVO));

        DataUtils.checkParam(productRewardSummaryBatchAuditVO.getProductUuidList());
        int count = reportService.productRewardSummaryBatchIncomeTaxClear(productRewardSummaryBatchAuditVO);

        logger.info("productRewardSummaryBatchIncomeTaxClear end: " + DataUtils.toString(productRewardSummaryBatchAuditVO.getTraceID(), count));
        return creatOKRespResult(productRewardSummaryBatchAuditVO.getTraceID(), count);
    }

    /**
     * Step4 产品奖励记录_奖励详情_产品奖励明细记录
     * @param param
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/lstProductRewardItems", method = RequestMethod.GET)
    public ResponseResult lstProductRewardItems(@RequestParam Map<String, Object> param) throws BusinessException {
        String jsonString = JSON.toJSONString(param);
        LstProductRewardItemsVO lstProductRewardItemsVO = JSON.parseObject(jsonString, LstProductRewardItemsVO.class);
        logger.info("lstProductRewardItems start: " + DataUtils.toString(lstProductRewardItemsVO));

        DataUtils.checkParam(lstProductRewardItemsVO.getProduct_uuid());
        ProductRewardItemListVO productRewardItemListVO = reportService.lstProductRewardItems(lstProductRewardItemsVO);

        logger.info("lstProductRewardItems end: " + DataUtils.toString(lstProductRewardItemsVO.getTraceID(), productRewardItemListVO));
        return creatOKRespResult(lstProductRewardItemsVO.getTraceID(), productRewardItemListVO);
    }

    /**
     * Step5 产品奖励记录_奖励详情_管理费审核
     * @param productRewardSummaryBatchAuditVO
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/productRewardSummaryExchangeManagefeeAudit", method = RequestMethod.PUT)
    public ResponseResult productRewardSummaryExchangeManagefeeAudit(@RequestBody ProductRewardSummaryBatchAuditVO productRewardSummaryBatchAuditVO) throws BusinessException {
        logger.info("productRewardSummaryExchangeManagefeeAudit start: " + DataUtils.toString(productRewardSummaryBatchAuditVO));

        int count = reportService.productRewardSummaryExchangeManagefeeAudit(productRewardSummaryBatchAuditVO);

        logger.info("productRewardSummaryExchangeManagefeeAudit end: " + DataUtils.toString(productRewardSummaryBatchAuditVO.getTraceID(), count));
        return creatOKRespResult(productRewardSummaryBatchAuditVO.getTraceID(), count);
    }

    /**
     * Step6 产品奖励记录_奖励详情_管理费结算
     * @param productRewardSummaryBatchAuditVO
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/productRewardSummaryExchangeManagefeeClear", method = RequestMethod.PUT)
    public ResponseResult productRewardSummaryExchangeManagefeeClear(@RequestBody ProductRewardSummaryBatchAuditVO productRewardSummaryBatchAuditVO) throws BusinessException {
        logger.info("productRewardSummaryExchangeManagefeeClear start: " + DataUtils.toString(productRewardSummaryBatchAuditVO));

        int count = reportService.productRewardSummaryExchangeManagefeeClear(productRewardSummaryBatchAuditVO);

        logger.info("productRewardSummaryExchangeManagefeeClear end: " + DataUtils.toString(productRewardSummaryBatchAuditVO.getTraceID(), count));
        return creatOKRespResult(productRewardSummaryBatchAuditVO.getTraceID(), count);
    }

    /**
     * Step13 账户对账
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/commReconAccount", method = RequestMethod.GET)
    public ResponseResult commReconAccount(@RequestParam Map<String, Object> param) throws BusinessException {
        String jsonString = JSON.toJSONString(param);
        ReconcConditionVO lstConditionVO = JSON.parseObject(jsonString, ReconcConditionVO.class);
        logger.info("commReconAccount start: " + DataUtils.toString(lstConditionVO));

        DataUtils.checkParam(lstConditionVO.getReconcType());

        CommReportDataVO retData = new CommReportDataVO();
        if(11 == lstConditionVO.getReconcType()) {
            retData = reconciliationService.checkAccount(lstConditionVO);
        }else if(DataUtils.isContain(lstConditionVO.getReconcType(), IPayService.TYPE_RECHARGE, IPayService.TYPE_WITHDRAW)) {
            retData = reconciliationService.reconciliationRecharge(lstConditionVO);
        }else if(DataUtils.isContain(lstConditionVO.getReconcType(), IPayService.TYPE_INVEST, IPayService.TYPE_PAYMENT, IPayService.TYPE_REPAYMENT, IPayService.TYPE_TRANSFER)) {
            retData = reconciliationService.reconciliationTrade(lstConditionVO);
        }

        logger.info("commReconAccount end: " + DataUtils.toString(lstConditionVO.getTraceID(), retData));
        return creatOKRespResult(lstConditionVO.getTraceID(), retData);
    }


    /**
     * 通用报表处理
     *
     * @param param
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/getCommReport", method = RequestMethod.GET)
    public ResponseResult getCommReport(@RequestParam Map<String, Object> param) throws BusinessException {
        logger.info("getCommReport start: " + DataUtils.toString(param));
        String jsonString = JSON.toJSONString(param);
        ReportConditionVO reportCondition = JSON.parseObject(jsonString, ReportConditionVO.class);

        DataUtils.checkParam(reportCondition.getTraceID(), reportCondition.getReportNo());
        CommReportDataVO reportData = reportService.commReportEx(reportCondition);

        logger.info("getCommReport end: " + DataUtils.toString(reportCondition.getTraceID(), reportData));
        return creatOKRespResult(reportCondition.getTraceID(), reportData);
    }
}
