package cn.zjhf.kingold.trade.baofoo;

/**
 * @Author liuyao
 * @Description
 * @Date Created in 19:58 2017/6/1
 */

public class BaofooOrderIdResponse extends BaoFooResponse {
    private String order_id;

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }
}
