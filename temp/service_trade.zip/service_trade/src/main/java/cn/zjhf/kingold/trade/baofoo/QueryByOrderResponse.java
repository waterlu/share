package cn.zjhf.kingold.trade.baofoo;

import java.util.List;

/**
 * Created by lutiehua on 2017/5/3.
 */
public class QueryByOrderResponse extends BaoFooResponse {

    public List<QueryByOrderResult> getResult() {
        return result;
    }

    public void setResult(List<QueryByOrderResult> result) {
        this.result = result;
    }

    private List<QueryByOrderResult> result;
}
