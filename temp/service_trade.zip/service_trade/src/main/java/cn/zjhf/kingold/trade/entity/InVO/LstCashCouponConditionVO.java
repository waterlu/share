package cn.zjhf.kingold.trade.entity.InVO;

import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Size;
import java.util.Date;

/**
 * Created by zhangyijie on 2017/7/5.
 */
public class LstCashCouponConditionVO extends InVOBase {

    @ApiModelProperty(required = true, value = "现金券批次号")
    private String ccCode;

    @ApiModelProperty(required = true, value = "现金券类型(0全部，1现金券，2加息券)")
    private int ccType;

    @ApiModelProperty(required = true, value = "现金券状态(0全部，1待激活，2已激活，3已停用)")
    private int ccStatus;

    @ApiModelProperty(required = true, value = "创建时间_起始")
    private Date beginDate;

    @ApiModelProperty(required = true, value = "创建时间_结束")
    private Date endDate;

    @ApiModelProperty(required = true, value = "起始序号")
    private int beginSN;

    @ApiModelProperty(required = true, value = "结束序号")
    private int endSN;

    /**
     * 礼券code（多个$$分割）
     */
    @ApiModelProperty(required = false, value = "礼券code（多个$$分割）")
    private String couponCodes;

    public String getCcCode() {
        return ccCode;
    }

    public void setCcCode(String ccCode) {
        this.ccCode = ccCode;
    }

    public int getBeginSN() {
        return beginSN;
    }

    public void setBeginSN(int beginSN) {
        this.beginSN = beginSN;
    }

    public int getEndSN() {
        return endSN;
    }

    public void setEndSN(int endSN) {
        this.endSN = endSN;
    }

    public int getCcType() {
        return ccType;
    }

    public void setCcType(int ccType) {
        this.ccType = ccType;
    }

    public int getCcStatus() {
        return ccStatus;
    }

    public void setCcStatus(int ccStatus) {
        this.ccStatus = ccStatus;
    }

    public Date getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(Date beginDate) {
        this.beginDate = beginDate;
    }

    public Date getEndDate() {
        return convertEndDate(endDate);
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getCouponCodes() {
        return couponCodes;
    }

    public void setCouponCodes(String couponCodes) {
        this.couponCodes = couponCodes;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(getTraceID()) + ", ");
        sb.append("ccCode:" + DataUtils.toString(ccCode) + ", ");
        sb.append("ccType:" + DataUtils.toString(ccType) + ", ");
        sb.append("ccStatus:" + DataUtils.toString(ccStatus) + ", ");

        sb.append("beginDate:" + DataUtils.toString(beginDate) + ", ");
        sb.append("endDate:" + DataUtils.toString(endDate) + ", ");
        sb.append("beginSN:" + DataUtils.toString(beginSN) + ", ");
        sb.append("endSN:" + DataUtils.toString(endSN));
        sb.append("couponCodes:" + DataUtils.toString(couponCodes));
        return sb.toString();
    }
}
