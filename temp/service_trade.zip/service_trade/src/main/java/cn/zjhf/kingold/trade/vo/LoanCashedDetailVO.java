package cn.zjhf.kingold.trade.vo;

import cn.zjhf.kingold.trade.entity.InVO.InVOBase;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author xiexiaojie
 *         2018/3/20.
 *         募集放款、到期兑付明细
 */
public class LoanCashedDetailVO extends InVOBase{

    @ApiModelProperty(required = true, value = "订单编号扩展（宝付交易流水编号）")
    private String tradeOrderBillCodeExtend;

    @ApiModelProperty(required = true, value = "订单号，产品订单编号")
    private String orderBillCode;

    @ApiModelProperty(required = true, value = "用户名，手机号码")
    private String userPhone;

    @ApiModelProperty(required = true, value = "交易时间")
    private Date transactionTime;

    @ApiModelProperty(required = true, value = "产品UUID")
    private String productUuid;

    @ApiModelProperty(required = true, value = "投资金额/放款金额/本金   订单金额，订单金额 = 实缴金额 + 营销费用；订单金额 = 产品份额 * 产品单价")
    private BigDecimal orderAmount;

    @ApiModelProperty(required = true, value = "预期收益")
    private BigDecimal expectedProfitAmount;

    @ApiModelProperty(required = true, value = "支付金额/冻结金额   实缴金额")
    private BigDecimal paidAmount;

    @ApiModelProperty(required = true, value = "代金券金额   营销费用")
    private BigDecimal marketingAmount;

    @ApiModelProperty(required = true, value = "募集方应还利息(收益)  投资收益")
    private BigDecimal profitAmount;

    @ApiModelProperty(required = true, value = "平台应还营销利息(收益)  营销加息金额")
    private BigDecimal marketingRateAmount;

    @ApiModelProperty(required = true, value = "返还总金额  兑付金额")
    private BigDecimal cashAmount;

    @ApiModelProperty(required = true, value = "募集方返还总额")
    private BigDecimal partyRaisedReturnTotalAmount;

    @ApiModelProperty(required = true, value = "订单状态 1创建，2已付款，3产品成立，4已清算，5撤销")
    private Integer orderStatus;

    public String getTradeOrderBillCodeExtend() {
        return tradeOrderBillCodeExtend;
    }

    public void setTradeOrderBillCodeExtend(String tradeOrderBillCodeExtend) {
        this.tradeOrderBillCodeExtend = tradeOrderBillCodeExtend;
    }

    public String getOrderBillCode() {
        return orderBillCode;
    }

    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    public Date getTransactionTime() {
        return transactionTime;
    }

    public void setTransactionTime(Date transactionTime) {
        this.transactionTime = transactionTime;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public BigDecimal getOrderAmount() {
        return formatMoney(orderAmount);
    }

    public void setOrderAmount(BigDecimal orderAmount) {
        this.orderAmount = orderAmount;
    }

    public BigDecimal getExpectedProfitAmount() {
        return formatMoney(expectedProfitAmount);
    }

    public void setExpectedProfitAmount(BigDecimal expectedProfitAmount) {
        this.expectedProfitAmount = expectedProfitAmount;
    }

    public BigDecimal getPaidAmount() {
        return formatMoney(paidAmount);
    }

    public void setPaidAmount(BigDecimal paidAmount) {
        this.paidAmount = paidAmount;
    }

    public BigDecimal getMarketingAmount() {
        return formatMoney(marketingAmount);
    }

    public void setMarketingAmount(BigDecimal marketingAmount) {
        this.marketingAmount = marketingAmount;
    }

    public BigDecimal getProfitAmount() {
        return formatMoney(profitAmount);
    }

    public void setProfitAmount(BigDecimal profitAmount) {
        this.profitAmount = profitAmount;
    }

    public BigDecimal getMarketingRateAmount() {
        return formatMoney(marketingRateAmount);
    }

    public void setMarketingRateAmount(BigDecimal marketingRateAmount) {
        this.marketingRateAmount = marketingRateAmount;
    }

    public BigDecimal getCashAmount() {
        return formatMoney(cashAmount);
    }

    public void setCashAmount(BigDecimal cashAmount) {
        this.cashAmount = cashAmount;
    }

    public BigDecimal getPartyRaisedReturnTotalAmount() {
        return formatMoney(partyRaisedReturnTotalAmount);
    }

    public void setPartyRaisedReturnTotalAmount(BigDecimal partyRaisedReturnTotalAmount) {
        this.partyRaisedReturnTotalAmount = partyRaisedReturnTotalAmount;
    }

    public Integer getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(Integer orderStatus) {
        this.orderStatus = orderStatus;
    }

    @Override
    public String toString() {
        return "LoanCashedDetailVO{" +
                "tradeOrderBillCodeExtend='" + tradeOrderBillCodeExtend + '\'' +
                ", orderBillCode='" + orderBillCode + '\'' +
                ", userPhone='" + userPhone + '\'' +
                ", transactionTime=" + transactionTime +
                ", productUuid='" + productUuid + '\'' +
                ", orderAmount=" + orderAmount +
                ", expectedProfitAmount=" + expectedProfitAmount +
                ", paidAmount=" + paidAmount +
                ", marketingAmount=" + marketingAmount +
                ", profitAmount=" + profitAmount +
                ", marketingRateAmount=" + marketingRateAmount +
                ", cashAmount=" + cashAmount +
                ", partyRaisedReturnTotalAmount=" + partyRaisedReturnTotalAmount +
                ", orderStatus=" + orderStatus +
                '}';
    }
}
