package cn.zjhf.kingold.trade.baofoo;

import org.apache.commons.lang3.StringUtils;

import java.util.Date;

/**
 * Created by lutiehua on 2017/4/26.
 */
public class BaoFooResponse {

    /**
     * 编码
     */
    private String code;

    /**
     * 信息
     */
    private String msg;

    /**
     * 签名
     */
    private String sign;

    /**
     * 请求参数
     */
    private String requestParam;

    /**
     * 请求时间
     */
    private Date requestTime;

    /**
     * 响应时间
     */
    private Date responseTime;

    public boolean isSuccessful() {
        if (StringUtils.isBlank(code)) {
            return false;
        }

        return BaoFooCode.OK.equalsIgnoreCase(code);
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getRequestParam() {
        return requestParam;
    }

    public void setRequestParam(String requestParam) {
        this.requestParam = requestParam;
    }

    public Date getRequestTime() {
        return requestTime;
    }

    public void setRequestTime(Date requestTime) {
        this.requestTime = requestTime;
    }

    public Date getResponseTime() {
        return responseTime;
    }

    public void setResponseTime(Date responseTime) {
        this.responseTime = responseTime;
    }
}
