package cn.zjhf.kingold.trade.baofoo;

import java.util.Date;

/**
 * Created by lutiehua on 2017/7/5.
 */
public class RechargeNotify {

    private String billCode;

    private double amount;

    private int feeTakenOn;

    private double fee;

    private Date time;

    private String channel;

    private String result;

    public String getBillCode() {
        return billCode;
    }

    public void setBillCode(String billCode) {
        this.billCode = billCode;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public int getFeeTakenOn() {
        return feeTakenOn;
    }

    public void setFeeTakenOn(int feeTakenOn) {
        this.feeTakenOn = feeTakenOn;
    }

    public double getFee() {
        return fee;
    }

    public void setFee(double fee) {
        this.fee = fee;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    @Override
    public String toString() {
        return "RechargeNotify{" +
                "billCode='" + billCode + '\'' +
                ", amount=" + amount +
                ", feeTakenOn=" + feeTakenOn +
                ", fee=" + fee +
                ", time=" + time +
                ", channel='" + channel + '\'' +
                ", result='" + result + '\'' +
                '}';
    }
}
