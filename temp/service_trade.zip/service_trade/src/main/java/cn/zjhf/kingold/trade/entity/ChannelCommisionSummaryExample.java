package cn.zjhf.kingold.trade.entity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ChannelCommisionSummaryExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private Integer limit;

    private Integer offset;

    public ChannelCommisionSummaryExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andChannelCommisionSummaryIdIsNull() {
            addCriterion("channel_commision_summary_id is null");
            return (Criteria) this;
        }

        public Criteria andChannelCommisionSummaryIdIsNotNull() {
            addCriterion("channel_commision_summary_id is not null");
            return (Criteria) this;
        }

        public Criteria andChannelCommisionSummaryIdEqualTo(String value) {
            addCriterion("channel_commision_summary_id =", value, "channelCommisionSummaryId");
            return (Criteria) this;
        }

        public Criteria andChannelCommisionSummaryIdNotEqualTo(String value) {
            addCriterion("channel_commision_summary_id <>", value, "channelCommisionSummaryId");
            return (Criteria) this;
        }

        public Criteria andChannelCommisionSummaryIdGreaterThan(String value) {
            addCriterion("channel_commision_summary_id >", value, "channelCommisionSummaryId");
            return (Criteria) this;
        }

        public Criteria andChannelCommisionSummaryIdGreaterThanOrEqualTo(String value) {
            addCriterion("channel_commision_summary_id >=", value, "channelCommisionSummaryId");
            return (Criteria) this;
        }

        public Criteria andChannelCommisionSummaryIdLessThan(String value) {
            addCriterion("channel_commision_summary_id <", value, "channelCommisionSummaryId");
            return (Criteria) this;
        }

        public Criteria andChannelCommisionSummaryIdLessThanOrEqualTo(String value) {
            addCriterion("channel_commision_summary_id <=", value, "channelCommisionSummaryId");
            return (Criteria) this;
        }

        public Criteria andChannelCommisionSummaryIdLike(String value) {
            addCriterion("channel_commision_summary_id like", value, "channelCommisionSummaryId");
            return (Criteria) this;
        }

        public Criteria andChannelCommisionSummaryIdNotLike(String value) {
            addCriterion("channel_commision_summary_id not like", value, "channelCommisionSummaryId");
            return (Criteria) this;
        }

        public Criteria andChannelCommisionSummaryIdIn(List<String> values) {
            addCriterion("channel_commision_summary_id in", values, "channelCommisionSummaryId");
            return (Criteria) this;
        }

        public Criteria andChannelCommisionSummaryIdNotIn(List<String> values) {
            addCriterion("channel_commision_summary_id not in", values, "channelCommisionSummaryId");
            return (Criteria) this;
        }

        public Criteria andChannelCommisionSummaryIdBetween(String value1, String value2) {
            addCriterion("channel_commision_summary_id between", value1, value2, "channelCommisionSummaryId");
            return (Criteria) this;
        }

        public Criteria andChannelCommisionSummaryIdNotBetween(String value1, String value2) {
            addCriterion("channel_commision_summary_id not between", value1, value2, "channelCommisionSummaryId");
            return (Criteria) this;
        }

        public Criteria andRequestCycleIsNull() {
            addCriterion("request_cycle is null");
            return (Criteria) this;
        }

        public Criteria andRequestCycleIsNotNull() {
            addCriterion("request_cycle is not null");
            return (Criteria) this;
        }

        public Criteria andRequestCycleEqualTo(String value) {
            addCriterion("request_cycle =", value, "requestCycle");
            return (Criteria) this;
        }

        public Criteria andRequestCycleNotEqualTo(String value) {
            addCriterion("request_cycle <>", value, "requestCycle");
            return (Criteria) this;
        }

        public Criteria andRequestCycleGreaterThan(String value) {
            addCriterion("request_cycle >", value, "requestCycle");
            return (Criteria) this;
        }

        public Criteria andRequestCycleGreaterThanOrEqualTo(String value) {
            addCriterion("request_cycle >=", value, "requestCycle");
            return (Criteria) this;
        }

        public Criteria andRequestCycleLessThan(String value) {
            addCriterion("request_cycle <", value, "requestCycle");
            return (Criteria) this;
        }

        public Criteria andRequestCycleLessThanOrEqualTo(String value) {
            addCriterion("request_cycle <=", value, "requestCycle");
            return (Criteria) this;
        }

        public Criteria andRequestCycleLike(String value) {
            addCriterion("request_cycle like", value, "requestCycle");
            return (Criteria) this;
        }

        public Criteria andRequestCycleNotLike(String value) {
            addCriterion("request_cycle not like", value, "requestCycle");
            return (Criteria) this;
        }

        public Criteria andRequestCycleIn(List<String> values) {
            addCriterion("request_cycle in", values, "requestCycle");
            return (Criteria) this;
        }

        public Criteria andRequestCycleNotIn(List<String> values) {
            addCriterion("request_cycle not in", values, "requestCycle");
            return (Criteria) this;
        }

        public Criteria andRequestCycleBetween(String value1, String value2) {
            addCriterion("request_cycle between", value1, value2, "requestCycle");
            return (Criteria) this;
        }

        public Criteria andRequestCycleNotBetween(String value1, String value2) {
            addCriterion("request_cycle not between", value1, value2, "requestCycle");
            return (Criteria) this;
        }

        public Criteria andMerchantNumIsNull() {
            addCriterion("merchant_num is null");
            return (Criteria) this;
        }

        public Criteria andMerchantNumIsNotNull() {
            addCriterion("merchant_num is not null");
            return (Criteria) this;
        }

        public Criteria andMerchantNumEqualTo(String value) {
            addCriterion("merchant_num =", value, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumNotEqualTo(String value) {
            addCriterion("merchant_num <>", value, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumGreaterThan(String value) {
            addCriterion("merchant_num >", value, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumGreaterThanOrEqualTo(String value) {
            addCriterion("merchant_num >=", value, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumLessThan(String value) {
            addCriterion("merchant_num <", value, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumLessThanOrEqualTo(String value) {
            addCriterion("merchant_num <=", value, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumLike(String value) {
            addCriterion("merchant_num like", value, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumNotLike(String value) {
            addCriterion("merchant_num not like", value, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumIn(List<String> values) {
            addCriterion("merchant_num in", values, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumNotIn(List<String> values) {
            addCriterion("merchant_num not in", values, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumBetween(String value1, String value2) {
            addCriterion("merchant_num between", value1, value2, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumNotBetween(String value1, String value2) {
            addCriterion("merchant_num not between", value1, value2, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameIsNull() {
            addCriterion("channel_app_name is null");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameIsNotNull() {
            addCriterion("channel_app_name is not null");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameEqualTo(String value) {
            addCriterion("channel_app_name =", value, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameNotEqualTo(String value) {
            addCriterion("channel_app_name <>", value, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameGreaterThan(String value) {
            addCriterion("channel_app_name >", value, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameGreaterThanOrEqualTo(String value) {
            addCriterion("channel_app_name >=", value, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameLessThan(String value) {
            addCriterion("channel_app_name <", value, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameLessThanOrEqualTo(String value) {
            addCriterion("channel_app_name <=", value, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameLike(String value) {
            addCriterion("channel_app_name like", value, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameNotLike(String value) {
            addCriterion("channel_app_name not like", value, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameIn(List<String> values) {
            addCriterion("channel_app_name in", values, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameNotIn(List<String> values) {
            addCriterion("channel_app_name not in", values, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameBetween(String value1, String value2) {
            addCriterion("channel_app_name between", value1, value2, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameNotBetween(String value1, String value2) {
            addCriterion("channel_app_name not between", value1, value2, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andCommisionAmountIsNull() {
            addCriterion("commision_amount is null");
            return (Criteria) this;
        }

        public Criteria andCommisionAmountIsNotNull() {
            addCriterion("commision_amount is not null");
            return (Criteria) this;
        }

        public Criteria andCommisionAmountEqualTo(BigDecimal value) {
            addCriterion("commision_amount =", value, "commisionAmount");
            return (Criteria) this;
        }

        public Criteria andCommisionAmountNotEqualTo(BigDecimal value) {
            addCriterion("commision_amount <>", value, "commisionAmount");
            return (Criteria) this;
        }

        public Criteria andCommisionAmountGreaterThan(BigDecimal value) {
            addCriterion("commision_amount >", value, "commisionAmount");
            return (Criteria) this;
        }

        public Criteria andCommisionAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("commision_amount >=", value, "commisionAmount");
            return (Criteria) this;
        }

        public Criteria andCommisionAmountLessThan(BigDecimal value) {
            addCriterion("commision_amount <", value, "commisionAmount");
            return (Criteria) this;
        }

        public Criteria andCommisionAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("commision_amount <=", value, "commisionAmount");
            return (Criteria) this;
        }

        public Criteria andCommisionAmountIn(List<BigDecimal> values) {
            addCriterion("commision_amount in", values, "commisionAmount");
            return (Criteria) this;
        }

        public Criteria andCommisionAmountNotIn(List<BigDecimal> values) {
            addCriterion("commision_amount not in", values, "commisionAmount");
            return (Criteria) this;
        }

        public Criteria andCommisionAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("commision_amount between", value1, value2, "commisionAmount");
            return (Criteria) this;
        }

        public Criteria andCommisionAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("commision_amount not between", value1, value2, "commisionAmount");
            return (Criteria) this;
        }

        public Criteria andSettleStatusIsNull() {
            addCriterion("settle_status is null");
            return (Criteria) this;
        }

        public Criteria andSettleStatusIsNotNull() {
            addCriterion("settle_status is not null");
            return (Criteria) this;
        }

        public Criteria andSettleStatusEqualTo(Byte value) {
            addCriterion("settle_status =", value, "settleStatus");
            return (Criteria) this;
        }

        public Criteria andSettleStatusNotEqualTo(Byte value) {
            addCriterion("settle_status <>", value, "settleStatus");
            return (Criteria) this;
        }

        public Criteria andSettleStatusGreaterThan(Byte value) {
            addCriterion("settle_status >", value, "settleStatus");
            return (Criteria) this;
        }

        public Criteria andSettleStatusGreaterThanOrEqualTo(Byte value) {
            addCriterion("settle_status >=", value, "settleStatus");
            return (Criteria) this;
        }

        public Criteria andSettleStatusLessThan(Byte value) {
            addCriterion("settle_status <", value, "settleStatus");
            return (Criteria) this;
        }

        public Criteria andSettleStatusLessThanOrEqualTo(Byte value) {
            addCriterion("settle_status <=", value, "settleStatus");
            return (Criteria) this;
        }

        public Criteria andSettleStatusIn(List<Byte> values) {
            addCriterion("settle_status in", values, "settleStatus");
            return (Criteria) this;
        }

        public Criteria andSettleStatusNotIn(List<Byte> values) {
            addCriterion("settle_status not in", values, "settleStatus");
            return (Criteria) this;
        }

        public Criteria andSettleStatusBetween(Byte value1, Byte value2) {
            addCriterion("settle_status between", value1, value2, "settleStatus");
            return (Criteria) this;
        }

        public Criteria andSettleStatusNotBetween(Byte value1, Byte value2) {
            addCriterion("settle_status not between", value1, value2, "settleStatus");
            return (Criteria) this;
        }

        public Criteria andSettleOperatorIsNull() {
            addCriterion("settle_operator is null");
            return (Criteria) this;
        }

        public Criteria andSettleOperatorIsNotNull() {
            addCriterion("settle_operator is not null");
            return (Criteria) this;
        }

        public Criteria andSettleOperatorEqualTo(String value) {
            addCriterion("settle_operator =", value, "settleOperator");
            return (Criteria) this;
        }

        public Criteria andSettleOperatorNotEqualTo(String value) {
            addCriterion("settle_operator <>", value, "settleOperator");
            return (Criteria) this;
        }

        public Criteria andSettleOperatorGreaterThan(String value) {
            addCriterion("settle_operator >", value, "settleOperator");
            return (Criteria) this;
        }

        public Criteria andSettleOperatorGreaterThanOrEqualTo(String value) {
            addCriterion("settle_operator >=", value, "settleOperator");
            return (Criteria) this;
        }

        public Criteria andSettleOperatorLessThan(String value) {
            addCriterion("settle_operator <", value, "settleOperator");
            return (Criteria) this;
        }

        public Criteria andSettleOperatorLessThanOrEqualTo(String value) {
            addCriterion("settle_operator <=", value, "settleOperator");
            return (Criteria) this;
        }

        public Criteria andSettleOperatorLike(String value) {
            addCriterion("settle_operator like", value, "settleOperator");
            return (Criteria) this;
        }

        public Criteria andSettleOperatorNotLike(String value) {
            addCriterion("settle_operator not like", value, "settleOperator");
            return (Criteria) this;
        }

        public Criteria andSettleOperatorIn(List<String> values) {
            addCriterion("settle_operator in", values, "settleOperator");
            return (Criteria) this;
        }

        public Criteria andSettleOperatorNotIn(List<String> values) {
            addCriterion("settle_operator not in", values, "settleOperator");
            return (Criteria) this;
        }

        public Criteria andSettleOperatorBetween(String value1, String value2) {
            addCriterion("settle_operator between", value1, value2, "settleOperator");
            return (Criteria) this;
        }

        public Criteria andSettleOperatorNotBetween(String value1, String value2) {
            addCriterion("settle_operator not between", value1, value2, "settleOperator");
            return (Criteria) this;
        }

        public Criteria andSettleTimeIsNull() {
            addCriterion("settle_time is null");
            return (Criteria) this;
        }

        public Criteria andSettleTimeIsNotNull() {
            addCriterion("settle_time is not null");
            return (Criteria) this;
        }

        public Criteria andSettleTimeEqualTo(Date value) {
            addCriterion("settle_time =", value, "settleTime");
            return (Criteria) this;
        }

        public Criteria andSettleTimeNotEqualTo(Date value) {
            addCriterion("settle_time <>", value, "settleTime");
            return (Criteria) this;
        }

        public Criteria andSettleTimeGreaterThan(Date value) {
            addCriterion("settle_time >", value, "settleTime");
            return (Criteria) this;
        }

        public Criteria andSettleTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("settle_time >=", value, "settleTime");
            return (Criteria) this;
        }

        public Criteria andSettleTimeLessThan(Date value) {
            addCriterion("settle_time <", value, "settleTime");
            return (Criteria) this;
        }

        public Criteria andSettleTimeLessThanOrEqualTo(Date value) {
            addCriterion("settle_time <=", value, "settleTime");
            return (Criteria) this;
        }

        public Criteria andSettleTimeIn(List<Date> values) {
            addCriterion("settle_time in", values, "settleTime");
            return (Criteria) this;
        }

        public Criteria andSettleTimeNotIn(List<Date> values) {
            addCriterion("settle_time not in", values, "settleTime");
            return (Criteria) this;
        }

        public Criteria andSettleTimeBetween(Date value1, Date value2) {
            addCriterion("settle_time between", value1, value2, "settleTime");
            return (Criteria) this;
        }

        public Criteria andSettleTimeNotBetween(Date value1, Date value2) {
            addCriterion("settle_time not between", value1, value2, "settleTime");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionIsNull() {
            addCriterion("audit_opinion is null");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionIsNotNull() {
            addCriterion("audit_opinion is not null");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionEqualTo(String value) {
            addCriterion("audit_opinion =", value, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionNotEqualTo(String value) {
            addCriterion("audit_opinion <>", value, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionGreaterThan(String value) {
            addCriterion("audit_opinion >", value, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionGreaterThanOrEqualTo(String value) {
            addCriterion("audit_opinion >=", value, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionLessThan(String value) {
            addCriterion("audit_opinion <", value, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionLessThanOrEqualTo(String value) {
            addCriterion("audit_opinion <=", value, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionLike(String value) {
            addCriterion("audit_opinion like", value, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionNotLike(String value) {
            addCriterion("audit_opinion not like", value, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionIn(List<String> values) {
            addCriterion("audit_opinion in", values, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionNotIn(List<String> values) {
            addCriterion("audit_opinion not in", values, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionBetween(String value1, String value2) {
            addCriterion("audit_opinion between", value1, value2, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionNotBetween(String value1, String value2) {
            addCriterion("audit_opinion not between", value1, value2, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNull() {
            addCriterion("delete_flag is null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNotNull() {
            addCriterion("delete_flag is not null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagEqualTo(Byte value) {
            addCriterion("delete_flag =", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotEqualTo(Byte value) {
            addCriterion("delete_flag <>", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThan(Byte value) {
            addCriterion("delete_flag >", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThanOrEqualTo(Byte value) {
            addCriterion("delete_flag >=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThan(Byte value) {
            addCriterion("delete_flag <", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThanOrEqualTo(Byte value) {
            addCriterion("delete_flag <=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIn(List<Byte> values) {
            addCriterion("delete_flag in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotIn(List<Byte> values) {
            addCriterion("delete_flag not in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagBetween(Byte value1, Byte value2) {
            addCriterion("delete_flag between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotBetween(Byte value1, Byte value2) {
            addCriterion("delete_flag not between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("update_time is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("update_time is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("update_time =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("update_time <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("update_time >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("update_time >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("update_time <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("update_time <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("update_time in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("update_time not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("update_time between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("update_time not between", value1, value2, "updateTime");
            return (Criteria) this;
        }
    }

    /**
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}