package cn.zjhf.kingold.trade.entity;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by DELL on 2017/5/16.
 */
public class Product implements Serializable{

    /**
     * 自增主键
     */
    private Long productID;
    /**
     * UUID主键
     */
    private String productUuid;
    /**
     * 产品编码
     */
    private String productCode;
    /**
     * 产品类型（PRIF私募基金FIXI固定收益理财）
     */
    private String productType;
    /**
     * 产品名称
     */
    private String productName;
    /**
     * 产品简称
     */
    private String productAbbrName;
    /**
     * 产品发行者UUID（对应issuer表的uuid）
     */
    private String productIssuerUuid;
    /**
     * 产品发行者名称（对应issuer表的user_name）
     */
    private String productIssuerName;
    /**
     * 产品发行者简称（对应issuer表的user_short_name）
     */
    private String productIssuerShortName;
    /**
     * 币种，'CNY'人民币
     */
    private String productCurrency;
    /**
     * 产品状态（1募集中；2已售罄；3已成立；4已到期；5已兑付）
     */
    private Byte productStatus;
    /**
     * 产品上架状态（1未上架；2已上架；3已下架）
     */
    private Byte productOnStatus;
    /**
     * 产品显示顺序
     */
    private Integer productShowOrder;
    /**
     * 产品期限
     */
    private Integer productPeriod;
    /**
     * 产品期限类型： Y(year,年)； M(month,月)； W(week,周)； D(day,自然日)
     */
    private String productPeriodType;
    /**
     * 产品规模
     */
    private BigDecimal productScale;
    /**
     * 产品佣金奖励设置（JSON）
     */
    private String productAward;
    /**
     * 产品附件（JSON）
     */
    private String productAttachment;
    /**
     * 产品上架时间
     */
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    private Date productOpenTime;
    /**
     * 产品下架时间
     */
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    private Date productCloseTime;
    /**
     * 删除标识
     */
    private Byte deleteFlag;
    /**
     * 创建时间
     */
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;
    /**
     * 更新时间
     */
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    private Date updateTime;

    public Long getProductID() {
        return productID;
    }

    public void setProductID(Long productID) {
        this.productID = productID;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductAbbrName() {
        return productAbbrName;
    }

    public void setProductAbbrName(String productAbbrName) {
        this.productAbbrName = productAbbrName;
    }

    public String getProductIssuerUuid() {
        return productIssuerUuid;
    }

    public void setProductIssuerUuid(String productIssuerUuid) {
        this.productIssuerUuid = productIssuerUuid;
    }

    public String getProductIssuerName() {
        return productIssuerName;
    }

    public void setProductIssuerName(String productIssuerName) {
        this.productIssuerName = productIssuerName;
    }

    public String getProductIssuerShortName() {
        return productIssuerShortName;
    }

    public void setProductIssuerShortName(String productIssuerShortName) {
        this.productIssuerShortName = productIssuerShortName;
    }

    public String getProductCurrency() {
        return productCurrency;
    }

    public void setProductCurrency(String productCurrency) {
        this.productCurrency = productCurrency;
    }

    public Byte getProductStatus() {
        if(null != productStatus) {
        return productStatus;
        }else {
            return 0;
        }
    }

    public void setProductStatus(Byte productStatus) {
        this.productStatus = productStatus;
    }

    public Byte getProductOnStatus() {
        return productOnStatus;
    }

    public void setProductOnStatus(Byte productOnStatus) {
        this.productOnStatus = productOnStatus;
    }

    public Integer getProductShowOrder() {
        return productShowOrder;
    }

    public void setProductShowOrder(Integer productShowOrder) {
        this.productShowOrder = productShowOrder;
    }

    public Integer getProductPeriod() {
        return productPeriod;
    }

    public void setProductPeriod(Integer productPeriod) {
        this.productPeriod = productPeriod;
    }

    public String getProductPeriodType() {
        return productPeriodType;
    }

    public void setProductPeriodType(String productPeriodType) {
        this.productPeriodType = productPeriodType;
    }

    public BigDecimal getProductScale() {
        return productScale;
    }

    public void setProductScale(BigDecimal productScale) {
        this.productScale = productScale;
    }

    public String getProductAward() {
        return productAward;
    }

    public void setProductAward(String productAward) {
        this.productAward = productAward;
    }

    public String getProductAttachment() {
        return productAttachment;
    }

    public void setProductAttachment(String productAttachment) {
        this.productAttachment = productAttachment;
    }

    public Date getProductOpenTime() {
        return productOpenTime;
    }

    public void setProductOpenTime(Date productOpenTime) {
        this.productOpenTime = productOpenTime;
    }

    public Date getProductCloseTime() {
        return productCloseTime;
    }

    public void setProductCloseTime(Date productCloseTime) {
        this.productCloseTime = productCloseTime;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}
