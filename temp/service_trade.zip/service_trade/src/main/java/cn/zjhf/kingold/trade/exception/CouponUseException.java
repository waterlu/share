package cn.zjhf.kingold.trade.exception;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.constant.TradeStatusMsg;

/**
 * 优惠券使用异常
 *
 * @author lutiehua
 * @date 2018/3/15
 */
public class CouponUseException extends BusinessException {

    public CouponUseException() {
        super(TradeStatusMsg.CASHCOUPON_EXTENDRECORD_USE_INVALID, TradeStatusMsg.CASHCOUPON_EXTENDRECORD_USE_INVALID_MSG, false);
    }
}
