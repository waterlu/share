package cn.zjhf.kingold.trade.web;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.entity.InVO.CashCouponVO;
import cn.zjhf.kingold.trade.persistence.mq.consumer.OrderPaidConsumer;
import cn.zjhf.kingold.trade.persistence.mq.consumer.UserAuthConsumer;
import cn.zjhf.kingold.trade.persistence.mq.consumer.UserBindCardConsumer;
import cn.zjhf.kingold.trade.persistence.mq.consumer.UserRegisterConsumer;
import cn.zjhf.kingold.trade.persistence.mq.message.OrderPaidMessage;
import cn.zjhf.kingold.trade.persistence.mq.message.UserMessage;
import cn.zjhf.kingold.trade.utils.DataUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by zhangyijie on 2018/1/9.
 */
@RestController
@RequestMapping(value = "/mqtest")
public class MQTestController {
    protected static final Logger LOGGER = LoggerFactory.getLogger(MQTestController.class);

    @Autowired
    OrderPaidConsumer orderPaidConsumer;

    @Autowired
    UserAuthConsumer userAuthConsumer;

    @Autowired
    UserBindCardConsumer userBindCardConsumer;

    @Autowired
    UserRegisterConsumer userRegisterConsumer;

    /**
     * 定期订单认购成功
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/orderPaidProcess", method = RequestMethod.PUT)
    public ResponseResult orderPaidProcess(@RequestBody OrderPaidMessage orderPaidMessage) throws BusinessException {
        LOGGER.info("orderPaidProcess start: " + DataUtils.toString(orderPaidMessage));

        ResponseResult result = orderPaidConsumer.process(orderPaidMessage);

        LOGGER.info("orderPaidProcess end: " + DataUtils.toString(result));
        return result;
    }

    /**
     * 用户实名
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/userAuthProcess", method = RequestMethod.PUT)
    public ResponseResult userAuthProcess(@RequestBody UserMessage userMessage) throws BusinessException {
        LOGGER.info("userAuthProcess start: " + DataUtils.toString(userMessage));

        ResponseResult result = userAuthConsumer.process(userMessage);

        LOGGER.info("userAuthProcess end: " + DataUtils.toString(result));
        return result;
    }

    /**
     * 用户绑卡成功
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/userBindCardProcess", method = RequestMethod.PUT)
    public ResponseResult userBindCardProcess(@RequestBody UserMessage userMessage) throws BusinessException {
        LOGGER.info("userBindCardProcess start: " + DataUtils.toString(userMessage));

        ResponseResult result = userBindCardConsumer.process(userMessage);

        LOGGER.info("userBindCardProcess end: " + DataUtils.toString(result));
        return result;
    }

    /**
     * 用户注册成功
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/userRegisterProcess", method = RequestMethod.PUT)
    public ResponseResult userRegisterProcess(@RequestBody UserMessage userMessage) throws BusinessException {
        LOGGER.info("userRegisterProcess start: " + DataUtils.toString(userMessage));

        ResponseResult result = userRegisterConsumer.process(userMessage);

        LOGGER.info("userRegisterProcess end: " + DataUtils.toString(result));
        return result;
    }
}
