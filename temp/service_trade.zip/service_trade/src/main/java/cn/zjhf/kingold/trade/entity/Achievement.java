package cn.zjhf.kingold.trade.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author 
 */
public class Achievement implements Serializable {
    /**
     * 主键
     */
    private String achievementUuid;

    /**
     *  业绩状态（1有效 0无效）
     */
    private Integer achievementStatus;

    /**
     * 用户UUID
     */
    private String userUuid;

    /**
     * 客户UUID
     */
    private String customerUuid;

    /**
     * 客户手机号码
     */
    private String customerMobile;

    /**
     * 购买产品UUID
     */
    private String productUuid;

    /**
     *  购买产品名称
     */
    private String productName;

    /**
     * 购买产品类型
     */
    private String productType;

    /**
     * 订单号（包括定期和私募）
     */
    private String orderBillCode;

    /**
     * 订单金额
     */
    private BigDecimal orderAmount;

    /**
     * 订单时间
     */
    private Date orderTime;

    private static final long serialVersionUID = 1L;

    public String getAchievementUuid() {
        return achievementUuid;
    }

    public void setAchievementUuid(String achievementUuid) {
        this.achievementUuid = achievementUuid;
    }

    public Integer getAchievementStatus() {
        return achievementStatus;
    }

    public void setAchievementStatus(Integer achievementStatus) {
        this.achievementStatus = achievementStatus;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getCustomerUuid() {
        return customerUuid;
    }

    public void setCustomerUuid(String customerUuid) {
        this.customerUuid = customerUuid;
    }

    public String getCustomerMobile() {
        return customerMobile;
    }

    public void setCustomerMobile(String customerMobile) {
        this.customerMobile = customerMobile;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getOrderBillCode() {
        return orderBillCode;
    }

    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    public BigDecimal getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(BigDecimal orderAmount) {
        this.orderAmount = orderAmount;
    }

    public Date getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(Date orderTime) {
        this.orderTime = orderTime;
    }
}