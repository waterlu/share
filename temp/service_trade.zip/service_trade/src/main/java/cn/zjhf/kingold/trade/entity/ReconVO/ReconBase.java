package cn.zjhf.kingold.trade.entity.ReconVO;

/**
 * Created by zhangyijie on 2017/7/25.
 */
public class ReconBase {
    protected String orderCode;
    protected String investorName;
    protected String investorMobile;
    protected Long accountNo = 0L;

    protected String productAbbrName;
    protected int productTerm;
    protected double profitAmt;

    protected String platformTime;
    protected String baoFooTime;
    protected double platformAmt;
    protected double baoFooAmt;
    protected double platformFeeAmt;
    protected double baoFooFeeAmt;

    protected int platformStatus;
    protected int baoFooStatus;
    protected String errMess;

    //0:新建，1：成功，2：失败, 3:取消
    protected String getStatus(int status) {
        if(0 == status) {
            return "新建";
        }else if(1 == status){
            return "成功";
        }else if(2 == status){
            return "失败";
        }else if(3 == status){
            return "取消";
        }

        return "其他";
    }

    //0:失败，1：成功
    protected String getBaofooStatus(int status) {
        if(1 == status) {
            return "成功";
        }

        return "不成功";
        //return getStatus(status);
    }
}
