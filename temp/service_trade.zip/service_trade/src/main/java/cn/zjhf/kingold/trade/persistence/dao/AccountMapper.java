package cn.zjhf.kingold.trade.persistence.dao;

import cn.zjhf.kingold.trade.dto.BillDto;
import cn.zjhf.kingold.trade.utils.WhereCondition;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
@Mapper
public interface AccountMapper {
    Map get(Map params);

    int insert(Map record);

    int update(Map userInfo);

    int updateByUserUuid(Map param);

    int clearYesterdayProfit();

    int delete(Map params);

    Integer getCount(Map userMap);

    List<Map> getList(Map userMap);

    int recharge(Map userMap);

    Map getByUserId(Map paramMap);

    int invest(Map userMap);

    @Update("UPDATE account SET " +
            "account_freeze_amount = account_freeze_amount - #{inveAmount}, " +
            "account_inve_amount = account_inve_amount + (#{inveAmount} + #{maketAmount}),  " +
            "account_total_assets = (account_cash_amount + account_freeze_amount + account_inve_amount) " +
            "WHERE account_uuid = #{accountUUId}")
    void investorRaiseEnd(@Param("accountUUId") String accountUUId, @Param("inveAmount") double inveAmount, @Param("maketAmount") double maketAmount);

    @Select("SELECT account_uuid FROM account WHERE account_type = #{accountType} AND delete_flag=0 ORDER BY create_time DESC LIMIT 0,1")
    String lstAccountUuidByType(@Param("accountType") String accountType);

    @Update("UPDATE account SET " +
            "account_cash_amount = account_cash_amount + (#{raiseAmt} + #{profitAmount} + #{maketAmount}), " +
            "account_inve_amount = account_inve_amount - #{raiseAmt}, " +
            "account_accum_profit = account_accum_profit + (#{profitAmount} + #{maketAmount}), " +
            "account_paid_profit = account_paid_profit + (#{profitAmount} + #{maketAmount}), " +
            "account_total_assets = (account_cash_amount + account_freeze_amount + account_inve_amount) " +
            "WHERE account_uuid = #{accountUUId}")
    void investorProductEnd(@Param("accountUUId") String accountUUId, @Param("raiseAmt") double raiseAmt, @Param("profitAmount") double profitAmount, @Param("maketAmount") double maketAmount);

    //注意：该方法只更新累计佣金奖励
    @Update("UPDATE account SET " +
            "account_commission = account_commission + #{commissionAmt} " +
            "WHERE account_uuid = #{accountUUId}")
    void investorPaymentReward(@Param("accountUUId") String accountUUId, @Param("commissionAmt") double commissionAmt);

    @Update("UPDATE account SET " +
            "account_cash_amount = account_cash_amount + #{amount}, " +
            "account_total_assets = (account_cash_amount + account_freeze_amount + account_inve_amount) " +
            "WHERE account_uuid = #{accountUUId}")
    void addCashAmount(@Param("accountUUId") String accountUUId, @Param("amount") double amount);

    @Update("UPDATE account SET " +
            "account_cash_amount = account_cash_amount - #{amount}, " +
            "account_total_assets = (account_cash_amount + account_freeze_amount + account_inve_amount) " +
            "WHERE account_uuid = #{accountUUId}")
    void reduceCashAmount(@Param("accountUUId") String accountUUId, @Param("amount") double amount);

    @Update("UPDATE account SET " +
            "account_freeze_amount = account_freeze_amount - #{inveAmount}, " +
            "account_cash_amount = account_cash_amount + #{inveAmount}, " +
            "account_total_assets = (account_cash_amount + account_freeze_amount + account_inve_amount) " +
            "WHERE account_uuid = #{accountUUId}")
    void investorCancelTrade(@Param("accountUUId") String accountUUId, @Param("inveAmount") double inveAmount);

    /**
     * 冻结提款资金
     *
     * @param params
     * @return
     */
    int freezeCash(BillDto params);

    /**
     * 执行凭证（将冻结金额扣除）
     * @param accountParams
     * @return
     */
    int executeBill(Map accountParams);
    /**
     * 取消冻结提款资金
     *
     * @param accountParams
     * @return
     */
    int cancelFreezeCash(Map accountParams);

    /**
     * 付款、收款（付款 amount 负数，收款 amount 正数）
     * 必填参数 amount，accountUuid
     * @param paymentParams
     * @return
     */
    int payment(Map paymentParams);

    /**
     * 募集增款
     *
     * @param paymentParams
     * @return
     */
    int raiseCash(Map paymentParams);

}