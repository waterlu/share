package cn.zjhf.kingold.trade.exception;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.constant.TradeStatusMsg;

/**
 * 产品当前不能购买异常
 *
 * @author lutiehua
 * @date 2018/3/9
 */
public class ProductCannotBuyException extends BusinessException {

    public ProductCannotBuyException() {
        super(TradeStatusMsg.PRODUCT_CONNOT_BUY_CODE, TradeStatusMsg.PRODUCT_CONNOT_BUY_MSG, true);
    }
}
