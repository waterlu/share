package cn.zjhf.kingold.trade.vo;

import cn.zjhf.kingold.trade.entity.InVO.InVOBase;
import com.alibaba.fastjson.annotation.JSONField;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author xiexiaojie
 *         2018/3/22.
 *         产品收支明细报表
 */
public class ProductRewardSummaryReportVO extends InVOBase{

    @ApiModelProperty(required = true, value = "产品奖励记录申请编号,自增ID")
    private Long productRewardSummaryUuid;

    @ApiModelProperty(required = true, value = "产品UUID")
    private String productUuid;

    @ApiModelProperty(required = true, value = "产品简称")
    private String productAbbrName;

    @ApiModelProperty(required = false, value = "产品成立日, 格式为 YYYY-MM-DD")
    private String productEstablishmentDate;

    @ApiModelProperty(required = true, value = "募集方名称")
    private String productIssuerName;

    @ApiModelProperty(required = true, value = "产品期限")
    private Integer productPeriod;

    @ApiModelProperty(required = true, value = "预计年化收益率 仅是用与当前报表显示")
    private BigDecimal annualInterestShow;

    @ApiModelProperty(required = true, value = "产品加息利率")
    private BigDecimal increaseInterestRate;

    @ApiModelProperty(required = true, value = "实际募集金额")
    private BigDecimal productAccumulation;

    @ApiModelProperty(required = true, value = "募集方返还收益")
    private BigDecimal clearProfitAmount;

    @ApiModelProperty(required = true, value = "交易所发行费")
    private BigDecimal exchangeManageFee;

    @ApiModelProperty(required = true, value = "税前平台服务费 平台服务费")
    private BigDecimal pretaxPlatformServicefee;

    @ApiModelProperty(required = true, value = "加息券收益")
    private BigDecimal couponInterestYieldProfit;

    @ApiModelProperty(required = true, value = "产品加息收益")
    private BigDecimal increaseInterestProfit;

    @ApiModelProperty(required = true, value = "税前理顾佣金 邀请/达人奖励")
    private BigDecimal pretaxRewardAmount;

    @ApiModelProperty(required = true, value = "现金券使用总额")
    private BigDecimal marketingAmout;

    public Long getProductRewardSummaryUuid() {
        return productRewardSummaryUuid;
    }

    public void setProductRewardSummaryUuid(Long productRewardSummaryUuid) {
        this.productRewardSummaryUuid = productRewardSummaryUuid;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductAbbrName() {
        return productAbbrName;
    }

    public void setProductAbbrName(String productAbbrName) {
        this.productAbbrName = productAbbrName;
    }

    public String getProductEstablishmentDate() {
        return productEstablishmentDate;
    }

    public void setProductEstablishmentDate(String productEstablishmentDate) {
        this.productEstablishmentDate = productEstablishmentDate;
    }

    public String getProductIssuerName() {
        return productIssuerName;
    }

    public void setProductIssuerName(String productIssuerName) {
        this.productIssuerName = productIssuerName;
    }

    public Integer getProductPeriod() {
        return productPeriod;
    }

    public void setProductPeriod(Integer productPeriod) {
        this.productPeriod = productPeriod;
    }

    public BigDecimal getAnnualInterestShow() {
        return formatRate(annualInterestShow);
    }

    public void setAnnualInterestShow(BigDecimal annualInterestShow) {
        this.annualInterestShow = annualInterestShow;
    }

    public BigDecimal getIncreaseInterestRate() {
        return formatRate(increaseInterestRate);
    }

    public void setIncreaseInterestRate(BigDecimal increaseInterestRate) {
        this.increaseInterestRate = increaseInterestRate;
    }

    public BigDecimal getProductAccumulation() {
        return formatMoney(productAccumulation);
    }

    public void setProductAccumulation(BigDecimal productAccumulation) {
        this.productAccumulation = productAccumulation;
    }

    public BigDecimal getClearProfitAmount() {
        return formatMoney(clearProfitAmount);
    }

    public void setClearProfitAmount(BigDecimal clearProfitAmount) {
        this.clearProfitAmount = clearProfitAmount;
    }

    public BigDecimal getExchangeManageFee() {
        return formatMoney(exchangeManageFee);
    }

    public void setExchangeManageFee(BigDecimal exchangeManageFee) {
        this.exchangeManageFee = exchangeManageFee;
    }

    public BigDecimal getPretaxPlatformServicefee() {
        return formatMoney(pretaxPlatformServicefee);
    }

    public void setPretaxPlatformServicefee(BigDecimal pretaxPlatformServicefee) {
        this.pretaxPlatformServicefee = pretaxPlatformServicefee;
    }

    public BigDecimal getCouponInterestYieldProfit() {
        return formatMoney(couponInterestYieldProfit);
    }

    public void setCouponInterestYieldProfit(BigDecimal couponInterestYieldProfit) {
        this.couponInterestYieldProfit = couponInterestYieldProfit;
    }

    public BigDecimal getIncreaseInterestProfit() {
        return formatMoney(increaseInterestProfit);
    }

    public void setIncreaseInterestProfit(BigDecimal increaseInterestProfit) {
        this.increaseInterestProfit = increaseInterestProfit;
    }

    public BigDecimal getPretaxRewardAmount() {
        return formatMoney(pretaxRewardAmount);
    }

    public void setPretaxRewardAmount(BigDecimal pretaxRewardAmount) {
        this.pretaxRewardAmount = pretaxRewardAmount;
    }

    public BigDecimal getMarketingAmout() {
        return formatMoney(marketingAmout);
    }

    public void setMarketingAmout(BigDecimal marketingAmout) {
        this.marketingAmout = marketingAmout;
    }
}
