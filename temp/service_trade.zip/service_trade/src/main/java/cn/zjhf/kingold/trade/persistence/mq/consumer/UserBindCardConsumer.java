package cn.zjhf.kingold.trade.persistence.mq.consumer;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.rocketmq.annotation.RocketMQConsumer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQConsumer;
import cn.zjhf.kingold.trade.constant.BizDefine;
import cn.zjhf.kingold.trade.constant.MarketCampaignCodeEnum;
import cn.zjhf.kingold.trade.dto.CouponSendConditionDto;
import cn.zjhf.kingold.trade.persistence.dao.OperationReportMapper;
import cn.zjhf.kingold.trade.persistence.mq.message.UserMessage;
import cn.zjhf.kingold.trade.service.IMarketCampaignService;
import cn.zjhf.kingold.trade.service.IUserService;
import cn.zjhf.kingold.trade.utils.DataUtils;
import cn.zjhf.kingold.trade.utils.DateUtil;
import cn.zjhf.kingold.trade.utils.QueryUtils;
import cn.zjhf.kingold.trade.utils.WhereCondition;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;

/**
 * 用户绑卡成功，红包
 * <p>
 * Created by lutiehua on 2017/7/14.
 */
@RocketMQConsumer(topic = "user", tag = "bindCard")
public class UserBindCardConsumer extends AbstractMQConsumer<UserMessage> {

    private final Logger LOGGER = LoggerFactory.getLogger(UserBindCardConsumer.class);

    @Autowired
    private IMarketCampaignService marketCampaignService;

    @Autowired
    private IUserService userService;

    @Autowired
    private OperationReportMapper operationReportMapper;

    /**
     * 检查绑卡时间，只筛选出两小时之内的绑卡用户
     * @param userUuid
     * @return true 近期消息，继续处理；false 远期消息，放弃处理
     */
    private boolean checkBindCardTime(String userUuid) {
        if(DataUtils.isNotEmpty(userUuid)) {
            String sql = "SELECT update_time FROM account_baofoo_custody "
                    + "WHERE account_uuid IN (SELECT account_uuid FROM account WHERE user_uuid="
                    + WhereCondition.toSQLStr(userUuid) + " AND delete_flag=0) "
                    + "AND delete_flag=0 AND bank_card_info IS NOT NULL ORDER BY create_time DESC LIMIT 0,1 ";
            String occuTimeStr = operationReportMapper.lstSingleString(new QueryUtils(sql));

            if(DataUtils.isNotEmpty(occuTimeStr)) {
                Date occuTime = DateUtil.strToTime(occuTimeStr);
                if(occuTime!=null) {
                    int diffTime = (int) (((new Date()).getTime() - occuTime.getTime()) / (1000 * 3600));
                    return diffTime <= 1;
                }
            }
        }

        return false;
    }

    private boolean insertCerLog(int key, String value) {
        int ret = -1;

        try {
            ret = operationReportMapper.insertCerMqLog(key, value);
        }catch(Exception e) {
            LOGGER.error("插入失败", e);
        }

        LOGGER.info("ret: ", ret);
        return ret > 0;
    }

    @Override
    public ResponseResult process(UserMessage userMessage) throws BusinessException {
        LOGGER.info("用户绑卡消息");
        //判断商户号不是金疙瘩不发放优惠券
        if (StringUtils.isNotBlank(userMessage.getMerchantNum()) && !BizDefine.KINGOLD_MERCHANT.equals(userMessage.getMerchantNum())) {
            logger.info("用户绑卡渠道商户号是：{}", userMessage.getMerchantNum());
            return new ResponseResult();
        }

        if(checkBindCardTime(userMessage.getUserUuid())) {
            if(insertCerLog(MarketCampaignCodeEnum.FIRST_BIND_CARD.getCode(), userMessage.getUserUuid())) {
                try {
                    marketCampaignService.marketCampaignTrigger(new CouponSendConditionDto(userMessage.getUserUuid(), MarketCampaignCodeEnum.FIRST_BIND_CARD.getCode(), null, null));
                } catch (BusinessException e) {
                    logger.error("UserBindCardConsumer fail", e);
                }
            }

            String inviterUuid = userService.getInviterUuid(userMessage.getUserUuid());
            if (DataUtils.isNotEmpty(inviterUuid)) {
                if(insertCerLog(MarketCampaignCodeEnum.INVITE_FRIEND_FIRST_BIND_CARD.getCode(), inviterUuid + "&&" + userMessage.getUserUuid())) {
                    logger.info("用户绑卡 . userUuid={}, inviterUuid={}", userMessage.getUserUuid(), inviterUuid);
                    try {
                        marketCampaignService.marketCampaignTrigger(new CouponSendConditionDto(inviterUuid, MarketCampaignCodeEnum.INVITE_FRIEND_FIRST_BIND_CARD.getCode(), null, userMessage.getUserUuid()));
                    } catch (BusinessException e) {
                        logger.error("UserBindCardConsumer fail", e);
                    }
                }
            }
        }
        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        return responseResult;
    }
}