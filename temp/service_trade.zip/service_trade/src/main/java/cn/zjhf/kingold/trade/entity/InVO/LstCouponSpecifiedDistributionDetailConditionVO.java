package cn.zjhf.kingold.trade.entity.InVO;

import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import java.util.Date;

/**
 * Created by zhangyijie on 2017/7/5.
 */
public class LstCouponSpecifiedDistributionDetailConditionVO extends InVOBase {

    @NotEmpty
    @ApiModelProperty(required = true, value = "审核编号")
    private Long auditId;

    @ApiModelProperty(required = true, value = "起始序号")
    private int beginSN;

    @ApiModelProperty(required = true, value = "结束序号")
    private int endSN;

    public int getBeginSN() {
        return beginSN;
    }

    public void setBeginSN(int beginSN) {
        this.beginSN = beginSN;
    }

    public int getEndSN() {
        return endSN;
    }

    public void setEndSN(int endSN) {
        this.endSN = endSN;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(getTraceID()) + ", ");
        sb.append("auditId:" + DataUtils.toString(auditId) + ", ");

        sb.append("beginSN:" + DataUtils.toString(beginSN) + ", ");
        sb.append("endSN:" + DataUtils.toString(endSN));
        return sb.toString();
    }

    public Long getAuditId() {
        if(auditId != null) {
            return auditId;
        }else {
            return 0L;
        }
    }

    public void setAuditId(Long auditId) {
        this.auditId = auditId;
    }
}
