package cn.zjhf.kingold.trade.entity;

import java.io.Serializable;

/**
 * @author 
 */
public class CouponSpecifiedDistributionRecordItem implements Serializable {
    /**
     * 序号
     */
    private Long id;

    /**
     * 审核编号
     */
    private Long auditId;

    /**
     * 用户名/用户手机号
     */
    private String phoneNumber;

    /**
     * 用户姓名
     */
    private String phoneName;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getAuditId() {
        return auditId;
    }

    public void setAuditId(Long auditId) {
        this.auditId = auditId;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getPhoneName() {
        return phoneName;
    }

    public void setPhoneName(String phoneName) {
        this.phoneName = phoneName;
    }
}