package cn.zjhf.kingold.trade.baofoo;

/**
 * Created by lutiehua on 2017/4/27.
 */
public class AuthResponse {
    private String code;

    private String msg;

    private long user_id;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public long getUser_id() {
        return user_id;
    }

    public void setUser_id(long user_id) {
        this.user_id = user_id;
    }
}
