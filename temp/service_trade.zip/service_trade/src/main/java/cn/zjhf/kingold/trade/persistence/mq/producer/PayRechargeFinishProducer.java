package cn.zjhf.kingold.trade.persistence.mq.producer;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.rocketmq.annotation.RocketMQProducer;
import cn.zjhf.kingold.rocketmq.annotation.RocketMQTransactionProducer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQProducer;
import cn.zjhf.kingold.rocketmq.base.AbstractTransactionMQProducer;
import cn.zjhf.kingold.trade.persistence.mq.message.PayRechargeMessage;
import cn.zjhf.kingold.trade.service.IPayService;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 生产充值成功消息 消费完成
 *
 * Created by wangxun
 */
@RocketMQProducer(topic = "pay", tag = "recharge_finish")
public class PayRechargeFinishProducer extends AbstractMQProducer<PayRechargeMessage> {
}