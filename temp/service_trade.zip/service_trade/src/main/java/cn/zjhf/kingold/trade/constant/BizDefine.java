package cn.zjhf.kingold.trade.constant;

import cn.zjhf.kingold.trade.utils.DataUtils;

/**
 * Created by DELL on 2017/5/16.
 */
public class BizDefine {
     // `order_status` tinyint(4) NOT NULL COMMENT '订单状态 1创建，2已付款，3产品成立，4已到期，5已清算，9已撤销',

    public static String getTradeStatusName(int status) {
        switch(status) {
            case ORDER_STATUS_APPLY:
                return "待支付";
            case ORDER_STATUS_CONFIRM:
                return "已支付";
            case ORDER_STATUS_PRODUCT_INTEREST:
                return "计息中";
            case ORDER_STATUS_PRODUCT_END:
                return "已到期";
            case ORDER_STATUS_CLEAR:
                return "已到期兑付";
            case ORDER_STATUS_CANCEL:
                return "已撤销";
            default:
                return "其他";
        }
    }

    /**
     * 订单状态 1交易创建
     */
    public static final int ORDER_STATUS_APPLY  = 1;

    /**
     * 订单状态 2交易已付款
     */
    public static final int ORDER_STATUS_CONFIRM  = 2;

    /**
     * 订单状态 3产品计息中
     */
    public static final int ORDER_STATUS_PRODUCT_INTEREST  = 3;

    /**
     * 订单状态 4产品到期
     */
    public static final int ORDER_STATUS_PRODUCT_END  = 4;

    /**
     * 订单状态 5产品清算
     */
    public static final int ORDER_STATUS_CLEAR  = 5;

    /**
     * 订单状态 9交易撤销
     */
    public static final int ORDER_STATUS_CANCEL  = 9;


    /**
     * 账户状态 1正常
     */
    public static final int ACCOUNT_STATUS_NORMAL  = 1;


    /**
     * 工作流状态 -1审核失败
     */
    public static final Byte WORKFLOW_STATUS_AUDIT_FAIL  = -1;

    /**
     * 工作流状态 1待审核
     */
    public static final Byte WORKFLOW_STATUS_CREATE  = 1;

    /**
     * 工作流状态 2已审核
     */
    public static final Byte WORKFLOW_STATUS_AUDITED  = 2;

    /**
     * 工作流状态 3已兑付
     */
    public static final Byte WORKFLOW_STATUS_CLEAR  = 3;

    /**
     * 工作流状态 9进行中
     */
    public static final Byte WORKFLOW_STATUS_ING  = 9;


    /**
     * 宝付账户类型 12平台结算账户
     */
    public static final String ACCOUNT_TYPE_ZJ_CLEAR  = "12";

    /**
     * 宝付账户类型 11平台托管账户
     */
    public static final String ACCOUNT_TYPE_ZJ_DEPOSIT  = "11";

    /**
     * 宝付账户类型 21投资者托管账户
     */
    public static final String ACCOUNT_TYPE_INVESTOR  = "21";

    /**
     * 宝付账户类型 31融资人宝付托管账户
     */
    public static final String ACCOUNT_TYPE_ZJ_FINANCIER_DEPOSIT  = "31";

    public static String getProductStatusName(int status) {
        switch(status) {
            case PRODUCT_STATUS_UNCONFIRMED:
                return "待确认";
            case PRODUCT_STATUS_PREHEAT:
                return "预热中";
            case PRODUCT_STATUS_RAISE:
                return "募集中";
            case PRODUCT_STATUS_ENDRAISE:
                return "已售罄";
            case PRODUCT_STATUS_ESTABLISH:
                return "已成立";
            case PRODUCT_STATUS_LOAN:
                return "已放款";
            case PRODUCT_STATUS_INTEREST:
                return "计息中";
            case PRODUCT_PRIVATE_STATUS_CLOSED_PERIOD:
                return "封闭期";
            case PRODUCT_PRIVATE_STATUS_DURATION:
                return "存续期";
            case PRODUCT_PRIVATE_STATUS_PRODUCTEND:
                return "已结束";
            case PRODUCT_STATUS_PRODUCTEND:
                return "已到期";
            case PRODUCT_STATUS_CLEAR:
                return "已兑付";
            case PRODUCT_STATUS_ABORT:
                return "已作废";
            default:
                return "其他";
        }
    }

    /**
     * 产品状态 0待确认
     */
    public static final int PRODUCT_STATUS_UNCONFIRMED = 0;

    /**
     * 产品状态 1预热中
     */
    public static final int PRODUCT_STATUS_PREHEAT  = 1;

    /**
     * 产品状态 2募集中
     */
    public static final int PRODUCT_STATUS_RAISE = 2;

    /**
     * 产品状态 3已售罄
     */
    public static final int PRODUCT_STATUS_ENDRAISE = 3;

    /**
     * 产品状态 4已成立
     */
    public static final int PRODUCT_STATUS_ESTABLISH = 4;

    /**
     * 产品状态 5已放款
     */
    public static final int PRODUCT_STATUS_LOAN = 5;

    /**
     * 产品状态 6计息中
     */
    public static final int PRODUCT_STATUS_INTEREST = 6;

    /**
     * 产品状态 15封闭期
     */
    public static final int PRODUCT_PRIVATE_STATUS_CLOSED_PERIOD = 15;

    /**
     * 产品状态 16存续期
     */
    public static final int PRODUCT_PRIVATE_STATUS_DURATION = 16;

    /**
     * 产品状态 17已结束
     */
    public static final int PRODUCT_PRIVATE_STATUS_PRODUCTEND = 17;

    /**
     * 产品状态 8已到期
     */
    public static final int PRODUCT_STATUS_PRODUCTEND = 8;

    /**
     * 产品状态 9已兑付
     */
    public static final int PRODUCT_STATUS_CLEAR = 9;

    /**
     * 产品状态 21已作废
     */
    public static final int PRODUCT_STATUS_ABORT = 21;


    /**
     * 产品上架状态 1未上架
     */
    public static final int PRODUCT_SHELVES_STATUS_INIT = 1;

    /**
     * 产品上架状态 2已上架
     */
    public static final int PRODUCT_SHELVES_STATUS_ON = 2;

    /**
     * 产品上架状态 3已下架
     */
    public static final int PRODUCT_SHELVES_STATUS_OFF = 3;


    /**
     * 产品变更类型 3产品上下架
     */
    public static final int PRODUCT_CHANGE_TYPE_SHELVES = 3;

    /**
     * 产品变更类型 4状态变更
     */
    public static final int PRODUCT_CHANGE_TYPE_STATUS = 4;

    /**
     * 产品变更类型 5更新募集金额
     */
    public static final int PRODUCT_CHANGE_TYPE_RAISEAMOUNT = 5;

    /**
     * 未上架
     */
    public static final int PRODUCT_SHELVES_INIT = 1;

    /**
     * 产品上架
     */
    public static final int PRODUCT_SHELVES_ON = 2;

    /**
     * 产品下架
     */
    public static final int PRODUCT_SHELVES_OFF = 3;

    /**
     * 默认(系统)操作人
     */
    public static final String DEFAULT_OPERATOR = "system";

    /**
     * 转换产品类型
     */
    public static String convertProductType(String productType) {
        if(DataUtils.isNotEmpty(productType)) {
            if (productType.equals(ProductType.PRODUCT_FT)) {
                productType = "固定收益类";
            } else if (productType.equals(ProductType.PRODUCT_PF)) {
                productType = "私募产品";
            }
        }

        return "其他";
    }


    public static final String KINGOLD_MERCHANT = "00000";
}
