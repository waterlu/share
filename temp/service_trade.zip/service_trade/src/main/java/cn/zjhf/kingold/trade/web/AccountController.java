package cn.zjhf.kingold.trade.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.constant.AccountStatusMsg;
import cn.zjhf.kingold.trade.entity.TradeOrder;
import cn.zjhf.kingold.trade.entity.ProfitEverydayRecord;
import cn.zjhf.kingold.trade.service.IAccountService;
import cn.zjhf.kingold.trade.service.IAccountTransactionService;
import cn.zjhf.kingold.trade.utils.DataUtils;
import cn.zjhf.kingold.trade.utils.MapParamUtils;
import cn.zjhf.kingold.trade.utils.PropertyDescriptionUtils;
import cn.zjhf.kingold.trade.utils.RequestMapperConvert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Created by lu on 2017/3/13.
 */
@RestController
@RequestMapping(value = "/account")
public class AccountController {

    protected static final Logger logger = LoggerFactory.getLogger(AccountController.class);


    @Autowired
    private IAccountTransactionService accountTransactionService;

    @Autowired
    private IAccountService accountService;

//    /**
//     * 充值
//     * @return
//     * @throws BusinessException
//     */
//    @RequestMapping(value = "/recharge", method = RequestMethod.PUT)
//    public ResponseResult recharge( @RequestBody Map userMap) throws BusinessException {
//        logger.info("recharge start: " + DataUtils.toString(userMap));
//        RequestMapperConvert.initParam(userMap);
//
//        int num = accountService.recharge(userMap);
//        if(num == 0){
//            throw new BusinessException(AccountStatusMsg.ACCOUNT_NOT_EXIST_CODE, AccountStatusMsg.ACCOUNT_NOT_EXIST,true);
//        }
//
//        logger.info("recharge end: " + DataUtils.toString(userMap.get("traceID")));
//        return  new ResponseResult( MapParamUtils.getStringInMap( userMap,"traceID"), ResponseCode.REQUEST_SUCCESS,"成功");
//    }

    /**
     * 投资 orderCode,accountUuid，transactionAmount（负数）
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/invest", method = RequestMethod.PUT)
    public ResponseResult invest( @RequestBody Map userMap) throws BusinessException {
        logger.info("invest start: " + DataUtils.toString(userMap));
        RequestMapperConvert.initParam(userMap);

        int num = accountService.invest(userMap);
        if(num == 0){
            throw new BusinessException(AccountStatusMsg.ACCOUNT_NOT_EXIST_CODE, AccountStatusMsg.ACCOUNT_NOT_EXIST,true);
        }

        logger.info("invest end: " + DataUtils.toString(userMap.get("traceID")));
        return  new ResponseResult( MapParamUtils.getStringInMap( userMap,"traceID"), ResponseCode.REQUEST_SUCCESS,"成功");
    }
    /**
     *
     * 根据userId 查找
    * @param
    * @return
    * @throws BusinessException
    */
    @RequestMapping(value = "", method = RequestMethod.GET)
    public ResponseResult getByUserId(@RequestParam Map paramMap) throws BusinessException {
        logger.info("getByUserId start: " + DataUtils.toString(paramMap));
        RequestMapperConvert.initParam(paramMap);

        Map ui = accountService.getByUserId(paramMap);
        Map resultMap = PropertyDescriptionUtils.convertProperty(ui, (String) paramMap.get("properties"), (String) paramMap.get("desc"), PropertyDescriptionUtils.ACCOUNT_DIC);

        logger.info("getByUserId end: " + DataUtils.toString(paramMap.get("traceID"), resultMap));
        return new ResponseResult( MapParamUtils.getStringInMap( paramMap,"traceID"),ResponseCode.REQUEST_SUCCESS,"成功",resultMap);
    }

    /**
     * 查找
     * @param uuid
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/{uuid}", method = RequestMethod.GET)
    public ResponseResult getWithFilter(@PathVariable("uuid") String uuid,@RequestParam Map paramMap) throws BusinessException {
        logger.info("getWithFilter start: " + DataUtils.toString(uuid, paramMap));
        RequestMapperConvert.initParam(paramMap);

        paramMap.put("accountUuid",uuid);
        Map ui = accountService.getWithFilter(paramMap);
        Map resultMap = PropertyDescriptionUtils.convertProperty(ui, (String) paramMap.get("properties"), (String) paramMap.get("desc"), PropertyDescriptionUtils.ACCOUNT_DIC);

        logger.info("getWithFilter end: " + DataUtils.toString(paramMap.get("traceID"), resultMap));
        return new ResponseResult( MapParamUtils.getStringInMap( paramMap,"traceID"),ResponseCode.REQUEST_SUCCESS,"成功",resultMap);
    }

    /**
     * 获取用户特定账户
     *
     * @param accountType 11平台托管账户；12平台结算账户；41宝付清算账户',
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/getSysAccountByType/{accountType}", method = RequestMethod.GET)
    public ResponseResult getWithFilter(@PathVariable("accountType") String accountType) throws BusinessException {
        Map ui = accountService.getSysAccountByType(accountType);

        return new ResponseResult(UUID.randomUUID().toString(),ResponseCode.REQUEST_SUCCESS,"成功",ui);
    }

    /**
     * 获取用户账户资产结构
     *
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/assetStruct/{userUuid}", method = RequestMethod.GET)
    public ResponseResult getAccountAssets(@PathVariable("userUuid") String userUuid, @RequestParam Map paramMap) throws BusinessException {
        logger.info("assetStruct start. userUuid={}.", userUuid);
        paramMap.put("userUuid", userUuid);
        Map ui = accountService.getAccountAssets(paramMap);
        if(ui == null || ui.isEmpty()){
            throw new BusinessException(AccountStatusMsg.REQUEST_PARAM_ERROR_CODE, AccountStatusMsg.REQUEST_PARAM_ERROR,true);
        }
        Map resultMap = PropertyDescriptionUtils.convertProperty(ui, MapParamUtils.getStringInMap( paramMap,"properties"), MapParamUtils.getStringInMap( paramMap,"desc"),PropertyDescriptionUtils.ACCOUNT_AND_BAOFOO_DIC);
        return new ResponseResult( MapParamUtils.getStringInMap( paramMap,"traceID"),ResponseCode.REQUEST_SUCCESS,"成功",resultMap);
    }

    /**
     * 每日收益统计列表
     * @param userUuid
     * @param paramMap
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/profit/collection/{userUuid}", method = RequestMethod.GET)
    public ResponseResult everydayProfitList(@PathVariable("userUuid") String userUuid,
                                              @RequestParam(value = "startRow", defaultValue = "0") Integer startRow,
                                              @RequestParam(value = "pageSize", defaultValue = "20") Integer pageSize,
                                              @RequestParam Map paramMap) throws BusinessException {
        logger.info("profit collection list start.");
        List<ProfitEverydayRecord> result = accountService.profitCollection(userUuid, startRow, pageSize);
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("list", result);
        resultMap.put("count", accountService.profitCollectionCount(userUuid));
        return new ResponseResult(MapParamUtils.getStringInMap( paramMap,"traceID"),ResponseCode.REQUEST_SUCCESS,"成功", resultMap);
    }

    /**
     * 兑付收益统计列表
     * @param userUuid
     * @param paramMap
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/profit/paid/collection/{userUuid}", method = RequestMethod.GET)
    public ResponseResult getPaidProfitList(@PathVariable("userUuid") String userUuid,
                                              @RequestParam(value = "startRow", defaultValue = "0") Integer startRow,
                                              @RequestParam(value = "pageSize", defaultValue = "20") Integer pageSize,
                                              @RequestParam Map paramMap) throws BusinessException {
        logger.info("profit paid collection list start.");
        List<ProfitEverydayRecord> result = accountService.profitPaidList(userUuid, startRow, pageSize);
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("list", result);
        resultMap.put("count", 0);
        return new ResponseResult(MapParamUtils.getStringInMap( paramMap,"traceID"),ResponseCode.REQUEST_SUCCESS,"成功", resultMap);
    }


    /**
     * 定时计算昨日收益
     *
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/yesterday/profit", method = RequestMethod.GET)
    public ResponseResult yesterdayProfit() throws BusinessException {
        logger.info("yesterday profit start.");
        accountService.yesterdayProfit();
        return new ResponseResult(UUID.randomUUID().toString(),ResponseCode.REQUEST_SUCCESS,"成功");
    }

    /**
     * 投资扣款
     *
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/{accountUuid}/invest", method = RequestMethod.POST)
    public ResponseResult doInvest(@PathVariable("accountUuid") String accountUuid,
                                   @RequestBody TradeOrder order) throws BusinessException {
        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        responseResult.setData(accountService.invest(order));
        return responseResult;
    }
    /**
     * 读取平台账户余额
     *
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/platformAccountBalance", method = RequestMethod.GET)
    public ResponseResult getPlatformAccountBalance() throws BusinessException {
        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        responseResult.setData(accountService.getPlatformAccountBalance());
        return responseResult;
    }

}
