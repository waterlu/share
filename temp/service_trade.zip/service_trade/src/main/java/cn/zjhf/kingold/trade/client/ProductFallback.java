package cn.zjhf.kingold.trade.client;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.utils.MapParamUtils;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * @Author xiaody
 * @Description
 * @Date create in 17/11/8
 */
@Component
public class ProductFallback implements ProductClient{

    int code = 503;

    String message = "服务暂时不可用，请稍后再试";

    @Override
    public ResponseResult insert(Map params) throws BusinessException {
        return new ResponseResult(MapParamUtils.getStringInMap(params,"traceID"), code, message);
    }

    @Override
    public ResponseResult get(String productUuid, Map params) throws BusinessException {
        return new ResponseResult(MapParamUtils.getStringInMap(params,"traceID"), code, message);
    }

    @Override
    public ResponseResult update(String productUuid, Map params) throws BusinessException {
        return new ResponseResult(MapParamUtils.getStringInMap(params,"traceID"), code, message);
    }

    @Override
    public ResponseResult top(String productUuid, Map params) throws BusinessException {
        return new ResponseResult(MapParamUtils.getStringInMap(params,"traceID"), code, message);
    }

    @Override
    public ResponseResult lstByCondition(Map<String, Object> params) throws BusinessException {
        return new ResponseResult(MapParamUtils.getStringInMap(params,"traceID"), code, message);
    }

    @Override
    public ResponseResult getList(Map params) throws BusinessException {
        return new ResponseResult(MapParamUtils.getStringInMap(params,"traceID"), code, message);
    }

    @Override
    public ResponseResult count(Map params) throws BusinessException {
        return new ResponseResult(MapParamUtils.getStringInMap(params,"traceID"), code, message);
    }

    @Override
    public ResponseResult channelNonExistProductList(Map params) throws BusinessException {
        return new ResponseResult(MapParamUtils.getStringInMap(params,"traceID"), code, message);
    }

    @Override
    public ResponseResult channelNonExistProductCount(Map params) throws BusinessException {
        return new ResponseResult(MapParamUtils.getStringInMap(params,"traceID"), code, message);
    }

    @Override
    public ResponseResult getPrivateFund(String productUuid, Map params) throws BusinessException {
        return new ResponseResult(MapParamUtils.getStringInMap(params,"traceID"), code, message);
    }

    @Override
    public ResponseResult getFixedIncome(String productUuid, Map params) throws BusinessException {
        return new ResponseResult(MapParamUtils.getStringInMap(params,"traceID"), code, message);
    }

    @Override
    public ResponseResult getFixedIncomeChannel(Map params) throws BusinessException {
        return new ResponseResult(MapParamUtils.getStringInMap(params,"traceID"), code, message);
    }

    @Override
    public ResponseResult updateAccumulation(Map params) throws BusinessException {
        return new ResponseResult(MapParamUtils.getStringInMap(params,"traceID"), code, message);
    }

    @Override
    public ResponseResult getPrivateFundList(Map params) throws BusinessException {
        return new ResponseResult(MapParamUtils.getStringInMap(params,"traceID"), code, message);
    }

    @Override
    public ResponseResult privateFundCount(Map params) throws BusinessException {
        return new ResponseResult(MapParamUtils.getStringInMap(params,"traceID"), code, message);
    }

    @Override
    public ResponseResult getFixedIncomeList(Map params) throws BusinessException {
        return new ResponseResult(MapParamUtils.getStringInMap(params,"traceID"), code, message);
    }

    @Override
    public ResponseResult fixedIncomeCount(Map params) throws BusinessException {
        return new ResponseResult(MapParamUtils.getStringInMap(params,"traceID"), code, message);
    }

    @Override
    public ResponseResult rewardList(Map params) throws BusinessException {
        return new ResponseResult(MapParamUtils.getStringInMap(params,"traceID"), code, message);
    }

    @Override
    public ResponseResult rewardCount(Map params) throws BusinessException {
        return new ResponseResult(MapParamUtils.getStringInMap(params,"traceID"), code, message);
    }

    @Override
    public ResponseResult addProductChannelRelational(ProductChannelRelationalVO productChannelRelationalVO) throws BusinessException {
        return new ResponseResult(productChannelRelationalVO.getTraceID(), code, message);
    }

    @Override
    public ResponseResult lstProductChannelRelationals(Map<String, Object> param) throws BusinessException {
        return new ResponseResult(MapParamUtils.getStringInMap(param,"traceID"), code, message);
    }

    @Override
    public ResponseResult getDescriptionCode(String productUuid, Map params) throws BusinessException {
        return new ResponseResult(MapParamUtils.getStringInMap(params,"traceID"), code, message);
    }

    @Override
    public ResponseResult getFixedProducts(Map params) throws BusinessException {
        return new ResponseResult(MapParamUtils.getStringInMap(params,"traceID"), code, message);
    }

    /**
     * 更新产品剩余募集金额
     *
     * @param uuid
     * @param param
     * @return
     * @throws BusinessException
     */
    @Override
    public ResponseResult updateRaise(String uuid, ProductRemainDTO param) throws BusinessException {
        return new ResponseResult(param.getTraceID(), code, message);
    }
}
