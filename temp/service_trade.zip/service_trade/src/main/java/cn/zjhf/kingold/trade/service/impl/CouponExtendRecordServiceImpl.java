package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.constant.BizDefine;
import cn.zjhf.kingold.trade.constant.MarketCampaignCodeEnum;
import cn.zjhf.kingold.trade.constant.TradeStatusMsg;
import cn.zjhf.kingold.trade.dto.CouponSendConditionDto;
import cn.zjhf.kingold.trade.entity.*;
import cn.zjhf.kingold.trade.entity.InVO.*;
import cn.zjhf.kingold.trade.entity.OutVO.CouponExtendRecordItemListVO;
import cn.zjhf.kingold.trade.entity.OutVO.CouponSpecifiedDistributionRecordItemDetailVO;
import cn.zjhf.kingold.trade.entity.OutVO.CouponSpecifiedDistributionRecordItemListVO;
import cn.zjhf.kingold.trade.persistence.dao.CouponExtendRecordMapper;
import cn.zjhf.kingold.trade.persistence.dao.CouponSpecifiedDistributionRecordItemMapper;
import cn.zjhf.kingold.trade.persistence.dao.CouponSpecifiedDistributionRecordMapper;
import cn.zjhf.kingold.trade.persistence.mq.message.CouponMessage;
import cn.zjhf.kingold.trade.persistence.mq.producer.CouponSendProducer;
import cn.zjhf.kingold.trade.service.ICashCouponService;
import cn.zjhf.kingold.trade.service.ICouponExtendRecordService;
import cn.zjhf.kingold.trade.service.IMarketCampaignService;
import cn.zjhf.kingold.trade.service.ISequenceService;
import cn.zjhf.kingold.trade.task.BatchSetUnreadMessageTask;
import cn.zjhf.kingold.trade.utils.*;
import cn.zjhf.kingold.trade.utils.Tuple.TwoTuple;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * Created by zhangyijie on 2017/7/5.
 */
@Service
public class CouponExtendRecordServiceImpl extends ProductClearBase implements ICouponExtendRecordService {
    protected static final Logger logger = LoggerFactory.getLogger(CouponExtendRecordServiceImpl.class);

    /**
     * 分享:可发放礼券数量
     */
    @Value("${share.count}")
    private Integer SHARE_COUNT;

    private final static String SHARE_COUNT_KEY="share_record_count";

    private final static String COUPON_SPECIFIED_DISTRIBUTION_KEY = "coupon_specified_distribution_";

    //代金券状态：1已发放
    public static final int STATUS_EXTEND = 1;

    //代金券状态：2已使用
    public static final int STATUS_USED = 2;

    //代金券状态：3已过期
    public static final int STATUS_EXPIRED = 3;

    //代金券状态：4已废弃
    public static final int STATUS_OBSOLETE = 4;


    //不限制产品期限
    public static final int APPLY_PRODUCT_TERM_NO = 1;

    //限制产品期限
    public static final int APPLY_PRODUCT_TERM_YES = 2;


    //不限制子产品(不指定产品列表)
    public static final int APPLY_PRODUCTUUIDS_NO = 1;

    //限制产品子产品(指定产品列表)
    public static final int APPLY_PRODUCTUUIDS_YES = 2;

    /**
     * 指定发放类型，礼券
     */
    public static final int SPECIFIED_TYPE_CASH_COUPON = 1;

    @Autowired
    protected IMarketCampaignService marketCampaignService;

    @Autowired
    protected CouponExtendRecordMapper couponExtendRecordMapper;

    @Autowired
    protected CouponSpecifiedDistributionRecordMapper couponSpecifiedDistributionRecordMapper;

    @Autowired
    protected CouponSpecifiedDistributionRecordItemMapper couponSpecifiedDistributionRecordItemMapper;

    @Autowired
    private ICashCouponService cashCouponService;

    @Autowired
    private ProductClearBase productClearBase;

    @Autowired
    private ISequenceService sequenceService;

    @Autowired
    private CouponSendProducer couponSendProducer;

    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Autowired
    private BatchSetUnreadMessageTask batchSetUnreadMessageTask;

    //间隔符
    static final String REGEXSTR = "\\|";

    /**
     * 记录礼券发放
     * @param userInfo
     * @param marketCampaignVO
     * @param creater
     * @param conditionDto
     * @return
     * @throws BusinessException
     */
    private TwoTuple<Integer, String> establishCouponExtendRecordEx(UserInfo userInfo, MarketCampaignVO marketCampaignVO, String creater, CouponSendConditionDto conditionDto) throws BusinessException {
        //遍历现金券
        Integer recordCouont = 0;
        List<String> cashCouponCodes = DataUtils.split(marketCampaignVO.getApplyCashCoupon());
        BigDecimal couponTotal = new BigDecimal(0);
        long endTime = Long.MAX_VALUE;
        Date endDate = null;
        Set<Integer> couponTypeSet = new HashSet<>();
        for (String cashCouponCode : cashCouponCodes) {
            cashCouponCode = cashCouponCode.trim();
            if (DataUtils.isNotEmpty(cashCouponCode)) {
                CashCoupon cashCoupon = cashCouponService.lstValidCashCoupon(cashCouponCode);
                if (cashCoupon != null) {
                    CouponExtendRecord couponExtendRecord = new CouponExtendRecord();
                    couponExtendRecord.setApplyScene(new Integer(marketCampaignVO.getApplyScene()).byteValue());
                    //获取金币兑换礼券编码，不是金币兑换生成新的编码
                    String couponExtendRecordNo = conditionDto.getCouponExtendCode();
                    if (DataUtils.isEmpty(couponExtendRecordNo)){
                        couponExtendRecordNo = sequenceService.getCouponExtendRecordNo(couponExtendRecordMapper);
                    }
                    logger.info(couponExtendRecordNo);
                    couponExtendRecord.setCouponExtendCode(couponExtendRecordNo);
                    couponExtendRecord.setCouponCode(cashCoupon.getCcCode());
                    couponExtendRecord.setCouponType(cashCoupon.getCcType());
                    couponExtendRecord.setCouponFaceValue(cashCoupon.getFaceValue());
                    couponExtendRecord.setCouponInterestYieldRate(cashCoupon.getInterestYieldRate());
                    couponExtendRecord.setCouponInterestYieldPeriod(cashCoupon.getInterestYieldPeriod());
                    couponExtendRecord.setCouponInterestYieldType(cashCoupon.getInterestYieldType());
                    //有效时间处理
                    if (cashCoupon.getValidTermType() == CashCouponServiceImpl.VALID_TIME_TYPE_TERM) {
                        couponExtendRecord.setValidStartTime(cashCoupon.getValidStartTime());
                        couponExtendRecord.setValidEndTime(cashCoupon.getValidEndTime());
                    } else if (cashCoupon.getValidTermType() == CashCouponServiceImpl.VALID_TERM_TYPE_LENGTH) {
                        Date curDate = new Date();
                        couponExtendRecord.setValidStartTime(curDate);
                        if (cashCoupon.getValidTermUnit() == CashCouponServiceImpl.TIME_UNIT_DAY) {
                            couponExtendRecord.setValidEndTime(StringOrDate.dateOffsetDay(curDate, cashCoupon.getValidTermQuantity()));
                        } else if (cashCoupon.getValidTermUnit() == CashCouponServiceImpl.TIME_UNIT_MONTH) {
                            couponExtendRecord.setValidEndTime(StringOrDate.addMonth(curDate, cashCoupon.getValidTermQuantity()));
                        } else if (cashCoupon.getValidTermUnit() == CashCouponServiceImpl.TIME_UNIT_YEAR) {
                            couponExtendRecord.setValidEndTime(StringOrDate.addYear(curDate, cashCoupon.getValidTermQuantity()));
                        }
                    }
                    couponExtendRecord.setCouponStatus(new Integer(STATUS_EXTEND).byteValue());
                    couponExtendRecord.setUserUuid(userInfo.getUserUuid());
                    couponExtendRecord.setUserPhoneNumber(userInfo.getInvestorMobile());
                    couponExtendRecord.setUserName(userInfo.getInvestorRealName());
                    if(DataUtils.isNotEmpty(conditionDto.getInvitedUserUuid())){
                        couponExtendRecord.setInvitedUserUuid(conditionDto.getInvitedUserUuid());
                    }
                    couponExtendRecord.setCreateTime(new Date());
                    couponExtendRecord.setUpdateTime(new Date());
                    couponExtendRecord.setDeleteFlag(new Byte("0"));

                    creater = DataUtils.isNotEmpty(creater) ? creater : BizDefine.DEFAULT_OPERATOR;
                    couponExtendRecord.setUpdateUserId(creater);

                    couponTotal = couponTotal.add(cashCoupon.getFaceValue());
                    if (endTime > couponExtendRecord.getValidEndTime().getTime()) {
                        endTime = couponExtendRecord.getValidEndTime().getTime();
                        endDate = couponExtendRecord.getValidEndTime();
                    }
                    couponTypeSet.add(Integer.valueOf(cashCoupon.getCcType()));
                    recordCouont += couponExtendRecordMapper.insert(couponExtendRecord);
                } else {
                    logger.error(cashCouponCode + "批次无效或为空");
                }
            }
        }
        if(recordCouont > 0 && marketCampaignVO.getApplyScene() == MarketCampaignCodeEnum.SHARE.getCode()){
            if(getRecordShareCount(userInfo,marketCampaignVO) == 0){
                recordShareCount(userInfo,marketCampaignVO,1);
            }else if(getRecordShareCount(userInfo,marketCampaignVO) > 0){
                updateRecordShareCount(userInfo,marketCampaignVO);
            }
        }
        Integer applyScene = new Integer(marketCampaignVO.getApplyScene());
        CouponMessage couponMessage = new CouponMessage();
        couponMessage.setInvestorMobile(userInfo.getInvestorMobile());
        couponMessage.setOrderBillCode(conditionDto.getOrderBillCode());
        couponMessage.setApplyScene(applyScene);
        couponMessage.setUserUuid(userInfo.getUserUuid());
        couponMessage.setCouponFaceValue(couponTotal);
        couponMessage.setCouponTypeSet(couponTypeSet);
        couponMessage.setValidEndTime(endDate);
        couponMessage.setValidStartTime(new Date());
        couponMessage.setNewFlag(true);
        if (MarketCampaignCodeEnum.BEING_INVITED_REGISTER.getCode().equals(applyScene)||
                MarketCampaignCodeEnum.INVITE_FRIEND_REAL_NAME.getCode().equals(applyScene)||
                MarketCampaignCodeEnum.INVITE_FRIEND_FIRST_BIND_CARD.getCode().equals(applyScene)) {
            if (StringUtils.isNotEmpty(conditionDto.getInvitedUserUuid())) {
                UserInfo inviteUserInfo = getUserInfo(conditionDto.getInvitedUserUuid());
                couponMessage.setBeInviteMobile(inviteUserInfo.getInvestorMobile());
            }
        }
        couponSendProducer.send(couponMessage);
        return new TwoTuple<Integer, String>(1, "成功");
    }

    /**
     * 创建现金券发放记表
     * @param marketCampaignVO
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public TwoTuple<Integer, String> establishCouponExtendRecord(CouponSendConditionDto conditionDto,MarketCampaignVO marketCampaignVO) throws BusinessException {
        UserInfo userInfo = getUserInfo(conditionDto.getUserUuid());
        if ((userInfo == null)) {
            return new TwoTuple<Integer, String>(1, "成功");
        }
        logger.info(DataUtils.toString(userInfo));
        return establishCouponExtendRecordEx(userInfo, marketCampaignVO, BizDefine.DEFAULT_OPERATOR, conditionDto);
    }

    /**
     * 作废发放给投资者的现金券
     *
     * @param abolishCouponExtendRecordVO
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void abolishCouponExtendRecord(CommCouponUpdateVO abolishCouponExtendRecordVO) throws BusinessException {
        CouponExtendRecordVO couponExtendRecordVO = lstCouponExtendRecord(abolishCouponExtendRecordVO.getCommCode());
        if ((int) couponExtendRecordVO.getCouponStatus() == STATUS_EXTEND) {
            couponExtendRecordMapper.abolishRecord(abolishCouponExtendRecordVO.getCommCode(),
                    abolishCouponExtendRecordVO.getUpdateUserId(),
                    abolishCouponExtendRecordVO.getUpdateRemark(), STATUS_OBSOLETE);
        } else {
            throw new BusinessException(TradeStatusMsg.CASHCOUPON_EXTENDRECORD_ABOLISH_ERR,
                    TradeStatusMsg.CASHCOUPON_EXTENDRECORD_ABOLISH_ERR_MSG, false);
        }
    }

    /**
     * 查询现金券发放记录
     *
     * @param lstCondition
     * @return
     * @throws BusinessException
     */
    @Override
    public CouponExtendRecordItemListVO lstCouponExtendRecord(LstCouponExtendRecordConditionVO lstCondition) throws BusinessException {
        CouponExtendRecordItemListVO recordItemList = new CouponExtendRecordItemListVO();
        WhereCondition where = new WhereCondition();
        where.setCondi("coupon_extend_code", lstCondition.getCouponExtendCode(), true);
        where.setCondi("coupon_code", lstCondition.getCouponCode(), true);
        where.setCondi("user_phone_number", lstCondition.getUserPhoneNumber(), true);
        where.setCondi("coupon_status", lstCondition.getCouponStatus(), true);
        where.setCondi("coupon_type", lstCondition.getCouponType(), true);
        where.setBetween("create_time", lstCondition.getBeginDate(), lstCondition.getEndDate());
        recordItemList.setTotalCount(couponExtendRecordMapper.lstCountByCondition(where));

        where.setPage(lstCondition.getBeginSN(), lstCondition.getEndSN(), "create_time");
        recordItemList.setItemsEx(couponExtendRecordMapper.lstByCondition(where));
        return recordItemList;
    }

    /**
     * 获取剩余时间
     *
     * @param endDate
     * @return
     */
    private String getRemainTime(Date endDate) {
        if (null == endDate) {
            return "";
        }

        Date curTime = new Date();
        long diff = endDate.getTime() - curTime.getTime();
        if (diff <= 0) {
            return null;
        }

        long days = diff / (1000 * 60 * 60 * 24);
        if (days > 1) {
            return days + "天";
        }

        long hours = diff / (1000 * 60 * 60);
        if (hours > 1) {
            return hours + "小时";
        }

        long minutes = diff / (1000 * 60);
        return minutes + "分";
    }

    /**
     * 查询优惠券发放记录，投资者查询自己的现金券列表
     *
     * @param userPhoneNumber
     * @param couponType
     * @return
     * @throws BusinessException
     */
    @Override
    public List<CouponExtendRecordVO> lstCouponExtendRecord(String userPhoneNumber, int couponType) throws BusinessException {
        List<CouponExtendRecordVO> itemList = new ArrayList<CouponExtendRecordVO>();
        WhereCondition where = new WhereCondition();
        where.setCondi("user_phone_number", userPhoneNumber, true);
        where.setCondi("coupon_type", couponType, true);
        where.setCondiEx("ORDER BY coupon_status ASC, valid_end_time ASC");

        List<CouponExtendRecord> couponExtendRecords = couponExtendRecordMapper.lstByCondition(where);
        for (CouponExtendRecord couponExtendRecord : couponExtendRecords) {
            CouponExtendRecordVO couponExtendRecordVO = new CouponExtendRecordVO(couponExtendRecord);

            //时间处理
            if (null != couponExtendRecord.getValidEndTime()) {
                String remainTime = getRemainTime(couponExtendRecord.getValidEndTime());
                if (DataUtils.isNotEmpty(remainTime)) {
                    couponExtendRecordVO.setRemainTime(remainTime);
                } else {
                    couponExtendRecordMapper.updateStatus(couponExtendRecord.getCouponExtendCode(), STATUS_EXPIRED);
                    couponExtendRecordVO.setCouponStatus(STATUS_EXPIRED);
                }

                itemList.add(couponExtendRecordVO);
            }
        }

        return itemList;
    }

    /**
     * 投资者购买产品时，可用的优惠券列表
     * 排列规则：现金券(面值由大到小) + 加息券(加息率由高到低)
     * @param userPhoneNumber
     * @param productUuid
     * @param amt
     * @return
     * @throws BusinessException
     */
    @Override
    public List<CouponExtendRecordVO> lstCouponExtendRecord(String userPhoneNumber, String productUuid, double amt) throws BusinessException {
        List<CouponExtendRecordVO> itemList = new ArrayList<CouponExtendRecordVO>();

        WhereCondition where = new WhereCondition();
        where.setCondi("user_phone_number", userPhoneNumber, true);
        where.setCondi("coupon_status", STATUS_EXTEND, true);
        where.noDelete();
        where.setCondiEx("ORDER BY coupon_face_value, coupon_interest_yield_rate DESC, valid_end_time DESC");

        List<CouponExtendRecord> couponExtendRecords = couponExtendRecordMapper.lstByCondition(where);
        long curTime = new Date().getTime();
        for (CouponExtendRecord couponExtendRecord : couponExtendRecords) {
            if (/*(couponExtendRecord.getValidStartTime() != null) &&*/ (couponExtendRecord.getValidEndTime() != null)) {
                //对于已过期的，做过期处理，然后跳过
                if (/*(curTime < couponExtendRecord.getValidStartTime().getTime()) ||*/ (curTime > couponExtendRecord.getValidEndTime().getTime())) {
                    couponExtendRecordMapper.updateStatus(couponExtendRecord.getCouponExtendCode(), STATUS_EXPIRED);
                    continue;
                }

                if (cashCouponService.isAdaptTrade(couponExtendRecord.getCouponCode(), productUuid, amt)) {
                    itemList.add(new CouponExtendRecordVO(couponExtendRecord));
                } else {
                    logger.info("不符合的现金券：" + couponExtendRecord.getCouponCode() + " " + couponExtendRecord.getCouponExtendCode());
                }
            }
        }

        return itemList;
    }


    /**
     * 使用现金券
     *
     * @param couponExtendCode
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
    public int useCouponExtendRecord(String couponExtendCode, String orderBillCode, String userUuid) throws BusinessException {
        return couponExtendRecordMapper.use(couponExtendCode, STATUS_USED, orderBillCode, userUuid);
    }

    /**
     * 查询单条现金券发放记录
     *
     * @param couponExtendCode
     * @return
     * @throws BusinessException
     */
    @Override
    public CouponExtendRecordVO lstCouponExtendRecord(String couponExtendCode) throws BusinessException {
        CouponExtendRecord couponExtendRecord = couponExtendRecordMapper.selectByPrimaryKey(couponExtendCode);

        if (couponExtendRecord != null) {
            return new CouponExtendRecordVO(couponExtendRecord);
        } else {
            throw new BusinessException(TradeStatusMsg.CASHCOUPON_EXTENDRECORD_NOEXIST, TradeStatusMsg.CASHCOUPON_EXTENDRECORD_NOEXIST_MSG, false);
        }
    }

    /**
     * 自动状态刷新
     */
    @Override
    public void autoRefreshStatus() {
        String lastTime = signTime("couponextendrecord_antorefreshstatus_signtime");
        String curTime = DateUtil.formatTime(new Date());

        //礼券自动更新状态的单次最大更新数量为 1000
        final int limitCount = 1000;
        int succCount = 0;
        int totalCount = 0;
        while((succCount = couponExtendRecordMapper.updateStatusEx(STATUS_EXTEND, STATUS_EXPIRED, lastTime, curTime, limitCount)) > 0) {
            logger.info("autoRefreshStatus_stepupdate_succCount: {}", succCount);
            totalCount += succCount;

            if(succCount == limitCount) {
                continue;
            }else {
                break;
            }
        }

        logger.info("autoRefreshStatus_totalCount: {}", totalCount);
    }

    /**
     * 根据查询条件查询现金券发放记录列表(关联cash_coupon和coupon_extend_record两张表查询)
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @Override
    public List<Map> getExtendRecordList(Map params) throws BusinessException {
        return couponExtendRecordMapper.getExtendRecordList(params);
    }


    /**
     * 根据查询条件查询现金券发放记录数量(关联cash_coupon和coupon_extend_record两张表查询)
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @Override
    public Integer getExtendRecordCount(Map params) throws BusinessException {
        return couponExtendRecordMapper.getExtendRecordCount(params);
    }

    @Override
    public List<Map> getAvailableCouponList(String userUuid, String productUuid, Double amount, Integer couponType) throws BusinessException {
        List<Map> itemList = new ArrayList();
        Map searchMap = new HashMap();
        searchMap.put("userUuid", userUuid);
        searchMap.put("couponStatusList", new Integer[]{STATUS_EXTEND});
        searchMap.put("couponType", couponType);
        searchMap.put("orderBy", "t1.coupon_face_value desc, t1.coupon_interest_yield_rate desc, t1.valid_end_time asc");
        List<Map> list = couponExtendRecordMapper.getExtendRecordList(searchMap);

        ProductFixedIncome productFixedIncome = productClearBase.getFixedIncomeProductById(productUuid);
        long curTime = new Date().getTime();
        for (Map couponExtendRecord : list) {
            if (/*couponExtendRecord.get("validStartTime") != null &&*/ couponExtendRecord.get("validEndTime") != null) {
                //对于已过期的，做过期处理，然后跳过
                if (/*(curTime < ((Date) couponExtendRecord.get("validStartTime")).getTime())
                        ||*/ (curTime > ((Date) couponExtendRecord.get("validEndTime")).getTime())) {
                    couponExtendRecordMapper.updateStatus(couponExtendRecord.get("couponExtendCode").toString(), STATUS_EXPIRED);
                    continue;
                }

                if (isAdaptTrade(couponExtendRecord, productFixedIncome, amount)) {
                    itemList.add(couponExtendRecord);
                } else {
                    logger.info("不符合的现金券：{}  {}", couponExtendRecord.get("couponCode"), couponExtendRecord.get("couponExtendCode"));
                }
            }
        }
        return itemList;
    }


    /**
     * 判断该现金券是否适配交易
     *
     * @param couponExtendRecord
     * @param productFixedIncome
     * @param amount
     * @return
     */
    private boolean isAdaptTrade(Map couponExtendRecord, ProductFixedIncome productFixedIncome, Double amount) {
        if (null != couponExtendRecord) {
            // 检查是否满足单笔投资下限
            if (amount < MapParamUtils.getDoubleInMap(couponExtendRecord, "applyTradeAmount")) {
                System.out.println();
                logger.info("不满足单笔投资下限要求，{}  {}", MapParamUtils.getDoubleInMap(couponExtendRecord, "applyTradeAmount"), amount);
                return false;
            }

            // 如果已经指定了产品列表，检查是否在产品列表内
            if (MapParamUtils.getIntInMap(couponExtendRecord, "isApplyProductuuids") == APPLY_PRODUCTUUIDS_YES) {
                if (DataUtils.split(MapParamUtils.getStringInMap(couponExtendRecord, "applyProductuuids")).contains(productFixedIncome.getProductUuid())) {
                    return true;
                } else {
                    logger.info("该产品没有在指定列表内，{}  {}", MapParamUtils.getStringInMap(couponExtendRecord, "applyProductuuids"), productFixedIncome.getProductUuid());
                }
            }

            //Step3 如果已经要求了产品期限，则检查该产品的期限是否满足该现金券的要求
            if (MapParamUtils.getIntInMap(couponExtendRecord, "isApplyProductTerm") == APPLY_PRODUCT_TERM_YES) {
                List<TwoTuple<Integer, Integer>> listItems = getApplyProductTerms(MapParamUtils.getStringInMap(couponExtendRecord, "applyProductTerms"));

                for (TwoTuple<Integer, Integer> term : listItems) {
                    if ((productFixedIncome.getProductPeriod() >= term.first) && (productFixedIncome.getProductPeriod() <= term.second)) {
                        return true;
                    }
                }

                logger.info("该产品没有在指定产品期限内，{}  {}", MapParamUtils.getStringInMap(couponExtendRecord, "applyProductTerms"), productFixedIncome.getProductPeriod());
            }

            //既没有指定产品列表，也没有限制产品期限
            if ((MapParamUtils.getIntInMap(couponExtendRecord, "isApplyProductuuids") == APPLY_PRODUCTUUIDS_NO)
                    && (MapParamUtils.getIntInMap(couponExtendRecord, "isApplyProductTerm") == APPLY_PRODUCT_TERM_NO)) {
                return true;
            }
        } else {
            logger.info("该现金券不存在");
        }

        return false;
    }

    private List<TwoTuple<Integer, Integer>> getApplyProductTerms(String applyProductTerms) {
        List<TwoTuple<Integer, Integer>> listItems = new ArrayList();
        List<String> terms = DataUtils.split(applyProductTerms, ",");

        for (String term : terms) {
            List<String> termPair = DataUtils.split(term, "-");
            if (termPair.size() > 1) {
                try {
                    Integer startTerm = Integer.parseInt(termPair.get(0).trim());
                    Integer endTerm = Integer.parseInt(termPair.get(1).trim());
                    listItems.add(new TwoTuple(startTerm, endTerm));
                } catch (Exception e) {
                    logger.error(term + "转换失败", e);
                    continue;
                }
            }
        }

        return listItems;
    }

    /**
     * 设置指定发券的用户信息
     *
     * @param userList
     * @param auditId
     * @throws BusinessException
     */
    private void setUserInfoList(List<String> userList, Long auditId) throws BusinessException {
        WhereCondition where = new WhereCondition();
        where.setInString("investor_mobile", new ArrayList<String>(new HashSet<String>(userList)));
        where.noDelete();

        String sql = "SELECT investor_mobile, investor_real_name FROM kingold_user.investor ";
        sql += where.toString();

        int userCount = (new HashSet<String>(userList)).size();

        List<Map> mapList = operationReportMapper.lstQueryData(new QueryUtils(sql));
        if (userCount != mapList.size()) {
            throw new BusinessException(TradeStatusMsg.CASHCOUPON_SPECDIST_NOEXIST_ERR, TradeStatusMsg.CASHCOUPON_SPECDIST_NOEXIST_ERR_MSG);
        }

        Map<String, String> userMap = new HashMap<String, String>();
        for (Map map : mapList) {
            BizParam bizParam = new BizParam(map);
            String phoneNum = bizParam.get("investor_mobile");
            String realName = bizParam.get("investor_real_name");
//            realName = (DataUtils.isNotEmpty(realName)?realName:"匿名");
            userMap.put(phoneNum, realName);
        }

        StringBuilder sb = new StringBuilder("INSERT INTO coupon_specified_distribution_record_item(audit_id, phone_number, phone_name) VALUES");

        for (String userPhoneNum : userList) {
            sb.append("(").append(auditId).append(",");
            sb.append(WhereCondition.toSQLStr(userPhoneNum)).append(",");
            sb.append(WhereCondition.toSQLStr(userMap.get(userPhoneNum))).append(")");
            sb.append(",");
        }

        sb.append("");
        sql = sb.toString();
        sql = sql.substring(0, sql.length() - 1);
        //logger.info(sql);
        couponSpecifiedDistributionRecordItemMapper.insertMultipleRecord(new QueryUtils(sql));
    }

    /**
     * 设置指定发券的用户信息
     *
     * @param userList
     * @param auditId
     * @throws BusinessException
     */
    private void setUserInfoListEx(List<String> userList, Long auditId) throws BusinessException {
        final int MaxItemLen = 1000;
        List<List<String>> listItems = DataUtils.splitList(userList, MaxItemLen, false);

        int pos = 0;
        for (List<String> listItem : listItems) {
            setUserInfoList(listItem, auditId);
            logger.info("setUserInfoList: " + (++pos) + " " + listItems.size());
        }
    }

    /**
     * 添加指定发放礼券的记录
     *
     * @param ccCodeList
     * @param userPhoneList
     * @param operator
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean insertSpecifiedDistribution(List<String> ccCodeList, List<String> userPhoneList, String operator) throws BusinessException {
        CouponSpecifiedDistributionRecord record = new CouponSpecifiedDistributionRecord();

        if (ccCodeList.size() != (new HashSet<String>(ccCodeList)).size()) {
            throw new BusinessException(TradeStatusMsg.CASHCOUPON_SPECDIST_REPEAT_ERR, TradeStatusMsg.CASHCOUPON_SPECDIST_REPEAT_ERR_MSG);
        }

        String ccCodeStr = DataUtils.listToStr(ccCodeList);
        record.setSpecifiedType(SPECIFIED_TYPE_CASH_COUPON);
        record.setCcCodes(ccCodeStr);
        record.setUserCount(userPhoneList.size());

        record.setAuditStatus(BizDefine.WORKFLOW_STATUS_CREATE);
        record.setDeleteFlag(new Byte("0"));

        operator = DataUtils.isNotEmpty(operator) ? operator : BizDefine.DEFAULT_OPERATOR;
        record.setCreatorUserid(operator);

        Date now = new Date();
        record.setCreateTime(now);
        record.setUpdateTime(now);

        int ret = couponSpecifiedDistributionRecordMapper.insert(record);
        if (ret > 0) {
            Long auditId = couponSpecifiedDistributionRecordMapper.lstLastAuditId();
            setUserInfoListEx(userPhoneList, auditId);
        }

        return ret > 0;
    }

    /**
     * 查询现金券指定发放记录
     *
     * @param
     * @return
     * @throws BusinessException
     */
    @Override
    public CouponSpecifiedDistributionRecordItemListVO lstCouponSpecifiedDistributionRecord(LstCouponSpecifiedDistributionConditionVO lstCondition) throws BusinessException {
        CouponSpecifiedDistributionRecordItemListVO couponSpecifiedDistributionRecordList = new CouponSpecifiedDistributionRecordItemListVO();
        WhereCondition where = new WhereCondition();
        where.setCondi("audit_id", lstCondition.getAuditId(), true);
        where.setLike("cc_codes", lstCondition.getCcCode());
        where.setCondi("specified_type", SPECIFIED_TYPE_CASH_COUPON);
        if (lstCondition.getAuditStatus() != -1) {
            where.setCondi("audit_status", lstCondition.getAuditStatus(), true);
        } else if (lstCondition.getAuditStatus() == -1) {
            where.setCondi("audit_status", lstCondition.getAuditStatus());
        }
        where.setBetween("create_time", lstCondition.getBeginDate(), lstCondition.getEndDate());

        int totalCount = couponSpecifiedDistributionRecordMapper.lstCountByCondition(where);
        couponSpecifiedDistributionRecordList.setTotalCount(totalCount);

        where.setPage(lstCondition.getBeginSN(), lstCondition.getEndSN(), "create_time");
        List<CouponSpecifiedDistributionRecord> items = couponSpecifiedDistributionRecordMapper.lstByCondition(where);
        couponSpecifiedDistributionRecordList.setItemsEx(items);

        return couponSpecifiedDistributionRecordList;
    }

    /**
     * 查询现金券指定发放记录明细
     *
     * @param
     * @return
     * @throws BusinessException
     */
    @Override
    public CouponSpecifiedDistributionRecordItemDetailVO lstCouponSpecifiedDistributionDetail(LstCouponSpecifiedDistributionDetailConditionVO lstCondition) throws BusinessException {
        CouponSpecifiedDistributionRecordItemDetailVO couponSpecifiedDistributionRecordDetail = new CouponSpecifiedDistributionRecordItemDetailVO();

        //修正查询序号
        lstCondition.setBeginSN((lstCondition.getBeginSN() > 0) ? lstCondition.getBeginSN() : 1);
        if (lstCondition.getBeginSN() > lstCondition.getEndSN()) {
            return couponSpecifiedDistributionRecordDetail;
        }

        WhereCondition where = new WhereCondition();
        where.setCondi("audit_id", lstCondition.getAuditId());
        couponSpecifiedDistributionRecordDetail.setTotalCount(couponSpecifiedDistributionRecordItemMapper.lstCountByCondition(where));

        where.setPage(lstCondition.getBeginSN(), lstCondition.getEndSN(), "id");
        List<CouponSpecifiedDistributionRecordItem> items = couponSpecifiedDistributionRecordItemMapper.lstByCondition(where);

        couponSpecifiedDistributionRecordDetail.setItems(new ArrayList<CouponSpecifiedDistributionRecordItemDetailVO.UserInfo>());
        for (CouponSpecifiedDistributionRecordItem item : items) {
            CouponSpecifiedDistributionRecordItemDetailVO.UserInfo userInfo = new CouponSpecifiedDistributionRecordItemDetailVO.UserInfo(item.getPhoneNumber(), item.getPhoneName());
            couponSpecifiedDistributionRecordDetail.getItems().add(userInfo);
        }

        return couponSpecifiedDistributionRecordDetail;
    }

    /**
     * 批量发券 Step2实际做现金券的发放
     *
     * @param userPhones
     * @param applyScene
     * @param cashCoupon
     * @param validStartTime
     * @param validEndTime
     * @param creater
     * @return
     * @throws BusinessException
     */
    private int batchEstablishCouponExtendRecord(List<String> userPhones, int applyScene, CashCoupon cashCoupon, String validStartTime, String validEndTime, String creater) throws BusinessException {
        logger.info("Step3 取用户信息");
        WhereCondition where = new WhereCondition();
        where.setInString("investor_mobile", userPhones);
        String sql = "SELECT user_uuid AS userUuid, investor_mobile AS investorMobile, investor_real_name AS investorRealName FROM kingold_user.investor " + where.toString();
        List<Map> listMap = operationReportMapper.lstQueryData(new QueryUtils(sql));
        Map<String, UserInfo> userInfoMap = new HashMap<String, UserInfo>();
        for (Map map : listMap) {
            BizParam bizParam = new BizParam(map);
            String userUuid = bizParam.getString("userUuid");
            String investorMobile = bizParam.getString("investorMobile");
            String investorRealName = bizParam.getString("investorRealName");

            if (!userInfoMap.containsKey(investorMobile)) {
                userInfoMap.put(investorMobile, new UserInfo(userUuid, investorMobile, investorRealName));
            }
        }

        List<UserInfo> userInfos = new ArrayList<UserInfo>();
        for (String userPhone : userPhones) {
            userInfos.add(userInfoMap.get(userPhone));
        }

        if ((userInfos == null) || (userInfos.size() == 0)) {
            return 0;
        }

        StringBuilder sb = new StringBuilder("INSERT INTO coupon_extend_record(" +
                "coupon_extend_code, coupon_code, coupon_type, coupon_face_value, valid_start_time, " +
                "valid_end_time, coupon_status, user_uuid, user_phone_number, user_name, " +
                "apply_scene,coupon_interest_yield_rate,coupon_interest_yield_type,coupon_interest_yield_period, update_user_id) VALUES");

        List<String> userUuids = new ArrayList<>();
        for (UserInfo userInfo : userInfos) {
            sb.append("(").append(WhereCondition.toSQLStr(sequenceService.getCouponExtendRecordNo(couponExtendRecordMapper))).append(",");
            sb.append(WhereCondition.toSQLStr(cashCoupon.getCcCode())).append(",");
            sb.append(cashCoupon.getCcType()).append(",");
            sb.append(cashCoupon.getFaceValue()).append(",");
            sb.append(WhereCondition.toSQLStr(validStartTime)).append(",");

            sb.append(WhereCondition.toSQLStr(validEndTime)).append(",");
            sb.append(STATUS_EXTEND).append(",");
            sb.append(WhereCondition.toSQLStr(userInfo.getUserUuid())).append(",");
            sb.append(WhereCondition.toSQLStr(userInfo.getInvestorMobile())).append(",");
            sb.append(WhereCondition.toSQLStr(userInfo.getInvestorRealName())).append(",");

            sb.append(applyScene).append(",");
            //新增加息券相关信息
            sb.append(cashCoupon.getInterestYieldRate()).append(",");
            sb.append(cashCoupon.getInterestYieldType()).append(",");
            sb.append(cashCoupon.getInterestYieldPeriod()).append(",");

            sb.append(WhereCondition.toSQLStr(creater)).append(")");
            sb.append(",");
            userUuids.add(userInfo.getUserUuid());
        }

        sql = sb.toString();
        sql = sql.substring(0, sql.length() - 1);
        //logger.info(sql);
        //logger.info("Step4 实际做发券");
        int succCount = couponExtendRecordMapper.insertMultipleRecord(new QueryUtils(sql));
        //设置发送红包未读消息
        batchSetUnreadMessageTask.asyncSendCoupon(userUuids, Integer.valueOf(cashCoupon.getCcType()));

        return succCount;
    }

    /**
     * 通用批量发券
     * @param marketCampaign 场景
     * @param userPhones 用户手机号
     * @param operator 操作人
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int commBatchEstablishCouponExtendRecordEx(MarketCampaignVO marketCampaign, List<String> userPhones, String operator) throws BusinessException {
        if((marketCampaign==null) || (DataUtils.isEmpty(marketCampaign.getApplyCashCoupon()))) {
            return 0;
        }

        operator = DataUtils.isNotEmpty(operator) ? operator : BizDefine.DEFAULT_OPERATOR;
        Date now = new Date();
        int succCountAll = 0;
        List<String> cashCouponCodes = DataUtils.split(marketCampaign.getApplyCashCoupon());
        for (String cashCouponCode : cashCouponCodes) {
            cashCouponCode = cashCouponCode.trim();
            if (DataUtils.isNotEmpty(cashCouponCode)) {
                CashCoupon cashCoupon = cashCouponService.lstValidCashCoupon(cashCouponCode);
                if (cashCoupon != null) {

                    //有效时间处理
                    String validStartTime = "";
                    String validEndTime = "";
                    if (cashCoupon.getValidTermType() == CashCouponServiceImpl.VALID_TIME_TYPE_TERM) {
                        validStartTime = DataUtils.toString(cashCoupon.getValidStartTime());
                        validEndTime = DataUtils.toString(cashCoupon.getValidEndTime());
                    } else if (cashCoupon.getValidTermType() == CashCouponServiceImpl.VALID_TERM_TYPE_LENGTH) {
                        validStartTime = DataUtils.toString(now);
                        if (cashCoupon.getValidTermUnit() == CashCouponServiceImpl.TIME_UNIT_DAY) {
                            validEndTime = DataUtils.toString(StringOrDate.dateOffsetDay(now, cashCoupon.getValidTermQuantity()));
                        } else if (cashCoupon.getValidTermUnit() == CashCouponServiceImpl.TIME_UNIT_MONTH) {
                            validEndTime = DataUtils.toString(StringOrDate.addMonth(now, cashCoupon.getValidTermQuantity()));
                        } else if (cashCoupon.getValidTermUnit() == CashCouponServiceImpl.TIME_UNIT_YEAR) {
                            validEndTime = DataUtils.toString(StringOrDate.addYear(now, cashCoupon.getValidTermQuantity()));
                        }
                    }

                    TwoTuple<Integer, Integer> availableQuantity = cashCouponService.lstAvailableQuantity(cashCouponCode);
                    logger.info("availableQuantity: {}", availableQuantity);
                    logger.info("userPhones.size: {}", userPhones.size());
                    if(availableQuantity.second.intValue() < userPhones.size()) {
                        throw new BusinessException(TradeStatusMsg.CASHCOUPON_INSUFFICIENT_QUANTITY_ERR,
                                cashCouponCode + TradeStatusMsg.CASHCOUPON_INSUFFICIENT_QUANTITY_ERR_MSG, false);
                    }

                    final int MaxItemLen = 2000;
                    List<List<String>> listItems = DataUtils.splitList(userPhones, MaxItemLen, false);

                    int pos = 0;
                    int succCount = 0;
                    for (List<String> listItem : listItems) {
                        succCount += batchEstablishCouponExtendRecord(listItem, marketCampaign.getApplyScene(), cashCoupon, validStartTime, validEndTime, operator);
                        logger.info("batchEstablishCouponExtendRecordEx: " + (++pos) + "/" + listItems.size());
                    }

                    succCountAll += succCount;
                    if((availableQuantity.first.intValue()==CashCouponServiceImpl.AVAIL_TYPE_TOTAL)
                            && (availableQuantity.second.intValue()==succCount)) {
                        logger.info(cashCouponCode + "批次已经用完，停用");
                        cashCouponService.updateStatus(cashCouponCode, CashCouponServiceImpl.STATUS_STOP, "sys");
                    }
                }else {
                    logger.error(cashCouponCode + "批次无效或为空");
                }
            }
        }
        return succCountAll;
    }

    /**
     * 批量发券 Step1汇总全局数据，拆分用户
     *
     * @param ccCodes
     * @param userPhones
     * @param operator
     * @return
     * @throws BusinessException
     */
    private int batchEstablishCouponExtendRecordEx(String ccCodes, List<String> userPhones, String operator) throws BusinessException {
        logger.info("Step1 取礼券批次信息");
        String applyCashCoupon = "";
        List<String> items = DataUtils.split(ccCodes, ",");
        for (String item : items) {
            List<String> subItems = DataUtils.split(item, "-");
            if ((subItems.size() >= 2) && DataUtils.isNotEmpty(subItems.get(0))) {
                if (applyCashCoupon.length() > 0) {
                    applyCashCoupon += "$$";
                }
                applyCashCoupon += subItems.get(0);
            }
        }

        logger.info("Step2 取场景信息");
        MarketCampaignVO marketCampaign = marketCampaignService.lstMarketCampaign(MarketCampaignServiceImpl.SPECIFIED_DISTRIBUTION_CODE);
        if (marketCampaign != null) {
            marketCampaign.setApplyCashCoupon(applyCashCoupon);

            return commBatchEstablishCouponExtendRecordEx(marketCampaign, userPhones, operator);
        } else {
            logger.error("未配置礼券 指定发放 的业务场景");
        }

        return 0;
    }

    /**
     * 现金券指定发放记录审核
     *
     * @param
     * @return
     * @throws BusinessException
     */
    @Override
    public boolean couponSpecifiedDistributionAudit(CouponSpecifiedDistributionAuditVO auditInfo) throws BusinessException {
        final int MAX_RUN_TIME = 2;      //最大耗时时间，两分钟

        WhereCondition where = new WhereCondition();
        List<String> auditIds = DataUtils.split(auditInfo.getAuditIdList(), REGEXSTR);
        where.setInString("audit_id", auditIds);
        where.noDelete();

        List<CouponSpecifiedDistributionRecord> recordList =
                couponSpecifiedDistributionRecordMapper.lstByCondition(where);

        int succCount = 0;
        if (recordList != null && recordList.size() > 0) {
            for (CouponSpecifiedDistributionRecord record : recordList) {

                if(checkKeyLock(COUPON_SPECIFIED_DISTRIBUTION_KEY + record.getAuditId(), MAX_RUN_TIME)) {
                    continue;
                }

                logger.info("CouponSpecifiedDistributionRecord: " + DataUtils.toString(record.toString()));
                if ((!record.getAuditStatus().equals(BizDefine.WORKFLOW_STATUS_AUDIT_FAIL))
                        && (!record.getAuditStatus().equals(BizDefine.WORKFLOW_STATUS_AUDITED))) {
                    logger.info("AuditStatus: " + DataUtils.toString(record.getAuditStatus()));
                    Date now = new Date();
                    record.setAuditTime(now);
                    record.setAuditOperator(auditInfo.getAuditOperator());
                    record.setUpdateTime(now);
                    if (auditInfo.getIsAudited() != 1) {
                        record.setAuditStatus(BizDefine.WORKFLOW_STATUS_AUDIT_FAIL);
                        record.setAuditOpinion(auditInfo.getAuditOpinion());
                    } else {
                        record.setAuditStatus(BizDefine.WORKFLOW_STATUS_AUDITED);
                        logger.info("发放现金券");
                        List<String> phoneNumberList = couponSpecifiedDistributionRecordItemMapper.lstUserPhoneByAuditId(record.getAuditId());

                        if (DataUtils.isNotEmpty(record.getCcCodes()) && (phoneNumberList != null) && (phoneNumberList.size() > 0)) {
                            int establishInt = batchEstablishCouponExtendRecordEx(record.getCcCodes(), phoneNumberList, auditInfo.getAuditOperator());
                            if(establishInt <= 0) {
                                continue;
                            }
                        } else {
                            logger.error("CcCodes:" + DataUtils.toString(record.getCcCodes()) + ", UserPhoneNumbers:" + DataUtils.toString(phoneNumberList));
                        }
                    }

                    //更新回批量审核记录
                    if(couponSpecifiedDistributionRecordMapper.updateByPrimaryKeyEx(record) > 0) {
                        ++succCount;
                    }else {
                        logger.error("批量更新失败，{}", record.toString());
                        throw new BusinessException(TradeStatusMsg.CASHCOUPON_SPECDIST_STATUS_ERR,
                                TradeStatusMsg.CASHCOUPON_SPECDIST_STATUS_ERR_MSG, false);
                    }
                }else {
                    throw new BusinessException(TradeStatusMsg.CASHCOUPON_SPECDIST_STATUS_ERR,
                            TradeStatusMsg.CASHCOUPON_SPECDIST_STATUS_ERR_MSG, false);
                }
            }
            return succCount>0;
        }
        return false;
    }

    /**
     * 记录分享并发放礼券批次数量
     * @param userInfo
     * @param marketCampaignVO
     * @param shareCount
     * @throws BusinessException
     */
    public void recordShareCount(UserInfo userInfo, MarketCampaignVO marketCampaignVO,Integer shareCount)throws BusinessException{
        stringRedisTemplate.opsForValue().set(SHARE_COUNT_KEY + userInfo.getUserUuid(),String.valueOf(shareCount));
        setPrescription(userInfo);
    }

    /**
     * 获取当前用户已经分享并发放礼券次数
     * @param userInfo
     * @param marketCampaignVO
     * @return
     * @throws BusinessException
     */
    public Integer getRecordShareCount(UserInfo userInfo, MarketCampaignVO marketCampaignVO)throws BusinessException{
        logger.info("getRecordShareCount start {} {} ",userInfo,marketCampaignVO);
        Integer recordShareCount = 0;
        if(stringRedisTemplate.opsForValue().get(SHARE_COUNT_KEY + userInfo.getUserUuid()) != null){
            recordShareCount = Integer.parseInt(stringRedisTemplate.opsForValue().get(SHARE_COUNT_KEY + userInfo.getUserUuid())) ;
        }
        logger.info("getRecordShareCount end{} ",recordShareCount);
        getExpiryTime(userInfo);
        return recordShareCount;
    }

    /**
     * 更新当前用户已经分享并发放礼券次数
     * @param userInfo
     * @param marketCampaignVO
     * @throws BusinessException
     */
    @Override
    public void updateRecordShareCount(UserInfo userInfo, MarketCampaignVO marketCampaignVO)throws BusinessException{
        logger.info("updateRecordShareCount {} {} ",userInfo,marketCampaignVO);
        stringRedisTemplate.opsForValue().increment(SHARE_COUNT_KEY + userInfo.getUserUuid(),1);
        setPrescription(userInfo);
        getExpiryTime(userInfo);
    }

    @Override
    public void campaignExchangeCouponExtendRecord(MarketCampaignTriggerVO vo, MarketCampaignVO marketCampaignVO)
            throws BusinessException{
        UserInfo userInfo = getUserInfo(vo.getUserUuid());
        CouponSendConditionDto conditionDto = new CouponSendConditionDto();

        conditionDto.setInvitedUserUuid(vo.getInvitedUserUuid());
        conditionDto.setOrderBillCode(vo.getOrderBillCode());
        conditionDto.setCouponExtendCode(vo.getCouponExtendCode());
        this.establishCouponExtendRecordEx(userInfo, marketCampaignVO, BizDefine.DEFAULT_OPERATOR, conditionDto);
    }

    @Override
    public String getCouponExtendCode() {
        return this.sequenceService.getCouponExtendRecordNo(this.couponExtendRecordMapper);
    }

    /**
     * 设置过期时间
     * @param userInfo
     */
    private void setPrescription(UserInfo userInfo){
        logger.info("setPrescription {} ",userInfo);
        Long startTime=new Date().getTime();
        Date time=DateUtil.strToDate(DateUtil.formateDate(new Date(),DateUtil.DAY_FROMAT));
        Long endTime=StringOrDate.dateOffsetDay(time, 1).getTime();
        stringRedisTemplate.expire(SHARE_COUNT_KEY + userInfo.getUserUuid(),endTime-startTime, TimeUnit.MILLISECONDS);
        logger.info("setPrescription {} {} ",userInfo ,endTime-startTime);
    }

    /**
     * 记录该用户过期时间
     * @param userInfo
     */
    private void getExpiryTime(UserInfo userInfo){
        logger.info("getExpiryTime userUuid time {} {} ", userInfo.getUserUuid() ,stringRedisTemplate.getExpire(SHARE_COUNT_KEY + userInfo.getUserUuid()));
    }

}
