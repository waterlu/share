package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.service_consumer.service.UserServiceConsumer;
import cn.zjhf.kingold.trade.constant.*;
import cn.zjhf.kingold.trade.entity.InVO.LstProductRewardItemsVO;
import cn.zjhf.kingold.trade.entity.InVO.LstProductRewardSummaryItemsVO;
import cn.zjhf.kingold.trade.entity.InVO.ProductRewardSummaryBatchAuditVO;
import cn.zjhf.kingold.trade.entity.InVO.ReportConditionVO;
import cn.zjhf.kingold.trade.entity.*;
import cn.zjhf.kingold.trade.entity.OutVO.*;
import cn.zjhf.kingold.trade.persistence.dao.OperationReportMapper;
import cn.zjhf.kingold.trade.persistence.dao.ProductRewardSummaryMapper;
import cn.zjhf.kingold.trade.persistence.dao.RewardMapper;
import cn.zjhf.kingold.trade.persistence.dao.TradeOrderMapper;
import cn.zjhf.kingold.trade.service.IReportService;
import cn.zjhf.kingold.trade.utils.*;
import cn.zjhf.kingold.trade.vo.ProductRewardSummaryReportVO;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import org.apache.xmlbeans.UserType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.text.Collator;
import java.util.*;

/**
 * Created by zhangyijie on 2017/6/5.
 */
@Service
public class ReportServiceImpl extends ProductClearBase implements IReportService {
    protected static final Logger logger = LoggerFactory.getLogger(ReportServiceImpl.class);
    @Autowired
    private UserServiceConsumer userServiceConsumer;
    @Autowired
    ProductRewardSummaryMapper productRewardSummaryMapper;

    @Autowired
    RewardMapper rewardMapper;

    @Autowired
    OperationReportMapper operationReportMapper;

    @Autowired
    TradeOrderMapper tradeOrderMapper;

    //间隔符
    static final String REGEXSTR = "\\|";

    /**
     * Step1 产品奖励记录_查询
     *
     * @param param
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public ProductRewardSummaryListVO lstProductRewardSummaryItems(LstProductRewardSummaryItemsVO param) throws BusinessException {
       if(DataUtils.isNotEmpty(param.getProductIssuerName())){
          return listProductRewardSummaryItems(param);
       }
        ProductRewardSummaryListVO productRewardSummaryList = new ProductRewardSummaryListVO();

        WhereCondition where = new WhereCondition();
        where.setLike("product_abbr_name", param.getProductAbbrName());
        where.setCondi("product_uuid", param.getProductUuid(), true);
        where.setCondi("product_code", param.getProductCode(), true);
        where.setCondi("product_type", param.getProductType(), true);
        where.setCondi("product_period", param.getProductPeriod(), true);

        if (param.getIncomeTaxClearStatus() != 0) {
            where.setCondi("income_tax_clear_status", param.getIncomeTaxClearStatus());
        }

        if (param.getExchangeManagefeeClearStatus() != 0) {
            where.setCondi("exchange_managefee_clear_status", param.getExchangeManagefeeClearStatus());
        }
//        where.setBetween("product_interest_date", param.getProductInterestDateFrom(), param.getProductInterestDateTo());
        where.setBetween("product_establishment_date", param.getProductEstablishmentDateFrom(), param.getProductEstablishmentDateTo());
        where.noDelete();

        productRewardSummaryList.setTotalCount(productRewardSummaryMapper.lstCountByCondition(where));

        where.setPage(param.getBeginSN(), param.getEndSN(), "product_reward_summary_uuid");
        List<ProductRewardSummary> items = productRewardSummaryMapper.lstByCondition(where);

        productRewardSummaryList.setItems(ProductRewardSummaryVO.toList(items));
        setMarketingAmount(productRewardSummaryList);
        return productRewardSummaryList;
    }

    protected ProductRewardSummaryListVO listProductRewardSummaryItems(LstProductRewardSummaryItemsVO param){
        ProductRewardSummaryListVO productRewardSummaryList = new ProductRewardSummaryListVO();

        WhereCondition where = new WhereCondition();
        where.setCondiEx(" reward.product_uuid = product.product_uuid AND reward.delete_flag = 0 ");
        where.setLike("reward.product_abbr_name", param.getProductAbbrName());
        where.setLike("product.product_issuer_name", param.getProductIssuerName());
        where.setCondi("reward.product_uuid", param.getProductUuid(), true);
        where.setCondi("reward.product_code", param.getProductCode(), true);
        where.setCondi("reward.product_type", param.getProductType(), true);
        where.setCondi("reward.product_period", param.getProductPeriod(), true);
        if (param.getIncomeTaxClearStatus() != 0) {
            where.setCondi("reward.income_tax_clear_status", param.getIncomeTaxClearStatus());
        }
        if (param.getExchangeManagefeeClearStatus() != 0) {
            where.setCondi("reward.exchange_managefee_clear_status", param.getExchangeManagefeeClearStatus());
        }
        where.setBetween("reward.product_interest_date", param.getProductInterestDateFrom(), param.getProductInterestDateTo());
        where.setBetween("reward.product_establishment_date", param.getProductEstablishmentDateFrom(), param.getProductEstablishmentDateTo());

        productRewardSummaryList.setTotalCount(productRewardSummaryMapper.listCountByCondition(where));

        where.setPage(param.getBeginSN(), param.getEndSN(), "reward.product_reward_summary_uuid");
        List<ProductRewardSummary> items = productRewardSummaryMapper.listByCondition(where);
        productRewardSummaryList.setItems(ProductRewardSummaryVO.toList(items));
        setMarketingAmount(productRewardSummaryList);
        return productRewardSummaryList;
    }

    /**
     * 产品收支明细表
     * @param param
     * @return
     * @throws BusinessException
     */
    @Override
    public CommItemListVO<ProductRewardSummaryReportVO> getExpenditureDetailsReport(LstProductRewardSummaryItemsVO param) throws BusinessException {
        WhereCondition where = new WhereCondition();
        where.setCondiEx(" reward.product_uuid = trade.product_uuid AND reward.product_uuid = pro.product_uuid AND reward.product_uuid = fixed.product_uuid " +
                "AND reward.delete_flag = 0");
        where.setLike("reward.product_abbr_name", param.getProductAbbrName());
        where.setLike("pro.product_issuer_name", param.getProductIssuerName());
        where.setCondi("reward.product_type", param.getProductType(), true);
        where.setCondi("reward.product_period", param.getProductPeriod(), true);
        // 需要排除支付失败的情况
        where.setNotInInt("trade.order_status", 1, 9);
        where.setBetween("reward.product_establishment_date", param.getProductEstablishmentDateFrom(), param.getProductEstablishmentDateTo());
        Integer count=productRewardSummaryMapper.getExpenditureDetailsReportCount(where);
        where.setCondiEx(" GROUP BY trade.product_uuid,reward.product_reward_summary_uuid,reward.product_abbr_name,reward.product_establishment_date," +
                "pro.product_issuer_name,reward.product_period,fixed.annual_interest_show,fixed.increase_interest_rate,reward.product_accumulation," +
                "reward.exchange_manage_fee,reward.pretax_platform_servicefee,reward.pretax_reward_amount ");
        where.setPage(param.getBeginSN(), param.getEndSN(), "reward.product_reward_summary_uuid");
        List<ProductRewardSummaryReportVO> list=productRewardSummaryMapper.getExpenditureDetailsReport(where);
//        for(ProductRewardSummaryReportVO vo:list){
//            vo.setAnnualInterestShow(vo.getAnnualInterestShow().multiply(BigDecimal.valueOf(100)));
//            vo.setIncreaseInterestRate(vo.getIncreaseInterestRate().multiply(BigDecimal.valueOf(100)));
//        }
        return new CommItemListVO<ProductRewardSummaryReportVO>(count,list);
    }

    /**
     * 设置营销费用(现金券)
     *
     * @param listVO
     * @return
     */
    private ProductRewardSummaryListVO setMarketingAmount(ProductRewardSummaryListVO listVO) {
        List<ProductRewardSummaryVO> items = listVO.getItems();
        if (items != null && items.size() > 0) {
            for (ProductRewardSummaryVO vo : items) {
                String productUuid = vo.getProductUuid();
                //现金券使用总额
                BigDecimal marketingAmount = tradeOrderMapper.getSumMarketingAmountByProductUuid(productUuid);
                //税前现金券总额=现金券使用总额/80%
                BigDecimal pretaxMarketingAmount = marketingAmount.divide(new BigDecimal(0.8), 6, BigDecimal.ROUND_HALF_EVEN);
                // 现金券扣税=税前现金券总额-现金券总额
                BigDecimal deductionMarketingAmount = pretaxMarketingAmount.subtract(marketingAmount);
                vo.setMarketingAmout(AmountUtils.exac(marketingAmount));
                vo.setPretaxMarketingAmout(AmountUtils.exac(pretaxMarketingAmount));
                vo.setDeductionMarketingAmout(AmountUtils.exac(deductionMarketingAmount));
            }
        }
        return listVO;
    }

    /**
     * Step2 产品奖励记录_批量报税审核
     *
     * @param param
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int productRewardSummaryBatchIncomeTaxAudit(ProductRewardSummaryBatchAuditVO param) throws BusinessException {
        WhereCondition where = new WhereCondition();
        List<String> productUuids = DataUtils.split(param.getProductUuidList(), REGEXSTR);
        where.setInString("product_uuid", productUuids);
        where.noDelete();

        List<ProductRewardSummary> items = productRewardSummaryMapper.lstByCondition(where);

        Date auditTime = new Date();
        for (ProductRewardSummary item : items) {
            int curStatus = item.getIncomeTaxClearStatus();
            if ((BizDefine.WORKFLOW_STATUS_AUDIT_FAIL == curStatus) || (BizDefine.WORKFLOW_STATUS_CREATE == curStatus)) {
                item.setIncomeTaxAuditOperator(param.getUserPhone());
                item.setIncomeTaxAuditTime(auditTime);

                if (param.getIsAudited() > 0) {
                    item.setIncomeTaxClearStatus(BizDefine.WORKFLOW_STATUS_AUDITED);
                    item.setIncomeTaxAuditOpinion("审核通过");
                } else {
                    item.setIncomeTaxClearStatus(BizDefine.WORKFLOW_STATUS_AUDIT_FAIL);
                    item.setIncomeTaxAuditOpinion(param.getMessage());
                }

                productRewardSummaryMapper.updateByPrimaryKey(item);
            }
        }

        return productUuids.size();
    }

    /**
     * Step3 产品奖励记录_批量报税(结算)
     *
     * @param param
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int productRewardSummaryBatchIncomeTaxClear(ProductRewardSummaryBatchAuditVO param) throws BusinessException {
        WhereCondition where = new WhereCondition();
        List<String> productUuids = DataUtils.split(param.getProductUuidList(), REGEXSTR);
        where.setInString("product_uuid", productUuids);
        where.noDelete();
        List<ProductRewardSummary> items = productRewardSummaryMapper.lstByCondition(where);

        Date clearTime = new Date();
        int count = 0;
        for (ProductRewardSummary item : items) {
            if (item.getIncomeTaxClearStatus() == BizDefine.WORKFLOW_STATUS_AUDITED) {
                item.setIncomeTaxClearOperator(param.getUserPhone());
                item.setIncomeTaxClearTime(clearTime);
                item.setIncomeTaxClearStatus(BizDefine.WORKFLOW_STATUS_CLEAR);

                productRewardSummaryMapper.updateByPrimaryKey(item);
                ++count;
            }
        }

        return count;
    }

    /**
     * Step4 产品奖励记录_奖励详情_产品奖励明细记录
     *
     * @param param
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public ProductRewardItemListVO lstProductRewardItems(LstProductRewardItemsVO param) throws BusinessException {
        ProductRewardItemListVO productRewardItemList = new ProductRewardItemListVO();
        WhereCondition where = new WhereCondition();
        where.setCondi("product_uuid", param.getProduct_uuid());
        List<Reward> rewardList = rewardMapper.lstByCondition(where);

        Map<String, ProductRewardItemVO> map = new HashMap<String, ProductRewardItemVO>();
        for (Reward reward : rewardList) {
            if (!map.containsKey(reward.getUserMobile())) {
                ProductRewardItemVO productRewardItemVO = new ProductRewardItemVO();
                productRewardItemVO.setUserMobile(reward.getUserMobile());
                productRewardItemVO.setUserRealName(reward.getUserRealName());
                map.put(reward.getUserMobile(), productRewardItemVO);
            }

            ProductRewardItemVO productRewardItemVO = map.get(reward.getUserMobile());
            double newRewardAmount = AmountUtils.exac(productRewardItemVO.getRewardAmount() + reward.getRewardAmount().doubleValue());
            productRewardItemVO.setRewardAmount(newRewardAmount);
            productRewardItemVO.setRewardCount(productRewardItemVO.getRewardCount() + 1);
        }

        productRewardItemList.setTotalCount(map.size());
        List<String> userPhones = new ArrayList<String>(map.keySet());

        Collections.sort(userPhones, Collator.getInstance(java.util.Locale.US));

        int beginSn = param.getBeginSN();
        int endSn = param.getEndSN();
        beginSn = ((beginSn > 0) ? (beginSn - 1) : 0);

        if ((endSn >= beginSn) && (beginSn < userPhones.size())) {
            endSn = ((endSn > userPhones.size()) ? userPhones.size() : endSn);
            List<String> selectUserPhones = userPhones.subList(beginSn, endSn);

            List<ProductRewardItemVO> items = new ArrayList<ProductRewardItemVO>();
            for (String userPhone : selectUserPhones) {
                items.add(map.get(userPhone));
            }
            productRewardItemList.setItems(items);
        }

        logger.info("lstProductRewardItems return: " + DataUtils.toString(productRewardItemList));
        return productRewardItemList;
    }

    /**
     * Step5 产品奖励记录_奖励详情_管理费审核
     *
     * @param param
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int productRewardSummaryExchangeManagefeeAudit(ProductRewardSummaryBatchAuditVO param) throws BusinessException {
        WhereCondition where = new WhereCondition();
        List<String> productUuids = DataUtils.split(param.getProductUuidList(), REGEXSTR);
        where.setInString("product_uuid", productUuids);
        where.noDelete();

        List<ProductRewardSummary> items = productRewardSummaryMapper.lstByCondition(where);

        Date auditTime = new Date();
        for (ProductRewardSummary item : items) {
            int curStatus = item.getExchangeManagefeeClearStatus();
            if ((BizDefine.WORKFLOW_STATUS_AUDIT_FAIL == curStatus) || (BizDefine.WORKFLOW_STATUS_CREATE == curStatus)) {
                item.setExchangeManagefeeAuditOperator(param.getUserPhone());
                item.setExchangeManagefeeAuditTime(auditTime);

                if (param.getIsAudited() > 0) {
                    item.setExchangeManagefeeClearStatus(BizDefine.WORKFLOW_STATUS_AUDITED);
                    item.setExchangeManagefeeAuditOpinion("审核通过");
                } else {
                    item.setExchangeManagefeeClearStatus(BizDefine.WORKFLOW_STATUS_AUDIT_FAIL);
                    item.setExchangeManagefeeAuditOpinion(param.getMessage());
                }

                productRewardSummaryMapper.updateByPrimaryKey(item);
            }
        }

        return productUuids.size();
    }

    /**
     * Step6 产品奖励记录_奖励详情_管理费结算
     *
     * @param param
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int productRewardSummaryExchangeManagefeeClear(ProductRewardSummaryBatchAuditVO param) throws BusinessException {
        WhereCondition where = new WhereCondition();
        List<String> productUuids = DataUtils.split(param.getProductUuidList(), REGEXSTR);
        where.setInString("product_uuid", productUuids);
        where.noDelete();
        List<ProductRewardSummary> items = productRewardSummaryMapper.lstByCondition(where);

        Date clearTime = new Date();
        int count = 0;
        for (ProductRewardSummary item : items) {
            if (item.getExchangeManagefeeClearStatus() == BizDefine.WORKFLOW_STATUS_AUDITED) {
                item.setExchangeManagefeeClearOperator(param.getUserPhone());
                item.setExchangeManagefeeClearTime(clearTime);
                item.setExchangeManagefeeClearStatus(BizDefine.WORKFLOW_STATUS_CLEAR);

                productRewardSummaryMapper.updateByPrimaryKey(item);
                ++count;
            }
        }

        return count;
    }

    public OperationReport lstReportRuleStr(String reportNo, int batchNo) {
        return operationReportMapper.selectByPrimaryKey(new OperationReportKey(reportNo, batchNo));
    }

    private List<String> getRechargeFeeDataItem(String userType, ReportConditionVO reportCondition, String... acctTypes) {
        List<String> contents = new ArrayList<String>();
        contents.add(ReportConditionVO.getTimeSection(reportCondition.getTradeBeginDate(), reportCondition.getTradeEndDate()));
        contents.add(userType);

        //Step1 处理鉴权数据
        boolean isInve = DataUtils.toList(acctTypes).contains(AccountType.ACCOUNT_TYPE_INVESTOR);
        String timeCondi = WhereCondition.setBetweenCondi("update_time", reportCondition.getTradeBeginDate(), reportCondition.getTradeEndDate());
        if (isInve) {
            contents.add("" + operationReportMapper.lstQueryCount(new QueryUtils("SELECT Count(*) FROM kingold_user.investor where investor_id_card_no is not null and delete_flag = 0" + timeCondi)));
        } else {
            contents.add("" + operationReportMapper.lstQueryCount(new QueryUtils("SELECT Count(*) FROM kingold_user.issuer WHERE legal_person_id_card_no is not null and delete_flag = 0" + timeCondi)));
        }
        contents.add("0");

        //Step2 处理充值数据
        double totalFee = 0;
        timeCondi = WhereCondition.setBetweenCondi("recharge.recharge_time", reportCondition.getTradeBeginDate(), reportCondition.getTradeEndDate());
        String sql = "SELECT Count(recharge.trade_recharge_uuid) as '充值笔数', sum(recharge.recharge_amount) as '充值总额(元)', sum(recharge.recharge_fee) as '充值手续费(元)' " +
                "from trade_recharge recharge, account acct " +
                "where recharge.account_uuid = acct.account_uuid " +
                "and acct.account_type in (" + WhereCondition.stringListToSql(DataUtils.toList(acctTypes)) +
                ") and recharge.recharge_bill_type = '" + TradeType.TRADE_RE_CHARGE +
                "' and recharge.recharge_status = 1 and recharge_fee_type = 1 " +
                timeCondi;

        List<Map> datas = operationReportMapper.lstQueryData(new QueryUtils(sql));
        for (Map map : datas) {
            BizParam param = new BizParam(map);
            contents.add(DataUtils.toString(param.getInt("充值笔数")));
            contents.add(DataUtils.toString(param.getDouble("充值总额(元)")));
            totalFee = param.getDouble("充值手续费(元)");
            contents.add(DataUtils.toString(totalFee));
            break;
        }

        //Step3 处理提现数据
        sql = "SELECT Count(recharge.trade_recharge_uuid) as '提现笔数', sum(recharge.recharge_fee) as '提现手续费(元)' " +
                "from trade_recharge recharge, account acct " +
                "where recharge.account_uuid = acct.account_uuid " +
                "and acct.account_type in (" + WhereCondition.stringListToSql(DataUtils.toList(acctTypes)) +
                ") and recharge.recharge_bill_type = '" + TradeType.TRADE_WITH_DROW +
                "' and recharge.recharge_status = 1 and recharge_fee_type = 1 " +
                timeCondi;

        datas = operationReportMapper.lstQueryData(new QueryUtils(sql));
        for (Map map : datas) {
            BizParam param = new BizParam(map);
            contents.add(DataUtils.toString(param.getInt("提现笔数")));
            double fee = param.getDouble("提现手续费(元)");
            contents.add(DataUtils.toString(fee));
            totalFee += fee;
        }

        //Step4 汇总手续费
        contents.add(DataUtils.toString(totalFee));

        return contents;
    }

    /**
     * 三方手续费汇总表
     *
     * @return
     */
    private List<List<String>> getRechargeFeeData(ReportConditionVO reportCondition) {
        List<List<String>> reportTable = new ArrayList<List<String>>();
        List<String> fieldNames = new ArrayList<String>();
        fieldNames.add("交易时间段");
        fieldNames.add("用户类型");

        fieldNames.add("鉴权笔数");
        fieldNames.add("鉴权手续费");

        fieldNames.add("充值笔数");
        fieldNames.add("充值总额(元)");
        fieldNames.add("充值手续费(元)");

        fieldNames.add("提现笔数");
        fieldNames.add("提现手续费(元)");
        fieldNames.add("手续费合计(元)");

        reportTable.add(getRechargeFeeDataItem("个人", reportCondition, AccountType.ACCOUNT_TYPE_INVESTOR));

        reportTable.add(getRechargeFeeDataItem("机构", reportCondition, AccountType.ACCOUNT_TYPE_PLATFORM_SETTLEMENT, AccountType.ACCOUNT_TYPE_FINANCIER));

        reportTable.add(0, fieldNames);
        return reportTable;
    }

    //B0501
    private List<List<String>> getProductSaleItems(ReportConditionVO reportCondition) throws BusinessException {
        List<List<String>> reportTable = new ArrayList<List<String>>();

        String timeSection = ReportConditionVO.getTimeSection(reportCondition.getTradeBeginDate(), reportCondition.getTradeEndDate());
        double totalFIXIRaiseAmt = 0;
        if (DataUtils.isEmpty(reportCondition.getProductType()) || reportCondition.getProductType().equals(ProductType.PRODUCT_FT)) {
            WhereCondition where = new WhereCondition();
            where.setCondi("trade.product_code", reportCondition.getProductCode());
            where.setLike("pro.product_abbr_name", reportCondition.getProductAbbrName());
            where.setBetween("Date(trade.payed_time)", reportCondition.getTradeBeginDate(), reportCondition.getTradeEndDate());

            if ((null != reportCondition.getProductStatus()) && (reportCondition.getProductStatus() != 0)) {
                where.setCondi("pro.product_status", reportCondition.getProductStatus());
            } else {
                where.setNotInInt("pro.product_status", BizDefine.PRODUCT_STATUS_UNCONFIRMED, BizDefine.PRODUCT_STATUS_PREHEAT,
                        BizDefine.PRODUCT_STATUS_ABORT);
            }

            String sql = "SELECT trade.product_code AS '产品编号', pro.product_abbr_name AS '产品名称', pro.product_status AS '产品状态', SUM(trade.order_amount) AS '实际募集金额' " +
                    " FROM trade_order trade, kingold_product.product pro";
            sql += where.toString();
            sql += " AND trade.product_uuid = pro.product_uuid ";
            sql += " AND trade.order_status NOT IN (1,9) AND trade.order_amount > 0 GROUP BY trade.product_uuid ";

            List<Map> mapList = operationReportMapper.lstReportData(new ReportUtils().setReportRule(sql.toString()));

            for (Map map : mapList) {
                BizParam bizParam = new BizParam(map);
                List<String> contents = new ArrayList<String>();
                contents.add(timeSection);
                contents.add("定期产品");

                contents.add(bizParam.getString("产品编号"));
                contents.add(bizParam.getString("产品名称"));
                contents.add(BizDefine.getProductStatusName(bizParam.getInt("产品状态")));
                double raiseAmt = bizParam.getDouble("实际募集金额");
                totalFIXIRaiseAmt += raiseAmt;
                contents.add(AmountUtils.toString(raiseAmt));
                reportTable.add(contents);
            }

            if ((mapList.size() > 0) && (totalFIXIRaiseAmt > 0)) {
                List<String> contents = new ArrayList<String>();
                contents.add(timeSection);
                contents.add("");
                contents.add("");
                contents.add("");
                contents.add("金额小计");
                contents.add(AmountUtils.toString(totalFIXIRaiseAmt));
                reportTable.add(contents);
            }
        }

        double totalPRIFRaiseAmt = 0;
        if (DataUtils.isEmpty(reportCondition.getProductType()) || reportCondition.getProductType().equals(ProductType.PRODUCT_PF)) {
            WhereCondition where = new WhereCondition();
            where.setCondi("trade.product_code", reportCondition.getProductCode());
            where.setLike("pro.product_abbr_name", reportCondition.getProductAbbrName());
            where.setBetween("DATE(trade.purchase_time)", reportCondition.getTradeBeginDate(), reportCondition.getTradeEndDate());

            if ((null != reportCondition.getProductStatus()) && (reportCondition.getProductStatus() != 0)) {
                where.setCondi("pro.product_status", reportCondition.getProductStatus());
            } else {
                where.setNotInInt("pro.product_status", BizDefine.PRODUCT_STATUS_UNCONFIRMED, BizDefine.PRODUCT_STATUS_PREHEAT,
                        BizDefine.PRODUCT_STATUS_ABORT);
            }

            String sql = "SELECT trade.product_code AS '产品编号', pro.product_abbr_name AS '产品名称', pro.product_status AS '产品状态', SUM(trade.purchase_amount) AS '实际募集金额' " +
                    " FROM trade_private_fund_order trade, kingold_product.product pro";
            sql += where.toString();
            sql += " AND trade.product_uuid = pro.product_uuid ";
            sql += " AND trade.pfo_status = 2 AND trade.purchase_amount > 0 GROUP BY trade.product_uuid ";

            List<Map> mapList = operationReportMapper.lstReportData(new ReportUtils().setReportRule(sql.toString()));

            for (Map map : mapList) {
                BizParam bizParam = new BizParam(map);
                List<String> contents = new ArrayList<String>();
                contents.add(timeSection);
                contents.add("私募产品");

                contents.add(bizParam.getString("产品编号"));
                contents.add(bizParam.getString("产品名称"));
                contents.add(BizDefine.getProductStatusName(bizParam.getInt("产品状态")));

                double raiseAmt = bizParam.getDouble("实际募集金额");
                totalPRIFRaiseAmt += raiseAmt;
                contents.add(AmountUtils.toString(raiseAmt));
                reportTable.add(contents);
            }

            if ((mapList.size() > 0) && (totalPRIFRaiseAmt > 0)) {
                List<String> contents = new ArrayList<String>();
                contents.add(timeSection);
                contents.add("");
                contents.add("");
                contents.add("");
                contents.add("金额小计");
                contents.add(AmountUtils.toString(totalPRIFRaiseAmt));
                reportTable.add(contents);
            }
        }

        if ((totalFIXIRaiseAmt > 0) || (totalPRIFRaiseAmt > 0)) {
            List<String> contents = new ArrayList<String>();
            contents.add(timeSection);
            contents.add("");
            contents.add("");
            contents.add("");
            contents.add("金额总计");
            contents.add(AmountUtils.toString(totalFIXIRaiseAmt + totalPRIFRaiseAmt));
            reportTable.add(contents);
        }

        List<String> fieldNames = new ArrayList<String>();
        fieldNames.add("交易时间段");
        fieldNames.add("产品类型");
        fieldNames.add("产品编号");
        fieldNames.add("产品名称");
        fieldNames.add("产品状态");
        fieldNames.add("实际募集金额(元)");
        reportTable.add(0, fieldNames);

        return reportTable;
    }

    //B08 活动费用计税表
    private CommReportDataVO getActivityExpenseTaxData(ReportConditionVO reportCondition) throws BusinessException {
        if (reportCondition.getActivityType() == 3) {
               return getMarketData(reportCondition);
        }
        CommReportDataVO reportData = new CommReportDataVO();
        List<List<String>> reportTable = new ArrayList<List<String>>();
        WhereCondition where = new WhereCondition();
        if(reportCondition.getUserType().equals(ReportUserType.INVESTOR)){
            where.setCondiEx(" trade.order_bill_code= trans.trade_order_bill_code AND product.product_uuid = trade.product_uuid AND trade.user_uuid = inv.user_uuid ");
        }else{
            where.setCondiEx(" trade.order_bill_code= trans.trade_order_bill_code AND product.product_uuid = trade.product_uuid AND trade.user_uuid = eninv.user_uuid ");
        }
        if (reportCondition.getActivityType() == 1) {
            where.setCondiEx(" AND trade.marketing_amount > 0 ");
        } else if (reportCondition.getActivityType() == 2) {
            where.setCondiEx(" AND trade.product_increase_interest_rate > 0 ");
        } else if (reportCondition.getActivityType() == 4) {
            where.setCondiEx(" AND trade.coupon_interest_yield_rate > 0 ");
        }
        where.setNotInInt("trade.order_status", 1, 9);
        where.setCondiEx(" AND trans.account_type = 21 ");
        where.setCondiEx(" AND trade.delete_flag = 0 ");
        where.setCondi("trans.trade_order_bill_code_extend", reportCondition.getOrderId());
        where.setLike("trade.product_abbr_name", reportCondition.getProductAbbrName());
        where.setCondi("trade.user_name", reportCondition.getUserName());
        where.setCondi("trade.user_phone", reportCondition.getUserPhoneNumber());
        where.setCondi("trade.user_type", reportCondition.getUserType(),true);
        Date tradeBeginDate= reportCondition.getTradeBeginDate();
        Date tradeEndDate= reportCondition.getTradeEndDate();
        if(tradeBeginDate != null && tradeEndDate != null){
            where.setBetween("Date(trade.payed_time)", tradeBeginDate, tradeEndDate);
        }else if(tradeBeginDate != null && tradeEndDate == null){
            where.setCondiEx(" AND  Date(trade.payed_time) >= '" + DataUtils.toString(tradeBeginDate) + " ' ");
        }else if(tradeBeginDate == null && tradeEndDate != null){
            where.setCondiEx(" AND  Date(trade.payed_time) <= '" + DataUtils.toString(tradeEndDate) + " ' ");
        }
        Date productEstablishmentBeginDate= reportCondition.getProductEstablishmentBeginDate();
        Date productEstablishmentEndDate= reportCondition.getProductEstablishmentEndDate();
        if(productEstablishmentBeginDate != null && productEstablishmentEndDate != null){
            where.setBetween("Date(product.product_establishment_date)", productEstablishmentBeginDate, productEstablishmentEndDate);
        }else if(productEstablishmentBeginDate != null && productEstablishmentEndDate == null){
            where.setCondiEx(" AND  Date(product.product_establishment_date) >= '" + DataUtils.toString(productEstablishmentBeginDate) + " ' ");
        }else if(productEstablishmentBeginDate == null && productEstablishmentEndDate != null){
            where.setCondiEx(" AND  Date(product.product_establishment_date) <= '" + DataUtils.toString(productEstablishmentEndDate) + " ' ");
        }
        int dataCount = 0;
        if(reportCondition.getUserType().equals(ReportUserType.INVESTOR)){
            dataCount = tradeOrderMapper.listCountByConditionEx(where);
        }else{
            dataCount = tradeOrderMapper.listCountByConditionEnterprise(where);
        }
        where.setOrderByDesc(" trade.payed_time ");
        where.setPage(reportCondition.getBeginSN(), reportCondition.getEndSN());
        List<Map> dataList = null;
        if(reportCondition.getUserType().equals(ReportUserType.INVESTOR)){
           dataList = tradeOrderMapper.listByCondition(where);
        }else{
           dataList = tradeOrderMapper.listByConditionEnterprise(where);
        }
        List<String> fieldNames = new ArrayList<String>();
        fieldNames.add("tradeOrderBillCodeExtend");//订单号
        fieldNames.add("productAbbrName");//产品简称
        fieldNames.add("productEstablishmentDate");//成立时间
        fieldNames.add("userName");//用户姓名
        fieldNames.add("idCardNo");//身份证号码
        fieldNames.add("userPhone");//手机号
        fieldNames.add("payedTime");//交易时间

        //活动计税类型 1.现金券 2.产品加息 3.体验金 4.加息券
        if (reportCondition.getActivityType() == 1) {
            fieldNames.add("marketingAmount");//实发金额
        } else if (reportCondition.getActivityType() == 2) {
            fieldNames.add("interestIncrease");//实发金额
        } else if (reportCondition.getActivityType() == 4) {
            fieldNames.add("interestIncrease");//实发金额
        }
        fieldNames.add("taxAmount");//税金 总额*20%
        fieldNames.add("totalAmount");//总额 发放金额/80%
        if (dataList.size() > 0) {
            for (Map map : dataList) {
                BizParam bizParam = new BizParam(map);
                if (reportCondition.getActivityType() == 1) {//现金券
                    BigDecimal marketingAmount = bizParam.getBigDecimal("marketingAmount");
                    if (marketingAmount.equals(BigDecimal.ZERO)) {
                        map.put("marketingAmount", 0);
                        map.put("taxAmount", 0);
                        map.put("totalAmount", 0);
                    } else {
                        marketingAmount=BigDecimal.valueOf(AmountUtils.exac(marketingAmount));//格式化收益保留两位小数
                        map.put("marketingAmount",marketingAmount);
                        BigDecimal totalAmount = marketingAmount.divide(BigDecimal.valueOf(0.8), 6, BigDecimal.ROUND_HALF_EVEN);
                        totalAmount=BigDecimal.valueOf(AmountUtils.exac(totalAmount));//格式化收益保留两位小数
                        map.put("taxAmount", AmountUtils.exac(totalAmount.subtract(marketingAmount)));
                        map.put("totalAmount",totalAmount);
                    }
                } else if (reportCondition.getActivityType() == 2) {
                    // 产品加息处理
                    String jsonString = JSON.toJSONString(map);
                    TradeOrder tradeOrder = JSON.parseObject(jsonString, TradeOrder.class);
                    BigDecimal orderAmount = tradeOrder.getOrderAmount();
                    orderAmount = BigDecimal.valueOf(AmountUtils.exac(orderAmount));
                    BigDecimal couponInterestYieldRate = tradeOrder.getCouponInterestYieldRate();
                    Integer productPeriod = tradeOrder.getProductPeriod();
                    Integer couponInterestPeriod = tradeOrder.getCouponInterestPeriod();
                    if (null == couponInterestPeriod || couponInterestPeriod.intValue() == 0) {
                        couponInterestPeriod = productPeriod;
                    }

                    // 读取平台兑付收益
                    BigDecimal marketAmount = tradeOrder.getMarketingRateAmount();
                    marketAmount.setScale(2, BigDecimal.ROUND_DOWN);

                    // 计算加息券加息收益
                    BigDecimal couponInterestAmount = BigDecimal.ZERO;
                    if (couponInterestYieldRate.compareTo(BigDecimal.ZERO) > 0) {
                        // 加息券加息收益 = 订单金额×加息券面值×加息时长÷365
                        BigDecimal period = new BigDecimal(365);
                        BigDecimal addPeriod = new BigDecimal(couponInterestPeriod);
                        couponInterestAmount = orderAmount.multiply(couponInterestYieldRate).multiply(addPeriod).divide(period, 6);
                        couponInterestAmount = couponInterestAmount.setScale(2, BigDecimal.ROUND_DOWN);
                    }

                    // 产品加息收益=平台兑付收益-加息券加息收益
                    BigDecimal productAddInterestAmount = marketAmount.subtract(couponInterestAmount);
                    if (productAddInterestAmount.compareTo(BigDecimal.ZERO) > 0) {
                        BigDecimal factor = new BigDecimal(0.8);
                        BigDecimal totalAmount = productAddInterestAmount.divide(factor, 6);
                        totalAmount = totalAmount.setScale(2, BigDecimal.ROUND_DOWN);
                        BigDecimal taxAmount = totalAmount.subtract(productAddInterestAmount);
                        logger.info("interestIncrease={}, taxAmount={}, totalAmount={}", productAddInterestAmount, taxAmount, totalAmount);
                        map.put("interestIncrease", AmountUtils.exac(productAddInterestAmount));
                        map.put("taxAmount", AmountUtils.exac(taxAmount));
                        map.put("totalAmount", AmountUtils.exac(totalAmount));
                    } else {
                        map.put("interestIncrease", 0);
                        map.put("taxAmount", 0);
                        map.put("totalAmount", 0);
                    }
                } else if (reportCondition.getActivityType() == 4) {
                    // 加息券处理
                    String jsonString = JSON.toJSONString(map);
                    TradeOrder tradeOrder = JSON.parseObject(jsonString, TradeOrder.class);
                    BigDecimal orderAmount = tradeOrder.getOrderAmount();
                    orderAmount = BigDecimal.valueOf(AmountUtils.exac(orderAmount));
                    BigDecimal couponInterestYieldRate = tradeOrder.getCouponInterestYieldRate();
                    Integer productPeriod = tradeOrder.getProductPeriod();
                    Integer couponInterestPeriod = tradeOrder.getCouponInterestPeriod();
                    if (null == couponInterestPeriod || couponInterestPeriod.intValue() == 0) {
                        couponInterestPeriod = productPeriod;
                    }
                    logger.info("orderAmount={}, couponInterestYieldRate={}, couponInterestPeriod={}, productPeriod={}",
                            orderAmount, couponInterestYieldRate, couponInterestPeriod, productPeriod);

                    // 计算加息券加息收益
                    BigDecimal couponInterestAmount = BigDecimal.ZERO;
                    if (couponInterestYieldRate.compareTo(BigDecimal.ZERO) > 0) {
                        // 加息券加息收益 = 订单金额×加息券面值×加息时长÷365
                        BigDecimal period = new BigDecimal(365);
                        BigDecimal addPeriod = new BigDecimal(couponInterestPeriod);
                        couponInterestAmount = orderAmount.multiply(couponInterestYieldRate).multiply(addPeriod).divide(period, 6);
                        couponInterestAmount = couponInterestAmount.setScale(2, BigDecimal.ROUND_DOWN);
                    }
                    logger.info("couponInterestAmount={}", couponInterestAmount);

                    if (couponInterestAmount.compareTo(BigDecimal.ZERO) > 0) {
                        BigDecimal factor = new BigDecimal(0.8);
                        BigDecimal totalAmount = couponInterestAmount.divide(factor, 6);
                        totalAmount = totalAmount.setScale(2, BigDecimal.ROUND_DOWN);
                        BigDecimal taxAmount = totalAmount.subtract(couponInterestAmount);
                        logger.info("interestIncrease={}, taxAmount={}, totalAmount={}", couponInterestAmount, taxAmount, totalAmount);
                        map.put("interestIncrease", couponInterestAmount);
                        map.put("taxAmount", taxAmount);
                        map.put("totalAmount", totalAmount);
                    } else {
                        map.put("interestIncrease", 0);
                        map.put("taxAmount", 0);
                        map.put("totalAmount", 0);
                    }
                }
                List<String> contents = new ArrayList<String>();
                for (String fieldName : fieldNames) {
                    contents.add(ReportUtils.getValue(fieldName, bizParam.get(fieldName)));
                }
                reportTable.add(contents);
            }
        }
        reportData.setItems(reportTable);
        reportData.setTotalCount(dataCount);
        return reportData;
    }

    private CommReportDataVO getMarketData(ReportConditionVO reportCondition) throws BusinessException {
        CommReportDataVO reportData = new CommReportDataVO();
        List<List<String>> reportTable = new ArrayList<List<String>>();
        WhereCondition where = new WhereCondition();
        where.setCondi("exper.experience_code", reportCondition.getOrderId());
        where.setLike("exper.experience_name", reportCondition.getProductAbbrName());
        where.setCondi("exper.investor_real_name", reportCondition.getUserName());
        where.setCondi("exper.investor_mobile", reportCondition.getUserPhoneNumber());
        where.setCondi("exper.experience_status", 6);
        Date tradeBeginDate= reportCondition.getTradeBeginDate();
        Date tradeEndDate= reportCondition.getTradeEndDate();
        if(tradeBeginDate != null && tradeEndDate != null){
            where.setBetween("Date(exper.start_rate_time)", reportCondition.getTradeBeginDate(), reportCondition.getTradeEndDate());
        }else if(tradeBeginDate != null && tradeEndDate == null){
            where.setCondiEx(" AND  Date(exper.start_rate_time) >= '" + DataUtils.toString(tradeBeginDate) + "'");
        }else if(tradeBeginDate == null && tradeEndDate != null){
            where.setCondiEx(" AND  Date(exper.start_rate_time) <= '" + DataUtils.toString(tradeEndDate) + "'");
        }
        int dataCount = tradeOrderMapper.listMarketCountByCondition(where);
        where.setOrderByDesc(" exper.start_rate_time ");
        where.setPage(reportCondition.getBeginSN(), reportCondition.getEndSN());
        List<Map> dataList = tradeOrderMapper.listMarketByCondition(where);

        List<String> fieldNames = new ArrayList<String>();
        fieldNames.add("experience_code");//订单号
        fieldNames.add("experience_name");//产品简称
        fieldNames.add("productInterestDate");//产品成立时间、这里只用于占位，无实际数据
        fieldNames.add("investor_real_name");//用户姓名
        fieldNames.add("investor_id_card_no");//身份证号码
        fieldNames.add("investor_mobile");//手机号
        fieldNames.add("start_rate_time");//交易时间
        fieldNames.add("interestIncrease");//实发金额
        fieldNames.add("taxAmount");//税金 总额*20%
        fieldNames.add("totalAmount");//总额 发放金额/80%
        if (dataList.size() > 0) {
            for (Map map : dataList) {
                BizParam bizParam = new BizParam(map);
                BigDecimal annualInterestRate = bizParam.getBigDecimal("annual_interest_rate");//年化收益率
                BigDecimal experienceAmount = bizParam.getBigDecimal("experience_amount");//体验金金额
                Integer RateDays = bizParam.getInt("rate_days");//计息天数
                BigDecimal result = (experienceAmount.multiply(annualInterestRate).multiply(BigDecimal.valueOf(RateDays))).divide(BigDecimal.valueOf(365),6, BigDecimal.ROUND_HALF_EVEN);//到期收益
                result=BigDecimal.valueOf(AmountUtils.exac(result));//格式化收益保留两位小数
                BigDecimal totalAmount = result.divide(BigDecimal.valueOf(0.8), 6, BigDecimal.ROUND_HALF_EVEN);
                totalAmount=BigDecimal.valueOf(AmountUtils.exac(totalAmount));
                map.put("interestIncrease",result);
                map.put("taxAmount",AmountUtils.exac(totalAmount.subtract(result)));
                map.put("totalAmount",totalAmount);
                List<String> contents = new ArrayList<String>();
                for (String fieldName : fieldNames) {
                    contents.add(ReportUtils.getValue(fieldName, bizParam.get(fieldName)));
                }
                reportTable.add(contents);
            }
        }
        reportData.setItems(reportTable);
        reportData.setTotalCount(dataCount);
        return reportData;
    }
     //B09 交易所投资明细表
    private CommReportDataVO getExchangeInvestmentDetailsData(ReportConditionVO reportCondition) throws BusinessException {
        CommReportDataVO reportData = new CommReportDataVO();
        List<List<String>> reportTable = new ArrayList<List<String>>();
        WhereCondition where = new WhereCondition();
        where.setCondiEx(" fixed.product_uuid=trade.product_uuid ");
        where.setNotInInt("trade.order_status", 1, 9);
        where.setCondiEx(" AND trade.delete_flag = 0 ");
        where.setLike("fixed.product_abbr_name", reportCondition.getProductAbbrName());
        where.setLike("fixed.product_attachment", reportCondition.getFileCode());
        where.setCondi("trade.user_name", reportCondition.getUserName());
        Date tradeBeginDate= reportCondition.getTradeBeginDate();
        Date tradeEndDate= reportCondition.getTradeEndDate();
        if(tradeBeginDate != null && tradeEndDate != null){
            where.setBetween("Date(trade.payed_time)", reportCondition.getTradeBeginDate(), reportCondition.getTradeEndDate());
        }else if(tradeBeginDate != null && tradeEndDate == null){
            where.setCondiEx(" AND  Date(trade.payed_time) >= '" + DataUtils.toString(tradeBeginDate) + "'");
        }else if(tradeBeginDate == null && tradeEndDate != null){
            where.setCondiEx(" AND  Date(trade.payed_time) <= '" + DataUtils.toString(tradeEndDate) + "'");
        }
//        if(DataUtils.isNotEmpty(reportCondition.getFileCode())){
//            WhereCondition productWhere = new WhereCondition();
//            productWhere.setLike("product_attachment",reportCondition.getFileCode());
//            List<String> productUuids=tradeOrderMapper.listProductByCondition(productWhere);
//            where.setInString("product_uuid",productUuids);
//        }
        int dataCount = tradeOrderMapper.listProAndTradeCountByCondition(where);
        where.setOrderByDesc(" payed_time ");
        if(reportCondition.getExportExcel()==0){
            where.setPage(reportCondition.getBeginSN(), reportCondition.getEndSN());
        }
        List<Map> dataList = tradeOrderMapper.listProAndTradeByCondition(where);
        List<String> fieldNames = new ArrayList<String>();
        fieldNames.add("fileCode");//附件编号
        fieldNames.add("product_abbr_name");//产品简称
        fieldNames.add("user_name");//投资人姓名
        fieldNames.add("idCardNo");//证件号码
        fieldNames.add("order_amount");//认购金额(元)
        fieldNames.add("product_period");//产品期限(天)
        fieldNames.add("payed_time");//认购日期
        fieldNames.add("product_interest_date");//起息日
        fieldNames.add("product_expiring_date");//到期日
        if (dataList.size() > 0) {
            for (Map map : dataList) {
                BizParam bizParam = new BizParam(map);
                if(map.get("payed_time")!=null){
                    map.put("payed_time",bizParam.getDateStr("payed_time"));
                }
                if(map.get("product_interest_date")!=null){
                    map.put("product_interest_date",DateUtil.convertInt2Date(bizParam.getInt("product_interest_date")));
                }
                if(map.get("product_expiring_date")!=null){
                    map.put("product_expiring_date",DateUtil.convertInt2Date(bizParam.getInt("product_expiring_date")));
                }
                Map user = getUser(map.get("user_uuid").toString());
                if (user != null) {
                    BizParam userParam = new BizParam(user);
                    String userType = userParam.get("userType");
                    if (userType.equals("1")) {
                        map.put("idCardNo", userParam.get("investorIdCardNo"));
                    } else if (userType.equals("3")) {
                        map.put("idCardNo", userParam.get("legalPersonIdCardNo"));
                    }
                }
//                Map product = getProductInfo(map.get("product_uuid").toString());
                    if (DataUtils.isNotEmpty(bizParam.get("product_attachment"))) {
                        JSONArray attachmentArray = JSONArray.parseArray(bizParam.get("product_attachment").toString());
                        String attachmentCode = "";
                        if(attachmentArray != null){
                            for (int i = 0; i < attachmentArray.size(); i++) {
                                attachmentCode = (attachmentArray.getJSONObject(0).getString("attachmentCode")==null )? "" : attachmentArray.getJSONObject(0).getString("attachmentCode");
                            }
                            map.put("fileCode", attachmentCode);
                        }
                    }
                List<String> contents = new ArrayList<String>();
                for (String fieldName : fieldNames) {
                    contents.add(ReportUtils.getValue(fieldName, bizParam.get(fieldName)));
                }
                reportTable.add(contents);
            }
        }
        reportData.setItems(reportTable);
        reportData.setTotalCount(dataCount);
        return reportData;
    }


    /**
     * 获取用户信息
     *
     * @param userUuid
     * @return
     * @throws BusinessException
     */
    private Map getUser(String userUuid) throws BusinessException {
        Map params = new HashMap();
        params.put("properties", "userUuid$$userType$$investorOrganizationUuid$$investorMobile$$investorRealName" +
                "$$userStatus$$userVerifyStatus");
        ResponseResult result = userServiceConsumer.get(String.format(URL.URL_GET_USER, userUuid), params);
        if (result.isSuccessful()) {
            return (Map) result.getData();
        } else {
            return null;
        }
    }

    /**
     * 获取产品信息
     *
     * @param productUuid
     * @return
     * @throws BusinessException
     */
    private Map getProductInfo(String productUuid) throws BusinessException {
        Map params = new HashMap();
        ResponseResult result = productClient.getFixedIncome(productUuid, params);
        if (result.isSuccessful()) {
            return (Map) result.getData();
        } else {
            return null;
        }
    }

    /**
     * 通用报表数据生成
     *
     * @param reportCondition
     * @return
     * @throws BusinessException
     */
    public CommReportDataVO commReportEx(ReportConditionVO reportCondition) throws BusinessException {
        CommReportDataVO reportData = new CommReportDataVO();

        //产品销售明细表
        if (reportCondition.getReportNo().trim().equals("B05")) {
            reportData.setItems(getProductSaleItems(reportCondition));
            reportData.setTotalCount(reportData.getItems().size() - 1);
            return reportData;
        }

        //三方手续费汇总表
        if (reportCondition.getReportNo().trim().equals("B06")) {
            reportData.setItems(getRechargeFeeData(reportCondition));
            reportData.setTotalCount(reportData.getItems().size() - 1);
            return reportData;
        }

        //活动费用计税表
        if (reportCondition.getReportNo().trim().equals("B08")) {
            return getActivityExpenseTaxData(reportCondition);
        }

        //交易所投资明细表
        if (reportCondition.getReportNo().trim().equals("B09")) {
            return getExchangeInvestmentDetailsData(reportCondition);
        }

        if (DataUtils.isContain(reportCondition.getReportNo(), "B0101", "B0201", "B0301", "B0401")
                && DataUtils.isNotEmpty(reportCondition.getProductUuid())) {
            ProductFixedIncome productInfo = getFixedIncomeProductById(reportCondition.getProductUuid());
            reportData.setTitle("[" + productInfo.getProductAbbrName() + "]订单明细");
        } else if (DataUtils.isContain(reportCondition.getReportNo(), "B0701")) {
            UserInfo userInfo = getUserInfo(reportCondition.getUserUuid());
            String userName = (null != userInfo) ? (userInfo.getInvestorRealName()) : "";
            reportData.setTitle("[" + userName + "]订单明细");
        }

        int batchNo = 1;
        //可根据查询条件，选择不同的批次
        OperationReport operationReport = lstReportRuleStr(reportCondition.getReportNo(), batchNo);
        if ((operationReport == null) || DataUtils.isEmpty(operationReport.getReportRule())) {
            throw new BusinessException(TradeStatusMsg.REPORT_UNDEFINED_ERR, TradeStatusMsg.REPORT_UNDEFINED_ERR_MSG, false);
        }

        ReportUtils reportUtils = new ReportUtils(operationReport.getReportRule());
        reportUtils.processWildCard(reportCondition);

        reportData.setTotalCount(lstQueryDataCount(reportUtils.getCondition()));
        List<Map> mapList = operationReportMapper.lstReportData(reportUtils);
        List<List<String>> reportTable = new ArrayList<List<String>>();

        if (mapList.size() > 0) {
            List<String> fieldNames = reportUtils.getFieldNames();

            for (Map map : mapList) {
                BizParam bizParam = new BizParam(map);
                List<String> contents = new ArrayList<String>();
                for (String fieldName : fieldNames) {
                    contents.add(ReportUtils.getValue(fieldName, bizParam.get(fieldName)));
                }
                reportTable.add(contents);
            }
        }

        reportTable.add(0, reportUtils.getFilterFieldNames());

        reportData.setItems(reportTable);
        return reportData;
    }
}
