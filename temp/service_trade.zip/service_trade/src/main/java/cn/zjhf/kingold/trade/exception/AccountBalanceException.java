package cn.zjhf.kingold.trade.exception;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.constant.TradeStatusMsg;

import java.util.Map;

/**
 * 账户余额不足
 *
 * @author lutiehua
 * @date 2018/3/9
 */
public class AccountBalanceException extends BusinessException {

    public AccountBalanceException(Map<String, Object> info) {
        super(TradeStatusMsg.BALANCE_INSUFFICIENT_CODE, TradeStatusMsg.BALANCE_INSUFFICIENT_MSG, info, true);
    }
}
