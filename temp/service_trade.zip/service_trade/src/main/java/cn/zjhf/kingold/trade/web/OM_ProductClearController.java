package cn.zjhf.kingold.trade.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.entity.InVO.*;
import cn.zjhf.kingold.trade.entity.OutVO.*;
import cn.zjhf.kingold.trade.persistence.dao.TradeOrderMapper;
import cn.zjhf.kingold.trade.persistence.mq.message.ContractFillMessage;
import cn.zjhf.kingold.trade.persistence.mq.producer.ContractFillProducer;
import cn.zjhf.kingold.trade.service.IProductEndService;
import cn.zjhf.kingold.trade.service.IProductEstablishService;
import cn.zjhf.kingold.trade.service.IProductManagerService;
import cn.zjhf.kingold.trade.service.ITradeService;
import cn.zjhf.kingold.trade.utils.BizParam;
import cn.zjhf.kingold.trade.utils.DataUtils;
import cn.zjhf.kingold.trade.vo.LoanCashedDetailVO;
import com.alibaba.fastjson.JSON;
import com.google.common.base.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Created by zhangyijie on 2017/5/13.
 */
@RestController
@RequestMapping(value = "/om_productclear")
public class OM_ProductClearController {
    protected static final Logger logger = LoggerFactory.getLogger(OM_ProductClearController.class);

    @Autowired
    IProductEstablishService productEstablishService;

    @Autowired
    IProductEndService productEndService;

    @Autowired
    IProductManagerService productManagerService;

    @Autowired
    ITradeService tradeServiceImpl;

    @Autowired
    ContractFillProducer contractFillProducer;

    @Autowired
    TradeOrderMapper tradeOrderMapper;

    private ResponseResult creatOKRespResult(String traceID) {
        ResponseResult respResult = new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS,"成功");
        return respResult;
    }

    private ResponseResult creatOKRespResult(String traceID, Object data) {
        ResponseResult respResult = new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS,"成功", data);
        return respResult;
    }

    /**
     * Step1 产品成立
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/productEstablish", method = RequestMethod.POST)
    public ResponseResult productEstablish(@RequestBody ProductUuidVO productUuidVO) throws BusinessException {
        logger.info("fixedProductEstablish start: " + DataUtils.toString(productUuidVO));

        DataUtils.checkParam(productUuidVO.getProduct_uuid());
        productEstablishService.productEstablish(productUuidVO.getProduct_uuid(), productUuidVO.getProductType(), productUuidVO.getCreateBy());

        logger.info("fixedProductEstablish end: " + DataUtils.toString(productUuidVO.getTraceID()));
        return creatOKRespResult(productUuidVO.getTraceID());
    }

    /**
     * Step2 产品成立_放款查询(维度:产品，列表)
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/lstProductEstablishLoan", method = RequestMethod.GET)
    public ResponseResult lstProductEstablishLoan(@RequestParam Map<String, Object> param) throws BusinessException {
        String jsonString = JSON.toJSONString(param);
        LstProductEstablishLoanVO lstProductEstablishLoanVO = JSON.parseObject(jsonString, LstProductEstablishLoanVO.class);
        logger.info("lstProductEstablishLoan start: " + DataUtils.toString(lstProductEstablishLoanVO));

        TradeInvestSummaryListVO tradeInvestSummaryListVO = productEstablishService.lstProductEstablishLoan(lstProductEstablishLoanVO);

        logger.info("lstProductEstablishLoan end: " + DataUtils.toString(lstProductEstablishLoanVO.getTraceID(), tradeInvestSummaryListVO));
        return creatOKRespResult(lstProductEstablishLoanVO.getTraceID(), tradeInvestSummaryListVO);
    }

    /**
     * Step3 产品成立_放款详情(维度:产品，单记录)
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/getProductEstablishLoanDetail", method = RequestMethod.GET)
    public ResponseResult getProductEstablishLoanDetail(@RequestParam String traceID, @RequestParam String productUuid) throws BusinessException {
        logger.info("getProductEstablishLoanDetail start:{} " , DataUtils.toString(traceID, productUuid));
        TradeInvestSummaryExVO tradeInvestSummaryExVO = productEstablishService.getProductEstablishLoanDetail(productUuid);
        logger.info("getProductEstablishLoanDetail end: {}" , DataUtils.toString(traceID, tradeInvestSummaryExVO));
        return creatOKRespResult(traceID, tradeInvestSummaryExVO);
    }

    /**
     * Step4 产品成立_放款明细(维度:产品-交易，列表)
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/lstProductEstablishLoanItems", method = RequestMethod.GET)
    public ResponseResult lstProductEstablishLoanItems(LstProductEstablishLoanItemsVO vo) throws BusinessException {
        logger.info("lstProductEstablishLoanItems start: {}" + DataUtils.toString(vo));
        CommItemListVO<LoanCashedDetailVO> loanDeail = productEstablishService.lstProductEstablishLoanItems(vo);
        logger.info("lstProductEstablishLoanItems end: {}" ,DataUtils.toString(vo.getTraceID(), loanDeail));
        return creatOKRespResult(vo.getTraceID(), loanDeail);
    }

    /**
     * Step5 产品成立_放款_审核
     * isAudited：1审核通过  0审核未通过
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/productEstablishLoanAudit", method = RequestMethod.PUT)
    public ResponseResult productEstablishLoanAudit(@RequestBody ProductClearParamVO productClearParamVO) throws BusinessException {
        logger.info("productEstablishLoanAudit start: " + DataUtils.toString(productClearParamVO));
        DataUtils.checkParam(productClearParamVO.getProduct_uuid());

        productEstablishService.productEstablishLoanAudit(productClearParamVO.getUserPhone(), productClearParamVO.getProduct_uuid(), productClearParamVO.getIsAudited(), productClearParamVO.getMessage());
        logger.info("productEstablishLoanAudit end: " + DataUtils.toString(productClearParamVO.getTraceID()));
        return creatOKRespResult(productClearParamVO.getTraceID());
    }

    /**
     * Step6 产品成立_放款_结算
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/productEstablishLoanClear", method = RequestMethod.POST)
    public ResponseResult productEstablishLoanClear(@RequestBody ProductClearParamVO productClearParamVO) throws BusinessException {
        logger.info("productEstablishLoanClear start: " + DataUtils.toString(productClearParamVO));
        DataUtils.checkParam(productClearParamVO.getProduct_uuid());

        //锁定该条记录
        //productEstablishService.lockTradePayment(productClearParamVO.getProduct_uuid());
        TradeInvestSummaryExVO tradeInvestSummaryExVO = null;
        try {
            tradeInvestSummaryExVO = productEstablishService.productEstablishLoanClear(productClearParamVO.getUserPhone(), productClearParamVO.getProduct_uuid(), productClearParamVO.getCreateBy());
        }catch(BusinessException e) {
            throw(e);
        }finally {
            //退出时，检测是否仍然是锁定状态，如果是，则解锁为待审核状态
            //productEstablishService.unLockTradePayment(productClearParamVO.getProduct_uuid());
        }

        //生成电子合同
        logger.info("tradeServiceImpl.contractFill_start: " + DataUtils.toString(productClearParamVO.getProduct_uuid()));
        ContractFillMessage contractFillMessage = new ContractFillMessage();
        contractFillMessage.setProductUuid(productClearParamVO.getProduct_uuid());
        contractFillProducer.send(contractFillMessage);

        //tradeServiceImpl.contractFill(productClearParamVO.getProduct_uuid());
        logger.info("tradeServiceImpl.contractFill_end: " + DataUtils.toString(productClearParamVO.getProduct_uuid()));

        // 产品成立消息
        // TODO 消费太快
//        String productUUId = productClearParamVO.getProduct_uuid();
//        logger.info("发送产品成立放款消息：{}", productUUId);
//        ProductEstablishLoanTopic productEstablishLoanTopic = new ProductEstablishLoanTopic(productUUId);
//        try {
//            Message message = productEstablishLoanTopic.toMessage();
//            SendResult sendResult = mqProducer.send(message);
//            if (sendResult.getSendStatus() == SendStatus.SEND_OK) {
//                logger.info("发送产品成立放款消息成功");
//            } else {
//                logger.error("发送产品成立放款消息失败：{}", sendResult.getSendStatus().name());
//            }
//        } catch (Exception e) {
//            logger.error("发送产品成立放款消息异常：{}", e.getMessage());
//        }

        logger.info("productEstablishLoanClear end: " + DataUtils.toString(productClearParamVO.getTraceID(), tradeInvestSummaryExVO));
        return creatOKRespResult(productClearParamVO.getTraceID(), tradeInvestSummaryExVO);
    }

    /**
     * Step10 产品进入封闭期
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/productBeginClosedPeriod", method = RequestMethod.PUT)
    public ResponseResult productBeginClosedPeriod(@RequestBody ProductUuidVO productUuidVO) throws BusinessException {
        logger.info("productBeginClosedPeriod start: " + DataUtils.toString(productUuidVO));

        DataUtils.checkParam(productUuidVO.getProduct_uuid(), productUuidVO.getProductType());
        productManagerService.productBeginClosedPeriod(productUuidVO.getProduct_uuid(), productUuidVO.getProductType(), productUuidVO.getCreateBy());

        logger.info("productBeginClosedPeriod end: " + DataUtils.toString(productUuidVO.getTraceID()));
        return creatOKRespResult(productUuidVO.getTraceID());
    }

    /**
     * Step10 产品进入存续期
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/productBeginDuration", method = RequestMethod.PUT)
    public ResponseResult productBeginDuration(@RequestBody ProductUuidVO productUuidVO) throws BusinessException {
        logger.info("productBeginDuration start: " + DataUtils.toString(productUuidVO));

        DataUtils.checkParam(productUuidVO.getProduct_uuid(), productUuidVO.getProductType());
        productManagerService.productBeginDuration(productUuidVO.getProduct_uuid(), productUuidVO.getProductType(), productUuidVO.getCreateBy());

        logger.info("productBeginDuration end: " + DataUtils.toString(productUuidVO.getTraceID()));
        return creatOKRespResult(productUuidVO.getTraceID());
    }

    /**
     * Step11 产品到期
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/productEnd", method = RequestMethod.POST)
    public ResponseResult productEnd(@RequestBody ProductUuidVO productUuidVO) throws BusinessException {
        logger.info("productEnd start: " + DataUtils.toString(productUuidVO));

        DataUtils.checkParam(productUuidVO.getProduct_uuid());
        productEndService.privateProductEnd(productUuidVO.getProduct_uuid(), productUuidVO.getCreateBy());

        logger.info("productEnd end: " + DataUtils.toString(productUuidVO.getTraceID()));
        return creatOKRespResult(productUuidVO.getTraceID());
    }

    /**
     * 发送产品到期发放礼券的
     * @param params
     * @return
     */
    @RequestMapping(value = "/sendProductEndCashCouponMess", method = RequestMethod.GET)
    public ResponseResult sendProductEndCashCouponMess(@RequestParam Map params) {
        logger.info("sendProductEndCashCouponMess start: " + DataUtils.toString(params));
        String traceID = new BizParam(params).getString("traceID");

        try {
            productEndService.sendCashCouponMess();
        }catch(BusinessException e) {
            logger.error("sendCashCouponMess Exception{}", e);
        }

        logger.info("sendProductEndCashCouponMess end: " + traceID);
        return creatOKRespResult(traceID);
    }

    /**
     * Step12 产品到期_兑付查询(维度:产品，列表)
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/lstProductExpireCash", method = RequestMethod.GET)
    public ResponseResult lstProductExpireCash(@RequestParam Map<String, Object> param) throws BusinessException {
        String jsonString = JSON.toJSONString(param);
        LstProductExpireCashVO lstProductExpireCashVO = JSON.parseObject(jsonString, LstProductExpireCashVO.class);
        logger.info("lstProductExpireCash start: " + DataUtils.toString(lstProductExpireCashVO));

        TradePaymentSummaryListVO tradePaymentSummaryListVO = productEndService.lstProductExpireCash(lstProductExpireCashVO);

        logger.info("lstProductExpireCash end: " + DataUtils.toString(lstProductExpireCashVO.getTraceID(), tradePaymentSummaryListVO));
        return creatOKRespResult(lstProductExpireCashVO.getTraceID(), tradePaymentSummaryListVO);
    }

    /**
     * Step13 产品到期_兑付详情(维度:产品，单记录)
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/getProductExpireCashDetail", method = RequestMethod.GET)
    public ResponseResult getProductExpireCashDetail(@RequestParam String traceID, @RequestParam String productUuid) throws BusinessException {
        logger.info("getProductExpireCashDetail start: {}" ,DataUtils.toString(traceID, productUuid));
        DataUtils.checkParam(productUuid);
        TradePaymentSummaryExVO tradePaymentSummaryExVO = productEndService.getProductExpireCashDetail(productUuid);
        logger.info("getProductExpireCashDetail end: {}" ,DataUtils.toString(traceID, tradePaymentSummaryExVO));
        return creatOKRespResult(traceID, tradePaymentSummaryExVO);
    }

    /**
     * Step14 产品到期_兑付明细(维度:产品-交易，列表)
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/lstProductExpireCashItems", method = RequestMethod.GET)
    public ResponseResult lstProductExpireCashItems(LstProductExpireCashItemsVO vo) throws BusinessException {
        logger.info("lstProductExpireCashItems start: {}" , DataUtils.toString(vo));
        CommItemListVO<LoanCashedDetailVO> cashDeail = productEndService.lstProductExpireCashItems(vo);
        logger.info("lstProductExpireCashItems end: {}" , DataUtils.toString(cashDeail));
        return  creatOKRespResult(vo.getTraceID(), cashDeail);
    }

    /**
     * Step15 产品到期_兑付_审核
     * @return
     * isAudited：1审核通过  0审核未通过
     * @throws BusinessException
     */
    @RequestMapping(value = "/productExpireCashAudit", method = RequestMethod.PUT)
    public ResponseResult productExpireCashAudit(@RequestBody ProductClearParamVO productClearParamVO) throws BusinessException {
        logger.info("productExpireCashAudit start: " + DataUtils.toString(productClearParamVO));

        DataUtils.checkParam(productClearParamVO.getProduct_uuid());
        productEndService.productExpireCashAudit(productClearParamVO.getUserPhone(), productClearParamVO.getProduct_uuid(), productClearParamVO.getIsAudited(), productClearParamVO.getMessage());

        logger.info("productExpireCashAudit end: " + DataUtils.toString(productClearParamVO.getTraceID()));
        return creatOKRespResult(productClearParamVO.getTraceID());
    }

    /**
     * Step16 产品到期_兑付_清算
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/productExpireCashClear", method = RequestMethod.POST)
    public ResponseResult productExpireCashClear(@RequestBody ProductClearParamVO productClearParamVO) throws BusinessException {
        logger.info("productExpireCashClear start: " + DataUtils.toString(productClearParamVO));

        DataUtils.checkParam(productClearParamVO.getProduct_uuid());
        TradePaymentSummaryExVO tradePaymentSummaryExVO = productEndService.productExpireCashClear(productClearParamVO.getUserPhone(), productClearParamVO.getProduct_uuid(), productClearParamVO.getCreateBy());

        logger.info("productExpireCashClear end: " + DataUtils.toString(productClearParamVO.getTraceID(), tradePaymentSummaryExVO));
        return creatOKRespResult(productClearParamVO.getTraceID(), tradePaymentSummaryExVO);
    }

    /**
     * 固收产品确认
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/fixedProductConfirm", method = RequestMethod.PUT)
    public ResponseResult fixedProductConfirm(@RequestBody ProductUuidVO productUuidVO) throws BusinessException {
        logger.info("fixedProductConfirm start: " + DataUtils.toString(productUuidVO));

        DataUtils.checkParam(productUuidVO.getProduct_uuid());
        productManagerService.fixedProductConfirm(productUuidVO.getProduct_uuid(), productUuidVO.getCreateBy());

        logger.info("fixedProductConfirm end: " + DataUtils.toString(productUuidVO.getTraceID()));
        return creatOKRespResult(productUuidVO.getTraceID());
    }

    /**
     * 固收产品作废
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/fixedProductAbort", method = RequestMethod.PUT)
    public ResponseResult fixedProductAbort(@RequestBody ProductUuidVO productUuidVO) throws BusinessException {
        logger.info("fixedProductAbort start: " + DataUtils.toString(productUuidVO));

        DataUtils.checkParam(productUuidVO.getProduct_uuid());
        productManagerService.fixedProductAbort(productUuidVO.getProduct_uuid(), productUuidVO.getCreateBy());

        logger.info("fixedProductAbort end: " + DataUtils.toString(productUuidVO.getTraceID()));
        return creatOKRespResult(productUuidVO.getTraceID());
    }

    /**
     * 周期性自动更新固收产品的状态
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/autoUpdateFixedProductStatus", method = RequestMethod.GET)
    public ResponseResult autoUpdateFixedProductStatus(@RequestParam Map params) throws BusinessException {
        logger.info("autoUpdateFixedProductStatus start: " + DataUtils.toString(params));

        productManagerService.autoUpdateFixedProductStatus();

        String traceID = new BizParam(params).getString("traceID");
        logger.info("autoUpdateFixedProductStatus end: " + DataUtils.toString(traceID));
        return creatOKRespResult(traceID);
    }

    /**
     * 产品提前到期
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/advanceProductEnd", method = RequestMethod.PUT)
    public ResponseResult advanceProductEnd(@RequestBody ProductUuidVO productUuidVO) throws BusinessException {
        logger.info("advanceProductEnd start: " + DataUtils.toString(productUuidVO));

        DataUtils.checkParam(productUuidVO.getProduct_uuid());
        productManagerService.advanceProductEnd(productUuidVO.getProduct_uuid(), productUuidVO.getCreateBy());

        logger.info("advanceProductEnd end: " + DataUtils.toString(productUuidVO.getTraceID()));
        return creatOKRespResult(productUuidVO.getTraceID());
    }

    /**
     * 产品提前到期Hotfix20180612，解决加息券问题
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/advanceProductEndFix", method = RequestMethod.GET)
    public ResponseResult advanceProductEndFix(@RequestParam String productUuid) throws BusinessException {

        if (Strings.isNullOrEmpty(productUuid)) {
            logger.info("advanceProductEndFix product is null");

            List<String> productUuidList = tradeOrderMapper.getFixProductUuidList(4);
            for (String product : productUuidList) {
                logger.info("advanceProductEndFix start: " + product);
                tradeServiceImpl.advanceProductEndFix(product);
                logger.info("advanceProductEndFix end: " + product);
            }
        } else {
            logger.info("advanceProductEndFix start: " + productUuid);
            tradeServiceImpl.advanceProductEndFix(productUuid);
            logger.info("advanceProductEndFix end: " + productUuid);
        }

        return creatOKRespResult("");
    }

    /**
     * 定时更新更新固收产品的状态
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/fixedTimeUpdateFixedProductStatus", method = RequestMethod.GET)
    public ResponseResult fixedTimeUpdateFixedProductStatus(@RequestParam Map params) throws BusinessException {
        logger.info("fixedTimeUpdateFixedProductStatus start: " + DataUtils.toString(params));

        productManagerService.fixedTimeUpdateFixedProductStatus();

        String traceID = new BizParam(params).getString("traceID");
        logger.info("fixedTimeUpdateFixedProductStatus end: " + DataUtils.toString(traceID));
        return creatOKRespResult(traceID);
    }

    /**
     * Step21 产品开始募集
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/productBeginRasie", method = RequestMethod.PUT)
    public ResponseResult productBeginRasie(@RequestBody ProductUuidVO productUuidVO) throws BusinessException {
        logger.info("productBeginRasie start: " + DataUtils.toString(productUuidVO));

        DataUtils.checkParam(productUuidVO.getProduct_uuid(), productUuidVO.getProductType());
        productManagerService.productBeginRasie(productUuidVO.getProduct_uuid(), productUuidVO.getProductType(), productUuidVO.getCreateBy());

        logger.info("productBeginRasie end: " + DataUtils.toString(productUuidVO.getTraceID()));
        return creatOKRespResult(productUuidVO.getTraceID());
    }

    /**
     * Step22 产品结束募集
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/productEndRasie", method = RequestMethod.PUT)
    public ResponseResult productEndRasie(@RequestBody ProductUuidVO productUuidVO) throws BusinessException {
        logger.info("productEndRasie start: " + DataUtils.toString(productUuidVO));

        DataUtils.checkParam(productUuidVO.getProduct_uuid(), productUuidVO.getProductType());
        productManagerService.productEndRasie(productUuidVO.getProduct_uuid(), productUuidVO.getProductType(), productUuidVO.getCreateBy());

        logger.info("productEndRasie end: " + DataUtils.toString(productUuidVO.getTraceID()));
        return creatOKRespResult(productUuidVO.getTraceID());
    }

    /**
     * Step23 产品上架
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/productShelvesOn", method = RequestMethod.PUT)
    public ResponseResult productShelvesOn(@RequestBody ProductUuidVO productUuidVO) throws BusinessException {
        logger.info("productShelvesOn start: " + DataUtils.toString(productUuidVO));

        DataUtils.checkParam(productUuidVO.getProduct_uuid(), productUuidVO.getProductType());
        productManagerService.productShelvesOn(productUuidVO.getProduct_uuid(), productUuidVO.getProductType(), productUuidVO.getCreateBy());

        logger.info("productShelvesOn end: " + DataUtils.toString(productUuidVO.getTraceID()));
        return creatOKRespResult(productUuidVO.getTraceID());
    }

    /**
     * Step24 产品下架
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/productShelvesOff", method = RequestMethod.PUT)
    public ResponseResult productShelvesOff(@RequestBody ProductUuidVO productUuidVO) throws BusinessException {
        logger.info("productShelvesOff start: " + DataUtils.toString(productUuidVO));

        DataUtils.checkParam(productUuidVO.getProduct_uuid(), productUuidVO.getProductType());
        productManagerService.productShelvesOff(productUuidVO.getProduct_uuid(), productUuidVO.getProductType(), productUuidVO.getCreateBy());

        logger.info("productShelvesOff end: " + DataUtils.toString(productUuidVO.getTraceID()));
        return creatOKRespResult(productUuidVO.getTraceID());
    }

    /**
     * 查询募集金额
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/lstRaiseAmount", method = RequestMethod.GET)
    public ResponseResult lstRaiseAmount(@RequestParam String traceID, @RequestParam String productUUId, @RequestParam String productType) throws BusinessException {
        logger.info("lstRaiseAmount start: " + DataUtils.toString(traceID, productUUId) + ", " + DataUtils.toString(productType));

        DataUtils.checkParam(productUUId, productType);
        ProductRaiseProgressVO productRaiseProgressVO = productManagerService.lstRaiseAmount(productUUId, productType);

        logger.info("lstRaiseAmount end: " + DataUtils.toString(traceID, productRaiseProgressVO));
        return creatOKRespResult(traceID, productRaiseProgressVO);
    }

    /**
     * 更新募集金额
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/updateRaiseAmount", method = RequestMethod.PUT)
    public ResponseResult updateRaiseAmount(@RequestBody UpdateProductRaiseProgressVO updateProductRaiseProgressVO) throws BusinessException {
        logger.info("updateRaiseAmount start: " + DataUtils.toString(updateProductRaiseProgressVO));

        DataUtils.checkParam(updateProductRaiseProgressVO.getProduct_uuid(), updateProductRaiseProgressVO.getProductType());
        productManagerService.updateRaiseAmount(updateProductRaiseProgressVO.getProduct_uuid(), updateProductRaiseProgressVO.getProductType(), updateProductRaiseProgressVO.getUserPhone(), updateProductRaiseProgressVO.getAmount(), updateProductRaiseProgressVO.getCreateBy());

        logger.info("updateRaiseAmount end: " + DataUtils.toString(updateProductRaiseProgressVO.getTraceID()));
        return creatOKRespResult(updateProductRaiseProgressVO.getTraceID());
    }


    /**
     * 取消交易退款
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/cancelTrade", method = RequestMethod.PUT)
    public ResponseResult cancelTrade(@RequestBody CancelTradeVO cancelTradeVO) throws BusinessException {
        logger.info("cancelTrade start: " + DataUtils.toString(cancelTradeVO));
        DataUtils.checkParam(cancelTradeVO.getOrderBillCode());
        productManagerService.cancelTrade(cancelTradeVO.getOrderBillCode(), cancelTradeVO.getUserPhone(), cancelTradeVO.getCancelReason());
        logger.info("cancelTrade end: " + DataUtils.toString(cancelTradeVO.getTraceID()));
        return creatOKRespResult(cancelTradeVO.getTraceID());
    }

    /**
     * 计算收益
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/calculationProfit", method = RequestMethod.GET)
    public ResponseResult calculationProfit(@RequestParam String traceID, @RequestParam String productUUId) throws BusinessException {
        logger.info("calcTotalProfit start: " + DataUtils.toString(traceID, productUUId));

        DataUtils.checkParam(productUUId);
        ProductProfitVO productProfitVO = productManagerService.calculationProfit(productUUId);

        logger.info("calcTotalProfit end: " + DataUtils.toString(traceID, productProfitVO));
        return creatOKRespResult(traceID, productProfitVO);
    }

    /**
     * 设置产品费用
     * @param
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/setProductFeeRate", method = RequestMethod.PUT)
    public ResponseResult setProductFeeRate(@RequestBody SetProductFeeRateVO setProductFeeRateVO) throws BusinessException {
        logger.info("setProductFeeRate start: " + DataUtils.toString(setProductFeeRateVO));

        DataUtils.checkParam(setProductFeeRateVO.getProduct_uuid());
        productManagerService.setProductFeeRate(setProductFeeRateVO.getProduct_uuid(), setProductFeeRateVO.getPlatformServiceFeeRate(), setProductFeeRateVO.getExchangeManagerFeeRate());

        logger.info("setProductFeeRate end: " + DataUtils.toString(setProductFeeRateVO.getTraceID()));
        return creatOKRespResult(setProductFeeRateVO.getTraceID());
    }

    /**
     * 兑付体验金的收益
     * @param params：userUuid，profitAmt，transactionChannel
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/experienceProfitPayment", method = RequestMethod.PUT)
    public ResponseResult experienceProfitPayment(@RequestBody Map params) throws BusinessException {
        logger.info("experienceProfitPayment start: " + DataUtils.toString(params));

        BizParam bizParam = new BizParam(params);
        String userUuid = bizParam.getString("userUuid");
        String transactionChannel = bizParam.getString("transactionChannel");
        double profitAmt = bizParam.getDouble("profitAmt");
        String orderNo = bizParam.getString("orderNo");

        DataUtils.checkParam(userUuid, orderNo);

        productEndService.experienceProfitPayment(userUuid, profitAmt, transactionChannel, orderNo);

        logger.info("experienceProfitPayment end: " + DataUtils.toString((String)params.get("traceID")));
        return creatOKRespResult((String)params.get("traceID"));
    }
}
