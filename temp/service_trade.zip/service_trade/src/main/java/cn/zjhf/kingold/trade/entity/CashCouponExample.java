package cn.zjhf.kingold.trade.entity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CashCouponExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private Integer limit;

    private Integer offset;

    public CashCouponExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andCcCodeIsNull() {
            addCriterion("cc_code is null");
            return (Criteria) this;
        }

        public Criteria andCcCodeIsNotNull() {
            addCriterion("cc_code is not null");
            return (Criteria) this;
        }

        public Criteria andCcCodeEqualTo(String value) {
            addCriterion("cc_code =", value, "ccCode");
            return (Criteria) this;
        }

        public Criteria andCcCodeNotEqualTo(String value) {
            addCriterion("cc_code <>", value, "ccCode");
            return (Criteria) this;
        }

        public Criteria andCcCodeGreaterThan(String value) {
            addCriterion("cc_code >", value, "ccCode");
            return (Criteria) this;
        }

        public Criteria andCcCodeGreaterThanOrEqualTo(String value) {
            addCriterion("cc_code >=", value, "ccCode");
            return (Criteria) this;
        }

        public Criteria andCcCodeLessThan(String value) {
            addCriterion("cc_code <", value, "ccCode");
            return (Criteria) this;
        }

        public Criteria andCcCodeLessThanOrEqualTo(String value) {
            addCriterion("cc_code <=", value, "ccCode");
            return (Criteria) this;
        }

        public Criteria andCcCodeLike(String value) {
            addCriterion("cc_code like", value, "ccCode");
            return (Criteria) this;
        }

        public Criteria andCcCodeNotLike(String value) {
            addCriterion("cc_code not like", value, "ccCode");
            return (Criteria) this;
        }

        public Criteria andCcCodeIn(List<String> values) {
            addCriterion("cc_code in", values, "ccCode");
            return (Criteria) this;
        }

        public Criteria andCcCodeNotIn(List<String> values) {
            addCriterion("cc_code not in", values, "ccCode");
            return (Criteria) this;
        }

        public Criteria andCcCodeBetween(String value1, String value2) {
            addCriterion("cc_code between", value1, value2, "ccCode");
            return (Criteria) this;
        }

        public Criteria andCcCodeNotBetween(String value1, String value2) {
            addCriterion("cc_code not between", value1, value2, "ccCode");
            return (Criteria) this;
        }

        public Criteria andCcNameIsNull() {
            addCriterion("cc_name is null");
            return (Criteria) this;
        }

        public Criteria andCcNameIsNotNull() {
            addCriterion("cc_name is not null");
            return (Criteria) this;
        }

        public Criteria andCcNameEqualTo(String value) {
            addCriterion("cc_name =", value, "ccName");
            return (Criteria) this;
        }

        public Criteria andCcNameNotEqualTo(String value) {
            addCriterion("cc_name <>", value, "ccName");
            return (Criteria) this;
        }

        public Criteria andCcNameGreaterThan(String value) {
            addCriterion("cc_name >", value, "ccName");
            return (Criteria) this;
        }

        public Criteria andCcNameGreaterThanOrEqualTo(String value) {
            addCriterion("cc_name >=", value, "ccName");
            return (Criteria) this;
        }

        public Criteria andCcNameLessThan(String value) {
            addCriterion("cc_name <", value, "ccName");
            return (Criteria) this;
        }

        public Criteria andCcNameLessThanOrEqualTo(String value) {
            addCriterion("cc_name <=", value, "ccName");
            return (Criteria) this;
        }

        public Criteria andCcNameLike(String value) {
            addCriterion("cc_name like", value, "ccName");
            return (Criteria) this;
        }

        public Criteria andCcNameNotLike(String value) {
            addCriterion("cc_name not like", value, "ccName");
            return (Criteria) this;
        }

        public Criteria andCcNameIn(List<String> values) {
            addCriterion("cc_name in", values, "ccName");
            return (Criteria) this;
        }

        public Criteria andCcNameNotIn(List<String> values) {
            addCriterion("cc_name not in", values, "ccName");
            return (Criteria) this;
        }

        public Criteria andCcNameBetween(String value1, String value2) {
            addCriterion("cc_name between", value1, value2, "ccName");
            return (Criteria) this;
        }

        public Criteria andCcNameNotBetween(String value1, String value2) {
            addCriterion("cc_name not between", value1, value2, "ccName");
            return (Criteria) this;
        }

        public Criteria andCcStatusIsNull() {
            addCriterion("cc_status is null");
            return (Criteria) this;
        }

        public Criteria andCcStatusIsNotNull() {
            addCriterion("cc_status is not null");
            return (Criteria) this;
        }

        public Criteria andCcStatusEqualTo(Byte value) {
            addCriterion("cc_status =", value, "ccStatus");
            return (Criteria) this;
        }

        public Criteria andCcStatusNotEqualTo(Byte value) {
            addCriterion("cc_status <>", value, "ccStatus");
            return (Criteria) this;
        }

        public Criteria andCcStatusGreaterThan(Byte value) {
            addCriterion("cc_status >", value, "ccStatus");
            return (Criteria) this;
        }

        public Criteria andCcStatusGreaterThanOrEqualTo(Byte value) {
            addCriterion("cc_status >=", value, "ccStatus");
            return (Criteria) this;
        }

        public Criteria andCcStatusLessThan(Byte value) {
            addCriterion("cc_status <", value, "ccStatus");
            return (Criteria) this;
        }

        public Criteria andCcStatusLessThanOrEqualTo(Byte value) {
            addCriterion("cc_status <=", value, "ccStatus");
            return (Criteria) this;
        }

        public Criteria andCcStatusIn(List<Byte> values) {
            addCriterion("cc_status in", values, "ccStatus");
            return (Criteria) this;
        }

        public Criteria andCcStatusNotIn(List<Byte> values) {
            addCriterion("cc_status not in", values, "ccStatus");
            return (Criteria) this;
        }

        public Criteria andCcStatusBetween(Byte value1, Byte value2) {
            addCriterion("cc_status between", value1, value2, "ccStatus");
            return (Criteria) this;
        }

        public Criteria andCcStatusNotBetween(Byte value1, Byte value2) {
            addCriterion("cc_status not between", value1, value2, "ccStatus");
            return (Criteria) this;
        }

        public Criteria andCcTypeIsNull() {
            addCriterion("cc_type is null");
            return (Criteria) this;
        }

        public Criteria andCcTypeIsNotNull() {
            addCriterion("cc_type is not null");
            return (Criteria) this;
        }

        public Criteria andCcTypeEqualTo(Byte value) {
            addCriterion("cc_type =", value, "ccType");
            return (Criteria) this;
        }

        public Criteria andCcTypeNotEqualTo(Byte value) {
            addCriterion("cc_type <>", value, "ccType");
            return (Criteria) this;
        }

        public Criteria andCcTypeGreaterThan(Byte value) {
            addCriterion("cc_type >", value, "ccType");
            return (Criteria) this;
        }

        public Criteria andCcTypeGreaterThanOrEqualTo(Byte value) {
            addCriterion("cc_type >=", value, "ccType");
            return (Criteria) this;
        }

        public Criteria andCcTypeLessThan(Byte value) {
            addCriterion("cc_type <", value, "ccType");
            return (Criteria) this;
        }

        public Criteria andCcTypeLessThanOrEqualTo(Byte value) {
            addCriterion("cc_type <=", value, "ccType");
            return (Criteria) this;
        }

        public Criteria andCcTypeIn(List<Byte> values) {
            addCriterion("cc_type in", values, "ccType");
            return (Criteria) this;
        }

        public Criteria andCcTypeNotIn(List<Byte> values) {
            addCriterion("cc_type not in", values, "ccType");
            return (Criteria) this;
        }

        public Criteria andCcTypeBetween(Byte value1, Byte value2) {
            addCriterion("cc_type between", value1, value2, "ccType");
            return (Criteria) this;
        }

        public Criteria andCcTypeNotBetween(Byte value1, Byte value2) {
            addCriterion("cc_type not between", value1, value2, "ccType");
            return (Criteria) this;
        }

        public Criteria andFaceValueIsNull() {
            addCriterion("face_value is null");
            return (Criteria) this;
        }

        public Criteria andFaceValueIsNotNull() {
            addCriterion("face_value is not null");
            return (Criteria) this;
        }

        public Criteria andFaceValueEqualTo(BigDecimal value) {
            addCriterion("face_value =", value, "faceValue");
            return (Criteria) this;
        }

        public Criteria andFaceValueNotEqualTo(BigDecimal value) {
            addCriterion("face_value <>", value, "faceValue");
            return (Criteria) this;
        }

        public Criteria andFaceValueGreaterThan(BigDecimal value) {
            addCriterion("face_value >", value, "faceValue");
            return (Criteria) this;
        }

        public Criteria andFaceValueGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("face_value >=", value, "faceValue");
            return (Criteria) this;
        }

        public Criteria andFaceValueLessThan(BigDecimal value) {
            addCriterion("face_value <", value, "faceValue");
            return (Criteria) this;
        }

        public Criteria andFaceValueLessThanOrEqualTo(BigDecimal value) {
            addCriterion("face_value <=", value, "faceValue");
            return (Criteria) this;
        }

        public Criteria andFaceValueIn(List<BigDecimal> values) {
            addCriterion("face_value in", values, "faceValue");
            return (Criteria) this;
        }

        public Criteria andFaceValueNotIn(List<BigDecimal> values) {
            addCriterion("face_value not in", values, "faceValue");
            return (Criteria) this;
        }

        public Criteria andFaceValueBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("face_value between", value1, value2, "faceValue");
            return (Criteria) this;
        }

        public Criteria andFaceValueNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("face_value not between", value1, value2, "faceValue");
            return (Criteria) this;
        }

        public Criteria andInterestYieldRateIsNull() {
            addCriterion("interest_yield_rate is null");
            return (Criteria) this;
        }

        public Criteria andInterestYieldRateIsNotNull() {
            addCriterion("interest_yield_rate is not null");
            return (Criteria) this;
        }

        public Criteria andInterestYieldRateEqualTo(BigDecimal value) {
            addCriterion("interest_yield_rate =", value, "interestYieldRate");
            return (Criteria) this;
        }

        public Criteria andInterestYieldRateNotEqualTo(BigDecimal value) {
            addCriterion("interest_yield_rate <>", value, "interestYieldRate");
            return (Criteria) this;
        }

        public Criteria andInterestYieldRateGreaterThan(BigDecimal value) {
            addCriterion("interest_yield_rate >", value, "interestYieldRate");
            return (Criteria) this;
        }

        public Criteria andInterestYieldRateGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("interest_yield_rate >=", value, "interestYieldRate");
            return (Criteria) this;
        }

        public Criteria andInterestYieldRateLessThan(BigDecimal value) {
            addCriterion("interest_yield_rate <", value, "interestYieldRate");
            return (Criteria) this;
        }

        public Criteria andInterestYieldRateLessThanOrEqualTo(BigDecimal value) {
            addCriterion("interest_yield_rate <=", value, "interestYieldRate");
            return (Criteria) this;
        }

        public Criteria andInterestYieldRateIn(List<BigDecimal> values) {
            addCriterion("interest_yield_rate in", values, "interestYieldRate");
            return (Criteria) this;
        }

        public Criteria andInterestYieldRateNotIn(List<BigDecimal> values) {
            addCriterion("interest_yield_rate not in", values, "interestYieldRate");
            return (Criteria) this;
        }

        public Criteria andInterestYieldRateBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("interest_yield_rate between", value1, value2, "interestYieldRate");
            return (Criteria) this;
        }

        public Criteria andInterestYieldRateNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("interest_yield_rate not between", value1, value2, "interestYieldRate");
            return (Criteria) this;
        }

        public Criteria andInterestYieldTypeIsNull() {
            addCriterion("interest_yield_type is null");
            return (Criteria) this;
        }

        public Criteria andInterestYieldTypeIsNotNull() {
            addCriterion("interest_yield_type is not null");
            return (Criteria) this;
        }

        public Criteria andInterestYieldTypeEqualTo(Integer value) {
            addCriterion("interest_yield_type =", value, "interestYieldType");
            return (Criteria) this;
        }

        public Criteria andInterestYieldTypeNotEqualTo(Integer value) {
            addCriterion("interest_yield_type <>", value, "interestYieldType");
            return (Criteria) this;
        }

        public Criteria andInterestYieldTypeGreaterThan(Integer value) {
            addCriterion("interest_yield_type >", value, "interestYieldType");
            return (Criteria) this;
        }

        public Criteria andInterestYieldTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("interest_yield_type >=", value, "interestYieldType");
            return (Criteria) this;
        }

        public Criteria andInterestYieldTypeLessThan(Integer value) {
            addCriterion("interest_yield_type <", value, "interestYieldType");
            return (Criteria) this;
        }

        public Criteria andInterestYieldTypeLessThanOrEqualTo(Integer value) {
            addCriterion("interest_yield_type <=", value, "interestYieldType");
            return (Criteria) this;
        }

        public Criteria andInterestYieldTypeIn(List<Integer> values) {
            addCriterion("interest_yield_type in", values, "interestYieldType");
            return (Criteria) this;
        }

        public Criteria andInterestYieldTypeNotIn(List<Integer> values) {
            addCriterion("interest_yield_type not in", values, "interestYieldType");
            return (Criteria) this;
        }

        public Criteria andInterestYieldTypeBetween(Integer value1, Integer value2) {
            addCriterion("interest_yield_type between", value1, value2, "interestYieldType");
            return (Criteria) this;
        }

        public Criteria andInterestYieldTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("interest_yield_type not between", value1, value2, "interestYieldType");
            return (Criteria) this;
        }

        public Criteria andInterestYieldPeriodIsNull() {
            addCriterion("interest_yield_period is null");
            return (Criteria) this;
        }

        public Criteria andInterestYieldPeriodIsNotNull() {
            addCriterion("interest_yield_period is not null");
            return (Criteria) this;
        }

        public Criteria andInterestYieldPeriodEqualTo(Integer value) {
            addCriterion("interest_yield_period =", value, "interestYieldPeriod");
            return (Criteria) this;
        }

        public Criteria andInterestYieldPeriodNotEqualTo(Integer value) {
            addCriterion("interest_yield_period <>", value, "interestYieldPeriod");
            return (Criteria) this;
        }

        public Criteria andInterestYieldPeriodGreaterThan(Integer value) {
            addCriterion("interest_yield_period >", value, "interestYieldPeriod");
            return (Criteria) this;
        }

        public Criteria andInterestYieldPeriodGreaterThanOrEqualTo(Integer value) {
            addCriterion("interest_yield_period >=", value, "interestYieldPeriod");
            return (Criteria) this;
        }

        public Criteria andInterestYieldPeriodLessThan(Integer value) {
            addCriterion("interest_yield_period <", value, "interestYieldPeriod");
            return (Criteria) this;
        }

        public Criteria andInterestYieldPeriodLessThanOrEqualTo(Integer value) {
            addCriterion("interest_yield_period <=", value, "interestYieldPeriod");
            return (Criteria) this;
        }

        public Criteria andInterestYieldPeriodIn(List<Integer> values) {
            addCriterion("interest_yield_period in", values, "interestYieldPeriod");
            return (Criteria) this;
        }

        public Criteria andInterestYieldPeriodNotIn(List<Integer> values) {
            addCriterion("interest_yield_period not in", values, "interestYieldPeriod");
            return (Criteria) this;
        }

        public Criteria andInterestYieldPeriodBetween(Integer value1, Integer value2) {
            addCriterion("interest_yield_period between", value1, value2, "interestYieldPeriod");
            return (Criteria) this;
        }

        public Criteria andInterestYieldPeriodNotBetween(Integer value1, Integer value2) {
            addCriterion("interest_yield_period not between", value1, value2, "interestYieldPeriod");
            return (Criteria) this;
        }

        public Criteria andValidTermTypeIsNull() {
            addCriterion("valid_term_type is null");
            return (Criteria) this;
        }

        public Criteria andValidTermTypeIsNotNull() {
            addCriterion("valid_term_type is not null");
            return (Criteria) this;
        }

        public Criteria andValidTermTypeEqualTo(Byte value) {
            addCriterion("valid_term_type =", value, "validTermType");
            return (Criteria) this;
        }

        public Criteria andValidTermTypeNotEqualTo(Byte value) {
            addCriterion("valid_term_type <>", value, "validTermType");
            return (Criteria) this;
        }

        public Criteria andValidTermTypeGreaterThan(Byte value) {
            addCriterion("valid_term_type >", value, "validTermType");
            return (Criteria) this;
        }

        public Criteria andValidTermTypeGreaterThanOrEqualTo(Byte value) {
            addCriterion("valid_term_type >=", value, "validTermType");
            return (Criteria) this;
        }

        public Criteria andValidTermTypeLessThan(Byte value) {
            addCriterion("valid_term_type <", value, "validTermType");
            return (Criteria) this;
        }

        public Criteria andValidTermTypeLessThanOrEqualTo(Byte value) {
            addCriterion("valid_term_type <=", value, "validTermType");
            return (Criteria) this;
        }

        public Criteria andValidTermTypeIn(List<Byte> values) {
            addCriterion("valid_term_type in", values, "validTermType");
            return (Criteria) this;
        }

        public Criteria andValidTermTypeNotIn(List<Byte> values) {
            addCriterion("valid_term_type not in", values, "validTermType");
            return (Criteria) this;
        }

        public Criteria andValidTermTypeBetween(Byte value1, Byte value2) {
            addCriterion("valid_term_type between", value1, value2, "validTermType");
            return (Criteria) this;
        }

        public Criteria andValidTermTypeNotBetween(Byte value1, Byte value2) {
            addCriterion("valid_term_type not between", value1, value2, "validTermType");
            return (Criteria) this;
        }

        public Criteria andValidStartTimeIsNull() {
            addCriterion("valid_start_time is null");
            return (Criteria) this;
        }

        public Criteria andValidStartTimeIsNotNull() {
            addCriterion("valid_start_time is not null");
            return (Criteria) this;
        }

        public Criteria andValidStartTimeEqualTo(Date value) {
            addCriterion("valid_start_time =", value, "validStartTime");
            return (Criteria) this;
        }

        public Criteria andValidStartTimeNotEqualTo(Date value) {
            addCriterion("valid_start_time <>", value, "validStartTime");
            return (Criteria) this;
        }

        public Criteria andValidStartTimeGreaterThan(Date value) {
            addCriterion("valid_start_time >", value, "validStartTime");
            return (Criteria) this;
        }

        public Criteria andValidStartTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("valid_start_time >=", value, "validStartTime");
            return (Criteria) this;
        }

        public Criteria andValidStartTimeLessThan(Date value) {
            addCriterion("valid_start_time <", value, "validStartTime");
            return (Criteria) this;
        }

        public Criteria andValidStartTimeLessThanOrEqualTo(Date value) {
            addCriterion("valid_start_time <=", value, "validStartTime");
            return (Criteria) this;
        }

        public Criteria andValidStartTimeIn(List<Date> values) {
            addCriterion("valid_start_time in", values, "validStartTime");
            return (Criteria) this;
        }

        public Criteria andValidStartTimeNotIn(List<Date> values) {
            addCriterion("valid_start_time not in", values, "validStartTime");
            return (Criteria) this;
        }

        public Criteria andValidStartTimeBetween(Date value1, Date value2) {
            addCriterion("valid_start_time between", value1, value2, "validStartTime");
            return (Criteria) this;
        }

        public Criteria andValidStartTimeNotBetween(Date value1, Date value2) {
            addCriterion("valid_start_time not between", value1, value2, "validStartTime");
            return (Criteria) this;
        }

        public Criteria andValidEndTimeIsNull() {
            addCriterion("valid_end_time is null");
            return (Criteria) this;
        }

        public Criteria andValidEndTimeIsNotNull() {
            addCriterion("valid_end_time is not null");
            return (Criteria) this;
        }

        public Criteria andValidEndTimeEqualTo(Date value) {
            addCriterion("valid_end_time =", value, "validEndTime");
            return (Criteria) this;
        }

        public Criteria andValidEndTimeNotEqualTo(Date value) {
            addCriterion("valid_end_time <>", value, "validEndTime");
            return (Criteria) this;
        }

        public Criteria andValidEndTimeGreaterThan(Date value) {
            addCriterion("valid_end_time >", value, "validEndTime");
            return (Criteria) this;
        }

        public Criteria andValidEndTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("valid_end_time >=", value, "validEndTime");
            return (Criteria) this;
        }

        public Criteria andValidEndTimeLessThan(Date value) {
            addCriterion("valid_end_time <", value, "validEndTime");
            return (Criteria) this;
        }

        public Criteria andValidEndTimeLessThanOrEqualTo(Date value) {
            addCriterion("valid_end_time <=", value, "validEndTime");
            return (Criteria) this;
        }

        public Criteria andValidEndTimeIn(List<Date> values) {
            addCriterion("valid_end_time in", values, "validEndTime");
            return (Criteria) this;
        }

        public Criteria andValidEndTimeNotIn(List<Date> values) {
            addCriterion("valid_end_time not in", values, "validEndTime");
            return (Criteria) this;
        }

        public Criteria andValidEndTimeBetween(Date value1, Date value2) {
            addCriterion("valid_end_time between", value1, value2, "validEndTime");
            return (Criteria) this;
        }

        public Criteria andValidEndTimeNotBetween(Date value1, Date value2) {
            addCriterion("valid_end_time not between", value1, value2, "validEndTime");
            return (Criteria) this;
        }

        public Criteria andValidTermUnitIsNull() {
            addCriterion("valid_term_unit is null");
            return (Criteria) this;
        }

        public Criteria andValidTermUnitIsNotNull() {
            addCriterion("valid_term_unit is not null");
            return (Criteria) this;
        }

        public Criteria andValidTermUnitEqualTo(Byte value) {
            addCriterion("valid_term_unit =", value, "validTermUnit");
            return (Criteria) this;
        }

        public Criteria andValidTermUnitNotEqualTo(Byte value) {
            addCriterion("valid_term_unit <>", value, "validTermUnit");
            return (Criteria) this;
        }

        public Criteria andValidTermUnitGreaterThan(Byte value) {
            addCriterion("valid_term_unit >", value, "validTermUnit");
            return (Criteria) this;
        }

        public Criteria andValidTermUnitGreaterThanOrEqualTo(Byte value) {
            addCriterion("valid_term_unit >=", value, "validTermUnit");
            return (Criteria) this;
        }

        public Criteria andValidTermUnitLessThan(Byte value) {
            addCriterion("valid_term_unit <", value, "validTermUnit");
            return (Criteria) this;
        }

        public Criteria andValidTermUnitLessThanOrEqualTo(Byte value) {
            addCriterion("valid_term_unit <=", value, "validTermUnit");
            return (Criteria) this;
        }

        public Criteria andValidTermUnitIn(List<Byte> values) {
            addCriterion("valid_term_unit in", values, "validTermUnit");
            return (Criteria) this;
        }

        public Criteria andValidTermUnitNotIn(List<Byte> values) {
            addCriterion("valid_term_unit not in", values, "validTermUnit");
            return (Criteria) this;
        }

        public Criteria andValidTermUnitBetween(Byte value1, Byte value2) {
            addCriterion("valid_term_unit between", value1, value2, "validTermUnit");
            return (Criteria) this;
        }

        public Criteria andValidTermUnitNotBetween(Byte value1, Byte value2) {
            addCriterion("valid_term_unit not between", value1, value2, "validTermUnit");
            return (Criteria) this;
        }

        public Criteria andValidTermQuantityIsNull() {
            addCriterion("valid_term_quantity is null");
            return (Criteria) this;
        }

        public Criteria andValidTermQuantityIsNotNull() {
            addCriterion("valid_term_quantity is not null");
            return (Criteria) this;
        }

        public Criteria andValidTermQuantityEqualTo(Integer value) {
            addCriterion("valid_term_quantity =", value, "validTermQuantity");
            return (Criteria) this;
        }

        public Criteria andValidTermQuantityNotEqualTo(Integer value) {
            addCriterion("valid_term_quantity <>", value, "validTermQuantity");
            return (Criteria) this;
        }

        public Criteria andValidTermQuantityGreaterThan(Integer value) {
            addCriterion("valid_term_quantity >", value, "validTermQuantity");
            return (Criteria) this;
        }

        public Criteria andValidTermQuantityGreaterThanOrEqualTo(Integer value) {
            addCriterion("valid_term_quantity >=", value, "validTermQuantity");
            return (Criteria) this;
        }

        public Criteria andValidTermQuantityLessThan(Integer value) {
            addCriterion("valid_term_quantity <", value, "validTermQuantity");
            return (Criteria) this;
        }

        public Criteria andValidTermQuantityLessThanOrEqualTo(Integer value) {
            addCriterion("valid_term_quantity <=", value, "validTermQuantity");
            return (Criteria) this;
        }

        public Criteria andValidTermQuantityIn(List<Integer> values) {
            addCriterion("valid_term_quantity in", values, "validTermQuantity");
            return (Criteria) this;
        }

        public Criteria andValidTermQuantityNotIn(List<Integer> values) {
            addCriterion("valid_term_quantity not in", values, "validTermQuantity");
            return (Criteria) this;
        }

        public Criteria andValidTermQuantityBetween(Integer value1, Integer value2) {
            addCriterion("valid_term_quantity between", value1, value2, "validTermQuantity");
            return (Criteria) this;
        }

        public Criteria andValidTermQuantityNotBetween(Integer value1, Integer value2) {
            addCriterion("valid_term_quantity not between", value1, value2, "validTermQuantity");
            return (Criteria) this;
        }

        public Criteria andExtendMaxNumIsNull() {
            addCriterion("extend_max_num is null");
            return (Criteria) this;
        }

        public Criteria andExtendMaxNumIsNotNull() {
            addCriterion("extend_max_num is not null");
            return (Criteria) this;
        }

        public Criteria andExtendMaxNumEqualTo(Integer value) {
            addCriterion("extend_max_num =", value, "extendMaxNum");
            return (Criteria) this;
        }

        public Criteria andExtendMaxNumNotEqualTo(Integer value) {
            addCriterion("extend_max_num <>", value, "extendMaxNum");
            return (Criteria) this;
        }

        public Criteria andExtendMaxNumGreaterThan(Integer value) {
            addCriterion("extend_max_num >", value, "extendMaxNum");
            return (Criteria) this;
        }

        public Criteria andExtendMaxNumGreaterThanOrEqualTo(Integer value) {
            addCriterion("extend_max_num >=", value, "extendMaxNum");
            return (Criteria) this;
        }

        public Criteria andExtendMaxNumLessThan(Integer value) {
            addCriterion("extend_max_num <", value, "extendMaxNum");
            return (Criteria) this;
        }

        public Criteria andExtendMaxNumLessThanOrEqualTo(Integer value) {
            addCriterion("extend_max_num <=", value, "extendMaxNum");
            return (Criteria) this;
        }

        public Criteria andExtendMaxNumIn(List<Integer> values) {
            addCriterion("extend_max_num in", values, "extendMaxNum");
            return (Criteria) this;
        }

        public Criteria andExtendMaxNumNotIn(List<Integer> values) {
            addCriterion("extend_max_num not in", values, "extendMaxNum");
            return (Criteria) this;
        }

        public Criteria andExtendMaxNumBetween(Integer value1, Integer value2) {
            addCriterion("extend_max_num between", value1, value2, "extendMaxNum");
            return (Criteria) this;
        }

        public Criteria andExtendMaxNumNotBetween(Integer value1, Integer value2) {
            addCriterion("extend_max_num not between", value1, value2, "extendMaxNum");
            return (Criteria) this;
        }

        public Criteria andExtendDayMaxNumIsNull() {
            addCriterion("extend_day_max_num is null");
            return (Criteria) this;
        }

        public Criteria andExtendDayMaxNumIsNotNull() {
            addCriterion("extend_day_max_num is not null");
            return (Criteria) this;
        }

        public Criteria andExtendDayMaxNumEqualTo(Integer value) {
            addCriterion("extend_day_max_num =", value, "extendDayMaxNum");
            return (Criteria) this;
        }

        public Criteria andExtendDayMaxNumNotEqualTo(Integer value) {
            addCriterion("extend_day_max_num <>", value, "extendDayMaxNum");
            return (Criteria) this;
        }

        public Criteria andExtendDayMaxNumGreaterThan(Integer value) {
            addCriterion("extend_day_max_num >", value, "extendDayMaxNum");
            return (Criteria) this;
        }

        public Criteria andExtendDayMaxNumGreaterThanOrEqualTo(Integer value) {
            addCriterion("extend_day_max_num >=", value, "extendDayMaxNum");
            return (Criteria) this;
        }

        public Criteria andExtendDayMaxNumLessThan(Integer value) {
            addCriterion("extend_day_max_num <", value, "extendDayMaxNum");
            return (Criteria) this;
        }

        public Criteria andExtendDayMaxNumLessThanOrEqualTo(Integer value) {
            addCriterion("extend_day_max_num <=", value, "extendDayMaxNum");
            return (Criteria) this;
        }

        public Criteria andExtendDayMaxNumIn(List<Integer> values) {
            addCriterion("extend_day_max_num in", values, "extendDayMaxNum");
            return (Criteria) this;
        }

        public Criteria andExtendDayMaxNumNotIn(List<Integer> values) {
            addCriterion("extend_day_max_num not in", values, "extendDayMaxNum");
            return (Criteria) this;
        }

        public Criteria andExtendDayMaxNumBetween(Integer value1, Integer value2) {
            addCriterion("extend_day_max_num between", value1, value2, "extendDayMaxNum");
            return (Criteria) this;
        }

        public Criteria andExtendDayMaxNumNotBetween(Integer value1, Integer value2) {
            addCriterion("extend_day_max_num not between", value1, value2, "extendDayMaxNum");
            return (Criteria) this;
        }

        public Criteria andExtendChannelIsNull() {
            addCriterion("extend_channel is null");
            return (Criteria) this;
        }

        public Criteria andExtendChannelIsNotNull() {
            addCriterion("extend_channel is not null");
            return (Criteria) this;
        }

        public Criteria andExtendChannelEqualTo(String value) {
            addCriterion("extend_channel =", value, "extendChannel");
            return (Criteria) this;
        }

        public Criteria andExtendChannelNotEqualTo(String value) {
            addCriterion("extend_channel <>", value, "extendChannel");
            return (Criteria) this;
        }

        public Criteria andExtendChannelGreaterThan(String value) {
            addCriterion("extend_channel >", value, "extendChannel");
            return (Criteria) this;
        }

        public Criteria andExtendChannelGreaterThanOrEqualTo(String value) {
            addCriterion("extend_channel >=", value, "extendChannel");
            return (Criteria) this;
        }

        public Criteria andExtendChannelLessThan(String value) {
            addCriterion("extend_channel <", value, "extendChannel");
            return (Criteria) this;
        }

        public Criteria andExtendChannelLessThanOrEqualTo(String value) {
            addCriterion("extend_channel <=", value, "extendChannel");
            return (Criteria) this;
        }

        public Criteria andExtendChannelLike(String value) {
            addCriterion("extend_channel like", value, "extendChannel");
            return (Criteria) this;
        }

        public Criteria andExtendChannelNotLike(String value) {
            addCriterion("extend_channel not like", value, "extendChannel");
            return (Criteria) this;
        }

        public Criteria andExtendChannelIn(List<String> values) {
            addCriterion("extend_channel in", values, "extendChannel");
            return (Criteria) this;
        }

        public Criteria andExtendChannelNotIn(List<String> values) {
            addCriterion("extend_channel not in", values, "extendChannel");
            return (Criteria) this;
        }

        public Criteria andExtendChannelBetween(String value1, String value2) {
            addCriterion("extend_channel between", value1, value2, "extendChannel");
            return (Criteria) this;
        }

        public Criteria andExtendChannelNotBetween(String value1, String value2) {
            addCriterion("extend_channel not between", value1, value2, "extendChannel");
            return (Criteria) this;
        }

        public Criteria andApplyProductTypeIsNull() {
            addCriterion("apply_product_type is null");
            return (Criteria) this;
        }

        public Criteria andApplyProductTypeIsNotNull() {
            addCriterion("apply_product_type is not null");
            return (Criteria) this;
        }

        public Criteria andApplyProductTypeEqualTo(String value) {
            addCriterion("apply_product_type =", value, "applyProductType");
            return (Criteria) this;
        }

        public Criteria andApplyProductTypeNotEqualTo(String value) {
            addCriterion("apply_product_type <>", value, "applyProductType");
            return (Criteria) this;
        }

        public Criteria andApplyProductTypeGreaterThan(String value) {
            addCriterion("apply_product_type >", value, "applyProductType");
            return (Criteria) this;
        }

        public Criteria andApplyProductTypeGreaterThanOrEqualTo(String value) {
            addCriterion("apply_product_type >=", value, "applyProductType");
            return (Criteria) this;
        }

        public Criteria andApplyProductTypeLessThan(String value) {
            addCriterion("apply_product_type <", value, "applyProductType");
            return (Criteria) this;
        }

        public Criteria andApplyProductTypeLessThanOrEqualTo(String value) {
            addCriterion("apply_product_type <=", value, "applyProductType");
            return (Criteria) this;
        }

        public Criteria andApplyProductTypeLike(String value) {
            addCriterion("apply_product_type like", value, "applyProductType");
            return (Criteria) this;
        }

        public Criteria andApplyProductTypeNotLike(String value) {
            addCriterion("apply_product_type not like", value, "applyProductType");
            return (Criteria) this;
        }

        public Criteria andApplyProductTypeIn(List<String> values) {
            addCriterion("apply_product_type in", values, "applyProductType");
            return (Criteria) this;
        }

        public Criteria andApplyProductTypeNotIn(List<String> values) {
            addCriterion("apply_product_type not in", values, "applyProductType");
            return (Criteria) this;
        }

        public Criteria andApplyProductTypeBetween(String value1, String value2) {
            addCriterion("apply_product_type between", value1, value2, "applyProductType");
            return (Criteria) this;
        }

        public Criteria andApplyProductTypeNotBetween(String value1, String value2) {
            addCriterion("apply_product_type not between", value1, value2, "applyProductType");
            return (Criteria) this;
        }

        public Criteria andApplyChannelIsNull() {
            addCriterion("apply_channel is null");
            return (Criteria) this;
        }

        public Criteria andApplyChannelIsNotNull() {
            addCriterion("apply_channel is not null");
            return (Criteria) this;
        }

        public Criteria andApplyChannelEqualTo(String value) {
            addCriterion("apply_channel =", value, "applyChannel");
            return (Criteria) this;
        }

        public Criteria andApplyChannelNotEqualTo(String value) {
            addCriterion("apply_channel <>", value, "applyChannel");
            return (Criteria) this;
        }

        public Criteria andApplyChannelGreaterThan(String value) {
            addCriterion("apply_channel >", value, "applyChannel");
            return (Criteria) this;
        }

        public Criteria andApplyChannelGreaterThanOrEqualTo(String value) {
            addCriterion("apply_channel >=", value, "applyChannel");
            return (Criteria) this;
        }

        public Criteria andApplyChannelLessThan(String value) {
            addCriterion("apply_channel <", value, "applyChannel");
            return (Criteria) this;
        }

        public Criteria andApplyChannelLessThanOrEqualTo(String value) {
            addCriterion("apply_channel <=", value, "applyChannel");
            return (Criteria) this;
        }

        public Criteria andApplyChannelLike(String value) {
            addCriterion("apply_channel like", value, "applyChannel");
            return (Criteria) this;
        }

        public Criteria andApplyChannelNotLike(String value) {
            addCriterion("apply_channel not like", value, "applyChannel");
            return (Criteria) this;
        }

        public Criteria andApplyChannelIn(List<String> values) {
            addCriterion("apply_channel in", values, "applyChannel");
            return (Criteria) this;
        }

        public Criteria andApplyChannelNotIn(List<String> values) {
            addCriterion("apply_channel not in", values, "applyChannel");
            return (Criteria) this;
        }

        public Criteria andApplyChannelBetween(String value1, String value2) {
            addCriterion("apply_channel between", value1, value2, "applyChannel");
            return (Criteria) this;
        }

        public Criteria andApplyChannelNotBetween(String value1, String value2) {
            addCriterion("apply_channel not between", value1, value2, "applyChannel");
            return (Criteria) this;
        }

        public Criteria andApplyTradeAmountIsNull() {
            addCriterion("apply_trade_amount is null");
            return (Criteria) this;
        }

        public Criteria andApplyTradeAmountIsNotNull() {
            addCriterion("apply_trade_amount is not null");
            return (Criteria) this;
        }

        public Criteria andApplyTradeAmountEqualTo(BigDecimal value) {
            addCriterion("apply_trade_amount =", value, "applyTradeAmount");
            return (Criteria) this;
        }

        public Criteria andApplyTradeAmountNotEqualTo(BigDecimal value) {
            addCriterion("apply_trade_amount <>", value, "applyTradeAmount");
            return (Criteria) this;
        }

        public Criteria andApplyTradeAmountGreaterThan(BigDecimal value) {
            addCriterion("apply_trade_amount >", value, "applyTradeAmount");
            return (Criteria) this;
        }

        public Criteria andApplyTradeAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("apply_trade_amount >=", value, "applyTradeAmount");
            return (Criteria) this;
        }

        public Criteria andApplyTradeAmountLessThan(BigDecimal value) {
            addCriterion("apply_trade_amount <", value, "applyTradeAmount");
            return (Criteria) this;
        }

        public Criteria andApplyTradeAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("apply_trade_amount <=", value, "applyTradeAmount");
            return (Criteria) this;
        }

        public Criteria andApplyTradeAmountIn(List<BigDecimal> values) {
            addCriterion("apply_trade_amount in", values, "applyTradeAmount");
            return (Criteria) this;
        }

        public Criteria andApplyTradeAmountNotIn(List<BigDecimal> values) {
            addCriterion("apply_trade_amount not in", values, "applyTradeAmount");
            return (Criteria) this;
        }

        public Criteria andApplyTradeAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("apply_trade_amount between", value1, value2, "applyTradeAmount");
            return (Criteria) this;
        }

        public Criteria andApplyTradeAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("apply_trade_amount not between", value1, value2, "applyTradeAmount");
            return (Criteria) this;
        }

        public Criteria andIsApplyProductTermIsNull() {
            addCriterion("is_apply_product_term is null");
            return (Criteria) this;
        }

        public Criteria andIsApplyProductTermIsNotNull() {
            addCriterion("is_apply_product_term is not null");
            return (Criteria) this;
        }

        public Criteria andIsApplyProductTermEqualTo(Byte value) {
            addCriterion("is_apply_product_term =", value, "isApplyProductTerm");
            return (Criteria) this;
        }

        public Criteria andIsApplyProductTermNotEqualTo(Byte value) {
            addCriterion("is_apply_product_term <>", value, "isApplyProductTerm");
            return (Criteria) this;
        }

        public Criteria andIsApplyProductTermGreaterThan(Byte value) {
            addCriterion("is_apply_product_term >", value, "isApplyProductTerm");
            return (Criteria) this;
        }

        public Criteria andIsApplyProductTermGreaterThanOrEqualTo(Byte value) {
            addCriterion("is_apply_product_term >=", value, "isApplyProductTerm");
            return (Criteria) this;
        }

        public Criteria andIsApplyProductTermLessThan(Byte value) {
            addCriterion("is_apply_product_term <", value, "isApplyProductTerm");
            return (Criteria) this;
        }

        public Criteria andIsApplyProductTermLessThanOrEqualTo(Byte value) {
            addCriterion("is_apply_product_term <=", value, "isApplyProductTerm");
            return (Criteria) this;
        }

        public Criteria andIsApplyProductTermIn(List<Byte> values) {
            addCriterion("is_apply_product_term in", values, "isApplyProductTerm");
            return (Criteria) this;
        }

        public Criteria andIsApplyProductTermNotIn(List<Byte> values) {
            addCriterion("is_apply_product_term not in", values, "isApplyProductTerm");
            return (Criteria) this;
        }

        public Criteria andIsApplyProductTermBetween(Byte value1, Byte value2) {
            addCriterion("is_apply_product_term between", value1, value2, "isApplyProductTerm");
            return (Criteria) this;
        }

        public Criteria andIsApplyProductTermNotBetween(Byte value1, Byte value2) {
            addCriterion("is_apply_product_term not between", value1, value2, "isApplyProductTerm");
            return (Criteria) this;
        }

        public Criteria andApplyProductTermsIsNull() {
            addCriterion("apply_product_terms is null");
            return (Criteria) this;
        }

        public Criteria andApplyProductTermsIsNotNull() {
            addCriterion("apply_product_terms is not null");
            return (Criteria) this;
        }

        public Criteria andApplyProductTermsEqualTo(String value) {
            addCriterion("apply_product_terms =", value, "applyProductTerms");
            return (Criteria) this;
        }

        public Criteria andApplyProductTermsNotEqualTo(String value) {
            addCriterion("apply_product_terms <>", value, "applyProductTerms");
            return (Criteria) this;
        }

        public Criteria andApplyProductTermsGreaterThan(String value) {
            addCriterion("apply_product_terms >", value, "applyProductTerms");
            return (Criteria) this;
        }

        public Criteria andApplyProductTermsGreaterThanOrEqualTo(String value) {
            addCriterion("apply_product_terms >=", value, "applyProductTerms");
            return (Criteria) this;
        }

        public Criteria andApplyProductTermsLessThan(String value) {
            addCriterion("apply_product_terms <", value, "applyProductTerms");
            return (Criteria) this;
        }

        public Criteria andApplyProductTermsLessThanOrEqualTo(String value) {
            addCriterion("apply_product_terms <=", value, "applyProductTerms");
            return (Criteria) this;
        }

        public Criteria andApplyProductTermsLike(String value) {
            addCriterion("apply_product_terms like", value, "applyProductTerms");
            return (Criteria) this;
        }

        public Criteria andApplyProductTermsNotLike(String value) {
            addCriterion("apply_product_terms not like", value, "applyProductTerms");
            return (Criteria) this;
        }

        public Criteria andApplyProductTermsIn(List<String> values) {
            addCriterion("apply_product_terms in", values, "applyProductTerms");
            return (Criteria) this;
        }

        public Criteria andApplyProductTermsNotIn(List<String> values) {
            addCriterion("apply_product_terms not in", values, "applyProductTerms");
            return (Criteria) this;
        }

        public Criteria andApplyProductTermsBetween(String value1, String value2) {
            addCriterion("apply_product_terms between", value1, value2, "applyProductTerms");
            return (Criteria) this;
        }

        public Criteria andApplyProductTermsNotBetween(String value1, String value2) {
            addCriterion("apply_product_terms not between", value1, value2, "applyProductTerms");
            return (Criteria) this;
        }

        public Criteria andIsApplyProductuuidsIsNull() {
            addCriterion("is_apply_productuuids is null");
            return (Criteria) this;
        }

        public Criteria andIsApplyProductuuidsIsNotNull() {
            addCriterion("is_apply_productuuids is not null");
            return (Criteria) this;
        }

        public Criteria andIsApplyProductuuidsEqualTo(Byte value) {
            addCriterion("is_apply_productuuids =", value, "isApplyProductuuids");
            return (Criteria) this;
        }

        public Criteria andIsApplyProductuuidsNotEqualTo(Byte value) {
            addCriterion("is_apply_productuuids <>", value, "isApplyProductuuids");
            return (Criteria) this;
        }

        public Criteria andIsApplyProductuuidsGreaterThan(Byte value) {
            addCriterion("is_apply_productuuids >", value, "isApplyProductuuids");
            return (Criteria) this;
        }

        public Criteria andIsApplyProductuuidsGreaterThanOrEqualTo(Byte value) {
            addCriterion("is_apply_productuuids >=", value, "isApplyProductuuids");
            return (Criteria) this;
        }

        public Criteria andIsApplyProductuuidsLessThan(Byte value) {
            addCriterion("is_apply_productuuids <", value, "isApplyProductuuids");
            return (Criteria) this;
        }

        public Criteria andIsApplyProductuuidsLessThanOrEqualTo(Byte value) {
            addCriterion("is_apply_productuuids <=", value, "isApplyProductuuids");
            return (Criteria) this;
        }

        public Criteria andIsApplyProductuuidsIn(List<Byte> values) {
            addCriterion("is_apply_productuuids in", values, "isApplyProductuuids");
            return (Criteria) this;
        }

        public Criteria andIsApplyProductuuidsNotIn(List<Byte> values) {
            addCriterion("is_apply_productuuids not in", values, "isApplyProductuuids");
            return (Criteria) this;
        }

        public Criteria andIsApplyProductuuidsBetween(Byte value1, Byte value2) {
            addCriterion("is_apply_productuuids between", value1, value2, "isApplyProductuuids");
            return (Criteria) this;
        }

        public Criteria andIsApplyProductuuidsNotBetween(Byte value1, Byte value2) {
            addCriterion("is_apply_productuuids not between", value1, value2, "isApplyProductuuids");
            return (Criteria) this;
        }

        public Criteria andApplyProductuuidsIsNull() {
            addCriterion("apply_productuuids is null");
            return (Criteria) this;
        }

        public Criteria andApplyProductuuidsIsNotNull() {
            addCriterion("apply_productuuids is not null");
            return (Criteria) this;
        }

        public Criteria andApplyProductuuidsEqualTo(String value) {
            addCriterion("apply_productuuids =", value, "applyProductuuids");
            return (Criteria) this;
        }

        public Criteria andApplyProductuuidsNotEqualTo(String value) {
            addCriterion("apply_productuuids <>", value, "applyProductuuids");
            return (Criteria) this;
        }

        public Criteria andApplyProductuuidsGreaterThan(String value) {
            addCriterion("apply_productuuids >", value, "applyProductuuids");
            return (Criteria) this;
        }

        public Criteria andApplyProductuuidsGreaterThanOrEqualTo(String value) {
            addCriterion("apply_productuuids >=", value, "applyProductuuids");
            return (Criteria) this;
        }

        public Criteria andApplyProductuuidsLessThan(String value) {
            addCriterion("apply_productuuids <", value, "applyProductuuids");
            return (Criteria) this;
        }

        public Criteria andApplyProductuuidsLessThanOrEqualTo(String value) {
            addCriterion("apply_productuuids <=", value, "applyProductuuids");
            return (Criteria) this;
        }

        public Criteria andApplyProductuuidsLike(String value) {
            addCriterion("apply_productuuids like", value, "applyProductuuids");
            return (Criteria) this;
        }

        public Criteria andApplyProductuuidsNotLike(String value) {
            addCriterion("apply_productuuids not like", value, "applyProductuuids");
            return (Criteria) this;
        }

        public Criteria andApplyProductuuidsIn(List<String> values) {
            addCriterion("apply_productuuids in", values, "applyProductuuids");
            return (Criteria) this;
        }

        public Criteria andApplyProductuuidsNotIn(List<String> values) {
            addCriterion("apply_productuuids not in", values, "applyProductuuids");
            return (Criteria) this;
        }

        public Criteria andApplyProductuuidsBetween(String value1, String value2) {
            addCriterion("apply_productuuids between", value1, value2, "applyProductuuids");
            return (Criteria) this;
        }

        public Criteria andApplyProductuuidsNotBetween(String value1, String value2) {
            addCriterion("apply_productuuids not between", value1, value2, "applyProductuuids");
            return (Criteria) this;
        }

        public Criteria andCcRemark1IsNull() {
            addCriterion("cc_remark1 is null");
            return (Criteria) this;
        }

        public Criteria andCcRemark1IsNotNull() {
            addCriterion("cc_remark1 is not null");
            return (Criteria) this;
        }

        public Criteria andCcRemark1EqualTo(String value) {
            addCriterion("cc_remark1 =", value, "ccRemark1");
            return (Criteria) this;
        }

        public Criteria andCcRemark1NotEqualTo(String value) {
            addCriterion("cc_remark1 <>", value, "ccRemark1");
            return (Criteria) this;
        }

        public Criteria andCcRemark1GreaterThan(String value) {
            addCriterion("cc_remark1 >", value, "ccRemark1");
            return (Criteria) this;
        }

        public Criteria andCcRemark1GreaterThanOrEqualTo(String value) {
            addCriterion("cc_remark1 >=", value, "ccRemark1");
            return (Criteria) this;
        }

        public Criteria andCcRemark1LessThan(String value) {
            addCriterion("cc_remark1 <", value, "ccRemark1");
            return (Criteria) this;
        }

        public Criteria andCcRemark1LessThanOrEqualTo(String value) {
            addCriterion("cc_remark1 <=", value, "ccRemark1");
            return (Criteria) this;
        }

        public Criteria andCcRemark1Like(String value) {
            addCriterion("cc_remark1 like", value, "ccRemark1");
            return (Criteria) this;
        }

        public Criteria andCcRemark1NotLike(String value) {
            addCriterion("cc_remark1 not like", value, "ccRemark1");
            return (Criteria) this;
        }

        public Criteria andCcRemark1In(List<String> values) {
            addCriterion("cc_remark1 in", values, "ccRemark1");
            return (Criteria) this;
        }

        public Criteria andCcRemark1NotIn(List<String> values) {
            addCriterion("cc_remark1 not in", values, "ccRemark1");
            return (Criteria) this;
        }

        public Criteria andCcRemark1Between(String value1, String value2) {
            addCriterion("cc_remark1 between", value1, value2, "ccRemark1");
            return (Criteria) this;
        }

        public Criteria andCcRemark1NotBetween(String value1, String value2) {
            addCriterion("cc_remark1 not between", value1, value2, "ccRemark1");
            return (Criteria) this;
        }

        public Criteria andCcRemark2IsNull() {
            addCriterion("cc_remark2 is null");
            return (Criteria) this;
        }

        public Criteria andCcRemark2IsNotNull() {
            addCriterion("cc_remark2 is not null");
            return (Criteria) this;
        }

        public Criteria andCcRemark2EqualTo(String value) {
            addCriterion("cc_remark2 =", value, "ccRemark2");
            return (Criteria) this;
        }

        public Criteria andCcRemark2NotEqualTo(String value) {
            addCriterion("cc_remark2 <>", value, "ccRemark2");
            return (Criteria) this;
        }

        public Criteria andCcRemark2GreaterThan(String value) {
            addCriterion("cc_remark2 >", value, "ccRemark2");
            return (Criteria) this;
        }

        public Criteria andCcRemark2GreaterThanOrEqualTo(String value) {
            addCriterion("cc_remark2 >=", value, "ccRemark2");
            return (Criteria) this;
        }

        public Criteria andCcRemark2LessThan(String value) {
            addCriterion("cc_remark2 <", value, "ccRemark2");
            return (Criteria) this;
        }

        public Criteria andCcRemark2LessThanOrEqualTo(String value) {
            addCriterion("cc_remark2 <=", value, "ccRemark2");
            return (Criteria) this;
        }

        public Criteria andCcRemark2Like(String value) {
            addCriterion("cc_remark2 like", value, "ccRemark2");
            return (Criteria) this;
        }

        public Criteria andCcRemark2NotLike(String value) {
            addCriterion("cc_remark2 not like", value, "ccRemark2");
            return (Criteria) this;
        }

        public Criteria andCcRemark2In(List<String> values) {
            addCriterion("cc_remark2 in", values, "ccRemark2");
            return (Criteria) this;
        }

        public Criteria andCcRemark2NotIn(List<String> values) {
            addCriterion("cc_remark2 not in", values, "ccRemark2");
            return (Criteria) this;
        }

        public Criteria andCcRemark2Between(String value1, String value2) {
            addCriterion("cc_remark2 between", value1, value2, "ccRemark2");
            return (Criteria) this;
        }

        public Criteria andCcRemark2NotBetween(String value1, String value2) {
            addCriterion("cc_remark2 not between", value1, value2, "ccRemark2");
            return (Criteria) this;
        }

        public Criteria andCcRemark3IsNull() {
            addCriterion("cc_remark3 is null");
            return (Criteria) this;
        }

        public Criteria andCcRemark3IsNotNull() {
            addCriterion("cc_remark3 is not null");
            return (Criteria) this;
        }

        public Criteria andCcRemark3EqualTo(String value) {
            addCriterion("cc_remark3 =", value, "ccRemark3");
            return (Criteria) this;
        }

        public Criteria andCcRemark3NotEqualTo(String value) {
            addCriterion("cc_remark3 <>", value, "ccRemark3");
            return (Criteria) this;
        }

        public Criteria andCcRemark3GreaterThan(String value) {
            addCriterion("cc_remark3 >", value, "ccRemark3");
            return (Criteria) this;
        }

        public Criteria andCcRemark3GreaterThanOrEqualTo(String value) {
            addCriterion("cc_remark3 >=", value, "ccRemark3");
            return (Criteria) this;
        }

        public Criteria andCcRemark3LessThan(String value) {
            addCriterion("cc_remark3 <", value, "ccRemark3");
            return (Criteria) this;
        }

        public Criteria andCcRemark3LessThanOrEqualTo(String value) {
            addCriterion("cc_remark3 <=", value, "ccRemark3");
            return (Criteria) this;
        }

        public Criteria andCcRemark3Like(String value) {
            addCriterion("cc_remark3 like", value, "ccRemark3");
            return (Criteria) this;
        }

        public Criteria andCcRemark3NotLike(String value) {
            addCriterion("cc_remark3 not like", value, "ccRemark3");
            return (Criteria) this;
        }

        public Criteria andCcRemark3In(List<String> values) {
            addCriterion("cc_remark3 in", values, "ccRemark3");
            return (Criteria) this;
        }

        public Criteria andCcRemark3NotIn(List<String> values) {
            addCriterion("cc_remark3 not in", values, "ccRemark3");
            return (Criteria) this;
        }

        public Criteria andCcRemark3Between(String value1, String value2) {
            addCriterion("cc_remark3 between", value1, value2, "ccRemark3");
            return (Criteria) this;
        }

        public Criteria andCcRemark3NotBetween(String value1, String value2) {
            addCriterion("cc_remark3 not between", value1, value2, "ccRemark3");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNull() {
            addCriterion("delete_flag is null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNotNull() {
            addCriterion("delete_flag is not null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagEqualTo(Byte value) {
            addCriterion("delete_flag =", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotEqualTo(Byte value) {
            addCriterion("delete_flag <>", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThan(Byte value) {
            addCriterion("delete_flag >", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThanOrEqualTo(Byte value) {
            addCriterion("delete_flag >=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThan(Byte value) {
            addCriterion("delete_flag <", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThanOrEqualTo(Byte value) {
            addCriterion("delete_flag <=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIn(List<Byte> values) {
            addCriterion("delete_flag in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotIn(List<Byte> values) {
            addCriterion("delete_flag not in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagBetween(Byte value1, Byte value2) {
            addCriterion("delete_flag between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotBetween(Byte value1, Byte value2) {
            addCriterion("delete_flag not between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteTimeIsNull() {
            addCriterion("delete_time is null");
            return (Criteria) this;
        }

        public Criteria andDeleteTimeIsNotNull() {
            addCriterion("delete_time is not null");
            return (Criteria) this;
        }

        public Criteria andDeleteTimeEqualTo(Date value) {
            addCriterion("delete_time =", value, "deleteTime");
            return (Criteria) this;
        }

        public Criteria andDeleteTimeNotEqualTo(Date value) {
            addCriterion("delete_time <>", value, "deleteTime");
            return (Criteria) this;
        }

        public Criteria andDeleteTimeGreaterThan(Date value) {
            addCriterion("delete_time >", value, "deleteTime");
            return (Criteria) this;
        }

        public Criteria andDeleteTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("delete_time >=", value, "deleteTime");
            return (Criteria) this;
        }

        public Criteria andDeleteTimeLessThan(Date value) {
            addCriterion("delete_time <", value, "deleteTime");
            return (Criteria) this;
        }

        public Criteria andDeleteTimeLessThanOrEqualTo(Date value) {
            addCriterion("delete_time <=", value, "deleteTime");
            return (Criteria) this;
        }

        public Criteria andDeleteTimeIn(List<Date> values) {
            addCriterion("delete_time in", values, "deleteTime");
            return (Criteria) this;
        }

        public Criteria andDeleteTimeNotIn(List<Date> values) {
            addCriterion("delete_time not in", values, "deleteTime");
            return (Criteria) this;
        }

        public Criteria andDeleteTimeBetween(Date value1, Date value2) {
            addCriterion("delete_time between", value1, value2, "deleteTime");
            return (Criteria) this;
        }

        public Criteria andDeleteTimeNotBetween(Date value1, Date value2) {
            addCriterion("delete_time not between", value1, value2, "deleteTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("update_time is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("update_time is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("update_time =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("update_time <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("update_time >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("update_time >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("update_time <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("update_time <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("update_time in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("update_time not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("update_time between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("update_time not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNull() {
            addCriterion("update_user_id is null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNotNull() {
            addCriterion("update_user_id is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdEqualTo(String value) {
            addCriterion("update_user_id =", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotEqualTo(String value) {
            addCriterion("update_user_id <>", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThan(String value) {
            addCriterion("update_user_id >", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThanOrEqualTo(String value) {
            addCriterion("update_user_id >=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThan(String value) {
            addCriterion("update_user_id <", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThanOrEqualTo(String value) {
            addCriterion("update_user_id <=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLike(String value) {
            addCriterion("update_user_id like", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotLike(String value) {
            addCriterion("update_user_id not like", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIn(List<String> values) {
            addCriterion("update_user_id in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotIn(List<String> values) {
            addCriterion("update_user_id not in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdBetween(String value1, String value2) {
            addCriterion("update_user_id between", value1, value2, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotBetween(String value1, String value2) {
            addCriterion("update_user_id not between", value1, value2, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andActivateTimeIsNull() {
            addCriterion("activate_time is null");
            return (Criteria) this;
        }

        public Criteria andActivateTimeIsNotNull() {
            addCriterion("activate_time is not null");
            return (Criteria) this;
        }

        public Criteria andActivateTimeEqualTo(Date value) {
            addCriterion("activate_time =", value, "activateTime");
            return (Criteria) this;
        }

        public Criteria andActivateTimeNotEqualTo(Date value) {
            addCriterion("activate_time <>", value, "activateTime");
            return (Criteria) this;
        }

        public Criteria andActivateTimeGreaterThan(Date value) {
            addCriterion("activate_time >", value, "activateTime");
            return (Criteria) this;
        }

        public Criteria andActivateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("activate_time >=", value, "activateTime");
            return (Criteria) this;
        }

        public Criteria andActivateTimeLessThan(Date value) {
            addCriterion("activate_time <", value, "activateTime");
            return (Criteria) this;
        }

        public Criteria andActivateTimeLessThanOrEqualTo(Date value) {
            addCriterion("activate_time <=", value, "activateTime");
            return (Criteria) this;
        }

        public Criteria andActivateTimeIn(List<Date> values) {
            addCriterion("activate_time in", values, "activateTime");
            return (Criteria) this;
        }

        public Criteria andActivateTimeNotIn(List<Date> values) {
            addCriterion("activate_time not in", values, "activateTime");
            return (Criteria) this;
        }

        public Criteria andActivateTimeBetween(Date value1, Date value2) {
            addCriterion("activate_time between", value1, value2, "activateTime");
            return (Criteria) this;
        }

        public Criteria andActivateTimeNotBetween(Date value1, Date value2) {
            addCriterion("activate_time not between", value1, value2, "activateTime");
            return (Criteria) this;
        }

        public Criteria andDisableTimeIsNull() {
            addCriterion("disable_time is null");
            return (Criteria) this;
        }

        public Criteria andDisableTimeIsNotNull() {
            addCriterion("disable_time is not null");
            return (Criteria) this;
        }

        public Criteria andDisableTimeEqualTo(Date value) {
            addCriterion("disable_time =", value, "disableTime");
            return (Criteria) this;
        }

        public Criteria andDisableTimeNotEqualTo(Date value) {
            addCriterion("disable_time <>", value, "disableTime");
            return (Criteria) this;
        }

        public Criteria andDisableTimeGreaterThan(Date value) {
            addCriterion("disable_time >", value, "disableTime");
            return (Criteria) this;
        }

        public Criteria andDisableTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("disable_time >=", value, "disableTime");
            return (Criteria) this;
        }

        public Criteria andDisableTimeLessThan(Date value) {
            addCriterion("disable_time <", value, "disableTime");
            return (Criteria) this;
        }

        public Criteria andDisableTimeLessThanOrEqualTo(Date value) {
            addCriterion("disable_time <=", value, "disableTime");
            return (Criteria) this;
        }

        public Criteria andDisableTimeIn(List<Date> values) {
            addCriterion("disable_time in", values, "disableTime");
            return (Criteria) this;
        }

        public Criteria andDisableTimeNotIn(List<Date> values) {
            addCriterion("disable_time not in", values, "disableTime");
            return (Criteria) this;
        }

        public Criteria andDisableTimeBetween(Date value1, Date value2) {
            addCriterion("disable_time between", value1, value2, "disableTime");
            return (Criteria) this;
        }

        public Criteria andDisableTimeNotBetween(Date value1, Date value2) {
            addCriterion("disable_time not between", value1, value2, "disableTime");
            return (Criteria) this;
        }
    }

    /**
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}