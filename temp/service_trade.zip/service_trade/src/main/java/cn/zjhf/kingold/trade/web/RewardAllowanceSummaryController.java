package cn.zjhf.kingold.trade.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.constant.RewardPrivateStatus;
import cn.zjhf.kingold.trade.constant.RewardSummaryStatus;
import cn.zjhf.kingold.trade.constant.Separator;
import cn.zjhf.kingold.trade.dto.RewardApplyDto;
import cn.zjhf.kingold.trade.dto.RewardSearchDto;
import cn.zjhf.kingold.trade.entity.RewardPrivateFund;
import cn.zjhf.kingold.trade.entity.RewardServiceAllowance;
import cn.zjhf.kingold.trade.service.IRewardAllowanceSummaryService;
import com.alibaba.fastjson.JSON;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.*;

/**
 * Created by lutiehua on 2017/6/14.
 */
@RestController
@RequestMapping(value = "/reward/summary/allowance")
public class RewardAllowanceSummaryController {

    @Autowired
    private IRewardAllowanceSummaryService rewardAllowanceSummaryService;

    /**
     * 请求生成批量服务津贴结算单
     *
     * @param rewardApplyDto
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "", method = RequestMethod.POST)
    public ResponseResult applyServiceAward(@RequestBody @Valid RewardApplyDto rewardApplyDto) throws BusinessException {
        return rewardAllowanceSummaryService.applyServiceReward(rewardApplyDto);
    }

    /**
     * 查询服务津贴发放记录
     *
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/search", method = RequestMethod.GET)
    public ResponseResult getAllowanceSummaryList(@RequestParam Map<String, Object> param) throws BusinessException {
        String jsonString = JSON.toJSONString(param);
        RewardSearchDto searchCondition = JSON.parseObject(jsonString, RewardSearchDto.class);

        // 保证""不作为查询条件
        if (StringUtils.isEmpty(searchCondition.getUserMobile())) {
            searchCondition.setUserMobile(null);
        }
        if (StringUtils.isEmpty(searchCondition.getUserName())) {
            searchCondition.setUserName(null);
        }

        if (null != searchCondition.getClearEndDate()) {
            // 包括结束日期，查询时加1天
            Date endDate = searchCondition.getClearEndDate();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(endDate);
            calendar.add(Calendar.DAY_OF_YEAR, 1);
            endDate = calendar.getTime();
            searchCondition.setClearEndDate(endDate);
        }

        List<RewardServiceAllowance> rewardList = rewardAllowanceSummaryService.search(searchCondition);
        int count = rewardAllowanceSummaryService.searchCount(searchCondition);
        Map<String, Object> data = new HashMap<>();
        data.put("list", rewardList);
        data.put("count", count);
        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        responseResult.setTraceID(searchCondition.getTraceID());
        responseResult.setData(data);
        return responseResult;
    }

    /**
     * 获取服务津贴汇总记录信息
     *
     * @param rewardAllowanceBillCode
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/{rewardAllowanceBillCode}", method = RequestMethod.GET)
    public ResponseResult getFixedAward(@PathVariable("rewardAllowanceBillCode") String rewardAllowanceBillCode) throws BusinessException {
        RewardServiceAllowance rewardServiceAllowance = rewardAllowanceSummaryService.getAllowanceAward(rewardAllowanceBillCode);
        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        responseResult.setData(rewardServiceAllowance);
        return responseResult;
    }

    /**
     * 审核服务津贴
     *
     * @param param
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/check", method = RequestMethod.PUT)
    public ResponseResult check(@RequestBody Map<String, Object> param) throws BusinessException {
        ResponseResult responseResult = new ResponseResult();

        // 参数检查
        if (null == param.get("rewardAllowanceBillCode") || null == param.get("pass")) {
            responseResult.setCode(ResponseCode.PARAM_ERROR);
            responseResult.setMsg(ResponseCode.PARAM_ERROR_TEXT);
            return responseResult;
        }

        String rewardAllowanceBillCode = param.get("rewardAllowanceBillCode").toString();
        if (StringUtils.isEmpty(rewardAllowanceBillCode)) {
            responseResult.setCode(ResponseCode.PARAM_ERROR);
            responseResult.setMsg(ResponseCode.PARAM_ERROR_TEXT);
            return responseResult;
        }

        // 拼装请求参数
        Map<String, Object> checkMap = new HashMap<>();
        checkMap.put("rewardAllowanceBillCode", rewardAllowanceBillCode);

        int pass = Integer.parseInt(param.get("pass").toString());
        checkMap.put("pass", pass);

        String checkUser = null;
        if (null != param.get("userUuid")) {
            String userString = param.get("userUuid").toString();
            if (StringUtils.isNotEmpty(userString)) {
                checkUser = userString;
            }
        }

        if (pass == 1) {
            checkMap.put("rewardAllowanceStatus", RewardSummaryStatus.CHECKED);
            checkMap.put("checkTime", new Date());
            checkMap.put("remark", "");
            if (null != checkUser) {
                checkMap.put("checkUser", checkUser);
            }
        } else {
            checkMap.put("rewardAllowanceStatus", RewardSummaryStatus.DELETE);
            checkMap.put("checkTime", null);
            if (null != param.get("remark")) {
                String remarkString = param.get("remark").toString();
                if (StringUtils.isNotEmpty(remarkString)) {
                    checkMap.put("remark", remarkString);
                }
            }
            if (null != checkUser) {
                checkMap.put("checkUser", checkUser);
            }
        }

        // 返回执行结果
        return rewardAllowanceSummaryService.updateCheckStatus(checkMap);
    }

    /**
     * 发放服务津贴
     *
     * @param param
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/clear", method = RequestMethod.PUT)
    public ResponseResult clear(@RequestBody Map<String, Object> param) throws BusinessException {
        ResponseResult responseResult = new ResponseResult();

        // 参数检查
        if (null == param.get("rewardAllowanceBillCode") || null == param.get("pass")) {
            responseResult.setCode(ResponseCode.PARAM_ERROR);
            responseResult.setMsg(ResponseCode.PARAM_ERROR_TEXT);
            return responseResult;
        }

        String rewardAllowanceBillCode = param.get("rewardAllowanceBillCode").toString();
        if (StringUtils.isEmpty(rewardAllowanceBillCode)) {
            responseResult.setCode(ResponseCode.PARAM_ERROR);
            responseResult.setMsg(ResponseCode.PARAM_ERROR_TEXT);
            return responseResult;
        }

        // 拼装请求参数
        Map<String, Object>  clearMap = new HashMap<>();
        // 单号
        clearMap.put("rewardAllowanceBillCode", rewardAllowanceBillCode);

        // 是否通过
        int pass = Integer.parseInt(param.get("pass").toString());
        clearMap.put("pass", pass);

        // 操作人
        if (null != param.get("userUuid")) {
            String userString = param.get("userUuid").toString();
            if (StringUtils.isNotEmpty(userString)) {
                clearMap.put("clearUser", userString);
            }
        }

        if (pass == 1) {
            clearMap.put("rewardAllowanceStatus", RewardSummaryStatus.FINISH);
            clearMap.put("clearTime", new Date());
            clearMap.put("remark", "");
        } else {
            clearMap.put("rewardAllowanceStatus", RewardSummaryStatus.REJECT);
            clearMap.put("clearTime", null);
            if (null != param.get("remark")) {
                String remarkString = param.get("remark").toString();
                if (StringUtils.isNotEmpty(remarkString)) {
                    clearMap.put("remark", remarkString);
                }
            }
        }

        // 返回执行结果
        return rewardAllowanceSummaryService.updateClearStatus(clearMap);
    }
}
