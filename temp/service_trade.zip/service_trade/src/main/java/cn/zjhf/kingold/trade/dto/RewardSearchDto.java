package cn.zjhf.kingold.trade.dto;

import cn.zjhf.kingold.common.param.ParamVO;

import java.util.Date;
import java.util.List;

/**
 * 奖励查询条件
 *
 * Created by lutiehua on 2017/6/1.
 */
public class RewardSearchDto extends ParamVO {
    /* PART1 产品信息 */

    /**
     * 产品类型
     */
    private String productType;

    /**
     * 产品名称
     */
    private String productName;


    /* PART2 用户信息 */

    /**
     * 用户手机号
     */
    private String userMobile;

    /**
     * 用户名
     */
    private String userName;

    private String belongTopUserUuid;

    private String belongTopOrgPath;


    /* PART3 订单和奖励单信息 */

    /**
     * 投资单号
     */
    private String orderBillCode;

    /**
     * 奖励单号
     */
    private String rewardBillCode;

    /**
     * 奖励类型
     */
    private Integer rewardType;

    /**
     * 奖励
     */
    private List<Integer> rewardTypes;

    /**
     * 奖励状态
     */
    private Integer rewardStatus;

    /**
     * 是否有效奖励
     */
    private Integer isEnabledReward;


    /* PART4 时间区间 */

    /**
     * 创建时间-开始
     */
    private Date fromCreateTime;

    /**
     * 创建时间-结束
     */
    private Date toCreateTime;

    /**
     * 更新时间-开始
     */
    private Date fromUpdateTime;

    /**
     * 更新时间-结束
     */
    private Date toUpdateTime;

    /**
     * 结算时间-开始
     */
    private Date clearStartDate;

    /**
     * 结算时间-结束
     */
    private Date clearEndDate;


    /* PART5 分页信息 */

    /**
     * pageNo
     */
    private Integer pageNo;

    /**
     * pageSize
     */
    private Integer pageSize;

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getOrderBillCode() {
        return orderBillCode;
    }

    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    public String getUserMobile() {
        return userMobile;
    }

    public void setUserMobile(String userMobile) {
        this.userMobile = userMobile;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getBelongTopUserUuid() {
        return belongTopUserUuid;
    }

    public void setBelongTopUserUuid(String belongTopUserUuid) {
        this.belongTopUserUuid = belongTopUserUuid;
    }

    public String getBelongTopOrgPath() {
        return belongTopOrgPath;
    }

    public void setBelongTopOrgPath(String belongTopOrgPath) {
        this.belongTopOrgPath = belongTopOrgPath;
    }

    public Date getClearStartDate() {
        return clearStartDate;
    }

    public void setClearStartDate(Date clearStartDate) {
        this.clearStartDate = clearStartDate;
    }

    public Date getClearEndDate() {
        return clearEndDate;
    }

    public void setClearEndDate(Date clearEndDate) {
        this.clearEndDate = clearEndDate;
    }

    public String getRewardBillCode() {
        return rewardBillCode;
    }

    public void setRewardBillCode(String rewardBillCode) {
        this.rewardBillCode = rewardBillCode;
    }

    public Date getFromUpdateTime() {
        return fromUpdateTime;
    }

    public void setFromUpdateTime(Date fromUpdateTime) {
        this.fromUpdateTime = fromUpdateTime;
    }

    public Date getToUpdateTime() {
        return toUpdateTime;
    }

    public void setToUpdateTime(Date toUpdateTime) {
        this.toUpdateTime = toUpdateTime;
    }

    public String getRewardAllowanceBatchCode() {
        return rewardAllowanceBatchCode;
    }

    public void setRewardAllowanceBatchCode(String rewardAllowanceBatchCode) {
        this.rewardAllowanceBatchCode = rewardAllowanceBatchCode;
    }

    public String getRewardAllowanceBillCode() {
        return rewardAllowanceBillCode;
    }

    public void setRewardAllowanceBillCode(String rewardAllowanceBillCode) {
        this.rewardAllowanceBillCode = rewardAllowanceBillCode;
    }

    private String rewardAllowanceBillCode;

    private String rewardAllowanceBatchCode;

    public Integer getPageNo() {
        return pageNo;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getRewardType() {
        return rewardType;
    }

    public void setRewardType(Integer rewardType) {
        this.rewardType = rewardType;
    }

    public Integer getRewardStatus() {
        return rewardStatus;
    }

    public void setRewardStatus(Integer rewardStatus) {
        this.rewardStatus = rewardStatus;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public Date getFromCreateTime() {
        return fromCreateTime;
    }

    public void setFromCreateTime(Date fromCreateTime) {
        this.fromCreateTime = fromCreateTime;
    }

    public Date getToCreateTime() {
        return toCreateTime;
    }

    public void setToCreateTime(Date toCreateTime) {
        this.toCreateTime = toCreateTime;
    }

    public Integer getIsEnabledReward() {
        return isEnabledReward;
    }

    public void setIsEnabledReward(Integer isEnabledReward) {
        this.isEnabledReward = isEnabledReward;
    }

    public List<Integer> getRewardTypes() {
        return rewardTypes;
    }

    public void setRewardTypes(List<Integer> rewardTypes) {
        this.rewardTypes = rewardTypes;
    }
}
