package cn.zjhf.kingold.trade.entity.InVO;

import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * Created by zhangyijie on 2017/6/5.
 */
@ApiModel(value = "ProductRewardSummaryBatchAuditVO", description = "批量报税审核/批量报税  公用入参")
public class ProductRewardSummaryBatchAuditVO extends InVOBase {
    @ApiModelProperty(required = true, value = "traceID")
    @NotEmpty
    private String traceID;

    @ApiModelProperty(required = true, value = "产品Uuid列表，以|间隔")
    @NotEmpty
    private String productUuidList;

    @ApiModelProperty(required = true, value = "用户名")
    @NotEmpty
    private String userPhone;

    @ApiModelProperty(required = true, value = "是否审核通过，仅在审核时使用，1审核通过  0审核未通过")
    private int isAudited;

    @ApiModelProperty(required = true, value = "审核不通过的原因，仅在审核失败(isAudited == 0)时使用")
    private String message;

    @Override
    public String getTraceID() {
        return traceID;
    }

    @Override
    public void setTraceID(String traceID) {
        this.traceID = traceID;
    }

    public String getProductUuidList() {
        return productUuidList;
    }

    public void setProductUuidList(String productUuidList) {
        this.productUuidList = productUuidList;
    }

    public int getIsAudited() {
        return isAudited;
    }

    public void setIsAudited(int isAudited) {
        this.isAudited = isAudited;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(traceID) + ", ");
        sb.append("productUuidList:" + DataUtils.toString(productUuidList) + ", ");
        sb.append("userPhone:" + DataUtils.toString(userPhone) + ", ");
        sb.append("isAudited:" + DataUtils.toString(isAudited) + ", ");
        sb.append("message:" + DataUtils.toString(message));
        return sb.toString();
    }
}
