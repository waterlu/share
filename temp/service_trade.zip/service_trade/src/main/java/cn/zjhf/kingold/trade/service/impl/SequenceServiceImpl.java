package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.trade.persistence.dao.CouponExtendRecordMapper;
import cn.zjhf.kingold.trade.persistence.dao.TradeOrderMapper;
import cn.zjhf.kingold.trade.service.ISequenceService;
import cn.zjhf.kingold.trade.utils.DataUtils;
import cn.zjhf.kingold.trade.utils.DateUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by zhangyijie on 2017/7/5.
 */
@Service
public class SequenceServiceImpl implements ISequenceService, InitializingBean {
    protected static final Logger logger = LoggerFactory.getLogger(SequenceServiceImpl.class);

    String cashCouponCode = null;

    String subContractNo = null;

    String couponExtendRecordNo = null;

    static String cashCouponCodeMode = null;
    static String subContractNoMode = null;
    static {
        int prifixLen = 10;
        cashCouponCodeMode = DataUtils.padStr(prifixLen, '_');

        prifixLen = 7;
        subContractNoMode = DataUtils.padStr(prifixLen, '_');
    }

    @Value("${server.number}")
    private String serverNumber;

    public SequenceServiceImpl(){
    }

    private void initServerNumber() {
        serverNumber = serverNumber.trim();

        if(serverNumber.length() > 0) {
            serverNumber = serverNumber.trim().substring(0, 1);
        }else {
            serverNumber = "0";
        }
    }

    private static String toYYMDD() {
        DateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        int iDate = Integer.parseInt(sdf.format(new Date()));

        int month = (iDate % 10000) / 100;
        String smonth = "";
        if (month < 10) {
            smonth = String.valueOf(month);
        } else if (month == 10) {
            smonth = "A";
        } else if (month == 11) {
            smonth = "B";
        } else if (month == 12) {
            smonth = "C";
        }

        String day = String.valueOf(iDate).substring(6, 8);
        return String.valueOf(iDate).substring(2, 4) + smonth + day;
    }

    //格式: PL + YYYYMMDD + 1位服务器顺序码 + 2位顺序号
    private String getNewCashCouponCode() {
        final String prefix = "PL";
        final int sequenceValidLen = 2;

        String curDate = DateUtil.getCueDate();
        final int sequenceLen = prefix.length() + curDate.length() + 1 + sequenceValidLen;
        final int sequenceBeginIndex = sequenceLen - sequenceValidLen;

        int curSequence = 0;

        if((cashCouponCode != null) && (cashCouponCode.length() >= sequenceLen)) {
            try {
                String date = cashCouponCode.substring(prefix.length(), prefix.length() + curDate.length());

                if(date.equals(curDate)) {
                    try {
                        curSequence = Integer.parseInt(cashCouponCode.trim().substring(sequenceBeginIndex, sequenceLen));
                    }catch (Exception e) {
                        curSequence = 0;
                    }
                }
            }catch (Exception e) {
            }
        }

        return prefix + curDate + serverNumber + DataUtils.leftPad(++curSequence, sequenceValidLen);
    }

    //格式: RG + YYMDD + 1位服务器顺序码 + 4位顺序号
    private String getNewSubContractNo() {
        final String prefix = "RG";
        final int sequenceValidLen = 4;

        String curDate = toYYMDD();
        final int sequenceLen = prefix.length() + curDate.length() + 1 + sequenceValidLen;
        final int sequenceBeginIndex = sequenceLen - sequenceValidLen;

        int curSequence = 0;
        if((subContractNo != null) && (subContractNo.length() >= sequenceLen)) {
            try {
                String date = subContractNo.substring(prefix.length(), prefix.length()+curDate.length());

                if(date.equals(curDate)) {
                    try {
                        curSequence = Integer.parseInt(subContractNo.trim().substring(sequenceBeginIndex, sequenceLen));
                    }catch (Exception e) {
                        curSequence = 0;
                    }
                }
            }catch (Exception e) {
            }
        }

        return prefix + curDate + serverNumber + DataUtils.leftPad(++curSequence, sequenceValidLen);
    }

    //格式: 1位服务器顺序码 + 8位顺序号
    private String getNewCouponExtendRecordNo() {
        final int sequenceValidLen = 8;
        final int sequenceLen = 1 + sequenceValidLen;
        int curSequence = 0;
        if((couponExtendRecordNo != null) && (couponExtendRecordNo.trim().length() == sequenceLen)) {
            try {
                curSequence = Integer.parseInt(couponExtendRecordNo.trim().substring(1,sequenceLen));
            }catch (Exception e) {
                curSequence = 0;
            }
        }

        return  serverNumber + DataUtils.leftPad(++curSequence, sequenceValidLen);
    }

    @Override
    public synchronized String getCashCouponCode(CashCouponServiceImpl cashCouponService){
        if(null == cashCouponCode) {
            cashCouponCode = cashCouponService.lstLastSequence(cashCouponCodeMode + serverNumber + "%");

            if(DataUtils.isNotEmpty(cashCouponCode)) {
                cashCouponCode = cashCouponCode.trim();
            }
        }

        cashCouponCode = getNewCashCouponCode();
        return cashCouponCode;
    }

    @Override
    public synchronized String getSubContractNo(TradeOrderMapper tradeOrderMapper){
        if(null == subContractNo) {
            subContractNo = tradeOrderMapper.lstLastSubContractNo(subContractNoMode + serverNumber + "%");

            if(DataUtils.isNotEmpty(subContractNo)) {
                subContractNo = subContractNo.trim();
            }
        }

        subContractNo = getNewSubContractNo();
        return subContractNo;
    }

    @Override
    public synchronized String getCouponExtendRecordNo(CouponExtendRecordMapper couponExtendRecordMapper) {
        if(null == couponExtendRecordNo) {
            couponExtendRecordNo = couponExtendRecordMapper.lstLastCouponExtendCodeNo(serverNumber + "%");

            if(DataUtils.isNotEmpty(couponExtendRecordNo)) {
                couponExtendRecordNo = couponExtendRecordNo.trim();
            }
        }

        couponExtendRecordNo = getNewCouponExtendRecordNo();
        return DataUtils.base64Encode(couponExtendRecordNo);
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        logger.info("serverNumber={}", serverNumber);
    }
}
