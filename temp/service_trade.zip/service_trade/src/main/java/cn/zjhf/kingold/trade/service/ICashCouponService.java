package cn.zjhf.kingold.trade.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.entity.CashCoupon;
import cn.zjhf.kingold.trade.entity.InVO.*;
import cn.zjhf.kingold.trade.entity.OutVO.CashCouponItemListVO;
import cn.zjhf.kingold.trade.entity.OutVO.ProductCouponItemVO;
import cn.zjhf.kingold.trade.utils.Tuple.TwoTuple;

import java.util.List;
import java.util.Map;

/**
 * Created by zhangyijie on 2017/7/5.
 */
public interface ICashCouponService {

    /**
     * 创建优惠券
     * @param cashCouponVO
     * @return
     * @throws BusinessException
     */
    String establishCashCoupon(CashCouponVO cashCouponVO) throws BusinessException;

    /**
     * 更新优惠券
     * @param cashCouponVO
     * @return
     * @throws BusinessException
     */
    Boolean updateCashCoupon(CashCouponVO cashCouponVO) throws BusinessException;

    /**
     * 查询优惠券的列表
     * @param lstCondition
     * @return
     * @throws BusinessException
     */
    CashCouponItemListVO lstCashCoupon(LstCashCouponConditionVO lstCondition) throws BusinessException;

    String lstLastSequence(String idMode);

    /**
     * 查询单个现金券
     * @param ccCode
     * @return
     * @throws BusinessException
     */
    CashCouponVO lstCashCoupon(String ccCode) throws BusinessException;

    /**
     * 更新现金券的状态
     * @param commCouponUpdateVO
     * @throws BusinessException
     */
    void updateStatus(CommCouponUpdateVO commCouponUpdateVO) throws BusinessException;

    void updateStatus(String ccCode, int status, String updateUserId) throws BusinessException;

    /**
     * 自动状态刷新
     * @throws BusinessException
     */
    void autoRefreshStatus();

    List<ProductCouponItemVO> cashCouponByProductList(List<ProductVO> productList) throws BusinessException;

    /**
     * 查询礼券的可用数量
     * @param ccCode
     * @return
     * @throws BusinessException
     */
    TwoTuple<Integer, Integer> lstAvailableQuantity(String ccCode) throws BusinessException;

    /**
     * 检测该批次礼券是否已经被领完
     * @param ccCode
     * @throws BusinessException
     */
    void checkCashCouponExhausted(String ccCode) throws BusinessException;

    /**
     * 查询单个有效的现金券
     * @param ccCode
     * @return
     * @throws BusinessException
     */
    CashCoupon lstValidCashCoupon(String ccCode) throws BusinessException;

    /**
     * 判断该现金券是否适配交易
     * @param couponCode
     * @param productUuid
     * @param amt
     * @return
     * @throws BusinessException
     */
    Boolean isAdaptTrade(String couponCode,String productUuid, double amt) throws BusinessException;

    /**
     * 根据现金券的批次号反向查询适用的产品
     * @param ccCode
     * @param merchantNum
     * @return Map 包含产品列表和产品总数
     * @throws BusinessException
     */
    Map lstAdaptProduct(String ccCode, Integer startRow, Integer pageSize, String merchantNum) throws BusinessException;

    /**
     * 获取全部礼券
     * @return
     * @throws BusinessException
     */
    List<CashCouponVO> getAllCoupon() throws BusinessException;

    /**
     * 根据查询条件获取礼券
     * @param params
     * @return
     * @throws BusinessException
     */
    List<CashCouponVO> getCouponList(Map params) throws BusinessException;

}
