package cn.zjhf.kingold.trade.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.common.utils.MapRemoveNullUtil;
import cn.zjhf.kingold.trade.constant.MarketCampaignCodeEnum;
import cn.zjhf.kingold.trade.constant.TradeStatusMsg;
import cn.zjhf.kingold.trade.dto.CouponSendConditionDto;
import cn.zjhf.kingold.trade.entity.InVO.*;
import cn.zjhf.kingold.trade.entity.OutVO.*;
import cn.zjhf.kingold.trade.service.ICashCouponService;
import cn.zjhf.kingold.trade.service.ICouponExtendRecordService;
import cn.zjhf.kingold.trade.service.IMarketCampaignService;
import cn.zjhf.kingold.trade.utils.*;
import cn.zjhf.kingold.trade.utils.Tuple.TwoTuple;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.constraints.NotEmpty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by zhangyijie on 2017/7/5.
 */
@RestController
@RequestMapping(value = "/coupon")
public class CouponController {
    protected static final Logger logger = LoggerFactory.getLogger(CouponController.class);

    @Autowired
    ICashCouponService cashCouponService;

    @Autowired
    IMarketCampaignService marketCampaignService;

    @Autowired
    ICouponExtendRecordService couponExtendRecordService;

    private ResponseResult creatOKRespResult(String traceID) {
        ResponseResult respResult = new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS,"成功");
        return respResult;
    }

    private ResponseResult creatOKRespResult(String traceID, Object data) {
        ResponseResult respResult = new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS,"成功", data);
        return respResult;
    }

    /**
     * Step1 礼券创建
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/establishCashCoupon", method = RequestMethod.PUT)
    public ResponseResult establishCashCoupon(@RequestBody CashCouponVO cashCouponVO) throws BusinessException {
        logger.info("establishCashCoupon start: " + DataUtils.toString(cashCouponVO));
        DataUtils.checkParam(cashCouponVO.getUpdateUserId());

        String ccCode = cashCouponService.establishCashCoupon(cashCouponVO);

        logger.info("establishCashCoupon end: " + DataUtils.toString(cashCouponVO.getTraceID(), ccCode));
        return creatOKRespResult(cashCouponVO.getTraceID(), ccCode);
    }

    /**
     * Step2 礼券修改,
     * 礼券编号不可修改，不可通过该接口修改状态
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/updateCashCoupon", method = RequestMethod.PUT)
    public ResponseResult updateCashCoupon(@RequestBody CashCouponVO cashCouponVO) throws BusinessException {
        logger.info("updateCashCoupon start: " + DataUtils.toString(cashCouponVO));

        DataUtils.checkParam(cashCouponVO.getCcCode(), cashCouponVO.getUpdateUserId());
        cashCouponService.updateCashCoupon(cashCouponVO);

        logger.info("updateCashCoupon end: " + DataUtils.toString(cashCouponVO.getTraceID()));
        return creatOKRespResult(cashCouponVO.getTraceID());
    }

    /**
     * Step3 礼券列表查询
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/lstCashCouponItems", method = RequestMethod.GET)
    public ResponseResult lstCashCouponItems(@RequestParam Map<String, Object> param) throws BusinessException {
        String jsonString = JSON.toJSONString(param);
        LstCashCouponConditionVO lstCashCouponConditionVO = JSON.parseObject(jsonString, LstCashCouponConditionVO.class);
        logger.info("lstCashCouponItems start: " + DataUtils.toString(lstCashCouponConditionVO));

        CashCouponItemListVO CashCouponItemList = cashCouponService.lstCashCoupon(lstCashCouponConditionVO);

        logger.info("lstCashCouponItems end: " + DataUtils.toString(lstCashCouponConditionVO.getTraceID(), CashCouponItemList));
        return creatOKRespResult(lstCashCouponConditionVO.getTraceID(), CashCouponItemList);
    }

    /**
     * Step4 礼券单条查询
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/lstCashCoupon", method = RequestMethod.GET)
    public ResponseResult lstCashCoupon(@RequestParam Map<String, Object> param) throws BusinessException {
        String jsonString = JSON.toJSONString(param);
        LstCashCouponConditionVO lstCashCouponConditionVO = JSON.parseObject(jsonString, LstCashCouponConditionVO.class);
        logger.info("lstCashCoupon start: " + DataUtils.toString(lstCashCouponConditionVO));

        DataUtils.checkParam(lstCashCouponConditionVO.getCcCode());

        CashCouponVO cashCouponVO = cashCouponService.lstCashCoupon(lstCashCouponConditionVO.getCcCode());

        logger.info("lstCashCoupon end: " + DataUtils.toString(lstCashCouponConditionVO.getTraceID(), cashCouponVO));
        return creatOKRespResult(lstCashCouponConditionVO.getTraceID(), cashCouponVO);
    }

    /**
     * Step5 更新礼券状态
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/updateCashCouponStatus", method = RequestMethod.PUT)
    public ResponseResult updateCashCouponStatus(@RequestBody CommCouponUpdateVO commCouponUpdateVO) throws BusinessException {
        logger.info("updateCashCouponStatus start: " + DataUtils.toString(commCouponUpdateVO));
        //DataUtils.checkParam(commCouponUpdateVO.getNewStatus());
        cashCouponService.updateStatus(commCouponUpdateVO);
        logger.info("updateCashCouponStatus end: " + DataUtils.toString(commCouponUpdateVO.getTraceID()));
        return creatOKRespResult(commCouponUpdateVO.getTraceID());
    }

    /**
     * Step11 活动创建
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/establishMarketCampaign", method = RequestMethod.PUT)
    public ResponseResult establishMarketCampaign(@RequestBody MarketCampaignVO marketCampaignVO) throws BusinessException {
        logger.info("establishMarketCampaign start: " + DataUtils.toString(marketCampaignVO));

        DataUtils.checkParam(marketCampaignVO.getUpdateUserId());
        String mcCode = marketCampaignService.establishMarketCampaign(marketCampaignVO);

        logger.info("establishMarketCampaign end: " + DataUtils.toString(marketCampaignVO.getTraceID(), mcCode));
        return creatOKRespResult(marketCampaignVO.getTraceID(), mcCode);
    }

    /**
     * Step12 活动修改
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/updateMarketCampaign", method = RequestMethod.PUT)
    public ResponseResult updateMarketCampaign(@RequestBody MarketCampaignVO marketCampaignVO) throws BusinessException {
        logger.info("updateMarketCampaign start: " + DataUtils.toString(marketCampaignVO));

        marketCampaignService.updateMarketCampaign(marketCampaignVO);

        logger.info("updateMarketCampaign end: " + DataUtils.toString(marketCampaignVO.getTraceID()));
        return creatOKRespResult(marketCampaignVO.getTraceID());
    }

    /**
     * Step13 活动列表查询
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/lstMarketCampaignItems", method = RequestMethod.GET)
    public ResponseResult lstMarketCampaignItems(@RequestParam Map<String, Object> param) throws BusinessException {
        String jsonString = JSON.toJSONString(param);
        LstMarketCampaignConditionVO lstConditionVO = JSON.parseObject(jsonString, LstMarketCampaignConditionVO.class);
        logger.info("lstMarketCampaignItems start: " + DataUtils.toString(lstConditionVO));

        MarketCampaignItemListVO itemList = marketCampaignService.lstMarketCampaign(lstConditionVO);

        logger.info("lstMarketCampaignItems end: " + DataUtils.toString(lstConditionVO.getTraceID(), itemList));
        return creatOKRespResult(lstConditionVO.getTraceID(), itemList);
    }

    /**
     * Step14 活动单条查询
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/lstMarketCampaign", method = RequestMethod.GET)
    public ResponseResult lstMarketCampaign(String traceID,@RequestParam("mcId") @NotEmpty Integer mcId) throws BusinessException {
        logger.info("lstMarketCampaign start: " + DataUtils.toString(mcId));
        DataUtils.checkParam(mcId);
        MarketCampaignVO marketCampaignVO = marketCampaignService.lstMarketCampaign(mcId);

        logger.info("lstCashCoupon end: " + DataUtils.toString(traceID, marketCampaignVO));
        return creatOKRespResult(traceID, marketCampaignVO);
    }

    /**
     * Step15 活动触发(给投资者分配现金券)
     * @param dto
     * mcCode: 1注册,2实名,3首次绑卡,4首次充值,5首次投资,6邀请好友首次投资,7复投,8邀请好友注册,9分享，10签到，11邀请好友实名，12邀请好友首次投资
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/marketCampaignTrigger", method = RequestMethod.PUT)
    public ResponseResult marketCampaignTrigger(@RequestBody CouponSendConditionDto dto) throws BusinessException {
        logger.info("marketCampaignTrigger start: " + DataUtils.toString(dto));
        Boolean couponAvailable = marketCampaignService.checkCouponSend(dto);
        if (couponAvailable) {
            marketCampaignService.marketCampaignTrigger(dto);
        }
        logger.info("marketCampaignTrigger end: " + DataUtils.toString(dto.getTraceID()));
        return creatOKRespResult(dto.getTraceID());
    }

    /**
     * 活动触发(答题活动专用)，当发送失败时候，返回code：-1
     * @param dto
     * mcCode: 1注册,2实名,3首次绑卡,4首次充值,5首次投资,6邀请好友首次投资,7复投,8邀请好友注册,9分享，10签到，11邀请好友实名，12邀请好友首次投资
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/marketCampaignForAnwser", method = RequestMethod.PUT)
    public ResponseResult marketCampaignForAnwser(@RequestBody CouponSendConditionDto dto) throws BusinessException {
        logger.info("marketCampaignTrigger start: " + DataUtils.toString(dto));
        Boolean couponAvailable = marketCampaignService.checkCouponSend(dto);
        if (couponAvailable) {

            TwoTuple<Integer, String> result =  marketCampaignService.marketCampaignTrigger(dto);
            if(result.first == 1) { //发送礼券成功
                return creatOKRespResult(dto.getTraceID());
            }
        }
        //发送礼券失败
        logger.info("marketCampaignTrigger end: " + DataUtils.toString(dto.getTraceID()));
        ResponseResult respResult = new ResponseResult(dto.getTraceID(), ResponseCode.PARAM_ERROR,"给："+dto.getUserUuid()+"发送礼券失败!");
        return respResult;


    }


    /**
     * 活动触发(春节抽奖专用)，当发送失败时候，返回code：-1
     * @param dto
     * mcCode:  16：春节抽奖_1%加息券 ， 17：春节抽奖_108元理财红包 ， 18：春节抽奖_88元理财红包， 19： 春节抽奖_66元理财红包
     *
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/marketCampaignForRaffle", method = RequestMethod.PUT)
    public ResponseResult marketCampaignForRaffle(@RequestBody CouponSendConditionDto dto) throws BusinessException {
        logger.info("marketCampaignTrigger start: " + DataUtils.toString(dto));
        Boolean couponAvailable = marketCampaignService.checkCouponSend(dto);
        if (couponAvailable) {
            TwoTuple<Integer, String> result =  marketCampaignService.marketCampaignTrigger(dto);
            if(result.first == 1) { //发送礼券成功
                return creatOKRespResult(dto.getTraceID());
            }
        }
        //发送礼券失败
        logger.info("marketCampaignTrigger end: " + DataUtils.toString(dto.getTraceID()));
        ResponseResult respResult = new ResponseResult(dto.getTraceID(), ResponseCode.PARAM_ERROR,"给："+dto.getUserUuid()+"发送礼券失败!");
        return respResult;


    }



    /**
     * Step21 运营后台，礼券领取记录
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/lstCouponExtendRecordItems", method = RequestMethod.GET)
    public ResponseResult lstCouponExtendRecordItems(@RequestParam Map<String, Object> param) throws BusinessException {
        String jsonString = JSON.toJSONString(param);
        LstCouponExtendRecordConditionVO lstConditionVO = JSON.parseObject(jsonString, LstCouponExtendRecordConditionVO.class);
        logger.info("lstCouponExtendRecordItems start: " + DataUtils.toString(lstConditionVO));

        CouponExtendRecordItemListVO itemList = couponExtendRecordService.lstCouponExtendRecord(lstConditionVO);

        logger.info("lstCouponExtendRecordItems end: " + DataUtils.toString(lstConditionVO.getTraceID(), itemList));
        return creatOKRespResult(lstConditionVO.getTraceID(), itemList);
    }

    /**
     * Step22 投资者_查询现金券列表
     * @param params
     * userPhoneNumber
     * couponType: 1现金券，2加息券
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/investorlstCouponExtendRecordItems", method = RequestMethod.GET)
    public ResponseResult investorlstCouponExtendRecordItems(@RequestParam Map params) throws BusinessException {
        logger.info("investorlstCouponExtendRecordItems start: " + DataUtils.toString(params));
        BizParam bizParam = new BizParam(params);
        String userPhoneNumber = bizParam.getString("userPhoneNumber");
        int couponType = bizParam.getInt("couponType");
        DataUtils.checkParam(userPhoneNumber);

        List<CouponExtendRecordVO> itemList = couponExtendRecordService.lstCouponExtendRecord(userPhoneNumber, couponType);

        logger.info("investorlstCouponExtendRecordItems end: " + DataUtils.toString((String)params.get("traceID"), itemList));
        return creatOKRespResult((String)params.get("traceID"), itemList);
    }

    /**
     * 根据现金券的批次号反查可用的产品列表
     * @param params
     * ccCode：现金券的批次号
     * @return
     * productUuid
     * productAbbrName：产品名称/简称
     * annualInterestRate：预期年化收益率，注意展示时需要*100
     * productPeriod：期限
     * @throws BusinessException
     */
    @RequestMapping(value = "/lstAdaptProduct", method = RequestMethod.GET)
    public ResponseResult lstAdaptProduct(@RequestParam Map params) throws BusinessException {
        logger.info("lstAdaptProduct start: " + DataUtils.toString(params));
        BizParam bizParam = new BizParam(params);
        String ccCode = bizParam.getString("ccCode");
        String merchantNum = bizParam.getString("merchantNum");
        Integer startRow = bizParam.getInt("startRow");
        Integer pageSize = bizParam.getInt("pageSize");
        DataUtils.checkParam(ccCode);

        Map productInfos = cashCouponService.lstAdaptProduct(ccCode, startRow, pageSize, merchantNum);

        logger.info("lstAdaptProduct end: " + DataUtils.toString((String)params.get("traceID"), productInfos));
        return creatOKRespResult((String)params.get("traceID"), productInfos);
    }


    /**
     * Step23 查询单条礼券记录
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/lstCouponExtendRecord", method = RequestMethod.GET)
    public ResponseResult lstCouponExtendRecord(@RequestParam Map<String, Object> param) throws BusinessException {
        String jsonString = JSON.toJSONString(param);
        LstCouponExtendRecordConditionVO lstConditionVO = JSON.parseObject(jsonString, LstCouponExtendRecordConditionVO.class);
        logger.info("lstCouponExtendRecord start: " + DataUtils.toString(lstConditionVO));

        DataUtils.checkParam(lstConditionVO.getCouponExtendCode());

        CouponExtendRecordVO couponExtendRecordVO = couponExtendRecordService.lstCouponExtendRecord(lstConditionVO.getCouponExtendCode());

        logger.info("lstCouponExtendRecord end: " + DataUtils.toString(lstConditionVO.getTraceID(), couponExtendRecordVO));
        return creatOKRespResult(lstConditionVO.getTraceID(), couponExtendRecordVO);
    }


    /**
     * Step25 投资者_查询当前交易可用现金券
     * @param params
     * userPhoneNumber
     * productUuid
     * orderAmount
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/lstAvailableCoupon", method = RequestMethod.GET)
    public ResponseResult lstAvailableCoupon(@RequestParam Map params) throws BusinessException {
        logger.info("lstAvailableCoupon start: " + DataUtils.toString(params));

        BizParam bizParam = new BizParam(params);
        String userPhoneNumber = bizParam.getString("userPhoneNumber");
        String productUuid = bizParam.getString("productUuid");
        double orderAmount = bizParam.getDouble("orderAmount");
        DataUtils.checkParam(userPhoneNumber, productUuid);

        List<CouponExtendRecordVO> couponExtendRecordVOs = couponExtendRecordService.lstCouponExtendRecord(userPhoneNumber, productUuid, orderAmount);

        logger.info("lstAvailableCoupon end: " + DataUtils.toString(bizParam.getString("traceID"), couponExtendRecordVOs));
        return creatOKRespResult(bizParam.getString("traceID"), couponExtendRecordVOs);
    }

    /**
     * Step23 作废已经发放给投资者的礼券
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/abolishCouponExtendRecord", method = RequestMethod.PUT)
    public ResponseResult abolishCouponExtendRecord(@RequestBody CommCouponUpdateVO abolishCouponExtendRecordVO) throws BusinessException {
        logger.info("abolishCouponExtendRecord start: " + DataUtils.toString(abolishCouponExtendRecordVO));

        DataUtils.checkParam(abolishCouponExtendRecordVO.getCommCode(), abolishCouponExtendRecordVO.getUpdateUserId(), abolishCouponExtendRecordVO.getUpdateRemark());
        couponExtendRecordService.abolishCouponExtendRecord(abolishCouponExtendRecordVO);

        logger.info("abolishCouponExtendRecord end: " + DataUtils.toString(abolishCouponExtendRecordVO.getTraceID()));
        return creatOKRespResult(abolishCouponExtendRecordVO.getTraceID());
    }

    /**
     * 自动更新活动和已分配代金券的状态
     * @param params
     * @return
     */
    @RequestMapping(value = "/autoRefreshStatus", method = RequestMethod.GET)
    public ResponseResult autoRefreshStatus(@RequestParam Map params) {
        logger.info("autoRefreshStatus start: " + DataUtils.toString(params));
        String traceID = new BizParam(params).getString("traceID");

        marketCampaignService.autoRefreshStatus();
//        cashCouponService.autoRefreshStatus();
        couponExtendRecordService.autoRefreshStatus();

        logger.info("autoRefreshStatus end: " + traceID);
        return creatOKRespResult(traceID);
    }

    /**
     * 根据查询条件查询现金券发放记录列表(关联cash_coupon和coupon_extend_record两张表查询)
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/extendRecord/list", method = RequestMethod.GET)
    public ResponseResult getExtendRecordList(@RequestParam Map params) throws BusinessException {
        logger.info("getExtendRecordList start: " + DataUtils.toString(params));
        MapRemoveNullUtil.removeNullEntry(params);
        RequestMapperConvert.initCouponParam(params);
        List<Map> couponList = couponExtendRecordService.getExtendRecordList(params);
        logger.info("getExtendRecordList end: " + DataUtils.toString(params.get("traceID"), couponList));
        return creatOKRespResult((String) params.get("traceID"), couponList);
    }

    /**
     * 根据查询条件查询现金券发放记录数量(关联cash_coupon和coupon_extend_record两张表查询)
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/extendRecord/count", method = RequestMethod.GET)
    public ResponseResult getExtendRecordCount(@RequestParam Map params) throws BusinessException {
        logger.info("getExtendRecordCount start: " + DataUtils.toString(params));
        MapRemoveNullUtil.removeNullEntry(params);
        RequestMapperConvert.initCouponParam(params);
        Integer count = couponExtendRecordService.getExtendRecordCount(params);
        logger.info("getExtendRecordCount end: " + DataUtils.toString(params.get("traceID"), count));
        return creatOKRespResult((String) params.get("traceID"), count);
    }

    /**
     * 查询当前交易产品的可用现金券列表
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/availableCoupon/list", method = RequestMethod.GET)
    public ResponseResult getAvailableCouponList(@RequestParam Map params) throws BusinessException {
        logger.info("getAvailableCouponList start: " + DataUtils.toString(params));
        String userUuid = MapParamUtils.getStringInMap(params, "userUuid");
        String productUuid = MapParamUtils.getStringInMap(params, "productUuid");
        Double amount = MapParamUtils.getDoubleInMap(params, "orderAmount");
        Integer couponType = MapParamUtils.getIntInMap(params, "couponType") == 0 ? null : MapParamUtils.getIntInMap(params, "couponType");
        if (StringUtils.isBlank(userUuid) || StringUtils.isBlank(productUuid) || amount == 0) {
            throw new BusinessException(ResponseCode.PARAM_ERROR, ResponseCode.PARAM_ERROR_TEXT, true);
        }
        List<Map> list = couponExtendRecordService.getAvailableCouponList(userUuid,productUuid,amount,couponType);
        logger.info("getAvailableCouponList end: " + DataUtils.toString(params.get("traceID"), list));
        return creatOKRespResult((String) params.get("traceID"), list);
    }

    /**
     * 添加指定发放礼券的记录(excel导入批量发放)
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/insertSpecifiedDistributionByExcelList", method = RequestMethod.POST)
    public ResponseResult insertSpecifiedDistributionByExcelList(InsertCouponSpecifiedDistributionAuditVO record,@RequestParam(value = "file", required = false)MultipartFile file) throws BusinessException {
        logger.info("insertSpecifiedDistributionByExcelList start: " + DataUtils.toString(record));
        boolean result = false;
        if(record != null) {
            if(file!=null) {
                List<String> userPhones = XLSUtils.readUserPhone(file, true);
                logger.info(DataUtils.toString(userPhones));
                record.setUserPhoneList(userPhones);
            }
            if((record.getCcCodeList() != null) && (record.getCcCodeList().size() > 0)
                    && (record.getUserPhoneList() != null) && (record.getUserPhoneList().size() > 0)) {
                if(record.getUserPhoneList().size() > (10*1000)){
                    throw new BusinessException(TradeStatusMsg.CASHCOUPON_SPECDIST_MAX_ERR, TradeStatusMsg.CASHCOUPON_SPECDIST_MAX_ERR_MSG);
                }
                result = couponExtendRecordService.insertSpecifiedDistribution(record.getCcCodeList(), record.getUserPhoneList(), record.getOperator());
            } else {
                throw new BusinessException(TradeStatusMsg.CASHCOUPON_SPECDIST_INVALID_ERR, TradeStatusMsg.CASHCOUPON_SPECDIST_INVALID_ERR_MSG);
            }
        }
        logger.info("insertSpecifiedDistributionByExcelList end: " + DataUtils.toString(record.getTraceID(), result));
        return creatOKRespResult(record.getTraceID(), result);
    }

    /**
     * 添加指定发放礼券的记录
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/insertSpecifiedDistributionByList", method = RequestMethod.POST)
    public ResponseResult insertSpecifiedDistributionByList(@RequestBody  InsertCouponSpecifiedDistributionAuditVO record) throws BusinessException {
        logger.info("insertSpecifiedDistributionByList start: " + DataUtils.toString(record));
        boolean result = false;
        if(record != null) {
            if((record.getCcCodeList() != null) && (record.getCcCodeList().size() > 0)
                    && (record.getUserPhoneList() != null) && (record.getUserPhoneList().size() > 0)) {
                if(record.getUserPhoneList().size() > (10*1000)){
                    throw new BusinessException(TradeStatusMsg.CASHCOUPON_SPECDIST_MAX_ERR, TradeStatusMsg.CASHCOUPON_SPECDIST_MAX_ERR_MSG);
                }
                result = couponExtendRecordService.insertSpecifiedDistribution(record.getCcCodeList(), record.getUserPhoneList(), record.getOperator());
            } else {
                throw new BusinessException(TradeStatusMsg.CASHCOUPON_SPECDIST_INVALID_ERR, TradeStatusMsg.CASHCOUPON_SPECDIST_INVALID_ERR_MSG);
            }
        }
        logger.info("insertSpecifiedDistributionByList end: " + DataUtils.toString(record.getTraceID(), result));
        return creatOKRespResult(record.getTraceID(), result);
    }

    /**
     * 查询现金券指定发放记录
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/lstCouponSpecifiedDistributionRecord", method = RequestMethod.GET)
    public ResponseResult lstCouponSpecifiedDistributionRecord(@RequestParam Map<String, Object> param) throws BusinessException {
        logger.info("lstCouponSpecifiedDistributionRecord start: " + DataUtils.toString(param));
        String jsonString = JSON.toJSONString(param);
        LstCouponSpecifiedDistributionConditionVO lstCondition = JSON.parseObject(jsonString, LstCouponSpecifiedDistributionConditionVO.class);

        CouponSpecifiedDistributionRecordItemListVO result = couponExtendRecordService.lstCouponSpecifiedDistributionRecord(lstCondition);

        logger.info("lstCouponSpecifiedDistributionRecord end: " + DataUtils.toString(lstCondition.getTraceID(), result));
        return creatOKRespResult(lstCondition.getTraceID(), result);
    }

    /**
     * 查询现金券指定发放记录明细
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/lstCouponSpecifiedDistributionDetail", method = RequestMethod.GET)
    public ResponseResult lstCouponSpecifiedDistributionDetail(LstCouponSpecifiedDistributionDetailConditionVO lstCondition) throws BusinessException {
        logger.info("lstCouponSpecifiedDistributionDetail start: " + DataUtils.toString(lstCondition));

        CouponSpecifiedDistributionRecordItemDetailVO result = couponExtendRecordService.lstCouponSpecifiedDistributionDetail(lstCondition);

        logger.info("lstCouponSpecifiedDistributionDetail end: " + DataUtils.toString(lstCondition.getTraceID(), result));
        return creatOKRespResult(lstCondition.getTraceID(), result);
    }

    /**
     * 现金券指定发放记录审核
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/couponSpecifiedDistributionAudit", method = RequestMethod.POST)
    public ResponseResult couponSpecifiedDistributionAudit(@RequestBody CouponSpecifiedDistributionAuditVO auditInfo) throws BusinessException {
        logger.info("couponSpecifiedDistributionAudit start: " + DataUtils.toString(auditInfo));

        boolean result = couponExtendRecordService.couponSpecifiedDistributionAudit(auditInfo);

        logger.info("couponSpecifiedDistributionAudit end: " + DataUtils.toString(auditInfo.getTraceID(), result));
        return creatOKRespResult(auditInfo.getTraceID(), result);
    }

    /**
     * 获取全部礼券
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/getAllCoupon", method = RequestMethod.GET)
    public ResponseResult getAllCoupon(@RequestParam Map<String, Object> param) throws BusinessException {
        logger.info("getAllCoupon start: " + DataUtils.toString((String) param.get("traceID")));
        List<CashCouponVO>  couponList = cashCouponService.getAllCoupon();
        logger.info("getAllCoupon end: " + DataUtils.toString((String) param.get("traceID"), couponList));
        return creatOKRespResult((String) param.get("traceID"), couponList);
    }

    /**
     * 计算产品现金券最大收益
     *
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/calculate/product", method = RequestMethod.GET)
    public ResponseResult calculateProfitByProductList(@RequestParam(value = "traceID") String traceID,
                                                       @RequestParam(value = "productList") String productList) throws BusinessException {
        List<ProductVO> productVos = JSONObject.parseArray(productList, ProductVO.class);
        List<ProductCouponItemVO> productCouponItemVOS = cashCouponService.cashCouponByProductList(productVos);
        logger.info("getAvailableCouponList end: " + DataUtils.toString(traceID, productCouponItemVOS));
        return creatOKRespResult(DataUtils.toString(traceID), productCouponItemVOS);
    }

    /**
     * 分享礼券发送
     *
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/shareSendCoupon", method = RequestMethod.GET)
    public ResponseResult shareSendCoupon(@RequestParam(value = "traceID") String traceID,
                                                       @RequestParam(value = "userUuid") String userUuid) throws BusinessException {
        Boolean couponAvailable = marketCampaignService.checkCouponSend(new CouponSendConditionDto(userUuid,MarketCampaignCodeEnum.SHARE.getCode(),null,null));
        if (couponAvailable) {
            marketCampaignService.marketCampaignTrigger(new CouponSendConditionDto(userUuid,MarketCampaignCodeEnum.SHARE.getCode(),null,null));
        }
        Map<String, Object> data = new HashMap<>();
        data.put("couponAvailable", couponAvailable ? 1 : 0);
        return creatOKRespResult(DataUtils.toString(traceID), data);

    }

    /**
     * 活动领券
     */
    @RequestMapping(value = "/campaign/exchange", method = RequestMethod.GET)
    public ResponseResult campaignExchangeCoupon(@RequestParam Map param) throws BusinessException{
        MarketCampaignTriggerVO vo = JsonUtil.toObject(param, MarketCampaignTriggerVO.class);
        if (StringUtils.isBlank(vo.getUserUuid()) || null == vo.getMcCode()){
            throw new BusinessException(ResponseCode.PARAM_ERROR, ResponseCode.PARAM_ERROR_TEXT);
        }
        marketCampaignService.campaignExchangeCoupon(vo);
        return creatOKRespResult(param.get("traceID").toString());
    }

    /**
     * 根据查询条件获取礼券批次
     * @param param
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/getCouponList", method = RequestMethod.GET)
    public ResponseResult getCouponList(@RequestParam Map<String, Object> param) throws BusinessException {
        logger.info("getCouponList start: " + DataUtils.toString(param));

        List<CashCouponVO> list= cashCouponService.getCouponList(param);

        logger.info("getCouponList end: " + DataUtils.toString(param.get("traceID"), list));
        return creatOKRespResult(param.get("traceID").toString(), list);
    }

    /**
     * 获取一个礼券编码，金币兑换使用
     */
    @RequestMapping(value = "/getCouponExtendCode", method = RequestMethod.GET)
    public ResponseResult getCouponExtendCode(@RequestParam Map param) throws BusinessException{
        String couponExtendCode = couponExtendRecordService.getCouponExtendCode();
        return creatOKRespResult(param.get("traceID").toString(), couponExtendCode);
    }
}
