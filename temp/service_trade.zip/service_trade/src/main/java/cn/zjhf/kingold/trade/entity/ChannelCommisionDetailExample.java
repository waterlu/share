package cn.zjhf.kingold.trade.entity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ChannelCommisionDetailExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private Integer limit;

    private Integer offset;

    public ChannelCommisionDetailExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andChannelCommisionDetailIdIsNull() {
            addCriterion("channel_commision_detail_id is null");
            return (Criteria) this;
        }

        public Criteria andChannelCommisionDetailIdIsNotNull() {
            addCriterion("channel_commision_detail_id is not null");
            return (Criteria) this;
        }

        public Criteria andChannelCommisionDetailIdEqualTo(Long value) {
            addCriterion("channel_commision_detail_id =", value, "channelCommisionDetailId");
            return (Criteria) this;
        }

        public Criteria andChannelCommisionDetailIdNotEqualTo(Long value) {
            addCriterion("channel_commision_detail_id <>", value, "channelCommisionDetailId");
            return (Criteria) this;
        }

        public Criteria andChannelCommisionDetailIdGreaterThan(Long value) {
            addCriterion("channel_commision_detail_id >", value, "channelCommisionDetailId");
            return (Criteria) this;
        }

        public Criteria andChannelCommisionDetailIdGreaterThanOrEqualTo(Long value) {
            addCriterion("channel_commision_detail_id >=", value, "channelCommisionDetailId");
            return (Criteria) this;
        }

        public Criteria andChannelCommisionDetailIdLessThan(Long value) {
            addCriterion("channel_commision_detail_id <", value, "channelCommisionDetailId");
            return (Criteria) this;
        }

        public Criteria andChannelCommisionDetailIdLessThanOrEqualTo(Long value) {
            addCriterion("channel_commision_detail_id <=", value, "channelCommisionDetailId");
            return (Criteria) this;
        }

        public Criteria andChannelCommisionDetailIdIn(List<Long> values) {
            addCriterion("channel_commision_detail_id in", values, "channelCommisionDetailId");
            return (Criteria) this;
        }

        public Criteria andChannelCommisionDetailIdNotIn(List<Long> values) {
            addCriterion("channel_commision_detail_id not in", values, "channelCommisionDetailId");
            return (Criteria) this;
        }

        public Criteria andChannelCommisionDetailIdBetween(Long value1, Long value2) {
            addCriterion("channel_commision_detail_id between", value1, value2, "channelCommisionDetailId");
            return (Criteria) this;
        }

        public Criteria andChannelCommisionDetailIdNotBetween(Long value1, Long value2) {
            addCriterion("channel_commision_detail_id not between", value1, value2, "channelCommisionDetailId");
            return (Criteria) this;
        }

        public Criteria andProductUuidIsNull() {
            addCriterion("product_uuid is null");
            return (Criteria) this;
        }

        public Criteria andProductUuidIsNotNull() {
            addCriterion("product_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andProductUuidEqualTo(String value) {
            addCriterion("product_uuid =", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotEqualTo(String value) {
            addCriterion("product_uuid <>", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidGreaterThan(String value) {
            addCriterion("product_uuid >", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidGreaterThanOrEqualTo(String value) {
            addCriterion("product_uuid >=", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidLessThan(String value) {
            addCriterion("product_uuid <", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidLessThanOrEqualTo(String value) {
            addCriterion("product_uuid <=", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidLike(String value) {
            addCriterion("product_uuid like", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotLike(String value) {
            addCriterion("product_uuid not like", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidIn(List<String> values) {
            addCriterion("product_uuid in", values, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotIn(List<String> values) {
            addCriterion("product_uuid not in", values, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidBetween(String value1, String value2) {
            addCriterion("product_uuid between", value1, value2, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotBetween(String value1, String value2) {
            addCriterion("product_uuid not between", value1, value2, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameIsNull() {
            addCriterion("product_abbr_name is null");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameIsNotNull() {
            addCriterion("product_abbr_name is not null");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameEqualTo(String value) {
            addCriterion("product_abbr_name =", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameNotEqualTo(String value) {
            addCriterion("product_abbr_name <>", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameGreaterThan(String value) {
            addCriterion("product_abbr_name >", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameGreaterThanOrEqualTo(String value) {
            addCriterion("product_abbr_name >=", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameLessThan(String value) {
            addCriterion("product_abbr_name <", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameLessThanOrEqualTo(String value) {
            addCriterion("product_abbr_name <=", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameLike(String value) {
            addCriterion("product_abbr_name like", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameNotLike(String value) {
            addCriterion("product_abbr_name not like", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameIn(List<String> values) {
            addCriterion("product_abbr_name in", values, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameNotIn(List<String> values) {
            addCriterion("product_abbr_name not in", values, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameBetween(String value1, String value2) {
            addCriterion("product_abbr_name between", value1, value2, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameNotBetween(String value1, String value2) {
            addCriterion("product_abbr_name not between", value1, value2, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andMerchantNumIsNull() {
            addCriterion("merchant_num is null");
            return (Criteria) this;
        }

        public Criteria andMerchantNumIsNotNull() {
            addCriterion("merchant_num is not null");
            return (Criteria) this;
        }

        public Criteria andMerchantNumEqualTo(String value) {
            addCriterion("merchant_num =", value, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumNotEqualTo(String value) {
            addCriterion("merchant_num <>", value, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumGreaterThan(String value) {
            addCriterion("merchant_num >", value, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumGreaterThanOrEqualTo(String value) {
            addCriterion("merchant_num >=", value, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumLessThan(String value) {
            addCriterion("merchant_num <", value, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumLessThanOrEqualTo(String value) {
            addCriterion("merchant_num <=", value, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumLike(String value) {
            addCriterion("merchant_num like", value, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumNotLike(String value) {
            addCriterion("merchant_num not like", value, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumIn(List<String> values) {
            addCriterion("merchant_num in", values, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumNotIn(List<String> values) {
            addCriterion("merchant_num not in", values, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumBetween(String value1, String value2) {
            addCriterion("merchant_num between", value1, value2, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumNotBetween(String value1, String value2) {
            addCriterion("merchant_num not between", value1, value2, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameIsNull() {
            addCriterion("channel_app_name is null");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameIsNotNull() {
            addCriterion("channel_app_name is not null");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameEqualTo(String value) {
            addCriterion("channel_app_name =", value, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameNotEqualTo(String value) {
            addCriterion("channel_app_name <>", value, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameGreaterThan(String value) {
            addCriterion("channel_app_name >", value, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameGreaterThanOrEqualTo(String value) {
            addCriterion("channel_app_name >=", value, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameLessThan(String value) {
            addCriterion("channel_app_name <", value, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameLessThanOrEqualTo(String value) {
            addCriterion("channel_app_name <=", value, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameLike(String value) {
            addCriterion("channel_app_name like", value, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameNotLike(String value) {
            addCriterion("channel_app_name not like", value, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameIn(List<String> values) {
            addCriterion("channel_app_name in", values, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameNotIn(List<String> values) {
            addCriterion("channel_app_name not in", values, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameBetween(String value1, String value2) {
            addCriterion("channel_app_name between", value1, value2, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameNotBetween(String value1, String value2) {
            addCriterion("channel_app_name not between", value1, value2, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andOrderCountIsNull() {
            addCriterion("order_count is null");
            return (Criteria) this;
        }

        public Criteria andOrderCountIsNotNull() {
            addCriterion("order_count is not null");
            return (Criteria) this;
        }

        public Criteria andOrderCountEqualTo(Integer value) {
            addCriterion("order_count =", value, "orderCount");
            return (Criteria) this;
        }

        public Criteria andOrderCountNotEqualTo(Integer value) {
            addCriterion("order_count <>", value, "orderCount");
            return (Criteria) this;
        }

        public Criteria andOrderCountGreaterThan(Integer value) {
            addCriterion("order_count >", value, "orderCount");
            return (Criteria) this;
        }

        public Criteria andOrderCountGreaterThanOrEqualTo(Integer value) {
            addCriterion("order_count >=", value, "orderCount");
            return (Criteria) this;
        }

        public Criteria andOrderCountLessThan(Integer value) {
            addCriterion("order_count <", value, "orderCount");
            return (Criteria) this;
        }

        public Criteria andOrderCountLessThanOrEqualTo(Integer value) {
            addCriterion("order_count <=", value, "orderCount");
            return (Criteria) this;
        }

        public Criteria andOrderCountIn(List<Integer> values) {
            addCriterion("order_count in", values, "orderCount");
            return (Criteria) this;
        }

        public Criteria andOrderCountNotIn(List<Integer> values) {
            addCriterion("order_count not in", values, "orderCount");
            return (Criteria) this;
        }

        public Criteria andOrderCountBetween(Integer value1, Integer value2) {
            addCriterion("order_count between", value1, value2, "orderCount");
            return (Criteria) this;
        }

        public Criteria andOrderCountNotBetween(Integer value1, Integer value2) {
            addCriterion("order_count not between", value1, value2, "orderCount");
            return (Criteria) this;
        }

        public Criteria andValidOrderCountIsNull() {
            addCriterion("valid_order_count is null");
            return (Criteria) this;
        }

        public Criteria andValidOrderCountIsNotNull() {
            addCriterion("valid_order_count is not null");
            return (Criteria) this;
        }

        public Criteria andValidOrderCountEqualTo(Integer value) {
            addCriterion("valid_order_count =", value, "validOrderCount");
            return (Criteria) this;
        }

        public Criteria andValidOrderCountNotEqualTo(Integer value) {
            addCriterion("valid_order_count <>", value, "validOrderCount");
            return (Criteria) this;
        }

        public Criteria andValidOrderCountGreaterThan(Integer value) {
            addCriterion("valid_order_count >", value, "validOrderCount");
            return (Criteria) this;
        }

        public Criteria andValidOrderCountGreaterThanOrEqualTo(Integer value) {
            addCriterion("valid_order_count >=", value, "validOrderCount");
            return (Criteria) this;
        }

        public Criteria andValidOrderCountLessThan(Integer value) {
            addCriterion("valid_order_count <", value, "validOrderCount");
            return (Criteria) this;
        }

        public Criteria andValidOrderCountLessThanOrEqualTo(Integer value) {
            addCriterion("valid_order_count <=", value, "validOrderCount");
            return (Criteria) this;
        }

        public Criteria andValidOrderCountIn(List<Integer> values) {
            addCriterion("valid_order_count in", values, "validOrderCount");
            return (Criteria) this;
        }

        public Criteria andValidOrderCountNotIn(List<Integer> values) {
            addCriterion("valid_order_count not in", values, "validOrderCount");
            return (Criteria) this;
        }

        public Criteria andValidOrderCountBetween(Integer value1, Integer value2) {
            addCriterion("valid_order_count between", value1, value2, "validOrderCount");
            return (Criteria) this;
        }

        public Criteria andValidOrderCountNotBetween(Integer value1, Integer value2) {
            addCriterion("valid_order_count not between", value1, value2, "validOrderCount");
            return (Criteria) this;
        }

        public Criteria andValidOrderUnsettleCountIsNull() {
            addCriterion("valid_order_unsettle_count is null");
            return (Criteria) this;
        }

        public Criteria andValidOrderUnsettleCountIsNotNull() {
            addCriterion("valid_order_unsettle_count is not null");
            return (Criteria) this;
        }

        public Criteria andValidOrderUnsettleCountEqualTo(Integer value) {
            addCriterion("valid_order_unsettle_count =", value, "validOrderUnsettleCount");
            return (Criteria) this;
        }

        public Criteria andValidOrderUnsettleCountNotEqualTo(Integer value) {
            addCriterion("valid_order_unsettle_count <>", value, "validOrderUnsettleCount");
            return (Criteria) this;
        }

        public Criteria andValidOrderUnsettleCountGreaterThan(Integer value) {
            addCriterion("valid_order_unsettle_count >", value, "validOrderUnsettleCount");
            return (Criteria) this;
        }

        public Criteria andValidOrderUnsettleCountGreaterThanOrEqualTo(Integer value) {
            addCriterion("valid_order_unsettle_count >=", value, "validOrderUnsettleCount");
            return (Criteria) this;
        }

        public Criteria andValidOrderUnsettleCountLessThan(Integer value) {
            addCriterion("valid_order_unsettle_count <", value, "validOrderUnsettleCount");
            return (Criteria) this;
        }

        public Criteria andValidOrderUnsettleCountLessThanOrEqualTo(Integer value) {
            addCriterion("valid_order_unsettle_count <=", value, "validOrderUnsettleCount");
            return (Criteria) this;
        }

        public Criteria andValidOrderUnsettleCountIn(List<Integer> values) {
            addCriterion("valid_order_unsettle_count in", values, "validOrderUnsettleCount");
            return (Criteria) this;
        }

        public Criteria andValidOrderUnsettleCountNotIn(List<Integer> values) {
            addCriterion("valid_order_unsettle_count not in", values, "validOrderUnsettleCount");
            return (Criteria) this;
        }

        public Criteria andValidOrderUnsettleCountBetween(Integer value1, Integer value2) {
            addCriterion("valid_order_unsettle_count between", value1, value2, "validOrderUnsettleCount");
            return (Criteria) this;
        }

        public Criteria andValidOrderUnsettleCountNotBetween(Integer value1, Integer value2) {
            addCriterion("valid_order_unsettle_count not between", value1, value2, "validOrderUnsettleCount");
            return (Criteria) this;
        }

        public Criteria andRaiseAmountIsNull() {
            addCriterion("raise_amount is null");
            return (Criteria) this;
        }

        public Criteria andRaiseAmountIsNotNull() {
            addCriterion("raise_amount is not null");
            return (Criteria) this;
        }

        public Criteria andRaiseAmountEqualTo(BigDecimal value) {
            addCriterion("raise_amount =", value, "raiseAmount");
            return (Criteria) this;
        }

        public Criteria andRaiseAmountNotEqualTo(BigDecimal value) {
            addCriterion("raise_amount <>", value, "raiseAmount");
            return (Criteria) this;
        }

        public Criteria andRaiseAmountGreaterThan(BigDecimal value) {
            addCriterion("raise_amount >", value, "raiseAmount");
            return (Criteria) this;
        }

        public Criteria andRaiseAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("raise_amount >=", value, "raiseAmount");
            return (Criteria) this;
        }

        public Criteria andRaiseAmountLessThan(BigDecimal value) {
            addCriterion("raise_amount <", value, "raiseAmount");
            return (Criteria) this;
        }

        public Criteria andRaiseAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("raise_amount <=", value, "raiseAmount");
            return (Criteria) this;
        }

        public Criteria andRaiseAmountIn(List<BigDecimal> values) {
            addCriterion("raise_amount in", values, "raiseAmount");
            return (Criteria) this;
        }

        public Criteria andRaiseAmountNotIn(List<BigDecimal> values) {
            addCriterion("raise_amount not in", values, "raiseAmount");
            return (Criteria) this;
        }

        public Criteria andRaiseAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("raise_amount between", value1, value2, "raiseAmount");
            return (Criteria) this;
        }

        public Criteria andRaiseAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("raise_amount not between", value1, value2, "raiseAmount");
            return (Criteria) this;
        }

        public Criteria andValidRaiseAmountIsNull() {
            addCriterion("valid_raise_amount is null");
            return (Criteria) this;
        }

        public Criteria andValidRaiseAmountIsNotNull() {
            addCriterion("valid_raise_amount is not null");
            return (Criteria) this;
        }

        public Criteria andValidRaiseAmountEqualTo(BigDecimal value) {
            addCriterion("valid_raise_amount =", value, "validRaiseAmount");
            return (Criteria) this;
        }

        public Criteria andValidRaiseAmountNotEqualTo(BigDecimal value) {
            addCriterion("valid_raise_amount <>", value, "validRaiseAmount");
            return (Criteria) this;
        }

        public Criteria andValidRaiseAmountGreaterThan(BigDecimal value) {
            addCriterion("valid_raise_amount >", value, "validRaiseAmount");
            return (Criteria) this;
        }

        public Criteria andValidRaiseAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("valid_raise_amount >=", value, "validRaiseAmount");
            return (Criteria) this;
        }

        public Criteria andValidRaiseAmountLessThan(BigDecimal value) {
            addCriterion("valid_raise_amount <", value, "validRaiseAmount");
            return (Criteria) this;
        }

        public Criteria andValidRaiseAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("valid_raise_amount <=", value, "validRaiseAmount");
            return (Criteria) this;
        }

        public Criteria andValidRaiseAmountIn(List<BigDecimal> values) {
            addCriterion("valid_raise_amount in", values, "validRaiseAmount");
            return (Criteria) this;
        }

        public Criteria andValidRaiseAmountNotIn(List<BigDecimal> values) {
            addCriterion("valid_raise_amount not in", values, "validRaiseAmount");
            return (Criteria) this;
        }

        public Criteria andValidRaiseAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("valid_raise_amount between", value1, value2, "validRaiseAmount");
            return (Criteria) this;
        }

        public Criteria andValidRaiseAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("valid_raise_amount not between", value1, value2, "validRaiseAmount");
            return (Criteria) this;
        }

        public Criteria andValidRaiseUnsettleAmountIsNull() {
            addCriterion("valid_raise_unsettle_amount is null");
            return (Criteria) this;
        }

        public Criteria andValidRaiseUnsettleAmountIsNotNull() {
            addCriterion("valid_raise_unsettle_amount is not null");
            return (Criteria) this;
        }

        public Criteria andValidRaiseUnsettleAmountEqualTo(BigDecimal value) {
            addCriterion("valid_raise_unsettle_amount =", value, "validRaiseUnsettleAmount");
            return (Criteria) this;
        }

        public Criteria andValidRaiseUnsettleAmountNotEqualTo(BigDecimal value) {
            addCriterion("valid_raise_unsettle_amount <>", value, "validRaiseUnsettleAmount");
            return (Criteria) this;
        }

        public Criteria andValidRaiseUnsettleAmountGreaterThan(BigDecimal value) {
            addCriterion("valid_raise_unsettle_amount >", value, "validRaiseUnsettleAmount");
            return (Criteria) this;
        }

        public Criteria andValidRaiseUnsettleAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("valid_raise_unsettle_amount >=", value, "validRaiseUnsettleAmount");
            return (Criteria) this;
        }

        public Criteria andValidRaiseUnsettleAmountLessThan(BigDecimal value) {
            addCriterion("valid_raise_unsettle_amount <", value, "validRaiseUnsettleAmount");
            return (Criteria) this;
        }

        public Criteria andValidRaiseUnsettleAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("valid_raise_unsettle_amount <=", value, "validRaiseUnsettleAmount");
            return (Criteria) this;
        }

        public Criteria andValidRaiseUnsettleAmountIn(List<BigDecimal> values) {
            addCriterion("valid_raise_unsettle_amount in", values, "validRaiseUnsettleAmount");
            return (Criteria) this;
        }

        public Criteria andValidRaiseUnsettleAmountNotIn(List<BigDecimal> values) {
            addCriterion("valid_raise_unsettle_amount not in", values, "validRaiseUnsettleAmount");
            return (Criteria) this;
        }

        public Criteria andValidRaiseUnsettleAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("valid_raise_unsettle_amount between", value1, value2, "validRaiseUnsettleAmount");
            return (Criteria) this;
        }

        public Criteria andValidRaiseUnsettleAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("valid_raise_unsettle_amount not between", value1, value2, "validRaiseUnsettleAmount");
            return (Criteria) this;
        }

        public Criteria andCommisionAmountIsNull() {
            addCriterion("commision_amount is null");
            return (Criteria) this;
        }

        public Criteria andCommisionAmountIsNotNull() {
            addCriterion("commision_amount is not null");
            return (Criteria) this;
        }

        public Criteria andCommisionAmountEqualTo(BigDecimal value) {
            addCriterion("commision_amount =", value, "commisionAmount");
            return (Criteria) this;
        }

        public Criteria andCommisionAmountNotEqualTo(BigDecimal value) {
            addCriterion("commision_amount <>", value, "commisionAmount");
            return (Criteria) this;
        }

        public Criteria andCommisionAmountGreaterThan(BigDecimal value) {
            addCriterion("commision_amount >", value, "commisionAmount");
            return (Criteria) this;
        }

        public Criteria andCommisionAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("commision_amount >=", value, "commisionAmount");
            return (Criteria) this;
        }

        public Criteria andCommisionAmountLessThan(BigDecimal value) {
            addCriterion("commision_amount <", value, "commisionAmount");
            return (Criteria) this;
        }

        public Criteria andCommisionAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("commision_amount <=", value, "commisionAmount");
            return (Criteria) this;
        }

        public Criteria andCommisionAmountIn(List<BigDecimal> values) {
            addCriterion("commision_amount in", values, "commisionAmount");
            return (Criteria) this;
        }

        public Criteria andCommisionAmountNotIn(List<BigDecimal> values) {
            addCriterion("commision_amount not in", values, "commisionAmount");
            return (Criteria) this;
        }

        public Criteria andCommisionAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("commision_amount between", value1, value2, "commisionAmount");
            return (Criteria) this;
        }

        public Criteria andCommisionAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("commision_amount not between", value1, value2, "commisionAmount");
            return (Criteria) this;
        }

        public Criteria andLoanTimeIsNull() {
            addCriterion("loan_time is null");
            return (Criteria) this;
        }

        public Criteria andLoanTimeIsNotNull() {
            addCriterion("loan_time is not null");
            return (Criteria) this;
        }

        public Criteria andLoanTimeEqualTo(Date value) {
            addCriterion("loan_time =", value, "loanTime");
            return (Criteria) this;
        }

        public Criteria andLoanTimeNotEqualTo(Date value) {
            addCriterion("loan_time <>", value, "loanTime");
            return (Criteria) this;
        }

        public Criteria andLoanTimeGreaterThan(Date value) {
            addCriterion("loan_time >", value, "loanTime");
            return (Criteria) this;
        }

        public Criteria andLoanTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("loan_time >=", value, "loanTime");
            return (Criteria) this;
        }

        public Criteria andLoanTimeLessThan(Date value) {
            addCriterion("loan_time <", value, "loanTime");
            return (Criteria) this;
        }

        public Criteria andLoanTimeLessThanOrEqualTo(Date value) {
            addCriterion("loan_time <=", value, "loanTime");
            return (Criteria) this;
        }

        public Criteria andLoanTimeIn(List<Date> values) {
            addCriterion("loan_time in", values, "loanTime");
            return (Criteria) this;
        }

        public Criteria andLoanTimeNotIn(List<Date> values) {
            addCriterion("loan_time not in", values, "loanTime");
            return (Criteria) this;
        }

        public Criteria andLoanTimeBetween(Date value1, Date value2) {
            addCriterion("loan_time between", value1, value2, "loanTime");
            return (Criteria) this;
        }

        public Criteria andLoanTimeNotBetween(Date value1, Date value2) {
            addCriterion("loan_time not between", value1, value2, "loanTime");
            return (Criteria) this;
        }

        public Criteria andSettleStatusIsNull() {
            addCriterion("settle_status is null");
            return (Criteria) this;
        }

        public Criteria andSettleStatusIsNotNull() {
            addCriterion("settle_status is not null");
            return (Criteria) this;
        }

        public Criteria andSettleStatusEqualTo(Byte value) {
            addCriterion("settle_status =", value, "settleStatus");
            return (Criteria) this;
        }

        public Criteria andSettleStatusNotEqualTo(Byte value) {
            addCriterion("settle_status <>", value, "settleStatus");
            return (Criteria) this;
        }

        public Criteria andSettleStatusGreaterThan(Byte value) {
            addCriterion("settle_status >", value, "settleStatus");
            return (Criteria) this;
        }

        public Criteria andSettleStatusGreaterThanOrEqualTo(Byte value) {
            addCriterion("settle_status >=", value, "settleStatus");
            return (Criteria) this;
        }

        public Criteria andSettleStatusLessThan(Byte value) {
            addCriterion("settle_status <", value, "settleStatus");
            return (Criteria) this;
        }

        public Criteria andSettleStatusLessThanOrEqualTo(Byte value) {
            addCriterion("settle_status <=", value, "settleStatus");
            return (Criteria) this;
        }

        public Criteria andSettleStatusIn(List<Byte> values) {
            addCriterion("settle_status in", values, "settleStatus");
            return (Criteria) this;
        }

        public Criteria andSettleStatusNotIn(List<Byte> values) {
            addCriterion("settle_status not in", values, "settleStatus");
            return (Criteria) this;
        }

        public Criteria andSettleStatusBetween(Byte value1, Byte value2) {
            addCriterion("settle_status between", value1, value2, "settleStatus");
            return (Criteria) this;
        }

        public Criteria andSettleStatusNotBetween(Byte value1, Byte value2) {
            addCriterion("settle_status not between", value1, value2, "settleStatus");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNull() {
            addCriterion("delete_flag is null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNotNull() {
            addCriterion("delete_flag is not null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagEqualTo(Byte value) {
            addCriterion("delete_flag =", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotEqualTo(Byte value) {
            addCriterion("delete_flag <>", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThan(Byte value) {
            addCriterion("delete_flag >", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThanOrEqualTo(Byte value) {
            addCriterion("delete_flag >=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThan(Byte value) {
            addCriterion("delete_flag <", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThanOrEqualTo(Byte value) {
            addCriterion("delete_flag <=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIn(List<Byte> values) {
            addCriterion("delete_flag in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotIn(List<Byte> values) {
            addCriterion("delete_flag not in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagBetween(Byte value1, Byte value2) {
            addCriterion("delete_flag between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotBetween(Byte value1, Byte value2) {
            addCriterion("delete_flag not between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("update_time is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("update_time is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("update_time =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("update_time <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("update_time >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("update_time >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("update_time <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("update_time <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("update_time in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("update_time not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("update_time between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("update_time not between", value1, value2, "updateTime");
            return (Criteria) this;
        }
    }

    /**
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}