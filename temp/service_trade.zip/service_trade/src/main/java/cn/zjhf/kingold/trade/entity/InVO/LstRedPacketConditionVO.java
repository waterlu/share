package cn.zjhf.kingold.trade.entity.InVO;

import io.swagger.annotations.ApiModelProperty;

import java.util.Date;

/**
 * Created by zhangyijie on 2018/1/26.
 */
public class LstRedPacketConditionVO extends InVOBase {
    @ApiModelProperty(required = true, value = "审核编号/审核批次号")
    private long auditId;

    @ApiModelProperty(required = true, value = "用户UserUUID, 注意：app查询专用")
    private String userUuid;

    @ApiModelProperty(required = true, value = "用户名")
    private String userPhone;

    @ApiModelProperty(required = true, value = "用户姓名")
    private String userName;

    @ApiModelProperty(required = true, value = "领取状态: 1已发放(待领取)；2已领取")
    private int receiveStatus;

    @ApiModelProperty(required = true, value = "领取起始日期")
    private Date beginDrawDate;

    @ApiModelProperty(required = true, value = "领取截止日期")
    private Date endDrawDate;

    @ApiModelProperty(required = true, value = "起始序号")
    private int beginSN;

    @ApiModelProperty(required = true, value = "结束序号")
    private int endSN;

    @ApiModelProperty(required = true, value = "排序字段")
    private String orderBy;

    public long getAuditId() {
        return auditId;
    }

    public void setAuditId(long auditId) {
        this.auditId = auditId;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getReceiveStatus() {
        return receiveStatus;
    }

    public void setReceiveStatus(int receiveStatus) {
        this.receiveStatus = receiveStatus;
    }

    public Date getBeginDrawDate() {
        return beginDrawDate;
    }

    public void setBeginDrawDate(Date beginDrawDate) {
        this.beginDrawDate = beginDrawDate;
    }

    public Date getEndDrawDate() {
        return convertEndDate(endDrawDate);
    }

    public void setEndDrawDate(Date endDrawDate) {
        this.endDrawDate = endDrawDate;
    }

    public int getBeginSN() {
        return beginSN;
    }

    public void setBeginSN(int beginSN) {
        this.beginSN = beginSN;
    }

    public int getEndSN() {
        return endSN;
    }

    public void setEndSN(int endSN) {
        this.endSN = endSN;
    }

    public String getOrderBy() {
        return orderBy;
    }

    public void setOrderBy(String orderBy) {
        this.orderBy = orderBy;
    }

    @Override
    public String toString() {
        return "LstRedPacketConditionVO{" +
                "auditId=" + auditId +
                ", userUuid='" + userUuid + '\'' +
                ", userPhone='" + userPhone + '\'' +
                ", userName='" + userName + '\'' +
                ", receiveStatus=" + receiveStatus +
                ", beginDrawDate=" + beginDrawDate +
                ", endDrawDate=" + endDrawDate +
                ", beginSN=" + beginSN +
                ", endSN=" + endSN +
                ", orderBy='" + orderBy + '\'' +
                '}';
    }
}
