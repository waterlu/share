package cn.zjhf.kingold.trade.persistence.mq.message;

import cn.zjhf.kingold.rocketmq.base.MQMessage;
import cn.zjhf.kingold.trade.entity.Reward;
import cn.zjhf.kingold.trade.entity.RewardPrivateFund;

import java.util.Date;

/**
 * 用户生成奖励消息
 *
 * Created by wangxun on 2017/12/4
 */
public class RewardMessage implements MQMessage  {
    private Reward reward;

    public Reward getReward() {
        return reward;
    }

    public void setReward(Reward reward) {
        this.reward = reward;
    }

    @Override
    public String getKey() {
        return getReward().getRewardBillCode();
    }
}
