package cn.zjhf.kingold.trade.entity.OutVO;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.trade.entity.TradeOrder;
import cn.zjhf.kingold.trade.utils.AmountUtils;
import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.Date;

@ApiModel(value = "TradeOrderVO", description = "交易单")
public class TradeOrderVO extends ParamVO {

    @ApiModelProperty(required = true, value = "订单号，产品订单编号")
    @NotEmpty
    @Size(min = 1, max = 32)
    private String orderBillCode;

    @ApiModelProperty(required = true, value = "用户名，手机号码")
    @NotEmpty
    @Size(min = 1, max = 11)
    private String userPhone;

    @ApiModelProperty(required = true, value = "交易时间")
    @NotEmpty
    private Date transactionTime;

    @ApiModelProperty(required = true, value = "产品UUID")
    @NotEmpty
    @Size(min = 1, max = 32)
    private String productUuid;

    @ApiModelProperty(required = true, value = "投资金额/放款金额/本金   订单金额，订单金额 = 实缴金额 + 营销费用；订单金额 = 产品份额 * 产品单价")
    @NotEmpty
    private double orderAmount;

    @ApiModelProperty(required = true, value = "预期收益")
    @NotEmpty
    private double expectedProfitAmount;

    @ApiModelProperty(required = true, value = "支付金额/冻结金额   实缴金额")
    @NotEmpty
    private double paidAmount;

    @ApiModelProperty(required = true, value = "代金券金额   营销费用")
    @NotEmpty
    private double marketingAmount;

    @ApiModelProperty(required = true, value = "募集方应还利息(收益)  投资收益")
    @NotEmpty
    private double profitAmount;

    @ApiModelProperty(required = true, value = "平台应还营销利息(收益)  营销加息金额")
    @NotEmpty
    private double marketRateAmount;

    @ApiModelProperty(required = true, value = "返还总金额  兑付金额")
    @NotEmpty
    private double cashAmount;

    @ApiModelProperty(required = true, value = "募集方返还总额")
    @NotEmpty
    private double partyRaisedReturnTotalAmount;

    @ApiModelProperty(required = true, value = "订单状态 1创建，2已付款，3产品成立，4已清算，5撤销")
    @NotEmpty
    private int orderStatus;

    public TradeOrderVO() {
    }

    public TradeOrderVO(TradeOrder tradeOrder) {
        if(tradeOrder != null) {
            this.orderBillCode = tradeOrder.getOrderBillCode();
            this.userPhone = tradeOrder.getUserPhone();
            this.transactionTime = tradeOrder.getTransactionTime();
            this.productUuid = tradeOrder.getProductUuid();
            this.orderAmount = tradeOrder.getOrderAmount().doubleValue();
            this.expectedProfitAmount = tradeOrder.getExpectedProfitAmount().doubleValue();
            this.paidAmount = tradeOrder.getPaidAmount().doubleValue();
            this.marketingAmount = tradeOrder.getMarketingAmount().doubleValue();
            //this.profitAmount = tradeOrder.getProfitAmount().doubleValue();
            this.cashAmount = tradeOrder.getCashAmount().doubleValue();
            this.orderStatus = tradeOrder.getOrderStatus();
            this.marketRateAmount = tradeOrder.getMarketingRateAmount().doubleValue();
            this.profitAmount = this.expectedProfitAmount - this.marketRateAmount;

            this.partyRaisedReturnTotalAmount = AmountUtils.normal(orderAmount + profitAmount);
        }
    }

    public String getOrderBillCode() {
        return orderBillCode;
    }

    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    public Date getTransactionTime() {
        return transactionTime;
    }

    public void setTransactionTime(Date transactionTime) {
        this.transactionTime = transactionTime;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public double getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(double orderAmount) {
        this.orderAmount = orderAmount;
    }

    public double getExpectedProfitAmount() {
        return expectedProfitAmount;
    }

    public void setExpectedProfitAmount(double expectedProfitAmount) {
        this.expectedProfitAmount = expectedProfitAmount;
    }

    public double getPaidAmount() {
        return paidAmount;
    }

    public void setPaidAmount(double paidAmount) {
        this.paidAmount = paidAmount;
    }

    public double getMarketingAmount() {
        return marketingAmount;
    }

    public void setMarketingAmount(double marketingAmount) {
        this.marketingAmount = marketingAmount;
    }

    public double getProfitAmount() {
        return profitAmount;
    }

    public void setProfitAmount(double profitAmount) {
        this.profitAmount = profitAmount;
    }

    public double getCashAmount() {
        return cashAmount;
    }

    public void setCashAmount(double cashAmount) {
        this.cashAmount = cashAmount;
    }

    public int getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(int orderStatus) {
        this.orderStatus = orderStatus;
    }

    private TradeOrder get() {
        TradeOrder tradeOrder = new TradeOrder();
        tradeOrder.setOrderBillCode(orderBillCode);
        tradeOrder.setUserPhone(userPhone);
        tradeOrder.setTransactionTime(transactionTime);
        tradeOrder.setProductUuid(productUuid);
        tradeOrder.setOrderAmount(new BigDecimal(orderAmount));
        tradeOrder.setExpectedProfitAmount(new BigDecimal(expectedProfitAmount));
        tradeOrder.setPaidAmount(new BigDecimal(paidAmount));
        tradeOrder.setMarketingAmount(new BigDecimal(marketingAmount));
        tradeOrder.setProfitAmount(new BigDecimal(profitAmount));
        tradeOrder.setCashAmount(new BigDecimal(cashAmount));
        tradeOrder.setOrderStatus(new Integer(orderStatus).byteValue());
        return tradeOrder;
    }

    public double getMarketRateAmount() {
        return marketRateAmount;
    }

    public void setMarketRateAmount(double marketRateAmount) {
        this.marketRateAmount = marketRateAmount;
    }

    public double getPartyRaisedReturnTotalAmount() {
        return partyRaisedReturnTotalAmount;
    }

    public void setPartyRaisedReturnTotalAmount(double partyRaisedReturnTotalAmount) {
        this.partyRaisedReturnTotalAmount = partyRaisedReturnTotalAmount;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("orderBillCode:" + DataUtils.toString(orderBillCode) + ", ");
        sb.append("userPhone:" + DataUtils.toString(userPhone) + ", ");
        sb.append("transactionTime:" + DataUtils.toString(transactionTime) + ", ");
        sb.append("productUuid:" + DataUtils.toString(productUuid) + ", ");
        sb.append("orderAmount:" + DataUtils.toString(orderAmount) + ", ");
        sb.append("expectedProfitAmount:" + DataUtils.toString(expectedProfitAmount) + ", ");
        sb.append("paidAmount:" + DataUtils.toString(paidAmount) + ", ");
        sb.append("marketingAmount:" + DataUtils.toString(marketingAmount) + ", ");
        sb.append("profitAmount:" + DataUtils.toString(profitAmount) + ", ");
        sb.append("marketRateAmount:" + DataUtils.toString(marketRateAmount) + ", ");
        sb.append("cashAmount:" + DataUtils.toString(cashAmount) + ", ");
        sb.append("partyRaisedReturnTotalAmount:" + DataUtils.toString(partyRaisedReturnTotalAmount) + ", ");
        sb.append("orderStatus:" + DataUtils.toString(orderStatus));
        return sb.toString();
    }
}
