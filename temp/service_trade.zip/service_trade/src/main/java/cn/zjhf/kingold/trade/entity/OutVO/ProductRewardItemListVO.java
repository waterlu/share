package cn.zjhf.kingold.trade.entity.OutVO;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangyijie on 2017/6/5.
 */
@ApiModel(value = "ProductRewardItemListVO", description = "列表  报表->产品奖励记录->奖励详情->用户奖励明细记录")
public class ProductRewardItemListVO extends ParamVO {
    @ApiModelProperty(required = true, value = "总记录数")
    private int totalCount;

    @ApiModelProperty(required = true, value = "返回列表")
    private List<ProductRewardItemVO> items;

    public ProductRewardItemListVO() {
        totalCount = 0;
        items = new ArrayList<ProductRewardItemVO>();
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public List<ProductRewardItemVO> getItems() {
        return items;
    }

    public void setItems(List<ProductRewardItemVO> items) {
        this.items = items;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("totalCount:" + DataUtils.toString(totalCount) + ", ");
        sb.append("items:" + DataUtils.toString(items));
        return sb.toString();
    }
}
