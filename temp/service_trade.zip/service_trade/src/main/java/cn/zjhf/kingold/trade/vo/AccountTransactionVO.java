package cn.zjhf.kingold.trade.vo;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author
 */
public class AccountTransactionVO{
    /**
     * UUID
     */
    private String accountTransactionUuid;
    /**
     * 用户（电话号码）
     */
    private String investorMobile;
    /**
     * 交易时间
     */
    private String transactionTime;
    /**
     * 金额
     */
    private BigDecimal transactionAmount;
    /**
     * 交易类型 1宝付充值；2宝付投标；3宝付满标；4宝付流标；5宝付还款；6宝付提现；11融资方佣金；12理财顾问佣金
     */
    private String tradeType;
    /**
     * 资金凭证单号，如宝付的资金流水号
     */
    private String tradeOrderBillCode;
    /**
     * 订单编号扩展（宝付交易流水编号）
     */
    private String tradeOrderBillCodeExtend;

    public String getAccountTransactionUuid() {
        return accountTransactionUuid;
    }

    public void setAccountTransactionUuid(String accountTransactionUuid) {
        this.accountTransactionUuid = accountTransactionUuid;
    }

    public String getInvestorMobile() {
        return investorMobile;
    }

    public void setInvestorMobile(String investorMobile) {
        this.investorMobile = investorMobile;
    }

    public String getTransactionTime() {
        return transactionTime;
    }

    public void setTransactionTime(String transactionTime) {
        this.transactionTime = transactionTime;
    }

    public BigDecimal getTransactionAmount() {
        return transactionAmount;
    }

    public void setTransactionAmount(BigDecimal transactionAmount) {
        this.transactionAmount = transactionAmount;
    }

    public String getTradeType() {
        return tradeType;
    }

    public void setTradeType(String tradeType) {
        this.tradeType = tradeType;
    }

    public String getTradeOrderBillCode() {
        return tradeOrderBillCode;
    }

    public void setTradeOrderBillCode(String tradeOrderBillCode) {
        this.tradeOrderBillCode = tradeOrderBillCode;
    }

    public String getTradeOrderBillCodeExtend() {
        return tradeOrderBillCodeExtend;
    }

    public void setTradeOrderBillCodeExtend(String tradeOrderBillCodeExtend) {
        this.tradeOrderBillCodeExtend = tradeOrderBillCodeExtend;
    }
}