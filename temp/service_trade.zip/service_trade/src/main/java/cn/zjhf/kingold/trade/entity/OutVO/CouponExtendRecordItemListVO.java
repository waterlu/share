package cn.zjhf.kingold.trade.entity.OutVO;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.trade.entity.CouponExtendRecord;
import cn.zjhf.kingold.trade.entity.InVO.CashCouponVO;
import cn.zjhf.kingold.trade.entity.InVO.CouponExtendRecordVO;
import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModelProperty;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangyijie on 2017/7/5.
 */
public class CouponExtendRecordItemListVO extends ParamVO {
    @ApiModelProperty(required = true, value = "总记录数")
    private int totalCount;

    @ApiModelProperty(required = true, value = "返回列表")
    private List<CouponExtendRecordVO> items;

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public List<CouponExtendRecordVO> getItems() {
        return items;
    }

    public void setItems(List<CouponExtendRecordVO> items) {
        this.items = items;
    }

    public void setItemsEx(List<CouponExtendRecord> items) {
        if(null == items) {
            return;
        }

        this.items = new ArrayList<CouponExtendRecordVO>();
        if(items != null && items.size() > 0) {
            for(CouponExtendRecord item : items) {
                this.items.add(new CouponExtendRecordVO(item));
            }
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(getTraceID()) + ", ");
        sb.append("totalCount:" + DataUtils.toString(totalCount) + ", ");
        sb.append("items:" + DataUtils.toString(items));
        return sb.toString();
    }
}
