package cn.zjhf.kingold.trade.constant;

/**
 * Created by Xiaody on 17/6/16.
 */
public interface NotificationType {

    /**
     * 验证码
     */
    String VERIFY_CODE = "1001";

    /**
     * 产品成立（私募）(投资用户)
     */
    String PRODUCT_ESTABLLISH_TO_INVESTOR = "1002";

    /**
     * 产品成立（私募）(预约提交者)
     */
    String PRODUCT_ESTABLLISH_TO_RESERVE = "1003";

    /**
     * 投资（定期）
     */
    String FIXI_INVEST = "1004";

    /**
     * 到期还款（定期）
     */
    String FIXI_REPAYMENT = "1005";

    /**
     * 奖励发放（私募）
     */
    String PRIF_PROVIDE_REWARD = "1006";

    /**
     * 服务津贴发放（私募）
     */
    String PRIF_PROVIDE_ALLOWANCE = "1007";

    /**
     * 奖励发放（定期）
     */
    String FIXI_PROVIDE_REWARD = "1008";


    /**
     * 提现
     */
    String WITH_DRAW = "1009";

    /**
     * 私募预约单分配
     */
    String ALLOCATE_RESERVATION = "1010";

    /**
     * 用户成为平台合伙人
     */
    String BE_FINANCIAL_PLANNER = "1011";


    /**
     * 客服电话
     */
    String CUSTOMER_SERVICE_PHONE = "400-640-3606";

}
