package cn.zjhf.kingold.trade.persistence.dao;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.dto.TradeOrderProfitEverydayDto;
import cn.zjhf.kingold.trade.entity.OutVO.TradePaymentSummaryVO;
import cn.zjhf.kingold.trade.entity.TradeInvestSummary;
import cn.zjhf.kingold.trade.entity.TradePaymentSummary;
import cn.zjhf.kingold.trade.entity.TradePaymentSummaryExample;

import java.util.Date;
import java.util.List;

import cn.zjhf.kingold.trade.utils.WhereCondition;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface TradePaymentSummaryMapper {
    long countByExample(TradePaymentSummaryExample example);

    int deleteByExample(TradePaymentSummaryExample example);

    int deleteByPrimaryKey(Long tradePaymentSummaryUuid);

    int insert(TradePaymentSummary record);

    int insertSelective(TradePaymentSummary record);

    List<TradePaymentSummary> selectByExample(TradePaymentSummaryExample example);

    List<TradePaymentSummary> lstByCondition(WhereCondition condition);

    @Select("SELECT Count(*) FROM trade_payment_summary ${condition}")
    int lstCountByCondition(WhereCondition condition);

    @Update("UPDATE trade_payment_summary SET batch_no = #{batchNo} WHERE batch_no = #{oldBatchNo}")
    void updateBatchNo(@Param("batchNo") String batchNo, @Param("oldBatchNo") String oldBatchNo);

    TradePaymentSummary selectByPrimaryKey(Long tradePaymentSummaryUuid);

    int updateByExampleSelective(@Param("record") TradePaymentSummary record, @Param("example") TradePaymentSummaryExample example);

    int updateByExample(@Param("record") TradePaymentSummary record, @Param("example") TradePaymentSummaryExample example);

    int updateByPrimaryKeySelective(TradePaymentSummary record);

    int updateByPrimaryKey(TradePaymentSummary record);

    List<String> calculateYesterdayPaidProfit(@Param("startTime") Date startTime, @Param("endTime") Date endTime) throws BusinessException;

    /**
     * 刷新收益
     *
     * @param tradePaymentSummaryVO
     * @return
     */
    int fixProductClear(TradePaymentSummaryVO tradePaymentSummaryVO);
}