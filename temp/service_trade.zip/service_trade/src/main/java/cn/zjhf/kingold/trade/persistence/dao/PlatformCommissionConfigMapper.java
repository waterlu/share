package cn.zjhf.kingold.trade.persistence.dao;

import cn.zjhf.kingold.trade.entity.PlatformCommissionConfig;
import cn.zjhf.kingold.trade.entity.PlatformCommissionConfigExample;
import java.util.List;

import cn.zjhf.kingold.trade.entity.TradeInvestSummary;
import cn.zjhf.kingold.trade.utils.WhereCondition;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface PlatformCommissionConfigMapper {
    long countByExample(PlatformCommissionConfigExample example);

    int deleteByExample(PlatformCommissionConfigExample example);

    int deleteByPrimaryKey(Long platformCommissionId);

    int insert(PlatformCommissionConfig record);

    int insertSelective(PlatformCommissionConfig record);

    @Delete("DELETE FROM platform_commission_config where product_uuid = #{productUuid}")
    int deleteByProductUuid(@Param("productUuid") String productUuid);

    List<PlatformCommissionConfig> lstByCondition(WhereCondition condition);

    List<PlatformCommissionConfig> selectByExample(PlatformCommissionConfigExample example);

    PlatformCommissionConfig selectByPrimaryKey(Long platformCommissionId);

    int updateByExampleSelective(@Param("record") PlatformCommissionConfig record, @Param("example") PlatformCommissionConfigExample example);

    int updateByExample(@Param("record") PlatformCommissionConfig record, @Param("example") PlatformCommissionConfigExample example);

    int updateByPrimaryKeySelective(PlatformCommissionConfig record);

    int updateByPrimaryKey(PlatformCommissionConfig record);
}