package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.constant.*;
import cn.zjhf.kingold.trade.entity.Reward;
import cn.zjhf.kingold.trade.entity.RewardFixedTerm;
import cn.zjhf.kingold.trade.persistence.dao.AccountMapper;
import cn.zjhf.kingold.trade.persistence.dao.RewardFixedTermMapper;
import cn.zjhf.kingold.trade.persistence.dao.RewardMapper;
import cn.zjhf.kingold.trade.persistence.mq.message.RewardFixedTermMessage;
import cn.zjhf.kingold.trade.persistence.mq.producer.RewardFixedTermProducer;
import cn.zjhf.kingold.trade.service.IAccountBaofooService;
import cn.zjhf.kingold.trade.service.IAccountService;
import cn.zjhf.kingold.trade.service.IPayService;
import cn.zjhf.kingold.trade.service.IRewardSummaryExecService;
import cn.zjhf.kingold.trade.utils.DataUtils;
import cn.zjhf.kingold.trade.utils.MapParamUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by lutiehua on 2017/6/21.
 */
@Service
public class RewardSummaryExecServiceImpl implements IRewardSummaryExecService {

    private final Logger LOGGER = LoggerFactory.getLogger(RewardSummaryExecServiceImpl.class);

    @Autowired
    private IAccountBaofooService accountBaofooService;

    @Autowired
    private IAccountService accountService;

    @Autowired
    private AccountMapper accountMapper;

    @Autowired
    private RewardFixedTermMapper rewardFixedTermMapper;

    @Autowired
    private RewardMapper rewardMapper;

    @Autowired
    private IPayService payService;

    @Autowired
    private RewardFixedTermProducer rewardFixedTermProducer;

    @Value("${baofoo.merchant.id}")
    private long merchantId;

    private Long getAccountNo(String accountUuid, String accountType) throws BusinessException {
        Map<String, Object> paramMap = new HashMap();
        if(DataUtils.isNotEmpty(accountUuid)) {
            paramMap.put("accountUuid", accountUuid);
        }else if(DataUtils.isNotEmpty(accountType)) {
            accountUuid = accountMapper.lstAccountUuidByType(accountType);
            if(DataUtils.isNotEmpty(accountUuid)) {
                paramMap.put("accountUuid", accountUuid);
            }
        }

        if(paramMap.size() == 0) {
            return null;
        }

        paramMap.put("properties", "accountNo");
        Map<String, Object> accountInfo = accountBaofooService.get(paramMap);

        return MapParamUtils.getLongInMap(accountInfo, "accountNo");
    }

    /**
     * 执行结算操作
     *
     * @param rewardFixedTerm
     * @return
     */
    @Override
    @Transactional(rollbackFor = BusinessException.class, propagation = Propagation.REQUIRES_NEW)
    public ResponseResult executeClearOperation(RewardFixedTerm rewardFixedTerm) throws BusinessException {
        ResponseResult responseResult = new ResponseResult();
        LOGGER.info("执行定期产品奖励结算操作：{}", rewardFixedTerm.getRewardFixedBillCode());

        // 取投资人托管账户
        Long investerAccountNo = getAccountNo(rewardFixedTerm.getAccountUuid(), null);
        if((investerAccountNo == null) || (investerAccountNo <= 0)) {
            throw new BusinessException(TradeStatusMsg.ACCOUNT_NOT_EXIST, "投资人托管" + TradeStatusMsg.ACCOUNT_NOT_EXIST_MSG);
        }

        // 取平台结算账户
        Long platformSettlementAccountNo = getAccountNo(null, AccountType.ACCOUNT_TYPE_PLATFORM_SETTLEMENT);
        if((platformSettlementAccountNo == null) || (platformSettlementAccountNo <= 0)) {
            throw new BusinessException(TradeStatusMsg.ACCOUNT_NOT_EXIST, "平台结算" + TradeStatusMsg.ACCOUNT_NOT_EXIST_MSG);
        }

        String orderID = rewardFixedTerm.getRewardFixedBillCode();
        BigDecimal amount = rewardFixedTerm.getPayAmount();

        LOGGER.info("orderID={}", orderID);
        LOGGER.info("amount={}", amount.doubleValue());

        // 记录账户变化和流水
        accountService.payment(orderID, platformSettlementAccountNo, investerAccountNo, amount, TradeType.TRADE_COMMISION_PAYMENT_ADVISER,
                "");

        //更新账户中的累计佣金奖励
        accountMapper.investorPaymentReward(rewardFixedTerm.getAccountUuid(), amount.doubleValue());

        Date now = new Date();

        // 更新状态
        Map<String, Object>  clearMap = new HashMap<>();
        clearMap.put("rewardFixedBillCode", rewardFixedTerm.getRewardFixedBillCode());
        clearMap.put("rewardFixedStatus", RewardSummaryStatus.FINISH);
        clearMap.put("clearTime", now);
        clearMap.put("remark", "");
        clearMap.put("orderId", orderID);
        clearMap.put("accountUuid", rewardFixedTerm.getAccountUuid());
        rewardFixedTermMapper.updateClearStatus(clearMap);

        // 更新奖励记录明细的状态和税后金额（分摊）
        List<Reward> rewardList = rewardMapper.queryBySummaryBillCode(rewardFixedTerm.getRewardFixedBillCode());
        if (rewardList.size() > 1) {
            BigDecimal total = rewardFixedTerm.getTotalAmount();
            BigDecimal payment = rewardFixedTerm.getPayAmount();
            if (payment.doubleValue() > 0) {
                BigDecimal unit = payment.divide(total, 6, BigDecimal.ROUND_DOWN);
                BigDecimal check = new BigDecimal(0);
                for (Reward reward : rewardList) {
                    BigDecimal rewardAmount = reward.getRewardAmount();
                    BigDecimal rewardPayment = rewardAmount.multiply(unit).setScale(BizConstant.CASH_FRACTION_COUNT, BigDecimal.ROUND_HALF_UP);
                    reward.setPayAmount(rewardPayment);
                    reward.setClearTime(now);
                    check = check.add(rewardPayment);
                }

                if (check.compareTo(payment) != 0) {
                    BigDecimal diff = payment.subtract(check);
                    Reward reward = rewardList.get(0);
                    BigDecimal rewardPayment = reward.getPayAmount();
                    rewardPayment = rewardPayment.add(diff);
                    reward.setPayAmount(rewardPayment);
                }
            } else {
                for (Reward reward : rewardList) {
                    reward.setPayAmount(new BigDecimal(0));
                    reward.setClearTime(now);
                }
            }

            for (Reward reward : rewardList) {
                Map<String, Object> paramReward = new HashMap<>();
                paramReward.put("rewardBillCode", reward.getRewardBillCode());
                paramReward.put("payAmount", reward.getPayAmount());
                paramReward.put("clearTime", reward.getClearTime());
                rewardMapper.updateClearTime(paramReward);
            }
        } else if (rewardList.size() == 1) {
            for (Reward reward : rewardList) {
                Map<String, Object> paramReward = new HashMap<>();
                reward.setPayAmount(rewardFixedTerm.getPayAmount());
                reward.setClearTime(now);
                paramReward.put("rewardBillCode", reward.getRewardBillCode());
                paramReward.put("payAmount", reward.getPayAmount());
                paramReward.put("clearTime", reward.getClearTime());
                rewardMapper.updateClearTime(paramReward);
            }
        }

        // 平台向用户转账
        LOGGER.info("orderID:" + orderID + ", investerAccountNo:" + investerAccountNo + ", amount:" + amount);
        ResponseResult payResult = payService.transferP2C(orderID, investerAccountNo, amount.doubleValue());
        if (!payResult.isSuccessful()) {
            LOGGER.info(payResult.toString());
            throw new BusinessException(payResult.getCode(), payResult.getMsg());
        }

        //定期奖励发送mq消息
        RewardFixedTermMessage message = new RewardFixedTermMessage();
        message.setRewardFixedTerm(rewardFixedTerm);
        rewardFixedTermProducer.send(message);

        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        return responseResult;
    }


    /**
     * 活动奖励1.向平台账户转账 2.记录明细流水
     * @param campaignRewardBillCode
     * @param amount
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = BusinessException.class, propagation = Propagation.REQUIRES_NEW)
    public ResponseResult executeCampaignRewardOperation(String userUuid,String campaignRewardBillCode,BigDecimal amount) throws BusinessException {
        ResponseResult responseResult = new ResponseResult();
        LOGGER.info("执行活动奖励结算操作：{}", campaignRewardBillCode);

        // 检查账户情况
        LOGGER.info("检查账户情况");
        Map<String, Object> paramMap = new HashMap();
        paramMap.put("userUuid", userUuid);
        Map<String, Object> userInfo = accountMapper.get(paramMap);
        String accountUuid = "";
        if (null != userInfo && null != userInfo.get("accountUuid")) {
            accountUuid = userInfo.get("accountUuid").toString();
            LOGGER.info("accountUuid={}", accountUuid);
        }
        if (StringUtils.isEmpty(accountUuid)) {
            throw new BusinessException(TradeStatusMsg.ACCOUNT_NOT_EXIST, "账户" + TradeStatusMsg.ACCOUNT_NOT_EXIST_MSG);
        }

        // 取投资人托管账户
        Long investerAccountNo = getAccountNo(accountUuid, null);
        if((investerAccountNo == null) || (investerAccountNo <= 0)) {
            throw new BusinessException(TradeStatusMsg.ACCOUNT_NOT_EXIST, "投资人托管" + TradeStatusMsg.ACCOUNT_NOT_EXIST_MSG);
        }

        // 取平台结算账户
        Long platformSettlementAccountNo = getAccountNo(null, AccountType.ACCOUNT_TYPE_PLATFORM_SETTLEMENT);
        if((platformSettlementAccountNo == null) || (platformSettlementAccountNo <= 0)) {
            throw new BusinessException(TradeStatusMsg.ACCOUNT_NOT_EXIST, "平台结算" + TradeStatusMsg.ACCOUNT_NOT_EXIST_MSG);
        }

        LOGGER.info("campaignRewardBillCode={}", campaignRewardBillCode);
        LOGGER.info("amount={}", amount.doubleValue());

        // 记录账户变化和流水
        accountService.payment(campaignRewardBillCode, platformSettlementAccountNo, investerAccountNo, amount, TradeType.TRADE_COMMISION_PAYMENT_EXPERIENCE_ACTIVITY,
                "");

        // 平台向用户转账
        LOGGER.info("campaignRewardBillCode:" + campaignRewardBillCode + ", investerAccountNo:" + investerAccountNo + ", amount:" + amount);
        ResponseResult payResult = payService.transferP2C(campaignRewardBillCode, investerAccountNo, amount.doubleValue());
        if (!payResult.isSuccessful()) {
            LOGGER.info(payResult.toString());
            throw new BusinessException(payResult.getCode(), payResult.getMsg());
        }

        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        return responseResult;
    }
}
