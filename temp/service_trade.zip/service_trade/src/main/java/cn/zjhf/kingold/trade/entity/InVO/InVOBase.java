package cn.zjhf.kingold.trade.entity.InVO;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.trade.utils.AmountUtils;
import cn.zjhf.kingold.trade.utils.StringOrDate;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by zhangyijie on 2017/6/15.
 */
public class InVOBase extends ParamVO {
    protected Date convertEndDate(Date endDate) {
        if(endDate != null) {
            endDate = StringOrDate.dateOffsetDay(endDate, 1);
        }
        return endDate;
    }
    protected Double formatMoney(double money) {
        if(Double.isNaN(money)) {
            return money;
        }
        return AmountUtils.exac(money);
    }
    protected BigDecimal formatMoney(BigDecimal money) {
        if(money != null && !money.equals(BigDecimal.ZERO)) {
            return BigDecimal.valueOf(AmountUtils.exac(money));
        }
        return money;
    }
    protected Double formatRate(double rate) {
        if(Double.isNaN(rate)) {
            return rate;
        }
        return AmountUtils.exactRate(rate);
    }
    protected BigDecimal formatRate(BigDecimal rate) {
        if(rate != null && !rate.equals(BigDecimal.ZERO)) {
            return BigDecimal.valueOf(AmountUtils.exactRate(rate));
        }
        return rate;
    }
}
