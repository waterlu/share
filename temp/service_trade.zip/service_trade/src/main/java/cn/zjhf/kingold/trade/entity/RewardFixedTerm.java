package cn.zjhf.kingold.trade.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author 
 */
public class RewardFixedTerm implements Serializable {
    /**
     * 定期奖励结算单号
     */
    private String rewardFixedBillCode;

    /**
     * 定期奖励结算单批次号
     */
    private String rewardFixedBatchCode;

    /**
     * 定期奖励结算单状态
     */
    private Integer rewardFixedStatus;

    /**
     * 结算周期起始日
     */
    private Date rewardFixedStartDate;

    /**
     * 结算周期截止日
     */
    private Date rewardFixedEndDate;

    /**
     * 用户UUID
     */
    private String userUuid;

    /**
     * 用户手机
     */
    private String userMobile;

    /**
     * 用户姓名
     */
    private String userName;

    /**
     * 用户身份证号码
     */
    private String userIdCardNo;

    /**
     * 用户账户UUID
     */
    private String accountUuid;

    /**
     * 奖励单数
     */
    private Integer rewardCount;

    /**
     * 邀请奖励
     */
    private BigDecimal saleAmount;

    /**
     * 一度邀请津贴
     */
    private BigDecimal levelOneAmount;

    /**
     * 一度达人奖励
     */
    private BigDecimal masterOneAmount;

    /**
     * 二度达人奖励
     */
    private BigDecimal masterTwoAmount;

    /**
     * 三度达人奖励
     */
    private BigDecimal masterThreeAmount;

    /**
     * 二度邀请津贴
     */
    private BigDecimal levelTwoAmount;

    /**
     * 奖励税前金额合计
     */
    private BigDecimal totalAmount;

    /**
     * 税金
     */
    private BigDecimal taxAmount;

    /**
     * 税后奖励总额
     */
    private BigDecimal payAmount;

    public BigDecimal getPlatformAmount() {
        return platformAmount;
    }

    public void setPlatformAmount(BigDecimal platformAmount) {
        this.platformAmount = platformAmount;
    }

    private BigDecimal platformAmount;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 审核时间
     */
    private Date checkTime;

    /**
     * 结算时间
     */
    private Date clearTime;

    /**
     * 申请人
     */
    private String createUser;

    /**
     * 审核人
     */
    private String checkUser;

    /**
     * 结算人
     */
    private String clearUser;

    /**
     * 备注
     */
    private String remark;

    /**
     * 传给宝付的orderID
     */
    private String orderId;


    private String belongTopUserUuid;

    private String belongTopOrgPath;

    public String getBelongTopUserUuid() {
        return belongTopUserUuid;
    }

    public void setBelongTopUserUuid(String belongTopUserUuid) {
        this.belongTopUserUuid = belongTopUserUuid;
    }

    public String getBelongTopOrgPath() {
        return belongTopOrgPath;
    }

    public void setBelongTopOrgPath(String belongTopOrgPath) {
        this.belongTopOrgPath = belongTopOrgPath;
    }

    @JsonIgnore
    private List<Reward> rewardList = new ArrayList<>();

    public void addReward(Reward reward) {
        rewardList.add(reward);
    }

    public List<Reward> getRewardList() {
        return rewardList;
    }

    private static final long serialVersionUID = 1L;

    public String getRewardFixedBillCode() {
        return rewardFixedBillCode;
    }

    public void setRewardFixedBillCode(String rewardFixedBillCode) {
        this.rewardFixedBillCode = rewardFixedBillCode;
    }

    public Date getRewardFixedStartDate() {
        return rewardFixedStartDate;
    }

    public void setRewardFixedStartDate(Date rewardFixedStartDate) {
        this.rewardFixedStartDate = rewardFixedStartDate;
    }

    public Date getRewardFixedEndDate() {
        return rewardFixedEndDate;
    }

    public void setRewardFixedEndDate(Date rewardFixedEndDate) {
        this.rewardFixedEndDate = rewardFixedEndDate;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserIdCardNo() {
        return userIdCardNo;
    }

    public void setUserIdCardNo(String userIdCardNo) {
        this.userIdCardNo = userIdCardNo;
    }

    public String getAccountUuid() {
        return accountUuid;
    }

    public void setAccountUuid(String accountUuid) {
        this.accountUuid = accountUuid;
    }

    public Integer getRewardCount() {
        return rewardCount;
    }

    public void setRewardCount(Integer rewardCount) {
        this.rewardCount = rewardCount;
    }

    public BigDecimal getSaleAmount() {
        return saleAmount;
    }

    public void setSaleAmount(BigDecimal saleAmount) {
        this.saleAmount = saleAmount;
    }

    public BigDecimal getLevelOneAmount() {
        return levelOneAmount;
    }

    public void setLevelOneAmount(BigDecimal levelOneAmount) {
        this.levelOneAmount = levelOneAmount;
    }

    public BigDecimal getLevelTwoAmount() {
        return levelTwoAmount;
    }

    public void setLevelTwoAmount(BigDecimal levelTwoAmount) {
        this.levelTwoAmount = levelTwoAmount;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public BigDecimal getTaxAmount() {
        return taxAmount;
    }

    public void setTaxAmount(BigDecimal taxAmount) {
        this.taxAmount = taxAmount;
    }

    public BigDecimal getPayAmount() {
        return payAmount;
    }

    public void setPayAmount(BigDecimal payAmount) {
        this.payAmount = payAmount;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getCheckTime() {
        return checkTime;
    }

    public void setCheckTime(Date checkTime) {
        this.checkTime = checkTime;
    }

    public Date getClearTime() {
        return clearTime;
    }

    public void setClearTime(Date clearTime) {
        this.clearTime = clearTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public String getCheckUser() {
        return checkUser;
    }

    public void setCheckUser(String checkUser) {
        this.checkUser = checkUser;
    }

    public String getClearUser() {
        return clearUser;
    }

    public void setClearUser(String clearUser) {
        this.clearUser = clearUser;
    }

    public Integer getRewardFixedStatus() {
        return rewardFixedStatus;
    }

    public void setRewardFixedStatus(Integer rewardFixedStatus) {
        this.rewardFixedStatus = rewardFixedStatus;
    }

    public String getUserMobile() {
        return userMobile;
    }

    public void setUserMobile(String userMobile) {
        this.userMobile = userMobile;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getRewardFixedBatchCode() {
        return rewardFixedBatchCode;
    }

    public void setRewardFixedBatchCode(String rewardFixedBatchCode) {
        this.rewardFixedBatchCode = rewardFixedBatchCode;
    }

    @Override
    public String toString() {
        return "RewardFixedTerm{" +
                "rewardFixedBillCode='" + rewardFixedBillCode + '\'' +
                ", rewardFixedStatus=" + rewardFixedStatus +
                ", rewardFixedStartDate=" + rewardFixedStartDate +
                ", rewardFixedEndDate=" + rewardFixedEndDate +
                ", userUuid='" + userUuid + '\'' +
                ", userMobile='" + userMobile + '\'' +
                ", userName='" + userName + '\'' +
                ", userIdCardNo='" + userIdCardNo + '\'' +
                ", accountUuid='" + accountUuid + '\'' +
                ", rewardCount=" + rewardCount +
                ", saleAmount=" + saleAmount +
                ", levelOneAmount=" + levelOneAmount +
                ", levelTwoAmount=" + levelTwoAmount +
                ", masterOneAmount=" + masterOneAmount +
                ", masterTwoAmount=" + masterTwoAmount +
                ", masterThreeAmount=" + masterThreeAmount +
                ", totalAmount=" + totalAmount +
                ", taxAmount=" + taxAmount +
                ", payAmount=" + payAmount +
                ", platformAmount=" + platformAmount +
                ", createTime=" + createTime +
                ", checkTime=" + checkTime +
                ", clearTime=" + clearTime +
                ", createUser='" + createUser + '\'' +
                ", checkUser='" + checkUser + '\'' +
                ", clearUser='" + clearUser + '\'' +
                ", remark='" + remark + '\'' +
                ", orderId='" + orderId + '\'' +
                '}';
    }

    public BigDecimal getMasterOneAmount() {
        return masterOneAmount;
    }

    public void setMasterOneAmount(BigDecimal masterOneAmount) {
        this.masterOneAmount = masterOneAmount;
    }

    public BigDecimal getMasterTwoAmount() {
        return masterTwoAmount;
    }

    public void setMasterTwoAmount(BigDecimal masterTwoAmount) {
        this.masterTwoAmount = masterTwoAmount;
    }

    public BigDecimal getMasterThreeAmount() {
        return masterThreeAmount;
    }

    public void setMasterThreeAmount(BigDecimal masterThreeAmount) {
        this.masterThreeAmount = masterThreeAmount;
    }
}