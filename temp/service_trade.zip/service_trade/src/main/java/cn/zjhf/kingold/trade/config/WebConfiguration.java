package cn.zjhf.kingold.trade.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * Created by lu on 2017/3/13.
 */
@Configuration
public class WebConfiguration extends WebMvcConfigurerAdapter {

//    @Bean
//    public HttpRequestFilter webRequestFilter() {
//        return new HttpRequestFilter();
//    }
//
//    @Bean
//    public FilterRegistrationBean filterRegistrationBean() {
//        FilterRegistrationBean registrationBean = new FilterRegistrationBean();
////        registrationBean.setFilter(webRequestFilter());
//        registrationBean.addUrlPatterns("/*");
//        registrationBean.setName("httpRequestFilter");
//        registrationBean.setOrder(1);
//        return registrationBean;
//    }


}
