package cn.zjhf.kingold.trade.persistence.mq.consumer;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.rocketmq.annotation.RocketMQConsumer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQConsumer;
import cn.zjhf.kingold.trade.constant.BizDefine;
import cn.zjhf.kingold.trade.constant.MarketCampaignCodeEnum;
import cn.zjhf.kingold.trade.dto.CouponSendConditionDto;
import cn.zjhf.kingold.trade.persistence.dao.OperationReportMapper;
import cn.zjhf.kingold.trade.persistence.mq.message.UserMessage;
import cn.zjhf.kingold.trade.service.IMarketCampaignService;
import cn.zjhf.kingold.trade.service.IUserService;
import cn.zjhf.kingold.trade.utils.DataUtils;
import cn.zjhf.kingold.trade.utils.DateUtil;
import cn.zjhf.kingold.trade.utils.QueryUtils;
import cn.zjhf.kingold.trade.utils.WhereCondition;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;

/**
 * 用户注册成功，红包
 * <p>
 * Created by lutiehua on 2017/7/14.
 */
@RocketMQConsumer(topic = "user", tag = "auth")
public class UserAuthConsumer extends AbstractMQConsumer<UserMessage> {

    private final Logger LOGGER = LoggerFactory.getLogger(UserAuthConsumer.class);

    @Autowired
    private IMarketCampaignService marketCampaignService;

    @Autowired
    private IUserService userService;

    @Autowired
    private OperationReportMapper operationReportMapper;

    /**
     * 检查实名时间，只筛选出两小时之内的实名时间
     * @param userUuid
     * @return true 近期消息，继续处理；false 远期消息，放弃处理
     */
    private boolean checkAuthTime(String userUuid) {
        if(DataUtils.isNotEmpty(userUuid)) {
            String sql = "SELECT create_time FROM account_baofoo_custody "
                    + "WHERE account_uuid IN (SELECT account_uuid FROM account WHERE user_uuid="
                    + WhereCondition.toSQLStr(userUuid) + " AND delete_flag=0) "
                    + "AND delete_flag=0 ORDER BY create_time DESC LIMIT 0,1 ";
            String occuTimeStr = operationReportMapper.lstSingleString(new QueryUtils(sql));

            if(DataUtils.isNotEmpty(occuTimeStr)) {
                Date occuTime = DateUtil.strToTime(occuTimeStr);
                if(occuTime!=null) {
                    int diffTime = (int) (((new Date()).getTime() - occuTime.getTime()) / (1000 * 3600));
                    return diffTime <= 1;
                }
            }
        }

        return false;
    }

    private boolean insertCerLog(int key, String value) {
        int ret = -1;

        try {
            ret = operationReportMapper.insertCerMqLog(key, value);
        }catch(Exception e) {
            LOGGER.error("插入失败", e);
        }

        LOGGER.info("ret: ", ret);
        return ret > 0;
    }

    @Override
    public ResponseResult process(UserMessage userMessage) throws BusinessException {
        LOGGER.info("用户实名认证消息");
        //判断商户号不是金疙瘩不发放优惠券
        if (StringUtils.isNotBlank(userMessage.getMerchantNum()) && !BizDefine.KINGOLD_MERCHANT.equals(userMessage.getMerchantNum())) {
            logger.info("用户实名认证渠道商户号是：{}", userMessage.getMerchantNum());
            return new ResponseResult();
        }
        int applyScene = MarketCampaignCodeEnum.INVITE_FRIEND_REAL_NAME.getCode();
        String messKey = null;

        if (checkAuthTime(userMessage.getUserUuid())) {
            String inviterUuid = userService.getInviterUuid(userMessage.getUserUuid());
            if (DataUtils.isNotEmpty(inviterUuid)) {

                messKey = inviterUuid + "&&" + userMessage.getUserUuid();
                if(insertCerLog(applyScene, messKey)) {
                    LOGGER.info("sendCoupon friend first invest . userUuid={}, inviterUuid={}", userMessage.getUserUuid(), inviterUuid);

                    try {
                        marketCampaignService.marketCampaignTrigger(new CouponSendConditionDto(inviterUuid, applyScene, null, userMessage.getUserUuid()));
                    } catch (BusinessException e) {
                        LOGGER.error("用户实名认证异常，", e);
                    }
                }
            }
        }
        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        return responseResult;
    }
}