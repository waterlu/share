package cn.zjhf.kingold.trade.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author 
 */
public class RewardServiceAllowance implements Serializable {
    /**
     * 发放单号
     */
    private String rewardAllowanceBillCode;

    /**
     * 定期奖励结算单批次号
     */
    private String rewardAllowanceBatchCode;

    /**
     * 结算周期起始日
     */
    private Date rewardAllowanceStartDate;

    /**
     * 结算周期截止日
     */
    private Date rewardAllowanceEndDate;

    /**
     * 发放状态
     */
    private Integer rewardAllowanceStatus;

    /**
     * 所属机构ID
     */
    private String orgUuid;

    /**
     * 所属机构树形关系
     */
    private String orgPath;

    /**
     * 用户UUID
     */
    private String userUuid;

    /**
     * 用户手机号码
     */
    private String userMobile;

    /**
     * 用户姓名
     */
    private String userRealName;

    /**
     * 用户身份证号码
     */
    private String userIdCardNo;

    /**
     * 奖励单数
     */
    private Integer rewardCount;

    /**
     * 奖励金额（税前服务津贴）
     */
    private BigDecimal rewardAmount;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 审核时间
     */
    private Date checkTime;

    /**
     * 结算时间
     */
    private Date clearTime;

    /**
     * 创建人
     */
    private String createUser;

    /**
     * 审核人
     */
    private String checkUser;

    /**
     * 结算人
     */
    private String clearUser;

    /**
     * 备注
     */
    private String remark;

    private String belongTopUserUuid;

    private String belongTopOrgPath;

    public String getBelongTopUserUuid() {
        return belongTopUserUuid;
    }

    public void setBelongTopUserUuid(String belongTopUserUuid) {
        this.belongTopUserUuid = belongTopUserUuid;
    }

    public String getBelongTopOrgPath() {
        return belongTopOrgPath;
    }

    public void setBelongTopOrgPath(String belongTopOrgPath) {
        this.belongTopOrgPath = belongTopOrgPath;
    }

    @JsonIgnore
    private List<Reward> rewardList = new ArrayList<>();

    public void addReward(Reward reward) {
        rewardList.add(reward);
    }

    public List<Reward> getRewardList() {
        return rewardList;
    }

    private static final long serialVersionUID = 1L;

    public String getRewardAllowanceBillCode() {
        return rewardAllowanceBillCode;
    }

    public void setRewardAllowanceBillCode(String rewardAllowanceBillCode) {
        this.rewardAllowanceBillCode = rewardAllowanceBillCode;
    }

    public Date getRewardAllowanceStartDate() {
        return rewardAllowanceStartDate;
    }

    public void setRewardAllowanceStartDate(Date rewardAllowanceStartDate) {
        this.rewardAllowanceStartDate = rewardAllowanceStartDate;
    }

    public Date getRewardAllowanceEndDate() {
        return rewardAllowanceEndDate;
    }

    public void setRewardAllowanceEndDate(Date rewardAllowanceEndDate) {
        this.rewardAllowanceEndDate = rewardAllowanceEndDate;
    }

    public Integer getRewardAllowanceStatus() {
        return rewardAllowanceStatus;
    }

    public void setRewardAllowanceStatus(Integer rewardAllowanceStatus) {
        this.rewardAllowanceStatus = rewardAllowanceStatus;
    }

    public String getOrgUuid() {
        return orgUuid;
    }

    public void setOrgUuid(String orgUuid) {
        this.orgUuid = orgUuid;
    }

    public String getOrgPath() {
        return orgPath;
    }

    public void setOrgPath(String orgPath) {
        this.orgPath = orgPath;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getUserMobile() {
        return userMobile;
    }

    public void setUserMobile(String userMobile) {
        this.userMobile = userMobile;
    }

    public String getUserRealName() {
        return userRealName;
    }

    public void setUserRealName(String userRealName) {
        this.userRealName = userRealName;
    }

    public String getUserIdCardNo() {
        return userIdCardNo;
    }

    public void setUserIdCardNo(String userIdCardNo) {
        this.userIdCardNo = userIdCardNo;
    }

    public Integer getRewardCount() {
        return rewardCount;
    }

    public void setRewardCount(Integer rewardCount) {
        this.rewardCount = rewardCount;
    }

    public BigDecimal getRewardAmount() {
        return rewardAmount;
    }

    public void setRewardAmount(BigDecimal rewardAmount) {
        this.rewardAmount = rewardAmount;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getCheckTime() {
        return checkTime;
    }

    public void setCheckTime(Date checkTime) {
        this.checkTime = checkTime;
    }

    public Date getClearTime() {
        return clearTime;
    }

    public void setClearTime(Date clearTime) {
        this.clearTime = clearTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public String getCheckUser() {
        return checkUser;
    }

    public void setCheckUser(String checkUser) {
        this.checkUser = checkUser;
    }

    public String getClearUser() {
        return clearUser;
    }

    public void setClearUser(String clearUser) {
        this.clearUser = clearUser;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getRewardAllowanceBatchCode() {
        return rewardAllowanceBatchCode;
    }

    public void setRewardAllowanceBatchCode(String rewardAllowanceBatchCode) {
        this.rewardAllowanceBatchCode = rewardAllowanceBatchCode;
    }
}