package cn.zjhf.kingold.trade.constant;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.utils.DataUtils;

/**
 * Created by liuyao on 2017/7/11.
 */
public enum  MarketCampaignCodeEnum {
    UNDEFINED(-1, "未定义场景"),

    REGISTER(1, "注册"),
    USER_AUTH(2, "实名"),
    FIRST_BIND_CARD(3, "首次绑卡"),
    FIRST_RECHARGE(4, "首次充值"),
    FIRST_INVEST(5, "首次投资"),

    FRIEND_FIRST_INVEST(6, "邀请好友首次投资"),
    REPEATED_INVESTMENT(7,"复投"),
    BEING_INVITED_REGISTER(8,"邀请好友注册"),
    SHARE(9,"分享"),
    EVERYDAY_SIGN(10,"签到"),

    INVITE_FRIEND_REAL_NAME(11,"邀请好友实名"),
    INVITE_FRIEND_FIRST_BIND_CARD(12,"邀请好友首次绑卡"),
    FRIEND_INVEST(13,"邀友投资"),
    SELF_INVEST(14,"自己投资"),

    SPRING_CAMPAIGN_SEND_PER_ONE_COUPON(20,"春节活动送1%加息券"),

    FIXED_PRODUCT_END(21,"产品到期"),

    SPECIFIED_DISTRIBUTION(99,"指定发放"),
    COIN_EXCHANGE(100,"金币兑换");

    private Integer code;
    private String msg;

    MarketCampaignCodeEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public static boolean onlyOneFreq(int applyScene) {
        return DataUtils.isContain(applyScene, REGISTER.getCode(), USER_AUTH.getCode(), FIRST_BIND_CARD.getCode(),
                FIRST_RECHARGE.getCode(), FIRST_INVEST.getCode(), REPEATED_INVESTMENT.getCode());
    }

    public static boolean isInvited(int applyScene) {
        return DataUtils.isContain(applyScene, FRIEND_FIRST_INVEST.getCode(), BEING_INVITED_REGISTER.getCode(),
                INVITE_FRIEND_REAL_NAME.getCode(), INVITE_FRIEND_FIRST_BIND_CARD.getCode());
    }

    public static MarketCampaignCodeEnum getCampaignCodeEnum(Integer code) throws BusinessException {
        for (MarketCampaignCodeEnum paramEnum: MarketCampaignCodeEnum.values()) {
            if(paramEnum.getCode().equals(code)) {
                return paramEnum;
            }
        }
        throw new BusinessException(-1, "no enum match");
    }

    /**
     * 获取场景名称
     * @param code 场景代码
     * @return
     */
    public static String getMarketCampaignName(Integer code) {
        for (MarketCampaignCodeEnum paramEnum: MarketCampaignCodeEnum.values()) {
            if(paramEnum.getCode().equals(code)) {
                return paramEnum.getMsg();
            }
        }

        return UNDEFINED.getMsg();
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
