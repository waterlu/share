package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.rocketmq.base.SimpleMessage;
import cn.zjhf.kingold.trade.constant.*;
import cn.zjhf.kingold.trade.entity.*;
import cn.zjhf.kingold.trade.entity.InVO.LstProductExpireCashItemsVO;
import cn.zjhf.kingold.trade.entity.InVO.LstProductExpireCashVO;
import cn.zjhf.kingold.trade.entity.OutVO.*;
import cn.zjhf.kingold.trade.persistence.mq.producer.ProductExpireProducer;
import cn.zjhf.kingold.trade.service.IMarketCampaignService;
import cn.zjhf.kingold.trade.service.IProductEndService;
import cn.zjhf.kingold.trade.utils.*;
import cn.zjhf.kingold.trade.utils.AmountUtils;
import cn.zjhf.kingold.trade.utils.DataUtils;
import cn.zjhf.kingold.trade.utils.StringOrDate;
import cn.zjhf.kingold.trade.utils.WhereCondition;
import cn.zjhf.kingold.trade.vo.LoanCashedDetailVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.SetOperations;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * Created by zhangyijie on 2017/5/19.
 */
@Service
public class ProductEndServiceImpl extends ProductClearBase implements IProductEndService {
    protected static final Logger logger = LoggerFactory.getLogger(ProductEndServiceImpl.class);

    @Autowired
    ProductEstablishServiceImpl productEstablishService;

    @Autowired
    IMarketCampaignService marketCampaignService;

    @Autowired
    private ProductExpireProducer productExpireProducer;

    @Value("${product.oldproduct.productuuid}")
    public String oldproductuuid;

    //产品到期短信名单
    public static String FIXEDPRODUCT_END_CASHCOUPON_MESS_PHONENUMERLIST_KEY = "fixedproduct_end_cashcoupon_sms:phonenumberlist";

    //增补放款(募集汇总)的其他信息
    private TradePaymentSummaryExVO getTradePaymentSummaryExVO(TradePaymentSummary tradePaymentSummary) throws BusinessException {
        TradePaymentSummaryExVO tradePaymentSummaryExVO = new TradePaymentSummaryExVO(tradePaymentSummary);

        //完善其他数据
        ProductFixedIncome productInfo = getFixedIncomeProductById(tradePaymentSummary.getProductUuid());
        tradePaymentSummaryExVO.setProductPeriod(productInfo.getProductPeriod());
        tradePaymentSummaryExVO.setProductScale(productInfo.getProductScale().doubleValue());

        return tradePaymentSummaryExVO;
    }

    private TradePaymentSummary lstTradePaymentSummaryByProduct(String productUUId) {
        WhereCondition condition = new WhereCondition();
        condition.setCondi("product_uuid", productUUId);
        condition.noDelete();
        condition.setOrderByDesc("trade_payment_summary_uuid");
        List<TradePaymentSummary> items = tradePaymentSummaryMapper.lstByCondition(condition);
        return items.size() > 0 ? items.get(0) : null;
    }

    /**
     * Step1 产品到期
     * @param createBy 操作人
     * @return
     * @throws BusinessException
     */
    //@Override
    @Transactional(rollbackFor = Exception.class)
    public void fixedProductEnd(String productUUId, String createBy) throws BusinessException {
        //检查是否已经放款
        logger.info("Step1 检查是否已经放款结束");
        if(!productEstablishService.isLoan(productUUId)) {
            throw new BusinessException(TradeStatusMsg.PRODUCT_ISLOAN_ERR, TradeStatusMsg.PRODUCT_ISLOAN_ERR_MSG, true);
        }

        //如果已经成立过，则直接返回
        if(lstTradePaymentSummaryByProduct(productUUId) != null) {
            return;
        }

        //Step1 检查产品信息：到期日、状态等
        logger.info("Step2 检查产品信息：到期日、状态等");
        ProductFixedIncome productInfo = getFixedIncomeProductById(productUUId);
        //Step1.1 检查状态
        if(productInfo.getProductStatus() != BizDefine.PRODUCT_STATUS_INTEREST) {
            throw new BusinessException(TradeStatusMsg.PRODUCT_STATUS_ERR, TradeStatusMsg.PRODUCT_STATUS_ERR_MSG, true);
        }

        //Step1.2 检查到期日
        //if(!baseService.dateCheck(productInfo.getProductExpiringDate())) {
            //throw new BusinessException(TradeStatusMsg.PRODUCT_DATE_ERR, TradeStatusMsg.PRODUCT_DATE_ERR_MSG, true);
        //}

        //Step3 填充产品信息
        logger.info("Step3 填充产品信息");
        TradePaymentSummaryVO tradePaymentSummaryVO = new TradePaymentSummaryVO();
        tradePaymentSummaryVO.setProductUuid(productUUId);
        tradePaymentSummaryVO.setProductCode(productInfo.getProductCode());
        tradePaymentSummaryVO.setProductType(productInfo.getProductType());
        tradePaymentSummaryVO.setProductAbbrName(productInfo.getProductAbbrName());
        tradePaymentSummaryVO.setProductPeriod(productInfo.getProductPeriod());

        //Step4 汇总产品的交易信息
        logger.info("Step4 汇总产品的交易信息");
        WhereCondition condition = new WhereCondition();
        condition.setCondi("product_uuid", productUUId);
        condition.setCondi("order_status", BizDefine.ORDER_STATUS_PRODUCT_INTEREST);
        condition.noDelete();
        condition.setOrderByAsc("payed_time");

        Set<String> userIds = new HashSet<String>();
        List<String> userUuidList = new ArrayList<>();
        Map<String, String> uuidPhoneNumMap = new HashMap<>();
        List<TradeOrder> orderList = lstTradeOrdersByCondition(condition);
        for(TradeOrder tradeOrder : orderList) {
            userIds.add(tradeOrder.getUserUuid());

            if(DataUtils.isNotEmpty(tradeOrder.getUserUuid())) {
                userUuidList.add(tradeOrder.getUserUuid());
                uuidPhoneNumMap.put(tradeOrder.getUserUuid(), tradeOrder.getUserPhone());
            }

            //本金
            double raiseAmt = tradeOrder.getOrderAmount().doubleValue();
            tradePaymentSummaryVO.setClearPrincAmount(tradePaymentSummaryVO.getClearPrincAmount() + raiseAmt);

            //收益
            double profitAmount = tradeOrder.getExpectedProfitAmount().subtract(tradeOrder.getMarketingRateAmount()).doubleValue();
            tradePaymentSummaryVO.setClearProfitAmount(tradePaymentSummaryVO.getClearProfitAmount() + profitAmount);

            //营销加息
            double maketAmount = tradeOrder.getMarketingRateAmount().doubleValue();
            tradePaymentSummaryVO.setMarketingRateAmount(tradePaymentSummaryVO.getMarketingRateAmount() + maketAmount);

            //兑付总金额
            double cashAmount = raiseAmt + profitAmount + maketAmount;
            logger.info("raiseAmt:" + raiseAmt + ", profitAmount:" + profitAmount + ", maketAmount:" + maketAmount);
            tradePaymentSummaryVO.setClearTotalAmount(tradePaymentSummaryVO.getClearTotalAmount() + cashAmount);

            tradeOrderMapper.updateProductEndAmount(tradeOrder.getOrderBillCode(), cashAmount);
        }
        //有效投资用户
        tradePaymentSummaryVO.setClearCount(userIds.size());

        //Step5 填充出入账户信息
        logger.info("Step5 填充出账户信息");
        //融资人托管账户
        String productIssuerUuid = productInfo.getProductIssuerUuid();
        Account outClearAccount = getAccountByUserUuid(BizDefine.ACCOUNT_TYPE_ZJ_FINANCIER_DEPOSIT, productIssuerUuid);
        checkAccount(outClearAccount);
        tradePaymentSummaryVO.setOutClearAccountNo(outClearAccount.getAccountUuid());
        tradePaymentSummaryVO.setOutClearAccountUuid(outClearAccount.getAccountUuid());
        tradePaymentSummaryVO.setOutClearUserUuid(outClearAccount.getUserUuid());

        //平台结算账户
        Account outMaketRateAccount = getAccountByType(BizDefine.ACCOUNT_TYPE_ZJ_CLEAR);
        checkAccount(outMaketRateAccount);
        tradePaymentSummaryVO.setOutMarketingRateAccountNo(outMaketRateAccount.getAccountUuid());
        tradePaymentSummaryVO.setOutMarketingRateAccountUuid(outMaketRateAccount.getAccountUuid());
        tradePaymentSummaryVO.setOutMarketingRateUserUuid(outMaketRateAccount.getUserUuid());

        //Step6 填充创建和更新信息
        logger.info("Step6 填充创建和更新信息");
        Date curTime = new Date();
        tradePaymentSummaryVO.setCreateTime(curTime);
        tradePaymentSummaryVO.setUpdateTime(curTime);
        tradePaymentSummaryVO.setTransactionStatus(BizDefine.WORKFLOW_STATUS_CREATE);

        //Step7 添加兑付汇总信息
        logger.info("Step7 添加兑付汇总信息");
        TradePaymentSummary tradePaymentSummary = tradePaymentSummaryVO.get();
        tradePaymentSummary.setBatchNo(generateBatchNo(TradeType.TRADE_PROFIT_PAYMENT));
        tradePaymentSummaryMapper.insert(tradePaymentSummary);

        //Step8 更新交易状态
        logger.info("Step8 更新交易状态为 已到期");
        tradeOrderMapper.updateStatus(productUUId, BizDefine.ORDER_STATUS_PRODUCT_END, BizDefine.ORDER_STATUS_PRODUCT_INTEREST);

        //Step9 更新产品状态
        logger.info("Step9 更新产品状态为 已到期");
        updateProductStatus(productUUId, BizDefine.PRODUCT_STATUS_PRODUCTEND, createBy, null);

        //Step10 发放产品到期场景礼券
        List<String> succPhoneNum = marketCampaignService.marketCampaignTrigger(MarketCampaignCodeEnum
                .FIXED_PRODUCT_END.getCode(), orderList, uuidPhoneNumMap);

        //Step11 发送短信
        //addCashCouponMess(succPhoneNum);
    }

    /**
     * 将产品到期发放礼券的用户手机号放入redis
     * @param phoneNumList
     * @throws BusinessException
     */
    @Override
    public void addCashCouponMess(List<String> phoneNumList) throws BusinessException {
        SetOperations<String, String> opsForSet = stringRedisTemplate.opsForSet();
        opsForSet.add(FIXEDPRODUCT_END_CASHCOUPON_MESS_PHONENUMERLIST_KEY, (String[])(phoneNumList.toArray(new String[phoneNumList.size()])));
    }

    /**
     * Step11 产品到期
     * @param productUUId 产品ID
     * @param createBy 操作人
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void privateProductEnd(String productUUId, String createBy) throws BusinessException {
        int productStatus = getProductStatus(productUUId, ProductType.PRODUCT_PF);
        statusCheck(productStatus, BizDefine.PRODUCT_PRIVATE_STATUS_DURATION);
        updateProductStatus(productUUId, BizDefine.PRODUCT_PRIVATE_STATUS_PRODUCTEND, createBy, null);
        return;
    }

    /**
     * Step2 产品到期_兑付查询(维度:产品，列表)
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public TradePaymentSummaryListVO lstProductExpireCash(LstProductExpireCashVO lstProductExpireCashVO) throws BusinessException {
        TradePaymentSummaryListVO tradeInvestSummaryListVO = new TradePaymentSummaryListVO();

        WhereCondition condition = new WhereCondition();
        condition.setCondi("trade_payment_summary_uuid", lstProductExpireCashVO.getApplyUUId(), true);
        condition.setLike("product_abbr_name", lstProductExpireCashVO.getProductName());
        if(0 != lstProductExpireCashVO.getTransStatus()){
            condition.setCondi("transaction_status", lstProductExpireCashVO.getTransStatus());
        }
        condition.setBetween("create_time", lstProductExpireCashVO.getBeginDate(), lstProductExpireCashVO.getEndDate());
        condition.noDelete();
        tradeInvestSummaryListVO.setTotalCount(tradePaymentSummaryMapper.lstCountByCondition(condition));

        condition.setPage(lstProductExpireCashVO.getBeginSN(), lstProductExpireCashVO.getEndSN(), "trade_payment_summary_uuid");
        List<TradePaymentSummary> items = tradePaymentSummaryMapper.lstByCondition(condition);

        List<TradePaymentSummaryVO> VOItems = new ArrayList<TradePaymentSummaryVO>();
        for(TradePaymentSummary tradePaymentSummary : items) {
            VOItems.add(new TradePaymentSummaryVO(tradePaymentSummary));
        }
        tradeInvestSummaryListVO.setItems(VOItems);

        return tradeInvestSummaryListVO;
    }

    /**
     * Step3 产品到期_兑付详情(维度:产品，单记录)
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public TradePaymentSummaryExVO getProductExpireCashDetail(String productUuid) throws BusinessException {
        TradePaymentSummary tradePaymentSummary = lstTradePaymentSummaryByProduct(productUuid);
        if(tradePaymentSummary == null) {
            throw new BusinessException(TradeStatusMsg.SYSTEM_BIZ_ERR, TradeStatusMsg.SYSTEM_BIZ_ERR_MSG, false);
        }
        return getTradePaymentSummaryExVO(tradePaymentSummary);
    }

    /**
     * Step4 产品到期_兑付明细(维度:产品-交易，列表)
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public  CommItemListVO<LoanCashedDetailVO> lstProductExpireCashItems(LstProductExpireCashItemsVO param) throws BusinessException {
        Integer count = 0;
        List<LoanCashedDetailVO> list = new ArrayList<LoanCashedDetailVO>();
        //已指定了状态，并且与还款状态不一致，则返回空记录
//        if(param.getStatus() > 0) {
//            TradePaymentSummary tradePaymentSummary = lstTradePaymentSummaryByProduct(param.getProductUuid());
//            if (tradePaymentSummary.getTransactionStatus() != param.getStatus()) {
//                return new CommItemListVO<LoanCashedDetailVO>(count,list);
//            }
//        }
        WhereCondition condition = new WhereCondition();
        condition.setCondiEx(" trade.order_bill_code = trans.trade_order_bill_code AND trade.delete_flag = 0 ");
        condition.setInInt("trade.order_status",  BizDefine.ORDER_STATUS_PRODUCT_END, BizDefine.ORDER_STATUS_CLEAR);
        condition.setCondi("trans.trade_type",  TradeType.TRADE_INVEST);
        condition.setCondi("trans.account_type", AccountType.ACCOUNT_TYPE_INVESTOR);
        condition.setCondi("trade.product_uuid", param.getProductUuid(), true);
        condition.setCondi("trade.user_phone", param.getUserPhone(), true);
        condition.setBetween("trade.clear_time", param.getBeginDate(), param.getEndDate());
        if(DataUtils.isNotEmpty(param.getOrderNo())){
            condition.setCondiEx(" AND (trade.order_bill_code = '"+param.getOrderNo()+"' OR trans.trade_order_bill_code_extend = '"+param.getOrderNo() + "' )");
        }
        count=tradeOrderMapper.getLoanCashedDetailCount(condition);
        condition.setPage(param.getBeginSN(), param.getEndSN(), "trade.order_bill_code");
        list = tradeOrderMapper.getLoanCashedDetail(condition);
        for(LoanCashedDetailVO vo:list){
            if(DataUtils.isNotEmpty(vo.getTradeOrderBillCodeExtend())){
                vo.setOrderBillCode(vo.getTradeOrderBillCodeExtend());
            }
            vo.setProfitAmount(vo.getExpectedProfitAmount().subtract(vo.getMarketingRateAmount()));
            vo.setPartyRaisedReturnTotalAmount(vo.getOrderAmount().add(vo.getProfitAmount()));
        }
        return new CommItemListVO<LoanCashedDetailVO>(count,list);
    }

    /**
     * Step5 产品到期_兑付_审核
     * isAudited 1审核通过  0审核未通过
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean productExpireCashAudit(String userPhone, String productUUId, int isAudited, String message) throws BusinessException {
        TradePaymentSummary tradePaymentSummary = lstTradePaymentSummaryByProduct(productUUId);

        bizCheck(tradePaymentSummary);
        statusCheck(tradePaymentSummary.getTransactionStatus(), BizDefine.WORKFLOW_STATUS_AUDIT_FAIL, BizDefine.WORKFLOW_STATUS_CREATE);

        tradePaymentSummary.setAuditOperator(userPhone);
        tradePaymentSummary.setAuditTime(new Date());

        if(isAudited > 0) {
            //审核通过
            tradePaymentSummary.setTransactionStatus(BizDefine.WORKFLOW_STATUS_AUDITED);
        }else {
            //审核不通过
            tradePaymentSummary.setTransactionStatus(BizDefine.WORKFLOW_STATUS_AUDIT_FAIL);
            tradePaymentSummary.setAuditOpinion(message);
        }

        return (tradePaymentSummaryMapper.updateByPrimaryKey(tradePaymentSummary) > 0);
    }

    //添加资金流水
    private String insertAccountTransaction(String orderCode, Account outAccount, Account inAccount, double amount, String type, String tradeOrderUuid, String transactionChannel) throws BusinessException {
        //Step1 记录账户流水
        String sn = insertAccountTransactionEx(orderCode, outAccount, inAccount, amount, type, tradeOrderUuid, transactionChannel);

        //Step2 记录账户流水
        insertAccountTransactionEx(orderCode, inAccount, outAccount, amount, type, tradeOrderUuid, transactionChannel);

        return sn;
    }

    /**
     * 本金和收益兑付
     * @return
     * @throws BusinessException
     */
    private void transCashAmtsEx(ProductFixedIncome productInfo, String orderNo, String outAccountUuid, double amount) throws BusinessException {
        Account outAccount = getAccountByAccountUuid(outAccountUuid);

        //Step1 检查融资人托管账户中资金是否充足，不得少于 本金+收益
        logger.info("还款Step1，检查融资人托管账户中资金是否充足，不得少于 本金+收益");
        if(outAccount.getAccountCashAmount().doubleValue() < amount) {
            throw new BusinessException(TradeStatusMsg.FINANCIER_ACCOUNT_LESS_BALANCE, TradeStatusMsg.FINANCIER_ACCOUNT_LESS_BALANCE_MSG, false);
        }

        //Step2 汇总每一笔交易的还款金额
        logger.info("还款Step2，汇总每一笔交易的还款金额");
        List<Payee> payees = new ArrayList<Payee>();
        WhereCondition condition = new WhereCondition();
        condition.setCondi("product_uuid", productInfo.getProductUuid());
        condition.setCondi("order_status", BizDefine.ORDER_STATUS_CLEAR);
        condition.noDelete();
        for(TradeOrder tradeOrder : lstTradeOrdersByCondition(condition)) {
            Account account = getAccountByAccountUuid(tradeOrder.getAccountUuid());
            if(account != null) {
                double cashAmount = tradeOrder.getOrderAmount().doubleValue() + tradeOrder.getExpectedProfitAmount().doubleValue();
                cashAmount = AmountUtils.normal(cashAmount);

                if(cashAmount > 0) {
                    payees.add(new Payee(account.getAccountNo(), cashAmount, 0));
                }
            }
        }

        //Step3 维护账户 调减融资人托管账户的可用资金
        logger.info("还款Step3，维护账户 调减融资人托管账户的可用资金");
        logger.info(outAccountUuid + " " + amount);
        accountMapper.reduceCashAmount(outAccountUuid, amount);

        //Step4 记录资金流水信息
        logger.info("还款Step4，记录资金流水，每一笔都拆分本金和收益");
        condition = new WhereCondition();
        condition.setCondi("product_uuid", productInfo.getProductUuid());
        condition.setCondi("order_status", BizDefine.ORDER_STATUS_CLEAR);
        condition.noDelete();
        for(TradeOrder tradeOrder : lstTradeOrdersByCondition(condition)) {
            Account account = getAccountByAccountUuid(tradeOrder.getAccountUuid());

            //Step3 添加资金流水
            //收益处理
            insertAccountTransaction(orderNo, outAccount, account, tradeOrder.getOrderAmount().doubleValue(), TradeType.TRADE_PRINCIPAL_PAYMENT, tradeOrder.getOrderBillCode(), tradeOrder.getTransactionChannel());

            //本金处理
            insertAccountTransaction(orderNo, outAccount, account, tradeOrder.getExpectedProfitAmount().doubleValue(), TradeType.TRADE_PROFIT_PAYMENT, tradeOrder.getOrderBillCode(), tradeOrder.getTransactionChannel());
        }

        if(payees.size() > 0) {
            try {
                logger.info("还款Step5，实际调用宝付的接口做还款处理");
                //orderNo 资金流水的ID
                logger.info("payService.repay orderNo:" + orderNo + ", productID:" + productInfo.getProductID() + ", productName:" + productInfo.getProductName() + ", borrowUserID:" + outAccount.getAccountNo() + ", payees:" + payees.toString());
                ResponseResult responseResult = payService.repay(orderNo, productInfo.getProductID(), productInfo.getProductName(), outAccount.getAccountNo(), payees);
                logger.info(DataUtils.toString(responseResult));

                if ((responseResult == null) || (responseResult.getCode() != TradeError.OK)) {
                    throw new BusinessException(TradeStatusMsg.PRODUCT_PAYMENT_FAIL, TradeStatusMsg.PRODUCT_PAYMENT_FAIL_MSG, false);
                }
            } catch (BusinessException e) {
                logger.error("宝付还款异常", e);
                throw (e);
            }
        }else {
            logger.error("还款Step5，没有有效的还款信息");
        }
    }

    /**
     * 本金和收益兑付
     * @return
     * @throws BusinessException
     */
    private void transCashAmts(ProductFixedIncome productInfo, String orderNo, String outAccountUuid, double amount) throws BusinessException {
        Account outAccount = getAccountByAccountUuid(outAccountUuid);

        //Step1 检查融资人托管账户中资金是否充足，不得少于 本金+收益
        logger.info("还款Step1，检查融资人托管账户中资金是否充足，不得少于 本金+收益");
        if(outAccount.getAccountCashAmount().doubleValue() < amount) {
            throw new BusinessException(TradeStatusMsg.FINANCIER_ACCOUNT_LESS_BALANCE, TradeStatusMsg.FINANCIER_ACCOUNT_LESS_BALANCE_MSG, false);
        }

        //Step2 汇总每一笔交易的还款金额
        logger.info("还款Step2，汇总每一笔交易的还款金额");
        List<Payee> payees = new ArrayList<Payee>();
        WhereCondition condition = new WhereCondition();
        condition.setCondi("product_uuid", productInfo.getProductUuid());
        condition.setCondi("order_status", BizDefine.ORDER_STATUS_CLEAR);
        condition.noDelete();
        for(TradeOrder tradeOrder : lstTradeOrdersByCondition(condition)) {
            Account account = getAccountByAccountUuid(tradeOrder.getAccountUuid());
            if(account != null) {
                double cashAmount = tradeOrder.getOrderAmount().doubleValue() + tradeOrder.getProfitAmount().doubleValue();
                cashAmount = AmountUtils.normal(cashAmount);

                if(cashAmount > 0) {
                    payees.add(new Payee(account.getAccountNo(), cashAmount, 0));
                }
            }
        }

        //Step3 维护账户 调减融资人托管账户的可用资金
        logger.info("还款Step3，维护账户 调减融资人托管账户的可用资金");
        logger.info(outAccountUuid + " " + amount);
        accountMapper.reduceCashAmount(outAccountUuid, amount);

        //Step4 记录资金流水信息
        logger.info("还款Step4，记录资金流水，每一笔都拆分本金和收益");
        condition = new WhereCondition();
        condition.setCondi("product_uuid", productInfo.getProductUuid());
        condition.setCondi("order_status", BizDefine.ORDER_STATUS_CLEAR);
        condition.noDelete();
        for(TradeOrder tradeOrder : lstTradeOrdersByCondition(condition)) {
            Account account = getAccountByAccountUuid(tradeOrder.getAccountUuid());

            //Step3 添加资金流水
            //本金处理
            insertAccountTransaction(orderNo, outAccount, account, tradeOrder.getOrderAmount().doubleValue(), TradeType.TRADE_PRINCIPAL_PAYMENT, tradeOrder.getOrderBillCode(), tradeOrder.getTransactionChannel());

            //收益处理
            insertAccountTransaction(orderNo, outAccount, account, tradeOrder.getProfitAmount().doubleValue(), TradeType.TRADE_PROFIT_PAYMENT, tradeOrder.getOrderBillCode(), tradeOrder.getTransactionChannel());
        }

        if(payees.size() > 0) {
            try {
                logger.info("还款Step5，实际调用宝付的接口做还款处理");
                //orderNo 资金流水的ID
                logger.info("payService.repay orderNo:" + orderNo + ", productID:" + productInfo.getProductID() + ", productName:" + productInfo.getProductName() + ", borrowUserID:" + outAccount.getAccountNo() + ", payees:" + payees.toString());
                ResponseResult responseResult = payService.repay(orderNo, productInfo.getProductID(), productInfo.getProductName(), outAccount.getAccountNo(), payees);
                logger.info(DataUtils.toString(responseResult));

                if ((responseResult == null) || (responseResult.getCode() != TradeError.OK)) {
                    throw new BusinessException(TradeStatusMsg.PRODUCT_PAYMENT_FAIL, TradeStatusMsg.PRODUCT_PAYMENT_FAIL_MSG, false);
                }
            } catch (BusinessException e) {
                logger.error("宝付还款异常", e);
                throw (e);
            }
        }else {
            logger.error("还款Step5，没有有效的还款信息");
        }
    }

    /**
     * 营销加息兑付
     * @return
     * @throws BusinessException
     */
    private void transMarketRateAmts(ProductFixedIncome productInfo, String outAccountUuid, double amount) throws BusinessException {
        Account outAccount = getAccountByAccountUuid(outAccountUuid);

        //Step1 检查平台基本账户中资金是否充足，不得少于 给投资者的营销加息
        logger.info("还款Step1，检查平台基本账户中资金是否充足，不得少于 给投资者的营销加息");
        if(outAccount.getAccountCashAmount().doubleValue() < amount) {
            throw new BusinessException(TradeStatusMsg.CLEAR_ACCOUNT_LESS_BALANCE, TradeStatusMsg.CLEAR_ACCOUNT_LESS_BALANCE_MSG, false);
        }

        //Step2 汇总每一笔交易的还款金额
        logger.info("还款Step2，汇总加息数据，记录交易流水");
        List<Payee> payees = new ArrayList<Payee>();
        WhereCondition condition = new WhereCondition();
        condition.setCondi("product_uuid", productInfo.getProductUuid());
        condition.setCondi("order_status", BizDefine.ORDER_STATUS_CLEAR);
        condition.noDelete();
        for(TradeOrder tradeOrder : lstTradeOrdersByCondition(condition)) {
            Account account = getAccountByAccountUuid(tradeOrder.getAccountUuid());
            if(account != null) {
                double marketRateAmt = tradeOrder.getMarketingRateAmount().doubleValue();
                marketRateAmt = AmountUtils.normal(marketRateAmt);

                if(marketRateAmt > 0) {
                    String orderNo = generateBatchNo(TradeType.TRADE_ADDED_INTEREST);

                    //整理营销加息数据
                    payees.add(new Payee(account.getAccountNo(), marketRateAmt, 0, orderNo));

                    //记录资金流水，平台返还营销加息
                    insertAccountTransaction(orderNo, outAccount, account, tradeOrder.getMarketingRateAmount().doubleValue(), TradeType.TRADE_ADDED_INTEREST, tradeOrder.getOrderBillCode(), tradeOrder.getTransactionChannel());
                }
            }
        }

        if(payees.size() <= 0) {
            logger.info("没有有效的加息数据需要处理");
            return;
        }

        //Step3 维护账户 调减平台结算账户的可用资金
        logger.info("还款Step3，维护账户 调减平台结算账户的可用资金");
        logger.info(outAccountUuid + " " + amount);
        accountMapper.reduceCashAmount(outAccountUuid, amount);

        logger.info("还款Step4，实际调用宝付的接口做 营销加息 兑付处理");
        for(Payee payee : payees) {
            try {
                logger.info(payee.toString());
                ResponseResult responseResult = payService.transferP2C(payee.getOrderNo(), payee.getUserId(), payee.getAmount());
                logger.info((responseResult != null) ? responseResult.toString() : "null");

                if ((responseResult == null) || (responseResult.getCode() != TradeError.OK)) {
                    throw new BusinessException(TradeStatusMsg.COUPON_LOAN_FAIL, TradeStatusMsg.COUPON_LOAN_FAIL_MSG, false);
                }
            } catch (BusinessException e) {
                logger.error("营销加息兑付，宝付转账异常", e);
                throw (e);
            }
        }
    }

    //更新投资者账户和交易相关信息
    private void updateInvestorInfo(String productUUId) {
        //Step1 更新投资者账户信息
        WhereCondition condition = new WhereCondition();
        condition.setCondi("product_uuid", productUUId);
        condition.setCondi("order_status", BizDefine.ORDER_STATUS_PRODUCT_END);
        condition.noDelete();
        for(TradeOrder tradeOrder : lstTradeOrdersByCondition(condition)) {
            double raiseAmt = tradeOrder.getOrderAmount().doubleValue();
            double profitAmount = tradeOrder.getExpectedProfitAmount().doubleValue() - tradeOrder.getMarketingRateAmount().doubleValue();
            double maketAmount = tradeOrder.getMarketingRateAmount().doubleValue();
            String accountUuid = tradeOrder.getAccountUuid();

            logger.info("updateInvestorInfo  accountUuid:" + accountUuid + ", raiseAmt:" + raiseAmt + ", profitAmount:" + profitAmount + ", maketAmount:" + maketAmount);
            accountMapper.investorProductEnd(accountUuid, raiseAmt, profitAmount, maketAmount);
        }
    }

    /**
     * Step6 产品到期_兑付_清算
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public TradePaymentSummaryExVO productExpireCashClear(String userPhone, String productUUId, String createBy) throws BusinessException {
        logger.info("Step0 加锁处理, 该产品的到期兑付在运行中，则返回状态异常");
        if(checkKeyLock("productExpireCashClear_"+productUUId, 2)) {
            throw new BusinessException(TradeStatusMsg.WORKFLOW_STATUS_ERR, TradeStatusMsg.WORKFLOW_STATUS_ERR_MSG, false);
        }

        logger.info("Step1 兑付单和产品信息检查");
        TradePaymentSummary tradePaymentSummary = lstTradePaymentSummaryByProduct(productUUId);
        if(tradePaymentSummary == null) {
            throw new BusinessException(TradeStatusMsg.WORKFLOW_STATUS_ERR, TradeStatusMsg.WORKFLOW_STATUS_ERR_MSG, false);
        }

        ProductFixedIncome productInfo = getFixedIncomeProductById(tradePaymentSummary.getProductUuid());

        //Step2 检查是否已经审核通过
        logger.info("Step2 兑付单状态检查");
        if(BizDefine.WORKFLOW_STATUS_AUDITED == tradePaymentSummary.getTransactionStatus()) {
            logger.info("Step3 更新兑付单，兑付状态和日期、更换流水号");
            tradePaymentSummary.setTransactionStatus(BizDefine.WORKFLOW_STATUS_CLEAR);
            tradePaymentSummary.setPayedOperator(userPhone);
            tradePaymentSummary.setPayedTime(new Date());

            //更换流水号
            String newBatchNo = generateBatchNo(TradeType.TRADE_PROFIT_PAYMENT);
            tradePaymentSummary.setBatchNo(newBatchNo);

            //更新产品到期兑付汇总信息
            tradePaymentSummaryMapper.updateByPrimaryKey(tradePaymentSummary);

            //更新相应交易状态
            logger.info("Step4 更新投资者信息 调整账户信息");
            updateInvestorInfo(productUUId);

            logger.info("Step5 将相关交易状态变更为已清算");
            tradeOrderMapper.updateStatus(productUUId, BizDefine.ORDER_STATUS_CLEAR, BizDefine.ORDER_STATUS_PRODUCT_END);

            //Step7 检查募集方账户和平台结算账户余额是否充足
            logger.info("Step7 检查募集方账户和平台结算账户余额是否充足");
            logger.info("Step7.1，检查融资人托管账户中资金是否充足，不得少于 本金+收益");
            double cashAmount = tradePaymentSummary.getClearPrincAmount().doubleValue() + tradePaymentSummary.getClearProfitAmount().doubleValue();
            Account collectAccount = getAccountByAccountUuid(tradePaymentSummary.getOutClearAccountUuid());
            if(collectAccount.getAccountCashAmount().doubleValue() < cashAmount) {
                throw new BusinessException(TradeStatusMsg.FINANCIER_ACCOUNT_LESS_BALANCE, TradeStatusMsg.FINANCIER_ACCOUNT_LESS_BALANCE_MSG, false);
            }

            logger.info("Step7.2，检查平台基本账户中资金是否充足，不得少于 给投资者的产品和营销加息");
            double marketRateAmount = tradePaymentSummary.getMarketingRateAmount().doubleValue();
            Account outMaketRateAccount = getAccountByAccountUuid(tradePaymentSummary.getOutMarketingRateAccountUuid());
            if(outMaketRateAccount.getAccountCashAmount().doubleValue() < marketRateAmount) {
                throw new BusinessException(TradeStatusMsg.CLEAR_ACCOUNT_LESS_BALANCE, TradeStatusMsg.CLEAR_ACCOUNT_LESS_BALANCE_MSG, false);
            }

            //Step8 处理融资方给投资者转账(本金+收益)
            logger.info("Step8 处理融资方给投资者转账(本金+收益)");
            List<String> oldProductUuids = DataUtils.split(oldproductuuid, ",");
            logger.info("OldProductUuid: " + DataUtils.toString(oldProductUuids));
            if((oldProductUuids!=null) && (oldProductUuids.contains(productInfo.getProductUuid()))) {
                transCashAmtsEx(productInfo, tradePaymentSummary.getBatchNo(), tradePaymentSummary.getOutClearAccountUuid(), cashAmount);
            }else {
                transCashAmts(productInfo, tradePaymentSummary.getBatchNo(), tradePaymentSummary.getOutClearAccountUuid(), cashAmount);
            }

            logger.info("Step9 处理营销计息给投资者转账(产品加息+加息券加息)");
            transMarketRateAmts(productInfo, tradePaymentSummary.getOutMarketingRateAccountUuid(), marketRateAmount);

            //产品还款发送mq消息
            logger.info("Step10 产品还款发送mq消息");
            SimpleMessage message = new SimpleMessage();
            message.setData(productUUId);
            productExpireProducer.send(message);

            //Step6 更新产品状态
            logger.info("Step11 更新产品状态为 已清算");
            ProductCriticalDateVO productCriticalDate = new ProductCriticalDateVO();
            productCriticalDate.setRepaymentDate(StringOrDate.getCurDate());
            updateProductStatus(productUUId, BizDefine.PRODUCT_STATUS_CLEAR, createBy, productCriticalDate);

            TradePaymentSummaryExVO tradePaymentSummaryExVO = getTradePaymentSummaryExVO(tradePaymentSummary);
            return tradePaymentSummaryExVO;
        }else {
            throw new BusinessException(TradeStatusMsg.SYSTEM_BIZ_ERR, TradeStatusMsg.SYSTEM_BIZ_ERR_MSG, false);
        }
    }

    /**
     * 体验金产品，兑付收益
     * @param userUuid
     * @param profitAmt
     * @param transactionChannel
     * @param orderNo
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void experienceProfitPayment(String userUuid, double profitAmt, String transactionChannel, String orderNo) throws BusinessException {
        if(DataUtils.isEmpty(userUuid) || (profitAmt <= 0)) {
            return;
        }

        //Step1 修正金额
        logger.info("Step1 修正金额");
        profitAmt = AmountUtils.exac(profitAmt);

        //Step2 获取账户并检查平台结算账户余额
        logger.info("Step2 获取账户并检查平台结算账户余额");
        Account investorAccount = getAccountByUserUuid(BizDefine.ACCOUNT_TYPE_INVESTOR, userUuid);
        Account clearAccount = getAccountByType(BizDefine.ACCOUNT_TYPE_ZJ_CLEAR);
        if(clearAccount.getAccountCashAmount().doubleValue() < profitAmt) {
            throw new BusinessException(TradeStatusMsg.CLEAR_ACCOUNT_LESS_BALANCE, TradeStatusMsg.CLEAR_ACCOUNT_LESS_BALANCE_MSG, false);
        }

        //Step3 添加资金流水
        logger.info("Step3 添加资金流水");
        //String orderNo = generateBatchNo(TradeType.EXPERIENCE_PROFIT_PAYMENT);
        insertAccountTransaction(orderNo, clearAccount, investorAccount, profitAmt, TradeType.EXPERIENCE_PROFIT_PAYMENT, null, transactionChannel);

        //Step4 调整台账余额
        logger.info("Step4 调整台账余额");
        accountMapper.reduceCashAmount(clearAccount.getAccountUuid(), profitAmt);
        accountMapper.investorProductEnd(investorAccount.getAccountUuid(),0,profitAmt,0);

        //Step5 调用宝付的接口做实际划付
        logger.info("Step5 调用宝付的接口做实际划付");
        ResponseResult responseResult = payService.transferP2C(orderNo, investorAccount.getAccountNo(), profitAmt);
        logger.info(DataUtils.toString(responseResult));

        if((responseResult == null)||(responseResult.getCode() != TradeError.OK)) {
            throw new BusinessException(TradeStatusMsg.PRODUCT_PAYMENT_FAIL, TradeStatusMsg.PRODUCT_PAYMENT_FAIL_MSG, false);
        }
    }

    /**
     * 发送产品到期发放礼券的
     * @throws BusinessException
     */
    @Override
    public void sendCashCouponMess() throws BusinessException {
        SetOperations<String, String> opsForSet = stringRedisTemplate.opsForSet();
        Set<String> phoneNumSet = opsForSet.members(FIXEDPRODUCT_END_CASHCOUPON_MESS_PHONENUMERLIST_KEY);

        logger.info("phoneNumSet: {}", phoneNumSet);
        //发送短信
        //TODO

        //移除redis内的数据
        stringRedisTemplate.delete(FIXEDPRODUCT_END_CASHCOUPON_MESS_PHONENUMERLIST_KEY);
    }
}
