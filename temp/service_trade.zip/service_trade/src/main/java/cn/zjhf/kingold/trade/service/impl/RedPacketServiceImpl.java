package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.constant.BizDefine;
import cn.zjhf.kingold.trade.constant.TradeStatusMsg;
import cn.zjhf.kingold.trade.entity.CouponSpecifiedDistributionRecord;
import cn.zjhf.kingold.trade.entity.CouponSpecifiedDistributionRecordItem;
import cn.zjhf.kingold.trade.entity.InVO.CouponSpecifiedDistributionAuditVO;
import cn.zjhf.kingold.trade.entity.InVO.LstCouponSpecifiedDistributionConditionVO;
import cn.zjhf.kingold.trade.entity.InVO.LstCouponSpecifiedDistributionDetailConditionVO;
import cn.zjhf.kingold.trade.entity.InVO.LstRedPacketConditionVO;
import cn.zjhf.kingold.trade.entity.OutVO.*;
import cn.zjhf.kingold.trade.entity.RedPacketRecord;
import cn.zjhf.kingold.trade.persistence.dao.CouponSpecifiedDistributionRecordItemMapper;
import cn.zjhf.kingold.trade.persistence.dao.CouponSpecifiedDistributionRecordMapper;
import cn.zjhf.kingold.trade.persistence.dao.RedPacketRecordMapper;
import cn.zjhf.kingold.trade.persistence.mq.message.RedPacketAuditMessage;
import cn.zjhf.kingold.trade.persistence.mq.producer.RedPacketAuditProducer;
import cn.zjhf.kingold.trade.service.IAccountService;
import cn.zjhf.kingold.trade.service.IDrawRedPacketService;
import cn.zjhf.kingold.trade.service.IRedPacketService;
import cn.zjhf.kingold.trade.utils.DataUtils;
import cn.zjhf.kingold.trade.utils.File.FileUtils;
import cn.zjhf.kingold.trade.utils.QueryUtils;
import cn.zjhf.kingold.trade.utils.Tuple.TwoTuple;
import cn.zjhf.kingold.trade.utils.WhereCondition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.InputStream;
import java.math.BigDecimal;
import java.util.*;

/**
 * Created by zhangyijie on 2018/1/26.
 */
@Service
public class RedPacketServiceImpl extends ProductClearBase implements IRedPacketService {
    protected static final Logger logger = LoggerFactory.getLogger(RedPacketServiceImpl.class);

    @Autowired
    private IAccountService accountService;

    @Autowired
    protected CouponSpecifiedDistributionRecordMapper couponSpecifiedDistributionRecordMapper;

    @Autowired
    protected CouponSpecifiedDistributionRecordItemMapper couponSpecifiedDistributionRecordItemMapper;

    @Autowired
    protected RedPacketRecordMapper redPacketRecordMapper;

    @Autowired
    private IDrawRedPacketService drawRedPacketService;

    @Autowired
    private RedPacketAuditProducer redPacketAuditProducer;

    private final static String COUPON_SPECIFIED_DISTRIBUTION_RED_PACKET_KEY = "coupon_specified_distribution_redpacket_";

    /**
     * 指定发放类型，现金红包
     */
    private final static int SPECIFIED_TYPE_RED_PACKET = 2;

    /**
     * 领取状态_未领取(已发放)
     */
    public final static int UNDRAW_STATUS = 1;

    /**
     * 领取状态_已领取
     */
    public final static int DRAW_STATUS = 2;

    //间隔符
    static final String REGEXSTR = "\\|";

    /**
     * 运行最大耗时 2分钟
     */
    final int MAX_RUN_TIME = 2;

    final int MaxItemLen = 1000;

    /**
     * 设置指定发券的用户信息
     *
     * @param userList
     * @param auditId
     * @throws BusinessException
     */
    private void setUserInfoList(List<String> userList, Long auditId) throws BusinessException {
        WhereCondition where = new WhereCondition();
        where.setInString("investor_mobile", userList);
        where.noDelete();

        String sql = "SELECT " + auditId + ", user_uuid, investor_mobile, investor_real_name FROM kingold_user.investor ";
        sql += where.toString();
        sql = "INSERT INTO coupon_specified_distribution_record_item(audit_id, user_uuid, phone_number, phone_name) " + sql;

        int ret = couponSpecifiedDistributionRecordItemMapper.insertMultipleRecord(new QueryUtils(sql));
        if(ret <= 0) {
            throw new BusinessException(TradeStatusMsg.CASHCOUPON_SPECDIST_NOEXIST_ERR, TradeStatusMsg.CASHCOUPON_SPECDIST_NOEXIST_ERR_MSG);
        }
    }

    /**
     * 设置指定发券的用户信息
     *
     * @param userList
     * @param auditId
     * @throws BusinessException
     */
    private void setUserInfoListEx(List<String> userList, Long auditId) throws BusinessException {
        List<List<String>> listItems = DataUtils.splitList(userList, MaxItemLen, false);

        int pos = 0;
        for (List<String> listItem : listItems) {
            setUserInfoList(listItem, auditId);
            logger.info("setUserInfoList: " + (++pos) + " " + listItems.size());
        }
    }

    /**
     * 非注册用户列表
     * @param userPhoneList
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public List<String> getUnRegistUserphone(List<String> userPhoneList) throws BusinessException {
        List<String> unRegistUserphoneList = new ArrayList<String>();
        List<List<String>> listItems = DataUtils.splitList(userPhoneList, MaxItemLen, false);

        for (List<String> listItem : listItems) {
            WhereCondition where = new WhereCondition();
            where.setInString("investor_mobile", listItem);
            where.noDelete();
            String sql = "SELECT investor_mobile FROM kingold_user.investor " + where.toString();

            //注册的用户列表
            List<String> registUserphoneList = operationReportMapper.lstStrList(new QueryUtils(sql));

            if((registUserphoneList!=null) && (registUserphoneList.size()>0)) {
                for(String userPhone : listItem) {
                    if(!registUserphoneList.contains(userPhone)) {
                        unRegistUserphoneList.add(userPhone);
                    }
                }
            }else {
                unRegistUserphoneList.addAll(listItem);
            }
        }

        return unRegistUserphoneList;
    }

    /**
     * 添加指定发放礼券的记录
     * @param redPacketAmount
     * @param userList
     * @param operator
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean insertSpecifiedDistributionByExcel(BigDecimal redPacketAmount, String specifiedName, List<String> userList, String operator, InputStream input) throws BusinessException {
        String md5Str = FileUtils.getMd5ByFile(input);
        if(!checkKeyLock(COUPON_SPECIFIED_DISTRIBUTION_RED_PACKET_KEY + md5Str, MAX_RUN_TIME)) {
            return insertSpecifiedDistribution(redPacketAmount, specifiedName, userList, operator);
        }else {
            throw new BusinessException(TradeStatusMsg.SPECDIST_BATCH_REPEAT_ERR,
                    TradeStatusMsg.SPECDIST_BATCH_REPEAT_ERR_MSG, false);
        }
    }

    /**
     * 添加指定发放礼券的记录
     * @param redPacketAmount
     * @param userList
     * @param operator
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean insertSpecifiedDistributionByList(BigDecimal redPacketAmount, String specifiedName, List<String> userList, String operator) throws BusinessException {
        String md5Str = DataUtils.getMd5Str(userList);
        if(!checkKeyLock(COUPON_SPECIFIED_DISTRIBUTION_RED_PACKET_KEY + md5Str, MAX_RUN_TIME)) {
            return insertSpecifiedDistribution(redPacketAmount, specifiedName, userList, operator);
        }else {
            throw new BusinessException(TradeStatusMsg.SPECDIST_BATCH_REPEAT_ERR,
                    TradeStatusMsg.SPECDIST_BATCH_REPEAT_ERR_MSG, false);
        }
    }

    /**
     * 添加指定发放现金红包的记录
     * @param redPacketAmount
     * @param userPhoneList
     * @param operator
     * @throws BusinessException
     */
    private boolean insertSpecifiedDistribution(BigDecimal redPacketAmount, String specifiedName, List<String> userPhoneList, String operator) throws BusinessException {
        CouponSpecifiedDistributionRecord record = new CouponSpecifiedDistributionRecord();

        record.setSpecifiedName(specifiedName);
        record.setSpecifiedType(SPECIFIED_TYPE_RED_PACKET);
        record.setRedPacketAmount(redPacketAmount);

        record.setCcCodes("");
        record.setUserCount(userPhoneList.size());

        record.setAuditStatus(BizDefine.WORKFLOW_STATUS_CREATE);
        record.setDeleteFlag(new Byte("0"));

        operator = DataUtils.isNotEmpty(operator) ? operator : BizDefine.DEFAULT_OPERATOR;
        record.setCreatorUserid(operator);

        Date now = new Date();
        record.setCreateTime(now);
        record.setUpdateTime(now);

        int ret = couponSpecifiedDistributionRecordMapper.insert(record);
        if (ret > 0) {
            Long auditId = couponSpecifiedDistributionRecordMapper.lstLastAuditId();
            setUserInfoListEx(userPhoneList, auditId);
        }

        return ret > 0;
    }

    /**
     * 查询现金券指定发放记录
     * @param
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public CouponSpecifiedDistributionRecordItemListVO lstCouponSpecifiedDistributionRecord(LstCouponSpecifiedDistributionConditionVO lstCondition) throws BusinessException {
        CouponSpecifiedDistributionRecordItemListVO couponSpecifiedDistributionRecordList = new CouponSpecifiedDistributionRecordItemListVO();
        WhereCondition where = new WhereCondition();
        where.setCondi("audit_id", lstCondition.getAuditId(), true);
        where.setCondi("specified_type", SPECIFIED_TYPE_RED_PACKET);
        //where.setLike("cc_codes", lstCondition.getCcCode());
        if (lstCondition.getAuditStatus() != -1) {
            where.setCondi("audit_status", lstCondition.getAuditStatus(), true);
        } else if (lstCondition.getAuditStatus() == -1) {
            where.setCondi("audit_status", lstCondition.getAuditStatus());
        }
        where.setBetween("create_time", lstCondition.getBeginDate(), lstCondition.getEndDate());

        int totalCount = couponSpecifiedDistributionRecordMapper.lstCountByCondition(where);
        couponSpecifiedDistributionRecordList.setTotalCount(totalCount);

        where.setPage(lstCondition.getBeginSN(), lstCondition.getEndSN(), "create_time");
        List<CouponSpecifiedDistributionRecord> items = couponSpecifiedDistributionRecordMapper.lstByCondition(where);

        if(items != null && items.size() > 0) {
            for(CouponSpecifiedDistributionRecord item : items) {
                CouponSpecifiedDistributionRecordVO itemVO = new CouponSpecifiedDistributionRecordVO(item);

                int drawCount = redPacketRecordMapper.lstCountByAuditId(itemVO.getAuditId(), DRAW_STATUS);
                logger.info("DrawCount: " + drawCount);

                itemVO.setDrawCount(drawCount);
                itemVO.setUnDrawCount(itemVO.getUserCount() - itemVO.getDrawCount());
                couponSpecifiedDistributionRecordList.addItem(itemVO);
            }
        }

        return couponSpecifiedDistributionRecordList;
    }

    /**
     * 查询现金券指定发放记录明细
     * @param
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public CouponSpecifiedDistributionRecordItemDetailVO lstCouponSpecifiedDistributionDetail(LstCouponSpecifiedDistributionDetailConditionVO lstCondition) throws BusinessException {
        CouponSpecifiedDistributionRecordItemDetailVO couponSpecifiedDistributionRecordDetail = new CouponSpecifiedDistributionRecordItemDetailVO();

        //修正查询序号
        lstCondition.setBeginSN((lstCondition.getBeginSN() > 0) ? lstCondition.getBeginSN() : 1);
        if (lstCondition.getBeginSN() > lstCondition.getEndSN()) {
            return couponSpecifiedDistributionRecordDetail;
        }

        WhereCondition where = new WhereCondition();
        where.setCondi("audit_id", lstCondition.getAuditId());
        couponSpecifiedDistributionRecordDetail.setTotalCount(couponSpecifiedDistributionRecordItemMapper.lstCountByCondition(where));

        where.setPage(lstCondition.getBeginSN(), lstCondition.getEndSN(), "id");
        List<CouponSpecifiedDistributionRecordItem> items = couponSpecifiedDistributionRecordItemMapper.lstByCondition(where);

        couponSpecifiedDistributionRecordDetail.setItems(new ArrayList<CouponSpecifiedDistributionRecordItemDetailVO.UserInfo>());
        for (CouponSpecifiedDistributionRecordItem item : items) {
            CouponSpecifiedDistributionRecordItemDetailVO.UserInfo userInfo =
                    new CouponSpecifiedDistributionRecordItemDetailVO.UserInfo(item.getPhoneNumber(), item.getPhoneName());
            couponSpecifiedDistributionRecordDetail.getItems().add(userInfo);
        }

        return couponSpecifiedDistributionRecordDetail;
    }

    /**
     * 现金券指定发放记录审核
     * @param
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean couponSpecifiedDistributionAudit(CouponSpecifiedDistributionAuditVO auditInfo) throws BusinessException {
        WhereCondition where = new WhereCondition();
        List<String> auditIds = DataUtils.split(auditInfo.getAuditIdList(), REGEXSTR);
        where.setInString("audit_id", auditIds);
        where.setCondi("specified_type", SPECIFIED_TYPE_RED_PACKET);
        where.noDelete();

        List<CouponSpecifiedDistributionRecord> recordList =
                couponSpecifiedDistributionRecordMapper.lstByCondition(where);

        int succCount = 0;
        Set<Long> messageAuditIds = new HashSet<>();
        if (recordList != null && recordList.size() > 0) {
            for (CouponSpecifiedDistributionRecord record : recordList) {
                if(checkKeyLock(COUPON_SPECIFIED_DISTRIBUTION_RED_PACKET_KEY + record.getAuditId(), MAX_RUN_TIME)) {
                    continue;
                }

                logger.info("CouponSpecifiedDistributionRecord: " + DataUtils.toString(record.toString()));
                if ((!record.getAuditStatus().equals(BizDefine.WORKFLOW_STATUS_AUDIT_FAIL))
                        && (!record.getAuditStatus().equals(BizDefine.WORKFLOW_STATUS_AUDITED))) {
                    logger.info("AuditStatus: " + DataUtils.toString(record.getAuditStatus()));
                    Date now = new Date();
                    record.setAuditTime(now);
                    record.setAuditOperator(auditInfo.getAuditOperator());
                    record.setUpdateTime(now);
                    if (auditInfo.getIsAudited() != 1) {
                        record.setAuditStatus(BizDefine.WORKFLOW_STATUS_AUDIT_FAIL);
                        record.setAuditOpinion(auditInfo.getAuditOpinion());
                    } else {
                        record.setAuditStatus(BizDefine.WORKFLOW_STATUS_AUDITED);
                        logger.info("发放现金红包");
                        int ret = batchEstablishRedPacketRecord(record.getRedPacketAmount(), record.getAuditId());
                        logger.info("发放现金红包数量：{}", ret);
                    }

                    //更新回批量审核记录
                    if(couponSpecifiedDistributionRecordMapper.updateByPrimaryKeyEx(record) > 0) {
                        ++succCount;
                    }else {
                        logger.error("批量更新失败，{}", record.toString());
                        throw new BusinessException(TradeStatusMsg.CASHCOUPON_SPECDIST_STATUS_ERR,
                                TradeStatusMsg.CASHCOUPON_SPECDIST_STATUS_ERR_MSG, false);
                    }
                }else {
                    throw new BusinessException(TradeStatusMsg.CASHCOUPON_SPECDIST_STATUS_ERR,
                            TradeStatusMsg.CASHCOUPON_SPECDIST_STATUS_ERR_MSG, false);
                }
                messageAuditIds.add(record.getAuditId());
            }

            //发送发红包消息
            if (messageAuditIds.size() > 0) {
                for (Long auditId : messageAuditIds) {
                    RedPacketAuditMessage redPacketAuditMessage = new RedPacketAuditMessage();
                    redPacketAuditMessage.setAuditId(auditId);
                    redPacketAuditProducer.send(redPacketAuditMessage);
                }
            }
            return succCount>0;
        }
        return false;
    }

    /**
     * 批量发放现金红包
     * @param amount 单个现金红包金额
     * @param auditId 审核批次号
     * @return 成功发放的数量
     */
    private int batchEstablishRedPacketRecord(BigDecimal amount, Long auditId) {
        logger.info("Step1 清理已有记录");
        String sql = "DELETE FROM red_packet_record WHERE audit_id = " + auditId;
        redPacketRecordMapper.deleteRecord(new QueryUtils(sql));

        logger.info("Step2 添加新记录");
        sql = "INSERT INTO red_packet_record (audit_id, user_uuid, phone_number, phone_name, red_packet_amount)" +
                " SELECT audit_id, user_uuid, phone_number, phone_name, " + amount.doubleValue() +
                " FROM coupon_specified_distribution_record_item " +
                " WHERE audit_id=" + auditId;
        int ret = redPacketRecordMapper.insertMultipleRecord(new QueryUtils(sql));

        logger.info("Step3 更新现金券备注信息");
        CouponSpecifiedDistributionRecord couponSpecifiedDistributionInfo
                = couponSpecifiedDistributionRecordMapper.selectByPrimaryKey(auditId);
        if((couponSpecifiedDistributionInfo!=null)
                && (DataUtils.isNotEmpty(couponSpecifiedDistributionInfo.getSpecifiedName()))) {
            redPacketRecordMapper.updateRemarks(couponSpecifiedDistributionInfo.getSpecifiedName(), auditId);
        }

        return ret;
    }

    /**
     * 删除未实际发放的现金红包指定发放, 实际上将指定记录从当前表中删除，转存至备份表中
     * @param
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean deleteCouponSpecifiedDistribution(Long auditId) throws BusinessException {
        logger.info("Step1 转存现金券指定发放记录");
        couponSpecifiedDistributionRecordMapper.deleteBackByAuditId(auditId);
        int ret = couponSpecifiedDistributionRecordMapper.insertBackByAuditId(auditId);
        if(ret == 0) {
            logger.info("不存在可转存的记录，转存失败");
            throw new BusinessException(TradeStatusMsg.CASHCOUPON_SPECDIST_STATUS_ERR, "删除失败，" + TradeStatusMsg.CASHCOUPON_SPECDIST_STATUS_ERR_MSG, false);
        }

        logger.info("Step2 转存现金券指定发放明细记录");
        couponSpecifiedDistributionRecordItemMapper.deleteBackByAuditId(auditId);
        couponSpecifiedDistributionRecordItemMapper.insertBackByAuditId(auditId);

        logger.info("Step3 删除现有记录");
        couponSpecifiedDistributionRecordMapper.deleteByPrimaryKey(auditId);
        couponSpecifiedDistributionRecordItemMapper.deleteByAuditId(auditId);
        return true;
    }

    /**
     * 查询红包发放记录
     * @param
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public CommItemListVO<RedPacketRecordVO> lstRedPacketRecord(LstRedPacketConditionVO lstCondition) throws BusinessException {
        CommItemListVO<RedPacketRecordVO> itemList = new CommItemListVO<>();
        WhereCondition where = new WhereCondition();
        where.setCondi("audit_id", lstCondition.getAuditId(), true);
        where.setCondi("user_uuid", lstCondition.getUserUuid());
        where.setCondi("phone_number", lstCondition.getUserPhone());
        where.setLike("phone_name", lstCondition.getUserName());

        where.setCondi("receive_status", lstCondition.getReceiveStatus(), true);
        where.setBetween("receive_time", lstCondition.getBeginDrawDate(), lstCondition.getEndDrawDate());
        itemList.setCount(lstQueryDataCount("SELECT COUNT(*) FROM red_packet_record " + where.toString()));

        if (DataUtils.isNotEmpty(lstCondition.getOrderBy())) {
            where.setPage(lstCondition.getBeginSN(), lstCondition.getEndSN(), lstCondition.getOrderBy());
        } else {
            where.setPage(lstCondition.getBeginSN(), lstCondition.getEndSN(), "create_time");
        }
        List<RedPacketRecord> redPacketRecordList = redPacketRecordMapper.lstByCondition(where);
        for(RedPacketRecord redPacketRecord : redPacketRecordList) {
            itemList.addItem(new RedPacketRecordVO(redPacketRecord));
        }

        return itemList;
    }

    /**
     * 根据查询条件获取记录数量
     * @param lstCondition
     * @return
     * @throws BusinessException
     */
    @Override
    public int countRedPacketRecord(LstRedPacketConditionVO lstCondition) throws BusinessException {
        return redPacketRecordMapper.countRedPacketRecord(lstCondition);
    }

    /**
     * 根据查询条件活动红包总额
     * @param lstCondition
     * @return
     * @throws BusinessException
     */
    @Override
    public double totalRedPacketRecord(LstRedPacketConditionVO lstCondition) throws BusinessException {
        Double result = redPacketRecordMapper.totalRedPacketRecord(lstCondition);
        return result == null ? 0 : result;
    }


    /**
     * 领取红包
     * @param
     * @return 1领取成功，2领取失败
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int drawRedPacketList(String redPacketIds) throws BusinessException {
        List<String> redPacketIdList = DataUtils.split(redPacketIds);
        List<Long> redPacketIdLList = new ArrayList<>();
        for(String redPacketId : redPacketIdList) {
            Long redPacketIdL = Long.parseLong(redPacketId);
            if(redPacketIdL.longValue() > 0) {
                redPacketIdLList.add(redPacketIdL);
            }
        }

        int count = 0;
        for(Long redPacketId : redPacketIdLList) {
            RedPacketRecord redPacketRecord = redPacketRecordMapper.selectByPrimaryKey(redPacketId);
            if(redPacketRecord.getUserUuid() != null) {
                TwoTuple<Integer, String> ret = null;
                try {
                    ret = drawRedPacketService.drawRedPacket(redPacketRecord.getUserUuid(), redPacketId);
                    //ret = drawRedPacket(redPacketRecord.getUserUuid(), redPacketId);
                }catch(BusinessException e) {
                    ret = null;
                    logger.error("BusinessException: ", e);
                    drawRedPacketService.drawRedPacketFail(redPacketId, e.getMessage());
                }

                logger.info("RedPacketId: {}", redPacketId);
                if((ret!=null) && (ret.first!=null) && (ret.first.intValue()>0)) {
                    ++count;
                }
            }
        }

        return count;
    }

    /**
     * 创建红包记录
     * @param auditId
     * @param userUuid
     * @param phoneNumber
     * @param phoneName
     * @param amount
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int establishRedPacketRecord(Long auditId, String userUuid, String phoneNumber, String phoneName, BigDecimal amount) throws BusinessException {
        StringBuilder sb = new StringBuilder("INSERT INTO red_packet_record (audit_id, user_uuid, phone_number, phone_name, red_packet_amount) VALUES");

        sb.append("(").append(auditId).append(", ");
        sb.append(WhereCondition.toSQLStr(userUuid)).append(", ");
        sb.append(WhereCondition.toSQLStr(phoneNumber)).append(", ");
        sb.append(WhereCondition.toSQLStr(phoneName)).append(", ");
        sb.append(amount).append(")");

        return redPacketRecordMapper.insertMultipleRecord(new QueryUtils(sb.toString()));
    }
}
