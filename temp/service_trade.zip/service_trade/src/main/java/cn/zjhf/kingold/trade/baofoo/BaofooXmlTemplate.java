package cn.zjhf.kingold.trade.baofoo;

/**
 * Created by liuyao on 2017/7/13.
 */
public class BaofooXmlTemplate {

    public final static String RECHARGE_PAGE_DATA = "<?xml version='1.0' encoding='UTF-8'?>" +
            "<custody_req>" +
            "<merchant_id>%s</merchant_id>" +
            "<user_id>%s</user_id>" +
            "<order_id>%s</order_id>" +
            "<amount>%s</amount>" +
            "<fee>%s</fee>" +
            "<fee_taken_on>%s</fee_taken_on>" +
            "<page_url>%s</page_url>" +
            "<return_url>%s</return_url>" +
            "</custody_req>";
}
