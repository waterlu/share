package cn.zjhf.kingold.trade.entity.InVO;

import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.web.multipart.MultipartFile;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by zhangyijie on 2017/8/23.
 */
@ApiModel(value = "InsertCouponSpecifiedDistributionAuditVO", description = "添加现金券指定发放记录")
public class InsertCouponSpecifiedDistributionAuditVO extends InVOBase {
    @ApiModelProperty(required = true, value = "批次号列表，每条格式： 批次号-批次名")
    @NotEmpty
    private List<String> ccCodeList;

    @ApiModelProperty(required = true, value = "指定发放的名字")
    private String specifiedName;

    @ApiModelProperty(required = true, value = "现金红包金额")
    private BigDecimal redPacketAmount;

    @ApiModelProperty(required = true, value = "用户手机号列表")
    private List<String> userPhoneList;

    @ApiModelProperty(required = true, value = "操作人")
    private String operator;

    public List<String> getCcCodeList() {
        return ccCodeList;
    }

    public void setCcCodeList(List<String> ccCodeList) {
        this.ccCodeList = ccCodeList;
    }

    public List<String> getUserPhoneList() {
        return userPhoneList;
    }

    public void setUserPhoneList(List<String> userPhoneList) {
        this.userPhoneList = userPhoneList;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(getTraceID()) + ", ");
        sb.append("specifiedName:" + DataUtils.toString(getSpecifiedName()) + ", ");
        sb.append("redPacketAmount:" + DataUtils.toString(redPacketAmount) + ", ");
        sb.append("ccCodeList:" + DataUtils.toString(ccCodeList) + ", ");
        sb.append("userPhoneList:" + DataUtils.toString(userPhoneList) + ", ");
        sb.append("operator:" + DataUtils.toString(operator) + ", ");
        return sb.toString();
    }

    public String getSpecifiedName() {
        return specifiedName;
    }

    public void setSpecifiedName(String specifiedName) {
        this.specifiedName = specifiedName;
    }

    public BigDecimal getRedPacketAmount() {
        return redPacketAmount;
    }

    public void setRedPacketAmount(BigDecimal redPacketAmount) {
        this.redPacketAmount = redPacketAmount;
    }
}
