package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.rocketmq.base.SimpleMessage;
import cn.zjhf.kingold.trade.baofoo.*;
import cn.zjhf.kingold.trade.constant.*;
import cn.zjhf.kingold.trade.entity.InVO.RechargeSdkVo;
import cn.zjhf.kingold.trade.entity.OutVO.BaofooPayParamVO;
import cn.zjhf.kingold.trade.entity.PayLog;
import cn.zjhf.kingold.trade.entity.Payee;
import cn.zjhf.kingold.trade.persistence.dao.PayLogMapper;
import cn.zjhf.kingold.trade.persistence.dao.TradeOrderMapper;
import cn.zjhf.kingold.trade.persistence.mq.producer.PayTimeoutProducer;
import cn.zjhf.kingold.trade.service.IPayService;
import cn.zjhf.kingold.trade.service.ITradeOrderService;
import cn.zjhf.kingold.trade.service.ITradeService;
import cn.zjhf.kingold.trade.utils.AmountUtils;
import cn.zjhf.kingold.trade.utils.BaofooResponseMappingUtil;
import cn.zjhf.kingold.trade.utils.HttpDownload;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.rocketmq.client.producer.MQProducer;
import com.alibaba.rocketmq.common.message.Message;
import okhttp3.*;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;


import java.math.BigDecimal;
import java.net.SocketTimeoutException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by lutiehua on 2017/4/26.
 */
@Service
public class PayServiceImpl implements IPayService {

    private final static Logger LOGGER = LoggerFactory.getLogger(PayServiceImpl.class);
    private final static String XML_ROOT = "custody_req";
    @Value("${baofoo.merchant.id}")
    private String merchantID;
    @Value("${baofoo.terminal.id}")
    private String terminalID;
    @Value("${baofoo.aes.key}")
    private String password;
    @Value("${baofoo.url}")
    private String url;
    @Value("${baofoo.platform.url}")
    private String platformUrl;
    @Value("${baofoo.debug}")
    private boolean debug = false;
    @Value("#{${baofoo.error.mapping}}")
    private Map<String, String> errorMapping;
    @Value("#{${error.define}}")
    private Map<String, String> errors;
    @Autowired
    private SecurityUtil securityUtil;
    @Autowired
    private OkHttpClient okHttpClient;

    @Autowired
    private PayLogMapper payLogMapper;

    @Autowired
    private PayTimeoutProducer mqProducer;
    @Autowired
    private ITradeService tradeService;
    @Autowired
    private TradeOrderMapper tradeOrderMapper;


    /**
     * 统一的错误处理
     *
     * @param baoFooResponse
     * @return
     */
    private ResponseResult buildResponse(BaoFooResponse baoFooResponse) throws BusinessException {
        if (baoFooResponse.getCode().equalsIgnoreCase(BaoFooCode.OK)) {
            ResponseResult responseResult = new ResponseResult();
            responseResult.setCode(PayResponseCode.OK);
            responseResult.setMsg(PayResponseCode.OK_MSG);

            return responseResult;
        } else {
            String code = baoFooResponse.getCode();
            String msg = baoFooResponse.getMsg();
            String message = code + "|" + msg;
            throw new BusinessException(PayResponseCode.ERROR_UNKNOW_CODE, message, false);
        }
    }

    /**
     * 统一的错误处理
     *
     * @param baoFooResponse
     * @return
     */
    private ResponseResult buildResponseWithoutException(BaoFooResponse baoFooResponse) throws BusinessException {
        ResponseResult responseResult = new ResponseResult();
        int returnCode = BaofooResponseMappingUtil.getPayResponseCode(baoFooResponse.getCode());
        responseResult.setCode(returnCode);
        if (returnCode == PayResponseCode.ERROR_UNKNOW_CODE) {
            responseResult.setMsg(baoFooResponse.getMsg());
        } else {
            responseResult.setMsg(BaofooResponseMappingUtil.getPayResponseMsg(baoFooResponse.getCode()));
        }
        return responseResult;
    }

    /**
     * 包装返回结果
     *
     * @param baofooResponse
     * @return
     */
    private BigDecimal buildPlatformResponse(String baofooResponse) throws BusinessException {
        JSONObject jo = JSON.parseObject(JSON.parseObject(baofooResponse).getString("trans_content"));
        JSONObject head = JSON.parseObject(jo.getString("trans_head"));
        if (!"0000".equals(head.get("return_code").toString())) {
            ResponseResult rr = new ResponseResult();
            rr.setCode(Integer.valueOf(head.getString("return_code")));
            rr.setMsg(head.getString("return_msg"));
        }
        JSONObject data = JSON.parseObject(JSON.parseObject(jo.getString("trans_reqDatas")).getString("trans_reqData"));
        return data.getBigDecimal("balance");
    }

    /**
     * 生成充值日志记录
     * @param requestXml
     * @param orderId
     */
    private void generateRechargeLog(String requestXml, String orderId){
        List<PayLog> payLogs = payLogMapper.queryByOrderBillCode(orderId);
        if (!CollectionUtils.isEmpty(payLogs)) {
            return;
        }
        PayLog payLog = new PayLog();
        payLog.setOrderBillCode(orderId);
        payLog.setPayOrderId(orderId);
        payLog.setPaySeq(1);
        payLog.setPayType(IPayService.TYPE_RECHARGE);
        payLog.setPayRequest(requestXml);
        payLog.setPayRequestTime(new Date());
        payLog.setPayStatus(PayStatus.PENDING);
        payLogMapper.insert(payLog);
    }

    /**
     * 查询账户余额
     *
     * @param userID 商户会员ID
     * @return
     * @throws Exception
     */
    public ResponseResult getAccountBalance(long userID) throws BusinessException {
        Map<String, Object> userInfo = new HashMap<>();
        // 商户号
        userInfo.put("merchant_id", merchantID);
        // 用户编号(唯一)
        userInfo.put("user_id", userID);
        QueryAccountBalanceResponse queryAccountBalanceResponse;
        try {
            String xmlString =  Map2Xml.convert(userInfo, XML_ROOT);
            queryAccountBalanceResponse = doBaoFooRequest(CMD_ACCOUNT_BALANCE, xmlString, false, QueryAccountBalanceResponse.class);
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            throw new BusinessException(PayResponseCode.ERROR_UNKNOW_CODE, e.getMessage(), true);
        }
        ResponseResult responseResult = buildResponseWithoutException(queryAccountBalanceResponse);
        responseResult.setData(queryAccountBalanceResponse.getBalance() == null ? 0 : queryAccountBalanceResponse.getBalance());
        return responseResult;
    }

    /**
     * 客户端充值，获取宝付orderId
     *
     * @return
     * @throws BusinessException
     */
    @Override
    public ResponseResult getBaofooOrderId(long userId, String orderId, double amount, String returnUrl) throws BusinessException {
        Map<String, Object> transferInfo = new HashMap<>();
        // 商户号
        transferInfo.put("user_id", userId);
        // 订单号
        transferInfo.put("order_id", orderId);
        // 充值金额
        transferInfo.put("amount", amount);
        transferInfo.put("fee", "0");
        // 手续费收取方，1：平台，2：用户自担
        transferInfo.put("fee_taken_on", "1");
        // 付款方帐号类型 0为普通用户(平台的user_id) 1为商户号
        transferInfo.put("return_url", returnUrl);
        // 发起宝付请求
        BaofooOrderIdResponse orderIdResponse;
        try {
            String xmlString =  Map2Xml.convert(transferInfo, XML_ROOT);
            generateRechargeLog(xmlString, orderId);
            orderIdResponse = doBaoFooRequest(CMD_GET_BAOFOO_RECHARGE_ID, xmlString, false, BaofooOrderIdResponse.class);
        } catch (Exception e) {
            LOGGER.error("getBaofooOrderId failed. userId={}, orderId={}, amount={}, returnUrl={}.",userId, orderId, amount, returnUrl, e.getMessage());
            throw new BusinessException(PayResponseCode.ERROR_UNKNOW_CODE, e.getMessage(), true);
        }
        ResponseResult result = buildResponse(orderIdResponse);
        if (result.getCode() == PayResponseCode.OK) {
            result.setData(orderIdResponse.getOrder_id());
        }
        return result;
    }

    /**
     * 绑定账户（开户）
     *
     * @param phone 手机号码
     * @param userID 用户ID
     * @param realName 真实姓名
     * @param idCard 身份证号码
     * @param smsCode 验证码
     * @return PayResponse
     */
    @Override
    public ResponseResult bindPlatform(String phone, long userID, String realName, String idCard, String smsCode, int isAccredit) throws BusinessException {
        return openAccount(phone, userID, realName, idCard, smsCode, 1 , isAccredit);
    }

    @Override
    public Map<String, String> getPlatformInfo() {
        Map<String, String> platform = new HashMap<>();
        platform.put("merchantId", merchantID);
        platform.put("terminalId", terminalID);
        platform.put("key", password);
        return platform;
    }

    /**
     * 开户
     *
     * @param phone 手机号码
     * @param userID 用户ID
     * @param realName 真实姓名
     * @param idCard 身份证号码
     * @return
     * @throws Exception
     */
    @Override
    public ResponseResult createAccount(String phone, long userID, String realName, String idCard, int isAccredit) throws BusinessException {
        return openAccount(phone, userID, realName, idCard, null, 0 ,isAccredit);
    }

    private ResponseResult openAccount(String phone, long userID, String realName, String idCard, String smsCode, int type, int isAccredit) throws BusinessException {
        Map<String, Object> userInfo = new HashMap<>();
        // 是否已有宝付会员账号（0 无 、 1有）
        userInfo.put("has_bf_account", String.valueOf(type));
        // 宝付会员账号 (手机号)
        userInfo.put("bf_account", phone);
        // 用户编号(唯一)
        userInfo.put("user_id", userID);
        // 用户真实姓名
        userInfo.put("real_name", realName);
        // 用户真实身份证号码
        userInfo.put("id_card", idCard);
        // 平台绑定码
        userInfo.put("bind_code", smsCode == null ? "0" : smsCode);
        // 会员账户类型 1：手机注册(唯一支持)
        userInfo.put("account_type","1");
        userInfo.put("is_accredit",String.valueOf(isAccredit));

        String xmlString = null;
        BaoFooResponse baoFooResponse = null;
        try {
            xmlString = Map2Xml.convert(userInfo, XML_ROOT);
            baoFooResponse = doBaoFooRequest(CMD_REGISTER, xmlString, true);
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            throw new BusinessException(PayResponseCode.ERROR_UNKNOW_CODE, e.getMessage(), false);
        }

        ResponseResult responseResult = buildResponseWithoutException(baoFooResponse);
        return responseResult;
    }

    /**
     * 募集方企业开户
     *
     * @param email 企业邮箱
     * @param mobile 法人手机号码
     * @param userID 用户ID
     * @param realName 真实姓名
     * @param idCard 身份证号码
     * @param license 营业执照号码
     * @param enterpriseName 企业名称
     * @return
     * @throws Exception
     */
    @Override
    public ResponseResult createIssueAccount(String email, long userID, String realName, String idCard, String enterpriseName, String license, String mobile ) throws BusinessException {
        Map<String, Object> userInfo = new HashMap<>();
        // 是否已有宝付会员账号（0 无 、 1有）
        userInfo.put("has_bf_account", "0");
        // 宝付会员账号 (邮箱)
        userInfo.put("bf_account", email);
        // 用户编号(唯一)
        userInfo.put("user_id", userID);
        // 用户真实姓名
        userInfo.put("real_name", realName);
        // 用户真实身份证号码
        userInfo.put("id_card", idCard);
        // 平台绑定码
        userInfo.put("bind_code", "0");
        userInfo.put("enterprise_name",enterpriseName);
        userInfo.put("license",license);
        userInfo.put("Mobile",mobile);
        userInfo.put("return_url", "www.baidu.com");

        String xmlString = null;
        BaoFooResponse baoFooResponse;
        try {
            xmlString = Map2Xml.convert(userInfo, XML_ROOT);
            baoFooResponse = doBaoFooRequest(CMD_REGISTER, xmlString, true);
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            throw new BusinessException(PayResponseCode.ERROR_UNKNOW_CODE, e.getMessage(), false);
        }
        ResponseResult responseResult = buildResponse(baoFooResponse);
        return responseResult;
    }

    /**
     *发送验证码
     *
     * @param userID 商户会员ID
     * @return
     * @throws BusinessException
     */
    @Override
    public ResponseResult sendVerifyCode(long userID) throws BusinessException {
        String requestParams = Long.toString(userID);
        BaoFooResponse baoFooResponse = null;
        try {
            baoFooResponse = doBaoFooRequest(CMD_VERIFY_CODE, requestParams);
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            throw new BusinessException(PayResponseCode.ERROR_UNKNOW_CODE, e.getMessage(), true);
        }

        return buildResponse(baoFooResponse);
    }

    /**
     * 发送绑定账号短信验证码
     *
     * @param accountMobile 商户会员账号
     * @return
     * @throws BusinessException
     */
    @Override
    public ResponseResult sendAccountBindVerifyCode(String accountMobile) throws BusinessException {
        BaoFooResponse baoFooResponse = null;
        try {
            baoFooResponse = doBaoFooRequest(CMD_ACCOUNT_BIND_VERIFY_CODE, accountMobile);
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            throw new BusinessException(PayResponseCode.ERROR_UNKNOW_CODE, e.getMessage(), true);
        }

        return buildResponse(baoFooResponse);
    }


    @Override
    public BaofooPayParamVO getRechargeParam(RechargeSdkVo rechargeSdkVo) throws BusinessException {
        String requestParams = String.format(BaofooXmlTemplate.RECHARGE_PAGE_DATA, merchantID,
                rechargeSdkVo.getUserId().toString(), rechargeSdkVo.getOrderId(), rechargeSdkVo.getAmount().toString(),
                rechargeSdkVo.getFee().toString(), rechargeSdkVo.getFeeTakenOn().toString(),
                rechargeSdkVo.getPageUrl(), rechargeSdkVo.getReturnUrl());

        BaofooPayParamVO baofooPayParamVO = new BaofooPayParamVO();
        baofooPayParamVO.setMerchantId(merchantID);
        baofooPayParamVO.setTerminalId(terminalID);
        baofooPayParamVO.setRequestParams(requestParams);
        baofooPayParamVO.setSign(securityUtil.encryptMD5(requestParams));
        generateRechargeLog(requestParams, rechargeSdkVo.getOrderId());
        return baofooPayParamVO;
    }


    @Override
    public String getSuccessfulOrderId(String orderBillCode) throws BusinessException {
        List<PayLog> payLogList = payLogMapper.querySuccessByOrderBillCode(orderBillCode);
        if (payLogList.size() == 0) {
            return null;
        }

        if (payLogList.size() > 1) {
            throw new BusinessException(PayResponseCode.REPEATED_PAYMENT, PayResponseCode.REPEATED_PAYMENT_MSG);
        }

        PayLog payLog = payLogList.get(0);
        return payLog.getPayOrderId();
    }


    @Override
    @Transactional(rollbackFor = BusinessException.class, propagation = Propagation.REQUIRES_NEW)
    public int updateRecharge(String billCode, String request, Integer orderStatus) throws BusinessException {
        List<PayLog> payLogList = payLogMapper.queryByOrderBillCode(billCode);
        if (payLogList.size() <= 0) {
            throw new BusinessException(PayResponseCode.NO_PAY_ORDER_PAYMENT, PayResponseCode.NO_PAY_ORDER_PAYMENT_MSG);
        }

        PayLog payLog = payLogList.get(0);
        if (payLog.getPayStatus() != RechargeStatusParamEnum.SUCCESS.getPayStatus()) {
            // 还没有收到回调通知
            String payOrderId = billCode;
            payLog.setPaySeq(7);
            payLog.setPayType(IPayService.TYPE_RECHARGE);
            if (orderStatus != RechargeStatusParamEnum.SUCCESS.getParamStatus()) {
                RechargeStatusParamEnum statusEnum = RechargeStatusParamEnum.getStatusByParamStatus(orderStatus);
                payLog.setPayStatus(statusEnum.getPayStatus());
            } else {
                payLog.setPayStatus(PayStatus.APPLY_SUCCESS);
            }
            //此处更新状态为申请成功,申请成功发送延迟消息
            try {
                SimpleMessage msg = new SimpleMessage(payOrderId);
                // messageDelayLevel = "1s 2s 3s 5s 10s 30s 1m 2m 3m 5m 10m 20m 30m 60m 120m 600m";
                // 延时3分钟后发送，3分钟后还没有收到充值成功通知，启动超时处理
                mqProducer.send(msg, 9);
            } catch (Exception e) {
                LOGGER.error("updateRecharge failed. billCode={}, request={}, orderStatus={}.", billCode, request, orderStatus, e.getMessage());
                throw new BusinessException(ResponseCode.EXCEPTION, e.getMessage());
            }
            payLogMapper.updatePayInfo(payLog);
            return TradeStatus.NEW;
        } else {
            // 已经收到回调通知
            payLog.setOrderBillCode(billCode);
            if (request != null) {
                payLog.setPayRequest(request);
            }
            payLogMapper.updateRequestByOrderBillCode(payLog);
            return RechargeStatusParamEnum.getStatusByParamStatus(payLog.getPayStatus()).getDbStatus();
        }
    }

    @Override
    public String notifyRecharge(String billCode, String response) throws BusinessException {
        // 查询充值操作日志记录
        PayLog payLog = payLogMapper.selectByPrimaryKey(billCode);
        if (null == payLog) {
            // 回调通知早于客户端告知
            payLog = new PayLog();
            payLog.setOrderBillCode(billCode);
            payLog.setPayOrderId(billCode);
            payLog.setPaySeq(1);
            payLog.setPayType(IPayService.TYPE_RECHARGE);
            payLog.setPayRequest("");
            payLog.setPayRequestTime(null);
            payLog.setPayResponse(response);
            payLog.setPayResponseTime(new Date());
            payLog.setPayStatus(PayStatus.SUCCESSFUL);
            payLogMapper.insert(payLog);
        } else {
            // 回调通知晚于客户端告知
            if (payLog.getPayStatus() == PayStatus.PENDING) {
                payLog.setPayResponse(response);
                payLog.setPayResponseTime(new Date());
                payLog.setPayStatus(PayStatus.SUCCESSFUL);
                payLogMapper.updateByPrimaryKey(payLog);
            }
        }

        return billCode;
    }

    @Override
    public ResponseResult queryTimeoutStatus(String payOrderId) throws BusinessException {
        ResponseResult responseResult = query(IPayService.TYPE_RECHARGE, payOrderId);
        if (responseResult.getCode() != 200 || null == responseResult.getData()) {
            LOGGER.info("queryTimeoutStatus failed. msg={}", responseResult.getMsg());
            responseResult.setCode(responseResult.getCode());
            responseResult.setMsg(responseResult.getMsg());
            return responseResult;
        }
        LOGGER.info("queryTimeoutStatus success. status={}, msg={}", responseResult.getCode(), responseResult.getMsg());
        Map<String, String> data = (Map<String, String>) responseResult.getData();
        String orderBillCode = data.get("orderBillCode");
        String state = data.get("state");
        String amountString = data.get("amount");
//        String feeString = data.get("fee");
        // baofoo_fee 宝付手续费 fee 商户手续费
        String feeString = data.get("baoFooFee");
        int feeTakenOn = Integer.valueOf(data.get("feeTakenOn"));
        String timeString = data.get("time");
        String result = data.get("result");
        if (null != orderBillCode &&
            orderBillCode.equalsIgnoreCase(payOrderId) &&
            Integer.parseInt(state) == 1) {
            // 订单号一致，状态是成功，刷新余额
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.0");
            Date time = null;
            try {
                if (null != timeString) {
                    time = dateFormat.parse(timeString);
                }
            } catch (ParseException e) {
                LOGGER.error("queryTimeoutStatus failed. data={}", JSON.toJSON(data), e);
            }
            double amount = Double.parseDouble(amountString);
            tradeService.executeRechargeOrder(orderBillCode, amount, feeTakenOn, Double.valueOf(feeString), time, result, null);
            PayLog payLog = new PayLog();
            payLog.setPayResponse(JSON.toJSON(data).toString());
            payLog.setPayResponseTime(new Date());
            payLog.setPayStatus(PayStatus.SUCCESSFUL);
            payLogMapper.updateByPrimaryKey(payLog);
            responseResult.setCode(ResponseCode.OK);
            responseResult.setCode(ResponseCode.OK);
            responseResult.setMsg(ResponseCode.OK_TEXT);
            return responseResult;
        }
        responseResult.setCode(ResponseCode.EXCEPTION);
        responseResult.setMsg("充值主动查询没有成功.");
        return responseResult;
    }

    @Override
    public boolean checkRecharge(RechargeNotify rechargeNotify) throws BusinessException {
        String orderBillCode = rechargeNotify.getBillCode();
        PayLog payLog = payLogMapper.selectByPrimaryKey(orderBillCode);
        if (payLog != null && payLog.getPayStatus() == PayStatus.SUCCESSFUL) {
            return true;
        }
        return false;
    }

    @Override
    public boolean updatePayLog(String orderId, int status, String response) throws BusinessException {
        PayLog payLog = payLogMapper.selectByPrimaryKey(orderId);
        if (null == payLog || payLog.getPayStatus() != PayStatus.PENDING) {
            return false;
        }

        payLog.setPayStatus(status);
        payLog.setPayResponseTime(new Date());
        payLog.setPayResponse(response);
        return payLogMapper.updateByPrimaryKey(payLog) > 0;
    }

    @Override
    public boolean checkWithdraw(String payOrderId) throws BusinessException {
        PayLog payLog = payLogMapper.selectByPrimaryKey(payOrderId);
        if (payLog != null && payLog.getPayStatus() == PayStatus.PENDING) {
            return true;
        }
        return false;
    }

    /**
     * 查询所有账户余额
     *
     * @return
     * @throws Exception
     */
    public ResponseResult getAllAccountBalance() throws BusinessException {
        Date now = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        String xmlString =  dateFormat.format(now);
        BaoFooResponse baoFooResponse = null;
        try {
            baoFooResponse = doBaoFooRequest(CMD_ALL_ACCOUNT_BALANCE, xmlString);
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            throw new BusinessException(PayResponseCode.ERROR_UNKNOW_CODE, e.getMessage(), true);
        }

        return buildResponse(baoFooResponse);
    }

    /**
     * 绑定银行卡
     *
     * @param userID 商户会员ID
     * @param mobile 银行预留手机号码
     * @param bankNo 银行卡号
     * @param validateCode 手机验证码
     * @return
     * @throws BusinessException
     */
    @Override
    public ResponseResult bindBankCard(long userID, String mobile, String bankNo, String validateCode) throws BusinessException {
        Map<String, Object> bindInfo = new HashMap<>();
        // 用户ID
        bindInfo.put("user_id", userID);
        // 银行卡手机预留号
        bindInfo.put("mobile", mobile);
        // 银行卡号
        bindInfo.put("bank_no", bankNo);
        // 手机验证码
        bindInfo.put("validate_code", validateCode);
        String xmlString = null;
        BindBankCardResponse baoFooResponse = null;
        try {
            xmlString = Map2Xml.convert(bindInfo, XML_ROOT);
            baoFooResponse = doBaoFooRequest(CMD_BIND_BANK_CARD, xmlString, true, BindBankCardResponse.class);
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            throw new BusinessException(PayResponseCode.ERROR_UNKNOW_CODE, e.getMessage(), false);
        }

        ResponseResult responseResult = buildResponse(baoFooResponse);
        if (responseResult.getCode() == PayResponseCode.OK) {
            Map<String, String> data = new HashMap<>();
            data.put("cardID", baoFooResponse.getCard_id());
            responseResult.setData(data);
        }
        return responseResult;
    }

    /**
     * 投资
     *
     * @param orderBillCode 订单编号
     * @param productID 产品ID
     * @param productName 产品名称
     * @param borrowUserID 融资方用户ID
     * @param userID 投资方用户ID
     * @param amount 投资金额
     * @return
     * @throws Exception
     */
    @Override
//    @Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRES_NEW)
    public ResponseResult invest(String orderBillCode, long productID, String productName, long borrowUserID, long userID,
                                 double amount) throws BusinessException {
        LOGGER.info("invest");
        // 检查是否已操作成功
        BFPayStatus bfPayStatus = this.checkPayStatus(orderBillCode);
        if (bfPayStatus.isSuccess()) {
            ResponseResult responseResult = new ResponseResult();
            responseResult.setCode(ResponseCode.OK);
            responseResult.setMsg(ResponseCode.OK_TEXT);
            responseResult.setData(bfPayStatus.getPayOrderId());
            return responseResult;
        }

        // 没有查询到是否成功
        if (bfPayStatus.getQueryFailedCount() > 0) {
            LOGGER.error("queryFailedCount={}", bfPayStatus.getQueryFailedCount());
            throw new BusinessException(PayResponseCode.GET_STATUS_FAILED, PayResponseCode.GET_STATUS_FAILED_MSG);
        }

        // 提交给宝付的订单ID=我们的订单ID+6位序号
        int actionType = IPayService.TYPE_INVEST;
        int seq = bfPayStatus.getTryCount() + 1;
        String payOrderId = String.format("%s%06d", orderBillCode, seq);
        LOGGER.info("payOrderId=[{}]", payOrderId);

        Map<String, Object> investInfo = new HashMap<>();
        // 商户号
        investInfo.put("merchant_id", merchantID);
        // 请求类型，投标为1
        investInfo.put("action_type", actionType);
        // 订单号 （唯一不允许重复）
        investInfo.put("order_id", payOrderId);
        // 标id
        investInfo.put("cus_id", productID);
        // 标名称
        investInfo.put("cus_name", productName);
        // 借款人user_id用户编号
        investInfo.put("brw_id", borrowUserID);
        // 请求时间
        investInfo.put("req_time", System.currentTimeMillis());
        // 手续费
        investInfo.put("fee", 0);

        Map<String, Object> actionsInfo = new HashMap<>();
        Map<String, Object> actionInfo = new HashMap<>();
        // 用户编号(唯一)
        actionInfo.put("user_id", userID);
        // 金额，单位：元
        actionInfo.put("amount", AmountUtils.exac(amount));
        actionsInfo.put("action", actionInfo);
        investInfo.put("actions", actionsInfo);

        // 设置日志信息
        PayLog payLog = new PayLog();
        payLog.setOrderBillCode(orderBillCode);
        payLog.setPayOrderId(payOrderId);
        payLog.setPaySeq(seq);
        payLog.setPayType(actionType);

        // 发起宝付请求
        LOGGER.info("before doBaoFooXMLRequest");
        BaoFooResponse baoFooResponse = doBaoFooXMLRequest(CMD_INVEST, investInfo, payLog);
        LOGGER.info("after doBaoFooXMLRequest");

        // 更新宝付请求状态
        payLog.setPayResponse(baoFooResponse.getCode() + "|" + baoFooResponse.getMsg());
        payLog.setPayResponseTime(baoFooResponse.getResponseTime());
        if (baoFooResponse.isSuccessful()) {
            payLog.setPayStatus(PayStatus.SUCCESSFUL);
        } else {
            payLog.setPayStatus(PayStatus.FAILED);
        }

        LOGGER.info("before updatePayInfo");
        payLogMapper.updatePayInfo(payLog);
        LOGGER.info("after updatePayInfo");

        return buildResponse(baoFooResponse);
    }

    /**
     * 放款
     *
     * @param orderID 订单编号（唯一不允许重复）
     * @param productID 产品ID
     * @param productName 产品名称
     * @param borrowUserID 融资方用户ID
     * @param amount 金额
     * @param fee 手续费
     * @return
     * @throws Exception
     */
    public ResponseResult paymentEx(String orderID, long productID, String productName, long borrowUserID, long userId, double amount, double fee) throws BusinessException {
        Map<String, Object> investInfo = new HashMap<>();
        // 商户号
        investInfo.put("merchant_id", merchantID);
        // 请求类型，投标为1
        investInfo.put("action_type", "2");
        // 订单号 （唯一不允许重复）
        investInfo.put("order_id", orderID);
        // 标id
        investInfo.put("cus_id", productID);
        // 标名称
        investInfo.put("cus_name", productName);
        // 借款人user_id用户编号
        investInfo.put("brw_id", borrowUserID);

        // 请求时间
        investInfo.put("req_time", System.currentTimeMillis());
        // 手续费
        investInfo.put("fee", fee);

        Map<String, Object> actionsInfo = new HashMap<>();
        Map<String, Object> actionInfo = new HashMap<>();
        // 用户编号(唯一)
        actionInfo.put("user_id", userId);
        // 金额，单位：元
        actionInfo.put("amount", amount);
        // 是否担保人
        actionInfo.put("is_voucher", "0");
        actionsInfo.put("action", actionInfo);
        investInfo.put("actions", actionsInfo);

        BaoFooResponse baoFooResponse = doBaoFooXMLRequest(CMD_INVEST, investInfo);
        return buildResponse(baoFooResponse);
    }

    /**
     * 放款
     *
     * @param orderID 订单编号（唯一不允许重复）
     * @param productID 产品ID
     * @param productName 产品名称
     * @param borrowUserID 融资方用户ID
     * @param amount 金额
     * @param fee 手续费
     * @return
     * @throws Exception
     */
    public ResponseResult payment(String orderID, long productID, String productName, long borrowUserID, double amount, double fee) throws BusinessException {
        Map<String, Object> investInfo = new HashMap<>();
        // 商户号
        investInfo.put("merchant_id", merchantID);
        // 请求类型，投标为1
        investInfo.put("action_type", "2");
        // 订单号 （唯一不允许重复）
        investInfo.put("order_id", orderID);
        // 标id
        investInfo.put("cus_id", productID);
        // 标名称
        investInfo.put("cus_name", productName);
        // 借款人user_id用户编号
        investInfo.put("brw_id", borrowUserID);
        // 请求时间
        investInfo.put("req_time", System.currentTimeMillis());
        // 手续费
        investInfo.put("fee", fee);

        Map<String, Object> actionsInfo = new HashMap<>();
        Map<String, Object> actionInfo = new HashMap<>();
        // 用户编号(唯一)
        actionInfo.put("user_id", borrowUserID);
        // 金额，单位：元
        actionInfo.put("amount", amount);
        // 是否担保人
        actionInfo.put("is_voucher", "0");
        actionsInfo.put("action", actionInfo);
        investInfo.put("actions", actionsInfo);

        BaoFooResponse baoFooResponse = doBaoFooXMLRequest(CMD_INVEST, investInfo);
        return buildResponse(baoFooResponse);
    }

    /**
     * 退款
     *
     * @param orderID 订单编号
     * @param productID 产品ID
     * @param productName 产品名称
     * @param borrowUserID 融资方用户ID
     * @param userID 投资方用户ID
     * @param amount 金额
     * @return
     * @throws Exception
     */
    public ResponseResult refund(String orderID, long productID, String productName, long borrowUserID, long userID, double amount) throws BusinessException {
        Map<String, Object> investInfo = new HashMap<>();
        // 商户号
        investInfo.put("merchant_id", merchantID);
        // 请求类型，投标为1
        investInfo.put("action_type", "3");
        // 订单号 （唯一不允许重复）
        investInfo.put("order_id", orderID);
        // 标id
        investInfo.put("cus_id", productID);
        // 标名称
        investInfo.put("cus_name", productName);
        // 借款人user_id用户编号
        investInfo.put("brw_id", borrowUserID);
        // 请求时间
        investInfo.put("req_time", System.currentTimeMillis());

        Map<String, Object> actionsInfo = new HashMap<>();
        Map<String, Object> actionInfo = new HashMap<>();
        // 用户编号(唯一)
        actionInfo.put("user_id", userID);
        // 金额，单位：元
        actionInfo.put("amount", amount);
        // 手续费( 满标专用)
        actionInfo.put("fee", 0);
        actionsInfo.put("action", actionInfo);
        investInfo.put("actions", actionsInfo);

        BaoFooResponse baoFooResponse = doBaoFooXMLRequest(CMD_INVEST, investInfo);
        return buildResponse(baoFooResponse);
    }

    /**
     * 还款
     * 一次请求中如果一个收款人收款失败，整个请求的所有收款人都失败
     * @param orderID 订单编号（唯一不允许重复）
     * @param productID 产品ID
     * @param productName 产品名称
     * @param borrowUserID 融资方用户ID
     * @param payees 收款人列表
     * @return
     * @throws BusinessException
     */
    @Override
    public ResponseResult repay(String orderID, long productID, String productName, long borrowUserID, List<Payee> payees) throws BusinessException {
        Map<String, Object> investInfo = new HashMap<>();
        // 商户号
        investInfo.put("merchant_id", merchantID);
        // 请求类型，投标为1
        investInfo.put("action_type", "4");
        // 订单号 （唯一不允许重复）
        investInfo.put("order_id", orderID);
        // 标id
        investInfo.put("cus_id", productID);
        // 标名称
        investInfo.put("cus_name", productName);
        // 借款人user_id用户编号
        investInfo.put("brw_id", borrowUserID);
        // 请求时间
        investInfo.put("req_time", System.currentTimeMillis());

        List<Map<Object, Object>> ListArray = new ArrayList<>();
        Map<Object, Object> Repayment = new HashMap<>();
        Map<Object, Object> RepaymentParams = new HashMap<>();
        for (Payee payee : payees)
        {
            Map<Object, Object> ActionParams = new HashMap<>();
            Map<Object, Object> Params = new HashMap<>();
            Params.put("user_id", payee.getUserId());
            Params.put("amount", payee.getAmount());
            Params.put("fee", payee.getFee());
            ActionParams.put("action", Params);
            ListArray.add(ActionParams);
        }
        RepaymentParams.put("user_id", borrowUserID);
        RepaymentParams.put("special", "1");
        Repayment.put("action", RepaymentParams);
        ListArray.add(Repayment);
        investInfo.put("actions", ListArray);

        BaoFooResponse baoFooResponse = doBaoFooXMLRequest(CMD_INVEST, investInfo);
        return buildResponse(baoFooResponse);
    }

    /**
     * 提现
     *
     * @param orderID 提现订单号（唯一）
     * @param userID 用户编号(唯一)
     * @param amount 金额，单位：元
     * @param fee 平台收取的手续费, 元
     * @param bankNo 银行卡号
     * @return
     */
    @Override
    @Transactional(rollbackFor = BusinessException.class, propagation = Propagation.REQUIRES_NEW)
    public ResponseResult withdraw(String orderID, long userID, double amount, double fee, int feeTokenOn, String bankNo) throws BusinessException {
        ResponseResult responseResult = new ResponseResult();

        // 查询历史记录
        List<PayLog> payLogList = payLogMapper.queryByOrderBillCode(orderID);
        if (payLogList.size() > 1) {
            throw new BusinessException(PayResponseCode.REPEATED_PAYMENT, PayResponseCode.REPEATED_PAYMENT_MSG);
        }

        if (payLogList.size() > 0) {
            // 有记录
            PayLog payLog = payLogList.get(0);
            int status = payLog.getPayStatus();
            if (status == PayStatus.SUCCESSFUL) {
                // 成功
                responseResult.setCode(ResponseCode.OK);
                responseResult.setMsg(ResponseCode.OK_TEXT);
                responseResult.setData(payLog.getPayOrderId());
                return responseResult;
            } else if (status == PayStatus.FAILED) {
                // 失败
                responseResult.setCode(PayResponseCode.FAILED_OPERATION);
                responseResult.setMsg(PayResponseCode.FAILED_OPERATION_MSG);
                return responseResult;
            } else {
                responseResult.setCode(PayResponseCode.PENDING_OPERATION);
                responseResult.setMsg(PayResponseCode.PENDING_OPERATION_MSG);
                return responseResult;
            }
        }

        Map<String, Object> withdrawInfo = new HashMap<>();
        // 提现订单号（唯一）
        withdrawInfo.put("order_id", orderID);
        // 用户编号(唯一)
        withdrawInfo.put("user_id", userID);
        // 金额，单位：元
        withdrawInfo.put("amount", amount);
        // 平台收取的手续费, 元
        withdrawInfo.put("fee", fee);
        // 宝付手续费，收取方
        withdrawInfo.put("fee_taken_on", feeTokenOn);
        // 银行卡号
        withdrawInfo.put("bank_no", bankNo);

        PayLog payLog = new PayLog();
        payLog.setOrderBillCode(orderID);
        payLog.setPayOrderId(orderID);
        payLog.setPaySeq(1);
        payLog.setPayType(IPayService.TYPE_WITHDRAW);

        BaoFooResponse baoFooResponse = doBaoFooXMLRequest(CMD_WITHDRAW, withdrawInfo, payLog);
        return buildResponse(baoFooResponse);
    }

    /**
     * 用户之间转账
     *
     * @param orderID 订单号
     * @param payerUserID 付款方用户号
     * @param payeeUserID 收款方用户号
     * @param amount 转账金额
     * @return
     * @throws Exception
     */
    public ResponseResult transferC2C(String orderID, long payerUserID, long payeeUserID, double amount) throws BusinessException {
        Map<String, Object> transferInfo = new HashMap<>();
        // 商户号
        transferInfo.put("merchant_id", merchantID);
        // 订单号
        transferInfo.put("order_id", orderID);
        // 付款方用户号
        transferInfo.put("payer_user_id", payerUserID);
        // 收款方用户号
        transferInfo.put("payee_user_id", payeeUserID);
        // 付款方帐号类型 0为普通用户(平台的user_id) 1为商户号
        transferInfo.put("payer_type", "0");
        // 收款方帐号类型 0为普通用户(平台的user_id) 1为商户号
        transferInfo.put("payee_type", "0");
        // 转账金额
        transferInfo.put("amount", amount);
        // 手续费
        transferInfo.put("fee", "0");
        // 费用收取方0或1 0付款方1收款方
        transferInfo.put("fee_taken_on", "0");
        // 请求时间
        transferInfo.put("req_time", System.currentTimeMillis());
        BaoFooResponse baoFooResponse = doBaoFooXMLRequest(CMD_TRANSFER, transferInfo);
        return buildResponse(baoFooResponse);
    }

    /**
     * 平台向用户转账
     *
     * @param orderBillCode 订单号
     * @param userID 用户号
     * @param amount 转账金额
     * @return
     * @throws Exception
     */
    public ResponseResult transferP2C(String orderBillCode, long userID, double amount) throws BusinessException {
        BFPayStatus bfPayStatus = this.checkPayStatus(orderBillCode);
        if (bfPayStatus.isSuccess()) {
            ResponseResult responseResult = new ResponseResult();
            responseResult.setCode(ResponseCode.OK);
            responseResult.setMsg(ResponseCode.OK_TEXT);
            responseResult.setData(bfPayStatus.getPayOrderId());
            return responseResult;
        }

        if (bfPayStatus.getQueryFailedCount() > 0) {
            LOGGER.error("queryFailedCount={}", bfPayStatus.getQueryFailedCount());
            throw new BusinessException(PayResponseCode.GET_STATUS_FAILED, PayResponseCode.GET_STATUS_FAILED_MSG);
        }

        // 提交给宝付的订单ID=我们的订单ID+6位序号
        int actionType = IPayService.TYPE_TRANSFER;
        int seq = bfPayStatus.getTryCount() + 1;
        String orderID = String.format("%s%06d", orderBillCode, seq);

        Map<String, Object> transferInfo = new HashMap<>();
        // 商户号
        transferInfo.put("merchant_id", merchantID);
        // 订单号
        transferInfo.put("order_id", orderID);
        // 付款方用户号
        transferInfo.put("payer_user_id", merchantID);
        // 收款方用户号
        transferInfo.put("payee_user_id", userID);
        // 付款方帐号类型 0为普通用户(平台的user_id) 1为商户号
        transferInfo.put("payer_type", "1");
        // 收款方帐号类型 0为普通用户(平台的user_id) 1为商户号
        transferInfo.put("payee_type", "0");
        // 转账金额
        transferInfo.put("amount", amount);
        // 手续费
        transferInfo.put("fee", "0");
        // 费用收取方0或1 0付款方1收款方
        transferInfo.put("fee_taken_on", "0");
        // 请求时间
        transferInfo.put("req_time", System.currentTimeMillis());

        // 设置日志信息
        PayLog payLog = new PayLog();
        payLog.setOrderBillCode(orderBillCode);
        payLog.setPayOrderId(orderID);
        payLog.setPaySeq(seq);
        payLog.setPayType(actionType);

        BaoFooResponse baoFooResponse = doBaoFooXMLRequest(CMD_TRANSFER, transferInfo, payLog);

        // 更新宝付请求状态
        payLog.setPayResponse(baoFooResponse.getCode() + "|" + baoFooResponse.getMsg());
        payLog.setPayResponseTime(baoFooResponse.getResponseTime());
        if (baoFooResponse.isSuccessful()) {
            payLog.setPayStatus(PayStatus.SUCCESSFUL);
        } else {
            payLog.setPayStatus(PayStatus.FAILED);
        }
        payLogMapper.updatePayInfo(payLog);

        return buildResponse(baoFooResponse);
    }

    /**
     * 查询
     *
     * @param type
     * @param startTime
     * @param endTime
     * @return
     */
    @Override
    public ResponseResult query(int type, Date startTime, Date endTime) throws BusinessException {
        Map<String, Object> queryInfo = new HashMap<>();
        queryInfo.put("type", type);
        queryInfo.put("start_time", startTime.getTime());
        queryInfo.put("end_time", endTime.getTime());

        String xmlString = null;
        QueryResponse baoFooResponse = null;
        try {
            xmlString = Map2Xml.convert(queryInfo, XML_ROOT);
            baoFooResponse = doBaoFooRequest(CMD_QUERY, xmlString, false, QueryResponse.class);
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            throw new BusinessException(PayResponseCode.ERROR_UNKNOW_CODE, e.getMessage(), true);
        }

        ResponseResult responseResult = buildResponse(baoFooResponse);
        if (responseResult.getCode() == PayResponseCode.OK
                && baoFooResponse.getResult() != null &&
                !StringUtils.isEmpty(baoFooResponse.getResult())) {
            List<String> list = JSON.parseArray(baoFooResponse.getResult(), String.class);
            JSONObject order = JSON.parseObject(list.get(0));
            List<Map> orderMaps = JSON.parseArray(order.get("order").toString(), Map.class);
            responseResult.setData(orderMaps);
        }
        return responseResult;
    }

    /**
     * 根据单据编号查询
     *
     * @param type 类型
     * @param orderBillCode 单据编号
     * @return
     * @throws BusinessException
     */
    @Override
    public ResponseResult query(int type, String orderBillCode) throws BusinessException {
        Map<String, Object> queryInfo = new HashMap<>();
        queryInfo.put("type", type);
        queryInfo.put("order_id", orderBillCode);
        String xmlString = null;
        QueryByOrderResponse baoFooResponse = null;
        try {
            xmlString =  Map2Xml.convert(queryInfo, XML_ROOT);
            baoFooResponse = doBaoFooRequest(CMD_QUERY, xmlString, false, QueryByOrderResponse.class);
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            throw new BusinessException(PayResponseCode.ERROR_UNKNOW_CODE, e.getMessage(), true);
        }

        ResponseResult responseResult = buildResponse(baoFooResponse);
        if (responseResult.getCode() == PayResponseCode.OK) {
            // 拼接返回数据
            QueryByOrderResult queryByOrderResult = null;
            OrderResponse orderResponse = null;
            if (null != baoFooResponse.getResult() && baoFooResponse.getResult().size() == 1) {
                queryByOrderResult = baoFooResponse.getResult().get(0);
            }
            if (null != queryByOrderResult && queryByOrderResult.getOrder().size() == 1) {
                orderResponse = queryByOrderResult.getOrder().get(0);
            }
            if (null != orderResponse) {
                Map<String, String> data = new HashMap<>();
                data.put("orderBillCode", orderResponse.getOrder_id());
                data.put("state", Integer.toString(orderResponse.getState()));
                data.put("amount", Double.toString(orderResponse.getSucc_amount()));
                data.put("feeTakenOn", Integer.toString(orderResponse.getFee_taken_on()));
                data.put("fee", Double.toString(orderResponse.getFee()));
                data.put("baoFooFee", Double.toString(orderResponse.getBaofoo_fee()));
                data.put("time", orderResponse.getSucc_time());
                data.put("result", JSONObject.toJSONString(queryByOrderResult));
                responseResult.setData(data);
            }
        }

        return responseResult;
    }

    /**
     * 查询平台相关账户资金
     *
     * @param baofooAccountEnum 宝付账户类型类型
     * @return
     * @throws BusinessException
     */
    @Override
    public ResponseResult platformAccountQuery(BaofooAccountEnum baofooAccountEnum) throws BusinessException {
        Map<String, String> postParams = new HashMap<>();
        //帐户类型--0:全部、1:基本账户、2:未结算账户、3:冻结账户、4:保证金账户、5:资金托管账户；
        postParams.put("account_type", baofooAccountEnum.getValue().toString());
        String Md5Sing = securityUtil.baofooPlatformQueryMd5(postParams);//必须为大写
        postParams.put("sign", Md5Sing);
        String returnString = doPlatformRequest(postParams);
        BigDecimal data = buildPlatformResponse(returnString);
        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(PayResponseCode.OK);
        responseResult.setData(data);
        return responseResult;
    }

    /**
     * 查询excel生成流水
     * @param startTime
     * @param endTime
     * @return
     * @throws BusinessException
     */
    @Override
    public ResponseResult queryTranscationExcel(Date startTime, Date endTime) throws BusinessException {
        Map<String, Object> queryInfo = new HashMap<>();
        queryInfo.put("start_time", startTime.getTime());
        queryInfo.put("end_time", endTime.getTime());

        String xmlString;
        ResponseResult responseResult = new ResponseResult();
        String fileName = "transcation_excel_"+System.currentTimeMillis() + ".xls";
        try {
            xmlString = Map2Xml.convert(queryInfo, XML_ROOT);
            String filePath = invokeHttpFileRequest(CMD_QUERY_EXCEL, xmlString, fileName);
            if (filePath != null) {
                responseResult.setCode(PayResponseCode.OK);
                responseResult.setData(filePath);
            } else {
                responseResult.setCode(PayResponseCode.ERROR_UNKNOW_CODE);
            }
            return responseResult;
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            throw new BusinessException(PayResponseCode.ERROR_UNKNOW_CODE, e.getMessage(), true);
        }
    }

    /**
     * 宝付请求，默认不加密（XML），不记录日志表
     *
     * @param command
     * @param info
     * @return
     * @throws BusinessException
     */
    private BaoFooResponse doBaoFooXMLRequest(int command, Map<String, Object> info) throws BusinessException {
        return doBaoFooXMLRequest(command, info, false, null);
    }

    /**
     * 宝付请求，默认不加密（XML）
     *
     * @param command
     * @param info
     * @param payLog
     * @return
     * @throws BusinessException
     */
    private BaoFooResponse doBaoFooXMLRequest(int command, Map<String, Object> info, PayLog payLog) throws BusinessException {
        return doBaoFooXMLRequest(command, info, false, payLog);
    }

    /**
     * 宝付请求（XML）
     *
     * @param command
     * @param info
     * @return
     * @throws BusinessException
     */
    private BaoFooResponse doBaoFooXMLRequest(int command, Map<String, Object> info, boolean encrypt, PayLog payLog) throws BusinessException {
        BaoFooResponse baoFooResponse = null;
        try {
            String xmlString = Map2Xml.convert(info, XML_ROOT);
            Date start = new Date();

            if (null != payLog) {
                // 记录宝付请求日志
                payLog.setPayStatus(PayStatus.PENDING);
                payLog.setPayRequest(xmlString);
                payLog.setPayRequestTime(start);
                payLogMapper.insert(payLog);
            }

            baoFooResponse = doBaoFooRequest(command, xmlString, encrypt);
            Date end = new Date();
            baoFooResponse.setResponseTime(end);
        } catch (SocketTimeoutException socketTimeoutException) {
            LOGGER.error("doBaoFooXMLRequest socket time out error.", socketTimeoutException);
            throw new BusinessException(PayResponseCode.SOCKET_TIMEOUT_ERROR_CODE, PayResponseCode.SOCKET_TIMEOUT_ERROR_MSG, true);
        } catch (Exception e) {
            LOGGER.error("doBaoFooXMLRequest error.", e);
            throw new BusinessException(PayResponseCode.ERROR_UNKNOW_CODE, e.getMessage(), true);
        }

        return baoFooResponse;
    }

    /**
     * 默认不加密
     *
     * @param command
     * @param data
     * @return
     * @throws Exception
     */
    private BaoFooResponse doBaoFooRequest(int command, String data) throws Exception {
        return doBaoFooRequest(command, data, false);
    }

    /**
     * 默认解析code/msg/sign
     *
     * @param command
     * @param data
     * @param encrypt
     * @return
     * @throws Exception
     */
    private BaoFooResponse doBaoFooRequest(int command, String data, boolean encrypt) throws Exception {
        return doBaoFooRequest(command, data, encrypt, BaoFooResponse.class);
    }

    /**
     * 宝付统一接口封装
     *
     * @param command 指令类型
     * @param data 参数数据
     * @param encrypt 请求参数是否加密
     * @param clazz 返回值解析类
     * @param <T> 返回值类型
     * @return
     * @throws Exception
     */
    private <T> T doBaoFooRequest(int command, String data, boolean encrypt, Class<T> clazz) throws Exception {
        String requestUrl = getUrl(command);
        String requestParams = data;
        LOGGER.info("doBaofooRequest url={}, requestParams={}", requestUrl, requestParams);
        if (encrypt) {
            requestParams = securityUtil.encryptAES(data);
            LOGGER.info("doBaofooRequest request param encrypt. requestParam={}", requestParams);
        }

        // HTTP调用宝付接口
        String result = invokeCustodyHttpRequest(requestUrl, requestParams);

        // XML数据转JSON
        JSONObject jsonObject = XmlTool.xml2Json(result);

        // JSON数据转对象
        T baoFooResponse = jsonObject.toJavaObject(clazz);

        return baoFooResponse;
    }

    private String doPlatformRequest( Map<String, String> requestParams) throws BusinessException {
        try {
            String returnString = invokePlatformHttpRequest(platformUrl, requestParams);
            return returnString;
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            throw new BusinessException(PayResponseCode.ERROR_UNKNOW_CODE, e.getMessage(), true);
        }
    }

    /**
     * 发送HTTP（POST）请求到宝付服务器
     *
     * @param requestUrl
     * @param requestParams
     * @return
     * @throws Exception
     */
    private String invokePlatformHttpRequest(String requestUrl, Map<String, String> requestParams) throws Exception {
        //	商户号
        requestParams.put("member_id", merchantID);
        //	终端号
        requestParams.put("terminal_id", terminalID);
        //	返回报文数据类型xml 或json
        requestParams.put("return_type", "json");
        //	交易码
        requestParams.put("trans_code", "BF0001");
        //版本号
        requestParams.put("version", "4.0");
        String sign = securityUtil.baofooPlatformQueryMd5(requestParams);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("sign=" + sign);
        }

        RequestBody formBody = new FormBody.Builder()
                .add("member_id", requestParams.get("member_id"))
                .add("terminal_id", requestParams.get("terminal_id"))
                .add("return_type", requestParams.get("return_type"))
                .add("trans_code", requestParams.get("trans_code"))
                .add("account_type", requestParams.get("account_type"))
                .add("version", requestParams.get("version"))
                .add("sign", sign)
                .build();
        Request request = new Request.Builder()
                .url(requestUrl)
                .post(formBody)
                .build();
        LOGGER.info("doBaofooRequest url={}, requestParams={}", requestUrl, JSON.toJSON(requestParams));
        Response response = okHttpClient.newCall(request).execute();
        if (response.isSuccessful()) {
            String result = response.body().string();
            LOGGER.info("invokeHttpRequest response success. result={}", result);
            return result;
        } else {
            throw new Exception("Unexpected code: " + response);
        }
    }


    /**
     * 发送HTTP（POST）请求到宝付服务器
     *
     * @param requestUrl
     * @param requestParams
     * @return
     * @throws Exception
     */
    private String invokeCustodyHttpRequest(String requestUrl, String requestParams) throws Exception {
        String sign = securityUtil.encryptMD5(requestParams);
        LOGGER.info("invokeHttpRequest sign. sign={}", sign);

        RequestBody formBody = new FormBody.Builder()
                .add("merchant_id", merchantID)
                .add("terminal_id", terminalID)
                .add("requestParams", requestParams)
                .add("sign", sign)
                .build();
        Request request = new Request.Builder()
                .url(requestUrl)
                .post(formBody)
                .build();
        Response response = okHttpClient.newCall(request).execute();
        if (response.isSuccessful()) {
            String result = response.body().string();
            LOGGER.info("invokeHttpRequest response success. result={}", result);
            return result;
        } else {
            throw new Exception("Unexpected code: " + response);
        }
    }

    private String invokeHttpFileRequest(int command,  String requestParams, String fileName) throws Exception {
        String requestUrl = getUrl(command);
        String sign = securityUtil.encryptMD5(requestParams);
        return HttpDownload.download(fileName, requestUrl, merchantID, terminalID,requestParams, sign);
    }

    private final static int CMD_REGISTER = 1;

    private final static int CMD_VERIFY_CODE = 2;

    private final static int CMD_ACCOUNT_BALANCE = 3;

    private final static int CMD_BIND_BANK_CARD = 4;

    private final static int CMD_INVEST = 5;

    private final static int CMD_WITHDRAW = 6;

    private final static int CMD_TRANSFER = 7;

    private final static int CMD_TRANSFER_BATCH = 8;

    private final static int CMD_ALL_ACCOUNT_BALANCE = 9;

    private final static int CMD_QUERY = 10;

    private final static int CMD_ACCOUNT_BIND_VERIFY_CODE = 11;

    private final static int CMD_QUERY_EXCEL = 12;

    private final static int CMD_GET_BAOFOO_RECHARGE_ID = 13;


    /**
     获取宝付请求URI地址
     *
     *  1. CMD_REGISTER 注册开户<br>
     *  2. CMD_VERIFY_CODE 银行卡绑定验证码<br>
     *  3. CMD_ACCOUNT_BALANCE 账户余额<br>
     *  4. CMD_BIND_BANK_CARD 个人服务端绑卡<br>
     *  5. CMD_INVEST 投资<br>
     *  6. CMD_WITHDRAW 提现接口<br>
     *  7. CMD_TRANSFER 转账接口<br>
     *  8. CMD_TRANSFER_BATCH 批量转账接口<br>
     *  9. CMD_ALL_ACCOUNT_BALANCE 托管账户余额总额<br>
     *  10. CMD_QUERY 查询接口<br>
     *
     * @param Url_Id
     * @return
     */
    private String getUrl(int Url_Id){

        String realUrl = url;

        switch (Url_Id)
        {
            case CMD_REGISTER:
                realUrl += "quickRegister.do";
                break;
            case CMD_VERIFY_CODE:
                realUrl += "sendBindCodeById.do";
                break;
            case CMD_ACCOUNT_BALANCE:
                realUrl += "accountBalance.do";
                break;
            case CMD_BIND_BANK_CARD:
                realUrl += "addBankCard.do";
                break;
            case CMD_INVEST:
                realUrl += "p2pRequest.do";
                break;
            case CMD_WITHDRAW:
                realUrl += "foChargeNew.do";
                break;
            case CMD_TRANSFER:
                realUrl += "acctTrans.do";
                break;
            case CMD_TRANSFER_BATCH:
                realUrl += "foChargePageNew.do";
                break;
            case CMD_ALL_ACCOUNT_BALANCE:
                realUrl += "accountAllBalance.do";
                break;
            case CMD_QUERY:
                realUrl += "p2pQuery.do";
                break;
            case CMD_ACCOUNT_BIND_VERIFY_CODE:
                realUrl += "sendBindCode.do";
                break;
            case CMD_QUERY_EXCEL:
                realUrl += "queryExport.do";
                break;
            case CMD_GET_BAOFOO_RECHARGE_ID:
                realUrl += "cerPayRechargeSdk.do";
            default:
                break;
        }

        return realUrl;
    }

    /**
     * 宝付支付状态
     *
     */
    private class BFPayStatus {

        /**
         * 是否成功
         */
        private boolean success;

        /**
         * 已尝试次数
         */
        private int tryCount;

        /**
         * 查询失败次数
         */
        private int queryFailedCount;

        /**
         * 成功的orderId
         */
        private String payOrderId;

        public boolean isSuccess() {
            return success;
        }

        public void setSuccess(boolean success) {
            this.success = success;
        }

        public int getTryCount() {
            return tryCount;
        }

        public void setTryCount(int tryCount) {
            this.tryCount = tryCount;
        }

        public int getQueryFailedCount() {
            return queryFailedCount;
        }

        public void setQueryFailedCount(int queryFailedCount) {
            this.queryFailedCount = queryFailedCount;
        }

        public String getPayOrderId() {
            return payOrderId;
        }

        public void setPayOrderId(String payOrderId) {
            this.payOrderId = payOrderId;
        }
    }

    /**
     * 检查订单的支付状态
     *
     * @param orderBillCode
     * @return
     */
    private BFPayStatus checkPayStatus(String orderBillCode) {
        BFPayStatus bfPayStatus = new BFPayStatus();
        bfPayStatus.setSuccess(false);

        // 查询历史记录
        LOGGER.info("before queryByOrderBillCode");
        List<PayLog> payLogList = payLogMapper.queryByOrderBillCode(orderBillCode);
        LOGGER.info("after queryByOrderBillCode");
        int max = 0;
        int queryFailedCount = 0;
        for (PayLog payLog : payLogList) {
            int status = payLog.getPayStatus();
            if (payLog.getPaySeq() > max) {
                max = payLog.getPaySeq();
            }
            if (status == PayStatus.SUCCESSFUL) {
                // 有成功的，返回成功
                bfPayStatus.setSuccess(true);
                bfPayStatus.setPayOrderId(payLog.getPayOrderId());
                break;
            } else if (status == PayStatus.PENDING) {
                // 可能是没有收到结果，再查询一遍
                int type = payLog.getPayType();
                String orderID = payLog.getPayOrderId();
                ResponseResult result = null;
                try {
                    result = this.query(type, orderID);
                    if (result.isSuccessful()) {
                        Map<String, Object> orderInfo = (Map<String, Object>)result.getData();
                        PayLog pendingPayLog = new PayLog();
                        pendingPayLog.setPayResponse(orderInfo.get("result").toString());
                        int state = Integer.parseInt(orderInfo.get("state").toString());
                        if (state == 1) {
                            // 查询到有成功的，返回成功
                            pendingPayLog.setPayStatus(PayStatus.SUCCESSFUL);
                            payLogMapper.updatePayInfo(pendingPayLog);
                            bfPayStatus.setSuccess(true);
                            bfPayStatus.setPayOrderId(payLog.getPayOrderId());
                            break;
                        } else {
                            pendingPayLog.setPayStatus(PayStatus.FAILED);
                            payLogMapper.updatePayInfo(pendingPayLog);
                        }
                    } else {
                        LOGGER.error(result.getMsg());
                        queryFailedCount++;
                    }
                } catch (BusinessException e) {
                    LOGGER.error(e.getMessage());
                    queryFailedCount++;
                }
            }
        }

        bfPayStatus.setQueryFailedCount(queryFailedCount);
        bfPayStatus.setTryCount(max);
        return bfPayStatus;
    }
}
