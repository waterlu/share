package cn.zjhf.kingold.trade.entity.InVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * Created by zhangyijie on 2018/1/30.
 */
@ApiModel(value = "DeleteCouponSpecifiedDistributionVO", description = "删除未审核通过的指定发放批次")
public class DeleteCouponSpecifiedDistributionVO extends InVOBase {
    @ApiModelProperty(required = true, value = "审核编号")
    @NotEmpty
    private Long auditId;

    @ApiModelProperty(required = true, value = "删除人")
    @NotEmpty
    private String deleteOperator;

    public Long getAuditId() {
        return auditId;
    }

    public void setAuditId(Long auditId) {
        this.auditId = auditId;
    }

    public String getDeleteOperator() {
        return deleteOperator;
    }

    public void setDeleteOperator(String deleteOperator) {
        this.deleteOperator = deleteOperator;
    }

    @Override
    public String toString() {
        return "DeleteCouponSpecifiedDistributionVO{" +
                "auditId=" + auditId +
                ", deleteOperator='" + deleteOperator + '\'' +
                '}';
    }
}
