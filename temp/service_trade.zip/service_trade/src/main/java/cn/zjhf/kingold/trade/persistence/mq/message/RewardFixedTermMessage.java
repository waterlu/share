package cn.zjhf.kingold.trade.persistence.mq.message;

import cn.zjhf.kingold.rocketmq.base.MQMessage;
import cn.zjhf.kingold.trade.entity.RewardFixedTerm;

/**
 * Created by Xiaody on 17/7/27.
 */
public class RewardFixedTermMessage implements MQMessage {

    private RewardFixedTerm rewardFixedTerm;

    public RewardFixedTerm getRewardFixedTerm() {
        return rewardFixedTerm;
    }

    public void setRewardFixedTerm(RewardFixedTerm rewardFixedTerm) {
        this.rewardFixedTerm = rewardFixedTerm;
    }

    @Override
    public String getKey() {
        return getRewardFixedTerm().getRewardFixedBillCode();
    }
}
