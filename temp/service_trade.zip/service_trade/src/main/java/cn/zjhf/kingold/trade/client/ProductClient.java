package cn.zjhf.kingold.trade.client;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * @author xiaody
 * @description
 * @date create in 17/11/7
 */
@FeignClient(value = "service-core-product",fallback = ProductFallback.class)
//@RequestMapping(value = "/product",consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE})
public interface ProductClient {

    /**
     * 创建产品
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/product", method = RequestMethod.POST)
    ResponseResult insert(@RequestBody Map params) throws BusinessException;

    /**
     * 获取产品信息
     *
     * @param productUuid
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/product/{productUuid}", method = RequestMethod.GET)
    ResponseResult get(@PathVariable(value = "productUuid") String productUuid, @RequestParam Map params) throws BusinessException;

    /**
     * 修改产品信息
     *
     * @param productUuid
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/product/{productUuid}", method = RequestMethod.PUT, consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    ResponseResult update(@PathVariable(value = "productUuid") String productUuid, @RequestBody Map params) throws BusinessException;

    /**
     * 修改产品信息到置顶
     *
     * @param productUuid
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/product/top/{productUuid}", method = RequestMethod.PUT)
    ResponseResult top(@PathVariable(value = "productUuid") String productUuid, @RequestBody Map params) throws BusinessException;

    /**
     * 通用报表处理
     * @param param
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/product/lstByCondition", method = RequestMethod.GET)
    ResponseResult lstByCondition(@RequestParam Map<String, Object> param) throws BusinessException;

    /**
     * 根据查询条件获取产品列表
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/product/list", method = RequestMethod.GET)
    ResponseResult getList(@RequestParam Map params) throws BusinessException;

    /**
     * 根据查询条件获取产品数量
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/product/count", method = RequestMethod.GET)
    ResponseResult count(@RequestParam Map params) throws BusinessException;

    /**
     * 根据查询条件获取产品列表,过滤掉给定渠道下已有产品
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/product/channelNonExistProductList", method = RequestMethod.GET)
    ResponseResult channelNonExistProductList(@RequestParam Map params) throws BusinessException;

    /**
     * 根据查询条件获取产品列表,过滤掉给定渠道下已有产品数量
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/product/channelNonExistProductCount", method = RequestMethod.GET)
    ResponseResult channelNonExistProductCount(@RequestParam Map params) throws BusinessException;

    /**
     * 获取私募产品详情
     *
     * @param productUuid
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/product/privateFund/{productUuid}", method = RequestMethod.GET)
    ResponseResult getPrivateFund(@PathVariable(value = "productUuid") String productUuid, @RequestParam Map params) throws BusinessException;

    /**
     * 获取固收产品详情
     *
     * @param productUuid
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/product/fixedIncome/{productUuid}", method = RequestMethod.GET)
    ResponseResult getFixedIncome(@PathVariable(value = "productUuid") String productUuid, @RequestParam Map params) throws BusinessException;

    /**
     * 获取固收产品和渠道详情
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/product/channel/fixedIncome", method = RequestMethod.GET)
    ResponseResult getFixedIncomeChannel(@RequestParam Map params) throws BusinessException;

    /**
     * 修改募集金额
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/product/updateAccumulation", method = RequestMethod.PUT, consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    ResponseResult updateAccumulation(@RequestBody Map params) throws BusinessException;

    /**
     * 根据查询条件获取私募产品列表
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/product/privateFund/list", method = RequestMethod.GET)
    ResponseResult getPrivateFundList(@RequestParam Map params) throws BusinessException;

    /**
     * 根据查询条件获取私募产品数量
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/product/privateFund/count", method = RequestMethod.GET)
    ResponseResult privateFundCount(@RequestParam Map params) throws BusinessException;

    /**
     * 根据查询条件获取固收产品列表
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/product/fixedIncome/list", method = RequestMethod.GET)
    ResponseResult getFixedIncomeList(@RequestParam Map params) throws BusinessException;

    /**
     * 根据查询条件获取固定产品数量
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/product/fixedIncome/count", method = RequestMethod.GET)
    ResponseResult fixedIncomeCount(@RequestParam Map params) throws BusinessException;


    /**
     * 获取产品奖励细则列表
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/product/reward/list", method = RequestMethod.GET)
    ResponseResult rewardList(@RequestParam Map params) throws BusinessException;

    /**
     * 获取产品奖励细则数量
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/product/reward/count", method = RequestMethod.GET)
    ResponseResult rewardCount(@RequestParam Map params) throws BusinessException;

    /**
     * 添加 产品-渠道 关联关系
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/product/addProductChannelRelational", method = RequestMethod.POST)
    ResponseResult addProductChannelRelational(@RequestBody ProductChannelRelationalVO productChannelRelationalVO) throws BusinessException;

    /**
     * 查询 产品-渠道 关联关系列表
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/product/lstProductChannelRelationals", method = RequestMethod.GET)
    ResponseResult lstProductChannelRelationals(@RequestParam Map<String, Object> param) throws BusinessException;

    /**
     * 获取产品说明书编码
     * @param productUuid
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/product/descriptionCode/{productUuid}", method = RequestMethod.GET)
    ResponseResult getDescriptionCode(@PathVariable(value = "productUuid") String productUuid, @RequestParam Map params) throws BusinessException;

    /**
     * 获取限制子产品集合
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/product/getFixedProducts", method = RequestMethod.GET)
    ResponseResult getFixedProducts(@RequestParam Map params) throws BusinessException;

    /**
     * 更新产品剩余募集金额
     *
     * @param uuid
     * @param param
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/product/{uuid}/raise", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
    ResponseResult updateRaise(@PathVariable(value = "uuid") String uuid, @RequestBody ProductRemainDTO param) throws BusinessException;
}
