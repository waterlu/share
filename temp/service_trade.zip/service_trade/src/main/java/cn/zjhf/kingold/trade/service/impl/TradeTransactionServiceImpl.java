package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.common.utils.CacheUtil;
import cn.zjhf.kingold.service_consumer.service.GeneralServiceConsumer;
import cn.zjhf.kingold.service_consumer.service.UserServiceConsumer;
import cn.zjhf.kingold.trade.client.ProductClient;
import cn.zjhf.kingold.trade.client.ProductRemainDTO;
import cn.zjhf.kingold.trade.constant.*;
import cn.zjhf.kingold.trade.dto.BillDto;
import cn.zjhf.kingold.trade.dto.UpdateTradeStatusDTO;
import cn.zjhf.kingold.trade.entity.InVO.CouponExtendRecordVO;
import cn.zjhf.kingold.trade.entity.TradeOrder;
import cn.zjhf.kingold.trade.entity.TradeRecharge;
import cn.zjhf.kingold.trade.exception.*;
import cn.zjhf.kingold.trade.lock.DistributedLock;
import cn.zjhf.kingold.trade.persistence.dao.AccountBaofooCustodyMapper;
import cn.zjhf.kingold.trade.persistence.dao.OperationReportMapper;
import cn.zjhf.kingold.trade.persistence.dao.TradeOrderMapper;
import cn.zjhf.kingold.trade.service.IAccountService;
import cn.zjhf.kingold.trade.service.ICouponExtendRecordService;
import cn.zjhf.kingold.trade.service.IPayService;
import cn.zjhf.kingold.trade.service.ITradeTransactionService;
import cn.zjhf.kingold.trade.utils.DataUtils;
import cn.zjhf.kingold.trade.utils.MapParamUtils;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.google.common.base.Strings;
import org.apache.commons.collections.map.HashedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.security.auth.login.AccountException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 投资事务逻辑
 *
 * @author lutiehua
 * @date 2017/6/26
 */
@Service
public class TradeTransactionServiceImpl implements ITradeTransactionService {

    private final static Logger LOGGER = LoggerFactory.getLogger(TradeTransactionServiceImpl.class);

    @Autowired
    private TradeOrderMapper tradeOrderMapper;

    @Autowired
    private OperationReportMapper operationReportMapper;

    @Autowired
    private AccountBaofooCustodyMapper accountBaofooMapper;

    @Autowired
    private IAccountService accountService;

    @Autowired
    private ICouponExtendRecordService couponExtendRecordService;

    @Autowired
    private IPayService payService;

    @Autowired
    private AccountBaofooServiceImpl accountBaofooService;

    @Autowired
    private ProductClient productClient;

    @Autowired
    private DistributedLock redisLock;

    @Autowired
    private UserServiceConsumer userServiceConsumer;

    @Autowired
    private GeneralServiceConsumer selfServiceConsumer;

    @Override
    @Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
    public ResponseResult invest(TradeOrder order) throws BusinessException {
        ResponseResult responseResult = new ResponseResult();

        String orderBillCode = order.getOrderBillCode();
        String accountUuid = order.getAccountUuid();
        BigDecimal orderAmount = order.getOrderAmount();
        BigDecimal paidAmount = order.getPaidAmount();
        String userUuid = order.getUserUuid();
        String productUuid = order.getProductUuid();

        LOGGER.info("确认认购开始:产品=[{}]，用户=[{}], 金额=[{}]", productUuid, userUuid, orderAmount);

        // 锁定5秒钟
        String key = String.format("lock:invest:user:%s", userUuid);
        long seconds = 5;
        int times = 50;
        int count = 0;
        int interval = 100;
        boolean locked = false;
        locked = redisLock.lock(key, seconds);
        while(!locked && count < times) {
            try {
                Thread.sleep(interval);
            } catch (InterruptedException e) {
                throw new LockException(key);
            }
            count++;
            locked = redisLock.lock(key, seconds);
        }

        if (!locked) {
            // 并发时没有抢到锁，失败
            LOGGER.error("没有抢到锁[{}]", key);
            throw new LockException(key);
        }

        try {

            /**
             * 更新本地事务状态
             */

            // 修改订单状态和实付金额和预期收益
            LOGGER.info("更新订单状态");
            updateOrderInfo(order);

            // 调用扣账户余额接口
            LOGGER.info("扣账户余额");
            if(accountService.invest(order) <= 0) {
                LOGGER.error("扣账户[{}]余额失败", accountUuid);
//                throw new PayOrderException();
                throw new BusinessException(TradeStatusMsg.FREEZE_ACCOUNT_CASH_FAILED, TradeStatusMsg.FREEZE_ACCOUNT_CASH_FAILED_TXT);
            }
            LOGGER.info("扣账户[{}]余额成功", accountUuid);

            // 使用优惠券
            // TODO 拆分优惠券服务时需要重构，以下代码需要挪到优惠券服务中
            String couponExtendCode = order.getStrategyIds();
            if(!Strings.isNullOrEmpty(couponExtendCode)) {
                LOGGER.info("使用优惠券");
                CouponExtendRecordVO couponExtendRecordVO = couponExtendRecordService.lstCouponExtendRecord(couponExtendCode);
                if (null == couponExtendRecordVO) {
//                    throw new CouponUseException();
                    throw new BusinessException(TradeStatusMsg.NO_COUPON, TradeStatusMsg.NO_COUPON_TXT);
                }

                // 检查逻辑删除标识
                if (couponExtendRecordVO.getDeleteFlag() != 0) {
                    throw new BusinessException(TradeStatusMsg.NO_COUPON, TradeStatusMsg.NO_COUPON_TXT);
                }

                // 检查状态，必须是已发放状态（已使用/已过期/已作废肯定不行，已转让应该也不行）
                if (couponExtendRecordVO.getCouponStatus() != CouponExtendRecordServiceImpl.STATUS_EXTEND) {
//                    throw new CouponUseException();
                    throw new BusinessException(TradeStatusMsg.WRONG_COUPON_STATUS, TradeStatusMsg.WRONG_COUPON_STATUS_TXT);
                }

                // 检查过期
                long now = System.currentTimeMillis();
                if (null != couponExtendRecordVO.getValidStartTime()) {
                    long startTime = couponExtendRecordVO.getValidStartTime().getTime();
                    if (now < startTime) {
                        //throw new CouponUseException();
                        throw new BusinessException(TradeStatusMsg.COUPON_EXPIRED, TradeStatusMsg.COUPON_EXPIRED_TXT);
                    }
                }
                if (null != couponExtendRecordVO.getValidEndTime()) {
                    long endTime = couponExtendRecordVO.getValidEndTime().getTime();
                    if (now > endTime) {
                        //throw new CouponUseException();
                        throw new BusinessException(TradeStatusMsg.COUPON_EXPIRED, TradeStatusMsg.COUPON_EXPIRED_TXT);
                    }
                }

                // 变更优惠券状态为已使用
                if (couponExtendRecordService.useCouponExtendRecord(couponExtendCode, orderBillCode, userUuid) <= 0) {
                    LOGGER.error("使用优惠券[{}]失败", couponExtendCode);
                    //throw new CouponUseException();
                    throw new BusinessException(TradeStatusMsg.COUPON_USED, TradeStatusMsg.COUPON_USED_TXT);
                }
            }

            /**
             * 更新远程事务状态
             */

            // 远程调用产品服务，更新产品募集金额
            LOGGER.info("更新产品募集金额");
            ProductRemainDTO productRemain = new ProductRemainDTO();
            productRemain.setUserUuid(userUuid);
            productRemain.setOrderBillCode(orderBillCode);
            productRemain.setAmount(order.getOrderAmount());
            productRemain.setTraceID(CacheUtil.getTraceID());
            ResponseResult productResult = productClient.updateRaise(productUuid, productRemain);
            if (!productResult.isSuccessful()) {
                LOGGER.error("扣产品剩余募集金额失败：{}", productResult.getMsg());
                throw new BusinessException(productResult.getCode(), productResult.getMsg());
            }
            LOGGER.info("扣产品剩余募集金额成功");

            // TODO 如果是新手标，远程调用用户服务，更新用户交易状态
            if (order.getProductRookieFlag() == 1) {
                LOGGER.info("更新用户交易状态");
                UpdateTradeStatusDTO updateTradeStatusDTO = new UpdateTradeStatusDTO();
                updateTradeStatusDTO.setOrderBillCode(orderBillCode);
                updateTradeStatusDTO.setTraceID(CacheUtil.getTraceID());
                String uri = String.format("/user/%s/updateTradeStatus", userUuid);
                ResponseResult result = userServiceConsumer.put(uri, updateTradeStatusDTO);
                if (result.isSuccessful()) {
                    int updateFlag = Integer.parseInt(result.getData().toString());
                    if (updateFlag != 1) {
                        LOGGER.info("新手标更新用户交易状态失败");
                        throw new RookieCheckFailException();
                    }
                    LOGGER.info("新手标更新用户交易状态成功");
                } else {
                    LOGGER.info("新手标更新用户交易状态异常");
                    throw new BusinessException(result.getCode(), result.getMsg());
                }
            }

            // 调用扣账户余额接口
    //        String url = String.format("http://localhost:8051/account/%s/invest", order.getAccountUuid());
    //        String jsonString = JSON.toJSONString(order);
    //        Map<String, Object> accountParam = JSON.parseObject(jsonString, new TypeReference<HashMap<String, Object>>(){});
    //        ResponseResult accountResult = selfServiceConsumer.post(url, accountParam);
    //        if (!accountResult.isSuccessful()) {
    //            LOGGER.error("扣账户余额失败：{}", accountResult.getMsg());
    //            throw new BusinessException(accountResult.getCode(), accountResult.getMsg());
    //        }
    //        int row = Integer.parseInt(accountResult.getData().toString());
    //        if (row <= 0) {
    //            LOGGER.error("扣账户金额失败：row=0");
    //            throw new AccountBalanceException(new HashMap<>());
    //        }
    //        LOGGER.info("扣账户余额成功");

            // 调用支付接口（远程调用宝付接口）
            LOGGER.info("调用支付接口");
            long payerAccountNo = Long.parseLong(order.getAccountNo());
            payService.invest(orderBillCode, order.getProductID(), order.getProductAbbrName(), order.getPayeeAccountNo(),
                    payerAccountNo, paidAmount.doubleValue());

            responseResult.setCode(ResponseCode.OK);
            responseResult.setMsg(ResponseCode.OK_TEXT);
            responseResult.setData(order);
            LOGGER.info("确认认购完成");
            return responseResult;
        } finally {
            redisLock.unlock(key);
        }
    }

//    @Override
//    public boolean checkPay(TradeOrderMessage order) throws BusinessException {
//        String orderBillCode = order.getOrderBillCode();
//        List<PayLog> payLogList = payLogMapper.queryByOrderBillCode(orderBillCode);
//        for (PayLog payLog : payLogList) {
//            int status = payLog.getPayStatus();
//            if (status == PayStatus.SUCCESSFUL) {
//                return true;
//            } else if (status == PayStatus.PENDING) {
//                int type = payLog.getPayType();
//                String orderID = payLog.getPayOrderId();
//                ResponseResult result = payService.query(type, orderID);
//                if (result.isSuccessful()) {
//                    Map<String, Object> orderInfo = (Map<String, Object>)result.getData();
//                    PayLog pendingPayLog = new PayLog();
//                    pendingPayLog.setPayResponse(orderInfo.get("result").toString());
//                    int state = Integer.parseInt(orderInfo.get("state").toString());
//                    if (state == 1) {
//                        pendingPayLog.setPayStatus(PayStatus.SUCCESSFUL);
//                        payLogMapper.updatePayInfo(pendingPayLog);
//                        return true;
//                    } else {
//                        pendingPayLog.setPayStatus(PayStatus.FAILED);
//                        payLogMapper.updatePayInfo(pendingPayLog);
//                    }
//                } else {
//                    LOGGER.error(result.getMsg());
//                }
//            }
//        }
//
//        return false;
//    }

    /**
     * 宝付提现成功后，设置账户系统冻结账户金额
     * @param tradeRecharge
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = BusinessException.class)
    public ResponseResult successWithDraw(TradeRecharge tradeRecharge) throws BusinessException {
        Map baofooParams = new HashMap();
        baofooParams.put("userUuid", tradeRecharge.getUserUuid());
        List bankList = accountBaofooService.getBankCardList(baofooParams);
        String bankNo = "";
        if (bankList != null && bankList.size() > 0) {
            bankNo = ((Map<String, String>) bankList.get(0)).get("bankUserCardNo");
        }

        Double amount = tradeRecharge.getRechargeAmount().doubleValue();
        int feeType = tradeRecharge.getRechargeFeeType();
        String accountUuid = tradeRecharge.getAccountUuid();

        //调用账户提现操作
        BillDto wod = new BillDto( tradeRecharge.getRechargeBillCode(), TradeType.TRADE_WITH_DROW, new BigDecimal(amount + ""), accountUuid,"");
        wod.setTransactionChannel(tradeRecharge.getTransactionChannel());
        accountService.freezeCashEntity(wod);

        //调用账户手续费操作
        Map platformMap = accountService.getSysAccountByType(AccountType.ACCOUNT_TYPE_PLATFORM_SETTLEMENT);
        String platformAccountUuid = MapParamUtils.getStringInMap(platformMap, "accountUuid");

        BillDto fod = new BillDto( tradeRecharge.getRechargeBillCode(), TradeType.TRADE_WITHDRAW_FACTORAGE, tradeRecharge.getRechargeFee(), accountUuid,"");
        fod.setTransactionChannel(tradeRecharge.getTransactionChannel());
        if (feeType == PayMsg.FEE_TOKEN_ON_PLATFORM) {
            fod.setAccountUuid(platformAccountUuid);
        } else if (feeType == PayMsg.FEE_TOKEN_ON_PERSON) {
            fod.setAccountUuid(accountUuid);
        }

        accountService.freezeCashEntity(fod);

        // 调用宝付提现接口
        String billCode = tradeRecharge.getRechargeBillCode();
        long accountNo = Long.parseLong(tradeRecharge.getAgencyAccountNo());
        ResponseResult responseResult;
        try {
            responseResult = payService.withdraw(billCode, accountNo, amount, 0, feeType, bankNo);
        } catch (BusinessException e) {
            if (e.getErrorCode() != PayResponseCode.SOCKET_TIMEOUT_ERROR_CODE) {
                throw e;
            }
            responseResult = new ResponseResult();
            responseResult.setCode(PayResponseCode.OK);
            responseResult.setMsg(PayResponseCode.SOCKET_TIMEOUT_ERROR_MSG);
        }
        if (!responseResult.isSuccessful()) {
            // 如果出现了重复操作，并且上一个操作还没有完成，这里抛出异常回滚账户操作，外面捕获异常
            throw new BusinessException(responseResult.getCode(), responseResult.getMsg());
        }

        responseResult.setData(billCode);
        return responseResult;
    }

    /**
     * 修改订单状态和支付信息
     *
     * @param order
     * @throws BusinessException
     */
    private boolean updateOrderInfo(TradeOrder order) throws BusinessException {
        Map<String, Object> updateMap = new HashMap<>(16);
        updateMap.put("orderBillCode", order.getOrderBillCode());
        updateMap.put("orderStatus", TradeStatus.ORDER_STATUS_INVEST);
        updateMap.put("orderPayStatus", TradeOrderConstant.ORDER_PAY_STATUS_PAID);
        updateMap.put("marketingAmount", order.getMarketingAmount());
        updateMap.put("paidAmount", order.getPaidAmount());
        updateMap.put("expectedProfitAmount", order.getExpectedProfitAmount());
        updateMap.put("marketingRateAmount", order.getMarketingRateAmount());
        updateMap.put("profitAmount", order.getProfitAmount());
        String couponExtendCode = order.getStrategyIds();
        if(DataUtils.isNotEmpty(couponExtendCode)) {
            updateMap.put("strategyIds", couponExtendCode);
        }
        updateMap.put("payedTime", order.getPayedTime());

        LOGGER.info("tradeOrderMapper.updatePaySuccessStatus begin: " + DataUtils.toString(updateMap));
        int row = tradeOrderMapper.updatePaySuccessStatus(updateMap);
        if (row == 0) {
            throw new BusinessException(TradeStatusMsg.PAID_ORDER, TradeStatusMsg.PAID_ORDER_MSG);
        }
        LOGGER.info("tradeOrderMapper.updatePaySuccessStatus end: ");
        return true;
    }
}