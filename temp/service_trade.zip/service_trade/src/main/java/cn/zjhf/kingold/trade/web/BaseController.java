package cn.zjhf.kingold.trade.web;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.constant.TradeError;
import cn.zjhf.kingold.trade.utils.BizParam;

import java.util.Map;

/**
 * Created by DELL on 2017/5/10.
 */
public class BaseController {
    private static final String TRACEID = "traceID";

    protected BizParam initParam(Map paraMap) {
        return new BizParam(paraMap);
    }

    protected BizParam initParam(Map paraMap, String... keys) throws BusinessException {
        BizParam bizPara = new BizParam(paraMap);
        bizPara.check(keys);
        return bizPara;
    }

    protected ResponseResult respRet(BizParam paraMap, int code, String msg, Object data) {
        return new ResponseResult(paraMap.get(TRACEID), code, msg, data);
    }

    protected ResponseResult respRet(BizParam paraMap, Object data) {
        return new ResponseResult(paraMap.get(TRACEID), TradeError.OK, TradeError.OK_TEXT, data);
    }

    protected ResponseResult respRet(BizParam paraMap) {
        return new ResponseResult(paraMap.get(TRACEID), TradeError.OK, TradeError.OK_TEXT);
    }
}
