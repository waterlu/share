package cn.zjhf.kingold.trade.persistence.mq.message;

import cn.zjhf.kingold.rocketmq.base.MQMessage;

import java.util.Date;

/**
 * 私募订单确认消息
 *
 * Created by lutiehua on 2017/7/14.
 */
public class OrderConfirmMessage implements MQMessage {

    private String productType;

    private String orderBillCode;

    private Date createTime;

    public OrderConfirmMessage() {

    }

    @Override
    public String getKey() {
        return orderBillCode;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getOrderBillCode() {
        return orderBillCode;
    }

    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}
