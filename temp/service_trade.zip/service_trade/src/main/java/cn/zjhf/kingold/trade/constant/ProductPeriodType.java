package cn.zjhf.kingold.trade.constant;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by lutiehua on 2017/6/7.
 */
public interface ProductPeriodType {

    String DAY = "D";

    String MONTH = "M";

    String YEAR = "Y";

    Map PRODUCT_PERIOD_TYPE = new HashMap() {{
        put("D", "天");
        put("M", "个月");
        put("Y", "年");
    }};

}
