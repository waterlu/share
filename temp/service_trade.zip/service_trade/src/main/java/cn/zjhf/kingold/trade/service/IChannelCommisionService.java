package cn.zjhf.kingold.trade.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.entity.InVO.*;
import cn.zjhf.kingold.trade.entity.OutVO.*;

/**
 * Created by zhangyijie on 2017/10/12.
 */
public interface IChannelCommisionService {
    /**
     * 生成渠道佣金明细记录
     * @param productUuid
     * @return
     * @throws BusinessException
     */
    int creatClearData(String productUuid) throws BusinessException;

    /**
     * 查询渠道佣金明细记录
     * @param lstCondition
     * @return
     * @throws BusinessException
     */
    CommItemListVO<ChannelCommisionDetailVO> lstDetail(LstChannelCommisionDetailConditionVO lstCondition) throws BusinessException;

    /**
     * 查询渠道 交易佣金记录， 使用产品ID和渠道商户号
     * @param lstCondition
     * @return
     * @throws BusinessException
     */
    CommItemListVO<ChannelTradeCommisionItemVO> lstTradeCommisionsByMerchantNum(LstTradeCommisionsByMerchantNumConditionVO lstCondition) throws BusinessException;

    /**
     * 批量请求结算
     * @param requestCycle 请求周期，格式: YYYY.MM
     * @return
     * @throws BusinessException
     */
    ChannelCommisionRequestResultVO request(String requestCycle) throws BusinessException;

    /**
     * 获取批量请求条数/佣金总和
     * @param requestCycle 请求周期，格式: YYYY.MM
     * @return
     * @throws BusinessException
     */
    ChannelCommisionRequestResultVO getBatchCountAndCommission(String requestCycle) throws BusinessException;

    /**
     * 查询渠道佣金汇总记录
     * @param lstCondition
     * @return
     * @throws BusinessException
     */
    CommItemListVO<ChannelCommisionSummaryVO> lstSummary(LstChannelCommisionSummaryConditionVO lstCondition) throws BusinessException;

    /**
     * 查询渠道 交易佣金记录， 使用产品ID和渠道商户号
     * @param lstCondition
     * @return
     * @throws BusinessException
     */
    CommItemListVO<ChannelTradeCommisionItemVO> lstTradeCommisionsByRequestId(LstTradeCommisionsByRequestIdConditionVO lstCondition) throws BusinessException;

    /**
     * 根据 佣金请求结算ID列表 查询总佣金记录数
     * @param requestIds
     * @return
     * @throws BusinessException
     */
    ChannelCommisionCountVO lstChannelCommisionCount(String requestIds) throws BusinessException;

    /**
     * 结算渠道佣金
     * @param channelCommisionSettle
     * @return
     * @throws BusinessException
     */
    int channelCommisionSettle(ChannelCommisionSettleVO channelCommisionSettle) throws BusinessException;
}
