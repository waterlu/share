package cn.zjhf.kingold.trade.persistence.mq.producer;

import cn.zjhf.kingold.rocketmq.annotation.RocketMQProducer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQProducer;
import cn.zjhf.kingold.rocketmq.base.SimpleMessage;

/**
 * 生产支付超时消息（延时消息）
 *
 * Created by lutiehua on 2017/7/13.
 */
@RocketMQProducer(topic = "pay", tag = "timeout")
public class PayTimeoutProducer extends AbstractMQProducer<SimpleMessage> {
}
