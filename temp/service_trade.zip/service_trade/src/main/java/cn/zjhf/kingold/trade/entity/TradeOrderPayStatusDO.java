package cn.zjhf.kingold.trade.entity;

/**
 * @author lutiehua
 * @date 2018/3/12
 */
public class TradeOrderPayStatusDO {

    /**
     * 订单号
     */
    private String orderBillCode;

    /**
     * 订单支付状态
     */
    private Integer orderPayStatus;

    public String getOrderBillCode() {
        return orderBillCode;
    }

    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    public Integer getOrderPayStatus() {
        return orderPayStatus;
    }

    public void setOrderPayStatus(Integer orderPayStatus) {
        this.orderPayStatus = orderPayStatus;
    }
}
