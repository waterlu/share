package cn.zjhf.kingold.trade.utils;

import org.apache.commons.collections4.MapUtils;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by DELL on 2017/5/15.
 */
public class MapParamUtils {

    public static String getStringInMap(Map params, String key){
        if(MapUtils.isEmpty(params) || params.get(key) == null){
            return "";
        }

        return params.get(key).toString();

    }

    public static int getIntInMap(Map params,String key){
        if(MapUtils.isEmpty(params) || params.get(key) == null){
            return 0;
        }

        return Integer.parseInt(params.get(key).toString());

    }

    public static long getLongInMap(Map params,String key){
        if(MapUtils.isEmpty(params) || params.get(key) == null){
            return 0;
        }

        return Long.parseLong(params.get(key).toString());

    }

    public static double getDoubleInMap(Map params,String key){
        if(MapUtils.isEmpty(params) || params.get(key) == null){
            return 0;
        }

        return Double.parseDouble(params.get(key).toString());

    }


    public static BigDecimal getBigDecimalInMap(Map params, String key){
        if(MapUtils.isEmpty(params) || params.get(key) == null){
            return new BigDecimal(0);
        }

        return new BigDecimal(params.get(key).toString());

    }



    public static byte getByteInMap(Map params,String key){
        if(MapUtils.isEmpty(params) || params.get(key) == null){
            return 0;
        }

        return Byte.parseByte(params.get(key).toString());

    }


    public static Map<String, Object> obj2Map(Object obj) {
        Map<String, Object> map = new HashMap<>();
        Field[] fields = obj.getClass().getDeclaredFields();
        for (int i = 0, len = fields.length; i < len; i++) {
            String varName = fields[i].getName();
            try {
                boolean accessFlag = fields[i].isAccessible();
                fields[i].setAccessible(true);
                Object o = fields[i].get(obj);
                if (o != null)
                    map.put(varName, o);
                fields[i].setAccessible(accessFlag);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return map;
    }


}
