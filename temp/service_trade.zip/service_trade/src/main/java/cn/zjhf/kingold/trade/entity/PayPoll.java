package cn.zjhf.kingold.trade.entity;

import java.io.Serializable;

/**
 * @Author liuyao
 * @Description
 * @Date Created in 15:46 2017/5/15
 */

public class PayPoll implements Serializable{

    private static final long serialVersionUID = -8543127967854615237L;
    int type;
    String orderBillCode;
    String returnState;

    public PayPoll() {

    }

    public PayPoll(int type, String orderBillCode) {
        this.type = type;
        this.orderBillCode = orderBillCode;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getOrderBillCode() {
        return orderBillCode;
    }

    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    public String getReturnState() {
        return returnState;
    }

    public void setReturnState(String returnState) {
        this.returnState = returnState;
    }
}
