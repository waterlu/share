package cn.zjhf.kingold.trade.dto;

import cn.zjhf.kingold.common.param.ParamVO;

/**
 * @author xiexiaojie
 *         2018/4/8.
 */
public class AccountDTO extends ParamVO{
    /**
     * 宝付账户账号
     */
    private Long accountNo;
    /**
     * 投资人电话
     */
    private String investorMobile;

    /**
     * 注册时间开始(开户时间)
     */
    private String accountTimeFrom;

    /**
     * 注册时间结束(开户时间)
     */
    private String accountTimeTo;

    /**
     * 21 投资人，31 募集方
     */
    private String accountType;

    /**
     * 投资人类型（11普通投资人 12理财顾问 19专职理财师)
     */
    private Integer investorType;

    /**
     * 账户余额：0为0，1不为0
     */
    private Integer balanceType;

    private Integer startRow;

    private Integer pageSize;

    private String orderBy;

    public Long getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(Long accountNo) {
        this.accountNo = accountNo;
    }

    public String getInvestorMobile() {
        return investorMobile;
    }

    public void setInvestorMobile(String investorMobile) {
        this.investorMobile = investorMobile;
    }

    public String getAccountTimeFrom() {
        return accountTimeFrom;
    }

    public void setAccountTimeFrom(String accountTimeFrom) {
        this.accountTimeFrom = accountTimeFrom;
    }

    public String getAccountTimeTo() {
        return accountTimeTo;
    }

    public void setAccountTimeTo(String accountTimeTo) {
        this.accountTimeTo = accountTimeTo;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public Integer getInvestorType() {
        return investorType;
    }

    public void setInvestorType(Integer investorType) {
        this.investorType = investorType;
    }

    public Integer getStartRow() {
        return startRow;
    }

    public void setStartRow(Integer startRow) {
        this.startRow = startRow;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public String getOrderBy() {
        return orderBy;
    }

    public void setOrderBy(String orderBy) {
        this.orderBy = orderBy;
    }

    public Integer getBalanceType() {
        return balanceType;
    }

    public void setBalanceType(Integer balanceType) {
        this.balanceType = balanceType;
    }

    @Override
    public String toString() {
        return "AccountDTO{" +
                "accountNo=" + accountNo +
                ", investorMobile='" + investorMobile + '\'' +
                ", accountTimeFrom='" + accountTimeFrom + '\'' +
                ", accountTimeTo='" + accountTimeTo + '\'' +
                ", accountType='" + accountType + '\'' +
                ", investorType=" + investorType +
                ", balanceType=" + balanceType +
                ", startRow=" + startRow +
                ", pageSize=" + pageSize +
                ", orderBy='" + orderBy + '\'' +
                '}';
    }
}
