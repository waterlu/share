package cn.zjhf.kingold.trade.exception;

import cn.zjhf.kingold.common.exception.BusinessException;

/**
 * 优惠券状态异常
 *
 * @author lutiehua
 * @date 2018/3/9
 */
public class CouponStatusException extends BusinessException {

    public CouponStatusException() {
        super(6021, "优惠券已使用、赠送或者过期");
    }

}
