package cn.zjhf.kingold.trade.baofoo;
/**
 * @Author liuyao
 * @Description
 * @Date Created in 17:21 2017/6/6
 */

public enum BaofooAccountEnum {
    BASE_ACCOUNT(1, "基本账户"),UN_FREEZE_ACCOUNT(2, "未冻结账户")
    , FREEZE_ACCOUNT(3, "冻结账户"), DEPOSIT_ACCOUNT(4, "保证金账户"), CUSTODY_ACCOUNT(5, "托管账户");

    private String typeName;
    private Integer value;

    BaofooAccountEnum(Integer value, String typeName) {
        this.typeName = typeName;
        this.value = value;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }
}
