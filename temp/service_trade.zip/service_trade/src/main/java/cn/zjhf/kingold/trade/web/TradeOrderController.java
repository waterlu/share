package cn.zjhf.kingold.trade.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.common.utils.MapRemoveNullUtil;
import cn.zjhf.kingold.trade.dto.AccountTransactionDto;
import cn.zjhf.kingold.trade.dto.TradeOrderDto;
import cn.zjhf.kingold.trade.entity.TradePaymentSummary;
import cn.zjhf.kingold.trade.service.ITradeOrderService;
import cn.zjhf.kingold.trade.service.ITradeService;
import cn.zjhf.kingold.trade.utils.DataUtils;
import cn.zjhf.kingold.trade.utils.MapParamUtils;
import cn.zjhf.kingold.trade.utils.RequestMapperConvert;
import cn.zjhf.kingold.trade.vo.TradeOrderVO;
import com.alibaba.fastjson.JSON;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Created by lu on 2017/3/13.
 */
@RestController
@RequestMapping(value = "/tradeorder")
public class TradeOrderController {

    protected static final Logger logger = LoggerFactory.getLogger(TradeOrderController.class);

    @Autowired
    private ITradeOrderService tradeOrderService;

    @Autowired
    private ITradeService tradeService;

    /**
     * 订单列表
     *
     * @param paramMap 参数选填：userPhone
     *  transactionChannel（1.app(IOS); 2,app(安卓); 其他）
     *  productAbbrName（产品简称）
     *  productUuid（产品ID）
     *  orderBillCode（订单号）
     *  createOrderTimeFrom(查询开始时间)
     *  createOrderTimeTo(查询结束时间)
     *  orderStatus（订单状态）
     *  properties(要返回的属性)
     *  startRow（起始行），
     *  pageSize（每页数量）
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public ResponseResult getList(@RequestParam Map paramMap) throws BusinessException {
        logger.info("getList start: " + DataUtils.toString(paramMap));

        MapRemoveNullUtil.removeNullEntry(paramMap);
        RequestMapperConvert.initTradeOrderParam(paramMap);

        List<Map> userList = tradeOrderService.getList(paramMap);

        logger.info("getList end: " + DataUtils.toString(paramMap.get("traceID"), userList));
        return new ResponseResult( MapParamUtils.getStringInMap( paramMap,"traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", userList);
    }

    /**
     * 订单查询（现仅用于订单列表导出）
     * @param param
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/order/list", method = RequestMethod.GET)
    public ResponseResult getOrderList(@RequestParam Map<String, Object> param) throws BusinessException {
        logger.info("getOrderList start {} " ,param);
        String jsonString = JSON.toJSONString(param);
        TradeOrderDto dto = JSON.parseObject(jsonString, TradeOrderDto.class);
        List<TradeOrderVO> orderList = tradeOrderService.getOrderList(dto);
        logger.info("getOrderList end traceID size{}{}","" ,orderList.size());
        //logger.info("getOrderList end traceID {}", DataUtils.toString(orderList));
        return new ResponseResult(dto.getTraceID(), ResponseCode.REQUEST_SUCCESS, "正常调用", orderList);
    }

    /**
     * 订单总数
     *
     * @param paramMap 参数选填： userPhone
     *  transactionChannel（1.app(IOS); 2,app(安卓); 其他）
     *  productAbbrName（产品简称）
     *  productUuid（产品ID）
     *  orderBillCode（订单号）
     *  createOrderTimeFrom(查询开始时间)
     *  createOrderTimeTo(查询结束时间)
     *  orderStatus（订单状态）
     *  properties(要返回的属性)
     *  startRow（起始行），
     *  pageSize（每页数量）
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/count", method = RequestMethod.GET)
    public ResponseResult getCount(@RequestParam Map paramMap) throws BusinessException {
        logger.info("getCount start: " + DataUtils.toString(paramMap));

        MapRemoveNullUtil.removeNullEntry(paramMap);
        RequestMapperConvert.initTradeOrderParam(paramMap);
        Integer count  = tradeOrderService.getCount(paramMap);

        logger.info("getCount end: " + DataUtils.toString(paramMap.get("traceID"), count));
        return new ResponseResult( MapParamUtils.getStringInMap( paramMap,"traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", count);
    }

    /**
     * 获取订单
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/{orderBillCode}", method = RequestMethod.GET)
    public ResponseResult getOrder(@PathVariable String orderBillCode, @RequestParam Map params) throws BusinessException {
        logger.info("getOrder start: " + DataUtils.toString(orderBillCode, params));

        Map tradeOrder = tradeOrderService.getTradeOrder(orderBillCode);
        //添加产品兑付日期信息
        TradePaymentSummary tradePaymentSummary = tradeOrderService.getTradePaymentSummary((String) tradeOrder.get("productUuid"));
        if (tradePaymentSummary != null) {
            tradeOrder.put("cashDate", tradePaymentSummary.getPayedTime());
        }

        //把私有认购协议文件转化为可以访问的地址
        if (tradeOrder.containsKey("subcontractFilepath") && StringUtils.isNotEmpty(MapParamUtils.getStringInMap(tradeOrder, "subcontractFilepath"))) {
            String subcontractFilepath = tradeService.getAccessFileUrl(MapParamUtils.getStringInMap(tradeOrder, "subcontractFilepath"));
            tradeOrder.put("subcontractFilepath", subcontractFilepath);
        }

        logger.info("getOrder end: " + DataUtils.toString(params.get("traceID"), tradeOrder));
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", tradeOrder);
    }
}
