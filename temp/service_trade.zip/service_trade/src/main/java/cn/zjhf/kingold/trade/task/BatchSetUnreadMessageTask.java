package cn.zjhf.kingold.trade.task;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.service_consumer.service.BaseServiceConsumer;
import cn.zjhf.kingold.trade.constant.URL;
import com.google.common.base.Joiner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author liuyao
 * @date 2018/1/22
 * 批量发送红包未读消息
 */
@Component
public class BatchSetUnreadMessageTask {

    private final static Logger LOGGER = LoggerFactory.getLogger(BatchSetUnreadMessageTask.class);

    @Autowired
    protected BaseServiceConsumer baseServiceConsumer;

    @Async("IoBusyExecutor")
    public void asyncSendCoupon(List<String> userUuidList, Integer couponType) throws BusinessException {
        LOGGER.info("start set unread message. size ={}, type={}", userUuidList.size(), couponType);
        Map<String, Object> param = new HashMap<>();
        int pageSize = 200;
        int startRow = 0;
        do {
            int toIndex = startRow + pageSize;
            if (toIndex > userUuidList.size()) {
                toIndex = userUuidList.size();
            }
            List<String> pageList = userUuidList.subList(startRow, toIndex);
            String userUuids = Joiner.on("$$").join(pageList);
            param.put("userUuids", userUuids);
            param.put("couponType", couponType);
            baseServiceConsumer.post(URL.URL_BASE_BATCH_COUPON_SET_UNREAD_MESSAGE, param);
            startRow = toIndex;
        } while (startRow < userUuidList.size());
        LOGGER.info("end set unread message.");
    }

}
