package cn.zjhf.kingold.trade.utils;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.constant.BizDefine;
import cn.zjhf.kingold.trade.constant.ProductType;
import cn.zjhf.kingold.trade.constant.ReportNo;
import cn.zjhf.kingold.trade.entity.InVO.ReportConditionVO;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangyijie on 2017/6/28.
 */
public class ReportUtils {
    private String reportRule = null;
    private List<String> fieldNames = new ArrayList<String>();
    private List<String> wildCards = new ArrayList<String>();

    final static String Amt = "Amt";
    final static String Time = "Time";

    public ReportUtils(String value) {
        reportRule = value;

        init();

        creatWildCards();
        creatFieldNames();
    }

    public ReportUtils() {
    }

    public ReportUtils setReportRule(String reportRule) {
        this.reportRule = reportRule;
        return this;
    }

    private void init() {
        String[] tmpStrs = reportRule.split("\\s+");

        for(int i=0; i<tmpStrs.length; i++) {
            String tmpStr = tmpStrs[i].trim();
            if(tmpStr.startsWith("$")) {
                String target = "";

                if(tmpStr.endsWith(",")) {
                    target = toSQLStr(tmpStr.substring(0, tmpStr.length() -1).replace("$", "")) + ",";
                }else {
                    target = toSQLStr(tmpStr.replace("$", ""));
                }

                reportRule = reportRule.replace(tmpStr, target);
            }
        }
    }

    private void creatWildCards() {
        String[] tmpStrs = reportRule.split("\\s+");

        for(int i=0; i<tmpStrs.length; i++) {
            if(tmpStrs[i].trim().startsWith("#")) {
                wildCards.add(tmpStrs[i].trim());
            }
        }
    }

    private void creatFieldNames() {
        String[] tmpStrs = reportRule.split("\\s+");

        int asPos = -1;
        for(int i=0; i<tmpStrs.length; i++) {
            if(tmpStrs[i].trim().equals("AS") || tmpStrs[i].trim().equals("as")) {
                asPos = i;
            }

            if((asPos != -1) && ((i-1) == asPos)) {
                fieldNames.add(tmpStrs[i].replace(",", "").replace("'", "").trim());
                asPos = -1;
            }
        }
    }


    public List<String> getFieldNames() {
        return fieldNames;
    }

    private String toSQLStr(String strValue) {
        if (DataUtils.isEmpty(strValue))
            strValue = "''";

        return "'" + strValue.trim() + "'";
    }

    public void processWildCard(ReportConditionVO condi) throws BusinessException {
        for(String wildCard : wildCards) {
            wildCard = wildCard.trim();
            String value = "";

            if(wildCard.equals("#productAbbrName")) {
                value = (DataUtils.isNotEmpty(condi.getProductAbbrName()) ? condi.getProductAbbrName() : "");
                value = "%" + value + "%";
                value = toSQLStr(value);
            }else if (wildCard.equals("#productUuid")){
                if(DataUtils.isNotEmpty(condi.getProductUuid())){
                    value = toSQLStr(condi.getProductUuid());
                }
            }else if(wildCard.equals("#productInterestBeginDate")) {
                if(condi.getProductInterestBeginDate() != null) {
                    value = DateUtil.formateDate(condi.getProductInterestBeginDate());
                    value = toSQLStr(value);
                }
            }else if(wildCard.equals("#productInterestEndDate")) {
                if(condi.getProductInterestEndDate() != null) {
                    value = DateUtil.formateDate(condi.getProductInterestEndDate());
                    value = toSQLStr(value);
                }
            }else if(wildCard.equals("#productExpiringBeginDate")) {
                if(condi.getProductExpiringBeginDate() != null) {
                    value = DateUtil.formateDate(condi.getProductExpiringBeginDate());
                    value = toSQLStr(value);
                }
            }else if(wildCard.equals("#productExpiringEndDate")) {
                if(condi.getProductExpiringEndDate() != null) {
                    value = DateUtil.formateDate(condi.getProductExpiringEndDate());
                    value = toSQLStr(value);
                }
            }else if(wildCard.equals("#beginSN,#endSN")) {
                value = condi.getBeginSN()+","+condi.getEndSN();
            }else if(wildCard.equals("#LIMIT")){
                value = WhereCondition.getPageCondi(condi.getBeginSN(), condi.getEndSN());
            }else if(wildCard.equals("#productCondition")) {
                if(DataUtils.isNotEmpty(condi.getProductUuid())) {//产品UUID
                    value += " AND pro.product_uuid = " + WhereCondition.toSQLStr(condi.getProductUuid()) + " ";
                }

                if(DataUtils.isNotEmpty(condi.getProductAbbrName())) {//产品名称
                    value += " AND pro.product_abbr_name " + WhereCondition.toSQLLike(condi.getProductAbbrName()) + " ";
                }

                if(DataUtils.isNotEmpty(condi.getProductCode())){//产品编号
                    value += " AND pro.product_code = " + WhereCondition.toSQLStr(condi.getProductCode()) + " ";
                }

                if(condi.getProductStatus() != null && condi.getProductStatus() > 0){//产品状态
                    value += " AND pro.product_status = " + condi.getProductStatus() + " ";
                } else {
                    if(condi.getReportNo().equals(ReportNo.REPORT_NO_PRODUCT_FIXED)){
                        value += " AND pro.product_status IN  ( "+BizDefine.PRODUCT_STATUS_RAISE+","+BizDefine.PRODUCT_STATUS_ABORT+","+
                                BizDefine.PRODUCT_STATUS_ENDRAISE+","+BizDefine.PRODUCT_STATUS_ESTABLISH+","+BizDefine.PRODUCT_STATUS_LOAN+","+
                                BizDefine.PRODUCT_STATUS_INTEREST+","+BizDefine.PRODUCT_STATUS_PRODUCTEND+","+BizDefine.PRODUCT_STATUS_CLEAR+" )  ";
                    } else if(condi.getReportNo().equals(ReportNo.REPORT_NO_PRODUCT_FIXED_RAISE)){
                        value += " AND pro.product_status IN  ( "+BizDefine.PRODUCT_STATUS_RAISE+" )  ";
                    } else if(condi.getReportNo().equals(ReportNo.REPORT_NO_PRODUCT_FIXED_INTEREST)){
                        value += " AND pro.product_status IN  ( "+BizDefine.PRODUCT_STATUS_INTEREST+" )  ";
                    } else if(condi.getReportNo().equals(ReportNo.REPORT_NO_PRODUCT_FIXED_EXPIRE_CASH)){
                        value += " AND pro.product_status IN  ( "+BizDefine.PRODUCT_STATUS_PRODUCTEND+","+ BizDefine.PRODUCT_STATUS_CLEAR+" )  ";
                    } else if(condi.getReportNo().equals(ReportNo.REPORT_NO_PRODUCT_SALE_DETAIL_REPORT)){
                        value += " AND pro.product_status IN  ( "+BizDefine.PRODUCT_STATUS_RAISE+","+BizDefine.PRODUCT_STATUS_ENDRAISE+","+
                                BizDefine.PRODUCT_STATUS_ESTABLISH+","+ BizDefine.PRODUCT_STATUS_LOAN+","+BizDefine.PRODUCT_STATUS_INTEREST+","+
                                BizDefine.PRODUCT_STATUS_PRODUCTEND+","+ BizDefine.PRODUCT_STATUS_CLEAR+" )  ";
                    }
                }

                if(DataUtils.isNotEmpty(condi.getProductType())){//产品类型
                    value += " AND pro.product_type = " + WhereCondition.toSQLStr(condi.getProductType()) + " ";
                } else {
                    if(condi.getReportNo().equals(ReportNo.REPORT_NO_PRODUCT_SALE_DETAIL_REPORT)){
                        value += " AND pro.product_type IN  ( "+ ProductType.PRODUCT_FT+","+ProductType.PRODUCT_FT+" )  ";
                    }
                }

                if((null != condi.getProductInterestBeginDate()) && (null != condi.getProductInterestEndDate())){//起息日期
                    value += " AND pro_fix.product_interest_date BETWEEN '" +
                            DateUtil.formateDate(condi.getProductInterestBeginDate()) + "' AND '" +
                            DateUtil.formateDate(condi.getProductInterestEndDate()) + "' ";
                }else if (null != condi.getProductInterestBeginDate()){
                    value += " AND pro_fix.product_interest_date >= '" +
                            DateUtil.formateDate(condi.getProductInterestBeginDate()) + "'";
                }else if (null != condi.getProductInterestEndDate()){
                    value += " AND pro_fix.product_interest_date <= '" +
                            DateUtil.formateDate(condi.getProductInterestEndDate()) + "'";
                }

                if((null != condi.getProductExpiringBeginDate()) && (null != condi.getProductExpiringEndDate())){//到期日期
                    value += " AND pro_fix.product_expiring_date BETWEEN '" +
                            DateUtil.formateDate(condi.getProductExpiringBeginDate()) + "' AND '" +
                            DateUtil.formateDate(condi.getProductExpiringEndDate()) + "' ";
                } else if (null != condi.getProductExpiringBeginDate()){
                    value += " AND pro_fix.product_expiring_date >= '" +
                            DateUtil.formateDate(condi.getProductExpiringBeginDate()) + "'";
                } else if (null != condi.getProductExpiringEndDate()){
                    value += " AND pro_fix.product_expiring_date <= '" +
                            DateUtil.formateDate(condi.getProductExpiringEndDate()) + "'";
                }

                if((null != condi.getProductStartRaiseBeginDate()) && (null != condi.getProductStartRaiseEndDate())){//产品募集起始日_结束日期
                    value += " AND pro_fix.raise_start_date BETWEEN '" +
                            DataUtils.toString(condi.getProductStartRaiseBeginDate()) + "' AND '" +
                            DataUtils.toString(condi.getProductStartRaiseEndDate()) + "' ";
                }else if (null != condi.getProductStartRaiseBeginDate()){
                    value += " AND pro_fix.raise_start_date >= '" +
                            DateUtil.formateDate(condi.getProductStartRaiseBeginDate()) + "'";
                } else if (null != condi.getProductStartRaiseEndDate()){
                    value += " AND pro_fix.raise_start_date <= '" +
                            DateUtil.formateDate(condi.getProductStartRaiseEndDate()) + "'";
                }

                if((null != condi.getProductEstablishmentBeginDate()) && (null != condi.getProductEstablishmentEndDate())){//产品成立日_截止日期
                    value += " AND pro_fix.product_establishment_date BETWEEN '" +
                            DataUtils.toString(condi.getProductEstablishmentBeginDate()) + "' AND '" +
                            DataUtils.toString(condi.getProductEstablishmentEndDate()) + "' ";
                }else if (null != condi.getProductEstablishmentBeginDate()){
                    value += " AND pro_fix.product_establishment_date >= '" +
                            DateUtil.formateDate(condi.getProductEstablishmentBeginDate()) + "'";
                } else if (null != condi.getProductEstablishmentEndDate()){
                    value += " AND pro_fix.product_establishment_date <= '" +
                            DateUtil.formateDate(condi.getProductEstablishmentEndDate()) + "'";
                }

                if (StringUtils.isNotBlank(condi.getUserId())){
                    value += " AND acct.account_no = " + WhereCondition.toSQLStr(condi.getUserId()) + " ";
                }
                if(StringUtils.isNotBlank(condi.getUserName())) {//用户名称
                    value += " AND trade.user_name " + WhereCondition.toSQLLike(condi.getUserName()) + " ";
                }
                if (StringUtils.isNotBlank(condi.getUserPhoneNumber())){
                    value += " AND trade.user_phone = " + WhereCondition.toSQLStr(condi.getUserPhoneNumber()) + " ";
                }
                if((null != condi.getTradeBeginDate()) && (null != condi.getTradeEndDate())){//交易日期
                    value += " AND trade.payed_time BETWEEN '" +
                            DataUtils.toString(condi.getTradeBeginDate()) + "' AND '" +
                            DataUtils.toString(condi.getTradeEndDate()) + "' ";
                }else if (null != condi.getTradeBeginDate()){
                    value += " AND trade.payed_time >= '" +
                            DateUtil.formateDate(condi.getTradeBeginDate()) + "'";
                } else if (null != condi.getTradeEndDate()){
                    value += " AND trade.payed_time <= '" +
                            DateUtil.formateDate(condi.getTradeEndDate()) + "'";
                }

                if(condi.getProductPeriod() != null && condi.getProductPeriod() > 0){
                    value += " AND pro.product_period = " + condi.getProductPeriod() + " ";
                }
            }else if (wildCard.equals("#userUuid")){
                if(DataUtils.isNotEmpty(condi.getUserUuid())){
                    value = toSQLStr(condi.getUserUuid());
                }
            }

            if(value != null) {
                reportRule = reportRule.replace(wildCard, value);
                //throw new BusinessException(TradeStatusMsg.REPORT_PARAM_ERR, TradeStatusMsg.REPORT_PARAM_ERR_MSG, false);
            }
        }
    }

    public List<String> getFilterFieldNames() {
        List<String> filterFieldNames = new ArrayList<String>();
        for(String fieldName : fieldNames) {
            fieldName = fieldName.replace(Amt,"").replace(Time,"");
            filterFieldNames.add(fieldName);
        }

        return filterFieldNames;
    }

    public static String getValue(String fieldName, String value) {
        if(fieldName.endsWith(Time)) {
            int pos = value.lastIndexOf(".");
            return value.substring(0,pos);
        }else if(fieldName.endsWith(Amt)) {
            return AmountUtils.toString(value);
        }else if(fieldName.contains("产品状态")) {
            if(DataUtils.isNumeric(value)) {
                value = BizDefine.getProductStatusName(new Integer(value.trim()));
            }
        }else if(fieldName.contains("订单状态")) {
            if(DataUtils.isNumeric(value)) {
                value = BizDefine.getTradeStatusName(new Integer(value.trim()));
            }
        }

        return value;
    }

    public String getCondition() {
        return toString();
    }

    @Override
    public String toString() {
        return reportRule.toString();
    }
}
