package cn.zjhf.kingold.trade.entity.OutVO;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.trade.constant.BizDefine;
import cn.zjhf.kingold.trade.entity.TradeInvestSummary;
import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.Date;

@ApiModel(value = "TradeInvestSummaryExVO", description = "募集资金汇总")
public class TradeInvestSummaryExVO extends ParamVO {

    @ApiModelProperty(required = false, value = "放款申请编号,自增ID")
    private Long tradeInvestSummaryUuid;

    @ApiModelProperty(required = true, value = "产品UUID")
    @NotEmpty
    @Size(min = 1, max = 32)
    private String productUuid;

    @ApiModelProperty(required = true, value = "产品编码")
    @NotEmpty
    @Size(min = 1, max = 16)
    private String productCode;

    @ApiModelProperty(required = true, value = "产品类型")
    @NotEmpty
    @Size(min = 1, max = 16)
    private String productType;

    @ApiModelProperty(required = true, value = "产品名称  产品简称")
    @NotEmpty
    @Size(min = 1, max = 40)
    private String productAbbrName;

    @ApiModelProperty(required = false, value = "产品期限")
    private int productPeriod;

    @ApiModelProperty(required = true, value = "有效投资用户(个数)   募集总笔数")
    @NotEmpty
    private double raiseCount;

    @ApiModelProperty(required = true, value = "申请放款金额  募集总金额 = 募集金额_客户缴纳部分 + 募集金额_平台营销费用部分")
    @NotEmpty
    private double raiseAmount;

    @ApiModelProperty(required = true, value = "募集规模")
    @NotEmpty
    private double productScale;

    @ApiModelProperty(required = true, value = "平台中间户划款金额/已募集资金 募集金额_客户缴纳部分")
    @NotEmpty
    private double raiseInvestorAmount;

    @ApiModelProperty(required = true, value = "平台基本户代金券金额/代金券资金 募集金额_平台营销费用部分")
    @NotEmpty
    private double raisePlatformAmount;

    @ApiModelProperty(required = true, value = "募集方扣平台服务费/平台服务费")
    @NotEmpty
    private double platformServerFeeAmount;

    @ApiModelProperty(required = true, value = "交易所管理费")
    @NotEmpty
    private double exchangeManagerFeeAmount;

    @ApiModelProperty(required = true, value = "用户UUID")
    @NotEmpty
    @Size(min = 1, max = 32)
    private String outUserUuid;

    @ApiModelProperty(required = true, value = "账户UUID")
    @NotEmpty
    @Size(min = 1, max = 32)
    private String outAccountUuid;

    @ApiModelProperty(required = false, value = "托管机构用户账号")
    @Size(min = 1, max = 32)
    private String outAccountNo;

    @ApiModelProperty(required = true, value = "对手方用户UUID")
    @NotEmpty
    @Size(min = 1, max = 32)
    private String inUserUuid;

    @ApiModelProperty(required = true, value = "对手方账户UUID")
    @NotEmpty
    @Size(min = 1, max = 32)
    private String inAccountUuid;

    @ApiModelProperty(required = false, value = "对手方托管机构用户账号")
    @Size(min = 1, max = 32)
    private String inAccountNo;

    @ApiModelProperty(required = true, value = "汇总时间")
    @NotEmpty
    private Date creatTime;

    @ApiModelProperty(required = true, value = "放款状态： -1审核失败；1待审核；2审核通过；3已兑付")
    @NotEmpty
    private int transactionStatus;

    @ApiModelProperty(required = false, value = "最后审核人 审核人")
    @Size(min = 1, max = 32)
    private String auditOperator;

    @ApiModelProperty(required = false, value = "最后审核时间 审核时间")
    private Date auditTime;

    @ApiModelProperty(required = false, value = "审核意见")
    @Size(min = 1, max = 512)
    private String auditOpinion;

    @ApiModelProperty(required = false, value = "放款人 兑付人")
    @Size(min = 1, max = 32)
    private String payedOperator;

    @ApiModelProperty(required = false, value = "放款时间 兑付时间")
    private Date payedTime;

    @ApiModelProperty(required = false, value = "签名")
    @Size(min = 1, max = 128)
    private String signature;

    @ApiModelProperty(required = true, value = "删除标记 0未删除，1已删除")
    @NotEmpty
    private int deleteFlag;

    @ApiModelProperty(required = true, value = "申请放款时间 ")
    @NotEmpty
    private Date createTime;

    @ApiModelProperty(required = true, value = "")
    @NotEmpty
    private Date updateTime;

    public TradeInvestSummaryExVO() {
        this.platformServerFeeAmount = 0;
        this.exchangeManagerFeeAmount = 0;
    }

    public TradeInvestSummaryExVO(TradeInvestSummary tradeInvestSummary) {
        if(tradeInvestSummary != null) {
            this.tradeInvestSummaryUuid = tradeInvestSummary.getTradeInvestSummaryUuid();
            this.productUuid = tradeInvestSummary.getProductUuid();
            this.productCode = tradeInvestSummary.getProductCode();
            this.productType = tradeInvestSummary.getProductType();
            this.productAbbrName = tradeInvestSummary.getProductAbbrName();
            this.raiseCount = tradeInvestSummary.getRaiseCount().doubleValue();
            this.raiseAmount = tradeInvestSummary.getRaiseAmount().doubleValue();
            this.raiseInvestorAmount = tradeInvestSummary.getRaiseInvestorAmount().doubleValue();
            this.raisePlatformAmount = tradeInvestSummary.getRaisePlatformAmount().doubleValue();
            this.outUserUuid = tradeInvestSummary.getOutUserUuid();
            this.outAccountUuid = tradeInvestSummary.getOutAccountUuid();
            this.outAccountNo = tradeInvestSummary.getOutAccountNo();
            this.inUserUuid = tradeInvestSummary.getInUserUuid();
            this.inAccountUuid = tradeInvestSummary.getInAccountUuid();
            this.inAccountNo = tradeInvestSummary.getInAccountNo();
            this.transactionStatus = tradeInvestSummary.getTransactionStatus();
            this.auditOperator = tradeInvestSummary.getAuditOperator();
            this.auditTime = tradeInvestSummary.getAuditTime();
            this.auditOpinion = tradeInvestSummary.getAuditOpinion();
            this.payedOperator = tradeInvestSummary.getPayedOperator();
            this.payedTime = tradeInvestSummary.getPayedTime();
            this.signature = tradeInvestSummary.getSignature();
            this.deleteFlag = tradeInvestSummary.getDeleteFlag();
            this.createTime = tradeInvestSummary.getCreateTime();
            this.updateTime = tradeInvestSummary.getUpdateTime();

            this.platformServerFeeAmount = tradeInvestSummary.getPlatformServiceFee().doubleValue();
            this.exchangeManagerFeeAmount = tradeInvestSummary.getExchangeManageFee().doubleValue();
        }
    }

    public int getProductPeriod() {
        return productPeriod;
    }

    public void setProductPeriod(int productPeriod) {
        this.productPeriod = productPeriod;
    }

    public long getTradeInvestSummaryUuid() {
        return tradeInvestSummaryUuid;
    }

    public void setTradeInvestSummaryUuid(long tradeInvestSummaryUuid) {
        this.tradeInvestSummaryUuid = tradeInvestSummaryUuid;

    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getProductAbbrName() {
        return productAbbrName;
    }

    public void setProductAbbrName(String productAbbrName) {
        this.productAbbrName = productAbbrName;
    }

    public double getRaiseCount() {
        return raiseCount;
    }

    public void setRaiseCount(double raiseCount) {
        this.raiseCount = raiseCount;
    }

    public double getRaiseAmount() {
        return raiseAmount;
    }

    public void setRaiseAmount(double raiseAmount) {
        this.raiseAmount = raiseAmount;
    }

    public double getRaiseInvestorAmount() {
        return raiseInvestorAmount;
    }

    public void setRaiseInvestorAmount(double raiseInvestorAmount) {
        this.raiseInvestorAmount = raiseInvestorAmount;
    }

    public double getRaisePlatformAmount() {
        return raisePlatformAmount;
    }

    public void setRaisePlatformAmount(double raisePlatformAmount) {
        this.raisePlatformAmount = raisePlatformAmount;
    }

    public String getOutUserUuid() {
        return outUserUuid;
    }

    public void setOutUserUuid(String outUserUuid) {
        this.outUserUuid = outUserUuid;
    }

    public String getOutAccountUuid() {
        return outAccountUuid;
    }

    public void setOutAccountUuid(String outAccountUuid) {
        this.outAccountUuid = outAccountUuid;
    }

    public String getOutAccountNo() {
        return outAccountNo;
    }

    public void setOutAccountNo(String outAccountNo) {
        this.outAccountNo = outAccountNo;
    }

    public String getInUserUuid() {
        return inUserUuid;
    }

    public void setInUserUuid(String inUserUuid) {
        this.inUserUuid = inUserUuid;
    }

    public String getInAccountUuid() {
        return inAccountUuid;
    }

    public void setInAccountUuid(String inAccountUuid) {
        this.inAccountUuid = inAccountUuid;
    }

    public String getInAccountNo() {
        return inAccountNo;
    }

    public void setInAccountNo(String inAccountNo) {
        this.inAccountNo = inAccountNo;
    }

    public Date getCreatTime() {
        return creatTime;
    }

    public void setCreatTime(Date creatTime) {
        this.creatTime = creatTime;
    }

    public int getTransactionStatus() {
        return transactionStatus;
    }

    public void setTransactionStatus(int transactionStatus) {
        this.transactionStatus = transactionStatus;
    }

    public String getAuditOperator() {
        return auditOperator;
    }

    public void setAuditOperator(String auditOperator) {
        this.auditOperator = auditOperator;
    }

    public Date getAuditTime() {
        return auditTime;
    }

    public void setAuditTime(Date auditTime) {
        this.auditTime = auditTime;
    }

    public String getAuditOpinion() {
        return auditOpinion;
    }

    public void setAuditOpinion(String auditOpinion) {
        this.auditOpinion = auditOpinion;
    }

    public String getPayedOperator() {
        return payedOperator;
    }

    public void setPayedOperator(String payedOperator) {
        this.payedOperator = payedOperator;
    }

    public Date getPayedTime() {
        return payedTime;
    }

    public void setPayedTime(Date payedTime) {
        this.payedTime = payedTime;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public int getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(int deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public TradeInvestSummary get() {
        TradeInvestSummary tradeInvestSummary = new TradeInvestSummary();

        tradeInvestSummary.setPlatformServiceFee(new BigDecimal(platformServerFeeAmount));
        tradeInvestSummary.setExchangeManageFee(new BigDecimal(exchangeManagerFeeAmount));
        tradeInvestSummary.setTradeInvestSummaryUuid(tradeInvestSummaryUuid);
        tradeInvestSummary.setProductUuid(productUuid);
        tradeInvestSummary.setProductCode(productCode);
        tradeInvestSummary.setProductType(productType);
        tradeInvestSummary.setProductAbbrName(productAbbrName);
        tradeInvestSummary.setRaiseCount(new BigDecimal(raiseCount));
        tradeInvestSummary.setRaiseAmount(new BigDecimal(raiseAmount));
        tradeInvestSummary.setRaiseInvestorAmount(new BigDecimal(raiseInvestorAmount));
        tradeInvestSummary.setRaisePlatformAmount(new BigDecimal(raisePlatformAmount));
        tradeInvestSummary.setOutUserUuid(outUserUuid);
        tradeInvestSummary.setOutAccountUuid(outAccountUuid);
        tradeInvestSummary.setOutAccountNo(outAccountNo);
        tradeInvestSummary.setInUserUuid(inUserUuid);
        tradeInvestSummary.setInAccountUuid(inAccountUuid);
        tradeInvestSummary.setInAccountNo(inAccountNo);
        tradeInvestSummary.setTransactionStatus(new Integer(transactionStatus).byteValue());
        tradeInvestSummary.setAuditOperator(auditOperator);
        tradeInvestSummary.setAuditTime(auditTime);
        tradeInvestSummary.setAuditOpinion(auditOpinion);
        tradeInvestSummary.setPayedOperator(payedOperator);
        tradeInvestSummary.setPayedTime(payedTime);
        tradeInvestSummary.setSignature(signature);
        tradeInvestSummary.setDeleteFlag(new Integer(deleteFlag).byteValue());
        tradeInvestSummary.setCreateTime(createTime);
        tradeInvestSummary.setUpdateTime(updateTime);
        return tradeInvestSummary;
    }

    public void setTradeInvestSummaryUuid(Long tradeInvestSummaryUuid) {
        this.tradeInvestSummaryUuid = tradeInvestSummaryUuid;
    }

    public double getPlatformServerFeeAmount() {
        return platformServerFeeAmount;
    }

    public void setPlatformServerFeeAmount(double platformServerFeeAmount) {
        this.platformServerFeeAmount = platformServerFeeAmount;
    }

    public double getExchangeManagerFeeAmount() {
        return exchangeManagerFeeAmount;
    }

    public void setExchangeManagerFeeAmount(double exchangeManagerFeeAmount) {
        this.exchangeManagerFeeAmount = exchangeManagerFeeAmount;
    }

    public double getProductScale() {
        return productScale;
    }

    public void setProductScale(double productScale) {
        this.productScale = productScale;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("tradeInvestSummaryUuid:" + DataUtils.toString(tradeInvestSummaryUuid) + ", ");
        sb.append("productUuid:" + DataUtils.toString(productUuid) + ", ");
        sb.append("productCode:" + DataUtils.toString(productCode) + ", ");
        sb.append("productType:" + DataUtils.toString(productType) + ", ");
        sb.append("productAbbrName:" + DataUtils.toString(productAbbrName) + ", ");
        sb.append("productPeriod:" + DataUtils.toString(productPeriod) + ", ");
        sb.append("raiseCount:" + DataUtils.toString(raiseCount) + ", ");
        sb.append("raiseAmount:" + DataUtils.toString(raiseAmount) + ", ");
        sb.append("productScale:" + DataUtils.toString(productScale) + ", ");
        sb.append("raiseInvestorAmount:" + DataUtils.toString(raiseInvestorAmount) + ", ");
        sb.append("raisePlatformAmount:" + DataUtils.toString(raisePlatformAmount) + ", ");
        sb.append("platformServerFeeAmount:" + DataUtils.toString(platformServerFeeAmount) + ", ");
        sb.append("exchangeManagerFeeAmount:" + DataUtils.toString(exchangeManagerFeeAmount) + ", ");
        sb.append("outUserUuid:" + DataUtils.toString(outUserUuid) + ", ");
        sb.append("outAccountUuid:" + DataUtils.toString(outAccountUuid) + ", ");
        sb.append("outAccountNo:" + DataUtils.toString(outAccountNo) + ", ");
        sb.append("inUserUuid:" + DataUtils.toString(inUserUuid) + ", ");
        sb.append("inAccountUuid:" + DataUtils.toString(inAccountUuid) + ", ");
        sb.append("inAccountNo:" + DataUtils.toString(inAccountNo) + ", ");
        sb.append("creatTime:" + DataUtils.toString(creatTime) + ", ");
        sb.append("transactionStatus:" + DataUtils.toString(transactionStatus) + ", ");
        sb.append("auditOperator:" + DataUtils.toString(auditOperator) + ", ");
        sb.append("auditTime:" + DataUtils.toString(auditTime) + ", ");
        sb.append("auditOpinion:" + DataUtils.toString(auditOpinion) + ", ");
        sb.append("payedOperator:" + DataUtils.toString(payedOperator) + ", ");
        sb.append("payedTime:" + DataUtils.toString(payedTime) + ", ");
        sb.append("signature:" + DataUtils.toString(signature) + ", ");
        sb.append("deleteFlag:" + DataUtils.toString(deleteFlag) + ", ");
        sb.append("createTime:" + DataUtils.toString(createTime) + ", ");
        sb.append("updateTime:" + DataUtils.toString(updateTime));
        return sb.toString();
    }
}
