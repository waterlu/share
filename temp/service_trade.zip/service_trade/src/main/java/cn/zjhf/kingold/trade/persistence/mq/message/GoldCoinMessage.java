package cn.zjhf.kingold.trade.persistence.mq.message;

import cn.zjhf.kingold.rocketmq.base.MQMessage;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by wangxun on 18/1/15.
 */
public class GoldCoinMessage implements MQMessage {

    /**
     * mq唯一主键
     */
    private String key;

    private String gcUuid;

    /**
     * 完成任务产生金币人uuid
     */
    private String gcCreateUserUuid;

    /**
     * 场景编码(1注册,2实名,3首次绑卡,4首次充值,5首次投资,6邀请好友首次投资,7复投,8邀请好友注册,9分享，10签到，99指定发放，100金币兑换)
     */
    private Integer gcApplyScene;

    /**
     * 金币总数量
     */
    private BigDecimal gcTotalAmount;


    /**
     * 金币激活时间
     */
    private Date gcActiveTime;

    public String getGcCreateUserUuid() {
        return gcCreateUserUuid;
    }

    public void setGcCreateUserUuid(String gcCreateUserUuid) {
        this.gcCreateUserUuid = gcCreateUserUuid;
    }

    public Integer getGcApplyScene() {
        return gcApplyScene;
    }

    public void setGcApplyScene(Integer gcApplyScene) {
        this.gcApplyScene = gcApplyScene;
    }

    public BigDecimal getGcTotalAmount() {
        return gcTotalAmount;
    }

    public void setGcTotalAmount(BigDecimal gcTotalAmount) {
        this.gcTotalAmount = gcTotalAmount;
    }

    public Date getGcActiveTime() {
        return gcActiveTime;
    }

    public void setGcActiveTime(Date gcActiveTime) {
        this.gcActiveTime = gcActiveTime;
    }

    public String getGcUuid() {
        return gcUuid;
    }

    public void setGcUuid(String gcUuid) {
        this.gcUuid = gcUuid;
    }

    public void setKey(String key) {
        this.key = key;
    }

    @Override
    public String getKey() {
        return key;
    }

    @Override
    public String toString() {
        return "GoldCoinMessage{" +
                "key='" + key + '\'' +
                ", gcUuid='" + gcUuid + '\'' +
                ", gcCreateUserUuid='" + gcCreateUserUuid + '\'' +
                ", gcApplyScene=" + gcApplyScene +
                ", gcTotalAmount=" + gcTotalAmount +
                ", gcActiveTime=" + gcActiveTime +
                '}';
    }
}
