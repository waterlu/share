package cn.zjhf.kingold.trade.exception;

import cn.zjhf.kingold.common.exception.BusinessException;

/**
 * @author lutiehua
 * @date 2018/3/12
 */
public class PendingException extends BusinessException {

    public PendingException() {
        super(500, "处理中");
    }
}
