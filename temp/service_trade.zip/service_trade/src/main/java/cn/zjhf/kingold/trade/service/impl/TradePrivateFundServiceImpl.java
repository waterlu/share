package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.constant.TradeType;
import cn.zjhf.kingold.trade.persistence.dao.TradeOrderMapper;
import cn.zjhf.kingold.trade.persistence.dao.TradePrivateFundOrderMapper;
import cn.zjhf.kingold.trade.persistence.dao.TradeRechargeMapper;
import cn.zjhf.kingold.trade.service.ITradeOrderService;
import cn.zjhf.kingold.trade.service.ITradePrivateFundOrderService;
import cn.zjhf.kingold.trade.utils.RandUtil;
import cn.zjhf.kingold.trade.utils.ZJBuzzUtils;
import com.alibaba.fastjson.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by wangxun on 2016/11/04.
 * Copyright by zjinv
 */
@Service
public class TradePrivateFundServiceImpl implements ITradePrivateFundOrderService {
    private static final Logger LOGGER = LoggerFactory.getLogger(TradePrivateFundServiceImpl.class);

    @Autowired
    private TradePrivateFundOrderMapper tradePrivateFundOrderMapper;

    @Value("${system.run.model}")
    public String runModel;

    @Value("${app.admin.verify.code}")
    public String adminVerifyCode;

    /**
     * 获取订单列表
     *
     * @param params 参数选填：pfoCode,reservationBillCode,reservationUuid,pfoStatusList
     * @return
     * @throws BusinessException
     */
    @Override
    public Map getWithFilter(Map params) throws BusinessException {
        LOGGER.info("获取订单列表"+ JSONObject.toJSONString(params));
        return tradePrivateFundOrderMapper.get(params);
    }

    /**
     * 插入私募订单
     * @param params 参数选填： tradePrivateFundOrder对象所有属性 必填：pfoCode
     * @return
     * @throws BusinessException
     */
    @Override
    public Integer insert(Map params) throws BusinessException {
        String orderCode = ZJBuzzUtils.generateOrderBillCode(TradeType.TRADE_PRODUCT_ORDER);
        params.put("pfoCode",orderCode);
        params.put("pfoStatus","0");
        LOGGER.info("插入私募订单，param:"+ JSONObject.toJSONString(params));
        return tradePrivateFundOrderMapper.insert(params);
    }

    /**
     * 获取订单列表
     * @param params 参数选填： tradePrivateFundOrder对象所有属性 必填：pfoCode
     * @return
     * @throws BusinessException
     */
    @Override
    public int update(Map params) throws BusinessException {
        LOGGER.info("更新私募订单，param:"+ JSONObject.toJSONString(params));
        return tradePrivateFundOrderMapper.update(params);
    }

    /**
     * 获取订单列表
     * @param params 参数选填：pfoCode
     * @return
     * @throws BusinessException
     */
    @Override
    public List<Map> getList(Map params) throws BusinessException {
        LOGGER.info("获取私募订单列表，param:"+ JSONObject.toJSONString(params));
        List<Map> userList = tradePrivateFundOrderMapper.getList(params);

        return userList;
    }

    /**
     * 获取订单总数
     *
     * @param params 参数选填：pfoCode
     * @return
     * @throws BusinessException
     */
    @Override
    public Integer getCount(Map params) throws BusinessException {
        LOGGER.info("获取私募订单列表总数，param:"+ JSONObject.toJSONString(params));
        Integer result = tradePrivateFundOrderMapper.getCount(params);
        return result;
    }

    /**
     * 获取目前已经生成私募订单的金额（不包含申请驳回状态数据）
     *
     * @param params 参数选填(选一个)：productUuid,productCode
     * @return
     * @throws BusinessException
     */
    @Override
    public BigDecimal getOrderPurchaseSum(Map params) throws BusinessException {
        LOGGER.info(" 获取目前已经生成私募订单的金额（不包含申请驳回状态数据），param:"+ JSONObject.toJSONString(params));
        return tradePrivateFundOrderMapper.getOrderPurchaseSum(params);
    }

    /**
     * 获取目前已经生成私募订单的金额（仅已通过的状态数据）
     *
     * @param params 参数选填(选一个)：productUuid,productCode
     * @return
     * @throws BusinessException
     */
    @Override
    public BigDecimal getOrderVerifyPurchaseSum(Map params) throws BusinessException {
        LOGGER.info(" 获取目前已经生成私募订单的金额（不包含申请驳回状态数据），param:"+ JSONObject.toJSONString(params));
        return tradePrivateFundOrderMapper.getOrderVerifyPurchaseSum(params);
    }


    @Override
    public BigDecimal querySumAmountByUser(String userUuid, String idCardNo) throws BusinessException {
        Map<String, String> param = new HashMap<>();
        param.put("userUuid", userUuid);
        param.put("customerIdCardNo", idCardNo);
        return tradePrivateFundOrderMapper.querySumAmountByUser(param);
    }

}