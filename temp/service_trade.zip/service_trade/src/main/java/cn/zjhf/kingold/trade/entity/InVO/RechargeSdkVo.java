package cn.zjhf.kingold.trade.entity.InVO;

import org.hibernate.validator.constraints.NotEmpty;

/**
 * Created by liuyao on 2017/7/13.
 */
public class RechargeSdkVo extends InVOBase{
    @NotEmpty
    private Long userId;
    @NotEmpty
    private String orderId;
    @NotEmpty
    private Double amount;
    @NotEmpty
    private String returnUrl;

    private Double fee;

    private Integer feeTakenOn;

    private String pageUrl;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getReturnUrl() {
        return returnUrl;
    }

    public void setReturnUrl(String returnUrl) {
        this.returnUrl = returnUrl;
    }

    public Double getFee() {
        return fee;
    }

    public void setFee(Double fee) {
        this.fee = fee;
    }

    public Integer getFeeTakenOn() {
        return feeTakenOn;
    }

    public void setFeeTakenOn(Integer feeTakenOn) {
        this.feeTakenOn = feeTakenOn;
    }

    public String getPageUrl() {
        return pageUrl;
    }

    public void setPageUrl(String pageUrl) {
        this.pageUrl = pageUrl;
    }

    @Override
    public String toString() {
        return "RechargeSdkVo{" +
                "userId=" + userId +
                ", orderId='" + orderId + '\'' +
                ", amount=" + amount +
                ", returnUrl='" + returnUrl + '\'' +
                ", fee=" + fee +
                ", feeTakenOn=" + feeTakenOn +
                ", pageUrl='" + pageUrl + '\'' +
                '}';
    }
}
