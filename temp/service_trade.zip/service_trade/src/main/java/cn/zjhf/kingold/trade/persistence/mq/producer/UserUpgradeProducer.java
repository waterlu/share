package cn.zjhf.kingold.trade.persistence.mq.producer;

import cn.zjhf.kingold.rocketmq.annotation.RocketMQProducer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQProducer;
import cn.zjhf.kingold.trade.persistence.mq.message.UserUpgradeMessage;

/**
 * 生产用户升级为理财师消息
 *
 * Created by lutiehua on 2017/7/13.
 */
@RocketMQProducer(topic = "user", tag = "upgrade")
public class UserUpgradeProducer extends AbstractMQProducer<UserUpgradeMessage> {
}