package cn.zjhf.kingold.trade.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.entity.InVO.CouponSpecifiedDistributionAuditVO;
import cn.zjhf.kingold.trade.entity.InVO.LstCouponSpecifiedDistributionConditionVO;
import cn.zjhf.kingold.trade.entity.InVO.LstCouponSpecifiedDistributionDetailConditionVO;
import cn.zjhf.kingold.trade.entity.InVO.LstRedPacketConditionVO;
import cn.zjhf.kingold.trade.entity.OutVO.CommItemListVO;
import cn.zjhf.kingold.trade.entity.OutVO.CouponSpecifiedDistributionRecordItemDetailVO;
import cn.zjhf.kingold.trade.entity.OutVO.CouponSpecifiedDistributionRecordItemListVO;
import cn.zjhf.kingold.trade.entity.OutVO.RedPacketRecordVO;
import cn.zjhf.kingold.trade.utils.Tuple.TwoTuple;

import java.io.InputStream;
import java.math.BigDecimal;
import java.util.List;

/**
 * Created by zhangyijie on 2018/1/26.
 */
public interface IRedPacketService {

    /**
     * 添加指定发放礼券的记录
     * @param redPacketAmount
     * @param userList
     * @param operator
     * @throws BusinessException
     */
    boolean insertSpecifiedDistributionByExcel(BigDecimal redPacketAmount, String specifiedName, List<String> userList, String operator, InputStream input) throws BusinessException;

    /**
     * 添加指定发放礼券的记录
     * @param redPacketAmount
     * @param userList
     * @param operator
     * @throws BusinessException
     */
    boolean insertSpecifiedDistributionByList(BigDecimal redPacketAmount, String specifiedName, List<String> userList, String operator) throws BusinessException;

    /**
     * 非注册用户列表
     * @param userPhoneList
     * @return
     * @throws BusinessException
     */
    List<String> getUnRegistUserphone(List<String> userPhoneList) throws BusinessException;

    /**
     * 查询现金券指定发放记录
     * @param
     * @return
     * @throws BusinessException
     */
    CouponSpecifiedDistributionRecordItemListVO lstCouponSpecifiedDistributionRecord(LstCouponSpecifiedDistributionConditionVO lstCondition) throws BusinessException;

    /**
     * 查询现金券指定发放记录明细
     * @param
     * @return
     * @throws BusinessException
     */
    CouponSpecifiedDistributionRecordItemDetailVO lstCouponSpecifiedDistributionDetail(LstCouponSpecifiedDistributionDetailConditionVO lstCondition) throws BusinessException;

    /**
     * 现金券指定发放记录审核
     * @param
     * @return
     * @throws BusinessException
     */
    boolean couponSpecifiedDistributionAudit(CouponSpecifiedDistributionAuditVO auditInfo) throws BusinessException;

    /**
     * 删除未实际发放的现金红包指定发放
     * @param
     * @return
     * @throws BusinessException
     */
    boolean deleteCouponSpecifiedDistribution(Long auditId) throws BusinessException;

    /**
     * 查询红包发放记录
     * @param
     * @return
     * @throws BusinessException
     */
    CommItemListVO<RedPacketRecordVO> lstRedPacketRecord(LstRedPacketConditionVO lstCondition) throws BusinessException;

    /**
     * 领取红包
     * @param
     * @return 1领取成功，2领取失败
     * @throws BusinessException
     */
    int drawRedPacketList(String redPacketIds) throws BusinessException;

    /**
     * 根据查询条件获取记录数量
     * @param
     * @return
     * @throws BusinessException
     */
    int countRedPacketRecord(LstRedPacketConditionVO lstCondition) throws BusinessException;

    /**
     * 根据查询条件查询红包总额
     * @param
     * @return
     * @throws BusinessException
     */
    double totalRedPacketRecord(LstRedPacketConditionVO lstCondition) throws BusinessException;

    /**
     * 创建红包记录
     * @param auditId
     * @param userUuid
     * @param phoneNumber
     * @param phoneName
     * @param amount
     * @return
     * @throws BusinessException
     */
    int establishRedPacketRecord(Long auditId, String userUuid, String phoneNumber, String phoneName, BigDecimal amount) throws BusinessException;
}
