package cn.zjhf.kingold.trade.persistence.dao;

import cn.zjhf.kingold.trade.entity.AccountUnpaidFund;
import cn.zjhf.kingold.trade.entity.AccountUnpaidFundExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AccountUnpaidFundMapper {
    long countByExample(AccountUnpaidFundExample example);

    int deleteByExample(AccountUnpaidFundExample example);

    int deleteByPrimaryKey(Long accountTransactionUuid);

    int insert(AccountUnpaidFund record);

    int insertSelective(AccountUnpaidFund record);

    List<AccountUnpaidFund> selectByExample(AccountUnpaidFundExample example);

    AccountUnpaidFund selectByPrimaryKey(Long accountTransactionUuid);

    int updateByExampleSelective(@Param("record") AccountUnpaidFund record, @Param("example") AccountUnpaidFundExample example);

    int updateByExample(@Param("record") AccountUnpaidFund record, @Param("example") AccountUnpaidFundExample example);

    int updateByPrimaryKeySelective(AccountUnpaidFund record);

    int updateByPrimaryKey(AccountUnpaidFund record);
}