package cn.zjhf.kingold.trade.lock;

import com.mysql.jdbc.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 分布式锁
 *
 * @author lutiehua
 * @date 2018/3/7
 */
@Component
public class DistributedLock {

    private static final Logger LOGGER = LoggerFactory.getLogger(DistributedLock.class);

    @Resource
    private RedisTemplate<String, String> redisTemplate;

    private ThreadLocal<String> localValue = new ThreadLocal<>();

    /**
     * 加锁
     *
     * @return 得到锁返回true，返回false表示没有得到锁
     */
    public boolean lock(String key, long seconds) {

        long timeout = System.currentTimeMillis() + seconds * 1000;
        String value = Long.toString(timeout);

        // 保存过期时间
        localValue.set(value);

        // 获得锁直接返回true
        if(redisTemplate.opsForValue().setIfAbsent(key, value)) {
            LOGGER.info("lock {} {} seconds", key, seconds);
            return true;
        }

        // Key已经存在，检查锁是否超时
        String currentValue = redisTemplate.opsForValue().get(key);
        if (!StringUtils.isNullOrEmpty(currentValue)) {
            timeout = Long.parseLong(currentValue);
            if (System.currentTimeMillis() > timeout) {
                // 锁已经过期
                String oldValue  = redisTemplate.opsForValue().getAndSet(key, value);
                // 如果oldValue=currentValue说明是自己getAndSet的
                if (!StringUtils.isNullOrEmpty(oldValue) && oldValue.equals(currentValue)) {
                    // 我抢到了锁
                    LOGGER.info("renew lock {} {} seconds", key, seconds);
                    return true;
                }
            }
        }

        LOGGER.error("lock {} failed", key);
        return false;
    }

    /**
     * 解锁
     *
     */
    public void unlock(String key){
        LOGGER.info("unlock {}", key);

        String currentValue = redisTemplate.opsForValue().get(key);

        // 读取过期时间
        String value = localValue.get();

        // 值相等才是自己的锁，有可能已经过期被别人占用了
        // 没有被删除的锁在过期后可以被使用
        if(!StringUtils.isNullOrEmpty(currentValue) && currentValue.equals(value)) {
            LOGGER.info("remove redis key {}", key);
            redisTemplate.opsForValue().getOperations().delete(key);
        }
    }
}
