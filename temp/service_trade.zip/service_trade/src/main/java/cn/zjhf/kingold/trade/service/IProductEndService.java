package cn.zjhf.kingold.trade.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.entity.InVO.LstProductExpireCashItemsVO;
import cn.zjhf.kingold.trade.entity.InVO.LstProductExpireCashVO;
import cn.zjhf.kingold.trade.entity.OutVO.*;
import cn.zjhf.kingold.trade.vo.LoanCashedDetailVO;

import java.util.List;

/**
 * Created by zhangyijie on 2017/5/19.
 */
public interface IProductEndService {
    /**
     * Step1 产品到期
     *
     * @param product_uuid 产品ID
     * @param createBy 操作人
     * @return
     * @throws BusinessException
     */
    public void fixedProductEnd(String product_uuid, String createBy) throws BusinessException;

    /**
     * Step1 产品到期
     *
     * @param product_uuid 产品ID
     * @param createBy 操作人
     * @return
     * @throws BusinessException
     */
    public void privateProductEnd(String product_uuid, String createBy) throws BusinessException;

    /**
     * Step2 产品到期_兑付查询(维度:产品，列表)
     * @return
     * @throws BusinessException
     */
    public TradePaymentSummaryListVO lstProductExpireCash(LstProductExpireCashVO lstProductExpireCashVO) throws BusinessException;

    /**
     * Step3 产品到期_兑付详情(维度:产品，单记录)
     * @return
     * @throws BusinessException
     */
    public TradePaymentSummaryExVO getProductExpireCashDetail(String productUUId) throws BusinessException;

    /**
     * Step4 产品到期_兑付明细(维度:产品-交易，列表)
     * @return
     * @throws BusinessException
     */
    public  CommItemListVO<LoanCashedDetailVO> lstProductExpireCashItems(LstProductExpireCashItemsVO lstProductExpireCashItemsVO) throws BusinessException;

    /**
     * Step5 产品到期_兑付_审核
     * isAudited 1审核通过  0审核未通过
     * @return
     * @throws BusinessException
     */
    public boolean productExpireCashAudit(String userPhone, String productUUId, int isAudited, String message) throws BusinessException;

    /**
     * Step6 产品到期_兑付_清算
     * @return
     * @throws BusinessException
     */
    public TradePaymentSummaryExVO productExpireCashClear(String userPhone, String productUUId, String createBy) throws BusinessException;

    /**
     * 体验金产品，兑付收益
     * @param userUuid
     * @param profitAmt
     * @param transactionChannel
     * @param orderNo
     * @throws BusinessException
     */
    public void experienceProfitPayment(String userUuid, double profitAmt, String transactionChannel, String orderNo) throws BusinessException;

    /**
     * 将产品到期发放礼券的用户手机号放入redis
     * @param phoneNumList
     * @throws BusinessException
     */
    public void addCashCouponMess(List<String> phoneNumList) throws BusinessException;

    /**
     * 发送产品到期发放礼券的用户短信
     * @throws BusinessException
     */
    public void sendCashCouponMess() throws BusinessException;
}
