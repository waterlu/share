package cn.zjhf.kingold.trade.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.dto.RewardApplyDto;
import cn.zjhf.kingold.trade.dto.RewardFixedClearDto;
import cn.zjhf.kingold.trade.dto.RewardFixedSearchDto;
import cn.zjhf.kingold.trade.entity.RewardFixedTerm;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * Created by lutiehua on 2017/6/2.
 */
public interface IRewardSummaryExecService {

    /**
     * 为了事务
     *
     * @param rewardFixedTerm
     * @return
     */
    ResponseResult executeClearOperation(RewardFixedTerm rewardFixedTerm) throws BusinessException;


    /**
     * 活动奖励1.向平台账户转账 2.记录明细流水
     *
     * @param userUuid
     * @param campaignRewardBillCode
     * @param amount
     * @return
     * @throws BusinessException
     */
    ResponseResult executeCampaignRewardOperation(String userUuid, String campaignRewardBillCode, BigDecimal amount) throws BusinessException;
}
