package cn.zjhf.kingold.trade.persistence.mq.message;

import cn.zjhf.kingold.rocketmq.base.MQMessage;
import cn.zjhf.kingold.trade.entity.TradeOrder;

/**
 * 定期订单认购成功消息
 *
 * @author lutiehua
 * @date 2017/6/27
 */
public class OrderPaidMessage extends TradeOrder implements MQMessage {

//    /**
//     * 产品ID
//     */
//    private Long productID;
//
//    /**
//     * 融资人账户
//     */
//    private Long payeeAccountNo;
//
//    /**
//     * 投资人账户
//     */
//    private Long payerAccountNo;
//
//    public Long getProductID() {
//        return productID;
//    }
//
//    public void setProductID(Long productID) {
//        this.productID = productID;
//    }
//
//    public Long getPayeeAccountNo() {
//        return payeeAccountNo;
//    }
//
//    public void setPayeeAccountNo(Long payeeAccountNo) {
//        this.payeeAccountNo = payeeAccountNo;
//    }
//
//    public Long getPayerAccountNo() {
//        return payerAccountNo;
//    }
//
//    public void setPayerAccountNo(Long payerAccountNo) {
//        this.payerAccountNo = payerAccountNo;
//    }

    @Override
    public String getKey() {
        return getOrderBillCode();
    }

    @Override
    public String toString() {
        return super.toString() + ", OrderPaidMessage{" +
                "productID=" + productID +
                ", payeeAccountNo=" + payeeAccountNo +
                '}';
    }
}
