package cn.zjhf.kingold.trade.baofoo;

import java.util.List;

/**
 * Created by lutiehua on 2017/5/6.
 */
public class QueryByOrderResult {

    public List<OrderResponse> getOrder() {
        return order;
    }

    public void setOrder(List<OrderResponse> order) {
        this.order = order;
    }

    private List<OrderResponse> order;


}
