package cn.zjhf.kingold.trade.entity.OutVO;

import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Size;
import java.util.Date;

/**
 * Created by zhangyijie on 2017/10/12.
 */
public class ChannelTradeCommisionItemVO {
    @ApiModelProperty(required = true, value = "订单号/产品订单编号/宝付订单号")
    @NotEmpty
    @Size(min = 1, max = 32)
    private String orderBillCode;

    @ApiModelProperty(required = true, value = "用户名/手机号码")
    @NotEmpty
    @Size(min = 1, max = 11)
    private String userPhone;

    @ApiModelProperty(required = true, value = "用户姓名")
    @NotEmpty
    @Size(min = 1, max = 20)
    private String userName;

    @ApiModelProperty(required = true, value = "投资产品")
    @NotEmpty
    @Size(min = 1, max = 20)
    private String productAbbrName;

    @ApiModelProperty(required = true, value = "支付时间")
    private Date payedTime;

    @ApiModelProperty(required = true, value = "投资金额")
    @NotEmpty
    private double orderAmount;

    @ApiModelProperty(required = true, value = "佣金")
    @NotEmpty
    private double commisionAmount;

    public String getOrderBillCode() {
        return orderBillCode;
    }

    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getProductAbbrName() {
        return productAbbrName;
    }

    public void setProductAbbrName(String productAbbrName) {
        this.productAbbrName = productAbbrName;
    }

    public Date getPayedTime() {
        return payedTime;
    }

    public void setPayedTime(Date payedTime) {
        this.payedTime = payedTime;
    }

    public double getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(double orderAmount) {
        this.orderAmount = orderAmount;
    }

    public double getCommisionAmount() {
        return commisionAmount;
    }

    public void setCommisionAmount(double commisionAmount) {
        this.commisionAmount = commisionAmount;
    }

    public ChannelTradeCommisionItemVO() {
    }

    @Override
    public String toString() {
        return "ChannelTradeCommisionItemVO{" +
                "orderBillCode='" + orderBillCode + '\'' +
                ", userPhone='" + userPhone + '\'' +
                ", userName='" + userName + '\'' +
                ", productAbbrName='" + productAbbrName + '\'' +
                ", payedTime=" + payedTime +
                ", orderAmount=" + orderAmount +
                ", commisionAmount=" + commisionAmount +
                '}';
    }
}
