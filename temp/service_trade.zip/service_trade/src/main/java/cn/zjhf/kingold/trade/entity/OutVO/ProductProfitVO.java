package cn.zjhf.kingold.trade.entity.OutVO;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Size;

/**
 * Created by zhangyijie on 2017/5/22.
 */
@ApiModel(value = "ProductProfitVO", description = "产品收益")
public class ProductProfitVO extends ParamVO {
    @ApiModelProperty(required = true, value = "产品UUID")
    @NotEmpty
    @Size(min = 1, max = 32)
    private String productUuid;

    @ApiModelProperty(required = true, value = "产品简称")
    @NotEmpty
    @Size(min = 1, max = 40)
    private String productAbbrName;

    @ApiModelProperty(required = true, value = "产品兑付总金额")
    @NotEmpty
    private double clearTotalAmount;

    @ApiModelProperty(required = true, value = "产品本金总金额")
    @NotEmpty
    private double clearPrincAmount;

    @ApiModelProperty(required = true, value = "产品收益总金额")
    @NotEmpty
    private double clearProfitAmount;

    @ApiModelProperty(required = true, value = "营销加息金额")
    @NotEmpty
    private double marketingRateAmount;

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductAbbrName() {
        return productAbbrName;
    }

    public void setProductAbbrName(String productAbbrName) {
        this.productAbbrName = productAbbrName;
    }

    public double getClearTotalAmount() {
        return clearTotalAmount;
    }

    public void setClearTotalAmount(double clearTotalAmount) {
        this.clearTotalAmount = clearTotalAmount;
    }

    public double getClearPrincAmount() {
        return clearPrincAmount;
    }

    public void setClearPrincAmount(double clearPrincAmount) {
        this.clearPrincAmount = clearPrincAmount;
    }

    public double getClearProfitAmount() {
        return clearProfitAmount;
    }

    public void setClearProfitAmount(double clearProfitAmount) {
        this.clearProfitAmount = clearProfitAmount;
    }

    public double getMarketingRateAmount() {
        return marketingRateAmount;
    }

    public void setMarketingRateAmount(double marketingRateAmount) {
        this.marketingRateAmount = marketingRateAmount;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("productUuid:" + DataUtils.toString(productUuid) + ", ");
        sb.append("productAbbrName:" + DataUtils.toString(productAbbrName) + ", ");
        sb.append("clearTotalAmount:" + DataUtils.toString(clearTotalAmount) + ", ");
        sb.append("clearPrincAmount:" + DataUtils.toString(clearPrincAmount) + ", ");
        sb.append("clearProfitAmount:" + DataUtils.toString(clearProfitAmount) + ", ");
        sb.append("marketingRateAmount:" + DataUtils.toString(marketingRateAmount));
        return sb.toString();
    }
}
