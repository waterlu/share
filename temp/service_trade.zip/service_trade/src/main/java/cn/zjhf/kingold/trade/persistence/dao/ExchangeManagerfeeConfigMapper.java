package cn.zjhf.kingold.trade.persistence.dao;

import cn.zjhf.kingold.trade.entity.ExchangeManagerfeeConfig;
import cn.zjhf.kingold.trade.entity.ExchangeManagerfeeConfigExample;
import java.util.List;

import cn.zjhf.kingold.trade.entity.PlatformCommissionConfig;
import cn.zjhf.kingold.trade.utils.WhereCondition;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface ExchangeManagerfeeConfigMapper {
    long countByExample(ExchangeManagerfeeConfigExample example);

    int deleteByExample(ExchangeManagerfeeConfigExample example);

    int deleteByPrimaryKey(Long exchangeManagerfeeId);

    int insert(ExchangeManagerfeeConfig record);

    int insertSelective(ExchangeManagerfeeConfig record);

    @Delete("DELETE FROM exchange_managerfee_config where product_uuid = #{productUuid}")
    int deleteByProductUuid(@Param("productUuid") String productUuid);

    List<ExchangeManagerfeeConfig> lstByCondition(WhereCondition condition);

    List<ExchangeManagerfeeConfig> selectByExample(ExchangeManagerfeeConfigExample example);

    ExchangeManagerfeeConfig selectByPrimaryKey(Long exchangeManagerfeeId);

    int updateByExampleSelective(@Param("record") ExchangeManagerfeeConfig record, @Param("example") ExchangeManagerfeeConfigExample example);

    int updateByExample(@Param("record") ExchangeManagerfeeConfig record, @Param("example") ExchangeManagerfeeConfigExample example);

    int updateByPrimaryKeySelective(ExchangeManagerfeeConfig record);

    int updateByPrimaryKey(ExchangeManagerfeeConfig record);
}