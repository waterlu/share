package cn.zjhf.kingold.trade.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author 
 */
public class ProductRewardSummary implements Serializable {
    /**
     * 产品奖励记录申请编号,自增ID
     */
    private Long productRewardSummaryUuid;

    /**
     * 产品UUID
     */
    private String productUuid;

    /**
     * 产品编码
     */
    private String productCode;

    /**
     * 产品简称
     */
    private String productAbbrName;

    /**
     * 产品类型
     */
    private String productType;

    /**
     * 产品成立日, 格式为 YYYY-MM-DD
     */
    private Date productEstablishmentDate;

    /**
     * 奖励记录数
     */
    private Integer rewardCount;

    /**
     * 已结算奖励记录数
     */
    private Integer rewardClearCount;

    /**
     * 理财顾问数量
     */
    private Integer financialAdvisorCount;

    /**
     * 税前理顾佣金
     */
    private BigDecimal pretaxRewardAmount;

    /**
     * 税前平台服务费
     */
    private BigDecimal pretaxPlatformServicefee;

    /**
     * (平台服务费的)扣税
     */
    private BigDecimal platformServicefeeTax;

    /**
     * 税后平台服务费
     */
    private BigDecimal aftertaxPlatformServicefee;

    /**
     * 交易所管理费
     */
    private BigDecimal exchangeManageFee;

    /**
     * 平台收入
     */
    private BigDecimal platformIncome;

    /**
     * 放款时间
     */
    private Date loanTime;

    /**
     * 收入报税审核人
     */
    private String incomeTaxAuditOperator;

    /**
     * 收入报税审核时间
     */
    private Date incomeTaxAuditTime;

    /**
     * 收入报税审核意见
     */
    private String incomeTaxAuditOpinion;

    /**
     * 收入报税结算人
     */
    private String incomeTaxClearOperator;

    /**
     * 收入报税结算时间
     */
    private Date incomeTaxClearTime;

    /**
     * 收入报税处理状态：-1审批失败；1待审核；2审核通过; 3已结算
     */
    private Byte incomeTaxClearStatus;

    /**
     * 管理费审核人
     */
    private String exchangeManagefeeAuditOperator;

    /**
     * 管理费审核时间
     */
    private Date exchangeManagefeeAuditTime;

    /**
     * 管理费审核意见
     */
    private String exchangeManagefeeAuditOpinion;

    /**
     * 管理费结算人
     */
    private String exchangeManagefeeClearOperator;

    /**
     * 管理费结算时间
     */
    private Date exchangeManagefeeClearTime;

    /**
     * 管理费处理状态：-1审批失败；1待审核；2审核通过; 3已结算
     */
    private Byte exchangeManagefeeClearStatus;

    /**
     * 签名
     */
    private String signature;

    /**
     * 删除标记 0未删除，1已删除
     */
    private Byte deleteFlag;

    /**
     * 产品期限
     */
    private Integer productPeriod;

    /**
     * 募集金额/产品规模
     */
    private BigDecimal productScale;

    /**
     * 管理费率
     */
    private BigDecimal managementFee;

    /**
     * 实际募集金额
     */
    private BigDecimal productAccumulation;

    /**
     * 服务费率
     */
    private BigDecimal platformCommission;

    private Date createTime;

    private Date updateTime;

    /**
     * 募集方名称
     */
    private String productIssuerName;

    private static final long serialVersionUID = 1L;

    public Long getProductRewardSummaryUuid() {
        return productRewardSummaryUuid;
    }

    public void setProductRewardSummaryUuid(Long productRewardSummaryUuid) {
        this.productRewardSummaryUuid = productRewardSummaryUuid;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductAbbrName() {
        return productAbbrName;
    }

    public void setProductAbbrName(String productAbbrName) {
        this.productAbbrName = productAbbrName;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public Date getProductEstablishmentDate() {
        return productEstablishmentDate;
    }

    public void setProductEstablishmentDate(Date productEstablishmentDate) {
        this.productEstablishmentDate = productEstablishmentDate;
    }

    public Integer getRewardCount() {
        return rewardCount;
    }

    public void setRewardCount(Integer rewardCount) {
        this.rewardCount = rewardCount;
    }

    public Integer getRewardClearCount() {
        return rewardClearCount;
    }

    public void setRewardClearCount(Integer rewardClearCount) {
        this.rewardClearCount = rewardClearCount;
    }

    public Integer getFinancialAdvisorCount() {
        return financialAdvisorCount;
    }

    public void setFinancialAdvisorCount(Integer financialAdvisorCount) {
        this.financialAdvisorCount = financialAdvisorCount;
    }

    public BigDecimal getPretaxRewardAmount() {
        return pretaxRewardAmount;
    }

    public void setPretaxRewardAmount(BigDecimal pretaxRewardAmount) {
        this.pretaxRewardAmount = pretaxRewardAmount;
    }

    public BigDecimal getPretaxPlatformServicefee() {
        return pretaxPlatformServicefee;
    }

    public void setPretaxPlatformServicefee(BigDecimal pretaxPlatformServicefee) {
        this.pretaxPlatformServicefee = pretaxPlatformServicefee;
    }

    public BigDecimal getPlatformServicefeeTax() {
        return platformServicefeeTax;
    }

    public void setPlatformServicefeeTax(BigDecimal platformServicefeeTax) {
        this.platformServicefeeTax = platformServicefeeTax;
    }

    public BigDecimal getAftertaxPlatformServicefee() {
        return aftertaxPlatformServicefee;
    }

    public void setAftertaxPlatformServicefee(BigDecimal aftertaxPlatformServicefee) {
        this.aftertaxPlatformServicefee = aftertaxPlatformServicefee;
    }

    public BigDecimal getExchangeManageFee() {
        return exchangeManageFee;
    }

    public void setExchangeManageFee(BigDecimal exchangeManageFee) {
        this.exchangeManageFee = exchangeManageFee;
    }

    public BigDecimal getPlatformIncome() {
        return platformIncome;
    }

    public void setPlatformIncome(BigDecimal platformIncome) {
        this.platformIncome = platformIncome;
    }

    public Date getLoanTime() {
        return loanTime;
    }

    public void setLoanTime(Date loanTime) {
        this.loanTime = loanTime;
    }

    public String getIncomeTaxAuditOperator() {
        return incomeTaxAuditOperator;
    }

    public void setIncomeTaxAuditOperator(String incomeTaxAuditOperator) {
        this.incomeTaxAuditOperator = incomeTaxAuditOperator;
    }

    public Date getIncomeTaxAuditTime() {
        return incomeTaxAuditTime;
    }

    public void setIncomeTaxAuditTime(Date incomeTaxAuditTime) {
        this.incomeTaxAuditTime = incomeTaxAuditTime;
    }

    public String getIncomeTaxAuditOpinion() {
        return incomeTaxAuditOpinion;
    }

    public void setIncomeTaxAuditOpinion(String incomeTaxAuditOpinion) {
        this.incomeTaxAuditOpinion = incomeTaxAuditOpinion;
    }

    public String getIncomeTaxClearOperator() {
        return incomeTaxClearOperator;
    }

    public void setIncomeTaxClearOperator(String incomeTaxClearOperator) {
        this.incomeTaxClearOperator = incomeTaxClearOperator;
    }

    public Date getIncomeTaxClearTime() {
        return incomeTaxClearTime;
    }

    public void setIncomeTaxClearTime(Date incomeTaxClearTime) {
        this.incomeTaxClearTime = incomeTaxClearTime;
    }

    public Byte getIncomeTaxClearStatus() {
        return incomeTaxClearStatus;
    }

    public void setIncomeTaxClearStatus(Byte incomeTaxClearStatus) {
        this.incomeTaxClearStatus = incomeTaxClearStatus;
    }

    public String getExchangeManagefeeAuditOperator() {
        return exchangeManagefeeAuditOperator;
    }

    public void setExchangeManagefeeAuditOperator(String exchangeManagefeeAuditOperator) {
        this.exchangeManagefeeAuditOperator = exchangeManagefeeAuditOperator;
    }

    public Date getExchangeManagefeeAuditTime() {
        return exchangeManagefeeAuditTime;
    }

    public void setExchangeManagefeeAuditTime(Date exchangeManagefeeAuditTime) {
        this.exchangeManagefeeAuditTime = exchangeManagefeeAuditTime;
    }

    public String getExchangeManagefeeAuditOpinion() {
        return exchangeManagefeeAuditOpinion;
    }

    public void setExchangeManagefeeAuditOpinion(String exchangeManagefeeAuditOpinion) {
        this.exchangeManagefeeAuditOpinion = exchangeManagefeeAuditOpinion;
    }

    public String getExchangeManagefeeClearOperator() {
        return exchangeManagefeeClearOperator;
    }

    public void setExchangeManagefeeClearOperator(String exchangeManagefeeClearOperator) {
        this.exchangeManagefeeClearOperator = exchangeManagefeeClearOperator;
    }

    public Date getExchangeManagefeeClearTime() {
        return exchangeManagefeeClearTime;
    }

    public void setExchangeManagefeeClearTime(Date exchangeManagefeeClearTime) {
        this.exchangeManagefeeClearTime = exchangeManagefeeClearTime;
    }

    public Byte getExchangeManagefeeClearStatus() {
        return exchangeManagefeeClearStatus;
    }

    public void setExchangeManagefeeClearStatus(Byte exchangeManagefeeClearStatus) {
        this.exchangeManagefeeClearStatus = exchangeManagefeeClearStatus;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Integer getProductPeriod() {
        return productPeriod;
    }

    public void setProductPeriod(Integer productPeriod) {
        this.productPeriod = productPeriod;
    }

    public BigDecimal getProductScale() {
        return productScale;
    }

    public void setProductScale(BigDecimal productScale) {
        this.productScale = productScale;
    }

    public BigDecimal getManagementFee() {
        return managementFee;
    }

    public void setManagementFee(BigDecimal managementFee) {
        this.managementFee = managementFee;
    }

    public BigDecimal getProductAccumulation() {
        return productAccumulation;
    }

    public void setProductAccumulation(BigDecimal productAccumulation) {
        this.productAccumulation = productAccumulation;
    }

    public BigDecimal getPlatformCommission() {
        return platformCommission;
    }

    public void setPlatformCommission(BigDecimal platformCommission) {
        this.platformCommission = platformCommission;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getProductIssuerName() {
        return productIssuerName;
    }

    public void setProductIssuerName(String productIssuerName) {
        this.productIssuerName = productIssuerName;
    }
}