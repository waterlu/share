package cn.zjhf.kingold.trade.persistence.mq.consumer;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.rocketmq.annotation.RocketMQConsumer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQConsumer;
import cn.zjhf.kingold.trade.persistence.mq.message.ContractFillMessage;
import cn.zjhf.kingold.trade.service.ITradeService;
import cn.zjhf.kingold.trade.utils.DataUtils;
import cn.zjhf.kingold.trade.utils.Tuple.ThreeTuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * Created by zhangyijie on 2018/3/12.
 */
@RocketMQConsumer(topic = "product", tag = "establishloanclear_contractfill")
public class ContractFillConsumer extends AbstractMQConsumer<ContractFillMessage> {
    protected static final Logger logger = LoggerFactory.getLogger(ContractFillConsumer.class);

    @Autowired
    ITradeService tradeServiceImpl;

    @Override
    public ResponseResult process(ContractFillMessage contractFillMessage) throws BusinessException {
        logger.info("ContractFillConsumer_start: {}", contractFillMessage);

        if((contractFillMessage!=null) && (DataUtils.isNotEmpty(contractFillMessage.getProductUuid()))) {
            List<ThreeTuple<String, String, String>> contractFileInfoList = tradeServiceImpl.contractFill(contractFillMessage.getProductUuid());
            //tradeServiceImpl.updateContractFileInfo(contractFileInfoList);
        }else {
            logger.error("Message或者ProductUuid为空");
        }

        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        logger.info("ContractFillConsumer_end: {}", responseResult);
        return responseResult;
    }
}
