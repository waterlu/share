package cn.zjhf.kingold.trade.utils;

import io.swagger.models.auth.In;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by Xiaody on 17/5/17.
 */
public class  DateUtil {
    public static String CURRENTTIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
    public static String DAY_FROMAT = "yyyy-MM-dd";
    /**
     * 字符串型日期yyyy-MM-dd 转化为int  yyyyMMdd
     * @param date
     * @return
     */
    public static int convertDate2Int(String date) {
        return Integer.parseInt(date.replaceAll("-", ""));
    }

    public static String getCueDate() {
        DateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        return sdf.format(new Date());
    }

    /**
     * int型日期yyyyMMdd 转化为字符串型日期  yyyy－MM－dd
     * @param date
     * @return
     */
    public static String convertInt2Date(int date){
        DateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        DateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
        try {
            return sdf2.format(sdf.parse(String.valueOf(date)));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 将Date类型转换成int类型 yyyyMMdd,并支持天位移
     * @param date
     * @return
     */
    public static Integer dateDiff(Date date){
        long from = date.getTime();
        long to = StringOrDate.getCurDate().getTime();

        int days = (int) ((to - from)/(1000 * 60 * 60 * 24));
        ++days;
        return days;
    }

    /**
     * 将Date类型转换成int类型 yyyyMMdd,并支持天位移
     * @param date
     * @return
     */
    public static Integer date2Int(Date date, Integer dayMoved){
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DATE, dayMoved);
        Integer day = calendar.get(Calendar.YEAR) * 10000 + (calendar.get(Calendar.MONTH) + 1) * 100 + calendar.get(Calendar.DATE);
        return day;
    }

    /**
     * 格式化日期
     *
     * @param date
     * @param pattern
     * @return
     */
    public static String formateDate(Date date, String pattern) {
        DateFormat sdf = new SimpleDateFormat(pattern);
        return sdf.format(date);
    }

    public static String formateDate(Date date) {
        DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(date);
    }

    public static String formatTime(Date date) {
        if(date == null) {
            return "";
        }

        DateFormat sdf = new SimpleDateFormat(CURRENTTIME_FORMAT);
        return sdf.format(date);
    }

    public static Date strToTime(String str, String timeFormat) {
        DateFormat format = new SimpleDateFormat(timeFormat);
        Date date = null;
        try {
            // Fri Feb 24 00:00:00 CST 2012
            date = format.parse(str);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return date;
    }

    public static Date strToTime(String str) {
        DateFormat format = new SimpleDateFormat(CURRENTTIME_FORMAT);
        Date date = null;
        try {
            // Fri Feb 24 00:00:00 CST 2012
            date = format.parse(str);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return date;
    }

    public static Date strToDate(String str) {
        DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Date date = null;
        try {
            // Fri Feb 24 00:00:00 CST 2012
            date = format.parse(str);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return date;
    }

    public static Date strToDate(String str,String pattern) {
        DateFormat format = new SimpleDateFormat(pattern);
        Date date = null;
        try {
            // Fri Feb 24 00:00:00 CST 2012
            date = format.parse(str);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return date;
    }

    public static String stringAppendStratTime(String value) {
        if(DataUtils.isNotEmpty(value)){
            StringBuilder sb = new StringBuilder();
            sb.append(value.trim()).append(" 00:00:00");
            return sb.toString();
        }
        return value;
    }

    public static String stringAppendMiddleTime(String value) {
        if(DataUtils.isNotEmpty(value)){
            StringBuilder sb = new StringBuilder();
            sb.append(value.trim()).append(" 12:00:00");
            return sb.toString();
        }
        return value;
    }

    public static String stringAppendEndTime(String value) {
        if(DataUtils.isNotEmpty(value)){
            StringBuilder sb = new StringBuilder();
            sb.append(value.trim()).append(" 23:59:59");
            return sb.toString();
        }
        return value;
    }

}
