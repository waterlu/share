package cn.zjhf.kingold.trade.entity.InVO;

import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import java.util.Date;

/**
 * Created by zhangyijie on 2017/7/5.
 */
public class LstCouponExtendRecordConditionVO extends InVOBase {
    @ApiModelProperty(required = true, value = "礼券编号")
    private String couponExtendCode;

    @ApiModelProperty(required = true, value = "礼券批次号")
    private String couponCode;

    @ApiModelProperty(required = true, value = "用户名")
    private String userPhoneNumber;

    @ApiModelProperty(required = true, value = "礼券状态：1已发放,2已使用,3已过期,4已作废")
    private int couponStatus;

    @ApiModelProperty(required = true, value = "现金券类型：1现金券，2加息券")
    private int couponType;


    @ApiModelProperty(required = true, value = "发放时间_起始")
    private Date beginDate;

    @ApiModelProperty(required = true, value = "发放时间_结束")
    private Date endDate;


    @ApiModelProperty(required = true, value = "起始序号")
    private int beginSN;

    @ApiModelProperty(required = true, value = "结束序号")
    private int endSN;


    public String getCouponExtendCode() {
        return couponExtendCode;
    }

    public void setCouponExtendCode(String couponExtendCode) {
        this.couponExtendCode = couponExtendCode;
    }

    public int getBeginSN() {
        return beginSN;
    }

    public void setBeginSN(int beginSN) {
        this.beginSN = beginSN;
    }

    public int getEndSN() {
        return endSN;
    }

    public void setEndSN(int endSN) {
        this.endSN = endSN;
    }

    public String getCouponCode() {
        return couponCode;
    }

    public void setCouponCode(String couponCode) {
        this.couponCode = couponCode;
    }

    public String getUserPhoneNumber() {
        return userPhoneNumber;
    }

    public void setUserPhoneNumber(String userPhoneNumber) {
        this.userPhoneNumber = userPhoneNumber;
    }

    public int getCouponStatus() {
        return couponStatus;
    }

    public void setCouponStatus(int couponStatus) {
        this.couponStatus = couponStatus;
    }

    public int getCouponType() {
        return couponType;
    }

    public void setCouponType(int couponType) {
        this.couponType = couponType;
    }

    public Date getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(Date beginDate) {
        this.beginDate = beginDate;
    }

    public Date getEndDate() {
        return convertEndDate(endDate);
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(getTraceID()) + ", ");
        sb.append("couponExtendCode:" + DataUtils.toString(couponExtendCode) + ", ");
        sb.append("couponCode:" + DataUtils.toString(couponCode) + ", ");
        sb.append("userPhoneNumber:" + DataUtils.toString(userPhoneNumber) + ", ");
        sb.append("couponStatus:" + DataUtils.toString(couponStatus) + ", ");
        sb.append("couponType:" + DataUtils.toString(couponType) + ", ");

        sb.append("beginDate:" + DataUtils.toString(beginDate) + ", ");
        sb.append("endDate:" + DataUtils.toString(endDate) + ", ");
        sb.append("beginSN:" + DataUtils.toString(beginSN) + ", ");
        sb.append("endSN:" + DataUtils.toString(endSN));
        return sb.toString();
    }
}
