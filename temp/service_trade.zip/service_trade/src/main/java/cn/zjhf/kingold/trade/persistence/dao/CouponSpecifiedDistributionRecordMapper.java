package cn.zjhf.kingold.trade.persistence.dao;

import cn.zjhf.kingold.trade.entity.CouponSpecifiedDistributionRecord;
import cn.zjhf.kingold.trade.entity.CouponSpecifiedDistributionRecordExample;
import java.util.List;
import java.util.Map;

import cn.zjhf.kingold.trade.entity.TradeInvestSummary;
import cn.zjhf.kingold.trade.utils.QueryUtils;
import cn.zjhf.kingold.trade.utils.WhereCondition;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface CouponSpecifiedDistributionRecordMapper {
    long countByExample(CouponSpecifiedDistributionRecordExample example);

    int deleteByExample(CouponSpecifiedDistributionRecordExample example);

    int deleteByPrimaryKey(Long auditId);

    int insert(CouponSpecifiedDistributionRecord record);

    int insertSelective(CouponSpecifiedDistributionRecord record);

    @Select("SELECT * FROM coupon_specified_distribution_record ${condition}")
    @ResultMap("BaseResultMap")
    List<CouponSpecifiedDistributionRecord> lstByCondition(WhereCondition condition);

    @Select("SELECT Count(*) FROM coupon_specified_distribution_record ${condition}")
    int lstCountByCondition(WhereCondition condition);

    @Delete("DELETE FROM coupon_specified_distribution_record_back WHERE audit_id=#{auditId} AND delete_flag=0")
    int deleteBackByAuditId(@Param("auditId") Long auditId);

    @Insert("INSERT INTO coupon_specified_distribution_record_back(" +
            "audit_id, specified_name, specified_type, red_packet_amount, cc_codes, " +
            "user_count, audit_status, audit_operator, audit_time, audit_opinion, " +
            "creator_userid, create_time, delete_flag ) " +
            "SELECT audit_id, specified_name, specified_type, red_packet_amount, cc_codes, " +
            "user_count, audit_status, audit_operator, audit_time, audit_opinion, " +
            "creator_userid, create_time, delete_flag  " +
            "FROM coupon_specified_distribution_record  " +
            "WHERE audit_id=#{auditId} AND audit_status != 2 ")
    int insertBackByAuditId(@Param("auditId") Long auditId);

    @Select("SELECT Max(audit_id) FROM coupon_specified_distribution_record WHERE 1")
    Long lstLastAuditId();

    List<CouponSpecifiedDistributionRecord> selectByExample(CouponSpecifiedDistributionRecordExample example);

    CouponSpecifiedDistributionRecord selectByPrimaryKey(Long auditId);

    int updateByExampleSelective(@Param("record") CouponSpecifiedDistributionRecord record, @Param("example") CouponSpecifiedDistributionRecordExample example);

    int updateByExample(@Param("record") CouponSpecifiedDistributionRecord record, @Param("example") CouponSpecifiedDistributionRecordExample example);

    int updateByPrimaryKeySelective(CouponSpecifiedDistributionRecord record);

    int updateByPrimaryKey(CouponSpecifiedDistributionRecord record);

    int updateByPrimaryKeyEx(CouponSpecifiedDistributionRecord record);
}