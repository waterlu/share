package cn.zjhf.kingold.trade.persistence.dao;

import cn.zjhf.kingold.trade.entity.CouponExtendRecord;
import cn.zjhf.kingold.trade.entity.CouponExtendRecordExample;
import cn.zjhf.kingold.trade.utils.QueryUtils;
import cn.zjhf.kingold.trade.utils.WhereCondition;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;
import java.util.Map;

@Repository
@Mapper
public interface CouponExtendRecordMapper {
    long countByExample(CouponExtendRecordExample example);

    int deleteByExample(CouponExtendRecordExample example);

    int deleteByPrimaryKey(String couponExtendCode);

    int insert(CouponExtendRecord record);

    int insertSelective(CouponExtendRecord record);

    List<CouponExtendRecord> selectByExample(CouponExtendRecordExample example);

    @Insert("${condition}")
    int insertMultipleRecord(QueryUtils condition);

    @Update("UPDATE coupon_extend_record SET cancel_time = now(), delete_flag = 1,coupon_status=#{couponStatus}, update_user_id = #{userId}, cancel_remark = #{cancelRemark}  " +
            "WHERE coupon_extend_code = #{couponExtendCode}")
    int abolishRecord(@Param("couponExtendCode") String couponExtendCode, @Param("userId") String userId, @Param("cancelRemark") String cancelRemark, @Param("couponStatus") int couponStatus);

    @Update("UPDATE coupon_extend_record SET coupon_status = #{couponStatus}, update_user_id = 'sys'  " +
            "WHERE coupon_extend_code = #{couponExtendCode}")
    int updateStatus(@Param("couponExtendCode") String couponExtendCode, @Param("couponStatus") int couponStatus);

    @Update("UPDATE coupon_extend_record SET coupon_status = #{couponStatus}, update_user_id = 'sys'  " +
            "WHERE valid_end_time >= #{lastTime} AND valid_end_time < #{curTime} AND coupon_status = #{oldCouponStatus} LIMIT #{limitCount}")
    int updateStatusEx(@Param("oldCouponStatus") int oldCouponStatus, @Param("couponStatus") int couponStatus,
                       @Param("lastTime") String lastTime, @Param("curTime") String curTime, @Param("limitCount") int limitCount);


    @Update("UPDATE coupon_extend_record SET coupon_status = #{couponStatus}, update_user_id = 'sys'  " +
            "WHERE valid_end_time < #{curTime} AND coupon_status = #{oldCouponStatus} LIMIT #{limitCount}")
    int updateStatusEx1(@Param("oldCouponStatus") int oldCouponStatus, @Param("couponStatus") int couponStatus,
                        @Param("curTime") String curTime, @Param("limitCount") int limitCount);

    /**
     * 更改优惠券状态为已使用
     * <p>判断当前状态，以及拥有人是否正确</p>
     *
     * @param couponExtendCode
     * @param couponStatus
     * @param orderBillCode
     * @param userUuid
     * @return
     */
    @Update("UPDATE coupon_extend_record " +
            "SET coupon_status = #{couponStatus}, order_bill_code = #{orderBillCode}, update_user_id = 'sys'  " +
            "WHERE coupon_extend_code = #{couponExtendCode} AND user_uuid = #{userUuid} " +
            "AND coupon_status = 1 AND delete_flag = 0")
    int use(@Param("couponExtendCode") String couponExtendCode, @Param("couponStatus") int couponStatus,
            @Param("orderBillCode") String orderBillCode, @Param("userUuid") String userUuid);

    @Select("SELECT Count(*) FROM coupon_extend_record WHERE coupon_extend_code = #{couponExtendCode}")
    int isExists(@Param("couponExtendCode") String couponExtendCode);

    @Select("SELECT Count(*) FROM coupon_extend_record ${condition}")
    int lstCountByCondition(WhereCondition condition);

    @Select("SELECT Count(*) FROM coupon_extend_record WHERE coupon_code = '${couponCode}' AND coupon_status in (${status})")
    int lstCountByStatus(@Param("couponCode") String couponCode, @Param("status") String status);

    @Select("SELECT Count(*) FROM coupon_extend_record ${condition}")
    int lstCountRecord(WhereCondition condition);

    @Select("SELECT Max(from_base64(coupon_extend_code)) FROM coupon_extend_record WHERE LENGTH(coupon_extend_code) = 12 AND from_base64(coupon_extend_code) LIKE #{IdMode}")
    String lstLastCouponExtendCodeNo(@Param("IdMode") String IdMode);

    List<CouponExtendRecord> lstByCondition(WhereCondition condition);

    CouponExtendRecord selectByPrimaryKey(String couponExtendCode);

    int updateByExampleSelective(@Param("record") CouponExtendRecord record, @Param("example") CouponExtendRecordExample example);

    int updateByExample(@Param("record") CouponExtendRecord record, @Param("example") CouponExtendRecordExample example);

    int updateByPrimaryKeySelective(CouponExtendRecord record);

    int updateByPrimaryKey(CouponExtendRecord record);

    List<Map> getExtendRecordList(Map map);

    Integer getExtendRecordCount(Map map);
}