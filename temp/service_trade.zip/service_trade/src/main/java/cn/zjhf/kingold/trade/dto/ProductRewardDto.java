package cn.zjhf.kingold.trade.dto;

/**
 * 产品奖励佣金设置
 *
 * Created by lutiehua on 2017/5/27.
 */
public class ProductRewardDto {

    /**
     * 最小金额
     *
     */
    private Integer minAmount;

    /**
     * 最大金额
     *
     */
    private Integer maxAmount;

    /**
     * 奖励比例
     *
     */
    private Double percent;

    public Integer getMinAmount() {
        return minAmount;
    }

    public void setMinAmount(Integer minAmount) {
        this.minAmount = minAmount;
    }

    public Integer getMaxAmount() {
        return maxAmount;
    }

    public void setMaxAmount(Integer maxAmount) {
        this.maxAmount = maxAmount;
    }

    public Double getPercent() {
        return percent;
    }

    public void setPercent(Double percent) {
        this.percent = percent;
    }

    @Override
    public String toString() {
        return "ProductRewardDto{" +
                "minAmount=" + minAmount +
                ", maxAmount=" + maxAmount +
                ", percent=" + percent +
                '}';
    }
}
