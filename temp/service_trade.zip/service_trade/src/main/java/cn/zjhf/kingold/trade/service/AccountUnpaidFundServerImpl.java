package cn.zjhf.kingold.trade.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.entity.AccountUnpaidFund;

/**
 * Created by DELL on 2017/5/16.
 */
public interface AccountUnpaidFundServerImpl {
    /**
     * 插入记录
     * @return
     * @throws BusinessException
     */
    public AccountUnpaidFund insert(String productUUId) throws BusinessException;

    /**
     * 更新记录
     * @return
     * @throws BusinessException
     */
    public int update(String productUUId) throws BusinessException;
}
