package cn.zjhf.kingold.trade.entity.InVO;

import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Size;

/**
 * Created by zhangyijie on 2017/10/13.
 */
public class LstTradeCommisionsByRequestIdConditionVO extends InVOBase {
    @ApiModelProperty(required = true, value = "请求结算单号")
    @NotEmpty
    @Size(min = 1, max = 30)
    private String requestId;

    @ApiModelProperty(required = true, value = "起始序号")
    private int beginSN;

    @ApiModelProperty(required = true, value = "结束序号")
    private int endSN;

    public int getBeginSN() {
        return beginSN;
    }

    public void setBeginSN(int beginSN) {
        this.beginSN = beginSN;
    }

    public int getEndSN() {
        return endSN;
    }

    public void setEndSN(int endSN) {
        this.endSN = endSN;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    @Override
    public String toString() {
        return "LstTradeCommisionsByMerchantNumConditionVO{" +
                "traceID=" + DataUtils.toString(getTraceID()) + ", " +
                ", requestId='" + requestId + '\'' +
                ", beginSN=" + beginSN +
                ", endSN=" + endSN +
                '}';
    }
}
