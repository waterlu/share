package cn.zjhf.kingold.trade.dto;

import cn.zjhf.kingold.common.param.ParamVO;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
 * 创建订单的参数
 *
 * @author lutiehua
 * @date 2018/3/9
 */
public class CreateOrderDTO extends ParamVO {

    /**
     * 认购产品UUID
     */
    @NotBlank
    private String productUuid;

    /**
     * 认购用户UUID
     */
    @NotBlank
    private String userUuid;

    /**
     * 认购金额
     */
    @NotNull
    private BigDecimal orderAmount;

    /**
     * 交易密码
     */
    @NotBlank
    private String userPayPassword;

    /**
     * 渠道编码
     */
    private String belongMerchantNum;

    /**
     * 现金券编码
     */
    private String couponExtendCode;

    /**
     * 客户端唯一标识
     */
    @NotBlank
    private String uniqueIdentifier;

    /**
     * 渠道结佣标识
     */
    private String channelCommissionFlag;

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public BigDecimal getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(BigDecimal orderAmount) {
        this.orderAmount = orderAmount;
    }

    public String getUserPayPassword() {
        return userPayPassword;
    }

    public void setUserPayPassword(String userPayPassword) {
        this.userPayPassword = userPayPassword;
    }

    public String getCouponExtendCode() {
        return couponExtendCode;
    }

    public void setCouponExtendCode(String couponExtendCode) {
        this.couponExtendCode = couponExtendCode;
    }

    public String getUniqueIdentifier() {
        return uniqueIdentifier;
    }

    public void setUniqueIdentifier(String uniqueIdentifier) {
        this.uniqueIdentifier = uniqueIdentifier;
    }

    public String getBelongMerchantNum() {
        return belongMerchantNum;
    }

    public void setBelongMerchantNum(String belongMerchantNum) {
        this.belongMerchantNum = belongMerchantNum;
    }

    public String getChannelCommissionFlag() {
        return channelCommissionFlag;
    }

    public void setChannelCommissionFlag(String channelCommissionFlag) {
        this.channelCommissionFlag = channelCommissionFlag;
    }
}
