package cn.zjhf.kingold.trade.baofoo;

/**
 * Created by lutiehua on 2017/5/3.
 */
public class OrderResponse {

    private String order_id;

    private int state;

    private double succ_amount;

    private String succ_time;

    private double fee;

    private double baofoo_fee;

    private int fee_taken_on;

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public double getFee() {
        return fee;
    }

    public void setFee(double fee) {
        this.fee = fee;
    }

    public double getBaofoo_fee() {
        return baofoo_fee;
    }

    public void setBaofoo_fee(double baofoo_fee) {
        this.baofoo_fee = baofoo_fee;
    }

    public int getFee_taken_on() {
        return fee_taken_on;
    }

    public void setFee_taken_on(int fee_taken_on) {
        this.fee_taken_on = fee_taken_on;
    }

    public double getSucc_amount() {
        return succ_amount;
    }

    public void setSucc_amount(double succ_amount) {
        this.succ_amount = succ_amount;
    }

    public String getSucc_time() {
        return succ_time;
    }

    public void setSucc_time(String succ_time) {
        this.succ_time = succ_time;
    }
}
