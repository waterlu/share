package cn.zjhf.kingold.trade.entity.InVO;

import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Size;

/**
 * Created by zhangyijie on 2017/8/23.
 */

@ApiModel(value = "CouponSpecifiedDistributionAuditVO", description = "现金券指定发放记录审核")
public class CouponSpecifiedDistributionAuditVO extends InVOBase {
//    @ApiModelProperty(required = true, value = "审核编号")
//    @NotEmpty
//    private Long auditId;

    @ApiModelProperty(required = true, value = "审核编号列表，以|间隔")
    @NotEmpty
    private String auditIdList;

    @ApiModelProperty(required = true, value = "审核人")
    @NotEmpty
    private String auditOperator;

    @ApiModelProperty(required = true, value = "是否审核通过，仅在审核时使用，1审核通过  0作废")
    private int isAudited;

    @ApiModelProperty(required = false, value = "审核意见，作废时需要填写")
    private String auditOpinion;

//    public Long getAuditId() {
//        return auditId;
//    }
//
//    public void setAuditId(Long auditId) {
//        this.auditId = auditId;
//    }

    public String getAuditIdList() {
        return auditIdList;
    }

    public void setAuditIdList(String auditIdList) {
        this.auditIdList = auditIdList;
    }

    public String getAuditOperator() {
        return auditOperator;
    }

    public void setAuditOperator(String auditOperator) {
        this.auditOperator = auditOperator;
    }

    public int getIsAudited() {
        return isAudited;
    }

    public void setIsAudited(int isAudited) {
        this.isAudited = isAudited;
    }

    public String getAuditOpinion() {
        return auditOpinion;
    }

    public void setAuditOpinion(String auditOpinion) {
        this.auditOpinion = auditOpinion;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(getTraceID()) + ", ");
//        sb.append("auditId:" + DataUtils.toString(auditId) + ", ");
        sb.append("auditIdList:" + DataUtils.toString(auditIdList) + ", ");
        sb.append("auditOperator:" + DataUtils.toString(auditOperator) + ", ");
        sb.append("isAudited:" + DataUtils.toString(isAudited) + ", ");
        sb.append("auditOpinion:" + DataUtils.toString(auditOpinion) + ", ");
        return sb.toString();
    }
}
