package cn.zjhf.kingold.trade.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.entity.OutVO.ProductProfitVO;
import cn.zjhf.kingold.trade.entity.OutVO.ProductRaiseProgressVO;

/**
 * Created by zhangyijie on 2017/5/19.
 */
public interface IProductManagerService {

    /**
     * 查询募集金额
     * @return
     * @throws BusinessException
     */
    public ProductRaiseProgressVO lstRaiseAmount(String product_uuid, String productType) throws BusinessException;

    /**
     * 更新募集金额
     * @param createBy 操作人
     * @return
     * @throws BusinessException
     */
    public boolean updateRaiseAmount(String product_uuid, String productType, String userPhone, Double amount, String createBy) throws BusinessException;

    /**
     * 取消交易
     * @param orderBillCode 订单号
     * @return
     * @throws BusinessException
     */
    public boolean cancelTrade(String orderBillCode, String userPhone, String cancelReason) throws BusinessException;

    /**
     * 计算收益
     * @param product_uuid 产品ID
     * @return
     * @throws BusinessException
     */
    public ProductProfitVO calculationProfit(String product_uuid) throws BusinessException;

    /**
     * 产品确认
     * @param product_uuid 产品ID
     * @param createBy 操作人
     * @return
     * @throws BusinessException
     */
    public void fixedProductConfirm(String product_uuid, String createBy) throws BusinessException;

    /**
     * 产品开始募集
     * @param product_uuid 产品ID
     * @param productType
     * @param createBy 操作人
     * @return
     * @throws BusinessException
     */
    public void productBeginRasie(String product_uuid, String productType, String createBy) throws BusinessException;

    /**
     * 周期性自动更新固收产品的状态
     * @throws BusinessException
     */
    public void autoUpdateFixedProductStatus() throws BusinessException;

    /**
     * 定时更新更新固收产品的状态
     * @throws BusinessException
     */
    public void fixedTimeUpdateFixedProductStatus() throws BusinessException;

    /**
     * 产品作废
     * @param product_uuid 产品ID
     * @param createBy 操作人
     * @return
     * @throws BusinessException
     */
    public void fixedProductAbort(String product_uuid, String createBy) throws BusinessException;

    /**
     * 产品提前到期
     * @param product_uuid 产品ID
     * @param createBy 操作人
     * @return
     * @throws BusinessException
     */
    public void advanceProductEnd(String product_uuid, String createBy) throws BusinessException;

    /**
     * 产品进入封闭期
     * @param product_uuid 产品ID
     * @param productType
     * @param createBy 操作人
     * @return
     * @throws BusinessException
     */
    public void productBeginClosedPeriod(String product_uuid, String productType, String createBy) throws BusinessException;

    /**
     * 产品进入存续期
     * @param product_uuid 产品ID
     * @param productType
     * @param createBy 操作人
     * @return
     * @throws BusinessException
     */
    public void productBeginDuration(String product_uuid, String productType, String createBy) throws BusinessException;

    /**
     * 产品结束募集
     * @param product_uuid 产品ID
     * @param productType
     * @param createBy 操作人
     * @return
     * @throws BusinessException
     */
    public void productEndRasie(String product_uuid, String productType, String createBy) throws BusinessException;

    /**
     * 产品上架
     * @param product_uuid 产品ID
     * @param productType
     * @param createBy 操作人
     * @return
     * @throws BusinessException
     */
    public void productShelvesOn(String product_uuid, String productType, String createBy) throws BusinessException;

    /**
     * 产品下架
     * @param product_uuid 产品ID
     * @param productType
     * @param createBy 操作人
     * @return
     * @throws BusinessException
     */
    public void productShelvesOff(String product_uuid, String productType, String createBy) throws BusinessException;

    /**
     * 设置产品费用
     * @param
     * @return
     * @throws BusinessException
     */
    public void setProductFeeRate(String product_uuid, double platformServiceFeeRate, double exchangeManagerFeeRate) throws BusinessException;
}
