package cn.zjhf.kingold.trade.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author 
 */
public class TradeOrderVO implements Serializable {
    /**
     * 产品订单编号
     */
    private String orderBillCode;
    /**
     * 订单编号扩展（宝付交易流水编号）
     */
    private String tradeOrderBillCodeExtend;
    /**
     * 用户UUID
     */
    private String userUuid;
    /**
     * 真实姓名
     */
    private String userName;
    /**
     * 手机号码
     */
    private String userPhone;
    /**
     * 用户类型
     */
    private Integer userType;
    /**
     * 用户身份证号
     */
    private String idCardNo;
    /**
     * 产品简称
     */
    private String productAbbrName;
    /**
     * 产品期限
     */
    private Integer productPeriod;
    /**
     * 产品期限类型： Y(year,年)； M(month,月)； W(week,周)； D(day,自然日)
     */
    private String productPeriodType;
    /**
     * 营销费用
     */
    private BigDecimal marketingAmount;
    /**
     * 适用策略列表，多个策略之间用英文","间隔
     */
    private String strategyIds;
    /**
     * 加息券加息率
     */
    private BigDecimal couponInterestYieldRate;
    /**
     * 产品预计年化收益率(冗余)
     */
    private BigDecimal productAnnualInterestRate;
    /**
     * 产品加息率
     */
    private BigDecimal productIncreaseInterestRate;
    /**
     * 订单金额，订单金额 = 实缴金额 + 营销费用；订单金额 = 产品份额 * 产品单价
     */
    private BigDecimal orderAmount;
    /**
     * 实缴金额
     */
    private BigDecimal paidAmount;
    /**
     * 预期收益
     */
    private BigDecimal expectedProfitAmount;
    /**
     * 创建时间
     */
    private String createTime;
    /**
     * 付款时间
     */
    private String payedTime;
    /**
     * 交易渠道：1,app(IOS); 2,app(安卓); 其他
     */
    private String transactionChannel;
    /**
     * 订单状态 1创建，2已付款，3产品成立，4已清算，5撤销
     */
    private Integer orderStatus;

    public String getOrderBillCode() {
        return orderBillCode;
    }

    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    public String getTradeOrderBillCodeExtend() {
        return tradeOrderBillCodeExtend;
    }

    public void setTradeOrderBillCodeExtend(String tradeOrderBillCodeExtend) {
        this.tradeOrderBillCodeExtend = tradeOrderBillCodeExtend;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    public String getIdCardNo() {
        return idCardNo;
    }

    public void setIdCardNo(String idCardNo) {
        this.idCardNo = idCardNo;
    }

    public String getProductAbbrName() {
        return productAbbrName;
    }

    public void setProductAbbrName(String productAbbrName) {
        this.productAbbrName = productAbbrName;
    }

    public Integer getProductPeriod() {
        return productPeriod;
    }

    public void setProductPeriod(Integer productPeriod) {
        this.productPeriod = productPeriod;
    }

    public String getProductPeriodType() {
        return productPeriodType;
    }

    public void setProductPeriodType(String productPeriodType) {
        this.productPeriodType = productPeriodType;
    }

    public BigDecimal getMarketingAmount() {
        return marketingAmount;
    }

    public void setMarketingAmount(BigDecimal marketingAmount) {
        this.marketingAmount = marketingAmount;
    }

    public String getStrategyIds() {
        return strategyIds;
    }

    public void setStrategyIds(String strategyIds) {
        this.strategyIds = strategyIds;
    }

    public BigDecimal getCouponInterestYieldRate() {
        return couponInterestYieldRate;
    }

    public void setCouponInterestYieldRate(BigDecimal couponInterestYieldRate) {
        this.couponInterestYieldRate = couponInterestYieldRate;
    }

    public BigDecimal getProductAnnualInterestRate() {
        return productAnnualInterestRate;
    }

    public void setProductAnnualInterestRate(BigDecimal productAnnualInterestRate) {
        this.productAnnualInterestRate = productAnnualInterestRate;
    }

    public BigDecimal getProductIncreaseInterestRate() {
        return productIncreaseInterestRate;
    }

    public void setProductIncreaseInterestRate(BigDecimal productIncreaseInterestRate) {
        this.productIncreaseInterestRate = productIncreaseInterestRate;
    }

    public BigDecimal getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(BigDecimal orderAmount) {
        this.orderAmount = orderAmount;
    }

    public BigDecimal getPaidAmount() {
        return paidAmount;
    }

    public void setPaidAmount(BigDecimal paidAmount) {
        this.paidAmount = paidAmount;
    }

    public BigDecimal getExpectedProfitAmount() {
        return expectedProfitAmount;
    }

    public void setExpectedProfitAmount(BigDecimal expectedProfitAmount) {
        this.expectedProfitAmount = expectedProfitAmount;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getPayedTime() {
        return payedTime;
    }

    public void setPayedTime(String payedTime) {
        this.payedTime = payedTime;
    }

    public String getTransactionChannel() {
        return transactionChannel;
    }

    public void setTransactionChannel(String transactionChannel) {
        this.transactionChannel = transactionChannel;
    }

    public Integer getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(Integer orderStatus) {
        this.orderStatus = orderStatus;
    }

    public Integer getUserType() {
        return userType;
    }

    public void setUserType(Integer userType) {
        this.userType = userType;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    @Override
    public String toString() {
        return "TradeOrderVO{" +
                "orderBillCode='" + orderBillCode + '\'' +
                ", tradeOrderBillCodeExtend='" + tradeOrderBillCodeExtend + '\'' +
                ", userUuid='" + userUuid + '\'' +
                ", userName='" + userName + '\'' +
                ", userPhone='" + userPhone + '\'' +
                ", userType=" + userType +
                ", idCardNo='" + idCardNo + '\'' +
                ", productAbbrName='" + productAbbrName + '\'' +
                ", productPeriod=" + productPeriod +
                ", productPeriodType='" + productPeriodType + '\'' +
                ", marketingAmount=" + marketingAmount +
                ", strategyIds='" + strategyIds + '\'' +
                ", couponInterestYieldRate=" + couponInterestYieldRate +
                ", productAnnualInterestRate=" + productAnnualInterestRate +
                ", productIncreaseInterestRate=" + productIncreaseInterestRate +
                ", orderAmount=" + orderAmount +
                ", paidAmount=" + paidAmount +
                ", expectedProfitAmount=" + expectedProfitAmount +
                ", createTime='" + createTime + '\'' +
                ", payedTime='" + payedTime + '\'' +
                ", transactionChannel='" + transactionChannel + '\'' +
                ", orderStatus=" + orderStatus +
                '}';
    }
}