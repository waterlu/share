package cn.zjhf.kingold.trade.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author 
 */
public class TradeBill implements Serializable {
    /**
     * 交易单据UUID
     */
    private String tradeBillUuid;

    /**
     * 交易单据编号
     */
    private String tradeBillCode;

    /**
     * 交易单据类型
     */
    private String tradeBillType;

    /**
     * 产品订单UUID
     */
    private String orderUuid;

    /**
     * 产品订单编号（冗余）
     */
    private String orderBillCode;

    /**
     * 付款方用户UUID
     */
    private String payerUserUuid;

    /**
     * 付款方账户UUID
     */
    private String payerAccountUuid;

    /**
     * 付款方账户类型
     */
    private String payerAccountType;

    /**
     * 收款方用户UUID
     */
    private String payeeUserUuid;

    /**
     * 收款方账户UUID
     */
    private String payeeAccountUuid;

    /**
     * 收款方账户类型
     */
    private String payeeAccountType;

    /**
     * 单据金额
     */
    private BigDecimal billAmount;

    /**
     * 单据状态
     */
    private Byte billStatus;

    /**
     * 备注（JSON）
     */
    private String billRemark;

    private Byte deleteFlag;

    private Date createTime;

    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public String getTradeBillUuid() {
        return tradeBillUuid;
    }

    public void setTradeBillUuid(String tradeBillUuid) {
        this.tradeBillUuid = tradeBillUuid;
    }

    public String getTradeBillCode() {
        return tradeBillCode;
    }

    public void setTradeBillCode(String tradeBillCode) {
        this.tradeBillCode = tradeBillCode;
    }

    public String getTradeBillType() {
        return tradeBillType;
    }

    public void setTradeBillType(String tradeBillType) {
        this.tradeBillType = tradeBillType;
    }

    public String getOrderUuid() {
        return orderUuid;
    }

    public void setOrderUuid(String orderUuid) {
        this.orderUuid = orderUuid;
    }

    public String getOrderBillCode() {
        return orderBillCode;
    }

    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    public String getPayerUserUuid() {
        return payerUserUuid;
    }

    public void setPayerUserUuid(String payerUserUuid) {
        this.payerUserUuid = payerUserUuid;
    }

    public String getPayerAccountUuid() {
        return payerAccountUuid;
    }

    public void setPayerAccountUuid(String payerAccountUuid) {
        this.payerAccountUuid = payerAccountUuid;
    }

    public String getPayerAccountType() {
        return payerAccountType;
    }

    public void setPayerAccountType(String payerAccountType) {
        this.payerAccountType = payerAccountType;
    }

    public String getPayeeUserUuid() {
        return payeeUserUuid;
    }

    public void setPayeeUserUuid(String payeeUserUuid) {
        this.payeeUserUuid = payeeUserUuid;
    }

    public String getPayeeAccountUuid() {
        return payeeAccountUuid;
    }

    public void setPayeeAccountUuid(String payeeAccountUuid) {
        this.payeeAccountUuid = payeeAccountUuid;
    }

    public String getPayeeAccountType() {
        return payeeAccountType;
    }

    public void setPayeeAccountType(String payeeAccountType) {
        this.payeeAccountType = payeeAccountType;
    }

    public BigDecimal getBillAmount() {
        return billAmount;
    }

    public void setBillAmount(BigDecimal billAmount) {
        this.billAmount = billAmount;
    }

    public Byte getBillStatus() {
        return billStatus;
    }

    public void setBillStatus(Byte billStatus) {
        this.billStatus = billStatus;
    }

    public String getBillRemark() {
        return billRemark;
    }

    public void setBillRemark(String billRemark) {
        this.billRemark = billRemark;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}