package cn.zjhf.kingold.trade.entity.OutVO;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.trade.entity.ChannelCommisionDetail;
import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.Date;

@ApiModel(value = "ChannelCommisionDetailVO", description = "渠道佣金明细记录")
public class ChannelCommisionDetailVO extends ParamVO {

    @ApiModelProperty(required = true, value = "channel_commision_detail_id 自增长的20位数字")
    @NotEmpty
    private Long channelCommisionDetailId;

    @ApiModelProperty(required = true, value = "UUID主键")
    @NotEmpty
    @Size(min = 1, max = 32)
    private String productUuid;

    @ApiModelProperty(required = true, value = "产品简称")
    @NotEmpty
    @Size(min = 1, max = 40)
    private String productAbbrName;

    @ApiModelProperty(required = false, value = "商户号，5位数字 （如：10001）")
    @Size(min = 1, max = 20)
    private String merchantNum;

    @ApiModelProperty(required = false, value = "APP名称/渠道名称")
    @Size(min = 1, max = 30)
    private String channelAppName;

    @ApiModelProperty(required = false, value = "成交笔数")
    private int orderCount;

    @ApiModelProperty(required = false, value = "有效成交笔数")
    private int validOrderCount;

    @ApiModelProperty(required = false, value = "有效成交不结算笔数")
    private int validOrderUnsettleCount;

    @ApiModelProperty(required = true, value = "募集金额")
    @NotEmpty
    private double raiseAmount;

    @ApiModelProperty(required = true, value = "有效募集金额")
    @NotEmpty
    private double validRaiseAmount;

    @ApiModelProperty(required = true, value = "有效成交不结算募集金额")
    @NotEmpty
    private double validRaiseUnsettleAmount;

    @ApiModelProperty(required = true, value = "佣金")
    @NotEmpty
    private double commisionAmount;

    @ApiModelProperty(required = false, value = "放款时间")
    private Date loanTime;

    @ApiModelProperty(required = true, value = "结算状态：1未结算，2结算请求中，3已结算")
    @NotEmpty
    private int settleStatus;

    @ApiModelProperty(required = true, value = "删除标记 0未删除，1已删除")
    @NotEmpty
    private int deleteFlag;

    @ApiModelProperty(required = true, value = "")
    @NotEmpty
    private Date createTime;

    @ApiModelProperty(required = true, value = "")
    @NotEmpty
    private Date updateTime;

    public ChannelCommisionDetailVO() {
    }

    public ChannelCommisionDetailVO(ChannelCommisionDetail channelCommisionDetail) {
        this.channelCommisionDetailId = channelCommisionDetail.getChannelCommisionDetailId();
        this.productUuid = channelCommisionDetail.getProductUuid();
        this.productAbbrName = channelCommisionDetail.getProductAbbrName();
        this.merchantNum = channelCommisionDetail.getMerchantNum();
        this.channelAppName = channelCommisionDetail.getChannelAppName();
        this.orderCount = channelCommisionDetail.getOrderCount();
        this.validOrderCount = channelCommisionDetail.getValidOrderCount();
        this.validOrderUnsettleCount = channelCommisionDetail.getValidOrderUnsettleCount();
        this.raiseAmount = channelCommisionDetail.getRaiseAmount().doubleValue();
        this.validRaiseAmount = channelCommisionDetail.getValidRaiseAmount().doubleValue();
        this.validRaiseUnsettleAmount = channelCommisionDetail.getValidRaiseUnsettleAmount().doubleValue();
        this.commisionAmount = channelCommisionDetail.getCommisionAmount().doubleValue();
        this.loanTime = channelCommisionDetail.getLoanTime();
        this.settleStatus = channelCommisionDetail.getSettleStatus();
        this.deleteFlag = channelCommisionDetail.getDeleteFlag();
        this.createTime = channelCommisionDetail.getCreateTime();
        this.updateTime = channelCommisionDetail.getUpdateTime();
    }

    public Long getChannelCommisionDetailId() {
        return channelCommisionDetailId;
    }

    public void setChannelCommisionDetailId(Long channelCommisionDetailId) {
        this.channelCommisionDetailId = channelCommisionDetailId;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductAbbrName() {
        return productAbbrName;
    }

    public void setProductAbbrName(String productAbbrName) {
        this.productAbbrName = productAbbrName;
    }

    public String getMerchantNum() {
        return merchantNum;
    }

    public void setMerchantNum(String merchantNum) {
        this.merchantNum = merchantNum;
    }

    public String getChannelAppName() {
        return channelAppName;
    }

    public void setChannelAppName(String channelAppName) {
        this.channelAppName = channelAppName;
    }

    public int getOrderCount() {
        return orderCount;
    }

    public void setOrderCount(int orderCount) {
        this.orderCount = orderCount;
    }

    public int getValidOrderCount() {
        return validOrderCount;
    }

    public void setValidOrderCount(int validOrderCount) {
        this.validOrderCount = validOrderCount;
    }

    public int getValidOrderUnsettleCount() {
        return validOrderUnsettleCount;
    }

    public void setValidOrderUnsettleCount(int validOrderUnsettleCount) {
        this.validOrderUnsettleCount = validOrderUnsettleCount;
    }

    public double getRaiseAmount() {
        return raiseAmount;
    }

    public void setRaiseAmount(double raiseAmount) {
        this.raiseAmount = raiseAmount;
    }

    public double getValidRaiseAmount() {
        return validRaiseAmount;
    }

    public void setValidRaiseAmount(double validRaiseAmount) {
        this.validRaiseAmount = validRaiseAmount;
    }

    public double getValidRaiseUnsettleAmount() {
        return validRaiseUnsettleAmount;
    }

    public void setValidRaiseUnsettleAmount(double validRaiseUnsettleAmount) {
        this.validRaiseUnsettleAmount = validRaiseUnsettleAmount;
    }

    public double getCommisionAmount() {
        return commisionAmount;
    }

    public void setCommisionAmount(double commisionAmount) {
        this.commisionAmount = commisionAmount;
    }

    public Date getLoanTime() {
        return loanTime;
    }

    public void setLoanTime(Date loanTime) {
        this.loanTime = loanTime;
    }

    public int getSettleStatus() {
        return settleStatus;
    }

    public void setSettleStatus(int settleStatus) {
        this.settleStatus = settleStatus;
    }

    public int getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(int deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public ChannelCommisionDetail get() {
        ChannelCommisionDetail channelCommisionDetail = new ChannelCommisionDetail();
        channelCommisionDetail.setChannelCommisionDetailId(channelCommisionDetailId);
        channelCommisionDetail.setProductUuid(productUuid);
        channelCommisionDetail.setProductAbbrName(productAbbrName);
        channelCommisionDetail.setMerchantNum(merchantNum);
        channelCommisionDetail.setChannelAppName(channelAppName);
        channelCommisionDetail.setOrderCount(orderCount);
        channelCommisionDetail.setValidOrderCount(validOrderCount);
        channelCommisionDetail.setValidOrderUnsettleCount(validOrderUnsettleCount);
        channelCommisionDetail.setRaiseAmount(new BigDecimal(raiseAmount));
        channelCommisionDetail.setValidRaiseAmount(new BigDecimal(validRaiseAmount));
        channelCommisionDetail.setValidRaiseUnsettleAmount(new BigDecimal(validRaiseUnsettleAmount));
        channelCommisionDetail.setCommisionAmount(new BigDecimal(commisionAmount));
        channelCommisionDetail.setLoanTime(loanTime);
        channelCommisionDetail.setSettleStatus(new Integer(settleStatus).byteValue());
        channelCommisionDetail.setDeleteFlag(new Integer(deleteFlag).byteValue());
        channelCommisionDetail.setCreateTime(createTime);
        channelCommisionDetail.setUpdateTime(updateTime);
        return channelCommisionDetail;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("channelCommisionDetailId:" + DataUtils.toString(channelCommisionDetailId) + ", ");
        sb.append("productUuid:" + DataUtils.toString(productUuid) + ", ");
        sb.append("productAbbrName:" + DataUtils.toString(productAbbrName) + ", ");
        sb.append("merchantNum:" + DataUtils.toString(merchantNum) + ", ");
        sb.append("channelAppName:" + DataUtils.toString(channelAppName) + ", ");
        sb.append("orderCount:" + DataUtils.toString(orderCount) + ", ");
        sb.append("validOrderCount:" + DataUtils.toString(validOrderCount) + ", ");
        sb.append("validOrderUnsettleCount:" + DataUtils.toString(validOrderUnsettleCount) + ", ");
        sb.append("raiseAmount:" + DataUtils.toString(raiseAmount) + ", ");
        sb.append("validRaiseAmount:" + DataUtils.toString(validRaiseAmount) + ", ");
        sb.append("validRaiseUnsettleAmount:" + DataUtils.toString(validRaiseUnsettleAmount) + ", ");
        sb.append("commisionAmount:" + DataUtils.toString(commisionAmount) + ", ");
        sb.append("loanTime:" + DataUtils.toString(loanTime) + ", ");
        sb.append("settleStatus:" + DataUtils.toString(settleStatus) + ", ");
        sb.append("deleteFlag:" + DataUtils.toString(deleteFlag) + ", ");
        sb.append("createTime:" + DataUtils.toString(createTime) + ", ");
        sb.append("updateTime:" + DataUtils.toString(updateTime));
        return sb.toString();
    }
}
