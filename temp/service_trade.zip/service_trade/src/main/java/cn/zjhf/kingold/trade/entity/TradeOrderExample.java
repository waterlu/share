package cn.zjhf.kingold.trade.entity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TradeOrderExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private Integer limit;

    private Integer offset;

    public TradeOrderExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andOrderBillCodeIsNull() {
            addCriterion("order_bill_code is null");
            return (Criteria) this;
        }

        public Criteria andOrderBillCodeIsNotNull() {
            addCriterion("order_bill_code is not null");
            return (Criteria) this;
        }

        public Criteria andOrderBillCodeEqualTo(String value) {
            addCriterion("order_bill_code =", value, "orderBillCode");
            return (Criteria) this;
        }

        public Criteria andOrderBillCodeNotEqualTo(String value) {
            addCriterion("order_bill_code <>", value, "orderBillCode");
            return (Criteria) this;
        }

        public Criteria andOrderBillCodeGreaterThan(String value) {
            addCriterion("order_bill_code >", value, "orderBillCode");
            return (Criteria) this;
        }

        public Criteria andOrderBillCodeGreaterThanOrEqualTo(String value) {
            addCriterion("order_bill_code >=", value, "orderBillCode");
            return (Criteria) this;
        }

        public Criteria andOrderBillCodeLessThan(String value) {
            addCriterion("order_bill_code <", value, "orderBillCode");
            return (Criteria) this;
        }

        public Criteria andOrderBillCodeLessThanOrEqualTo(String value) {
            addCriterion("order_bill_code <=", value, "orderBillCode");
            return (Criteria) this;
        }

        public Criteria andOrderBillCodeLike(String value) {
            addCriterion("order_bill_code like", value, "orderBillCode");
            return (Criteria) this;
        }

        public Criteria andOrderBillCodeNotLike(String value) {
            addCriterion("order_bill_code not like", value, "orderBillCode");
            return (Criteria) this;
        }

        public Criteria andOrderBillCodeIn(List<String> values) {
            addCriterion("order_bill_code in", values, "orderBillCode");
            return (Criteria) this;
        }

        public Criteria andOrderBillCodeNotIn(List<String> values) {
            addCriterion("order_bill_code not in", values, "orderBillCode");
            return (Criteria) this;
        }

        public Criteria andOrderBillCodeBetween(String value1, String value2) {
            addCriterion("order_bill_code between", value1, value2, "orderBillCode");
            return (Criteria) this;
        }

        public Criteria andOrderBillCodeNotBetween(String value1, String value2) {
            addCriterion("order_bill_code not between", value1, value2, "orderBillCode");
            return (Criteria) this;
        }

        public Criteria andUserUuidIsNull() {
            addCriterion("user_uuid is null");
            return (Criteria) this;
        }

        public Criteria andUserUuidIsNotNull() {
            addCriterion("user_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andUserUuidEqualTo(String value) {
            addCriterion("user_uuid =", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidNotEqualTo(String value) {
            addCriterion("user_uuid <>", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidGreaterThan(String value) {
            addCriterion("user_uuid >", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidGreaterThanOrEqualTo(String value) {
            addCriterion("user_uuid >=", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidLessThan(String value) {
            addCriterion("user_uuid <", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidLessThanOrEqualTo(String value) {
            addCriterion("user_uuid <=", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidLike(String value) {
            addCriterion("user_uuid like", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidNotLike(String value) {
            addCriterion("user_uuid not like", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidIn(List<String> values) {
            addCriterion("user_uuid in", values, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidNotIn(List<String> values) {
            addCriterion("user_uuid not in", values, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidBetween(String value1, String value2) {
            addCriterion("user_uuid between", value1, value2, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidNotBetween(String value1, String value2) {
            addCriterion("user_uuid not between", value1, value2, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserTypeIsNull() {
            addCriterion("user_type is null");
            return (Criteria) this;
        }

        public Criteria andUserTypeIsNotNull() {
            addCriterion("user_type is not null");
            return (Criteria) this;
        }

        public Criteria andUserTypeEqualTo(Short value) {
            addCriterion("user_type =", value, "userType");
            return (Criteria) this;
        }

        public Criteria andUserTypeNotEqualTo(Short value) {
            addCriterion("user_type <>", value, "userType");
            return (Criteria) this;
        }

        public Criteria andUserTypeGreaterThan(Short value) {
            addCriterion("user_type >", value, "userType");
            return (Criteria) this;
        }

        public Criteria andUserTypeGreaterThanOrEqualTo(Short value) {
            addCriterion("user_type >=", value, "userType");
            return (Criteria) this;
        }

        public Criteria andUserTypeLessThan(Short value) {
            addCriterion("user_type <", value, "userType");
            return (Criteria) this;
        }

        public Criteria andUserTypeLessThanOrEqualTo(Short value) {
            addCriterion("user_type <=", value, "userType");
            return (Criteria) this;
        }

        public Criteria andUserTypeIn(List<Short> values) {
            addCriterion("user_type in", values, "userType");
            return (Criteria) this;
        }

        public Criteria andUserTypeNotIn(List<Short> values) {
            addCriterion("user_type not in", values, "userType");
            return (Criteria) this;
        }

        public Criteria andUserTypeBetween(Short value1, Short value2) {
            addCriterion("user_type between", value1, value2, "userType");
            return (Criteria) this;
        }

        public Criteria andUserTypeNotBetween(Short value1, Short value2) {
            addCriterion("user_type not between", value1, value2, "userType");
            return (Criteria) this;
        }

        public Criteria andInvestorOrganizationUuidIsNull() {
            addCriterion("investor_organization_uuid is null");
            return (Criteria) this;
        }

        public Criteria andInvestorOrganizationUuidIsNotNull() {
            addCriterion("investor_organization_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andInvestorOrganizationUuidEqualTo(String value) {
            addCriterion("investor_organization_uuid =", value, "investorOrganizationUuid");
            return (Criteria) this;
        }

        public Criteria andInvestorOrganizationUuidNotEqualTo(String value) {
            addCriterion("investor_organization_uuid <>", value, "investorOrganizationUuid");
            return (Criteria) this;
        }

        public Criteria andInvestorOrganizationUuidGreaterThan(String value) {
            addCriterion("investor_organization_uuid >", value, "investorOrganizationUuid");
            return (Criteria) this;
        }

        public Criteria andInvestorOrganizationUuidGreaterThanOrEqualTo(String value) {
            addCriterion("investor_organization_uuid >=", value, "investorOrganizationUuid");
            return (Criteria) this;
        }

        public Criteria andInvestorOrganizationUuidLessThan(String value) {
            addCriterion("investor_organization_uuid <", value, "investorOrganizationUuid");
            return (Criteria) this;
        }

        public Criteria andInvestorOrganizationUuidLessThanOrEqualTo(String value) {
            addCriterion("investor_organization_uuid <=", value, "investorOrganizationUuid");
            return (Criteria) this;
        }

        public Criteria andInvestorOrganizationUuidLike(String value) {
            addCriterion("investor_organization_uuid like", value, "investorOrganizationUuid");
            return (Criteria) this;
        }

        public Criteria andInvestorOrganizationUuidNotLike(String value) {
            addCriterion("investor_organization_uuid not like", value, "investorOrganizationUuid");
            return (Criteria) this;
        }

        public Criteria andInvestorOrganizationUuidIn(List<String> values) {
            addCriterion("investor_organization_uuid in", values, "investorOrganizationUuid");
            return (Criteria) this;
        }

        public Criteria andInvestorOrganizationUuidNotIn(List<String> values) {
            addCriterion("investor_organization_uuid not in", values, "investorOrganizationUuid");
            return (Criteria) this;
        }

        public Criteria andInvestorOrganizationUuidBetween(String value1, String value2) {
            addCriterion("investor_organization_uuid between", value1, value2, "investorOrganizationUuid");
            return (Criteria) this;
        }

        public Criteria andInvestorOrganizationUuidNotBetween(String value1, String value2) {
            addCriterion("investor_organization_uuid not between", value1, value2, "investorOrganizationUuid");
            return (Criteria) this;
        }

        public Criteria andUserNameIsNull() {
            addCriterion("user_name is null");
            return (Criteria) this;
        }

        public Criteria andUserNameIsNotNull() {
            addCriterion("user_name is not null");
            return (Criteria) this;
        }

        public Criteria andUserNameEqualTo(String value) {
            addCriterion("user_name =", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameNotEqualTo(String value) {
            addCriterion("user_name <>", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameGreaterThan(String value) {
            addCriterion("user_name >", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameGreaterThanOrEqualTo(String value) {
            addCriterion("user_name >=", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameLessThan(String value) {
            addCriterion("user_name <", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameLessThanOrEqualTo(String value) {
            addCriterion("user_name <=", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameLike(String value) {
            addCriterion("user_name like", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameNotLike(String value) {
            addCriterion("user_name not like", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameIn(List<String> values) {
            addCriterion("user_name in", values, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameNotIn(List<String> values) {
            addCriterion("user_name not in", values, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameBetween(String value1, String value2) {
            addCriterion("user_name between", value1, value2, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameNotBetween(String value1, String value2) {
            addCriterion("user_name not between", value1, value2, "userName");
            return (Criteria) this;
        }

        public Criteria andUserPhoneIsNull() {
            addCriterion("user_phone is null");
            return (Criteria) this;
        }

        public Criteria andUserPhoneIsNotNull() {
            addCriterion("user_phone is not null");
            return (Criteria) this;
        }

        public Criteria andUserPhoneEqualTo(String value) {
            addCriterion("user_phone =", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNotEqualTo(String value) {
            addCriterion("user_phone <>", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneGreaterThan(String value) {
            addCriterion("user_phone >", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneGreaterThanOrEqualTo(String value) {
            addCriterion("user_phone >=", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneLessThan(String value) {
            addCriterion("user_phone <", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneLessThanOrEqualTo(String value) {
            addCriterion("user_phone <=", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneLike(String value) {
            addCriterion("user_phone like", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNotLike(String value) {
            addCriterion("user_phone not like", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneIn(List<String> values) {
            addCriterion("user_phone in", values, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNotIn(List<String> values) {
            addCriterion("user_phone not in", values, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneBetween(String value1, String value2) {
            addCriterion("user_phone between", value1, value2, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNotBetween(String value1, String value2) {
            addCriterion("user_phone not between", value1, value2, "userPhone");
            return (Criteria) this;
        }

        public Criteria andAccountUuidIsNull() {
            addCriterion("account_uuid is null");
            return (Criteria) this;
        }

        public Criteria andAccountUuidIsNotNull() {
            addCriterion("account_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andAccountUuidEqualTo(String value) {
            addCriterion("account_uuid =", value, "accountUuid");
            return (Criteria) this;
        }

        public Criteria andAccountUuidNotEqualTo(String value) {
            addCriterion("account_uuid <>", value, "accountUuid");
            return (Criteria) this;
        }

        public Criteria andAccountUuidGreaterThan(String value) {
            addCriterion("account_uuid >", value, "accountUuid");
            return (Criteria) this;
        }

        public Criteria andAccountUuidGreaterThanOrEqualTo(String value) {
            addCriterion("account_uuid >=", value, "accountUuid");
            return (Criteria) this;
        }

        public Criteria andAccountUuidLessThan(String value) {
            addCriterion("account_uuid <", value, "accountUuid");
            return (Criteria) this;
        }

        public Criteria andAccountUuidLessThanOrEqualTo(String value) {
            addCriterion("account_uuid <=", value, "accountUuid");
            return (Criteria) this;
        }

        public Criteria andAccountUuidLike(String value) {
            addCriterion("account_uuid like", value, "accountUuid");
            return (Criteria) this;
        }

        public Criteria andAccountUuidNotLike(String value) {
            addCriterion("account_uuid not like", value, "accountUuid");
            return (Criteria) this;
        }

        public Criteria andAccountUuidIn(List<String> values) {
            addCriterion("account_uuid in", values, "accountUuid");
            return (Criteria) this;
        }

        public Criteria andAccountUuidNotIn(List<String> values) {
            addCriterion("account_uuid not in", values, "accountUuid");
            return (Criteria) this;
        }

        public Criteria andAccountUuidBetween(String value1, String value2) {
            addCriterion("account_uuid between", value1, value2, "accountUuid");
            return (Criteria) this;
        }

        public Criteria andAccountUuidNotBetween(String value1, String value2) {
            addCriterion("account_uuid not between", value1, value2, "accountUuid");
            return (Criteria) this;
        }

        public Criteria andAccountNoIsNull() {
            addCriterion("account_no is null");
            return (Criteria) this;
        }

        public Criteria andAccountNoIsNotNull() {
            addCriterion("account_no is not null");
            return (Criteria) this;
        }

        public Criteria andAccountNoEqualTo(String value) {
            addCriterion("account_no =", value, "accountNo");
            return (Criteria) this;
        }

        public Criteria andAccountNoNotEqualTo(String value) {
            addCriterion("account_no <>", value, "accountNo");
            return (Criteria) this;
        }

        public Criteria andAccountNoGreaterThan(String value) {
            addCriterion("account_no >", value, "accountNo");
            return (Criteria) this;
        }

        public Criteria andAccountNoGreaterThanOrEqualTo(String value) {
            addCriterion("account_no >=", value, "accountNo");
            return (Criteria) this;
        }

        public Criteria andAccountNoLessThan(String value) {
            addCriterion("account_no <", value, "accountNo");
            return (Criteria) this;
        }

        public Criteria andAccountNoLessThanOrEqualTo(String value) {
            addCriterion("account_no <=", value, "accountNo");
            return (Criteria) this;
        }

        public Criteria andAccountNoLike(String value) {
            addCriterion("account_no like", value, "accountNo");
            return (Criteria) this;
        }

        public Criteria andAccountNoNotLike(String value) {
            addCriterion("account_no not like", value, "accountNo");
            return (Criteria) this;
        }

        public Criteria andAccountNoIn(List<String> values) {
            addCriterion("account_no in", values, "accountNo");
            return (Criteria) this;
        }

        public Criteria andAccountNoNotIn(List<String> values) {
            addCriterion("account_no not in", values, "accountNo");
            return (Criteria) this;
        }

        public Criteria andAccountNoBetween(String value1, String value2) {
            addCriterion("account_no between", value1, value2, "accountNo");
            return (Criteria) this;
        }

        public Criteria andAccountNoNotBetween(String value1, String value2) {
            addCriterion("account_no not between", value1, value2, "accountNo");
            return (Criteria) this;
        }

        public Criteria andTransactionChannelIsNull() {
            addCriterion("transaction_channel is null");
            return (Criteria) this;
        }

        public Criteria andTransactionChannelIsNotNull() {
            addCriterion("transaction_channel is not null");
            return (Criteria) this;
        }

        public Criteria andTransactionChannelEqualTo(String value) {
            addCriterion("transaction_channel =", value, "transactionChannel");
            return (Criteria) this;
        }

        public Criteria andTransactionChannelNotEqualTo(String value) {
            addCriterion("transaction_channel <>", value, "transactionChannel");
            return (Criteria) this;
        }

        public Criteria andTransactionChannelGreaterThan(String value) {
            addCriterion("transaction_channel >", value, "transactionChannel");
            return (Criteria) this;
        }

        public Criteria andTransactionChannelGreaterThanOrEqualTo(String value) {
            addCriterion("transaction_channel >=", value, "transactionChannel");
            return (Criteria) this;
        }

        public Criteria andTransactionChannelLessThan(String value) {
            addCriterion("transaction_channel <", value, "transactionChannel");
            return (Criteria) this;
        }

        public Criteria andTransactionChannelLessThanOrEqualTo(String value) {
            addCriterion("transaction_channel <=", value, "transactionChannel");
            return (Criteria) this;
        }

        public Criteria andTransactionChannelLike(String value) {
            addCriterion("transaction_channel like", value, "transactionChannel");
            return (Criteria) this;
        }

        public Criteria andTransactionChannelNotLike(String value) {
            addCriterion("transaction_channel not like", value, "transactionChannel");
            return (Criteria) this;
        }

        public Criteria andTransactionChannelIn(List<String> values) {
            addCriterion("transaction_channel in", values, "transactionChannel");
            return (Criteria) this;
        }

        public Criteria andTransactionChannelNotIn(List<String> values) {
            addCriterion("transaction_channel not in", values, "transactionChannel");
            return (Criteria) this;
        }

        public Criteria andTransactionChannelBetween(String value1, String value2) {
            addCriterion("transaction_channel between", value1, value2, "transactionChannel");
            return (Criteria) this;
        }

        public Criteria andTransactionChannelNotBetween(String value1, String value2) {
            addCriterion("transaction_channel not between", value1, value2, "transactionChannel");
            return (Criteria) this;
        }

        public Criteria andTransactionTimeIsNull() {
            addCriterion("transaction_time is null");
            return (Criteria) this;
        }

        public Criteria andTransactionTimeIsNotNull() {
            addCriterion("transaction_time is not null");
            return (Criteria) this;
        }

        public Criteria andTransactionTimeEqualTo(Date value) {
            addCriterion("transaction_time =", value, "transactionTime");
            return (Criteria) this;
        }

        public Criteria andTransactionTimeNotEqualTo(Date value) {
            addCriterion("transaction_time <>", value, "transactionTime");
            return (Criteria) this;
        }

        public Criteria andTransactionTimeGreaterThan(Date value) {
            addCriterion("transaction_time >", value, "transactionTime");
            return (Criteria) this;
        }

        public Criteria andTransactionTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("transaction_time >=", value, "transactionTime");
            return (Criteria) this;
        }

        public Criteria andTransactionTimeLessThan(Date value) {
            addCriterion("transaction_time <", value, "transactionTime");
            return (Criteria) this;
        }

        public Criteria andTransactionTimeLessThanOrEqualTo(Date value) {
            addCriterion("transaction_time <=", value, "transactionTime");
            return (Criteria) this;
        }

        public Criteria andTransactionTimeIn(List<Date> values) {
            addCriterion("transaction_time in", values, "transactionTime");
            return (Criteria) this;
        }

        public Criteria andTransactionTimeNotIn(List<Date> values) {
            addCriterion("transaction_time not in", values, "transactionTime");
            return (Criteria) this;
        }

        public Criteria andTransactionTimeBetween(Date value1, Date value2) {
            addCriterion("transaction_time between", value1, value2, "transactionTime");
            return (Criteria) this;
        }

        public Criteria andTransactionTimeNotBetween(Date value1, Date value2) {
            addCriterion("transaction_time not between", value1, value2, "transactionTime");
            return (Criteria) this;
        }

        public Criteria andProductUuidIsNull() {
            addCriterion("product_uuid is null");
            return (Criteria) this;
        }

        public Criteria andProductUuidIsNotNull() {
            addCriterion("product_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andProductUuidEqualTo(String value) {
            addCriterion("product_uuid =", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotEqualTo(String value) {
            addCriterion("product_uuid <>", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidGreaterThan(String value) {
            addCriterion("product_uuid >", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidGreaterThanOrEqualTo(String value) {
            addCriterion("product_uuid >=", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidLessThan(String value) {
            addCriterion("product_uuid <", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidLessThanOrEqualTo(String value) {
            addCriterion("product_uuid <=", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidLike(String value) {
            addCriterion("product_uuid like", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotLike(String value) {
            addCriterion("product_uuid not like", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidIn(List<String> values) {
            addCriterion("product_uuid in", values, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotIn(List<String> values) {
            addCriterion("product_uuid not in", values, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidBetween(String value1, String value2) {
            addCriterion("product_uuid between", value1, value2, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotBetween(String value1, String value2) {
            addCriterion("product_uuid not between", value1, value2, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductCodeIsNull() {
            addCriterion("product_code is null");
            return (Criteria) this;
        }

        public Criteria andProductCodeIsNotNull() {
            addCriterion("product_code is not null");
            return (Criteria) this;
        }

        public Criteria andProductCodeEqualTo(String value) {
            addCriterion("product_code =", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotEqualTo(String value) {
            addCriterion("product_code <>", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeGreaterThan(String value) {
            addCriterion("product_code >", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeGreaterThanOrEqualTo(String value) {
            addCriterion("product_code >=", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLessThan(String value) {
            addCriterion("product_code <", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLessThanOrEqualTo(String value) {
            addCriterion("product_code <=", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLike(String value) {
            addCriterion("product_code like", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotLike(String value) {
            addCriterion("product_code not like", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeIn(List<String> values) {
            addCriterion("product_code in", values, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotIn(List<String> values) {
            addCriterion("product_code not in", values, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeBetween(String value1, String value2) {
            addCriterion("product_code between", value1, value2, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotBetween(String value1, String value2) {
            addCriterion("product_code not between", value1, value2, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameIsNull() {
            addCriterion("product_abbr_name is null");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameIsNotNull() {
            addCriterion("product_abbr_name is not null");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameEqualTo(String value) {
            addCriterion("product_abbr_name =", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameNotEqualTo(String value) {
            addCriterion("product_abbr_name <>", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameGreaterThan(String value) {
            addCriterion("product_abbr_name >", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameGreaterThanOrEqualTo(String value) {
            addCriterion("product_abbr_name >=", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameLessThan(String value) {
            addCriterion("product_abbr_name <", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameLessThanOrEqualTo(String value) {
            addCriterion("product_abbr_name <=", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameLike(String value) {
            addCriterion("product_abbr_name like", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameNotLike(String value) {
            addCriterion("product_abbr_name not like", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameIn(List<String> values) {
            addCriterion("product_abbr_name in", values, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameNotIn(List<String> values) {
            addCriterion("product_abbr_name not in", values, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameBetween(String value1, String value2) {
            addCriterion("product_abbr_name between", value1, value2, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameNotBetween(String value1, String value2) {
            addCriterion("product_abbr_name not between", value1, value2, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAnnualInterestRateIsNull() {
            addCriterion("product_annual_interest_rate is null");
            return (Criteria) this;
        }

        public Criteria andProductAnnualInterestRateIsNotNull() {
            addCriterion("product_annual_interest_rate is not null");
            return (Criteria) this;
        }

        public Criteria andProductAnnualInterestRateEqualTo(BigDecimal value) {
            addCriterion("product_annual_interest_rate =", value, "productAnnualInterestRate");
            return (Criteria) this;
        }

        public Criteria andProductAnnualInterestRateNotEqualTo(BigDecimal value) {
            addCriterion("product_annual_interest_rate <>", value, "productAnnualInterestRate");
            return (Criteria) this;
        }

        public Criteria andProductAnnualInterestRateGreaterThan(BigDecimal value) {
            addCriterion("product_annual_interest_rate >", value, "productAnnualInterestRate");
            return (Criteria) this;
        }

        public Criteria andProductAnnualInterestRateGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("product_annual_interest_rate >=", value, "productAnnualInterestRate");
            return (Criteria) this;
        }

        public Criteria andProductAnnualInterestRateLessThan(BigDecimal value) {
            addCriterion("product_annual_interest_rate <", value, "productAnnualInterestRate");
            return (Criteria) this;
        }

        public Criteria andProductAnnualInterestRateLessThanOrEqualTo(BigDecimal value) {
            addCriterion("product_annual_interest_rate <=", value, "productAnnualInterestRate");
            return (Criteria) this;
        }

        public Criteria andProductAnnualInterestRateIn(List<BigDecimal> values) {
            addCriterion("product_annual_interest_rate in", values, "productAnnualInterestRate");
            return (Criteria) this;
        }

        public Criteria andProductAnnualInterestRateNotIn(List<BigDecimal> values) {
            addCriterion("product_annual_interest_rate not in", values, "productAnnualInterestRate");
            return (Criteria) this;
        }

        public Criteria andProductAnnualInterestRateBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("product_annual_interest_rate between", value1, value2, "productAnnualInterestRate");
            return (Criteria) this;
        }

        public Criteria andProductAnnualInterestRateNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("product_annual_interest_rate not between", value1, value2, "productAnnualInterestRate");
            return (Criteria) this;
        }

        public Criteria andProductInterestDateIsNull() {
            addCriterion("product_interest_date is null");
            return (Criteria) this;
        }

        public Criteria andProductInterestDateIsNotNull() {
            addCriterion("product_interest_date is not null");
            return (Criteria) this;
        }

        public Criteria andProductInterestDateEqualTo(Integer value) {
            addCriterion("product_interest_date =", value, "productInterestDate");
            return (Criteria) this;
        }

        public Criteria andProductInterestDateNotEqualTo(Integer value) {
            addCriterion("product_interest_date <>", value, "productInterestDate");
            return (Criteria) this;
        }

        public Criteria andProductInterestDateGreaterThan(Integer value) {
            addCriterion("product_interest_date >", value, "productInterestDate");
            return (Criteria) this;
        }

        public Criteria andProductInterestDateGreaterThanOrEqualTo(Integer value) {
            addCriterion("product_interest_date >=", value, "productInterestDate");
            return (Criteria) this;
        }

        public Criteria andProductInterestDateLessThan(Integer value) {
            addCriterion("product_interest_date <", value, "productInterestDate");
            return (Criteria) this;
        }

        public Criteria andProductInterestDateLessThanOrEqualTo(Integer value) {
            addCriterion("product_interest_date <=", value, "productInterestDate");
            return (Criteria) this;
        }

        public Criteria andProductInterestDateIn(List<Integer> values) {
            addCriterion("product_interest_date in", values, "productInterestDate");
            return (Criteria) this;
        }

        public Criteria andProductInterestDateNotIn(List<Integer> values) {
            addCriterion("product_interest_date not in", values, "productInterestDate");
            return (Criteria) this;
        }

        public Criteria andProductInterestDateBetween(Integer value1, Integer value2) {
            addCriterion("product_interest_date between", value1, value2, "productInterestDate");
            return (Criteria) this;
        }

        public Criteria andProductInterestDateNotBetween(Integer value1, Integer value2) {
            addCriterion("product_interest_date not between", value1, value2, "productInterestDate");
            return (Criteria) this;
        }

        public Criteria andProductExpiringDateIsNull() {
            addCriterion("product_expiring_date is null");
            return (Criteria) this;
        }

        public Criteria andProductExpiringDateIsNotNull() {
            addCriterion("product_expiring_date is not null");
            return (Criteria) this;
        }

        public Criteria andProductExpiringDateEqualTo(Integer value) {
            addCriterion("product_expiring_date =", value, "productExpiringDate");
            return (Criteria) this;
        }

        public Criteria andProductExpiringDateNotEqualTo(Integer value) {
            addCriterion("product_expiring_date <>", value, "productExpiringDate");
            return (Criteria) this;
        }

        public Criteria andProductExpiringDateGreaterThan(Integer value) {
            addCriterion("product_expiring_date >", value, "productExpiringDate");
            return (Criteria) this;
        }

        public Criteria andProductExpiringDateGreaterThanOrEqualTo(Integer value) {
            addCriterion("product_expiring_date >=", value, "productExpiringDate");
            return (Criteria) this;
        }

        public Criteria andProductExpiringDateLessThan(Integer value) {
            addCriterion("product_expiring_date <", value, "productExpiringDate");
            return (Criteria) this;
        }

        public Criteria andProductExpiringDateLessThanOrEqualTo(Integer value) {
            addCriterion("product_expiring_date <=", value, "productExpiringDate");
            return (Criteria) this;
        }

        public Criteria andProductExpiringDateIn(List<Integer> values) {
            addCriterion("product_expiring_date in", values, "productExpiringDate");
            return (Criteria) this;
        }

        public Criteria andProductExpiringDateNotIn(List<Integer> values) {
            addCriterion("product_expiring_date not in", values, "productExpiringDate");
            return (Criteria) this;
        }

        public Criteria andProductExpiringDateBetween(Integer value1, Integer value2) {
            addCriterion("product_expiring_date between", value1, value2, "productExpiringDate");
            return (Criteria) this;
        }

        public Criteria andProductExpiringDateNotBetween(Integer value1, Integer value2) {
            addCriterion("product_expiring_date not between", value1, value2, "productExpiringDate");
            return (Criteria) this;
        }

        public Criteria andProductPaymentDateIsNull() {
            addCriterion("product_payment_date is null");
            return (Criteria) this;
        }

        public Criteria andProductPaymentDateIsNotNull() {
            addCriterion("product_payment_date is not null");
            return (Criteria) this;
        }

        public Criteria andProductPaymentDateEqualTo(Integer value) {
            addCriterion("product_payment_date =", value, "productPaymentDate");
            return (Criteria) this;
        }

        public Criteria andProductPaymentDateNotEqualTo(Integer value) {
            addCriterion("product_payment_date <>", value, "productPaymentDate");
            return (Criteria) this;
        }

        public Criteria andProductPaymentDateGreaterThan(Integer value) {
            addCriterion("product_payment_date >", value, "productPaymentDate");
            return (Criteria) this;
        }

        public Criteria andProductPaymentDateGreaterThanOrEqualTo(Integer value) {
            addCriterion("product_payment_date >=", value, "productPaymentDate");
            return (Criteria) this;
        }

        public Criteria andProductPaymentDateLessThan(Integer value) {
            addCriterion("product_payment_date <", value, "productPaymentDate");
            return (Criteria) this;
        }

        public Criteria andProductPaymentDateLessThanOrEqualTo(Integer value) {
            addCriterion("product_payment_date <=", value, "productPaymentDate");
            return (Criteria) this;
        }

        public Criteria andProductPaymentDateIn(List<Integer> values) {
            addCriterion("product_payment_date in", values, "productPaymentDate");
            return (Criteria) this;
        }

        public Criteria andProductPaymentDateNotIn(List<Integer> values) {
            addCriterion("product_payment_date not in", values, "productPaymentDate");
            return (Criteria) this;
        }

        public Criteria andProductPaymentDateBetween(Integer value1, Integer value2) {
            addCriterion("product_payment_date between", value1, value2, "productPaymentDate");
            return (Criteria) this;
        }

        public Criteria andProductPaymentDateNotBetween(Integer value1, Integer value2) {
            addCriterion("product_payment_date not between", value1, value2, "productPaymentDate");
            return (Criteria) this;
        }

        public Criteria andOrderAmountIsNull() {
            addCriterion("order_amount is null");
            return (Criteria) this;
        }

        public Criteria andOrderAmountIsNotNull() {
            addCriterion("order_amount is not null");
            return (Criteria) this;
        }

        public Criteria andOrderAmountEqualTo(BigDecimal value) {
            addCriterion("order_amount =", value, "orderAmount");
            return (Criteria) this;
        }

        public Criteria andOrderAmountNotEqualTo(BigDecimal value) {
            addCriterion("order_amount <>", value, "orderAmount");
            return (Criteria) this;
        }

        public Criteria andOrderAmountGreaterThan(BigDecimal value) {
            addCriterion("order_amount >", value, "orderAmount");
            return (Criteria) this;
        }

        public Criteria andOrderAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("order_amount >=", value, "orderAmount");
            return (Criteria) this;
        }

        public Criteria andOrderAmountLessThan(BigDecimal value) {
            addCriterion("order_amount <", value, "orderAmount");
            return (Criteria) this;
        }

        public Criteria andOrderAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("order_amount <=", value, "orderAmount");
            return (Criteria) this;
        }

        public Criteria andOrderAmountIn(List<BigDecimal> values) {
            addCriterion("order_amount in", values, "orderAmount");
            return (Criteria) this;
        }

        public Criteria andOrderAmountNotIn(List<BigDecimal> values) {
            addCriterion("order_amount not in", values, "orderAmount");
            return (Criteria) this;
        }

        public Criteria andOrderAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("order_amount between", value1, value2, "orderAmount");
            return (Criteria) this;
        }

        public Criteria andOrderAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("order_amount not between", value1, value2, "orderAmount");
            return (Criteria) this;
        }

        public Criteria andExpectedProfitAmountIsNull() {
            addCriterion("expected_profit_amount is null");
            return (Criteria) this;
        }

        public Criteria andExpectedProfitAmountIsNotNull() {
            addCriterion("expected_profit_amount is not null");
            return (Criteria) this;
        }

        public Criteria andExpectedProfitAmountEqualTo(BigDecimal value) {
            addCriterion("expected_profit_amount =", value, "expectedProfitAmount");
            return (Criteria) this;
        }

        public Criteria andExpectedProfitAmountNotEqualTo(BigDecimal value) {
            addCriterion("expected_profit_amount <>", value, "expectedProfitAmount");
            return (Criteria) this;
        }

        public Criteria andExpectedProfitAmountGreaterThan(BigDecimal value) {
            addCriterion("expected_profit_amount >", value, "expectedProfitAmount");
            return (Criteria) this;
        }

        public Criteria andExpectedProfitAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("expected_profit_amount >=", value, "expectedProfitAmount");
            return (Criteria) this;
        }

        public Criteria andExpectedProfitAmountLessThan(BigDecimal value) {
            addCriterion("expected_profit_amount <", value, "expectedProfitAmount");
            return (Criteria) this;
        }

        public Criteria andExpectedProfitAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("expected_profit_amount <=", value, "expectedProfitAmount");
            return (Criteria) this;
        }

        public Criteria andExpectedProfitAmountIn(List<BigDecimal> values) {
            addCriterion("expected_profit_amount in", values, "expectedProfitAmount");
            return (Criteria) this;
        }

        public Criteria andExpectedProfitAmountNotIn(List<BigDecimal> values) {
            addCriterion("expected_profit_amount not in", values, "expectedProfitAmount");
            return (Criteria) this;
        }

        public Criteria andExpectedProfitAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("expected_profit_amount between", value1, value2, "expectedProfitAmount");
            return (Criteria) this;
        }

        public Criteria andExpectedProfitAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("expected_profit_amount not between", value1, value2, "expectedProfitAmount");
            return (Criteria) this;
        }

        public Criteria andPaidAmountIsNull() {
            addCriterion("paid_amount is null");
            return (Criteria) this;
        }

        public Criteria andPaidAmountIsNotNull() {
            addCriterion("paid_amount is not null");
            return (Criteria) this;
        }

        public Criteria andPaidAmountEqualTo(BigDecimal value) {
            addCriterion("paid_amount =", value, "paidAmount");
            return (Criteria) this;
        }

        public Criteria andPaidAmountNotEqualTo(BigDecimal value) {
            addCriterion("paid_amount <>", value, "paidAmount");
            return (Criteria) this;
        }

        public Criteria andPaidAmountGreaterThan(BigDecimal value) {
            addCriterion("paid_amount >", value, "paidAmount");
            return (Criteria) this;
        }

        public Criteria andPaidAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("paid_amount >=", value, "paidAmount");
            return (Criteria) this;
        }

        public Criteria andPaidAmountLessThan(BigDecimal value) {
            addCriterion("paid_amount <", value, "paidAmount");
            return (Criteria) this;
        }

        public Criteria andPaidAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("paid_amount <=", value, "paidAmount");
            return (Criteria) this;
        }

        public Criteria andPaidAmountIn(List<BigDecimal> values) {
            addCriterion("paid_amount in", values, "paidAmount");
            return (Criteria) this;
        }

        public Criteria andPaidAmountNotIn(List<BigDecimal> values) {
            addCriterion("paid_amount not in", values, "paidAmount");
            return (Criteria) this;
        }

        public Criteria andPaidAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("paid_amount between", value1, value2, "paidAmount");
            return (Criteria) this;
        }

        public Criteria andPaidAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("paid_amount not between", value1, value2, "paidAmount");
            return (Criteria) this;
        }

        public Criteria andMarketingAmountIsNull() {
            addCriterion("marketing_amount is null");
            return (Criteria) this;
        }

        public Criteria andMarketingAmountIsNotNull() {
            addCriterion("marketing_amount is not null");
            return (Criteria) this;
        }

        public Criteria andMarketingAmountEqualTo(BigDecimal value) {
            addCriterion("marketing_amount =", value, "marketingAmount");
            return (Criteria) this;
        }

        public Criteria andMarketingAmountNotEqualTo(BigDecimal value) {
            addCriterion("marketing_amount <>", value, "marketingAmount");
            return (Criteria) this;
        }

        public Criteria andMarketingAmountGreaterThan(BigDecimal value) {
            addCriterion("marketing_amount >", value, "marketingAmount");
            return (Criteria) this;
        }

        public Criteria andMarketingAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("marketing_amount >=", value, "marketingAmount");
            return (Criteria) this;
        }

        public Criteria andMarketingAmountLessThan(BigDecimal value) {
            addCriterion("marketing_amount <", value, "marketingAmount");
            return (Criteria) this;
        }

        public Criteria andMarketingAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("marketing_amount <=", value, "marketingAmount");
            return (Criteria) this;
        }

        public Criteria andMarketingAmountIn(List<BigDecimal> values) {
            addCriterion("marketing_amount in", values, "marketingAmount");
            return (Criteria) this;
        }

        public Criteria andMarketingAmountNotIn(List<BigDecimal> values) {
            addCriterion("marketing_amount not in", values, "marketingAmount");
            return (Criteria) this;
        }

        public Criteria andMarketingAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("marketing_amount between", value1, value2, "marketingAmount");
            return (Criteria) this;
        }

        public Criteria andMarketingAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("marketing_amount not between", value1, value2, "marketingAmount");
            return (Criteria) this;
        }

        public Criteria andProductPriceIsNull() {
            addCriterion("product_price is null");
            return (Criteria) this;
        }

        public Criteria andProductPriceIsNotNull() {
            addCriterion("product_price is not null");
            return (Criteria) this;
        }

        public Criteria andProductPriceEqualTo(BigDecimal value) {
            addCriterion("product_price =", value, "productPrice");
            return (Criteria) this;
        }

        public Criteria andProductPriceNotEqualTo(BigDecimal value) {
            addCriterion("product_price <>", value, "productPrice");
            return (Criteria) this;
        }

        public Criteria andProductPriceGreaterThan(BigDecimal value) {
            addCriterion("product_price >", value, "productPrice");
            return (Criteria) this;
        }

        public Criteria andProductPriceGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("product_price >=", value, "productPrice");
            return (Criteria) this;
        }

        public Criteria andProductPriceLessThan(BigDecimal value) {
            addCriterion("product_price <", value, "productPrice");
            return (Criteria) this;
        }

        public Criteria andProductPriceLessThanOrEqualTo(BigDecimal value) {
            addCriterion("product_price <=", value, "productPrice");
            return (Criteria) this;
        }

        public Criteria andProductPriceIn(List<BigDecimal> values) {
            addCriterion("product_price in", values, "productPrice");
            return (Criteria) this;
        }

        public Criteria andProductPriceNotIn(List<BigDecimal> values) {
            addCriterion("product_price not in", values, "productPrice");
            return (Criteria) this;
        }

        public Criteria andProductPriceBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("product_price between", value1, value2, "productPrice");
            return (Criteria) this;
        }

        public Criteria andProductPriceNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("product_price not between", value1, value2, "productPrice");
            return (Criteria) this;
        }

        public Criteria andOrderShareIsNull() {
            addCriterion("order_share is null");
            return (Criteria) this;
        }

        public Criteria andOrderShareIsNotNull() {
            addCriterion("order_share is not null");
            return (Criteria) this;
        }

        public Criteria andOrderShareEqualTo(BigDecimal value) {
            addCriterion("order_share =", value, "orderShare");
            return (Criteria) this;
        }

        public Criteria andOrderShareNotEqualTo(BigDecimal value) {
            addCriterion("order_share <>", value, "orderShare");
            return (Criteria) this;
        }

        public Criteria andOrderShareGreaterThan(BigDecimal value) {
            addCriterion("order_share >", value, "orderShare");
            return (Criteria) this;
        }

        public Criteria andOrderShareGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("order_share >=", value, "orderShare");
            return (Criteria) this;
        }

        public Criteria andOrderShareLessThan(BigDecimal value) {
            addCriterion("order_share <", value, "orderShare");
            return (Criteria) this;
        }

        public Criteria andOrderShareLessThanOrEqualTo(BigDecimal value) {
            addCriterion("order_share <=", value, "orderShare");
            return (Criteria) this;
        }

        public Criteria andOrderShareIn(List<BigDecimal> values) {
            addCriterion("order_share in", values, "orderShare");
            return (Criteria) this;
        }

        public Criteria andOrderShareNotIn(List<BigDecimal> values) {
            addCriterion("order_share not in", values, "orderShare");
            return (Criteria) this;
        }

        public Criteria andOrderShareBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("order_share between", value1, value2, "orderShare");
            return (Criteria) this;
        }

        public Criteria andOrderShareNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("order_share not between", value1, value2, "orderShare");
            return (Criteria) this;
        }

        public Criteria andProfitAmountIsNull() {
            addCriterion("profit_amount is null");
            return (Criteria) this;
        }

        public Criteria andProfitAmountIsNotNull() {
            addCriterion("profit_amount is not null");
            return (Criteria) this;
        }

        public Criteria andProfitAmountEqualTo(BigDecimal value) {
            addCriterion("profit_amount =", value, "profitAmount");
            return (Criteria) this;
        }

        public Criteria andProfitAmountNotEqualTo(BigDecimal value) {
            addCriterion("profit_amount <>", value, "profitAmount");
            return (Criteria) this;
        }

        public Criteria andProfitAmountGreaterThan(BigDecimal value) {
            addCriterion("profit_amount >", value, "profitAmount");
            return (Criteria) this;
        }

        public Criteria andProfitAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("profit_amount >=", value, "profitAmount");
            return (Criteria) this;
        }

        public Criteria andProfitAmountLessThan(BigDecimal value) {
            addCriterion("profit_amount <", value, "profitAmount");
            return (Criteria) this;
        }

        public Criteria andProfitAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("profit_amount <=", value, "profitAmount");
            return (Criteria) this;
        }

        public Criteria andProfitAmountIn(List<BigDecimal> values) {
            addCriterion("profit_amount in", values, "profitAmount");
            return (Criteria) this;
        }

        public Criteria andProfitAmountNotIn(List<BigDecimal> values) {
            addCriterion("profit_amount not in", values, "profitAmount");
            return (Criteria) this;
        }

        public Criteria andProfitAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("profit_amount between", value1, value2, "profitAmount");
            return (Criteria) this;
        }

        public Criteria andProfitAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("profit_amount not between", value1, value2, "profitAmount");
            return (Criteria) this;
        }

        public Criteria andCashAmountIsNull() {
            addCriterion("cash_amount is null");
            return (Criteria) this;
        }

        public Criteria andCashAmountIsNotNull() {
            addCriterion("cash_amount is not null");
            return (Criteria) this;
        }

        public Criteria andCashAmountEqualTo(BigDecimal value) {
            addCriterion("cash_amount =", value, "cashAmount");
            return (Criteria) this;
        }

        public Criteria andCashAmountNotEqualTo(BigDecimal value) {
            addCriterion("cash_amount <>", value, "cashAmount");
            return (Criteria) this;
        }

        public Criteria andCashAmountGreaterThan(BigDecimal value) {
            addCriterion("cash_amount >", value, "cashAmount");
            return (Criteria) this;
        }

        public Criteria andCashAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("cash_amount >=", value, "cashAmount");
            return (Criteria) this;
        }

        public Criteria andCashAmountLessThan(BigDecimal value) {
            addCriterion("cash_amount <", value, "cashAmount");
            return (Criteria) this;
        }

        public Criteria andCashAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("cash_amount <=", value, "cashAmount");
            return (Criteria) this;
        }

        public Criteria andCashAmountIn(List<BigDecimal> values) {
            addCriterion("cash_amount in", values, "cashAmount");
            return (Criteria) this;
        }

        public Criteria andCashAmountNotIn(List<BigDecimal> values) {
            addCriterion("cash_amount not in", values, "cashAmount");
            return (Criteria) this;
        }

        public Criteria andCashAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("cash_amount between", value1, value2, "cashAmount");
            return (Criteria) this;
        }

        public Criteria andCashAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("cash_amount not between", value1, value2, "cashAmount");
            return (Criteria) this;
        }

        public Criteria andOrderStatusIsNull() {
            addCriterion("order_status is null");
            return (Criteria) this;
        }

        public Criteria andOrderStatusIsNotNull() {
            addCriterion("order_status is not null");
            return (Criteria) this;
        }

        public Criteria andOrderStatusEqualTo(Byte value) {
            addCriterion("order_status =", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusNotEqualTo(Byte value) {
            addCriterion("order_status <>", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusGreaterThan(Byte value) {
            addCriterion("order_status >", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusGreaterThanOrEqualTo(Byte value) {
            addCriterion("order_status >=", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusLessThan(Byte value) {
            addCriterion("order_status <", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusLessThanOrEqualTo(Byte value) {
            addCriterion("order_status <=", value, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusIn(List<Byte> values) {
            addCriterion("order_status in", values, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusNotIn(List<Byte> values) {
            addCriterion("order_status not in", values, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusBetween(Byte value1, Byte value2) {
            addCriterion("order_status between", value1, value2, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andOrderStatusNotBetween(Byte value1, Byte value2) {
            addCriterion("order_status not between", value1, value2, "orderStatus");
            return (Criteria) this;
        }

        public Criteria andPayedTimeIsNull() {
            addCriterion("payed_time is null");
            return (Criteria) this;
        }

        public Criteria andPayedTimeIsNotNull() {
            addCriterion("payed_time is not null");
            return (Criteria) this;
        }

        public Criteria andPayedTimeEqualTo(Date value) {
            addCriterion("payed_time =", value, "payedTime");
            return (Criteria) this;
        }

        public Criteria andPayedTimeNotEqualTo(Date value) {
            addCriterion("payed_time <>", value, "payedTime");
            return (Criteria) this;
        }

        public Criteria andPayedTimeGreaterThan(Date value) {
            addCriterion("payed_time >", value, "payedTime");
            return (Criteria) this;
        }

        public Criteria andPayedTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("payed_time >=", value, "payedTime");
            return (Criteria) this;
        }

        public Criteria andPayedTimeLessThan(Date value) {
            addCriterion("payed_time <", value, "payedTime");
            return (Criteria) this;
        }

        public Criteria andPayedTimeLessThanOrEqualTo(Date value) {
            addCriterion("payed_time <=", value, "payedTime");
            return (Criteria) this;
        }

        public Criteria andPayedTimeIn(List<Date> values) {
            addCriterion("payed_time in", values, "payedTime");
            return (Criteria) this;
        }

        public Criteria andPayedTimeNotIn(List<Date> values) {
            addCriterion("payed_time not in", values, "payedTime");
            return (Criteria) this;
        }

        public Criteria andPayedTimeBetween(Date value1, Date value2) {
            addCriterion("payed_time between", value1, value2, "payedTime");
            return (Criteria) this;
        }

        public Criteria andPayedTimeNotBetween(Date value1, Date value2) {
            addCriterion("payed_time not between", value1, value2, "payedTime");
            return (Criteria) this;
        }

        public Criteria andMarketingPaidTimeIsNull() {
            addCriterion("marketing_paid_time is null");
            return (Criteria) this;
        }

        public Criteria andMarketingPaidTimeIsNotNull() {
            addCriterion("marketing_paid_time is not null");
            return (Criteria) this;
        }

        public Criteria andMarketingPaidTimeEqualTo(Date value) {
            addCriterion("marketing_paid_time =", value, "marketingPaidTime");
            return (Criteria) this;
        }

        public Criteria andMarketingPaidTimeNotEqualTo(Date value) {
            addCriterion("marketing_paid_time <>", value, "marketingPaidTime");
            return (Criteria) this;
        }

        public Criteria andMarketingPaidTimeGreaterThan(Date value) {
            addCriterion("marketing_paid_time >", value, "marketingPaidTime");
            return (Criteria) this;
        }

        public Criteria andMarketingPaidTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("marketing_paid_time >=", value, "marketingPaidTime");
            return (Criteria) this;
        }

        public Criteria andMarketingPaidTimeLessThan(Date value) {
            addCriterion("marketing_paid_time <", value, "marketingPaidTime");
            return (Criteria) this;
        }

        public Criteria andMarketingPaidTimeLessThanOrEqualTo(Date value) {
            addCriterion("marketing_paid_time <=", value, "marketingPaidTime");
            return (Criteria) this;
        }

        public Criteria andMarketingPaidTimeIn(List<Date> values) {
            addCriterion("marketing_paid_time in", values, "marketingPaidTime");
            return (Criteria) this;
        }

        public Criteria andMarketingPaidTimeNotIn(List<Date> values) {
            addCriterion("marketing_paid_time not in", values, "marketingPaidTime");
            return (Criteria) this;
        }

        public Criteria andMarketingPaidTimeBetween(Date value1, Date value2) {
            addCriterion("marketing_paid_time between", value1, value2, "marketingPaidTime");
            return (Criteria) this;
        }

        public Criteria andMarketingPaidTimeNotBetween(Date value1, Date value2) {
            addCriterion("marketing_paid_time not between", value1, value2, "marketingPaidTime");
            return (Criteria) this;
        }

        public Criteria andClearTimeIsNull() {
            addCriterion("clear_time is null");
            return (Criteria) this;
        }

        public Criteria andClearTimeIsNotNull() {
            addCriterion("clear_time is not null");
            return (Criteria) this;
        }

        public Criteria andClearTimeEqualTo(Date value) {
            addCriterion("clear_time =", value, "clearTime");
            return (Criteria) this;
        }

        public Criteria andClearTimeNotEqualTo(Date value) {
            addCriterion("clear_time <>", value, "clearTime");
            return (Criteria) this;
        }

        public Criteria andClearTimeGreaterThan(Date value) {
            addCriterion("clear_time >", value, "clearTime");
            return (Criteria) this;
        }

        public Criteria andClearTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("clear_time >=", value, "clearTime");
            return (Criteria) this;
        }

        public Criteria andClearTimeLessThan(Date value) {
            addCriterion("clear_time <", value, "clearTime");
            return (Criteria) this;
        }

        public Criteria andClearTimeLessThanOrEqualTo(Date value) {
            addCriterion("clear_time <=", value, "clearTime");
            return (Criteria) this;
        }

        public Criteria andClearTimeIn(List<Date> values) {
            addCriterion("clear_time in", values, "clearTime");
            return (Criteria) this;
        }

        public Criteria andClearTimeNotIn(List<Date> values) {
            addCriterion("clear_time not in", values, "clearTime");
            return (Criteria) this;
        }

        public Criteria andClearTimeBetween(Date value1, Date value2) {
            addCriterion("clear_time between", value1, value2, "clearTime");
            return (Criteria) this;
        }

        public Criteria andClearTimeNotBetween(Date value1, Date value2) {
            addCriterion("clear_time not between", value1, value2, "clearTime");
            return (Criteria) this;
        }

        public Criteria andCancelReasonIsNull() {
            addCriterion("cancel_reason is null");
            return (Criteria) this;
        }

        public Criteria andCancelReasonIsNotNull() {
            addCriterion("cancel_reason is not null");
            return (Criteria) this;
        }

        public Criteria andCancelReasonEqualTo(Byte value) {
            addCriterion("cancel_reason =", value, "cancelReason");
            return (Criteria) this;
        }

        public Criteria andCancelReasonNotEqualTo(Byte value) {
            addCriterion("cancel_reason <>", value, "cancelReason");
            return (Criteria) this;
        }

        public Criteria andCancelReasonGreaterThan(Byte value) {
            addCriterion("cancel_reason >", value, "cancelReason");
            return (Criteria) this;
        }

        public Criteria andCancelReasonGreaterThanOrEqualTo(Byte value) {
            addCriterion("cancel_reason >=", value, "cancelReason");
            return (Criteria) this;
        }

        public Criteria andCancelReasonLessThan(Byte value) {
            addCriterion("cancel_reason <", value, "cancelReason");
            return (Criteria) this;
        }

        public Criteria andCancelReasonLessThanOrEqualTo(Byte value) {
            addCriterion("cancel_reason <=", value, "cancelReason");
            return (Criteria) this;
        }

        public Criteria andCancelReasonIn(List<Byte> values) {
            addCriterion("cancel_reason in", values, "cancelReason");
            return (Criteria) this;
        }

        public Criteria andCancelReasonNotIn(List<Byte> values) {
            addCriterion("cancel_reason not in", values, "cancelReason");
            return (Criteria) this;
        }

        public Criteria andCancelReasonBetween(Byte value1, Byte value2) {
            addCriterion("cancel_reason between", value1, value2, "cancelReason");
            return (Criteria) this;
        }

        public Criteria andCancelReasonNotBetween(Byte value1, Byte value2) {
            addCriterion("cancel_reason not between", value1, value2, "cancelReason");
            return (Criteria) this;
        }

        public Criteria andCancelTimeIsNull() {
            addCriterion("cancel_time is null");
            return (Criteria) this;
        }

        public Criteria andCancelTimeIsNotNull() {
            addCriterion("cancel_time is not null");
            return (Criteria) this;
        }

        public Criteria andCancelTimeEqualTo(Date value) {
            addCriterion("cancel_time =", value, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeNotEqualTo(Date value) {
            addCriterion("cancel_time <>", value, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeGreaterThan(Date value) {
            addCriterion("cancel_time >", value, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("cancel_time >=", value, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeLessThan(Date value) {
            addCriterion("cancel_time <", value, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeLessThanOrEqualTo(Date value) {
            addCriterion("cancel_time <=", value, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeIn(List<Date> values) {
            addCriterion("cancel_time in", values, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeNotIn(List<Date> values) {
            addCriterion("cancel_time not in", values, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeBetween(Date value1, Date value2) {
            addCriterion("cancel_time between", value1, value2, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeNotBetween(Date value1, Date value2) {
            addCriterion("cancel_time not between", value1, value2, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andStrategyIdsIsNull() {
            addCriterion("strategy_ids is null");
            return (Criteria) this;
        }

        public Criteria andStrategyIdsIsNotNull() {
            addCriterion("strategy_ids is not null");
            return (Criteria) this;
        }

        public Criteria andStrategyIdsEqualTo(String value) {
            addCriterion("strategy_ids =", value, "strategyIds");
            return (Criteria) this;
        }

        public Criteria andStrategyIdsNotEqualTo(String value) {
            addCriterion("strategy_ids <>", value, "strategyIds");
            return (Criteria) this;
        }

        public Criteria andStrategyIdsGreaterThan(String value) {
            addCriterion("strategy_ids >", value, "strategyIds");
            return (Criteria) this;
        }

        public Criteria andStrategyIdsGreaterThanOrEqualTo(String value) {
            addCriterion("strategy_ids >=", value, "strategyIds");
            return (Criteria) this;
        }

        public Criteria andStrategyIdsLessThan(String value) {
            addCriterion("strategy_ids <", value, "strategyIds");
            return (Criteria) this;
        }

        public Criteria andStrategyIdsLessThanOrEqualTo(String value) {
            addCriterion("strategy_ids <=", value, "strategyIds");
            return (Criteria) this;
        }

        public Criteria andStrategyIdsLike(String value) {
            addCriterion("strategy_ids like", value, "strategyIds");
            return (Criteria) this;
        }

        public Criteria andStrategyIdsNotLike(String value) {
            addCriterion("strategy_ids not like", value, "strategyIds");
            return (Criteria) this;
        }

        public Criteria andStrategyIdsIn(List<String> values) {
            addCriterion("strategy_ids in", values, "strategyIds");
            return (Criteria) this;
        }

        public Criteria andStrategyIdsNotIn(List<String> values) {
            addCriterion("strategy_ids not in", values, "strategyIds");
            return (Criteria) this;
        }

        public Criteria andStrategyIdsBetween(String value1, String value2) {
            addCriterion("strategy_ids between", value1, value2, "strategyIds");
            return (Criteria) this;
        }

        public Criteria andStrategyIdsNotBetween(String value1, String value2) {
            addCriterion("strategy_ids not between", value1, value2, "strategyIds");
            return (Criteria) this;
        }

        public Criteria andSignatureIsNull() {
            addCriterion("signature is null");
            return (Criteria) this;
        }

        public Criteria andSignatureIsNotNull() {
            addCriterion("signature is not null");
            return (Criteria) this;
        }

        public Criteria andSignatureEqualTo(String value) {
            addCriterion("signature =", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureNotEqualTo(String value) {
            addCriterion("signature <>", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureGreaterThan(String value) {
            addCriterion("signature >", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureGreaterThanOrEqualTo(String value) {
            addCriterion("signature >=", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureLessThan(String value) {
            addCriterion("signature <", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureLessThanOrEqualTo(String value) {
            addCriterion("signature <=", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureLike(String value) {
            addCriterion("signature like", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureNotLike(String value) {
            addCriterion("signature not like", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureIn(List<String> values) {
            addCriterion("signature in", values, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureNotIn(List<String> values) {
            addCriterion("signature not in", values, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureBetween(String value1, String value2) {
            addCriterion("signature between", value1, value2, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureNotBetween(String value1, String value2) {
            addCriterion("signature not between", value1, value2, "signature");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNull() {
            addCriterion("delete_flag is null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNotNull() {
            addCriterion("delete_flag is not null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagEqualTo(Byte value) {
            addCriterion("delete_flag =", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotEqualTo(Byte value) {
            addCriterion("delete_flag <>", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThan(Byte value) {
            addCriterion("delete_flag >", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThanOrEqualTo(Byte value) {
            addCriterion("delete_flag >=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThan(Byte value) {
            addCriterion("delete_flag <", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThanOrEqualTo(Byte value) {
            addCriterion("delete_flag <=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIn(List<Byte> values) {
            addCriterion("delete_flag in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotIn(List<Byte> values) {
            addCriterion("delete_flag not in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagBetween(Byte value1, Byte value2) {
            addCriterion("delete_flag between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotBetween(Byte value1, Byte value2) {
            addCriterion("delete_flag not between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("update_time is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("update_time is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("update_time =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("update_time <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("update_time >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("update_time >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("update_time <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("update_time <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("update_time in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("update_time not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("update_time between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("update_time not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andMarketingRateAmountIsNull() {
            addCriterion("marketing_rate_amount is null");
            return (Criteria) this;
        }

        public Criteria andMarketingRateAmountIsNotNull() {
            addCriterion("marketing_rate_amount is not null");
            return (Criteria) this;
        }

        public Criteria andMarketingRateAmountEqualTo(BigDecimal value) {
            addCriterion("marketing_rate_amount =", value, "marketingRateAmount");
            return (Criteria) this;
        }

        public Criteria andMarketingRateAmountNotEqualTo(BigDecimal value) {
            addCriterion("marketing_rate_amount <>", value, "marketingRateAmount");
            return (Criteria) this;
        }

        public Criteria andMarketingRateAmountGreaterThan(BigDecimal value) {
            addCriterion("marketing_rate_amount >", value, "marketingRateAmount");
            return (Criteria) this;
        }

        public Criteria andMarketingRateAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("marketing_rate_amount >=", value, "marketingRateAmount");
            return (Criteria) this;
        }

        public Criteria andMarketingRateAmountLessThan(BigDecimal value) {
            addCriterion("marketing_rate_amount <", value, "marketingRateAmount");
            return (Criteria) this;
        }

        public Criteria andMarketingRateAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("marketing_rate_amount <=", value, "marketingRateAmount");
            return (Criteria) this;
        }

        public Criteria andMarketingRateAmountIn(List<BigDecimal> values) {
            addCriterion("marketing_rate_amount in", values, "marketingRateAmount");
            return (Criteria) this;
        }

        public Criteria andMarketingRateAmountNotIn(List<BigDecimal> values) {
            addCriterion("marketing_rate_amount not in", values, "marketingRateAmount");
            return (Criteria) this;
        }

        public Criteria andMarketingRateAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("marketing_rate_amount between", value1, value2, "marketingRateAmount");
            return (Criteria) this;
        }

        public Criteria andMarketingRateAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("marketing_rate_amount not between", value1, value2, "marketingRateAmount");
            return (Criteria) this;
        }
    }

    /**
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}