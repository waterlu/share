package cn.zjhf.kingold.trade.entity.InVO;

import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModelProperty;

import java.util.Date;

/**
 * Created by zhangyijie on 2017/7/5.
 */
public class LstCouponSpecifiedDistributionConditionVO extends InVOBase {

    @ApiModelProperty(required = true, value = "审核编号")
    private Long auditId;

    @ApiModelProperty(required = true, value = "批次号")
    private String ccCode;

    @ApiModelProperty(required = true, value = "处理状态(0全部，-1审核作废, 1待审核, 2审核通过)")
    private int auditStatus;

    @ApiModelProperty(required = true, value = "创建时间_起始")
    private Date beginDate;

    @ApiModelProperty(required = true, value = "创建时间_结束")
    private Date endDate;

    @ApiModelProperty(required = true, value = "起始序号")
    private int beginSN;

    @ApiModelProperty(required = true, value = "结束序号")
    private int endSN;

    public String getCcCode() {
        return ccCode;
    }

    public void setCcCode(String ccCode) {
        this.ccCode = ccCode;
    }

    public int getBeginSN() {
        return beginSN;
    }

    public void setBeginSN(int beginSN) {
        this.beginSN = beginSN;
    }

    public int getEndSN() {
        return endSN;
    }

    public void setEndSN(int endSN) {
        this.endSN = endSN;
    }

    public Date getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(Date beginDate) {
        this.beginDate = beginDate;
    }

    public Date getEndDate() {
        return convertEndDate(endDate);
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(getTraceID()) + ", ");
        sb.append("auditId:" + DataUtils.toString(auditId) + ", ");
        sb.append("ccCode:" + DataUtils.toString(ccCode) + ", ");
        sb.append("auditStatus:" + DataUtils.toString(auditStatus) + ", ");

        sb.append("beginDate:" + DataUtils.toString(beginDate) + ", ");
        sb.append("endDate:" + DataUtils.toString(endDate) + ", ");
        sb.append("beginSN:" + DataUtils.toString(beginSN) + ", ");
        sb.append("endSN:" + DataUtils.toString(endSN));
        return sb.toString();
    }

    public Long getAuditId() {
        if(auditId != null) {
            return auditId;
        }else {
            return 0L;
        }
    }

    public void setAuditId(Long auditId) {
        this.auditId = auditId;
    }

    public int getAuditStatus() {
        return auditStatus;
    }

    public void setAuditStatus(int auditStatus) {
        this.auditStatus = auditStatus;
    }
}
