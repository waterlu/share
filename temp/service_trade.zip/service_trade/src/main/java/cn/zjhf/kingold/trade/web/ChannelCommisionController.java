package cn.zjhf.kingold.trade.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.entity.InVO.*;
import cn.zjhf.kingold.trade.entity.OutVO.*;
import cn.zjhf.kingold.trade.service.IChannelCommisionService;
import cn.zjhf.kingold.trade.utils.DataUtils;
import com.alibaba.fastjson.JSON;
import org.hibernate.validator.constraints.NotEmpty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * Created by zhangyijie on 2017/10/18.
 */
@RestController
@RequestMapping(value = "/channelcommision")
public class ChannelCommisionController {
    protected static final Logger logger = LoggerFactory.getLogger(ChannelCommisionController.class);

    @Autowired
    IChannelCommisionService channelCommisionService;

    private ResponseResult creatOKRespResult(String traceID) {
        ResponseResult respResult = new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS,"成功");
        return respResult;
    }

    private ResponseResult creatOKRespResult(String traceID, Object data) {
        ResponseResult respResult = new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS,"成功", data);
        return respResult;
    }

    /**
     * 查询渠道佣金明细记录
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/lstDetail", method = RequestMethod.GET)
    public ResponseResult lstDetail(@RequestParam Map<String, Object> param) throws BusinessException {
        String jsonString = JSON.toJSONString(param);
        LstChannelCommisionDetailConditionVO lstCondition = JSON.parseObject(jsonString, LstChannelCommisionDetailConditionVO.class);
        logger.info("lstDetail start: " + DataUtils.toString(lstCondition));

        CommItemListVO<ChannelCommisionDetailVO> ret = channelCommisionService.lstDetail(lstCondition);

        logger.info("lstDetail end: " + DataUtils.toString(lstCondition.getTraceID(), ret));
        return creatOKRespResult(lstCondition.getTraceID(), ret);
    }

    /**
     * 查询渠道 交易佣金记录， 使用产品ID和渠道商户号
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/lstTradeCommisionsByMerchantNum", method = RequestMethod.GET)
    public ResponseResult lstTradeCommisionsByMerchantNum(@RequestParam Map<String, Object> param) throws BusinessException {
        String jsonString = JSON.toJSONString(param);
        LstTradeCommisionsByMerchantNumConditionVO lstCondition = JSON.parseObject(jsonString, LstTradeCommisionsByMerchantNumConditionVO.class);
        logger.info("lstTradeCommisionsByMerchantNum start: " + DataUtils.toString(lstCondition));

        CommItemListVO<ChannelTradeCommisionItemVO> ret = channelCommisionService.lstTradeCommisionsByMerchantNum(lstCondition);

        logger.info("lstTradeCommisionsByMerchantNum end: " + DataUtils.toString(lstCondition.getTraceID(), ret));
        return creatOKRespResult(lstCondition.getTraceID(), ret);
    }

    /**
     * 批量请求结算
     * @param requestInfo 请求周期，格式: YYYY.MM
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/request", method = RequestMethod.PUT)
    public ResponseResult request(@RequestBody ChannelCommisionRequestVO requestInfo) throws BusinessException {
        logger.info("request start: " + DataUtils.toString(requestInfo));
        DataUtils.checkParam(requestInfo.getRequestCycle());

        ChannelCommisionRequestResultVO ret = channelCommisionService.request(requestInfo.getRequestCycle());

        logger.info("request end: " + DataUtils.toString(requestInfo.getTraceID(), ret));
        return creatOKRespResult(requestInfo.getTraceID(), ret);
    }

    /**
     * 获取批量请求条数/佣金总和
     * @param requestCycle 请求周期，格式: YYYY.MM
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/getBatchCountAndCommission", method = RequestMethod.GET)
    public ResponseResult getBatchCountAndCommission(String traceID,@RequestParam("requestCycle")String requestCycle) throws BusinessException {
        logger.info("getBatchCountAndCommission start: " + DataUtils.toString(requestCycle));
        DataUtils.checkParam(requestCycle);

        ChannelCommisionRequestResultVO ret = channelCommisionService.getBatchCountAndCommission(requestCycle);

        logger.info("getBatchCountAndCommission end: " + DataUtils.toString(traceID, ret));
        return creatOKRespResult(traceID, ret);
    }

    /**
     * 查询渠道佣金汇总记录
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/lstSummary", method = RequestMethod.GET)
    public ResponseResult lstSummary(@RequestParam Map<String, Object> param) throws BusinessException {
        String jsonString = JSON.toJSONString(param);
        LstChannelCommisionSummaryConditionVO lstCondition = JSON.parseObject(jsonString, LstChannelCommisionSummaryConditionVO.class);
        logger.info("lstSummary start: " + DataUtils.toString(lstCondition));

        CommItemListVO<ChannelCommisionSummaryVO> ret = channelCommisionService.lstSummary(lstCondition);

        logger.info("lstSummary end: " + DataUtils.toString(lstCondition.getTraceID(), ret));
        return creatOKRespResult(lstCondition.getTraceID(), ret);
    }

    /**
     * 查询渠道 交易佣金记录， 使用 请求结算单号
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/lstTradeCommisionsByRequestId", method = RequestMethod.GET)
    public ResponseResult lstTradeCommisionsByRequestId(@RequestParam Map<String, Object> param) throws BusinessException {
        String jsonString = JSON.toJSONString(param);
        LstTradeCommisionsByRequestIdConditionVO lstCondition = JSON.parseObject(jsonString, LstTradeCommisionsByRequestIdConditionVO.class);
        logger.info("lstTradeCommisionsByRequestId start: " + DataUtils.toString(lstCondition));

        CommItemListVO<ChannelTradeCommisionItemVO> ret = channelCommisionService.lstTradeCommisionsByRequestId(lstCondition);

        logger.info("lstTradeCommisionsByRequestId end: " + DataUtils.toString(lstCondition.getTraceID(), ret));
        return creatOKRespResult(lstCondition.getTraceID(), ret);
    }

    /**
     * 根据 佣金请求结算ID列表 查询总佣金记录数/总佣金
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/lstChannelCommisionCount", method = RequestMethod.GET)
    public ResponseResult lstChannelCommisionCount(String traceID,@RequestParam("requestIds") @NotEmpty String requestIds) throws BusinessException {
        logger.info("lstChannelCommisionCount start: " + DataUtils.toString(requestIds));
        DataUtils.checkParam(requestIds);
        ChannelCommisionCountVO vo = channelCommisionService.lstChannelCommisionCount(requestIds);

        logger.info("lstChannelCommisionCount end: " + DataUtils.toString(traceID, vo));
        return creatOKRespResult(traceID, vo);
    }

    /**
     * 结算渠道佣金
     * @param channelCommisionSettleVO
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/channelCommisionSettle", method = RequestMethod.PUT)
    public ResponseResult channelCommisionSettle(@RequestBody ChannelCommisionSettleVO channelCommisionSettleVO) throws BusinessException {
        logger.info("channelCommisionSettle start: " + DataUtils.toString(channelCommisionSettleVO));
        DataUtils.checkParam(channelCommisionSettleVO.getAuditor());

        int ret = channelCommisionService.channelCommisionSettle(channelCommisionSettleVO);

        logger.info("channelCommisionSettle end: " + DataUtils.toString(channelCommisionSettleVO.getTraceID(), ret));
        return creatOKRespResult(channelCommisionSettleVO.getTraceID(), ret);
    }
}
