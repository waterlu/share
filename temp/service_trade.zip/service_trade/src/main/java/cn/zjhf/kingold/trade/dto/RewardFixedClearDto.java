package cn.zjhf.kingold.trade.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by lutiehua on 2017/6/3.
 */
public class RewardFixedClearDto {

    private int pass = 0;

    private String operator = null;

    private String remark = null;

    private BigDecimal paymentAmount;

    private List<String> rewardCodeList = new ArrayList<>();

    /**
     * 批次单号
     */
    private String batchCode;

    public void addRewardCode(String rewordCode) {
        rewardCodeList.add(rewordCode);
    }

    public int getPass() {
        return pass;
    }

    public void setPass(int pass) {
        this.pass = pass;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public List<String> getRewardCodeList() {
        return rewardCodeList;
    }

    public String getBatchCode() {
        return batchCode;
    }

    public void setBatchCode(String batchCode) {
        this.batchCode = batchCode;
    }

    public BigDecimal getPaymentAmount() {
        return paymentAmount;
    }

    public void setPaymentAmount(BigDecimal paymentAmount) {
        this.paymentAmount = paymentAmount;
    }
}
