package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.constant.ProductType;
import cn.zjhf.kingold.trade.constant.TradeError;
import cn.zjhf.kingold.trade.constant.TradeStatusMsg;
import cn.zjhf.kingold.trade.entity.CashCoupon;
import cn.zjhf.kingold.trade.entity.InVO.*;
import cn.zjhf.kingold.trade.entity.OutVO.CashCouponItemListVO;
import cn.zjhf.kingold.trade.entity.OutVO.ProductCouponItemVO;
import cn.zjhf.kingold.trade.entity.ProductFixedIncome;
import cn.zjhf.kingold.trade.persistence.dao.CashCouponMapper;
import cn.zjhf.kingold.trade.persistence.dao.CouponExtendRecordMapper;
import cn.zjhf.kingold.trade.service.ICashCouponService;
import cn.zjhf.kingold.trade.service.ISequenceService;
import cn.zjhf.kingold.trade.utils.*;
import cn.zjhf.kingold.trade.utils.Tuple.TwoTuple;
import cn.zjhf.kingold.trade.utils.WhereCondition;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;

/**
 * Created by zhangyijie on 2017/7/5.
 */
@Service
public class CashCouponServiceImpl extends ProductClearBase implements ICashCouponService {
    protected static final Logger logger = LoggerFactory.getLogger(CashCouponServiceImpl.class);

    //代金券状态：删除
    public static final int STATUS_DELETE = -1;

    //代金券状态：1待激活
    public static final int STATUS_INIT = 1;

    //代金券状态：2已激活
    public static final int STATUS_ACTIVE = 2;

    //代金券状态：3已停用
    public static final int STATUS_STOP = 3;


    //礼券类别：1现金券
    public static final int COUPON_TYPE_CASH = 1;

    //礼券类别：2加息券
    public static final int COUPON_TYPE_INTEREST = 2;


    //有效期类型: 1指定有效时间区间
    public static final int VALID_TIME_TYPE_TERM = 1;

    //有效期类型: 2指定有效时间长度
    public static final int VALID_TERM_TYPE_LENGTH = 2;


    //时间单位：1年
    public static final int TIME_UNIT_YEAR = 1;

    //时间单位：2月
    public static final int TIME_UNIT_MONTH = 2;

    //时间单位：3日
    public static final int TIME_UNIT_DAY = 3;


    //不限制产品期限
    public static final int APPLY_PRODUCT_TERM_NO = 1;

    //限制产品期限
    public static final int APPLY_PRODUCT_TERM_YES = 2;


    //不限制子产品(不指定产品列表)
    public static final int APPLY_PRODUCTUUIDS_NO = 1;

    //限制产品子产品(指定产品列表)
    public static final int APPLY_PRODUCTUUIDS_YES = 2;

    /**
     * 剩余可用类型_总体
     */
    public static final int AVAIL_TYPE_TOTAL = 1;

    /**
     * 剩余可用类型_当日
     */
    public static final int AVAIL_TYPE_TODAY = 2;

    @Autowired
    protected CashCouponMapper cashCouponMapper;

    @Autowired
    protected CouponExtendRecordMapper couponExtendRecordMapper;

    @Autowired
    private ISequenceService sequenceService;

    /**
     * 创建现金券
     * @param cashCouponVO
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public String establishCashCoupon(CashCouponVO cashCouponVO) throws BusinessException {
        //获取序号
        cashCouponVO.setCcCode(sequenceService.getCashCouponCode(this));

        cashCouponVO.setCcStatus(STATUS_INIT);

        //对优惠券的类型做检查
        if(cashCouponVO.getCcType() == COUPON_TYPE_CASH) {
            if(cashCouponVO.getFaceValue() <= 0) {
                throw new BusinessException(TradeStatusMsg.CASHCOUPON_FACE_VALUE_ERR, TradeStatusMsg.CASHCOUPON_FACE_VALUE_ERR_MSG, false);
            }
        }else if(cashCouponVO.getCcType() == COUPON_TYPE_INTEREST) {
            if((cashCouponVO.getInterestYieldRate() <= 0) || (cashCouponVO.getInterestYieldRate() >= 1)) {
                throw new BusinessException(TradeStatusMsg.CASHCOUPON_YIELD_RATE_ERR, TradeStatusMsg.CASHCOUPON_YIELD_RATE_ERR_MSG, false);
            }

            if((cashCouponVO.getInterestYieldType() == 1) && (cashCouponVO.getInterestYieldPeriod() <= 0)) {
                throw new BusinessException(TradeStatusMsg.CASHCOUPON_YIELD_RATE_ERR, TradeStatusMsg.CASHCOUPON_YIELD_RATE_ERR_MSG, false);
            }
        }

        //cashCouponVO.setApplyProductType("FIXI");

        if(cashCouponVO.getCcType() == 1 && cashCouponVO.getFaceValue() <= 0) {
            throw new BusinessException(TradeStatusMsg.CASHCOUPON_BATCH_PAPAM_ERR, TradeStatusMsg.CASHCOUPON_BATCH_PAPAM_ERR_MSG, false);
        }

        if(cashCouponVO.getCcType() == 2 && cashCouponVO.getInterestYieldRate() < 0) {
            throw new BusinessException(TradeStatusMsg.INTERESTCOUPON_BATCH_PAPAM_ERR, TradeStatusMsg.INTERESTCOUPON_BATCH_PAPAM_ERR_MSG, false);
        }

        if(cashCouponVO.getValidTermType() == VALID_TIME_TYPE_TERM) {
            if((cashCouponVO.getValidStartTime() == null) || (cashCouponVO.getValidEndTime() == null) || (cashCouponVO.getValidEndTime().getTime() <= cashCouponVO.getValidStartTime().getTime())) {
                throw new BusinessException(TradeStatusMsg.CASHCOUPON_BATCH_PAPAM_ERR, TradeStatusMsg.CASHCOUPON_BATCH_PAPAM_ERR_MSG, false);
            }
        }else if(cashCouponVO.getValidTermType() == VALID_TERM_TYPE_LENGTH) {
            if((cashCouponVO.getValidTermUnit() <= 0) || (cashCouponVO.getValidTermQuantity() <= 0)) {
                throw new BusinessException(TradeStatusMsg.CASHCOUPON_BATCH_PAPAM_ERR, TradeStatusMsg.CASHCOUPON_BATCH_PAPAM_ERR_MSG, false);
            }
        }else {
            throw new BusinessException(TradeStatusMsg.CASHCOUPON_BATCH_PAPAM_ERR, TradeStatusMsg.CASHCOUPON_BATCH_PAPAM_ERR_MSG, false);
        }

        if(cashCouponVO.getApplyTradeAmount() <= 0) {
            throw new BusinessException(TradeStatusMsg.CASHCOUPON_BATCH_PAPAM_ERR, TradeStatusMsg.CASHCOUPON_BATCH_PAPAM_ERR_MSG, false);
        }

        if((cashCouponVO.getIsApplyProductTerm() == APPLY_PRODUCT_TERM_YES) && (DataUtils.isEmpty(cashCouponVO.getApplyProductTerms()))) {
            throw new BusinessException(TradeStatusMsg.CASHCOUPON_BATCH_PAPAM_ERR, TradeStatusMsg.CASHCOUPON_BATCH_PAPAM_ERR_MSG, false);
        }

        if((cashCouponVO.getIsApplyProductuuids() == APPLY_PRODUCTUUIDS_YES) && (DataUtils.isEmpty(cashCouponVO.getApplyProductuuids()))) {
            throw new BusinessException(TradeStatusMsg.CASHCOUPON_BATCH_PAPAM_ERR, TradeStatusMsg.CASHCOUPON_BATCH_PAPAM_ERR_MSG, false);
        }

        if(DataUtils.isEmpty(cashCouponVO.getUpdateUserId())) {
            throw new BusinessException(TradeStatusMsg.CASHCOUPON_BATCH_PAPAM_ERR, TradeStatusMsg.CASHCOUPON_BATCH_PAPAM_ERR_MSG, false);
        }

        cashCouponVO.setCreateTime(new Date());
        cashCouponVO.setUpdateTime(new Date());
        cashCouponVO.setUpdateUserId(cashCouponVO.getUpdateUserId());

        CashCoupon cashCoupon = cashCouponVO.get();
        cashCouponMapper.insertSelective(cashCoupon);
        return cashCouponVO.getCcCode();
    }

    /**
     * 更新现金券
     * @param cashCouponVO
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Boolean updateCashCoupon(CashCouponVO cashCouponVO) throws BusinessException {

        //避免覆盖处理
        CashCouponVO oldCashCouponVO = lstCashCoupon(cashCouponVO.getCcCode());
        cashCouponVO.setCcStatus(oldCashCouponVO.getCcStatus());
        cashCouponVO.setDeleteFlag(oldCashCouponVO.getDeleteFlag());
        cashCouponVO.setDeleteTime(oldCashCouponVO.getDeleteTime());
        cashCouponVO.setCreateTime(oldCashCouponVO.getCreateTime());

        return cashCouponMapper.updateByPrimaryKeySelective(cashCouponVO.get()) > 0;
    }

    private CashCouponVO additionalVO(CashCoupon cashCoupon) {
        if(cashCoupon == null) {
            return null;
        }

        CashCouponVO cashCouponVO = new CashCouponVO(cashCoupon);

        int usedCount = couponExtendRecordMapper.lstCountByStatus(cashCoupon.getCcCode(), WhereCondition.intsToSql(CouponExtendRecordServiceImpl.STATUS_USED));
        cashCouponVO.setUsedCount(usedCount);

        int receiptCount = couponExtendRecordMapper.lstCountByStatus(cashCoupon.getCcCode(),
                WhereCondition.intsToSql(CouponExtendRecordServiceImpl.STATUS_USED,
                        CouponExtendRecordServiceImpl.STATUS_EXTEND,
                        CouponExtendRecordServiceImpl.STATUS_EXPIRED,
                        CouponExtendRecordServiceImpl.STATUS_OBSOLETE));
        cashCouponVO.setReceiptCount(receiptCount);
        return cashCouponVO;
    }

    /**
     * 查询现金券的列表
     * @param lstCondition
     * @return
     * @throws BusinessException
     */
    @Override
    public CashCouponItemListVO lstCashCoupon(LstCashCouponConditionVO lstCondition) throws BusinessException {
        CashCouponItemListVO itemList = new CashCouponItemListVO();

        WhereCondition where = new WhereCondition();
        where.setCondi("cc_code", lstCondition.getCcCode());
        where.setCondi("cc_type", lstCondition.getCcType(), true);
        where.setCondi("cc_status", lstCondition.getCcStatus(), true);
        where.setBetween("create_time", lstCondition.getBeginDate(), lstCondition.getEndDate());
        where.noDelete();
        itemList.setTotalCount(cashCouponMapper.lstCountByCondition(where));

        where.setPage(lstCondition.getBeginSN(), lstCondition.getEndSN(), "create_time");
        List<CashCoupon> cashCoupons = cashCouponMapper.lstByCondition(where);

        List<CashCouponVO> cashCouponVOs = new ArrayList<CashCouponVO>();
        for(CashCoupon cashCoupon : cashCoupons) {
            CashCouponVO cashCouponVO = additionalVO(cashCoupon);
            if(cashCouponVO != null) {
                cashCouponVOs.add(cashCouponVO);
            }
        }
        itemList.setItems(cashCouponVOs);

        return itemList;
    }

    /**
     * 查询产品可用现金券，批量
     * @return
     * @throws BusinessException
     */
    @Override
    public List<ProductCouponItemVO> cashCouponByProductList(List<ProductVO> productList) throws BusinessException {
        WhereCondition where = new WhereCondition();
        where.setCondi("cc_status",2 , true);
        where.setCondi("delete_flag",0 , false);
        List<CashCoupon> cashCoupons = cashCouponMapper.lstByCondition(where);
        List<ProductCouponItemVO> productCouponItemVOS = new ArrayList<>();
        for (ProductVO productVO: productList) {
            ProductCouponItemVO productCouponItemVO = new ProductCouponItemVO();
            double maxIncome = calculateMaxCashCoupon(productVO.getProductUuid(), productVO.getProductPeriod(), productVO.getAnnualInterestRate(), cashCoupons);
            productCouponItemVO.setMaxProfit(AmountUtils.toBigDecimal(maxIncome).setScale(4, BigDecimal.ROUND_DOWN));
            productCouponItemVO.setProductUuid(productVO.getProductUuid());
            productCouponItemVOS.add(productCouponItemVO);
        }
        return productCouponItemVOS;
    }

    private double calculateMaxCashCoupon(String productUuid, Integer productPeriod, double annualInterestRate, List<CashCoupon> cashCoupons) {
        double maxIncome = 0;
        for (CashCoupon cashCoupon : cashCoupons) {
            if (!checkCouponWithProduct(cashCoupon, productUuid, productPeriod)) {
                continue;
            }
            double calculate = maxCouponProfitMath(cashCoupon,productPeriod, annualInterestRate);
            maxIncome = calculate > maxIncome ? calculate : maxIncome;
        }
        return maxIncome;
    }

    /**
     * 检查红包对某个产品是否可用
     * 通用算法逻辑，不包含任何IO，可以循环调用
     * @param cashCoupon
     * @param productUuid
     * @param productPeriod
     * @return
     */
    private boolean checkCouponWithProduct(CashCoupon cashCoupon, String productUuid, Integer productPeriod) {

        //Step1 如果已经指定了产品列表，检查是否在产品列表内
        if(DataUtils.byteToInt(cashCoupon.getIsApplyProductuuids()) == APPLY_PRODUCTUUIDS_YES) {
            if(!DataUtils.split(cashCoupon.getApplyProductuuids()).contains(productUuid)) {
                return false;
            }
        }
        //Step2 如果已经要求了产品期限，则检查该产品的期限是否满足该现金券的要求
        if(DataUtils.byteToInt(cashCoupon.getIsApplyProductTerm()) == APPLY_PRODUCT_TERM_YES) {
            //获取该产品的信息
            List<TwoTuple<Integer, Integer>> listItems = getApplyProductTerms(cashCoupon.getApplyProductTerms());
            boolean isIn = false;
            for(TwoTuple<Integer, Integer> term : listItems) {
                if((productPeriod >= term.first) && (productPeriod <= term.second)) {
                    isIn = true;
                    break;
                }
            }
            if (!isIn) {
                return false;
            }
        }
        return true;
    }


    private double maxCouponProfitMath (CashCoupon cashCoupon, Integer productPeriod, double annualInterestRate) {
        if (cashCoupon.getApplyTradeAmount().doubleValue() - cashCoupon.getFaceValue().doubleValue() <= 0) {
            return 0;
        }
        double profit = ( cashCoupon.getApplyTradeAmount().doubleValue() * annualInterestRate * (productPeriod.doubleValue()/365)
                + cashCoupon.getFaceValue().doubleValue() ) / (cashCoupon.getApplyTradeAmount().doubleValue() - cashCoupon.getFaceValue().doubleValue())/(productPeriod.doubleValue()/365);

        return profit - annualInterestRate;
    }

    /**
     * 查询单个现金券
     * @param ccCode
     * @return
     * @throws BusinessException
     */
    @Override
    public CashCouponVO lstCashCoupon(String ccCode) throws BusinessException {
        CashCoupon cashCoupon = cashCouponMapper.selectByPrimaryKey(ccCode);

        if(cashCoupon != null) {
            return additionalVO(cashCoupon);
        }else{
            throw new BusinessException(TradeStatusMsg.CASHCOUPON_BATCH_NOEXIST, TradeStatusMsg.CASHCOUPON_BATCH_NOEXIST_MSG, false);
        }
    }

    /**
     * 更新状态
     * @param ccCode 活动批次码
     * @param status 状态
     * @param updateUserId 更新用户Id
     */
    @Override
    public void updateStatus(String ccCode, int status, String updateUserId) {
        if(status == STATUS_ACTIVE) {
            cashCouponMapper.activate(ccCode, status, updateUserId);
        }else if(status == STATUS_STOP) {
            cashCouponMapper.disable(ccCode, status, updateUserId);
        }else if(status == STATUS_DELETE) {
            cashCouponMapper.delete(ccCode, updateUserId);
        }
    }

    /**
     * 查询礼券的可用数量
     * @param ccCode
     * @return
     * @throws BusinessException
     */
    @Override
    public TwoTuple<Integer, Integer> lstAvailableQuantity(String ccCode) throws BusinessException {
        CashCoupon cashCoupon = cashCouponMapper.selectByPrimaryKey(ccCode);

        if((cashCoupon!=null)
                && ((cashCoupon.getCcStatus()!=null) && (cashCoupon.getCcStatus() == STATUS_ACTIVE))
                && ((cashCoupon.getDeleteFlag()!=null) && (cashCoupon.getDeleteFlag() == 0))) {
            int availQuantity = 0;
            int availType = AVAIL_TYPE_TOTAL;

            //Step1 检查该批次礼券剩余数量
            int extendMaxNum = ((cashCoupon.getExtendMaxNum()!=null) ? cashCoupon.getExtendMaxNum().intValue() : 0);
            WhereCondition where = new WhereCondition();
            where.setCondi("coupon_code", ccCode);
            int useCount = couponExtendRecordMapper.lstCountRecord(where);
            logger.info("ccCode:" + ccCode + ", totalNum:" + extendMaxNum + ", useCount:" + useCount);
            if(useCount >= extendMaxNum) {
                logger.error("礼券批次" + ccCode + "已用完额度，停用该现金券");
                updateStatus(ccCode, STATUS_STOP, "sys");
                return new TwoTuple<>(AVAIL_TYPE_TOTAL, 0);
            }else {
                availQuantity = cashCoupon.getExtendMaxNum().intValue() - useCount;
                logger.info("总剩余数量：{}", availQuantity);
            }

            //Step2 检查该批次礼券当日剩余数量
            int extendDayMaxNum = ((cashCoupon.getExtendDayMaxNum()!=null) ? cashCoupon.getExtendDayMaxNum().intValue() : 0);
            Date tomorrow = StringOrDate.dateOffsetDay(StringOrDate.getCurDate(), 1);
            where.setBetween("create_time", StringOrDate.getCurDate(), tomorrow);
            useCount = couponExtendRecordMapper.lstCountRecord(where);
            logger.info("ccCode:" + ccCode + ", totalNum:" + extendDayMaxNum + ", useCount:" + useCount);
            if(useCount >= extendDayMaxNum) {
                logger.error("礼券批次" + ccCode + "今日额度已用完");
                return new TwoTuple<>(AVAIL_TYPE_TODAY, 0);
            }else {
                int todayAvailQuantity = cashCoupon.getExtendDayMaxNum().intValue() - useCount;
                logger.info("当日剩余数量：{}", todayAvailQuantity);
                if(todayAvailQuantity < availQuantity) {
                    availType = AVAIL_TYPE_TODAY;
                    availQuantity = todayAvailQuantity;
                }
            }

            return new TwoTuple<>(availType, availQuantity);
        }

        return new TwoTuple<>(AVAIL_TYPE_TOTAL, 0);
    }

    /**
     * 检测该批次礼券是否已经被领完
     * @param ccCode
     * @throws BusinessException
     */
    @Override
    public void checkCashCouponExhausted(String ccCode) throws BusinessException {
        CashCoupon cashCoupon = cashCouponMapper.selectByPrimaryKey(ccCode);
        if(cashCoupon==null) {
            throw new BusinessException(TradeStatusMsg.CASHCOUPON_BATCH_NOEXIST, TradeStatusMsg.CASHCOUPON_BATCH_NOEXIST_MSG, false);
        }

        TwoTuple<Integer, Integer> availableQuantity = lstAvailableQuantity(ccCode);
        logger.info("availableQuantity: {}", availableQuantity);

        if((availableQuantity.first.intValue()==AVAIL_TYPE_TOTAL) && (availableQuantity.second.intValue()<=0)) {
            //总额度已用完
            throw new BusinessException(TradeStatusMsg.CASHCOUPON_EXHAUSTED_ERR,
                    TradeStatusMsg.CASHCOUPON_EXHAUSTED_MSG, false);
        }else if((availableQuantity.first.intValue()==AVAIL_TYPE_TODAY) && (availableQuantity.second.intValue()<=0)) {
            //当日额度已用完
            throw new BusinessException(TradeStatusMsg.TODAY_CASHCOUPON_EXHAUSTED_ERR,
                    TradeStatusMsg.TODAY_CASHCOUPON_EXHAUSTED_MSG, false);
        }
    }

    /**
     * 查询单个有效的现金券
     * @param ccCode
     * @return 有效，返回礼券批次信息；反之，返回null
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = BusinessException.class, propagation = Propagation.REQUIRES_NEW)
    public CashCoupon lstValidCashCoupon(String ccCode) throws BusinessException {
        CashCoupon cashCoupon = cashCouponMapper.selectByPrimaryKey(ccCode);

        //Step1 检查是否为null
        if(cashCoupon == null) {
            logger.error("礼券批次{}不存在", ccCode);
            return cashCoupon;
        }else if((cashCoupon.getDeleteFlag()!=null) && (cashCoupon.getDeleteFlag().intValue()==1)) {
            logger.error("礼券批次{}已删除", ccCode);
            return null;
        }

        //Step2 如果设置了有效截止时间，则检查之
        if ((cashCoupon.getValidEndTime()!=null)
                && (cashCoupon.getValidEndTime().getTime()<(new Date()).getTime())) {
            logger.error("礼券批次" + ccCode + "已过期，有效截止时间：" + cashCoupon.getValidEndTime().toString());

            //如果当前状态为已激活，则停用
            if((cashCoupon.getCcStatus()!=null) && (cashCoupon.getCcStatus().intValue()==STATUS_ACTIVE)) {
                updateStatus(ccCode, STATUS_STOP, "sys");
            }
            return null;
        }

        //Step3 如果设置了有效截止时间，则检查之
        if((cashCoupon.getCcStatus()!=null) && (cashCoupon.getCcStatus().intValue()==STATUS_ACTIVE)) {
            //Step4 检查该批次礼券剩余数量
            int extendMaxNum = ((cashCoupon.getExtendMaxNum()!=null) ? cashCoupon.getExtendMaxNum().intValue() : 0);
            WhereCondition where = new WhereCondition();
            where.setCondi("coupon_code", ccCode);
            int useCount = couponExtendRecordMapper.lstCountRecord(where);
            logger.info("ccCode:" + ccCode + ", totalNum:" + extendMaxNum + ", useCount:" + useCount);
            if(useCount >= extendMaxNum) {
                logger.error("礼券批次" + ccCode + "已用完额度，停用该现金券");
                updateStatus(ccCode, STATUS_STOP, "sys");
                return null;
            }

            //Step5 检查该批次礼券当日剩余数量
            int extendDayMaxNum = ((cashCoupon.getExtendDayMaxNum()!=null) ? cashCoupon.getExtendDayMaxNum().intValue() : 0);
            Date tomorrow = StringOrDate.dateOffsetDay(StringOrDate.getCurDate(), 1);
            where.setBetween("create_time", StringOrDate.getCurDate(), tomorrow);
            useCount = couponExtendRecordMapper.lstCountRecord(where);
            logger.info("ccCode:" + ccCode + ", totalNum:" + extendDayMaxNum + ", useCount:" + useCount);
            if(useCount >= extendDayMaxNum) {
                logger.error("礼券批次" + ccCode + "今日额度已用完");
                return null;
            }

            return cashCoupon;
        }else {
            logger.error("礼券批次{}未激活", ccCode);
        }

        return null;
    }

    /**
     * 更新现金券的状态
     * @param commCouponUpdateVO
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateStatus(CommCouponUpdateVO commCouponUpdateVO) throws BusinessException {
        updateStatus(commCouponUpdateVO.getCommCode(), commCouponUpdateVO.getNewStatus(), commCouponUpdateVO.getUpdateUserId());
    }

    /**
     * 自动状态刷新
     */
    @Override
    public void autoRefreshStatus() {
        int totalCount = 0;

        // 场景一 该批次指定了现金券的有效时间，但该有限时间已过期，则停用该现金券， 即：发放给用户已经过期的现金券是一件很荒谬的事儿
        final int limitCount = 1000;
        int succCount = 0;

        while((succCount = cashCouponMapper.autoUpdateStatus(STATUS_STOP, VALID_TIME_TYPE_TERM, limitCount)) > 0) {
            logger.info("autoRefreshStatus_stepupdate_succCount: {}", succCount);
            totalCount += succCount;

            if(succCount == limitCount) {
                continue;
            }else {
                break;
            }
        }

        logger.info("autoRefreshStatus_totalCount: {}", totalCount);
    }

    private List<TwoTuple<Integer, Integer>> getApplyProductTerms(String applyProductTerms) {
        List<TwoTuple<Integer, Integer>> listItems = new ArrayList<TwoTuple<Integer, Integer>>();
        List<String> terms = DataUtils.split(applyProductTerms, ",");

        for(String term : terms) {
            List<String> termPair = DataUtils.split(term, "-");
            if(termPair.size() > 1) {
                try {
                    Integer startTerm = Integer.parseInt(termPair.get(0).trim());
                    Integer endTerm = Integer.parseInt(termPair.get(1).trim());
                    listItems.add(new TwoTuple<Integer, Integer>(startTerm, endTerm));
                }catch(Exception e) {
                    logger.error(term + "转换失败", e);
                    continue;
                }
            }
        }

        return listItems;
    }

    /**
     * 判断该现金券是否适配交易
     * @param couponCode
     * @param productUuid
     * @param amt
     * @return
     * @throws BusinessException
     */
    @Override
    public Boolean isAdaptTrade(String couponCode,String productUuid, double amt) throws BusinessException {
        CashCoupon cashCoupon = cashCouponMapper.selectByPrimaryKey(couponCode);
        if(null != cashCoupon) {
            //Step1 检查是否满足单笔投资下限
            if(amt < cashCoupon.getApplyTradeAmount().doubleValue()) {
                logger.error("不满足单笔投资下限要求，" + cashCoupon.getApplyTradeAmount().doubleValue() + " " + amt);
                return false;
            }

            //Step2 如果已经指定了产品列表，检查是否在产品列表内
            if(DataUtils.byteToInt(cashCoupon.getIsApplyProductuuids()) == APPLY_PRODUCTUUIDS_YES) {
                if(DataUtils.split(cashCoupon.getApplyProductuuids()).contains(productUuid)) {
                    return true;
                }else {
                    logger.error("该产品没有在指定列表内，" + cashCoupon.getApplyProductuuids() + " " + productUuid);
                }
            }

            //Step3 如果已经要求了产品期限，则检查该产品的期限是否满足该现金券的要求
            if(DataUtils.byteToInt(cashCoupon.getIsApplyProductTerm()) == APPLY_PRODUCT_TERM_YES) {
                //获取该产品的信息
                ProductFixedIncome productInfo = getFixedIncomeProductById(productUuid);
                List<TwoTuple<Integer, Integer>> listItems = getApplyProductTerms(cashCoupon.getApplyProductTerms());

                for(TwoTuple<Integer, Integer> term : listItems) {
                    if((productInfo.getProductPeriod() >= term.first) && (productInfo.getProductPeriod() <= term.second)) {
                        return true;
                    }
                }

                logger.error("该产品没有在指定产品期限内，" + cashCoupon.getApplyProductTerms() + " " + productInfo.getProductPeriod());
            }

            //既没有指定产品列表，也没有限制产品期限
            if((DataUtils.byteToInt(cashCoupon.getIsApplyProductuuids()) == APPLY_PRODUCTUUIDS_NO)
                    && (DataUtils.byteToInt(cashCoupon.getIsApplyProductTerm()) == APPLY_PRODUCT_TERM_NO)) {
                 return true;
            }
        }else {
            logger.error("该现金券不存在");
        }

        return false;
    }

    @Override
    public String lstLastSequence(String idMode) {
        return cashCouponMapper.lstLastSequence(idMode);
    }

    /**
     * 根据现金券的批次号反向查询适用的产品
     * @param ccCode
     * @param merchantNum
     * @return Map 包含产品列表和产品总数
     * @throws BusinessException
     */
    @Override
    public Map lstAdaptProduct(String ccCode, Integer startRow, Integer pageSize, String merchantNum) throws BusinessException {
        CashCouponVO cashCouponVO = lstCashCoupon(ccCode);

        if (((cashCouponVO.getCcStatus()==STATUS_ACTIVE) || (cashCouponVO.getCcStatus()==STATUS_STOP)) && cashCouponVO.getApplyProductType().equals(ProductType.PRODUCT_FT)) {
            Map<String, Object> param = MapParamUtils.obj2Map(new LstProductConditionVO(cashCouponVO.getApplyProductTerms(), cashCouponVO.getApplyProductuuids(), startRow, pageSize, merchantNum));
            ResponseResult responseResult = productClient.lstByCondition(param);

            logger.info((responseResult != null) ? responseResult.toString() : "null");

            if ((responseResult == null) || (responseResult.getCode() != TradeError.OK)) {
                throw new BusinessException(TradeStatusMsg.COUPON_LSTPRODUCT_ERR, TradeStatusMsg.COUPON_LSTPRODUCT_MSG, false);
            }

            return (Map) responseResult.getData();
        }

        return new HashMap();
    }

    @Override
    public  List<CashCouponVO> getAllCoupon()  throws BusinessException {
        return cashCouponMapper.getAllCoupon();
    }

    @Override
    public List<CashCouponVO> getCouponList(Map params) throws BusinessException{
        String couponCodes = (String)params.get("couponCodes");
        if (StringUtils.isNotBlank(couponCodes)) {
            List<String> ccCodeList = Arrays.asList(couponCodes.split("\\$\\$"));
            params.put("ccCodeList", ccCodeList);
        }
        return cashCouponMapper.getCouponList(params);
    }
}
