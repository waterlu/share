package cn.zjhf.kingold.trade.vo;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Created by zhangyijie on 2018/4/26.
 */
public class AmendTradeOrderVO implements Serializable {
    /**
     * 产品订单编号
     */
    private String orderBillCode;

    /**
     * 产品预计年化收益率(冗余)
     */
    private BigDecimal productAnnualInterestRate;

    /**
     * 加息券加息率
     */
    private BigDecimal couponInterestYieldRate;

    /**
     * 加息券加息时长，0为全程加息
     */
    private Integer couponInterestPeriod;

    /**
     * 订单金额，订单金额 = 实缴金额 + 营销费用；订单金额 = 产品份额 * 产品单价
     */
    private BigDecimal orderAmount;

    /**
     * 预期收益
     */
    private BigDecimal expectedProfitAmount;

    /**
     * 投资收益，每日日终更新
     */
    private BigDecimal profitAmount;

    /**
     * 营销加息金额
     */
    private BigDecimal marketingRateAmount;

    /**
     * 兑付金额
     */
    private BigDecimal cashAmount;

    public BigDecimal getProductAnnualInterestRate() {
        return productAnnualInterestRate;
    }

    public void setProductAnnualInterestRate(BigDecimal productAnnualInterestRate) {
        this.productAnnualInterestRate = productAnnualInterestRate;
    }

    public BigDecimal getCouponInterestYieldRate() {
        return couponInterestYieldRate;
    }

    public void setCouponInterestYieldRate(BigDecimal couponInterestYieldRate) {
        this.couponInterestYieldRate = couponInterestYieldRate;
    }

    public Integer getCouponInterestPeriod() {
        return couponInterestPeriod;
    }

    public void setCouponInterestPeriod(Integer couponInterestPeriod) {
        this.couponInterestPeriod = couponInterestPeriod;
    }

    public BigDecimal getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(BigDecimal orderAmount) {
        this.orderAmount = orderAmount;
    }

    public BigDecimal getExpectedProfitAmount() {
        return expectedProfitAmount;
    }

    public void setExpectedProfitAmount(BigDecimal expectedProfitAmount) {
        this.expectedProfitAmount = expectedProfitAmount;
    }

    public BigDecimal getProfitAmount() {
        return profitAmount;
    }

    public void setProfitAmount(BigDecimal profitAmount) {
        this.profitAmount = profitAmount;
    }

    public BigDecimal getMarketingRateAmount() {
        return marketingRateAmount;
    }

    public void setMarketingRateAmount(BigDecimal marketingRateAmount) {
        this.marketingRateAmount = marketingRateAmount;
    }

    public BigDecimal getCashAmount() {
        return cashAmount;
    }

    public void setCashAmount(BigDecimal cashAmount) {
        this.cashAmount = cashAmount;
    }

    public String getOrderBillCode() {
        return orderBillCode;
    }

    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    @Override
    public String toString() {
        return "AmendTradeOrderVO{" +
                "orderBillCode='" + orderBillCode + '\'' +
                ", productAnnualInterestRate=" + productAnnualInterestRate +
                ", couponInterestYieldRate=" + couponInterestYieldRate +
                ", couponInterestPeriod=" + couponInterestPeriod +
                ", orderAmount=" + orderAmount +
                ", expectedProfitAmount=" + expectedProfitAmount +
                ", profitAmount=" + profitAmount +
                ", marketingRateAmount=" + marketingRateAmount +
                ", cashAmount=" + cashAmount +
                '}';
    }
}
