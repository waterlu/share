package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.common.utils.CacheUtil;
import cn.zjhf.kingold.rocketmq.base.SimpleMessage;
import cn.zjhf.kingold.service_consumer.service.UserServiceConsumer;
import cn.zjhf.kingold.trade.baofoo.BaoFooCode;
import cn.zjhf.kingold.trade.constant.*;
import cn.zjhf.kingold.trade.dto.CreateOrderDTO;
import cn.zjhf.kingold.trade.entity.*;
import cn.zjhf.kingold.trade.entity.InVO.CouponExtendRecordVO;
import cn.zjhf.kingold.trade.entity.OutVO.TradePaymentSummaryVO;
import cn.zjhf.kingold.trade.exception.*;
import cn.zjhf.kingold.trade.persistence.dao.AccountBaofooCustodyMapper;
import cn.zjhf.kingold.trade.persistence.dao.OperationReportMapper;
import cn.zjhf.kingold.trade.persistence.dao.TradeOrderMapper;
import cn.zjhf.kingold.trade.persistence.dao.TradeRechargeMapper;
import cn.zjhf.kingold.trade.persistence.mq.message.OrderCancelMessage;
import cn.zjhf.kingold.trade.persistence.mq.message.OrderPaidMessage;
import cn.zjhf.kingold.trade.persistence.mq.producer.OrderCancelTransactionProducer;
import cn.zjhf.kingold.trade.persistence.mq.producer.OrderPaidTransactionProducer;
import cn.zjhf.kingold.trade.persistence.mq.producer.PayWithdrawTransactionProducer;
import cn.zjhf.kingold.trade.service.*;
import cn.zjhf.kingold.trade.utils.*;
import cn.zjhf.kingold.trade.utils.File.FileServiceUtils;
import cn.zjhf.kingold.trade.utils.File.FileUtils;
import cn.zjhf.kingold.trade.utils.File.PDFFillUtils;
import cn.zjhf.kingold.trade.utils.Tuple.ThreeTuple;
import cn.zjhf.kingold.trade.utils.Tuple.TwoTuple;
import cn.zjhf.kingold.trade.vo.AmendTradeOrderVO;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.alibaba.rocketmq.client.producer.LocalTransactionExecuter;
import com.alibaba.rocketmq.client.producer.LocalTransactionState;
import com.alibaba.rocketmq.common.message.Message;
import com.google.common.base.Strings;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.Image;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 交易实现类
 * <p>2018/03/06 修改超买超卖问题 lutiehua</p>
 *
 * @author lutiehua
 * @date 2017/4/28
 * @version
 */
@Service
public class TradeServiceImpl extends ProductClearBase implements ITradeService {

    private final Logger LOGGER = LoggerFactory.getLogger(TradeServiceImpl.class);

    @Autowired
    private TradeRechargeMapper tradeRechargeMapper;

    @Autowired
    private TradeOrderMapper tradeOrderMapper;

    @Autowired
    private AccountBaofooCustodyMapper accountBaofooMapper;

    @Autowired
    private OperationReportMapper operationReportMapper;

    @Autowired
    private IPayService payService;

    @Autowired
    private ITradeService tradeService;

    @Autowired
    private IAccountService accountService;

    @Autowired
    private UserServiceConsumer userServiceConsumer;

    @Autowired
    private IInvestorRemoteService investorRemoteService;

    @Autowired
    private OrderPaidTransactionProducer orderPaidTransactionProducer;

    @Autowired
    private OrderCancelTransactionProducer orderCancelTransactionProducer;

    @Autowired
    private PayWithdrawTransactionProducer payWithdrawTransactionProducer;

    @Autowired
    private ITradeTransactionService tradeTransactionService;

    @Autowired
    private FileServiceUtils fileServiceUtils;

    @Autowired
    private ICouponExtendRecordService couponExtendRecordService;

    @Autowired
    private ISequenceService sequenceService;

    @Value("${url.org.hostPort}")
    private String orgHostPort;

    @Value("${open.baofoo.interface}")
    public boolean isOpenBaofooInterface;


    @Value("${product.contract.templatefilepath}")
    private String contractTemplateFilePath;

    @Value("${product.contract.sealfilepath}")
    private String contractSealFilePath;

    @Value("${product.contract.destfilepath}")
    private String contractDestFilePath;

    /**
     * 创建充值订单
     *
     * @param userUUID        用户UUID
     * @param userPhone       用户手机号码
     * @param accountUUID     账户UUID
     * @param agencyAccountNo 代理机构对应账户
     * @param amount          充值金额
     * @param tradeOrderBillCodeExtend          宝付交易流水编号
     * @param transactionChannel
     * @return 充值单编号
     */
    @Override
    @Transactional(rollbackFor = {BusinessException.class, RuntimeException.class})
    public String createRechargeOrder(String userUUID, String userPhone, String accountUUID, String agencyAccountNo,
                                      double amount, String tradeOrderBillCodeExtend, String transactionChannel, String accountType,
                                      String belongMerchantNum, Integer payMethod ) throws BusinessException {
        Date date = new Date();
        String billCode = ZJBuzzUtils.generateOrderBillCode(TradeType.TRADE_RE_CHARGE);
        String uuid = ZJBuzzUtils.generateUUID();
        TradeRecharge recharge = new TradeRecharge();
        recharge.setTradeRechargeUuid(uuid);
        recharge.setRechargeBillCode(billCode);
        recharge.setRechargeBillType(TradeType.TRADE_RE_CHARGE);
        recharge.setUserUuid(userUUID);
        recharge.setUserPhone(userPhone);
        recharge.setAccountUuid(accountUUID);
        recharge.setAgencyAccountNo(agencyAccountNo);
        recharge.setRechargeAmount(new BigDecimal(amount));
        recharge.setRechargeStatus(TradeStatus.NEW);
        recharge.setAccountType(accountType);
        recharge.setPayMethod(payMethod.byteValue());
        recharge.setDeleteFlag((byte) 0);
        recharge.setCreateTime(date);
        recharge.setUpdateTime(date);
        recharge.setBelongMerchantNum(belongMerchantNum);

        if(DataUtils.isNotEmpty(transactionChannel)) {
            recharge.setTransactionChannel(transactionChannel);
        }
        if (accountType != null && AccountType.ACCOUNT_TYPE_FINANCIER.equals(accountType)) {
            recharge.setRechargeFeeType(Integer.valueOf(RechargeType.PERSON_PAY).byteValue());
            recharge.setRechargeFee(new BigDecimal(5));
        }
        //用来兼容一些老数据
        if(StringUtils.isBlank(tradeOrderBillCodeExtend)){
            recharge.setTradeOrderBillCodeExtend(billCode);
        }
        LOGGER.info("创建充值订单,param:"+JSONObject.toJSONString(recharge));
        tradeRechargeMapper.insert(recharge);
        return billCode;
    }

    /**
     * 创建取现订单
     * 这里只能获取投资用户 信息。
     *
     * @param accountUuid accountUuid
     * @param amount      取现金额
     * @param feeType     手续费支付方      PayMsg.FEE_TOKEN_ON_PLATFORM  PayMsg.FEE_TOKEN_ON_PERSON
     * @param tradeOrderBillCodeExtend      宝付交易流水编号
     * @param transactionChannel
     * @return 充值单编号
     */
    @Override
    @Transactional(rollbackFor = {BusinessException.class, RuntimeException.class})
    public TradeRecharge createWithdrawOrder(String accountUuid, double amount, byte feeType, String tradeOrderBillCodeExtend,
                                             String transactionChannel, String accountType, String belongMerchantNum) throws BusinessException {

        Map accountBaofooParams = new HashMap();
        accountBaofooParams.put("accountUuid", accountUuid);
        Map accountBaofooResult = accountBaofooMapper.getBaofooAndAccount(accountBaofooParams);
        String bankUserCardNo = "";
        if (!MapUtils.isEmpty(accountBaofooResult)) {

            if (null != accountBaofooResult.get("bankCardInfo") && ((List) accountBaofooResult.get("bankCardInfo")).size() > 0) {
                LOGGER.info("创建取现订单,获取到当前用户的银行卡号，param:{}",JSONObject.toJSONString(accountBaofooResult));
                bankUserCardNo = MapParamUtils.getStringInMap((Map) ((List) accountBaofooResult.get("bankCardInfo")).get(0), "bankUserCardNo");
            }
        }

        if (MapUtils.isEmpty(accountBaofooResult)) {
            throw new BusinessException(AccountStatusMsg.ACCOUNT_NOT_EXIST_CODE, AccountStatusMsg.ACCOUNT_NOT_EXIST, true);
        }
        String userUuid = MapParamUtils.getStringInMap(accountBaofooResult, "userUuid");

        //获取投资者信息
        Map investorMap = investorRemoteService.getInvestorInfo(userUuid);

        Date date = new Date();
        String billCode = ZJBuzzUtils.generateOrderBillCode(TradeType.TRADE_WITH_DROW);
        String uuid = ZJBuzzUtils.generateUUID();
        TradeRecharge recharge = new TradeRecharge();
        recharge.setTradeRechargeUuid(uuid);
        recharge.setRechargeBillCode(billCode);
        recharge.setRechargeBillType(TradeType.TRADE_WITH_DROW);
        recharge.setUserUuid(userUuid);
        recharge.setUserPhone(MapParamUtils.getStringInMap(investorMap, "userPhone"));
        recharge.setAccountUuid(accountUuid);
        recharge.setAgencyAccountNo(MapParamUtils.getStringInMap(accountBaofooResult, "accountNo"));
        recharge.setRechargeAmount(new BigDecimal(amount + ""));
        recharge.setRechargeFee(BigDecimal.valueOf(PayMsg.FEE_PER));
        recharge.setRechargeFeeType(feeType);
        recharge.setBankAccountNo(bankUserCardNo);
        recharge.setRechargeStatus(TradeStatus.NEW);
        recharge.setPayMethod(PayMethod.SWIFT);
        recharge.setDeleteFlag((byte) 0);
        recharge.setCreateTime(date);
        recharge.setUpdateTime(date);
        recharge.setRechargeTime(date);
        recharge.setTransactionChannel(transactionChannel);
        if(StringUtils.isNotBlank(accountType) && AccountType.ACCOUNT_TYPE_FINANCIER.equals(accountType)){
            recharge.setAccountType(accountType);
        }
        //用来兼容一些老数据，
        if(StringUtils.isBlank(tradeOrderBillCodeExtend)){
            tradeOrderBillCodeExtend = billCode;
        }
        recharge.setTradeOrderBillCodeExtend(tradeOrderBillCodeExtend);
        recharge.setBelongMerchantNum(belongMerchantNum);
        LOGGER.info("创建取现订单，param:{}",JSONObject.toJSONString(recharge));
        tradeRechargeMapper.insert(recharge);

        return recharge;
    }

    @Override
    /**
     * 查询充值记录
     *
     * @param billCode 交易单编号
     * @return
     * @throws Exception
     */
    public TradeRecharge queryRechargeOrderByBillCode(String billCode) throws BusinessException {
        LOGGER.info("查询充值记录，param:{}",billCode);
        return tradeRechargeMapper.selectByBillCode(billCode);
    }

    /**
     * 执行充值操作
     *
     * @param billCode   充值单编号
     * @param amount     充值金额
     * @param feeTakenOn 手续费付费方式：1 平台，2 个人
     * @param feeAmount 手续费金额
     *@param time       充值时间
     * @param rechargeRemark     充值返回值
     * @param transactionChannel
     *
     * @return
     */
    @Override
    @Transactional(rollbackFor = {BusinessException.class, RuntimeException.class})
    public String executeRechargeOrder(String billCode, double amount, int feeTakenOn, double feeAmount, Date time, String rechargeRemark, String transactionChannel) throws BusinessException {
        LOGGER.info("获取订单信息：" + billCode);
        TradeRecharge rechargeOrder = tradeRechargeMapper.selectByBillCode(billCode);
        if (null == rechargeOrder) {
            LOGGER.error("cannot find recharge order, bill code = " + billCode);
            throw new BusinessException(TradeStatusMsg.NO_RECHARGE_BILL, TradeStatusMsg.NO_RECHARGE_BILL_MSG, true);
        }

        // 检查订单状态
        if (rechargeOrder.getRechargeStatus() == TradeStatus.SUCCESS) {
            LOGGER.error("recharge notify, bill code = {}, recharge status = {}", billCode, rechargeOrder.getRechargeStatus());
            return null;
        }

        // 核对金额，以回调通知金额为准
        double orderAmount = rechargeOrder.getRechargeAmount().doubleValue();
        if (orderAmount > amount || orderAmount < amount) {
            LOGGER.error("orderAmount=" + orderAmount + ", amount=" + amount);
        }
        Map rechargeParam = new HashMap();
        if(null != transactionChannel) {
            rechargeParam.put("transactionChannel", transactionChannel);
        }else{
            rechargeParam.put("transactionChannel", "");
        }

        //判断返回的充值金额、手续费等信息是否与订单一致。不一致回写
        Byte feeTakenOnByte = 0;
        if(feeTakenOn == RechargeType.PLANTFORM_PAY){
            feeTakenOnByte = RechargeType.PLANTFORM_PAY;
        }
        if(feeTakenOn == RechargeType.PERSON_PAY){
            feeTakenOnByte = RechargeType.PERSON_PAY;
        }
        rechargeOrder.setRechargeTime(time);
        rechargeOrder.setTransactionChannel(transactionChannel);
        Map<String, String> remark2 = new HashMap();
        String RechargeRemarkJsonString = JSONObject.toJSONString(remark2);
        rechargeOrder.setRechargeRemark(RechargeRemarkJsonString);

        if(feeTakenOnByte != rechargeOrder.getRechargeFeeType() || rechargeOrder.getRechargeFee().compareTo(new BigDecimal(feeAmount)) != 0 || rechargeOrder.getRechargeAmount().compareTo(new BigDecimal(amount)) != 0){
            rechargeOrder.setRechargeAmount(new BigDecimal(amount));
            rechargeOrder.setRechargeFee(new BigDecimal(feeAmount));
            rechargeOrder.setRechargeFeeType(feeTakenOnByte);
            LOGGER.info("回写充值订单内容！");
            tradeRechargeMapper.update(rechargeOrder);
        }

        // 更新账户余额和流水
        accountService.recharge(rechargeOrder);

        // 更新订单状态
        Map<String, String> remark = new HashMap();
        remark.put("baofoo_result", rechargeRemark);
        String jsonString = JSONObject.toJSONString(remark);
        rechargeOrder.setRechargeStatus(TradeStatus.SUCCESS);
        rechargeOrder.setRechargeRemark(jsonString);
        rechargeOrder.setRechargeTime(time);
        tradeRechargeMapper.updateByPrimaryKey(rechargeOrder);

        int ret = operationReportMapper.updateUserRechargeStatus(rechargeOrder.getUserUuid());
        LOGGER.info("更新User的充值状态：" + DataUtils.toString(rechargeOrder.getUserUuid()) + " " + ret);

        return "OK";
    }

    /**
     * 设置充值，并更新订单状态
     * 1. 用来记录宝付调用日志
     * 2. 用来判断当前操作是否失败或取消。则设置状态。
     * 3. 成功则等待宝付回调account.recharge（宝付充值成功回调接口）接口。
     *
     * @param billCode 充值单编号
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = {BusinessException.class, RuntimeException.class})
    public int updateRechargeOrder(String billCode, String request, Integer orderStatus) throws BusinessException {
        TradeRecharge rechargeOrder = tradeRechargeMapper.selectByBillCode(billCode);
        if (null == rechargeOrder) {
            LOGGER.error("cannot find recharge order, bill code = " + billCode);
            throw new BusinessException(TradeStatusMsg.NO_RECHARGE_BILL, TradeStatusMsg.NO_RECHARGE_BILL_MSG, true);
        }

        // 记录支付状态
        int rechargeStatus = payService.updateRecharge(billCode, request, orderStatus);

        if (rechargeOrder.getRechargeStatus() != TradeStatus.NEW) {
            LOGGER.error("recharge query, bill code = " + billCode + ", recharge status = " + rechargeOrder.getRechargeStatus());
            return rechargeOrder.getRechargeStatus();
        }

        if (orderStatus == RechargeStatusParamEnum.CANCEL.getParamStatus() ||
                orderStatus == RechargeStatusParamEnum.FAIL.getParamStatus()) {
            LOGGER.info("executeRechargeOrder recharge syn failed or cancel. billCode={}, orderStatus={}", billCode, orderStatus);
            rechargeOrder.setRechargeStatus(RechargeStatusParamEnum.getStatusByParamStatus(orderStatus).getDbStatus());
            tradeRechargeMapper.updateByPrimaryKey(rechargeOrder);
            return RechargeStatusParamEnum.getStatusByParamStatus(orderStatus).getDbStatus();
        }
        

        // 不再主动查询充值状态，返回的结果不能确认充值成功
        //return RechargeStatusParamEnum.getStatusByParamStatus(orderStatus).getDbStatus();
        return rechargeStatus;
    }



    /**
     * 获取交易单
     * @param orderUuid
     * @return
     * @throws BusinessException
     */
    @Override
    public Map getTradeOrder(String orderUuid) throws BusinessException {
        return tradeOrderMapper.get(orderUuid);
    }

    /**
     * 检查该投资者是否可以购买此新手标
     * @param userUuid
     * @return
     * @throws BusinessException
     */
    @Override
    public boolean checkNoviceProduct(String userUuid) throws BusinessException {
        return (!havaValidOrder(null, userUuid, null));
    }

    /**
     * 认购定期理财产品
     *
     * @param map:productUuid,userUuid,orderAmount,couponExtendCode,belongMerchantNum
     * @return
     * @throws BusinessException
     */
    @Override
    public ResponseResult invest(Map map) throws BusinessException {
        String productUuid = map.get("productUuid").toString();
        LOGGER.info("==== 定期产品认购开始:{} ====", productUuid);

        // 投资订单
        TradeOrder order = null;

        // 根据客户端每个请求的唯一ID判断是否为重新提交的订单
        String clientRequestID = MapParamUtils.getStringInMap(map, "uniqueIdentifier");
        List<Map> list= tradeOrderMapper.selectByUniqueIdentifier(clientRequestID);
        if(list.size() > 0) {
            Map tradeOrder = list.get(0);
            // 检查订单状态
            int orderStatus = Integer.parseInt(tradeOrder.get("orderStatus").toString());
            if (orderStatus <= BizDefine.ORDER_STATUS_APPLY) {
                // 继续没完成的订单
                order = JSON.parseObject(JSON.toJSONString(tradeOrder), TradeOrder.class);
                LOGGER.info("订单[{}]重新提交：{}", order.getOrderBillCode(), clientRequestID);
            } else {
                // 订单已完成
                LOGGER.info("订单已经完成：{}", clientRequestID);
                throw new BusinessException(TradeStatusMsg.PAID_ORDER, TradeStatusMsg.PAID_ORDER_MSG, true);
            }
        } else {
            // 创建新订单
            CreateOrderDTO createOrderDTO = JSON.parseObject(JSON.toJSONString(map), CreateOrderDTO.class);
            order = createOrder(createOrderDTO);
        }

        // 设置时间
        order.setPayedTime(new Date());

        // 设置支付处理中状态
        TradeOrderPayStatusDO orderPayStatusDO = new TradeOrderPayStatusDO();
        orderPayStatusDO.setOrderBillCode(order.getOrderBillCode());
        orderPayStatusDO.setOrderPayStatus(TradeOrderConstant.ORDER_PAY_STATUS_PENDING);
        int row = tradeOrderMapper.updateOrderPayPendingStatus(orderPayStatusDO);
        if (row <= 0) {
            throw new PayOrderException();
        }

        return payOrder(order);
    }

    /**
     * 支付订单
     *
     * @param order
     * @return
     * @throws BusinessException
     */
    private ResponseResult payOrder(TradeOrder order) throws BusinessException {

        ResponseResult responseResult = new ResponseResult();

        try {
            // 发订单失败事务消息（Prepared消息）
            OrderCancelMessage orderCancelMessage = new OrderCancelMessage();
            orderCancelMessage.setOrderBillCode(order.getOrderBillCode());
            orderCancelMessage.setProductUuid(order.getProductUuid());
            orderCancelMessage.setUserUuid(order.getUserUuid());
            orderCancelMessage.setAccountUuid(order.getAccountUuid());
            orderCancelMessage.setCouponExtendCode(order.getStrategyIds());
            orderCancelMessage.setOrderAmount(order.getOrderAmount());
            orderCancelMessage.setPaidAmount(order.getPaidAmount());
            orderCancelMessage.setPaySeq(order.getPaySeq());
            orderCancelTransactionProducer.send(orderCancelMessage, new LocalTransactionExecuter() {
                @Override
                public LocalTransactionState executeLocalTransactionBranch(Message msg, Object arg) {
                    try {
                        ResponseResult innerResult = investImpl(order);
                        responseResult.setCode(innerResult.getCode());
                        responseResult.setData(innerResult.getData());
                        responseResult.setMsg(innerResult.getMsg());
                        if (innerResult.isSuccessful()) {
                            LOGGER.info("内部事务：正常完成，回滚订单取消消息");
                            return LocalTransactionState.ROLLBACK_MESSAGE;
                        } else {
                            LOGGER.info("内部事务：出现异常，提交订单取消消息");
                            // 更新为失败状态，如果更新操作失败，通过PENDING状态超时解决
                            TradeOrderPayStatusDO orderPayStatusDO = new TradeOrderPayStatusDO();
                            orderPayStatusDO.setOrderBillCode(order.getOrderBillCode());
                            orderPayStatusDO.setOrderPayStatus(TradeOrderConstant.ORDER_PAY_STATUS_FAILED);
                            tradeOrderMapper.updateOrderPayFailedStatus(orderPayStatusDO);
                            return LocalTransactionState.COMMIT_MESSAGE;
                        }
                    } catch (Exception e) {
                        LOGGER.error("取消订单事务消息发送内部异常：{}", e.getMessage());
                        responseResult.setCode(ResponseCode.EXCEPTION);
                        responseResult.setMsg(e.getMessage());

                        // 现在不告诉MQ成功还是失败，等MQ主动查询
                        return LocalTransactionState.UNKNOW;
                    }
                }
            }, null);
        } catch (Exception e) {
            // 取消订单消息发不出去，直接返回异常
            LOGGER.error("取消订单事务消息发送异常：{}", e.getMessage());
            responseResult.setCode(ResponseCode.EXCEPTION);
            responseResult.setMsg(e.getMessage());
        }

        return responseResult;
    }

    /**
     * 缓存的募集方账户信息
     *
     */
    private Map<String, Long> issuerAccountMap = new ConcurrentHashMap<>();

    /**
     * 读取募集方账户信息
     *
     * @param product
     * @return
     * @throws BusinessException
     */
    private Long getIssuerAccountNo(Map product) throws BusinessException {
        // 空检查
        String issuerUuid = product.get("productIssuerUuid").toString();
        if (Strings.isNullOrEmpty(issuerUuid)) {
            // 没有发行人信息，不能购买
            LOGGER.error("没有读取到募集方用户信息");
            throw new BusinessException(TradeStatusMsg.NO_ISSUER_USER, TradeStatusMsg.NO_ISSUER_USER_TXT);
        }
        LOGGER.info("issuerUserUuid={}", issuerUuid);

        long payeeAccountNo = 0L;

        if (issuerAccountMap.containsKey(issuerUuid)) {
            payeeAccountNo = issuerAccountMap.get(issuerUuid);
        } else {
            Map<String, String> getAccountParam = new HashMap<>();
            getAccountParam.put("userUuid", issuerUuid);
            Map accountInfo = accountService.getWithFilter(getAccountParam);
            String payeeAccountUuid = accountInfo.get("accountUuid").toString();
            LOGGER.info("issuerAccountUuid={}", payeeAccountUuid);
            if (Strings.isNullOrEmpty(payeeAccountUuid)) {
                // 募集账户不存在，不能购买
                LOGGER.error("没有读取到募集方账户信息");
                //throw new ProductCannotBuyException();
                throw new BusinessException(TradeStatusMsg.NO_ISSUER_ACCOUNT, TradeStatusMsg.NO_ISSUER_ACCOUNT_TXT);
            }
            payeeAccountNo = getPayeeAccountNo(payeeAccountUuid, product.get("payeeAccountType").toString());
            issuerAccountMap.put(issuerUuid, payeeAccountNo);
        }

        LOGGER.info("issuerAccountNo={}", payeeAccountNo);
        return payeeAccountNo;
    }

    /**
     * 创建投资订单
     *
     * @param createOrderDTO
     * @return
     * @throws BusinessException
     */
    private TradeOrder createOrder(CreateOrderDTO createOrderDTO) throws BusinessException {

        // 根据用户uuid获取用户信息
        LOGGER.info("读取用户信息");
        Map user = getUser(createOrderDTO.getUserUuid());

        // 根据产品uuid获取定期产品信息
        LOGGER.info("读取产品信息");
        Map product = getProductInfo(createOrderDTO.getProductUuid());

        // 读取募集方账户信息
        // 2018/01/10 不再从product_fixed_income子表读取募集方账户信息，根据product主表的product_issuer_uuid读取账户信息
        LOGGER.info("读取募集方账户信息");
        Long payeeAccountNo = getIssuerAccountNo(product);

        // 读取账户信息
        LOGGER.info("读取投资人账户信息");
        Map<String, Object> accountMap = new HashMap<>();
        accountMap.put("userUuid", createOrderDTO.getUserUuid());
        accountMap.put("accountType", AccountType.ACCOUNT_TYPE_INVESTOR);
        accountMap.put("accountStatus", "1");
        accountMap.put("properties", "accountUuid$$accountType$$accountCashAmount$$accountNo$$bankCardInfo");
        Map account = accountBaofooMapper.getBaofooAndAccount(accountMap);
        if (account == null) {
            // 投资人账户不存在，不能购买
            LOGGER.error("没有读取到投资人账户信息");
//            throw new AccountUnavailableException();
            throw new BusinessException(TradeStatusMsg. NO_INVESTOR_ACCOUNT, TradeStatusMsg.NO_INVESTOR_ACCOUNT_TXT);
        }

        // 读取优惠券信息
        String couponExtendCode = createOrderDTO.getCouponExtendCode();
        CouponExtendRecordVO couponVO = null;
        if (!Strings.isNullOrEmpty(couponExtendCode)) {
            LOGGER.info("读取优惠券信息");
            couponVO = couponExtendRecordService.lstCouponExtendRecord(couponExtendCode);
        }

        // 检查是否符合购买条件
        LOGGER.info("检查是否符合购买条件");
        checkCondition(createOrderDTO, user, product, account, couponVO);

        // 生成订单
        LOGGER.info("生成订单");
        TradeOrder order = buildTradeOrder(createOrderDTO, account, user, product, couponVO, payeeAccountNo);

        // 写数据库
        LOGGER.info("写入订单到数据库");
        String jsonString = JSON.toJSONString(order);
        Map tradeOrder = JSON.parseObject(jsonString, new TypeReference<HashMap<String, Object>>(){});
        int row = tradeOrderMapper.insert(tradeOrder);
        if (row <= 0) {
            LOGGER.error("写入订单到数据库失败");
            throw new CreateOrderException();
        }

        return order;
    }

    /**
     * 修正交易信息
     *
     * @param product_uuid
     * @return
     * @throws Exception
     */
    @Override
    public void fixTradeOrder(String product_uuid) throws BusinessException {
        ProductFixedIncome productInfo = null;
//        if(product_uuid.equals("2fdde086d1794168a99669ad3b48392e")) {
//            productInfo = new ProductFixedIncome();
//            productInfo.setProductInterestDate(DateUtil.strToDate("2017-06-17"));
//            productInfo.setProductExpiringDate(DateUtil.strToDate("2019-06-01"));
//            short rateFormulaParam=365;
//            productInfo.setRateFormulaParam(rateFormulaParam);
//            productInfo.setAnnualInterestShow(new BigDecimal("0.9"));
//        }else {
            productInfo = getFixedIncomeProductById(product_uuid);
//        }

        LOGGER.info("产品起息日[{}]，产品到期日[{}]", productInfo.getProductInterestDate(), productInfo.getProductExpiringDate());
        int productPeriod = DateUtil.dateDiff(productInfo.getProductInterestDate());
        LOGGER.info("产品计息天数[{}]", productPeriod);
        int rateFormulaParam = productInfo.getRateFormulaParam().intValue();

        BigDecimal annualInterestShow = productInfo.getAnnualInterestShow();
        LOGGER.info("产品基础收益率=[{}]", annualInterestShow);

        if(productPeriod <= 0){
            return;
        }

        List<AmendTradeOrderVO> tradeOrderList = tradeOrderMapper.getOrderListByProductUuidEx(product_uuid);
        LOGGER.info("tradeOrderList.size: ", tradeOrderList.size());
        for(AmendTradeOrderVO order : tradeOrderList) {
            LOGGER.info("before: " + order.toString());

            LOGGER.info("修正产品加息天数：{}", order.getCouponInterestPeriod(), productPeriod);
            if(order.getCouponInterestPeriod()>productPeriod) {
                order.setCouponInterestPeriod(productPeriod);
            }

            // 用户总收益=订单金额×(产品固有收益率+产品加息收益率)×产品期限÷365+订单金额×加息券面值×加息时长÷365（截取两位小数）
            BigDecimal expectedProfitAmount = calculateTotalProfit(order.getProductAnnualInterestRate(), order.getCouponInterestYieldRate(), productPeriod,
                    order.getCouponInterestPeriod(), rateFormulaParam, order.getOrderAmount());
            order.setExpectedProfitAmount(expectedProfitAmount);
            LOGGER.info("用户总收益=[{}]", expectedProfitAmount);

            // 募集方兑付收益（产品基础收益率），两位小数，舍
            BigDecimal raisedProfitAmount = calculateRaisedProfit(annualInterestShow, productPeriod, rateFormulaParam, order.getOrderAmount());
            if (raisedProfitAmount.compareTo(expectedProfitAmount) > 0) {
                // 由于用户总收益是舍位的，募集方兑付收益是四舍五入的，所以当金额特别小时，可能出现募集方兑付收益大于用户总收益的情况（已失效）
                raisedProfitAmount = expectedProfitAmount;
            }
            order.setProfitAmount(raisedProfitAmount);
            LOGGER.info("募集方兑付收益=[{}]", raisedProfitAmount);

            // 平台兑付收益=用户总收益-募集方兑付收益
            BigDecimal marketingRateAmount = order.getExpectedProfitAmount().subtract(raisedProfitAmount);
            order.setMarketingRateAmount(marketingRateAmount);
            LOGGER.info("平台兑付收益=[{}]", marketingRateAmount);

            // 兑付总金额
            BigDecimal cashAmount = order.getOrderAmount().add(order.getExpectedProfitAmount());
            order.setCashAmount(cashAmount);
            LOGGER.info("兑付总金额=[{}]", cashAmount);

            LOGGER.info("after: " + order.toString());

            tradeOrderMapper.updateTradeOrderProfit(order.getExpectedProfitAmount().doubleValue(),
                    order.getProfitAmount().doubleValue(), order.getCouponInterestPeriod(), order.getMarketingRateAmount().doubleValue(), order.getCashAmount().doubleValue(), order.getOrderBillCode());
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void advanceProductEndFix(String productUuid) throws BusinessException {
        ProductFixedIncome productInfo = getFixedIncomeProductById(productUuid);

        LOGGER.info("产品起息日[{}]，产品到期日[{}]", productInfo.getProductInterestDate(), productInfo.getProductExpiringDate());
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        int productPeriod = 0;
        try {
            Date now = dateFormat.parse("2018-06-12 12:00:00");
            long from = productInfo.getProductInterestDate().getTime();
            long to = now.getTime();
            int day = (int) ((to - from)/(1000 * 60 * 60 * 24));
            productPeriod = day + 1;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        LOGGER.info("产品计息天数[{}]", productPeriod);

        BigDecimal fixAmount = BigDecimal.ZERO;

        List<AmendTradeOrderVO> tradeOrderList = tradeOrderMapper.getOrderListByProductUuidEx(productUuid);
        LOGGER.info("tradeOrderList.size: ", tradeOrderList.size());
        for(AmendTradeOrderVO order : tradeOrderList) {
            if(order.getCouponInterestYieldRate().compareTo(BigDecimal.ZERO) > 0) {

                // 加息券加息天数，0=全称加息
                int couponInterestPeriod = order.getCouponInterestPeriod();
                if (couponInterestPeriod == 0) {
                    // 全程加息
                    couponInterestPeriod = productInfo.getProductPeriod();
                }
                if (couponInterestPeriod > productPeriod) {
                    couponInterestPeriod = productPeriod;
                }

                LOGGER.info("产品加息天数[{}]", couponInterestPeriod);

                // 用户总收益=订单金额×(产品固有收益率+产品加息收益率)×产品期限÷365+订单金额×加息券面值×加息时长÷365（截取两位小数）
                int rateFormulaParam = productInfo.getRateFormulaParam().intValue();
                BigDecimal expectedProfitAmount = calculateTotalProfit(order.getProductAnnualInterestRate(), order.getCouponInterestYieldRate(), productPeriod,
                        couponInterestPeriod, rateFormulaParam, order.getOrderAmount());
                // 加息补足金额
                BigDecimal diff = expectedProfitAmount.subtract(order.getExpectedProfitAmount());
                LOGGER.info("加息金额差额[{}]", diff);

                if (diff.compareTo(BigDecimal.ZERO) > 0) {
                    fixAmount = fixAmount.add(diff);

                    LOGGER.info("before: " + order.toString());

                    order.setExpectedProfitAmount(expectedProfitAmount);
                    LOGGER.info("用户总收益=[{}]", expectedProfitAmount);

                    // 募集方兑付收益（产品基础收益率），两位小数，舍
                    BigDecimal raisedProfitAmount = order.getProfitAmount();
                    LOGGER.info("募集方兑付收益=[{}]", raisedProfitAmount);

                    // 平台兑付收益=用户总收益-募集方兑付收益
                    BigDecimal marketingRateAmount = order.getExpectedProfitAmount().subtract(raisedProfitAmount);
                    order.setMarketingRateAmount(marketingRateAmount);
                    LOGGER.info("平台兑付收益=[{}]", marketingRateAmount);

                    // 兑付总金额
                    BigDecimal cashAmount = order.getOrderAmount().add(order.getExpectedProfitAmount());
                    order.setCashAmount(cashAmount);
                    LOGGER.info("兑付总金额=[{}]", cashAmount);

                    LOGGER.info("after: " + order.toString());

                    tradeOrderMapper.fixProductClear(order);
                }
            }
        }

        LOGGER.info("产品[{}]累计加息金额差额[{}]", productUuid, fixAmount);
        if (fixAmount.compareTo(BigDecimal.ZERO) > 0) {
            TradePaymentSummaryVO summaryVO = new TradePaymentSummaryVO();
            summaryVO.setProductUuid(productUuid);
            summaryVO.setClearTotalAmount(fixAmount.doubleValue());
            summaryVO.setMarketingRateAmount(fixAmount.doubleValue());
            tradePaymentSummaryMapper.fixProductClear(summaryVO);
        }
    }

    /**
     * 创建订单
     *
     * @param createOrderDTO
     * @param account
     * @param user
     * @param product
     * @param couponVO
     * @param payeeAccountNo
     * @return
     * @throws BusinessException
     */
    private TradeOrder buildTradeOrder(CreateOrderDTO createOrderDTO, Map account, Map user, Map product,
                                       CouponExtendRecordVO couponVO, long payeeAccountNo) throws BusinessException {
        TradeOrder order = new TradeOrder();
        order.setOrderBillCode(ZJBuzzUtils.generateOrderBillCode(TradeType.TRADE_PRODUCT_ORDER));
        order.setUserUuid(MapParamUtils.getStringInMap(user, "userUuid"));
        order.setUserType(Short.parseShort(MapParamUtils.getStringInMap(user, "userType")));
        order.setInvestorOrganizationUuid(MapParamUtils.getStringInMap(user, "investorOrganizationUuid"));
        order.setUserName(MapParamUtils.getStringInMap(user, "investorRealName"));
        order.setUserPhone(MapParamUtils.getStringInMap(user, "mobile"));
        order.setAccountUuid(MapParamUtils.getStringInMap(account, "accountUuid"));
        order.setAccountNo(MapParamUtils.getStringInMap(account, "accountNo"));
        String channel = getTransactionChannel(createOrderDTO.getCallSystemID());
        order.setTransactionChannel(channel);
        order.setProductID(MapParamUtils.getLongInMap(product, "productID"));
        order.setProductUuid(MapParamUtils.getStringInMap(product, "productUuid"));
        order.setProductCode(MapParamUtils.getStringInMap(product, "productCode"));
        order.setProductAbbrName(MapParamUtils.getStringInMap(product, "productName"));
        order.setProductAnnualInterestRate(MapParamUtils.getBigDecimalInMap(product, "annualInterestRate"));
        order.setProductPeriodType(MapParamUtils.getStringInMap(product, "productPeriodType"));
        order.setProductPeriod(MapParamUtils.getIntInMap(product, "productPeriod"));
        if (product.get("productInterestDate") != null) {
            order.setProductInterestDate(DateUtil.convertDate2Int(product.get("productInterestDate").toString()));
        }
        if (product.get("productExpiringDate") != null) {
            order.setProductExpiringDate(DateUtil.convertDate2Int(product.get("productExpiringDate").toString()));
        }
        if (product.get("productPaymentDate") != null) {
            order.setProductPaymentDate(DateUtil.convertDate2Int(product.get("productPaymentDate").toString()));
        }
        order.setOrderAmount(createOrderDTO.getOrderAmount());
        order.setOrderShare(createOrderDTO.getOrderAmount());
        order.setBelongMerchantNum(createOrderDTO.getBelongMerchantNum());
        order.setUniqueIdentifier(createOrderDTO.getUniqueIdentifier());
        order.setStrategyIds(createOrderDTO.getCouponExtendCode());
        order.setPaySeq(0);
        order.setOrderStatus(new Byte("1"));
        order.setOrderPayStatus(TradeOrderConstant.ORDER_PAY_STATUS_UNPAID);
        // 设置募集方账户信息
        order.setPayeeAccountNo(payeeAccountNo);
        // 渠道结佣标识
        order.setChannelCommissionFlag(createOrderDTO.getChannelCommissionFlag());

        // 新手标
        String productLabel = MapParamUtils.getStringInMap(product, "productLabel");
        if (ProductFixedIncome.isNoviceLabel(productLabel)) {
            order.setProductRookieFlag(1);
        } else {
            order.setProductRookieFlag(0);
        }

        // 订单金额，截取两位小数
        BigDecimal orderAmount = createOrderDTO.getOrderAmount();
        orderAmount = orderAmount.setScale(2, BigDecimal.ROUND_DOWN);
        LOGGER.info("订单金额=[{}]", orderAmount);

        // 产品基础收益率（募集方承担）
        BigDecimal annualInterestShow = MapParamUtils.getBigDecimalInMap(product, "annualInterestShow");
        LOGGER.info("产品基础收益率=[{}]", annualInterestShow);

        // 产品加息收益率（平台承担）
        BigDecimal increaseInterestRate =  MapParamUtils.getBigDecimalInMap(product, "increaseInterestRate");
        LOGGER.info("产品加息收益率=[{}]", increaseInterestRate);

        // 产品累计收益率=产品基础收益率+产品加息收益率
        BigDecimal annualInterestRate = MapParamUtils.getBigDecimalInMap(product, "annualInterestRate");
        LOGGER.info("产品累计收益率=[{}]", annualInterestRate);

        // 产品期限（单位：天）
        int productPeriod = MapParamUtils.getIntInMap(product, "productPeriod");

        // 一年按多少天计算收益（默认365天）
        int rateFormulaParam = MapParamUtils.getIntInMap(product, "rateFormulaParam");

        // 营销金额（订单金额-营销金额=实付金额）
        BigDecimal marketingAmount = BigDecimal.ZERO;

        // 加息券收益率
        BigDecimal couponInterestYieldRate = BigDecimal.ZERO;

        // 加息券加息天数
        Integer couponInterestPeriod = 0;

        // 优惠券处理
        if(null != couponVO) {
            if(couponVO.getCouponType() == CouponConstant.TYPE_SUB_CASH) {
                // 处理现金券，营销金额=现金券面值
                marketingAmount = couponVO.getCouponFaceValue();
            }else if(couponVO.getCouponType() == CouponConstant.TYPE_ADD_PROFIT) {
                // 处理加息券
                couponInterestYieldRate = couponVO.getCouponInterestYieldRate();
                if (couponVO.getCouponInterestYieldType().intValue() == 1) {
                    // 1-有加息时长
                    couponInterestPeriod = couponVO.getCouponInterestYieldPeriod();
                    if (couponInterestPeriod > productPeriod) {
                        // 加息时长不能大于产品周期
                        couponInterestPeriod = productPeriod;
                    }
                    if (couponInterestPeriod < 1) {
                        // 非全程加息情况下,最小值为1
                        couponInterestPeriod = 1;
                    }
                } else {
                    // 0-全程加息
                    couponInterestPeriod = productPeriod;
                }
            }
        }

        // 营销金额，两位小数，舍
        marketingAmount = marketingAmount.setScale(2, BigDecimal.ROUND_DOWN);
        order.setMarketingAmount(marketingAmount);
        LOGGER.info("营销金额=[{}]", marketingAmount);

        // 待支付金额=订单金额-营销金额
        BigDecimal paidAmount = createOrderDTO.getOrderAmount().subtract(order.getMarketingAmount());
        order.setPaidAmount(paidAmount);
        LOGGER.info("待支付金额=[{}]", paidAmount);

        // 优惠券加息收益率
        order.setCouponInterestYieldRate(couponInterestYieldRate);
        LOGGER.info("优惠券加息收益率=[{}]", couponInterestYieldRate);

        // 优惠券加息天数
        order.setCouponInterestPeriod(couponInterestPeriod);
        LOGGER.info("优惠券加息天数=[{}]", couponInterestPeriod);

        // 产品加息收益率
        BigDecimal productIncreaseInterest = increaseInterestRate.add(couponInterestYieldRate);
        productIncreaseInterest = productIncreaseInterest.setScale(6, BigDecimal.ROUND_DOWN);
        order.setProductIncreaseInterestRate(productIncreaseInterest);
        LOGGER.info("产品加息收益率=[{}]", productIncreaseInterest);

        // 用户总收益=订单金额×(产品固有收益率+产品加息收益率)×产品期限÷365+订单金额×加息券面值×加息时长÷365（截取两位小数）
        BigDecimal expectedProfitAmount = calculateTotalProfit(annualInterestRate, couponInterestYieldRate, productPeriod,
                couponInterestPeriod, rateFormulaParam, orderAmount);
        order.setExpectedProfitAmount(expectedProfitAmount);
        LOGGER.info("用户总收益=[{}]", expectedProfitAmount);

        // 募集方兑付收益（产品基础收益率），两位小数，舍
        BigDecimal raisedProfitAmount = calculateRaisedProfit(annualInterestShow, productPeriod, rateFormulaParam, orderAmount);
        if (raisedProfitAmount.compareTo(expectedProfitAmount) > 0) {
            // 由于用户总收益是舍位的，募集方兑付收益是四舍五入的，所以当金额特别小时，可能出现募集方兑付收益大于用户总收益的情况（已失效）
            raisedProfitAmount = expectedProfitAmount;
        }
        order.setProfitAmount(raisedProfitAmount);
        LOGGER.info("募集方兑付收益=[{}]", raisedProfitAmount);

        // 平台兑付收益=用户总收益-募集方兑付收益
        BigDecimal marketingRateAmount = order.getExpectedProfitAmount().subtract(raisedProfitAmount);
        order.setMarketingRateAmount(marketingRateAmount);
        LOGGER.info("平台兑付收益=[{}]", marketingRateAmount);

        // 兑付总金额
        BigDecimal cashAmount = createOrderDTO.getOrderAmount().add(order.getExpectedProfitAmount());
        order.setCashAmount(cashAmount);
        LOGGER.info("兑付总金额=[{}]", cashAmount);

        return order;
    }

    /**
     * 计算预期收益
     *
     * @param annualInterestRate 产品收益率（基础收益率+加息收益率）
     * @param increaseInterestRate 加息券收益率
     * @param productPeriod 产品期限
     * @param couponInterestPeriod 加息券加息时长
     * @param rateFormulaParam 365
     * @param amount 订单金额
     * @return
     * @throws BusinessException
     */
    public BigDecimal calculateTotalProfit(BigDecimal annualInterestRate, BigDecimal increaseInterestRate, int productPeriod,
                                       int couponInterestPeriod, int rateFormulaParam, BigDecimal amount) throws BusinessException {
        BigDecimal period = new BigDecimal(productPeriod);
        rateFormulaParam = (rateFormulaParam > 0) ? rateFormulaParam : RATEFORMULAPARAM;
        BigDecimal basePeriod = new BigDecimal(rateFormulaParam);

        // 产品收益=订单金额×(产品固有收益率+产品加息收益率)×产品期限÷365
        BigDecimal profitBase = amount.multiply(annualInterestRate).multiply(period).divide(basePeriod, 6);

        // 加息券收益=订单金额×加息券面值×加息时长÷365
        BigDecimal profitAdd = BigDecimal.ZERO;
        if (increaseInterestRate.compareTo(BigDecimal.ZERO) > 0) {
            BigDecimal addPeriod = new BigDecimal(couponInterestPeriod);
            profitAdd = amount.multiply(increaseInterestRate).multiply(addPeriod).divide(basePeriod, 6);
        }

        // 用户总收益=产品收益+加息券收益
        BigDecimal profitTotal = profitBase.add(profitAdd);

        // 保留两位小数，舍去
        profitTotal = profitTotal.setScale(2, BigDecimal.ROUND_DOWN);
        return profitTotal;
    }

    /**
     * 计算募集方应付收益
     *
     * @param annualInterestShow
     * @param productPeriod
     * @param rateFormulaParam
     * @param amount
     * @return
     */
    private BigDecimal calculateRaisedProfit(BigDecimal annualInterestShow, int productPeriod, int rateFormulaParam,
                                             BigDecimal amount) {
        rateFormulaParam = (rateFormulaParam > 0) ? rateFormulaParam : RATEFORMULAPARAM;
        BigDecimal profitBase = annualInterestShow.multiply(new BigDecimal(productPeriod));
        profitBase = profitBase.multiply(amount);
        BigDecimal raisedProfitAmount = profitBase.divide(new BigDecimal(rateFormulaParam), 6);
        // 舍
        raisedProfitAmount = raisedProfitAmount.setScale(2, BigDecimal.ROUND_DOWN);
        return raisedProfitAmount;
    }

    /**
     * 投资的真正实现
     *
     * @param order
     * @return
     * @throws BusinessException
     */
    private ResponseResult investImpl(TradeOrder order) throws BusinessException {
        // 返回结果
        ResponseResult responseResult = new ResponseResult();

        try {
            String jsonString = JSON.toJSONString(order);
            OrderPaidMessage orderPaidMessage = JSON.parseObject(jsonString, OrderPaidMessage.class);
            orderPaidTransactionProducer.send(orderPaidMessage, new LocalTransactionExecuter() {
                @Override
                public LocalTransactionState executeLocalTransactionBranch(Message message, Object o) {
                    try {
                        ResponseResult result = tradeTransactionService.invest(order);
                        responseResult.setCode(result.getCode());
                        responseResult.setMsg(result.getMsg());
                        responseResult.setData(order);
                        LOGGER.info("事务：投资操作成功");
                        return LocalTransactionState.COMMIT_MESSAGE;
                    } catch (BusinessException be) {
                        responseResult.setCode(be.getErrorCode());
                        responseResult.setMsg(be.getMessage());
                        LOGGER.error("事务：投资操作失败：{}", be.getMessage());
                        return LocalTransactionState.ROLLBACK_MESSAGE;
                    } catch (Exception e) {
                        responseResult.setCode(ResponseCode.EXCEPTION);
                        responseResult.setMsg(e.getMessage());
                        LOGGER.error("事务：投资操作异常：{}", e.getMessage());
                        return LocalTransactionState.UNKNOW;
                    }
                }
            }, null);
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            responseResult.setCode(ResponseCode.EXCEPTION);
            responseResult.setMsg(e.getMessage());
            LOGGER.error("调用投资操作异常：{}", e.getMessage());
            return responseResult;
        }

        return responseResult;
    }

    @Override
    public ResponseResult recoverWithdrawTimer() throws BusinessException {
        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        Calendar cal=Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR,-10);
        Map params = new HashMap();
        params.put("rechargeStatus", 0);
        params.put("rechargeBillType", "WDX");
        params.put("rechargeTimeBegin", cal.getTime());
        params.put("rechargeTimeTo", new Date());
        List<Map> withdrawList = tradeRechargeMapper.getList(params);
        if (CollectionUtils.isEmpty(withdrawList)) {
            LOGGER.info("recoverWithdrawTimer new list is empty, noting need todo.");
            return responseResult;
        }
        LOGGER.info("recoverWithdrawTimer new list size={}.", withdrawList.size());
        for (Map order : withdrawList) {
            String rechargeBillCode = MapParamUtils.getStringInMap(order, "rechargeBillCode");
            try {
                LOGGER.info("recoverWithdrawTimer is recovering order. rechargeBillCode={}", rechargeBillCode);
                recoverWithdraw(rechargeBillCode);
                LOGGER.info("recoverWithdrawTimerSuccess order. rechargeBillCode={}", rechargeBillCode);
            } catch (Exception e) {
                LOGGER.error("recoverWithdrawTimer recovering order error. rechargeBillCode={}", rechargeBillCode, e);
            }
        }
        return responseResult;
    }

    @Override
    public ResponseResult recoverWithdraw(String orderBillCode) throws BusinessException {
        ResponseResult responseResult = new ResponseResult();
        LOGGER.info("query withdraw. orderBillCode={}", orderBillCode);

        ResponseResult result = payService.query(IPayService.TYPE_WITHDRAW, orderBillCode);
        if (!result.isSuccessful()) {
            responseResult.setCode(result.getCode());
            responseResult.setMsg(result.getMsg());
            return responseResult;
        }

        Map<String, Object> data = (Map<String, Object>) result.getData();
        if (null == data) {
            responseResult.setCode(ResponseCode.EXCEPTION);
            responseResult.setMsg("data is null.");
            return responseResult;
        }

        String state = data.get("state").toString();
        String queryResult = data.get("result").toString();
        if (BaoFooCode.WITHDRAW_SUCCESS.equals(state)) {
            LOGGER.info("withdraw success. orderBillCode={}", orderBillCode);
            payService.updatePayLog(orderBillCode, PayStatus.SUCCESSFUL, queryResult);
            tradeService.executeBill(orderBillCode);
        } else if (BaoFooCode.WITHDRAW_ERROR.equals(state)) {
            payService.updatePayLog(orderBillCode, PayStatus.FAILED, queryResult);
            tradeService.cancelExecuteBill(orderBillCode,responseResult.getMsg());
            LOGGER.warn("withdraw failed. orderBillCode={}, response={}", orderBillCode, responseResult);
        } else {
            LOGGER.info("withdraw state. state={}", state);
            responseResult.setCode(ResponseCode.EXCEPTION);
            responseResult.setMsg(state);
            return responseResult;
        }

        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        return responseResult;
    }

    @Override
    public BigDecimal getTotalInvestAmount(Map map) throws BusinessException {
        return tradeOrderMapper.getTotalInvestAmount(map);
    }

    /**
     * 创建提现单
     *
     * @param params
     * @return
     */
    @Override
    @Transactional(rollbackFor = {BusinessException.class, RuntimeException.class, Exception.class})
    public TradeRecharge createRechargeOrder(Map params) throws BusinessException {
        String userUuid = MapParamUtils.getStringInMap(params, "userUuid");
        String accountType = MapParamUtils.getStringInMap(params, "accountType");
        String userPayPassword = MapParamUtils.getStringInMap(params, "userPayPassword");

        Map baofooParams = new HashMap();
        baofooParams.put("userUuid", userUuid);
        LOGGER.info("获取宝付信息，param:{}",JSONObject.toJSONString(baofooParams));
        Map baofooMap = accountBaofooMapper.getBaofooAndAccount(baofooParams);

        //判断支付密码是否正确
        //对这个逻辑做了修改：如没有交易密码，则不校验。因为对于渠道方的交易，是还款时自动提现的，这种场景下是没有交易密码的。张以杰 20170627
        if(DataUtils.isNotEmpty(userPayPassword)) {
            LOGGER.info("检验交易密码");
            investorRemoteService.checkPayPassword(userUuid, userPayPassword);
        }

        //检查提现金额是否满足要求(基本检查)
        LOGGER.info("检查提现金额是否满足要求(基本检查)");
        checkAllowWithdraw(params);

        String accountUuid = MapParamUtils.getStringInMap(baofooMap, "accountUuid");
        String agencyAccountNo = MapParamUtils.getStringInMap(baofooMap, "accountNo");//MapParamUtils.getStringInMap(params, "agencyAccountNo");
        Double amount = MapParamUtils.getDoubleInMap(params, "rechargeAmount");
        LOGGER.info("获取宝付银行卡信息，param:{}",JSONObject.toJSONString(baofooParams));

        //获取谁来支付手续费
        FeeTypeResult ftr = getFeeType(params);
        LOGGER.info("手续费信息，{}", ftr);
        int feeType = ftr.getFeeType();
        Double fee = ftr.getAmount();//单笔手续费2元
        //创建提现单
        String transactionChannel = MapParamUtils.getStringInMap(params, "transactionChannel");
        String belongMerchantNum = MapParamUtils.getStringInMap(params, "belongMerchantNum");
        TradeRecharge tradeRecharge = this.createWithdrawOrder(accountUuid, amount, Byte.parseByte(feeType + ""),
                MapParamUtils.getStringInMap(params,"tradeOrderBillCodeExtend"), transactionChannel, accountType, belongMerchantNum);
        return tradeRecharge;
    }


    /**
     * 宝付提现
     * @param tradeRecharge
     * @return
     */
    @Override
    public ResponseResult baofooWithDraw(TradeRecharge tradeRecharge){
        //获取谁来支付手续费
        int feeType = tradeRecharge.getRechargeFeeType();
        ResponseResult responseResult = new ResponseResult();
        if (isOpenBaofooInterface) {
            try {
                String billCode = tradeRecharge.getRechargeBillCode();
                SimpleMessage msg = new SimpleMessage(billCode);
                payWithdrawTransactionProducer.send(msg, new LocalTransactionExecuter() {
                    @Override
                    public LocalTransactionState executeLocalTransactionBranch(Message message, Object o) {
                        try {
                            if (feeType == PayMsg.FEE_TOKEN_ON_PLATFORM) {
                                LOGGER.info("宝付提现，平台支付");
                            } else if (feeType == PayMsg.FEE_TOKEN_ON_PERSON) {
                                LOGGER.info("宝付提现，个人支付");
                            }

                            ResponseResult result = tradeTransactionService.successWithDraw(tradeRecharge);
                            if (result.isSuccessful()) {
                                // 提现接口调用成功
                                responseResult.setCode(ResponseCode.OK);
                                responseResult.setMsg(ResponseCode.OK_TEXT);
                                responseResult.setData(result.getData());
                                return LocalTransactionState.COMMIT_MESSAGE;
                            } else {
                                // 提现失败，非宝付错误，宝付错误会抛异常
                                tradeRecharge.setRechargeStatus(TradeStatus.FAILURE);
                                tradeRechargeMapper.update(tradeRecharge);
                                responseResult.setCode(result.getCode());
                                responseResult.setMsg(result.getMsg());
                                return LocalTransactionState.ROLLBACK_MESSAGE;
                            }
                        } catch (BusinessException e) {
                            // 提现失败，宝付错误
                            LOGGER.error("baofoo withdraw error.tradeRecharge={}",tradeRecharge, e);

                            // 如果出现了重复操作，并且上一个操作还没有完成，tradeTransactionService.successWithDraw抛出异常回滚账户操作
                            // 在这里做特殊处理，不报给前端
                            if (e.getErrorCode() == PayResponseCode.PENDING_OPERATION) {
                                // 重复执行，第一个还没执行完，第二个直接告诉他成功
                                responseResult.setCode(ResponseCode.OK);
                                responseResult.setMsg(ResponseCode.OK_TEXT);
                                return LocalTransactionState.ROLLBACK_MESSAGE;
                            } else {
                                // 真正的宝付错误，更改订单状态
                                try {
                                    payService.updatePayLog(billCode, PayStatus.FAILED, e.getMessage());
                                } catch (BusinessException e1) {
                                    LOGGER.error("updatePayLog error.", e1);
                                }

                                tradeRecharge.setRechargeStatus(TradeStatus.FAILURE);
                                Map<String, String> remark = new HashMap();
                                remark.put("baofoo_result", e.getMessage());
                                String jsonString = JSONObject.toJSONString(remark);
                                tradeRecharge.setRechargeRemark(jsonString);
                                tradeRechargeMapper.update(tradeRecharge);
                                responseResult.setCode(e.getErrorCode());
                                responseResult.setMsg(e.getMessage());
                                return LocalTransactionState.ROLLBACK_MESSAGE;
                            }
                        }
                    }
                }, null);
            } catch (Exception e) {
                LOGGER.error("with draw error.tradeRecharge={}",tradeRecharge, e);
                responseResult.setCode(ResponseCode.EXCEPTION);
                responseResult.setMsg(e.getMessage());
            }
        } else {
            responseResult.setCode(ResponseCode.OK);
            responseResult.setMsg(ResponseCode.OK_TEXT);
            responseResult.setData(tradeRecharge.getRechargeBillCode());
        }

        return responseResult;
    }


    @Override
    /**
     * 获取手续费支付方 和 支付金额
     * @param params 参数必填：userUuid,amount,accountType
     * @return
     */
    public FeeTypeResult getFeeType(Map params) {
        LOGGER.info("获取手续费支付方 和 支付金额");
        FeeTypeResult result = new FeeTypeResult();
        //企业用户手续费平台承担
        String callSystem = MapParamUtils.getStringInMap(params, "callSystemID");
        if ("1005".equals(callSystem)) {
            LOGGER.info("企业用户提现");
            result.setFeeType(PayMsg.FEE_TOKEN_ON_PLATFORM);
            result.setAmount(PayMsg.FEE_PER);
            return result;
        }else if("1111".equals(callSystem)){
            LOGGER.info("运营后台提现");
            result.setFeeType(PayMsg.FEE_TOKEN_ON_PLATFORM);
            result.setAmount(PayMsg.FEE_PER);
            return result;
        }

        //判断当月提现是否超过3笔
        Map transParams = new HashMap();
        String userUuid =  MapParamUtils.getStringInMap(params, "userUuid");
        List<String> userUuidList = Arrays.asList(userUuid.split("\\$\\$"));
        transParams.put("userUuidList", userUuidList);
        transParams.put("rechargeBillType", TradeType.TRADE_WITH_DROW);
        transParams.put("rechargeFeeType", PayMsg.FEE_TOKEN_ON_PLATFORM);
        transParams.put("rechargeStatus", TradeStatus.SUCCESS);
        transParams.put("rechargeTimeBegin", StringOrDate.getFirstDayOfMonth());

        RequestMapperConvert.initTradeRechargeParam(transParams);
        LOGGER.info("获取当月提现次数，param：{}",JSONObject.toJSONString(transParams));
        int num = tradeRechargeMapper.getCount(transParams);
        int feeType = num >= PayMsg.FREE_FEE_PER_MONTH ? PayMsg.FEE_TOKEN_ON_PERSON : PayMsg.FEE_TOKEN_ON_PLATFORM;
        result.setFeeType(feeType);
        result.setAmount(PayMsg.FEE_PER);
        LOGGER.info("当月提现次数：{}",JSONObject.toJSONString(result));
        return result;
    }

    @Override
    public FeeTypeResult getFeeType(String userUuid) {
        Map params = new HashMap();
        params.put("userUuid", userUuid);
        return getFeeType(params);
    }

    /**
     * 执行凭证（提现）（幂等）
     *
     * @param billCode 取现单号
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = {BusinessException.class, RuntimeException.class})
    public void executeBill(String billCode) throws BusinessException {
        //获取提现单
        TradeRecharge tr = tradeRechargeMapper.selectByBillCode(billCode);
        if (tr == null || TradeStatus.NEW != tr.getRechargeStatus()) {
            LOGGER.error("recharge billCode:" + billCode + ",is not new!");
            return;
        }
        //扣除冻结金额
        accountService.executeBill(tr, TradeStatus.SUCCESS,"");

    }

    /**
     * 取消执行凭证（提现）（幂等）
     *
     * @param billCode 取现单号
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = {BusinessException.class, RuntimeException.class})
    public void cancelExecuteBill(String billCode,String remark) throws BusinessException {
        //获取提现单

        TradeRecharge tr = tradeRechargeMapper.selectByBillCode(billCode);
        if (tr == null || TradeStatus.NEW != tr.getRechargeStatus()) {
            LOGGER.error("recharge billCode:" + billCode + ",is not new!");
            return;
        }
        //返还冻结金额
        accountService.executeBill(tr, TradeStatus.FAILURE,remark);

        tr.setRechargeStatus(TradeStatus.FAILURE);
        LOGGER.info("更新充值体现单，param：{}",JSONObject.toJSONString(tr));
        tradeRechargeMapper.update(tr);

    }


    /**
     * 固收产品认购(判断能否购买)
     *
     * @param map
     * @return
     * @throws BusinessException
     */
    @Override
    public void productSubscription(Map map) throws BusinessException {
        //根据用户uuid获取用户信息
        Map user = getUser(MapParamUtils.getStringInMap(map,"userUuid"));

        //根据产品uuid获取固收产品信息
        Map product = getProductInfo(MapParamUtils.getStringInMap(map,"productUuid"));
        if (product == null) {
            throw new BusinessException(ResponseCode.PARAM_ERROR, ResponseCode.PARAM_ERROR_TEXT, true);
        }

        // 检查用户是否符合购买条件
        // 不检查优惠券、账户余额，只检查产品状态、用户状态
        CreateOrderDTO createOrderDTO = JSON.parseObject(JSON.toJSONString(map), CreateOrderDTO.class);
        preCheckCondition(createOrderDTO, user, product);
    }

    /**
     * 下单前检查是否能够购买
     * <p>这个时候还没有选择优惠券和支付方式，所以不用检查优惠券和账户余额</p>
     *
     * @param createOrderDTO 认购信息
     * @param user 用户信息
     * @param product 产品信息
     * @return
     * @throws BusinessException
     */
    private boolean preCheckCondition(CreateOrderDTO createOrderDTO, Map user, Map product) throws BusinessException {

        // 产品相关检查
        checkProductCondition(createOrderDTO.getUserUuid(), product);

        // 用户相关检查
        checkUserCondition(createOrderDTO.getUserUuid(), user, product);

        // 金额相关检查
        checkAmountCondition(createOrderDTO.getUserUuid(), createOrderDTO.getOrderAmount(), product);

        return true;
    }

    /**
     * 获取用户信息
     *
     * @param userUuid
     * @return
     * @throws BusinessException
     */
    private Map getUser(String userUuid) throws BusinessException {
        Map params = new HashMap();
        params.put("properties", "userUuid$$userType$$investorOrganizationUuid$$investorMobile$$investorRealName" +
                "$$userStatus$$userVerifyStatus");
        ResponseResult result = userServiceConsumer.get(String.format(URL.URL_GET_USER, userUuid), params);
        if (result.isSuccessful()) {
            return (Map) result.getData();
        } else if (result.getCode() == 1109) {//用户被冻结
            throw new BusinessException(TradeStatusMsg.USER_STATUS_WRONG_CODE, TradeStatusMsg.USER_STATUS_WRONG_MSG, true);
        } else {
            LOGGER.error("get user info error:{},{}", result.getCode(), result.getMsg());
            throw new BusinessException(result.getCode(), result.getMsg(), true);
        }
    }

    /**
     * 获取产品信息
     *
     * @param productUuid
     * @return
     * @throws BusinessException
     */
    private Map getProductInfo(String productUuid) throws BusinessException {
        Map params = new HashMap();
        params.put("traceID", CacheUtil.getTraceID());
        ResponseResult result = productClient.getFixedIncome(productUuid, params);
        if (result.isSuccessful()) {
            return (Map) result.getData();
        } else {
            LOGGER.error("get product info error:{},{}", result.getCode(), result.getMsg());
            throw new BusinessException(result.getCode(), result.getMsg(), true);
        }
    }

    /**
     * 认购时检查是否符合购买条件
     *
     * @param createOrderDTO 认购信息
     * @param user 用户信息
     * @param product 产品信息
     * @param account 账户信息
     * @param couponVO 使用的优惠券信息
     * @return
     * @throws BusinessException
     */
    private boolean checkCondition(CreateOrderDTO createOrderDTO, Map user, Map product, Map account,
                                CouponExtendRecordVO couponVO) throws BusinessException {

        // 产品相关检查
        checkProductCondition(createOrderDTO.getUserUuid(), product);

        // 用户相关检查
        checkUserCondition(createOrderDTO.getUserUuid(), user, product);

        // 金额相关检查
        checkAmountCondition(createOrderDTO.getUserUuid(), createOrderDTO.getOrderAmount(), product);

        // 优惠券相关检查
        BigDecimal discount = checkCouponCondition(createOrderDTO.getOrderAmount(), couponVO);

        // 账户相关检查
        checkAccountCondition(createOrderDTO.getOrderAmount(), discount, account, product);

        return true;
    }

    /**
     * 认购前产品相关检查
     *
     * @param userUuid 用户UUID
     * @param product 认购的产品信息
     * @return
     * @throws BusinessException
     */
    private boolean checkProductCondition(String userUuid, Map product) throws BusinessException {

        // 产品已下架 产品已删除
        int productOnStatus = MapParamUtils.getIntInMap(product, "productOnStatus");
        int productDeleteFlag = MapParamUtils.getIntInMap(product, "deleteFlag");
        if (productOnStatus != BizDefine.PRODUCT_SHELVES_ON || productDeleteFlag == 1) {
            // 产品状态错误，不能购买
            LOGGER.error("productOnStatus=[{}] productDeleteFlag=[{}] 产品状态错误", productOnStatus, productDeleteFlag);
            throw new ProductCannotBuyException();
        }

        // 产品已募集完成
        int productStatus = MapParamUtils.getIntInMap(product, "productStatus");
        if (productStatus != BizDefine.PRODUCT_STATUS_RAISE) {
            // 产品状态错误，不能购买
            LOGGER.error("productStatus=[{}] 产品募集状态错误", productStatus);
            throw new ProductStatusException();
        }

        // 新手标检查，通过是否有订单检查
        String productLabel = MapParamUtils.getStringInMap(product, "productLabel");
        if (ProductFixedIncome.isNoviceLabel(productLabel)) {
            int orderCount = tradeOrderMapper.getOrderCountByUser(userUuid);
            if (orderCount > 0) {
                // 已经有订单，不能再买新手标
                LOGGER.error("userUuid=[{}] orderCount=[{}] 不能买新手标", userUuid, orderCount);
                throw new BusinessException(TradeStatusMsg.TRADE_NOVICE_LABEL_CHECK_FAIL, TradeStatusMsg.TRADE_NOVICE_LABEL_CHECK_FAIL_MSG, true);
            }
        }

        return true;
    }

    /**
     * 认购前用户相关检查
        * @param userUuid 用户UUID
     * @param user 用户信息
     * @param product 认购产品信息
     * @return
     * @throws BusinessException
     */
    private boolean checkUserCondition(String userUuid, Map user, Map product) throws BusinessException {

        // 达人产品判断
        int vipFlag = MapParamUtils.getIntInMap(product, "vipFlag");
        int investorType = MapParamUtils.getIntInMap(user, "investorType");
        if (vipFlag == 1 && investorType != InvestorType.FINANCIAL_PLANNER) {
            // 达人标检查失败
            LOGGER.error("userUuid=[{}] investorType=[{}] 不能买达人标", userUuid, investorType);
            throw new VIPCheckFailException();
        }

        // 用户开户/绑卡状态
        int userVerifyStatus = MapParamUtils.getIntInMap(user, "userVerifyStatus");
        if (userVerifyStatus != 9) {
            // 用户状态检查失败
            LOGGER.error("userUuid=[{}] userVerifyStatus=[{}] 没有完成开户绑卡", userUuid, userVerifyStatus);
            throw new UserVerifyStatusException();
        }

        return true;
    }

    /**
     * 认购前金额相关检查
     *
     * @param amount 认购金额
     * @param product 认购产品信息
     * @return
     * @throws BusinessException
     */
    private boolean checkAmountCondition(String userUuid, BigDecimal amount, Map product) throws BusinessException {

        // 认购金额 < 起投金额
        BigDecimal minInvestment = MapParamUtils.getBigDecimalInMap(product, "productMinInvestment");
        if (amount.compareTo(minInvestment) < 0) {
            LOGGER.error("认购金额[{}] < 起投金额[{}]", amount, minInvestment);
            throw new ProductMinInvestmentException();
        }

        // 认购金额不满足递增金额规则
        double interval = MapParamUtils.getDoubleInMap(product, "investmentInterval");
        if (amount.subtract(minInvestment).doubleValue() %  interval != 0) {
            LOGGER.error("认购金额[{}]不满足递增[{}]规则", amount, interval);
            throw new ProductInvestmentIntervalException();
        }

        // 认购金额 > 剩余可投金额
        BigDecimal scale = MapParamUtils.getBigDecimalInMap(product, "productScale");
        BigDecimal accumulation = MapParamUtils.getBigDecimalInMap(product, "productAccumulation");
        BigDecimal manual = MapParamUtils.getBigDecimalInMap(product, "productManual");
        BigDecimal available = scale.subtract(accumulation).subtract(manual);
        if (amount.compareTo(available) > 0) {
            LOGGER.error("认购金额[{}]大于产品剩余可募集金额[{}]", amount, available);
            throw new ProductInvestmentBeyondException();
        }

        // 认购金额 > 最大投资金额
        BigDecimal maxInvestment = MapParamUtils.getBigDecimalInMap(product, "productMaxInvestment");
        if (null != maxInvestment && maxInvestment.compareTo(BigDecimal.ZERO) > 0) {
            // 可以不设置最大投资金额
            // 获取用户在该产品的总投资金额
            Map<String, Object> map = new HashMap<>();
            map.put("orderStatusList", new Integer[] { BizDefine.ORDER_STATUS_CONFIRM });
            map.put("userUuid", userUuid);
            map.put("productUuid", MapParamUtils.getStringInMap(product, "productUuid"));
            BigDecimal totalInvestment = getTotalInvestAmount(map);
            if (amount.add(totalInvestment).compareTo(maxInvestment) > 0) {
                LOGGER.error("认购金额[{}] + 已投金额[{}] > 产品最大投资金额[{}]", amount, totalInvestment, maxInvestment);
                throw new ProductMaxInvestmentException();
            }
        }

        return true;
    }

    /**
     * 认购前优惠券相关检查
     *
     * @param amount 认购金额
     * @param couponVO 使用的优惠券信息
     * @return 折扣金额（使用优惠券抵扣的金额）
     * @throws BusinessException
     */
    private BigDecimal checkCouponCondition(BigDecimal amount, CouponExtendRecordVO couponVO) throws BusinessException {
        BigDecimal discount = new BigDecimal(0);
        if (null != couponVO) {
            // 检查优惠券状态
            if (couponVO.getCouponStatus() != CouponConstant.STATUS_INIT) {
                LOGGER.error("优惠券[{}]状态异常[{}]", couponVO.getCouponExtendCode(), couponVO.getCouponStatus());
                throw new CouponStatusException();
            }

            // 检查优惠券是否过期
            long now = System.currentTimeMillis();
            if (now < couponVO.getValidStartTime().getTime() || now > couponVO.getValidEndTime().getTime()) {
                LOGGER.error("优惠券[{}]已经过期", couponVO.getCouponExtendCode());
                throw new CouponExpiredException();
            }

            // 计算现金券面值
            if (couponVO.getCouponType() == CouponConstant.TYPE_SUB_CASH) {
                discount = couponVO.getCouponFaceValue();
                LOGGER.info("折扣金额=[{}]", discount);
            }

            // 折扣金额不能大于认购金额
            if (discount.compareTo(amount) > 0) {
                LOGGER.error("折扣金额[{}]已经大于认购金额[{}]", discount, amount);
                throw new CouponValueException();
            }

            // 这里就不检查产品了，使用时检查
        }

        return discount;
    }

    /**
     * 认购前账户相关检查
     *
     * @param amount 认购金额
     * @param discount 折扣金额
     * @param account 账户信息
     * @param product 产品信息
     * @return
     * @throws BusinessException
     */
    private boolean checkAccountCondition(BigDecimal amount, BigDecimal discount, Map account, Map product) throws BusinessException {

        // 判断账户余额是否充足
        BigDecimal accountCashAmount = MapParamUtils.getBigDecimalInMap(account, "accountCashAmount");
        BigDecimal paidAmount = amount.subtract(discount);
        if (accountCashAmount.compareTo(paidAmount) < 0) {
            Map<String, Object> info = new HashMap();
            info.put("bankCardInfo", account.get("bankCardInfo"));
            info.put("accountCashAmount", account.get("accountCashAmount"));
            info.put("productName", product.get("productName"));
            info.put("annualInterestRate", product.get("annualInterestRate"));
            LOGGER.error("账户余额[{}]小于待支付金额[{}]", accountCashAmount, paidAmount);
            throw new AccountBalanceException(info);
        }

        return true;
    }

    /**
     * 获取交易渠道
     *
     * @param callSystemID
     * @return
     */
    private String getTransactionChannel(String callSystemID) {
        switch (callSystemID) {
            case "1001":
                return "1";//IOS
            case "1002":
                return "2";//Andoird
            case "1003":
                return "3";//weixin
            default:
                return "0";//其他
        }
    }


    /**
     * 检查提现金额是否满足要求(基本检查)
     * @param params
     * @throws BusinessException
     */
    private void checkAllowWithdraw(Map params) throws BusinessException {

        LOGGER.info("检查提现金额是否满足要求(基本检查)，param:{}",JSONObject.toJSONString(params));

        String userUuid = MapParamUtils.getStringInMap(params, "userUuid");
        String accountType = MapParamUtils.getStringInMap(params, "accountType");

        Map userMap = getUser(userUuid);
        if(userMap != null && MapParamUtils.getByteInMap(userMap,"userVerifyStatus") < UserVerifyStatus.USER_BIND_CARD_SUCCESS.getStatus() ){
            throw new BusinessException(TradeStatusMsg.ACCOUNT_NOT_EXIST, TradeStatusMsg.ACCOUNT_NOT_EXIST_MSG, true);
        }

        //提现金额是正数
        BigDecimal rechargeAmount = MapParamUtils.getBigDecimalInMap(params, "rechargeAmount");
        LOGGER.info("提现金额={}", rechargeAmount.doubleValue());
        if (rechargeAmount.doubleValue() <= 0) {
            throw new BusinessException(TradeStatusMsg.WITHDRAW_MUST_POSITIVE_INTEGER_CODE, TradeStatusMsg.WITHDRAW_MUST_POSITIVE_INTEGER, true);
        }

        //个人用户单笔 50万
        if (AccountType.ACCOUNT_TYPE_INVESTOR.equals(MapParamUtils.getStringInMap(params, "accountType")) && rechargeAmount.doubleValue() > 500000) {
            throw new BusinessException(TradeStatusMsg.OUT_OF_WITHDRAW_LIMIT_CODE, TradeStatusMsg.OUT_OF_WITHDRAW_LIMIT, true);
        } else if (AccountType.ACCOUNT_TYPE_FINANCIER.equals(MapParamUtils.getStringInMap(params, "accountType")) && rechargeAmount.doubleValue() > 2000000) {//商户单笔 200万
            throw new BusinessException(TradeStatusMsg.OUT_OF_WITHDRAW_LIMIT_CODE, TradeStatusMsg.OUT_OF_WITHDRAW_LIMIT, true);
        }

        Map accountPersonParams = new HashMap();
        accountPersonParams.put("userUuid", userUuid);
        if (StringUtils.isNotBlank(accountType)) {
            accountPersonParams.put("accountType", accountType);
        }
        Map accountMap = accountBaofooMapper.getBaofooAndAccount(accountPersonParams);

        BigDecimal accountCashAmount = MapParamUtils.getBigDecimalInMap(accountMap, "accountCashAmount");
        LOGGER.info("账户可提现余额={}", accountCashAmount.doubleValue());

        //获取手续费支付方 ,1 平台支付费用  2 个人支付费用
        FeeTypeResult ftr = getFeeType(params);
        int feeType = ftr.getFeeType();
        Double feePer = ftr.getAmount();//单笔手续费2元

        BigDecimal feeAmount = new BigDecimal(feePer.doubleValue());
        LOGGER.info("手续费={}", feeAmount.doubleValue());

        //如果是个人支付，检查个人账户是否满足手续费金额
        if (feeType == PayMsg.FEE_TOKEN_ON_PERSON) {
            LOGGER.info("手续费支付类型是：个人支付");
            //提现金额是否大于可用金额
            LOGGER.info("rechargeAmount is {}", MapParamUtils.getDoubleInMap(params, "rechargeAmount"));
            LOGGER.info("feePer is {}", feePer);
            LOGGER.info("accountCashAmount is {}", MapParamUtils.getDoubleInMap(accountMap, "accountCashAmount"));
            LOGGER.info("flag is {}", MapParamUtils.getDoubleInMap(params, "rechargeAmount") + feePer > MapParamUtils.getDoubleInMap(accountMap, "accountCashAmount"));

            if (MapParamUtils.getDoubleInMap(params, "rechargeAmount") + feePer > MapParamUtils.getDoubleInMap(accountMap, "accountCashAmount")) {
                throw new BusinessException(TradeStatusMsg.OUT_OF_WITHDRAW_LIMIT_CODE, TradeStatusMsg.OUT_OF_WITHDRAW_LIMIT, true);
            }
        } else {//如果是平台支付，检查平台清算账户是否有足够金额
            LOGGER.info("手续费支付类型是：平台支付");
            //提现金额是否大于可用金额
            BigDecimal platformCashAmount = accountService.getPlatformAccountBalance();
            LOGGER.info("平台结算账户余额={}", platformCashAmount);

            if (feePer > platformCashAmount.doubleValue()) {
                LOGGER.warn("手续费>平台结算账户余额");
                throw new BusinessException(TradeStatusMsg.OUT_OF_PLATFORM_SETTLEMENT_LIMIT_CODE, TradeStatusMsg.OUT_OF_PLATFORM_SETTLEMENT_LIMIT, true);
            }

            //提现金额是否大于可用金额
            if (rechargeAmount.doubleValue() > accountCashAmount.doubleValue()) {
                LOGGER.warn("提现金额>账户可提现余额");
                throw new BusinessException(TradeStatusMsg.WITHDRAW_MORE_CASH_AMOUNT_CODE, TradeStatusMsg.WITHDRAW_MORE_CASH_AMOUNT, true);
            }
        }
    }


    @Override
    /**
     * 修改订单所属机构和专职理财师信息
     *
     * @param orderBillCode
     * @param serviceUserUuid
     * @param serviceUserOrgPath
     * @throws BusinessException
     */
    public void updateServiceUserInfo(String orderBillCode, String serviceUserUuid, String serviceUserOrgPath) throws BusinessException {
        Map updateMap = new HashMap();
        updateMap.put("orderBillCode", orderBillCode);
        updateMap.put("serviceUserUuid", serviceUserUuid);
        updateMap.put("serviceUserOrgPath", serviceUserOrgPath);
        tradeOrderMapper.update(updateMap);
    }


    /**
     * 获取收款方账户的宝付托管ID
     *
     * @param accountUuid
     * @param accountType
     * @return
     * @throws BusinessException
     */
    private long getPayeeAccountNo(String accountUuid, String accountType) throws BusinessException {
        Map accountMap = new HashMap();
        accountMap.put("accountUuid", accountUuid);
        accountMap.put("accountType", accountType);
        accountMap.put("accountStatus", "1");
        accountMap.put("properties", "accountNo");
        Map account = accountBaofooMapper.getBaofooAndAccount(accountMap);
        if (account == null) {
            throw new BusinessException(TradeStatusMsg.NO_AVAILABLE_ACCOUNT_CODE, TradeStatusMsg.NO_AVAILABLE_ACCOUNT_MSG, true);
        }
        return (long) account.get("accountNo");
    }

    private String getIssuerResidence(String issuerUuid) {
        String issuerResidence = "";
        if(DataUtils.isNotEmpty(issuerUuid)) {
            String sql = "SELECT issuer_residence FROM kingold_user.issuer WHERE user_uuid = " + WhereCondition.toSQLStr(issuerUuid);
            String ret = operationReportMapper.lstSingleString(new QueryUtils(sql));
            issuerResidence = DataUtils.isNotEmpty(ret) ? ret:issuerResidence;
        }

        return issuerResidence;
    }


    /**
     * 将电子合同的订单信息更新进trade表
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = {BusinessException.class, RuntimeException.class})
    public int updateContractFileInfo(List<ThreeTuple<String, String, String>> contractFileInfoList) throws BusinessException {
        int succCount = 0;
        if(contractFileInfoList==null) {
            return succCount;
        }

        LOGGER.info("将电子合同信息更新到trade表 begin");
        for(ThreeTuple<String, String, String> contractFileInfo: contractFileInfoList) {
            succCount += tradeOrderMapper.updateContractInfo(contractFileInfo.third, contractFileInfo.second, contractFileInfo.third);
        }
        LOGGER.info("将电子合同信息更新到trade表 end");

        return succCount;
    }

    @Override
    public List<ThreeTuple<String, String, String>> contractFill(String productUuid) throws BusinessException {
        List<ThreeTuple<String, String, String>> contractFileInfoList = new ArrayList<>();

        ProductFixedIncome productInfo = getFixedIncomeProductById(productUuid);
        String issuerUuid = productInfo.getProductIssuerUuid();
        UserInfo issuerInfo = getUserInfo(issuerUuid);
        String productManualNo = getProductDescriptionCode(productUuid);

        //公司住所
        String issuerResidence = getIssuerResidence(issuerUuid);
        LOGGER.error("发行方公司住址：" + issuerResidence);

        LOGGER.info("获取法人和法人代表章");
        TwoTuple<Image, Image> sealImages = getIssuerSealImage(issuerUuid);

        if(!FileUtils.isExist(contractTemplateFilePath)) {
            LOGGER.error("模板文件" + DataUtils.toString(contractTemplateFilePath) + "不存在");
            return contractFileInfoList;
        }

        if(!FileUtils.makeDirs(contractDestFilePath)) {
            LOGGER.error("目录" + DataUtils.toString(contractDestFilePath) + "创建失败");
            return contractFileInfoList;
        }

        WhereCondition condition = new WhereCondition();
        condition.setCondi("product_uuid", productUuid);
        condition.setInInt("order_status", BizDefine.ORDER_STATUS_CONFIRM, BizDefine.ORDER_STATUS_PRODUCT_INTEREST);
        condition.setCondi(" subcontract_filepath IS NULL ");
        condition.noDelete();
        condition.setOrderByAsc("create_time");

        List<TradeOrder> tradeOrderList = lstTradeOrdersByCondition(condition);

        if((tradeOrderList==null) || (tradeOrderList.size()==0)) {
            LOGGER.error("没有有效的订单");
            return contractFileInfoList;
        }

        LOGGER.info("需要生成电子合同的订单数{}", tradeOrderList.size());
        for(TradeOrder tradeOrder : tradeOrderList) {
            ContractFillInfoVO fillInfo = new ContractFillInfoVO();
            fillInfo.setTemplateFilePath(contractTemplateFilePath);
            fillInfo.setContractFilePath(contractDestFilePath);
            fillInfo.setProductManualNo(productManualNo);
            fillInfo.setIssuerResidence(issuerResidence);

            fillInfo.setIssuerName(issuerInfo.getIssuerName());
            fillInfo.setLegalPersonName(issuerInfo.getLegalPersonName());

            fillInfo.setSealImages(sealImages);

            fillInfo.setInvestorName(tradeOrder.getUserName());
            fillInfo.setSubAmt(tradeOrder.getOrderAmount().doubleValue());

            UserInfo userInfo = getUserInfo(tradeOrder.getUserUuid());
            if(userInfo != null) {
                fillInfo.setInvestorIDNumber(userInfo.getInvestorIdCardNo());
                fillInfo.setContractNo(sequenceService.getSubContractNo(tradeOrderMapper));

                String newFileName = FileUtils.andExp(FileUtils.getFileName(fillInfo.getTemplateFilePath()), fillInfo.getContractNo());
                fillInfo.setContractFileName(fillInfo.getContractFilePath() + newFileName);

                LOGGER.info("PDFFillUtils.fillContent_start");
                fillInfo = PDFFillUtils.fillContent(fillInfo);
                LOGGER.info("PDFFillUtils.fillContent_end");

                String uriFilePath = fileServiceUtils.uploadFile(fillInfo.getContractFileName());
                LOGGER.info("fileServiceUtils.uploadFile_end");
                fillInfo.setContractFileName(uriFilePath);

                if(DataUtils.isNotEmpty(fillInfo.getContractFilePath()) && DataUtils.isNotEmpty(fillInfo.getContractFileName()) && DataUtils.isNotEmpty(fillInfo.getContractNo())) {
                    //contractFileInfoList.add(new ThreeTuple<String, String, String>(tradeOrder.getOrderBillCode(), fillInfo.getContractFileName(), fillInfo.getContractNo()));
                    tradeOrderMapper.updateContractInfo(tradeOrder.getOrderBillCode(), fillInfo.getContractFileName(), fillInfo.getContractNo());
                }else {
                    LOGGER.error("记录" + tradeOrder.getOrderBillCode() + "合同信息更新失败");
                }
            }
        }

        return contractFileInfoList;
    }

    /**
     * 根据发行人的userUuid，获取该发行人的法人公章和法定代表人私章
     * @param issuerUuid 发行人UserUuid
     * @return first法人公章, second法定代表人公章
     */
    private TwoTuple<Image, Image> getIssuerSealImage(String issuerUuid) {
        Image legalPersonImage = null;         //法人公章
        Image legalRepresentative = null;        //法人代表私章
        if(DataUtils.isNotEmpty(contractSealFilePath)) {
            String legalPersonImagePath = contractSealFilePath + issuerUuid + "_1.png";
            if(FileUtils.isExist(legalPersonImagePath)) {
                try {
                    legalPersonImage = Image.getInstance(legalPersonImagePath);
                } catch (BadElementException e) {
                    LOGGER.error("BadElementException: ", e);
                } catch (IOException e) {
                    LOGGER.error("IOException: ", e);
                }
            }

            String legalRepresentativeImagePath = contractSealFilePath + issuerUuid + "_2.png";
            if(FileUtils.isExist(legalRepresentativeImagePath)) {
                try {
                    legalRepresentative = Image.getInstance(legalRepresentativeImagePath);
                } catch (BadElementException e) {
                    LOGGER.error("BadElementException: ", e);
                } catch (IOException e) {
                    LOGGER.error("IOException: ", e);
                }
            }
        }else {
            LOGGER.info("没有配置印章图片路径");
        }

        return new TwoTuple<Image, Image>(legalPersonImage, legalRepresentative);
    }

    @Override
    @Transactional(rollbackFor = {BusinessException.class, RuntimeException.class})
    public void contractFillEx(String productUuid) throws BusinessException {
        ProductFixedIncome productInfo = getFixedIncomeProductById(productUuid);
        String issuerUuid = productInfo.getProductIssuerUuid();
        UserInfo issuerInfo = getUserInfo(issuerUuid);
        String productManualNo = getProductDescriptionCode(productUuid);

        //公司住所
        LOGGER.error("IssuerUuid: " + issuerUuid);
        String issuerResidence = getIssuerResidence(issuerUuid);

        if (!FileUtils.isExist(contractTemplateFilePath)) {
            LOGGER.error("模板文件" + DataUtils.toString(contractTemplateFilePath) + "不存在");
            return;
        }

        if (!FileUtils.makeDirs(contractDestFilePath)) {
            LOGGER.error("目录" + DataUtils.toString(contractDestFilePath) + "创建失败");
            return;
        }

        WhereCondition condition = new WhereCondition();
        condition.setCondi("product_uuid", productUuid);
        condition.setInInt("order_status", BizDefine.ORDER_STATUS_CONFIRM, BizDefine.ORDER_STATUS_PRODUCT_INTEREST);
        condition.setCondi(" subcontract_filepath IS NULL ");
        condition.noDelete();

        LOGGER.info("获取法人和法人代表章");
        TwoTuple<Image, Image> sealImages = getIssuerSealImage(issuerUuid);

        LOGGER.info(lstTradeOrdersByCondition(condition).size() * 100 + "");
        LOGGER.info("Begin: " + DataUtils.toString(new Date()));
        for (TradeOrder tradeOrder : lstTradeOrdersByCondition(condition)) {
            LOGGER.info("TradeOrder: " + tradeOrder.toString());
            //for(int i = 0; i<100;i++) {
            ContractFillInfoVO fillInfo = new ContractFillInfoVO();
            fillInfo.setIssuerResidence(issuerResidence);
            fillInfo.setTemplateFilePath(contractTemplateFilePath);
            fillInfo.setContractFilePath(contractDestFilePath);
            fillInfo.setProductManualNo(productManualNo);

            fillInfo.setSealImages(sealImages);

            fillInfo.setIssuerName(issuerInfo.getIssuerName());
            fillInfo.setLegalPersonName(issuerInfo.getLegalPersonName());

            fillInfo.setInvestorName(tradeOrder.getUserName());
            fillInfo.setSubAmt(tradeOrder.getOrderAmount().doubleValue());

            //UserInfo userInfo = getUserInfo(tradeOrder.getUserUuid());
            //if (userInfo != null) {
            //String investorIdCardNo = userInfo.getInvestorIdCardNo();
            String investorIdCardNo = "132132132132132132";
            fillInfo.setInvestorIDNumber(investorIdCardNo);
            fillInfo.setContractNo(sequenceService.getSubContractNo(tradeOrderMapper));

            String newFileName = FileUtils.andExp(FileUtils.getFileName(fillInfo.getTemplateFilePath()), fillInfo.getContractNo());
            fillInfo.setContractFileName(fillInfo.getContractFilePath() + newFileName);

            fillInfo = PDFFillUtils.fillContent(fillInfo);

            LOGGER.info("ContractFileName: " + fillInfo.getContractFileName());
            String uriFilePath = fileServiceUtils.uploadFile(fillInfo.getContractFileName());
            fillInfo.setContractFileName(uriFilePath);

            break;

//                if(DataUtils.isNotEmpty(fillInfo.getContractFilePath()) && DataUtils.isNotEmpty(fillInfo.getContractFileName()) && DataUtils.isNotEmpty(fillInfo.getContractNo())) {
//                    tradeOrderMapper.updateContractInfo(tradeOrder.getOrderBillCode(), fillInfo.getContractFileName(), fillInfo.getContractNo());
//                }else {
//                    LOGGER.error("记录" + tradeOrder.getOrderBillCode() + "合同信息更新失败");
//                }
            //}
            //++i;
            //}
        }
        LOGGER.info("End: " + DataUtils.toString(new Date()));
    }

    /**
     * 获取阿里private 文件访问路径
     * @param fileName
     * @return
     * @throws BusinessException
     */
    @Override
    public String getAccessFileUrl(String fileName) throws BusinessException {
        return fileServiceUtils.getAccessFileUrl(fileName);
    }
}
