package cn.zjhf.kingold.trade.entity.InVO;

import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import java.util.Date;

/**
 * Created by DELL on 2017/5/18.
 */
@ApiModel(value = "LstProductExpireCashVO", description = "产品到期_还款查询(维度:产品，列表) 查询入参")
public class LstProductExpireCashVO extends InVOBase {
    @ApiModelProperty(required = true, value = "traceID")
    @NotEmpty
    private String traceID;

    @ApiModelProperty(required = true, value = "产品名称")
    private String productName;

    @ApiModelProperty(required = true, value = "放款申请编号")
    private long applyUUId;

    @ApiModelProperty(required = true, value = "状态：-1审核失败；1待审核；2审核通过；3已兑付；0全部")
    private int transStatus;

    @ApiModelProperty(required = true, value = "申请时间_起始")
    private Date beginDate;

    @ApiModelProperty(required = true, value = "申请时间_结束")
    private Date endDate;

    @ApiModelProperty(required = true, value = "起始序号")
    private int beginSN;

    @ApiModelProperty(required = true, value = "结束序号")
    private int endSN;

    @ApiModelProperty(required = true, value = "排序字段，暂不使用")
    private String orderByFields;

    @Override
    public String getTraceID() {
        return traceID;
    }

    @Override
    public void setTraceID(String traceID) {
        this.traceID = traceID;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public long getApplyUUId() {
        return applyUUId;
    }

    public void setApplyUUId(long applyUUId) {
        this.applyUUId = applyUUId;
    }

    public int getTransStatus() {
        return transStatus;
    }

    public void setTransStatus(int transStatus) {
        this.transStatus = transStatus;
    }

    public Date getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(Date beginDate) {
        this.beginDate = beginDate;
    }

    public Date getEndDate() {
        return convertEndDate(endDate);
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public int getBeginSN() {
        return beginSN;
    }

    public void setBeginSN(int beginSN) {
        this.beginSN = beginSN;
    }

    public int getEndSN() {
        return endSN;
    }

    public void setEndSN(int endSN) {
        this.endSN = endSN;
    }

    public String getOrderByFields() {
        return orderByFields;
    }

    public void setOrderByFields(String orderByFields) {
        this.orderByFields = orderByFields;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(traceID) + ", ");
        sb.append("productName:" + DataUtils.toString(productName) + ", ");
        sb.append("applyUUId:" + DataUtils.toString(applyUUId) + ", ");
        sb.append("transStatus:" + DataUtils.toString(transStatus) + ", ");
        sb.append("beginDate:" + DataUtils.toString(beginDate) + ", ");
        sb.append("endDate:" + DataUtils.toString(endDate) + ", ");
        sb.append("beginSN:" + DataUtils.toString(beginSN) + ", ");
        sb.append("endSN:" + DataUtils.toString(endSN) + ", ");
        sb.append("orderByFields:" + DataUtils.toString(orderByFields));
        return sb.toString();
    }
}
