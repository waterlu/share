package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.constant.AccountType;
import cn.zjhf.kingold.trade.constant.TradeStatusMsg;
import cn.zjhf.kingold.trade.constant.TradeType;
import cn.zjhf.kingold.trade.entity.Account;
import cn.zjhf.kingold.trade.entity.RedPacketRecord;
import cn.zjhf.kingold.trade.persistence.dao.RedPacketRecordMapper;
import cn.zjhf.kingold.trade.service.IAccountService;
import cn.zjhf.kingold.trade.service.IDrawRedPacketService;
import cn.zjhf.kingold.trade.utils.DataUtils;
import cn.zjhf.kingold.trade.utils.QueryUtils;
import cn.zjhf.kingold.trade.utils.Tuple.TwoTuple;
import cn.zjhf.kingold.trade.utils.WhereCondition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by zhangyijie on 2018/2/1.
 */
@Service
public class DrawRedPacketServiceImpl extends ProductClearBase implements IDrawRedPacketService {
    protected static final Logger logger = LoggerFactory.getLogger(DrawRedPacketServiceImpl.class);

    @Autowired
    private IAccountService accountService;

    @Autowired
    protected RedPacketRecordMapper redPacketRecordMapper;

    @Override
    @Transactional(rollbackFor = BusinessException.class, propagation = Propagation.REQUIRES_NEW)
    public void drawRedPacketFail(Long redPacketId, String errMess) throws BusinessException {
        redPacketRecordMapper.drawRedPacketFail(redPacketId, errMess);
    }

    /**
     * 领取红包
     * @param
     * @return 1领取成功，2领取失败
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = BusinessException.class, propagation = Propagation.REQUIRES_NEW)
    public TwoTuple<Integer, String> drawRedPacket(String userUuid, Long redPacketId) throws BusinessException {

        RedPacketRecord redPacketRecord = redPacketRecordMapper.selectByPrimaryKey(redPacketId);
        int ret = 0;
        String errMess = "";
        Account clearAccount = null;
        Account investerAccount = null;

        if((redPacketRecord!=null)
                && DataUtils.isEmpty(redPacketRecord.getPhoneName())
                && DataUtils.isNotEmpty(redPacketRecord.getUserUuid())) {
            String sql = "SELECT investor_real_name FROM kingold_user.investor WHERE user_uuid="
                    + WhereCondition.toSQLStr(redPacketRecord.getUserUuid());

            String investorName = operationReportMapper.lstSingleString(new QueryUtils(sql));
            if(DataUtils.isNotEmpty(investorName)) {
                logger.info("更新投资者姓名");
                redPacketRecordMapper.updateInvestorName(redPacketRecord.getId(), investorName);
            }
        }

        logger.info("Step1 检查现金红包的信息");
        if ((redPacketRecord == null) || DataUtils.isEmpty(redPacketRecord.getUserUuid()) || (!redPacketRecord.getUserUuid().equals(userUuid))) {
            throw new BusinessException(TradeStatusMsg.RED_PACKET_NOEXIST, TradeStatusMsg.RED_PACKET_NOEXIST_MSG, false);
        }

        if (redPacketRecord.getReceiveStatus().intValue() != RedPacketServiceImpl.UNDRAW_STATUS) {
            throw new BusinessException(TradeStatusMsg.RED_PACKET_STATUS_ERR, TradeStatusMsg.RED_PACKET_STATUS_ERR_MSG, false);
        }

        try {
            logger.info("Step2 检查投资者是否已绑卡或平台清算账户余额是否充足");
            investerAccount = getAccountByUserUuid(AccountType.ACCOUNT_TYPE_INVESTOR, userUuid);
            clearAccount = getAccountByType(AccountType.ACCOUNT_TYPE_PLATFORM_SETTLEMENT);
            if (clearAccount.getAccountCashAmount().doubleValue() < redPacketRecord.getRedPacketAmount().doubleValue()) {
                throw new BusinessException(TradeStatusMsg.CLEAR_ACCOUNT_LESS_BALANCE, TradeStatusMsg.CLEAR_ACCOUNT_LESS_BALANCE_MSG, false);
            }
        }catch(BusinessException e) {
            logger.error("BusinessException: ", e);
            errMess = e.getMessage();
        }

        if(DataUtils.isEmpty(errMess)) {
            logger.info("Step3 将现金红包状态置为已领取");
            ret = redPacketRecordMapper.drawRedPacket(userUuid, redPacketId);

            if (ret > 0) {
                logger.info("Step4 实际给客户发放现金红包");
                // 记录账户变化和流水
                String campaignRewardBillCode = redPacketRecord.getAuditId() + "_" + redPacketRecord.getId();
                accountService.payment(campaignRewardBillCode, clearAccount.getAccountNo(), investerAccount.getAccountNo(),
                        redPacketRecord.getRedPacketAmount(), TradeType.TRADE_COMMISION_PAYMENT_EXPERIENCE_ACTIVITY,
                        "");

                // 平台向用户转账
                logger.info("campaignRewardBillCode:" + campaignRewardBillCode + ", investerAccountNo:" + investerAccount.getAccountNo() + ", amount:" + redPacketRecord.getRedPacketAmount());
                ResponseResult payResult = payService.transferP2C(campaignRewardBillCode, investerAccount.getAccountNo(), redPacketRecord.getRedPacketAmount().doubleValue());
                if (!payResult.isSuccessful()) {
                    ret=0;
                    logger.info(payResult.toString());
                    throw new BusinessException(payResult.getCode(), payResult.getMsg());
                }
            }else{
                throw new BusinessException(TradeStatusMsg.RED_PACKET_STATUS_ERR, TradeStatusMsg.RED_PACKET_STATUS_ERR_MSG, false);
            }
        }else {
            logger.info("Step3 设置领取失败消息");
            redPacketRecordMapper.drawRedPacketFail(redPacketId, errMess);
        }

        return new TwoTuple<Integer, String>(ret, errMess);
    }
}
