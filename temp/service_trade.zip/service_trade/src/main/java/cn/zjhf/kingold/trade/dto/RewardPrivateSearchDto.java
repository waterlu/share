package cn.zjhf.kingold.trade.dto;

import cn.zjhf.kingold.common.param.ParamVO;

import java.util.Date;

/**
 * 定期奖励结算查询条件
 *
 * Created by lutiehua on 2017/6/1.
 */
public class RewardPrivateSearchDto extends ParamVO {

    /**
     * offset
     */
    private Integer pageNo;

    /**
     * limit
     */
    private Integer pageSize;

    /**
     * 手机
     */
    private String userMobile;

    /**
     * 姓名
     */
    private String userName;

    /**
     * 产品名称
     */
    private String productName;

    /**
     * 定期奖励结算状态
     */
    private Integer rewardPrivateStatus;

    private String belongTopUserUuid;

    private String belongTopOrgPath;

    public String getBelongTopUserUuid() {
        return belongTopUserUuid;
    }

    public void setBelongTopUserUuid(String belongTopUserUuid) {
        this.belongTopUserUuid = belongTopUserUuid;
    }

    public String getBelongTopOrgPath() {
        return belongTopOrgPath;
    }

    public void setBelongTopOrgPath(String belongTopOrgPath) {
        this.belongTopOrgPath = belongTopOrgPath;
    }

    public Date getClearStartDate() {
        return clearStartDate;
    }

    public void setClearStartDate(Date clearStartDate) {
        this.clearStartDate = clearStartDate;
    }

    public Date getClearEndDate() {
        return clearEndDate;
    }

    public void setClearEndDate(Date clearEndDate) {
        this.clearEndDate = clearEndDate;
    }

    /**
     * 发放日期-开始（查询时使用）
     */
    private Date clearStartDate;

    /**
     * 发放日期-结束（查询时使用）
     */
    private Date clearEndDate;

    public Integer getPageNo() {
        return pageNo;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public String getUserMobile() {
        return userMobile;
    }

    public void setUserMobile(String userMobile) {
        this.userMobile = userMobile;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Integer getRewardPrivateStatus() {
        return rewardPrivateStatus;
    }

    public void setRewardPrivateStatus(Integer rewardPrivateStatus) {
        this.rewardPrivateStatus = rewardPrivateStatus;
    }
}
