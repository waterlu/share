package cn.zjhf.kingold.trade.dto;

import cn.zjhf.kingold.common.param.ParamVO;

import java.util.Date;

/**
 * Created by lutiehua on 2017/6/5.
 */
public class UserAuthDto extends ParamVO {

    private String userUuid;

    private Integer userCertificationStatus;

    private Integer userCertificationType;

    private Date createTime;

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public Integer getUserCertificationStatus() {
        return userCertificationStatus;
    }

    public void setUserCertificationStatus(Integer userCertificationStatus) {
        this.userCertificationStatus = userCertificationStatus;
    }

    public Integer getUserCertificationType() {
        return userCertificationType;
    }

    public void setUserCertificationType(Integer userCertificationType) {
        this.userCertificationType = userCertificationType;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}
