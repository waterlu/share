package cn.zjhf.kingold.trade.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author 
 */
public class CouponSpecifiedDistributionRecord implements Serializable {
    /**
     * 审核编号
     */
    private Long auditId;

    /**
     * 指定发放名称
     */
    private String specifiedName;

    /**
     * 1指定发放礼券，2是现金红包
     */
    private Integer specifiedType;

    /**
     * 红包金额/发放金额
     */
    private BigDecimal redPacketAmount;

    /**
     * 礼券批次, 批次号-名称, 多个礼券用英文“,”间隔
     */
    private String ccCodes;

    /**
     * 导入用户记录条数(人)
     */
    private Integer userCount;

    /**
     * 处理状态: -1审核作废；1待审核；2审核通过
     */
    private Byte auditStatus;

    /**
     * 审核人
     */
    private String auditOperator;

    /**
     * 审核时间
     */
    private Date auditTime;

    /**
     * 审核意见
     */
    private String auditOpinion;

    /**
     * 更新用户id
     */
    private String creatorUserid;

    /**
     * 创建/发放/导入发放时间
     */
    private Date createTime;

    /**
     * 删除标记 0未删除，1已删除
     */
    private Byte deleteFlag;

    /**
     * 更新时间
     */
    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public Long getAuditId() {
        return auditId;
    }

    public void setAuditId(Long auditId) {
        this.auditId = auditId;
    }

    public String getCcCodes() {
        return ccCodes;
    }

    public void setCcCodes(String ccCodes) {
        this.ccCodes = ccCodes;
    }

    public Integer getUserCount() {
        return userCount;
    }

    public void setUserCount(Integer userCount) {
        this.userCount = userCount;
    }

    public Byte getAuditStatus() {
        return auditStatus;
    }

    public void setAuditStatus(Byte auditStatus) {
        this.auditStatus = auditStatus;
    }

    public String getAuditOperator() {
        return auditOperator;
    }

    public void setAuditOperator(String auditOperator) {
        this.auditOperator = auditOperator;
    }

    public Date getAuditTime() {
        return auditTime;
    }

    public void setAuditTime(Date auditTime) {
        this.auditTime = auditTime;
    }

    public String getAuditOpinion() {
        return auditOpinion;
    }

    public void setAuditOpinion(String auditOpinion) {
        this.auditOpinion = auditOpinion;
    }

    public String getCreatorUserid() {
        return creatorUserid;
    }

    public void setCreatorUserid(String creatorUserid) {
        this.creatorUserid = creatorUserid;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        return "CouponSpecifiedDistributionRecord{" +
                "auditId=" + auditId +
                ", specifiedName='" + specifiedName + '\'' +
                ", specifiedType=" + specifiedType +
                ", redPacketAmount=" + redPacketAmount +
                ", ccCodes='" + ccCodes + '\'' +
                ", userCount=" + userCount +
                ", auditStatus=" + auditStatus +
                ", auditOperator='" + auditOperator + '\'' +
                ", auditTime=" + auditTime +
                ", auditOpinion='" + auditOpinion + '\'' +
                ", creatorUserid='" + creatorUserid + '\'' +
                ", createTime=" + createTime +
                ", deleteFlag=" + deleteFlag +
                ", updateTime=" + updateTime +
                '}';
    }

    public String getSpecifiedName() {
        return specifiedName;
    }

    public void setSpecifiedName(String specifiedName) {
        this.specifiedName = specifiedName;
    }

    public Integer getSpecifiedType() {
        return specifiedType;
    }

    public void setSpecifiedType(Integer specifiedType) {
        this.specifiedType = specifiedType;
    }

    public BigDecimal getRedPacketAmount() {
        return redPacketAmount;
    }

    public void setRedPacketAmount(BigDecimal redPacketAmount) {
        this.redPacketAmount = redPacketAmount;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }
}