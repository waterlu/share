package cn.zjhf.kingold.trade.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author 
 */
public class RewardPrivateFund implements Serializable {
    /**
     * 发放单号
     */
    private String rewardPrivateBillCode;

    /**
     * 发放状态
     */
    private Integer rewardPrivateStatus;

    /**
     * 产品UUID
     */
    private String productUuid;

    /**
     * 产品编码
     */
    private String productCode;

    /**
     * 产品名称
     */
    private String productName;

    /**
     * 产品简称
     */
    private String productAbbrName;

    /**
     * 用户UUID
     */
    private String userUuid;

    /**
     * 用户手机号码
     */
    private String userMobile;

    /**
     * 用户姓名
     */
    private String userRealName;

    /**
     * 用户身份证号码
     */
    private String userIdCardNo;

    /**
     * 奖励单数
     */
    private Integer rewardCount;

    /**
     * 奖励金额（税前佣金）
     */
    private BigDecimal rewardAmount;

    /**
     * 创建时间（产品成立时间）
     */
    private Date createTime;

    /**
     * 审核时间
     */
    private Date checkTime;

    /**
     * 结算时间（发放时间）
     */
    private Date clearTime;

    /**
     * 审核人
     */
    private String checkUser;

    /**
     * 结算人
     */
    private String clearUser;

    /**
     * 备注
     */
    private String remark;


    private String belongTopUserUuid;

    private String belongTopOrgPath;

    public String getBelongTopUserUuid() {
        return belongTopUserUuid;
    }

    public void setBelongTopUserUuid(String belongTopUserUuid) {
        this.belongTopUserUuid = belongTopUserUuid;
    }

    public String getBelongTopOrgPath() {
        return belongTopOrgPath;
    }

    public void setBelongTopOrgPath(String belongTopOrgPath) {
        this.belongTopOrgPath = belongTopOrgPath;
    }

    @JsonIgnore
    private List<Reward> rewardList = new ArrayList<>();

    public void addReward(Reward reward) {
        rewardList.add(reward);
    }

    public List<Reward> getRewardList() {
        return rewardList;
    }

    private static final long serialVersionUID = 1L;

    public String getRewardPrivateBillCode() {
        return rewardPrivateBillCode;
    }

    public void setRewardPrivateBillCode(String rewardPrivateBillCode) {
        this.rewardPrivateBillCode = rewardPrivateBillCode;
    }

    public Integer getRewardPrivateStatus() {
        return rewardPrivateStatus;
    }

    public void setRewardPrivateStatus(Integer rewardPrivateStatus) {
        this.rewardPrivateStatus = rewardPrivateStatus;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductAbbrName() {
        return productAbbrName;
    }

    public void setProductAbbrName(String productAbbrName) {
        this.productAbbrName = productAbbrName;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getUserMobile() {
        return userMobile;
    }

    public void setUserMobile(String userMobile) {
        this.userMobile = userMobile;
    }

    public String getUserRealName() {
        return userRealName;
    }

    public void setUserRealName(String userRealName) {
        this.userRealName = userRealName;
    }

    public String getUserIdCardNo() {
        return userIdCardNo;
    }

    public void setUserIdCardNo(String userIdCardNo) {
        this.userIdCardNo = userIdCardNo;
    }

    public Integer getRewardCount() {
        return rewardCount;
    }

    public void setRewardCount(Integer rewardCount) {
        this.rewardCount = rewardCount;
    }

    public BigDecimal getRewardAmount() {
        return rewardAmount;
    }

    public void setRewardAmount(BigDecimal rewardAmount) {
        this.rewardAmount = rewardAmount;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getCheckTime() {
        return checkTime;
    }

    public void setCheckTime(Date checkTime) {
        this.checkTime = checkTime;
    }

    public Date getClearTime() {
        return clearTime;
    }

    public void setClearTime(Date clearTime) {
        this.clearTime = clearTime;
    }

    public String getCheckUser() {
        return checkUser;
    }

    public void setCheckUser(String checkUser) {
        this.checkUser = checkUser;
    }

    public String getClearUser() {
        return clearUser;
    }

    public void setClearUser(String clearUser) {
        this.clearUser = clearUser;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}