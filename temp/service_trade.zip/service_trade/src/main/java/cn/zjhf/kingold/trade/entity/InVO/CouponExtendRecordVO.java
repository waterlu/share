package cn.zjhf.kingold.trade.entity.InVO;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.trade.entity.CouponExtendRecord;
import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.Date;

@ApiModel(value = "CouponExtendRecordVO", description = "现金券发放记表")
public class CouponExtendRecordVO extends InVOBase {

    @ApiModelProperty(required = true, value = "礼券编码")
    @NotEmpty
    @Size(min = 1, max = 32)
    private String couponExtendCode;

    @ApiModelProperty(required = true, value = "礼券批次号")
    @NotEmpty
    @Size(min = 1, max = 32)
    private String couponCode;

    @ApiModelProperty(required = false, value = "现金券类型(1现金券，2加息券)")
    private int couponType;

    @ApiModelProperty(required = true, value = "礼券面值")
    private BigDecimal couponFaceValue;

    @ApiModelProperty(required = false, value = "加息券加息率")
    private BigDecimal couponInterestYieldRate;

    @ApiModelProperty(required = false, value = "加息券加息类型：0全产品期限加息；1指定加息天数")
    private Integer couponInterestYieldType;

    @ApiModelProperty(required = false, value = "加息券加息天数，interest_yield_type=1时有效")
    private Integer couponInterestYieldPeriod;

    @ApiModelProperty(required = false, value = "有效期开始时间")
    private Date validStartTime;

    @ApiModelProperty(required = false, value = "有效期结束时间")
    private Date validEndTime;

    @ApiModelProperty(required = false, value = "剩余时间")
    private String remainTime;

    @ApiModelProperty(required = true, value = "礼券状态(1已发放,2已使用,3已过期,4已作废)")
    @NotEmpty
    private int couponStatus;

    @ApiModelProperty(required = true, value = "用户UUID")
    @NotEmpty
    @Size(min = 1, max = 32)
    private String userUuid;

    @ApiModelProperty(required = true, value = "用户名")
    @NotEmpty
    @Size(min = 1, max = 32)
    private String userPhoneNumber;

    @ApiModelProperty(required = true, value = "用户姓名")
    @NotEmpty
    @Size(min = 1, max = 64)
    private String userName;

    @ApiModelProperty(required = true, value = "场景编码(1注册,2实名,3首次绑卡,4首次充值,4首次投资,5邀请好友首次投资)")
    @NotEmpty
    private int applyScene;

    @ApiModelProperty(required = false, value = "作废时间")
    private Date cancelTime;

    @ApiModelProperty(required = false, value = "作废说明")
    @Size(min = 1, max = 256)
    private String cancelRemark;

    @ApiModelProperty(required = true, value = "删除标记 0未删除，1已删除")
    @NotEmpty
    private int deleteFlag;

    @ApiModelProperty(required = false, value = "创建/发放/导入发放时间")
    private Date createTime;

    @ApiModelProperty(required = false, value = "更新时间")
    private Date updateTime;

    @ApiModelProperty(required = false, value = "更新用户id")
    @Size(min = 1, max = 32)
    private String updateUserId;

    public CouponExtendRecordVO() {
    }

    public CouponExtendRecordVO(CouponExtendRecord couponExtendRecord) {
        this.couponExtendCode = couponExtendRecord.getCouponExtendCode();
        this.couponCode = couponExtendRecord.getCouponCode();
        this.couponType = couponExtendRecord.getCouponType();
        this.couponFaceValue = couponExtendRecord.getCouponFaceValue();
        this.couponInterestYieldRate = couponExtendRecord.getCouponInterestYieldRate();
        this.couponInterestYieldType = couponExtendRecord.getCouponInterestYieldType();
        this.couponInterestYieldPeriod = couponExtendRecord.getCouponInterestYieldPeriod();
        this.validStartTime = couponExtendRecord.getValidStartTime();
        this.validEndTime = couponExtendRecord.getValidEndTime();
        this.couponStatus = couponExtendRecord.getCouponStatus();
        this.userUuid = couponExtendRecord.getUserUuid();
        this.userPhoneNumber = couponExtendRecord.getUserPhoneNumber();
        this.userName = couponExtendRecord.getUserName();
        this.applyScene = couponExtendRecord.getApplyScene();
        this.cancelTime = couponExtendRecord.getCancelTime();
        this.cancelRemark = couponExtendRecord.getCancelRemark();
        this.deleteFlag = couponExtendRecord.getDeleteFlag();
        this.createTime = couponExtendRecord.getCreateTime();
        this.updateTime = couponExtendRecord.getUpdateTime();
        this.updateUserId = couponExtendRecord.getUpdateUserId();
    }

    public String getCouponExtendCode() {
        return couponExtendCode;
    }

    public void setCouponExtendCode(String couponExtendCode) {
        this.couponExtendCode = couponExtendCode;
    }

    public String getCouponCode() {
        return couponCode;
    }

    public void setCouponCode(String couponCode) {
        this.couponCode = couponCode;
    }

    public int getCouponType() {
        return couponType;
    }

    public void setCouponType(int couponType) {
        this.couponType = couponType;
    }

    public BigDecimal getCouponFaceValue() {
        return couponFaceValue;
    }

    public void setCouponFaceValue(BigDecimal couponFaceValue) {
        this.couponFaceValue = couponFaceValue;
    }

    public Date getValidStartTime() {
        return validStartTime;
    }

    public void setValidStartTime(Date validStartTime) {
        this.validStartTime = validStartTime;
    }

    public Date getValidEndTime() {
        return validEndTime;
    }

    public void setValidEndTime(Date validEndTime) {
        this.validEndTime = validEndTime;
    }

    public int getCouponStatus() {
        return couponStatus;
    }

    public void setCouponStatus(int couponStatus) {
        this.couponStatus = couponStatus;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getUserPhoneNumber() {
        return userPhoneNumber;
    }

    public void setUserPhoneNumber(String userPhoneNumber) {
        this.userPhoneNumber = userPhoneNumber;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getApplyScene() {
        return applyScene;
    }

    public void setApplyScene(int applyScene) {
        this.applyScene = applyScene;
    }

    public Date getCancelTime() {
        return cancelTime;
    }

    public void setCancelTime(Date cancelTime) {
        this.cancelTime = cancelTime;
    }

    public String getCancelRemark() {
        return cancelRemark;
    }

    public void setCancelRemark(String cancelRemark) {
        this.cancelRemark = cancelRemark;
    }

    public int getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(int deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(String updateUserId) {
        this.updateUserId = updateUserId;
    }

    public CouponExtendRecord get() {
        CouponExtendRecord couponExtendRecord = new CouponExtendRecord();
        couponExtendRecord.setCouponExtendCode(couponExtendCode);
        couponExtendRecord.setCouponCode(couponCode);
        couponExtendRecord.setCouponType(new Integer(couponType).byteValue());
        couponExtendRecord.setCouponFaceValue(couponFaceValue);
        couponExtendRecord.setCouponInterestYieldRate(couponInterestYieldRate);
        couponExtendRecord.setCouponInterestYieldType(couponInterestYieldType);
        couponExtendRecord.setCouponInterestYieldPeriod(couponInterestYieldPeriod);
        couponExtendRecord.setValidStartTime(validStartTime);
        couponExtendRecord.setValidEndTime(validEndTime);
        couponExtendRecord.setCouponStatus(new Integer(couponStatus).byteValue());
        couponExtendRecord.setUserUuid(userUuid);
        couponExtendRecord.setUserPhoneNumber(userPhoneNumber);
        couponExtendRecord.setUserName(userName);
        couponExtendRecord.setApplyScene(new Integer(applyScene).byteValue());
        couponExtendRecord.setCancelTime(cancelTime);
        couponExtendRecord.setCancelRemark(cancelRemark);
        couponExtendRecord.setDeleteFlag(new Integer(deleteFlag).byteValue());
        couponExtendRecord.setCreateTime(createTime);
        couponExtendRecord.setUpdateTime(updateTime);
        couponExtendRecord.setUpdateUserId(updateUserId);
        return couponExtendRecord;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(getTraceID()) + ", ");
        sb.append("couponExtendCode:" + DataUtils.toString(couponExtendCode) + ", ");
        sb.append("couponCode:" + DataUtils.toString(couponCode) + ", ");
        sb.append("couponType:" + DataUtils.toString(couponType) + ", ");
        sb.append("couponFaceValue:" + DataUtils.toString(couponFaceValue) + ", ");
        sb.append("couponInterestYieldRate:" + DataUtils.toString(couponInterestYieldRate) + ", ");
        sb.append("couponInterestYieldType:" + DataUtils.toString(couponInterestYieldType) + ", ");
        sb.append("couponInterestYieldPeriod:" + DataUtils.toString(couponInterestYieldPeriod) + ", ");
        sb.append("validStartTime:" + DataUtils.toString(validStartTime) + ", ");
        sb.append("validEndTime:" + DataUtils.toString(validEndTime) + ", ");
        sb.append("remainTime:" + DataUtils.toString(remainTime) + ", ");
        sb.append("couponStatus:" + DataUtils.toString(couponStatus) + ", ");
        sb.append("userUuid:" + DataUtils.toString(userUuid) + ", ");
        sb.append("userPhoneNumber:" + DataUtils.toString(userPhoneNumber) + ", ");
        sb.append("userName:" + DataUtils.toString(userName) + ", ");
        sb.append("applyScene:" + DataUtils.toString(applyScene) + ", ");
        sb.append("cancelTime:" + DataUtils.toString(cancelTime) + ", ");
        sb.append("cancelRemark:" + DataUtils.toString(cancelRemark) + ", ");
        sb.append("deleteFlag:" + DataUtils.toString(deleteFlag) + ", ");
        sb.append("createTime:" + DataUtils.toString(createTime) + ", ");
        sb.append("updateTime:" + DataUtils.toString(updateTime) + ", ");
        sb.append("updateUserId:" + DataUtils.toString(updateUserId));
        return sb.toString();
    }

    public String getRemainTime() {
        return remainTime;
    }

    public void setRemainTime(String remainTime) {
        this.remainTime = remainTime;
    }

    public BigDecimal getCouponInterestYieldRate() {
        return couponInterestYieldRate;
    }

    public void setCouponInterestYieldRate(BigDecimal couponInterestYieldRate) {
        this.couponInterestYieldRate = couponInterestYieldRate;
    }

    public Integer getCouponInterestYieldType() {
        return couponInterestYieldType;
    }

    public void setCouponInterestYieldType(Integer couponInterestYieldType) {
        this.couponInterestYieldType = couponInterestYieldType;
    }

    public Integer getCouponInterestYieldPeriod() {
        return couponInterestYieldPeriod;
    }

    public void setCouponInterestYieldPeriod(Integer couponInterestYieldPeriod) {
        this.couponInterestYieldPeriod = couponInterestYieldPeriod;
    }
}
