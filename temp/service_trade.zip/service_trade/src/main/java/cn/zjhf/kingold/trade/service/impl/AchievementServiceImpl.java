package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.service_consumer.service.UserServiceConsumer;
import cn.zjhf.kingold.trade.constant.*;
import cn.zjhf.kingold.trade.dto.InvestorDto;
import cn.zjhf.kingold.trade.dto.UserAuthDto;
import cn.zjhf.kingold.trade.dto.UserRelationDto;
import cn.zjhf.kingold.trade.entity.Achievement;
import cn.zjhf.kingold.trade.entity.TradeOrder;
import cn.zjhf.kingold.trade.entity.TradePrivateFundOrder;
import cn.zjhf.kingold.trade.persistence.dao.AchievementMapper;
import cn.zjhf.kingold.trade.persistence.mq.message.UserUpgradeMessage;
import cn.zjhf.kingold.trade.persistence.mq.producer.UserUpgradeProducer;
import cn.zjhf.kingold.trade.service.IAchievementService;
import cn.zjhf.kingold.trade.service.ITradeOrderService;
import cn.zjhf.kingold.trade.service.ITradePrivateFundOrderService;
import com.alibaba.fastjson.JSON;
import com.alibaba.rocketmq.client.producer.SendResult;
import com.alibaba.rocketmq.client.producer.SendStatus;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;

/**
 * Created by lutiehua on 2017/6/15.
 */
@Service
public class AchievementServiceImpl implements IAchievementService {

    private final Logger LOGGER = LoggerFactory.getLogger(AchievementServiceImpl.class);

    @Autowired
    ITradeOrderService orderService;

    @Autowired
    ITradePrivateFundOrderService privateFundOrderService;

    @Autowired
    UserServiceConsumer userServiceConsumer;

    @Autowired
    AchievementMapper achievementMapper;

    @Autowired
    UserUpgradeProducer mqProducer;

    /**
     * 升级为认证理财师的阈值
     *
     */
    @Value("${broker.upgrade.threshold}")
    private BigDecimal brokerThreshold;

    @Override
    public BigDecimal queryAchievement(String userUUid) throws BusinessException {
        return achievementMapper.queryTotalAchievement(userUUid);
    }

    /**
     * 生成定期产品业绩
     *
     * @param tradeOrder
     * @return
     * @throws BusinessException
     */
    @Override
    public boolean generateFTAchievement(TradeOrder tradeOrder) throws BusinessException {
        LOGGER.info("======== Generating achievement for fixed term product is started ========");
        String orderBillCode = tradeOrder.getOrderBillCode();
        LOGGER.info("orderBillCode={}", orderBillCode);

        // 重新查询订单
        Map<String, Object> orderMap = orderService.getTradeOrder(orderBillCode);
        if (null == orderMap) {
            LOGGER.error("交易订单号不存在：{}", orderBillCode);
            return false;
        }

        String jsonString = JSON.toJSONString(orderMap);
        tradeOrder = JSON.parseObject(jsonString, TradeOrder.class);

        // 订单必须是已支付的状态
        if (tradeOrder.getOrderStatus() != BizDefine.ORDER_STATUS_CONFIRM) {
            LOGGER.error("订单状态不是已支付：{} ", tradeOrder.getOrderStatus());
            return false;
        }

        // 订单金额不能为空
        if (null == tradeOrder.getOrderAmount()) {
            LOGGER.error("订单金额不能为空：{} ", orderBillCode);
            return false;
        }

        LOGGER.info("orderAmount={}", tradeOrder.getOrderAmount());

        // 确认产品
        String productUuid = tradeOrder.getProductUuid();
        if (StringUtils.isEmpty(productUuid)) {
            LOGGER.error("productUuid不能为空");
            return false;
        }

        LOGGER.info("productUuid={}", productUuid);

        // 确认认购人
        String userUuid = tradeOrder.getUserUuid();
        if (StringUtils.isEmpty(userUuid)) {
            LOGGER.error("userUuid不能为空");
            return false;
        }

        LOGGER.info("userUuid={}", userUuid);

        // 检查是否已经生成过业绩
        List<Achievement> achievementList = achievementMapper.queryByOrderBillCode(orderBillCode);
        if (achievementList.size() > 0) {
            LOGGER.error("查询到已经存在业绩记录，共{}条", achievementList.size());
            return false;
        }

        // 查询所有上级
        Map<String, Object> userRelationParam = new HashMap<>();
        userRelationParam.put("traceID", UUID.randomUUID().toString());
        String url = String.format(URL.URL_USER_GET_RELATION, userUuid);
        ResponseResult responseResult = userServiceConsumer.get(url, userRelationParam);
        if (!responseResult.isSuccessful()) {
            LOGGER.error("查询用户关系失败：{}" + responseResult.getMsg());
            return false;
        }
        UserRelationDto userRelationDto = userServiceConsumer.getData(responseResult, UserRelationDto.class);

        String leader = userRelationDto.getInviterLevelOneUuid();
        if (StringUtils.isNotEmpty(leader)) {
            LOGGER.info("生成业绩");
            LOGGER.info("业绩所属人={}", leader);
            Achievement achievement = new Achievement();
            achievement.setAchievementStatus(1);
            achievement.setAchievementUuid(UUID.randomUUID().toString().replace("-", ""));
            achievement.setCustomerMobile(tradeOrder.getUserPhone());
            achievement.setCustomerUuid(tradeOrder.getUserUuid());
            achievement.setOrderAmount(tradeOrder.getOrderAmount());
            achievement.setOrderBillCode(orderBillCode);
            achievement.setOrderTime(tradeOrder.getPayedTime());
            achievement.setProductUuid(tradeOrder.getProductUuid());
            achievement.setProductName(tradeOrder.getProductAbbrName());
            achievement.setProductType(ProductType.PRODUCT_FT);
            achievement.setUserUuid(leader);

            achievementMapper.insert(achievement);
        } else {
            LOGGER.info("没有上级邀请人，不生成业绩");
        }

        // 理财师认证
//        if (StringUtils.isNotEmpty(leader)) {
//            updateUserAuthStatus(leader);
//        }

        LOGGER.info("======== Generating achievement for fixed term product is finished ========");
        return false;
    }

    @Override
    public boolean generatePFAchievement(TradePrivateFundOrder tradeOrder) throws BusinessException {
        LOGGER.info("======== Generating achievement for private fund product is started ========");
        String orderBillCode = tradeOrder.getPfoCode();
        LOGGER.info("orderBillCode={}", orderBillCode);

        // 重新查询订单
        Map<String, Object> privateFundOrderParam = new HashMap<>();
        privateFundOrderParam.put("pfoCode", orderBillCode);
        Map<String, Object> orderMap = privateFundOrderService.getWithFilter(privateFundOrderParam);
        if (null == orderMap) {
            LOGGER.error("交易订单号不存在：{}", orderBillCode);
            return false;
        }

        String jsonString = JSON.toJSONString(orderMap);
        tradeOrder = JSON.parseObject(jsonString, TradePrivateFundOrder.class);

        // 私募订单必须是2已确认状态
        if (tradeOrder.getPfoStatus() != TradeConstants.PFO_STAUTS_DONE) {
            LOGGER.error("订单状态不是已确认：{} ", tradeOrder.getPfoStatus());
            return false;
        }

        // 订单金额不能为空
        if (null == tradeOrder.getPurchaseAmount()) {
            LOGGER.error("订单金额不能为空：{} ", orderBillCode);
            return false;
        }

        LOGGER.info("orderAmount={}", tradeOrder.getPurchaseAmount());

        // 确认产品
        String productUuid = tradeOrder.getProductUuid();
        if (StringUtils.isEmpty(productUuid)) {
            LOGGER.error("productUuid is empty");
            return false;
        }

        LOGGER.info("productUuid={}", productUuid);

        // 确认预约人
        String userUuid = tradeOrder.getInvestorUserUuid();
        if (StringUtils.isEmpty(userUuid)) {
            LOGGER.error("userUuid is empty");
            return false;
        }

        LOGGER.info("userUuid={}", userUuid);

        // 检查是否已经生成过业绩
        List<Achievement> achievementList = achievementMapper.queryByOrderBillCode(orderBillCode);
        if (achievementList.size() > 0) {
            LOGGER.error("查询到已经存在业绩记录，共{}条", achievementList.size());
            return false;
        }

        // 检查是否是给自己做的预约
        boolean isBookMyself = false;
        String customerIdCardNo = tradeOrder.getCustomerIdCardNo();
        String url = URL.URL_USER_GET_INVESTOR;
        Map<String, Object> investorParam = new HashMap<>();
        investorParam.put("userUuids", userUuid);
        ResponseResult responseResult = userServiceConsumer.get(url, investorParam);
        if (!responseResult.isSuccessful()) {
            LOGGER.error("查询投资人信息失败：{}" + userUuid);
            return false;
        }

        List<InvestorDto> investorDtoList = userServiceConsumer.getDataArray(responseResult, InvestorDto.class);
        if (investorDtoList.size() > 0) {
            InvestorDto investorDto = investorDtoList.get(0);
            String investorIdCardNo = investorDto.getInvestorIdCardNo();
            // 根据身份证号码判断是否给自己预约，投资人身份证号码=预约客户身份证号码？
            if (StringUtils.isNotEmpty(investorIdCardNo) && investorIdCardNo.equalsIgnoreCase(customerIdCardNo)) {
                isBookMyself = true;
            }
        }

        LOGGER.info("isBookMyself={}", isBookMyself);

        Achievement achievement = new Achievement();
        achievement.setAchievementStatus(1);
        achievement.setAchievementUuid(UUID.randomUUID().toString().replace("-", ""));
        achievement.setOrderAmount(tradeOrder.getPurchaseAmount());
        achievement.setOrderBillCode(orderBillCode);
        achievement.setOrderTime(tradeOrder.getPurchaseTime());
        achievement.setProductUuid(tradeOrder.getProductUuid());
        achievement.setProductName(tradeOrder.getProductName());
        achievement.setProductType(ProductType.PRODUCT_PF);
        achievement.setCustomerUuid(null);
        achievement.setCustomerMobile(tradeOrder.getCustomerMobile());

        // 业绩所属人
        String leader = null;
        if (isBookMyself) {
            LOGGER.info("理财师给自己做预约");

            // 查询上级
            Map<String, Object> userRelationParam = new HashMap<>();
            userRelationParam.put("traceID", UUID.randomUUID().toString());
            url = String.format(URL.URL_USER_GET_RELATION, userUuid);
            responseResult = userServiceConsumer.get(url, userRelationParam);
            if (!responseResult.isSuccessful()) {
                LOGGER.error("查询用户关系失败：{}" + responseResult.getMsg());
                return false;
            }
            UserRelationDto userRelationDto = userServiceConsumer.getData(responseResult, UserRelationDto.class);
            leader = userRelationDto.getInviterLevelOneUuid();
            if (StringUtils.isNotEmpty(leader)) {
                LOGGER.info("业绩所属人={}", leader);
                achievement.setUserUuid(leader);
                achievementMapper.insert(achievement);
            } else{
                LOGGER.info("没有上级邀请人，不生成业绩");
            }
        } else {
            LOGGER.info("理财师给别人做预约");
            leader = userUuid;
            LOGGER.info("业绩所属人={}", userUuid);
            achievement.setUserUuid(userUuid);
            achievementMapper.insert(achievement);
        }

        // 理财师认证
//        if (StringUtils.isNotEmpty(leader)) {
//            updateUserAuthStatus(leader);
//        }

        LOGGER.info("======== Generating achievement for private fund product is finished ========");
        return false;
    }

    /**
     * 用户身份认证
     *
     * @param userUuid
     * @return
     * @throws BusinessException
     */
    public boolean updateUserAuthStatus(String userUuid) throws BusinessException {
        LOGGER.info("======== User upgrade is started ========");
        if (StringUtils.isEmpty(userUuid)) {
            LOGGER.error("userUuid is null");
            return false;
        }

        // 判断用户身份是否是理财师
        LOGGER.info("userUuid={}", userUuid);

        // 读取用户信息
        Map<String, Object> userAuthParam = new HashMap<>();
        String url = URL.URL_USER_GET_INVESTOR;
        userAuthParam.put("userUuids", userUuid);
        ResponseResult responseResult = userServiceConsumer.get(url, userAuthParam);
        if (!responseResult.isSuccessful()) {
            LOGGER.error("读取用户信息失败：{}", responseResult.getMsg());
            return false;
        }

        List<InvestorDto> investorDtoList = userServiceConsumer.getDataArray(responseResult, InvestorDto.class);
        boolean upgrade = false;
        if (investorDtoList.size() > 0) {
            InvestorDto investorDto = investorDtoList.get(0);
            int investorType = investorDto.getInvestorType();
            LOGGER.info("用户身份={}", investorType);
            if (investorType == InvestorType.INVESTOR) {
                // 判断是否达到认证理财师门槛
                LOGGER.info("开始升级判断");

                BigDecimal amount = queryAchievement(userUuid);

                LOGGER.info("业绩={}", amount.doubleValue());
                LOGGER.info("升级阈值={}", brokerThreshold.doubleValue());
                if (amount.compareTo(brokerThreshold) >= 0) {
                    LOGGER.info("{}可以升级为认证理财师", userUuid);
                    upgrade = true;
                }

                if (upgrade) {
                    // 升级
                    LOGGER.info("升级到理财师：{}", userUuid);
                    // 更新investor表的用户身份
                    url = String.format(URL.URL_USER_PUT, userUuid);
                    Map<String, Object> userTypeParam = new HashMap<>();
                    userTypeParam.put("investorType", InvestorType.FINANCIAL_PLANNER);
                    ResponseResult result = userServiceConsumer.put(url, userTypeParam);
                    if (!result.isSuccessful()) {
                        LOGGER.error(result.getMsg());
                    }

                    // 写入理财师身份
                    UserAuthDto userAuthDto = new UserAuthDto();
                    userAuthDto.setUserUuid(userUuid);
                    userAuthDto.setUserCertificationStatus(1);
                    userAuthDto.setUserCertificationType(UserCertificationType.FINANCIAL_PLANNER);
                    url = URL.URL_USER_AUTH_ADD;
                    result = userServiceConsumer.post(url, userAuthDto);
                    if (!result.isSuccessful()) {
                        LOGGER.error(result.getMsg());
                    } else{
                        // 发布用户升级为理财师主题
                        try {
                            UserUpgradeMessage message = new UserUpgradeMessage(investorDto);
                            SendResult sendResult = mqProducer.send(message);
                            if (sendResult.getSendStatus() == SendStatus.SEND_OK) {
                                LOGGER.info("发送理财师认证消息成功");
                            } else {
                                LOGGER.error("发送理财师认证消息成功失败：{}", sendResult.getSendStatus().name());
                            }
                        } catch (Exception e) {
                            LOGGER.error("发送消息失败：{}", e.getMessage());
                        }
                    }
                }
            } else {
                LOGGER.info("{} 已认证，身份={}", userUuid, investorType);
            }
        } else {
            LOGGER.error("用户信息为空");
            return false;
        }


        LOGGER.info("======== User upgrade is finished ========");
        return true;
    }

}
