package cn.zjhf.kingold.trade.dto;

import java.math.BigDecimal;

/**
 * @author liuyao
 * @date 2018/3/19
 */
public class TradeOrderProfitEverydayDto {
    private String userUuid;
    private BigDecimal profit;

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public BigDecimal getProfit() {
        return profit;
    }

    public void setProfit(BigDecimal profit) {
        this.profit = profit;
    }
}
