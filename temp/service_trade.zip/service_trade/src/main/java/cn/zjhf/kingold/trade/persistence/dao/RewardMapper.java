package cn.zjhf.kingold.trade.persistence.dao;

import cn.zjhf.kingold.trade.dto.RewardSearchDto;
import cn.zjhf.kingold.trade.entity.Reward;
import cn.zjhf.kingold.trade.utils.WhereCondition;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Repository
public interface RewardMapper {
    int deleteByPrimaryKey(String rewardBillCode);

    int insert(Reward record);

    Reward selectByPrimaryKey(String rewardBillCode);

    int updateByPrimaryKey(Reward record);

    /**
     * 根据产品UUID查询奖励记录
     *
     * @param productUuid
     * @return
     */
    List<Reward> selectByProductUuid(String productUuid);

    /**
     * 根据产品UUID和奖励状态查询奖励记录
     *
     * @param queryParam
     * @return
     */
    List<Reward> selectByProductUuidAndStatus(Map<String, Object> queryParam);

    /**
     * 产品成立时更新产品成立日期
     *
     * @param param
     * @return
     */
    int updateProductEstablishTime(Map<String, Object> param);

    /**
     * 产品成立时更新奖励状态
     *
     * @param param
     * @return
     */
    int updateProductEstablishStatus(Map<String, Object> param);

    /**
     * 分页查询奖励记录
     *
     * @param rewardSearchDto
     * @return
     */
    List<Reward> searchReward(RewardSearchDto rewardSearchDto);

    List<Reward> lstByCondition(WhereCondition condition);

    /**
     * 查询奖励记录总数
     *
     * @param rewardSearchDto
     * @return
     */
    int searchRewardCount(RewardSearchDto rewardSearchDto);

    /**
     * 查询固收产品有效的奖励记录
     * @param fromCreateTime
     * @param toCreateTime
     * @return
     */
    @Select("SELECT reward.* FROM reward reward, trade_order trade " +
            "WHERE reward.order_bill_code = trade.order_bill_code AND trade.belong_merchant_num = '00000' " +
            "AND reward.reward_status!=2 and reward.is_enabled_reward=1 and reward.product_type = 'FIXI' " +
            "AND reward.product_interest_date>=#{fromCreateTime} and reward.product_interest_date<#{toCreateTime}")
    @ResultMap("BaseResultMap")
    List<Reward> searchEnableFixedReward(@Param("fromCreateTime") Date fromCreateTime, @Param("toCreateTime") Date toCreateTime);

    /**
     * 查询有效的奖励记录
     *
     * @param rewardSearchDto
     * @return
     */
    List<Reward> searchEnableReward(RewardSearchDto rewardSearchDto);

    /**
     * 查询有效的服务津贴
     *
     * @param rewardSearchDto
     * @return
     */
    List<Reward> searchServiceReward(RewardSearchDto rewardSearchDto);

    /**
     * 更新审核时间
     *
     * @param param
     * @return
     */
    int updateCheckTime(Map<String, Object> param);

    /**
     * 更新审核时间和金额
     *
     * @param param
     * @return
     */
    int updateClearTime(Map<String, Object> param);

    /**
     * 汇总后更新定期奖励结算单号
     *
     * @param param
     * @return
     */
    int updateSummaryBillCode(Map<String, Object> param);

    /**
     *
     * @param summaryBillCode
     * @return
     */
    List<Reward> queryBySummaryBillCode(String summaryBillCode);

    /**
     *
     * @param param
     * @return
     */
    List<Reward> queryPageBySummaryBillCode(Map<String, Object> param);

    @Select("SELECT * FROM reward WHERE order_bill_code=#{orderBillCode} AND reward_category=#{rewardCategory}")
    @ResultMap("BaseResultMap")
    List<Reward> queryByOrderBillCodeEx(@Param("orderBillCode") String orderBillCode, @Param("rewardCategory") int rewardCategory);

    /**
     *
     * @param summaryBillCode
     * @return
     */
    List<Reward> queryByOrderBillCode(String summaryBillCode);

    /**
     *
     * @param summaryBillCode
     * @return
     */
    int queryBySummaryBillCodeCount(String summaryBillCode);

    List<Reward> queryPrivateRewardForSummary(Map<String, Object> params);

    List<Reward> getRewardList(Map<String, Object> params);

    List<Map<String, BigDecimal>> listOrderBySum(@Param("userUuid") String userUuid, @Param("isInvest") Integer isInvest,@Param("offset") Integer offset,
                                                 @Param("limit") Integer limit);

    List<Reward> getRewardListByUuids(Map<String, Object> params);

    Integer getRewardCount(Map<String, Object> params);

    Map<String, BigDecimal> getRewardPaidSum(Map<String, Object> params);

    List<Map> getRewardGroupByType(@Param("userUuid") String userUuid);

    BigDecimal getRewardUnPaidSum(Map<String, Object> params);

    Reward getRewardDetail(@Param("rewardBillCode") String rewardBillCode);

    BigDecimal getTotalAmount();

}