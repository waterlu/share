package cn.zjhf.kingold.trade.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author 
 */
public class Reward implements Serializable {
    /**
     * 奖励单号
     */
    private String rewardBillCode;

    /**
     * 奖励类别：1邀请奖励，2达人奖励
     */
    private Integer rewardCategory;

    /**
     * 奖励类型
     */
    private Integer rewardType;

    /**
     * 奖励状态
     */
    private Integer rewardStatus;

    /**
     * 是否有效奖励
     */
    private Integer isEnabledReward;

    /**
     * 用户UUID
     */
    private String userUuid;

    /**
     * 投资者类型
     */
    private Integer investorType;

    /**
     * 用户手机号码
     */
    private String userMobile;

    /**
     * 用户真实姓名
     */
    private String userRealName;

    /**
     * 用户身份证号码
     */
    private String userIdCardNo;

    /**
     * 用户住址
     */
    private String userAddress;

    /**
     * 被邀请人手机号
     */
    private String beInvitedMobile;

    /**
     * 被邀请人uuid
     */
    private String beInvitedUserUuid;

    /**
     * 被邀请人投资时间
     */
    private Date beInvitedInvestTime;

    /**
     * 定期理财交易编号
     */
    private String orderBillCode;

    /**
     * 定期理财交易编号（扩展编号）
     */
    private String orderBillCodeExtend;

    /**
     * 产品UUID
     */
    private String productUuid;

    /**
     * 产品类型
     */
    private String productType;

    /**
     * 产品编码
     */
    private String productCode;

    /**
     * 产品名称
     */
    private String productName;

    /**
     * 产品简称
     */
    private String productAbbrName;

    /**
     * 产品期限
     */
    private Integer productPeriod;

    /**
     * 产品期限类型： Y(year,年)； M(month,月)； W(week,周)； D(day,自然日)
     */
    private String productPeriodType;

    /**
     * 用户认证时间
     */
    private Date userAuthTime;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 产品成立时间
     */
    private Date productInterestDate;

    /**
     * 审核日期
     */
    private Date checkTime;

    /**
     * 结算时间
     */
    private Date clearTime;

    /**
     * 认购金额
     */
    private BigDecimal investAmount;

    /**
     * 奖励计算基数金额
     */
    private BigDecimal baseAmount;

    /**
     * 奖励系数
     */
    private BigDecimal rewardFactor;

    /**
     * 奖励金额
     */
    private BigDecimal rewardAmount;

    /**
     * 结算金额（税后）
     */
    private BigDecimal payAmount;

    /**
     * 结算单号
     */
    private String summaryBillCode;


    private static final long serialVersionUID = 1L;


    private String belongTopUserUuid;

    private String belongTopOrgPath;

    public String getBelongTopUserUuid() {
        return belongTopUserUuid;
    }

    public void setBelongTopUserUuid(String belongTopUserUuid) {
        this.belongTopUserUuid = belongTopUserUuid;
    }

    public String getBelongTopOrgPath() {
        return belongTopOrgPath;
    }

    public void setBelongTopOrgPath(String belongTopOrgPath) {
        this.belongTopOrgPath = belongTopOrgPath;
    }

    public String getRewardBillCode() {
        return rewardBillCode;
    }

    public void setRewardBillCode(String rewardBillCode) {
        this.rewardBillCode = rewardBillCode;
    }

    public Integer getRewardType() {
        return rewardType;
    }

    public void setRewardType(Integer rewardType) {
        this.rewardType = rewardType;
    }

    public Integer getRewardStatus() {
        return rewardStatus;
    }

    public void setRewardStatus(Integer rewardStatus) {
        this.rewardStatus = rewardStatus;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public Integer getInvestorType() {
        return investorType;
    }

    public void setInvestorType(Integer investorType) {
        this.investorType = investorType;
    }

    public String getUserMobile() {
        return userMobile;
    }

    public void setUserMobile(String userMobile) {
        this.userMobile = userMobile;
    }

    public String getUserRealName() {
        return userRealName;
    }

    public void setUserRealName(String userRealName) {
        this.userRealName = userRealName;
    }

    public String getUserIdCardNo() {
        return userIdCardNo;
    }

    public void setUserIdCardNo(String userIdCardNo) {
        this.userIdCardNo = userIdCardNo;
    }

    public String getUserAddress() {
        return userAddress;
    }

    public void setUserAddress(String userAddress) {
        this.userAddress = userAddress;
    }

    public String getOrderBillCode() {
        return orderBillCode;
    }

    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductAbbrName() {
        return productAbbrName;
    }

    public void setProductAbbrName(String productAbbrName) {
        this.productAbbrName = productAbbrName;
    }

    public Integer getProductPeriod() {
        return productPeriod;
    }

    public void setProductPeriod(Integer productPeriod) {
        this.productPeriod = productPeriod;
    }

    public String getProductPeriodType() {
        return productPeriodType;
    }

    public void setProductPeriodType(String productPeriodType) {
        this.productPeriodType = productPeriodType;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getProductInterestDate() {
        return productInterestDate;
    }

    public void setProductInterestDate(Date productInterestDate) {
        this.productInterestDate = productInterestDate;
    }

    public Date getCheckTime() {
        return checkTime;
    }

    public void setCheckTime(Date checkTime) {
        this.checkTime = checkTime;
    }

    public Date getClearTime() {
        return clearTime;
    }

    public void setClearTime(Date clearTime) {
        this.clearTime = clearTime;
    }

    public BigDecimal getInvestAmount() {
        return investAmount;
    }

    public void setInvestAmount(BigDecimal investAmount) {
        this.investAmount = investAmount;
    }

    public BigDecimal getBaseAmount() {
        return baseAmount;
    }

    public void setBaseAmount(BigDecimal baseAmount) {
        this.baseAmount = baseAmount;
    }

    public BigDecimal getRewardFactor() {
        return rewardFactor;
    }

    public void setRewardFactor(BigDecimal rewardFactor) {
        this.rewardFactor = rewardFactor;
    }

    public BigDecimal getRewardAmount() {
        return rewardAmount;
    }

    public void setRewardAmount(BigDecimal rewardAmount) {
        this.rewardAmount = rewardAmount;
    }

    public Date getUserAuthTime() {
        return userAuthTime;
    }

    public void setUserAuthTime(Date userAuthTime) {
        this.userAuthTime = userAuthTime;
    }

    public Integer getIsEnabledReward() {
        return isEnabledReward;
    }

    public void setIsEnabledReward(Integer isEnabledReward) {
        this.isEnabledReward = isEnabledReward;
    }

    public BigDecimal getPayAmount() {
        return payAmount;
    }

    public void setPayAmount(BigDecimal payAmount) {
        this.payAmount = payAmount;
    }

    public String getSummaryBillCode() {
        return summaryBillCode;
    }

    public void setSummaryBillCode(String summaryBillCode) {
        this.summaryBillCode = summaryBillCode;
    }

    public String getBeInvitedMobile() {
        return beInvitedMobile;
    }

    public void setBeInvitedMobile(String beInvitedMobile) {
        this.beInvitedMobile = beInvitedMobile;
    }

    public Date getBeInvitedInvestTime() {
        return beInvitedInvestTime;
    }

    public void setBeInvitedInvestTime(Date beInvitedInvestTime) {
        this.beInvitedInvestTime = beInvitedInvestTime;
    }

    public String getBeInvitedUserUuid() {
        return beInvitedUserUuid;
    }

    public void setBeInvitedUserUuid(String beInvitedUserUuid) {
        this.beInvitedUserUuid = beInvitedUserUuid;
    }

    @Override
    public String toString() {
        return "Reward{" +
                "rewardBillCode='" + rewardBillCode + '\'' +
                ", rewardCategory=" + rewardCategory +
                ", rewardType=" + rewardType +
                ", rewardStatus=" + rewardStatus +
                ", userUuid='" + userUuid + '\'' +
                ", investorType=" + investorType +
                ", userMobile='" + userMobile + '\'' +
                ", userRealName='" + userRealName + '\'' +
                ", userIdCardNo='" + userIdCardNo + '\'' +
                ", userAddress='" + userAddress + '\'' +
                ", orderBillCode='" + orderBillCode + '\'' +
                ", orderBillCodeExtend='" + orderBillCodeExtend + '\'' +
                ", productUuid='" + productUuid + '\'' +
                ", productType='" + productType + '\'' +
                ", productCode='" + productCode + '\'' +
                ", productName='" + productName + '\'' +
                ", productAbbrName='" + productAbbrName + '\'' +
                ", productPeriod=" + productPeriod +
                ", productPeriodType='" + productPeriodType + '\'' +
                ", createTime=" + createTime +
                ", productInterestDate=" + productInterestDate +
                ", checkTime=" + checkTime +
                ", clearTime=" + clearTime +
                ", investAmount=" + investAmount +
                ", baseAmount=" + baseAmount +
                ", rewardFactor=" + rewardFactor +
                ", rewardAmount=" + rewardAmount +
                '}';
    }

    public Integer getRewardCategory() {
        return rewardCategory;
    }

    public void setRewardCategory(Integer rewardCategory) {
        this.rewardCategory = rewardCategory;
    }

    public String getOrderBillCodeExtend() {
        return orderBillCodeExtend;
    }

    public void setOrderBillCodeExtend(String orderBillCodeExtend) {
        this.orderBillCodeExtend = orderBillCodeExtend;
    }
}