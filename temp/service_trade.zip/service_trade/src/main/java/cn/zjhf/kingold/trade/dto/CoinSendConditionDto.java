package cn.zjhf.kingold.trade.dto;

import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * 金币发放条件
 * @author xiexiaojie
 */
public class CoinSendConditionDto {

    @ApiModelProperty(required = true, value = "用户uuid")
    @NotEmpty
    private String userUuid;

    @ApiModelProperty(required = true, value = "活动编号")
    @NotEmpty
    private Integer mcCode;

    public CoinSendConditionDto() {
    }
    public CoinSendConditionDto(String userUuid, Integer mcCode) {
        this.userUuid = userUuid;
        this.mcCode = mcCode;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public Integer getMcCode() {
        return mcCode;
    }

    public void setMcCode(Integer mcCode) {
        this.mcCode = mcCode;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("userUuid:" + DataUtils.toString(userUuid) + ", ");
        sb.append("mcCode:" + DataUtils.toString(mcCode));
        return sb.toString();
    }
}
