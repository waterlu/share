package cn.zjhf.kingold.trade.persistence.mq.message;

import cn.zjhf.kingold.rocketmq.base.MQMessage;
import cn.zjhf.kingold.trade.baofoo.RechargeNotify;

/**
 * 回调充值成功消息
 *
 * Created by lutiehua on 2017/7/13.
 */
public class PayRechargeMessage implements MQMessage {

    private RechargeNotify data;

    public PayRechargeMessage() {
    }

    public PayRechargeMessage(RechargeNotify rechargeNotify) {
        this.data = rechargeNotify;
    }

    @Override
    public String getKey() {
        return data.getBillCode();
    }

    public RechargeNotify getData() {
        return data;
    }

    public void setData(RechargeNotify data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "PayRechargeMessage{" +
                "data=" + data +
                '}';
    }
}
