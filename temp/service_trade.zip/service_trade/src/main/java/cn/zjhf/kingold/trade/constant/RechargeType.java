package cn.zjhf.kingold.trade.constant;

/**
 * Created by lutiehua on 2017/5/27.
 */
public interface RechargeType {

    /**
     * 平台支付
     *
     */
    int PLANTFORM_PAY = 1;

    /**
     * 个人支付
      */
    int PERSON_PAY = 2;



}
