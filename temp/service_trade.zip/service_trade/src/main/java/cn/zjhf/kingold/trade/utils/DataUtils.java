package cn.zjhf.kingold.trade.utils;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.constant.TradeError;
import cn.zjhf.kingold.trade.service.impl.ReconciliationServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by zhangyijie on 2017/5/16.
 */
public class DataUtils {
    private static final Logger logger = LoggerFactory.getLogger(DataUtils.class);

    public static final String LINEBREAK = "\r\n";

    public static final String SPLITSTR = "\\$\\$";

    public static byte intToByte(int x) {
        return (byte) x;
    }

    public static boolean isNotEmpty(String value) {
        if(value != null) {
            if(value.trim().length() > 0) {
                return true;
            }
        }

        return false;
    }

    public static boolean isNumeric(String str){
        Pattern pattern = Pattern.compile("[0-9]*");
        Matcher isNum = pattern.matcher(str.trim());
        if( !isNum.matches() ){
            return false;
        }
        return true;
    }

    public static List<String> getRepeat(List<String> items) {
        List<String> itemList = new ArrayList<>();
        Set<String>  repeatSet = new HashSet<>();

        if(items != null) {
            for (String item : items) {
                if (itemList.contains(item)) {
                    repeatSet.add(item);
                } else {
                    itemList.add(item);
                }
            }
        }

        return new ArrayList<String>(repeatSet);
    }

    public static List<String> split(String value) {
        if(isEmpty(value)) {
            return new ArrayList<String>();
        }

        String[] items = value.trim().split(SPLITSTR);
        return java.util.Arrays.asList(items);
    }

    public static int byteToInt(Byte b) {
        if(b != null) {
            return b & 0xFF;
        }

        return 0;
    }

    public static List<String> split(String value, String regex) {
        if(isEmpty(value)) {
            return new ArrayList<String>();
        }

        String[] items = value.trim().split(regex);
        return java.util.Arrays.asList(items);
    }

    public static List<String> toList(String... values) {
        List<String> items = new ArrayList<String>();
        for (String value : values) {
            items.add(value);
        }
        return items;
    }

    public static boolean isContain(int value, int... optValues) {
        if(optValues != null) {
            for (int optValue : optValues) {
                if (value == optValue) {
                    return true;
                }
            }
        }

        return false;
    }

    public static String base64Encode(String value) {
        String asB64 = null;
        try {
            asB64 = Base64.getEncoder().encodeToString(value.getBytes("utf-8"));
        } catch (UnsupportedEncodingException e) {
            logger.error("base64Decode Exception", e);
            asB64 = "";
        }
        return asB64;
    }

    public static String base64Decode(String value) {
        if(DataUtils.isEmpty(value)) {
            return "";
        }

        String asB64 = null;
        try {
            asB64 = new String(Base64.getDecoder().decode(value), "utf-8");
        } catch (UnsupportedEncodingException e) {
            logger.error("base64Decode Exception", e);
            asB64 = "";
        }
        return asB64;
    }

    public static boolean isContain(String value, String... optValues) {
        if(optValues != null) {
            for (String optValue : optValues) {
                if (value.equals(optValue)) {
                    return true;
                }
            }
        }

        return false;
    }

    public static boolean isEmpty(String value) {
        return !isNotEmpty(value);
    }

    public static void checkParam(String... params) throws BusinessException {
        if(params != null) {
            for (String param : params) {
                if ( isEmpty(param)) {
                    throw new BusinessException(TradeError.ERROR_PARAMETER, TradeError.ERROR_PARAMETER_TEXT, false);
                }
            }
        }else {
            throw new BusinessException(TradeError.ERROR_PARAMETER, TradeError.ERROR_PARAMETER_TEXT, false);
        }
    }

    public static void checkParam(int param) throws BusinessException {
        if(param <= 0) {
            throw new BusinessException(TradeError.ERROR_PARAMETER, TradeError.ERROR_PARAMETER_TEXT, false);
        }
    }

    public static void checkParam(Long param) throws BusinessException {
        if((param==null) || (param<=0L)) {
            throw new BusinessException(TradeError.ERROR_PARAMETER, TradeError.ERROR_PARAMETER_TEXT, false);
        }
    }

    /**
     * 去除重复的记录
     * @param items
     * @return
     */
    public static List<String> removeRepeat(List<String> items) {
        if(items != null) {
            return new ArrayList<String>(new HashSet<String>(items));
        }

        return items;
    }

    /**
     * 对字符串的List取MD5码
     * @param items
     * @return
     */
    public static String getMd5Str(List<String> items) {
        String value = toString(items);
        byte[] byteBuffer = value.getBytes();
        String md5Val = "";

        try {
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            md5.update(byteBuffer);
            BigInteger bi = new BigInteger(1, md5.digest());
            md5Val = bi.toString(16);
        } catch (Exception e) {
            logger.error("异常，", e);
        }

        if(value.length() < 32) {
            md5Val = DataUtils.padStr(32-value.length(),'0') + value;
        }

        return md5Val;
    }

    /**
     * 分割List
     * @param items 原始List
     * @param maxItemLen 分割后每个子的最大长度
     * @param isDupliRemove 是否去重
     * @param <T>
     * @return
     */
    public static <T> List<List<T>> splitList(List<T> items, int maxItemLen, boolean isDupliRemove) {
        List<List<T>> result = new ArrayList<>();
        if((items==null) || (items.size()==0) || (maxItemLen<1)) {
            return result;
        }

        List<T> tmpList = null;
        if(!isDupliRemove) {
            tmpList = items;
        }else {
            tmpList = new ArrayList<>(new HashSet<>(items));
        }

        int len = tmpList.size();
        int pos = 0;
        while(true) {
            int curItemLen = 0;
            if((pos+maxItemLen) <= len) {
                curItemLen = maxItemLen;
            }else if(((pos+maxItemLen) > len)&&(pos < len)){
                curItemLen = len-pos;
            }else {
                break;
            }

            result.add(tmpList.subList(pos, pos+curItemLen));
            pos += curItemLen;
        }

        return result;
    }

    public static <T> String listToStr(List<T> items) {
        StringBuilder str = new StringBuilder("");
        if (items == null)
            return str.toString();

        int len = items.size();
        if(len == 0) {
            logger.debug("空列表");
        }

        for (int i = 0; i < len; i++) {
            if (null != items.get(i)) {
                str.append(items.get(i).toString());

                if (i != (len - 1)) {
                    str.append(",");
                }
            }else {
                logger.debug("null");
            }
        }

        return str.toString();
    }

    public static String toString(List<List<String>> value) {
        StringBuilder sb = new StringBuilder("\r\n");
        if(null == value){
            return sb.toString();
        }

        for(List<String> items : value) {
            for(String item : items) {
                if(DataUtils.isEmpty(item)) {
                    item = "null";
                }

                sb.append(item).append("\t");
            }

            sb.append("\r\n");
        }

        return sb.toString();
    }

    //double的输出不要输出成科学计数法
    public static String toString(double value) {
        if (Double.isNaN(value))
            return "0";

        return AmountUtils.toString(value);
    }

    //double的输出不要输出成科学计数法
    public static String toString(int value) {
        if (Double.isNaN(value))
            return "0";

        return "" + value;
    }

    //Date不要输出成恶心的格式
    public static String toString(Date value) {
        if (null == value)
            return "1900-01-01 00:00:00";

        SimpleDateFormat sdf = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss" );
        return sdf.format(value);
    }

    //BigDecimal的输出不要输出成科学计数法
    public static String toString(BigDecimal value) {
        if (null == value)
            return "0";

        return AmountUtils.toString(value);
    }

    public static String toString(Object... objs) {
        StringBuilder sb = new StringBuilder();
        for(Object obj : objs) {
            sb.append(toString(obj)).append(" ");
        }

        return sb.toString();
    }

    public static String toString(Object obj) {
        if(obj instanceof Double) {
            return toString((double)obj);
        }else if(obj instanceof BigDecimal) {
            return toString((BigDecimal)obj);
        }else if(obj instanceof Date) {
            return toString((Date)obj);
        }else if(obj instanceof Map) {
            return toString((Map)obj);
        }else if(obj instanceof List) {
            return listToStr((List)obj);
        }

        return (obj != null) ? obj.toString() : "null";
    }

    public static String toString(Map map) {
        final String interStr = ", ";
        StringBuilder sb = new StringBuilder();

        List<Object> keys = new ArrayList<Object>(map.keySet());
        int count = keys.size();
        for(int i = 0; i < count; i++) {
            Object key = keys.get(i);
            sb.append(DataUtils.toString(key) + ":[" + DataUtils.toString(map.get(key)) + "]");

            if(i != (count-1)) {
                sb.append(interStr);
            }
        }

        return sb.toString();
    }

    public static String toLog(String name, Object velue) {
        return (new StringBuilder(toString(name)).append(":").append(toString(velue))).append(" ").toString();
    }

    public static String padStr(int len, char cc) {
        String format = "%" + len + "s";

        String tempResult = String.format(format, "");

        String finalResult = tempResult.replace(' ', cc);
        return finalResult;
    }

    // 左填充
    public static String leftPad(int value, int length) {
        String strFormat = "%0" + length + "d";
        String str = String.format(strFormat, value);

        if (str.length() > length) {
            return str.substring(str.length() - length, str.length());
        }
        return str;
    }

    public static String toString(Object obj1, Object obj2) {
        return (new StringBuilder(toString(obj1)).append(", ").append(toString(obj2))).toString();
    }

    /**
     * 将有重复记录的数据拆分成若干个分组，每个分组内都没有重复的数据
     * @param strLists
     * @return
     */
    public static List<List<String>> noRepeatGroup(List<String> strLists) {
        Map<String, Integer> repeatData = new HashMap<>();
        for(String key: strLists) {
            if(repeatData.containsKey(key)) {
                int repeatCount = repeatData.get(key).intValue();
                repeatData.replace(key, ++repeatCount);
            }else {
                repeatData.put(key, 1);
            }
        }

        List<List<String>> ret = new ArrayList<>();
        while (repeatData.size() > 0) {
            List<String> newList = new ArrayList<String>();

            Iterator<String> iterator = repeatData.keySet().iterator();
            while (iterator.hasNext()) {
                String key = iterator.next();
                newList.add(key);

                int repeatCount = repeatData.get(key).intValue();
                if(repeatData.get(key).intValue() == 1) {
                    iterator.remove();
                }else {
                    repeatData.replace(key, --repeatCount);
                }
            }
            ret.add(newList);
        }

        return ret;
    }
}
