package cn.zjhf.kingold.trade.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.constant.RewardError;
import cn.zjhf.kingold.trade.constant.RewardPrivateStatus;
import cn.zjhf.kingold.trade.dto.RewardPrivateSearchDto;
import cn.zjhf.kingold.trade.entity.RewardPrivateFund;
import cn.zjhf.kingold.trade.service.IRewardPrivateSummaryService;
import com.alibaba.fastjson.JSON;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * 私募产品佣金
 *
 * Created by lutiehua on 2017/6/2.
 */
@RestController
@RequestMapping(value = "/reward/summary/private")
public class RewardPrivateSummaryController {

    private final Logger LOGGER = LoggerFactory.getLogger(RewardPrivateSummaryController.class);

    @Autowired
    private IRewardPrivateSummaryService rewardPrivateSummaryService;

    /**
     * 获取私募产品佣金发放信息
     *
     * @param rewardPrivateBillCode
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/{rewardPrivateBillCode}", method = RequestMethod.GET)
    public ResponseResult getFixedAward(@PathVariable("rewardPrivateBillCode") String rewardPrivateBillCode) throws BusinessException {
        RewardPrivateFund rewardPrivateFund = rewardPrivateSummaryService.getAwardPrivate(rewardPrivateBillCode);
        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        responseResult.setData(rewardPrivateFund);
        return responseResult;
    }

    /**
     * 查询私募产品佣金发放记录
     *
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/search", method = RequestMethod.GET)
    public ResponseResult getPrivateAwardSummaryList(@RequestParam Map<String, Object> param) throws BusinessException {
        String jsonString = JSON.toJSONString(param);
        RewardPrivateSearchDto searchCondition = JSON.parseObject(jsonString, RewardPrivateSearchDto.class);

        // 保证""不作为查询条件
        if(StringUtils.isEmpty(searchCondition.getProductName())) {
            searchCondition.setProductName(null);
        }
        if (StringUtils.isEmpty(searchCondition.getUserMobile())) {
            searchCondition.setUserMobile(null);
        }
        if (StringUtils.isEmpty(searchCondition.getUserName())) {
            searchCondition.setUserName(null);
        }

        // 包括结束日期，查询时加1天
        if (null != searchCondition.getClearEndDate()) {
            Date endDate = searchCondition.getClearEndDate();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(endDate);
            calendar.add(Calendar.DAY_OF_YEAR, 1);
            endDate = calendar.getTime();
            searchCondition.setClearEndDate(endDate);
        }

        List<RewardPrivateFund> rewardList = rewardPrivateSummaryService.searchRewardPrivate(searchCondition);
        int count = rewardPrivateSummaryService.searchRewardPrivateCount(searchCondition);
        Map<String, Object> data = new HashMap<>();
        data.put("list", rewardList);
        data.put("count", count);
        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        responseResult.setTraceID(searchCondition.getTraceID());
        responseResult.setData(data);
        return responseResult;
    }

    /**
     * 批量审核私募产品佣金
     *
     * @param param
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/check", method = RequestMethod.PUT)
    public ResponseResult check(@RequestBody Map<String, Object> param) throws BusinessException {
        ResponseResult responseResult = new ResponseResult();

        // 参数检查
        if (null == param.get("rewardPrivateBillCode") || null == param.get("pass")) {
            responseResult.setCode(ResponseCode.PARAM_ERROR);
            responseResult.setMsg(ResponseCode.PARAM_ERROR_TEXT);
            return responseResult;
        }

        String rewardPrivateBillCode = param.get("rewardPrivateBillCode").toString();
        if (StringUtils.isEmpty(rewardPrivateBillCode)) {
            responseResult.setCode(ResponseCode.PARAM_ERROR);
            responseResult.setMsg(ResponseCode.PARAM_ERROR_TEXT);
            return responseResult;
        }

        int pass = Integer.parseInt(param.get("pass").toString());

        // 拼装请求参数
        Map<String, Object>  checkMap = new HashMap<>();
        checkMap.put("rewardPrivateBillCode", rewardPrivateBillCode);
        checkMap.put("pass", pass);

        if (null != param.get("userUuid")) {
            String userString = param.get("userUuid").toString();
            if (StringUtils.isNotEmpty(userString)) {
                checkMap.put("checkUser", userString);
            }
        }

        if (pass == 1) {
            checkMap.put("rewardPrivateStatus", RewardPrivateStatus.CHECKED);
            checkMap.put("checkTime", new Date());
            checkMap.put("remark", "");
        } else {
            checkMap.put("rewardPrivateStatus", RewardPrivateStatus.REJECT);
            checkMap.put("checkTime", null);
            if (null != param.get("remark")) {
                String remarkString = param.get("remark").toString();
                if (StringUtils.isNotEmpty(remarkString)) {
                    checkMap.put("remark", remarkString);
                }
            }
        }

        // 返回执行结果
        return rewardPrivateSummaryService.updateCheckStatus(checkMap);
    }

    /**
     * 批量发放私募产品佣金
     *
     * @param param
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/clear", method = RequestMethod.PUT)
    public ResponseResult clear(@RequestBody Map<String, Object> param) throws BusinessException {
        ResponseResult responseResult = new ResponseResult();

        // 参数检查
        if (null == param.get("rewardPrivateBillCode") || null == param.get("pass")) {
            responseResult.setCode(ResponseCode.PARAM_ERROR);
            responseResult.setMsg(ResponseCode.PARAM_ERROR_TEXT);
            return responseResult;
        }

        String rewardPrivateBillCode = param.get("rewardPrivateBillCode").toString();
        if (StringUtils.isEmpty(rewardPrivateBillCode)) {
            responseResult.setCode(ResponseCode.PARAM_ERROR);
            responseResult.setMsg(ResponseCode.PARAM_ERROR_TEXT);
            return responseResult;
        }

        // 拼装请求参数
        Map<String, Object>  clearMap = new HashMap<>();

        // 单号
        clearMap.put("rewardPrivateBillCode", rewardPrivateBillCode);

        // 是否通过
        int pass = Integer.parseInt(param.get("pass").toString());
        clearMap.put("pass", pass);

        // 操作人
        if (null != param.get("userUuid")) {
            String userString = param.get("userUuid").toString();
            if (StringUtils.isNotEmpty(userString)) {
                clearMap.put("clearUser", userString);
            }
        }

        if (pass == 1) {
            clearMap.put("rewardPrivateStatus", RewardPrivateStatus.FINISH);
            clearMap.put("clearTime", new Date());
        } else {
            LOGGER.error("pass != 1");
            responseResult.setCode(ResponseCode.PARAM_ERROR);
            responseResult.setMsg(ResponseCode.PARAM_ERROR_TEXT);
            return responseResult;
        }

        // 返回执行结果
        return rewardPrivateSummaryService.updateClearStatus(clearMap);
    }
}
