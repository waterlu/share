package cn.zjhf.kingold.trade.entity;

import cn.zjhf.kingold.trade.utils.DataUtils;

/**
 * Created by DELL on 2017/5/18.
 */
public class FeeTypeResult{
    private double amount;
    private int feeType;

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public int getFeeType() {
        return feeType;
    }

    public void setFeeType(int feeType) {
        this.feeType = feeType;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("amount:" + DataUtils.toString(amount) + ", ");
        sb.append("feeType:" + DataUtils.toString(feeType));
        return sb.toString();
    }
}
