package cn.zjhf.kingold.trade.constant;

/**
 * Created by lutiehua on 2017/6/26.
 */
public interface PayStatus {

    /**
     * 等待返回结果
     */
    int PENDING = 0;

    /**
     * 成功
     */
    int SUCCESSFUL = 1;

    /**
     * 失败
     */
    int FAILED = 2;

    /**
     * 取消
     */
    int CANCEL = 3;

    /**
     * 超时
     */
    int TIMEOUT = 4;

    /**
     * 申请成功
     */
    int APPLY_SUCCESS = 5;
}
