package cn.zjhf.kingold.trade.utils.File;

import cn.zjhf.kingold.trade.entity.ContractFillInfoVO;
import cn.zjhf.kingold.trade.utils.AmountUtils;
import cn.zjhf.kingold.trade.utils.AmtToCN;
import cn.zjhf.kingold.trade.utils.DateUtil;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by zhangyijie on 2017/7/14.
 */
public class PDFFillUtils {
    protected static final Logger logger = LoggerFactory.getLogger(PDFFillUtils.class);

    private static String getCNDate() {
        String curDate = DateUtil.getCueDate();
        return curDate.substring(0,4) + "年" + curDate.substring(4,6) + "月" + curDate.substring(6,8) + "日";
    }

    public static ContractFillInfoVO fillContent(ContractFillInfoVO fillInfo) {
        PdfReader reader = null;
        PdfStamper writer = null;
        try {
            FileUtils.delete(fillInfo.getContractFileName());

            reader = new PdfReader(fillInfo.getTemplateFilePath());
            writer = new PdfStamper(reader, new FileOutputStream(fillInfo.getContractFileName())/*, PdfWriter.VERSION_1_3*/);

            BaseFont bf = BaseFont.createFont("STSong-Light", "UniGB-UCS2-H", BaseFont.NOT_EMBEDDED);
            Font font = new Font(bf, 12);
            font.setStyle(Font.BOLD);
            font.setColor(BaseColor.BLACK);

            PdfContentByte over = writer.getOverContent(1);
            write(over, font, fillInfo.getContractNo(), 428, 754);
            write(over, font, fillInfo.getIssuerName(), 132, 625);

            //增加发行人住址
            write(over, font, fillInfo.getIssuerResidence(), 120, 594);

            write(over, font, fillInfo.getLegalPersonName(), 162, 531);
            write(over, font, fillInfo.getInvestorName(), 134, 468);
            write(over, font, fillInfo.getInvestorIDNumber(), 162, 438);

            over = writer.getOverContent(2);
            write(over, font, fillInfo.getIssuerName(), 210, 468);

            over = writer.getOverContent(3);
            write(over, font, fillInfo.getProductManualNo(), 420, 468);

            String cnAmt = AmtToCN.toCN(fillInfo.getSubAmt());
            over = writer.getOverContent(4);
            write(over, font, AmountUtils.toString(fillInfo.getSubAmt()), 250, 656);
            write(over, font, cnAmt, 384, 656);

            over = writer.getOverContent(11);
            write(over, font, cnAmt, 160, 625);
            write(over, font, AmountUtils.toString(fillInfo.getSubAmt()), 385, 625);

            write(over, font, fillInfo.getInvestorName(), 162, 240);
            write(over, font, getCNDate(), 175, 197);

            if(fillInfo.getSealImages().first != null) {
                addSeal(over, fillInfo.getSealImages().first, 385, 408);
            }
            write(over, font, fillInfo.getIssuerName(), 255, 456);


            if(fillInfo.getSealImages().second != null) {
                addSeal(over, fillInfo.getSealImages().second, 329, 349);
            }
            write(over, font, fillInfo.getLegalPersonName(), 312, 369);

            write(over, font, getCNDate(), 175, 326);

            writer.close();
            reader.close();
        }catch(IOException e) {
            logger.error("IOException", e);
        }catch(DocumentException e) {
            logger.error("DocumentException", e);
        }finally {
            if(reader!=null) {
                reader.close();
            }

            try {
                 if(writer!=null) {
                    writer.close();
                 }
            }catch(Exception e) {
                logger.error("Exception", e);
            }
        }

        return fillInfo;
    }

    private static void addSeal(PdfContentByte over, Image image, float xPos, float yPos) {
        try {
            image.setAbsolutePosition(xPos, yPos);
            over.addImage(image);
        } catch (BadElementException e) {
            logger.error("BadElementException: ", e);
        } catch (DocumentException e) {
            logger.error("DocumentException: ", e);
        }
    }

    private static void write(PdfContentByte over, Font font, String content, float xPos, float yPos) {
        over.beginText();
        over.setFontAndSize(font.getBaseFont(), font.getSize());
        over.setColorFill(font.getColor());
        over.setTextMatrix(xPos, yPos);
        content = ((content == null) ? "" : content);
        over.showText(content);
        over.endText();
    }
}
