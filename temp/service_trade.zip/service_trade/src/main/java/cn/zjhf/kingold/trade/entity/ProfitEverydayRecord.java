package cn.zjhf.kingold.trade.entity;

import java.math.BigDecimal;
import java.util.Date;

public class ProfitEverydayRecord implements Comparable<ProfitEverydayRecord>{
    private String userUuid;

    private BigDecimal profitAmount;

    private Integer profitType;

    private Integer profitDate;

    private int deleteFlag;

    private Date createTime;

    private Date updateTime;

    private BigDecimal profitPaidAmount;

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid == null ? null : userUuid.trim();
    }

    public BigDecimal getProfitAmount() {
        return profitAmount;
    }

    public void setProfitAmount(BigDecimal profitAmount) {
        this.profitAmount = profitAmount;
    }

    public Integer getProfitType() {
        return profitType;
    }

    public void setProfitType(Integer profitType) {
        this.profitType = profitType;
    }

    public Integer getProfitDate() {
        return profitDate;
    }

    public void setProfitDate(Integer profitDate) {
        this.profitDate = profitDate;
    }

    public int getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(int deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public BigDecimal getProfitPaidAmount() {
        return profitPaidAmount;
    }

    public void setProfitPaidAmount(BigDecimal profitPaidAmount) {
        this.profitPaidAmount = profitPaidAmount;
    }

    @Override
    public int compareTo(ProfitEverydayRecord o) {
        return o.getProfitDate() - this.getProfitDate();
    }
}