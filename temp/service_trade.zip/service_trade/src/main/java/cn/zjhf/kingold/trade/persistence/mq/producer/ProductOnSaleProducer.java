package cn.zjhf.kingold.trade.persistence.mq.producer;

import cn.zjhf.kingold.rocketmq.annotation.RocketMQProducer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQProducer;
import cn.zjhf.kingold.trade.persistence.mq.message.ProductMessage;

/**
 * Created by liuyao on 2017/8/27.
 */
@RocketMQProducer(topic = "product",tag = "onsale")
public class ProductOnSaleProducer extends AbstractMQProducer<ProductMessage>{
}
