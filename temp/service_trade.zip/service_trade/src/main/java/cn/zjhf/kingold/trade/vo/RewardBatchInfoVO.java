package cn.zjhf.kingold.trade.vo;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author lutiehua
 * @date 2018/3/22
 */
public class RewardBatchInfoVO {

    private Integer rewardFixedStatus;

    private Date rewardFixedStartDate;

    private Date rewardFixedEndDate;

    private Integer billCount;

    private BigDecimal totalAmount;

    private BigDecimal payAmount;

    public Integer getRewardFixedStatus() {
        return rewardFixedStatus;
    }

    public void setRewardFixedStatus(Integer rewardFixedStatus) {
        this.rewardFixedStatus = rewardFixedStatus;
    }

    public Date getRewardFixedStartDate() {
        return rewardFixedStartDate;
    }

    public void setRewardFixedStartDate(Date rewardFixedStartDate) {
        this.rewardFixedStartDate = rewardFixedStartDate;
    }

    public Date getRewardFixedEndDate() {
        return rewardFixedEndDate;
    }

    public void setRewardFixedEndDate(Date rewardFixedEndDate) {
        this.rewardFixedEndDate = rewardFixedEndDate;
    }

    public Integer getBillCount() {
        return billCount;
    }

    public void setBillCount(Integer billCount) {
        this.billCount = billCount;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public BigDecimal getPayAmount() {
        return payAmount;
    }

    public void setPayAmount(BigDecimal payAmount) {
        this.payAmount = payAmount;
    }
}
