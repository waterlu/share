package cn.zjhf.kingold.trade.persistence.dao;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface TradeBillMapper {
    Integer insert(Map map);

    Map get(@Param("tradeOrderUuid") String tradeOrderUuid);

    void update(Map map);

    List<Map> getList(Map map);

    Integer getCount(Map map);
}