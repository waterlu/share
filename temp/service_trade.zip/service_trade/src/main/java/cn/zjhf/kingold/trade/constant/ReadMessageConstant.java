package cn.zjhf.kingold.trade.constant;

/**
 * Created by liuyao on 2017/10/27.
 */
public class ReadMessageConstant {
    public final static String CASH_COUPON_USER_UNREAD_MESSAGE_KEY = "service_base_unread_message_couponse_";
    public final static String INTEREST_COUPON_USER_UNREAD_MESSAGE_KEY = "service_base_unread_message_interest_couponse_";

}
