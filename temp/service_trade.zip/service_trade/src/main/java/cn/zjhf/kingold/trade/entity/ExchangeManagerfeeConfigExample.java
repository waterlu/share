package cn.zjhf.kingold.trade.entity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class ExchangeManagerfeeConfigExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private Integer limit;

    private Integer offset;

    public ExchangeManagerfeeConfigExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andExchangeManagerfeeIdIsNull() {
            addCriterion("exchange_managerfee_id is null");
            return (Criteria) this;
        }

        public Criteria andExchangeManagerfeeIdIsNotNull() {
            addCriterion("exchange_managerfee_id is not null");
            return (Criteria) this;
        }

        public Criteria andExchangeManagerfeeIdEqualTo(Long value) {
            addCriterion("exchange_managerfee_id =", value, "exchangeManagerfeeId");
            return (Criteria) this;
        }

        public Criteria andExchangeManagerfeeIdNotEqualTo(Long value) {
            addCriterion("exchange_managerfee_id <>", value, "exchangeManagerfeeId");
            return (Criteria) this;
        }

        public Criteria andExchangeManagerfeeIdGreaterThan(Long value) {
            addCriterion("exchange_managerfee_id >", value, "exchangeManagerfeeId");
            return (Criteria) this;
        }

        public Criteria andExchangeManagerfeeIdGreaterThanOrEqualTo(Long value) {
            addCriterion("exchange_managerfee_id >=", value, "exchangeManagerfeeId");
            return (Criteria) this;
        }

        public Criteria andExchangeManagerfeeIdLessThan(Long value) {
            addCriterion("exchange_managerfee_id <", value, "exchangeManagerfeeId");
            return (Criteria) this;
        }

        public Criteria andExchangeManagerfeeIdLessThanOrEqualTo(Long value) {
            addCriterion("exchange_managerfee_id <=", value, "exchangeManagerfeeId");
            return (Criteria) this;
        }

        public Criteria andExchangeManagerfeeIdIn(List<Long> values) {
            addCriterion("exchange_managerfee_id in", values, "exchangeManagerfeeId");
            return (Criteria) this;
        }

        public Criteria andExchangeManagerfeeIdNotIn(List<Long> values) {
            addCriterion("exchange_managerfee_id not in", values, "exchangeManagerfeeId");
            return (Criteria) this;
        }

        public Criteria andExchangeManagerfeeIdBetween(Long value1, Long value2) {
            addCriterion("exchange_managerfee_id between", value1, value2, "exchangeManagerfeeId");
            return (Criteria) this;
        }

        public Criteria andExchangeManagerfeeIdNotBetween(Long value1, Long value2) {
            addCriterion("exchange_managerfee_id not between", value1, value2, "exchangeManagerfeeId");
            return (Criteria) this;
        }

        public Criteria andExchangeManagerfeeTypeIsNull() {
            addCriterion("exchange_managerfee_type is null");
            return (Criteria) this;
        }

        public Criteria andExchangeManagerfeeTypeIsNotNull() {
            addCriterion("exchange_managerfee_type is not null");
            return (Criteria) this;
        }

        public Criteria andExchangeManagerfeeTypeEqualTo(Byte value) {
            addCriterion("exchange_managerfee_type =", value, "exchangeManagerfeeType");
            return (Criteria) this;
        }

        public Criteria andExchangeManagerfeeTypeNotEqualTo(Byte value) {
            addCriterion("exchange_managerfee_type <>", value, "exchangeManagerfeeType");
            return (Criteria) this;
        }

        public Criteria andExchangeManagerfeeTypeGreaterThan(Byte value) {
            addCriterion("exchange_managerfee_type >", value, "exchangeManagerfeeType");
            return (Criteria) this;
        }

        public Criteria andExchangeManagerfeeTypeGreaterThanOrEqualTo(Byte value) {
            addCriterion("exchange_managerfee_type >=", value, "exchangeManagerfeeType");
            return (Criteria) this;
        }

        public Criteria andExchangeManagerfeeTypeLessThan(Byte value) {
            addCriterion("exchange_managerfee_type <", value, "exchangeManagerfeeType");
            return (Criteria) this;
        }

        public Criteria andExchangeManagerfeeTypeLessThanOrEqualTo(Byte value) {
            addCriterion("exchange_managerfee_type <=", value, "exchangeManagerfeeType");
            return (Criteria) this;
        }

        public Criteria andExchangeManagerfeeTypeIn(List<Byte> values) {
            addCriterion("exchange_managerfee_type in", values, "exchangeManagerfeeType");
            return (Criteria) this;
        }

        public Criteria andExchangeManagerfeeTypeNotIn(List<Byte> values) {
            addCriterion("exchange_managerfee_type not in", values, "exchangeManagerfeeType");
            return (Criteria) this;
        }

        public Criteria andExchangeManagerfeeTypeBetween(Byte value1, Byte value2) {
            addCriterion("exchange_managerfee_type between", value1, value2, "exchangeManagerfeeType");
            return (Criteria) this;
        }

        public Criteria andExchangeManagerfeeTypeNotBetween(Byte value1, Byte value2) {
            addCriterion("exchange_managerfee_type not between", value1, value2, "exchangeManagerfeeType");
            return (Criteria) this;
        }

        public Criteria andProductUuidIsNull() {
            addCriterion("product_uuid is null");
            return (Criteria) this;
        }

        public Criteria andProductUuidIsNotNull() {
            addCriterion("product_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andProductUuidEqualTo(String value) {
            addCriterion("product_uuid =", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotEqualTo(String value) {
            addCriterion("product_uuid <>", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidGreaterThan(String value) {
            addCriterion("product_uuid >", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidGreaterThanOrEqualTo(String value) {
            addCriterion("product_uuid >=", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidLessThan(String value) {
            addCriterion("product_uuid <", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidLessThanOrEqualTo(String value) {
            addCriterion("product_uuid <=", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidLike(String value) {
            addCriterion("product_uuid like", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotLike(String value) {
            addCriterion("product_uuid not like", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidIn(List<String> values) {
            addCriterion("product_uuid in", values, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotIn(List<String> values) {
            addCriterion("product_uuid not in", values, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidBetween(String value1, String value2) {
            addCriterion("product_uuid between", value1, value2, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotBetween(String value1, String value2) {
            addCriterion("product_uuid not between", value1, value2, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductCodeIsNull() {
            addCriterion("product_code is null");
            return (Criteria) this;
        }

        public Criteria andProductCodeIsNotNull() {
            addCriterion("product_code is not null");
            return (Criteria) this;
        }

        public Criteria andProductCodeEqualTo(String value) {
            addCriterion("product_code =", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotEqualTo(String value) {
            addCriterion("product_code <>", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeGreaterThan(String value) {
            addCriterion("product_code >", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeGreaterThanOrEqualTo(String value) {
            addCriterion("product_code >=", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLessThan(String value) {
            addCriterion("product_code <", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLessThanOrEqualTo(String value) {
            addCriterion("product_code <=", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLike(String value) {
            addCriterion("product_code like", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotLike(String value) {
            addCriterion("product_code not like", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeIn(List<String> values) {
            addCriterion("product_code in", values, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotIn(List<String> values) {
            addCriterion("product_code not in", values, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeBetween(String value1, String value2) {
            addCriterion("product_code between", value1, value2, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotBetween(String value1, String value2) {
            addCriterion("product_code not between", value1, value2, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductTypeIsNull() {
            addCriterion("product_type is null");
            return (Criteria) this;
        }

        public Criteria andProductTypeIsNotNull() {
            addCriterion("product_type is not null");
            return (Criteria) this;
        }

        public Criteria andProductTypeEqualTo(String value) {
            addCriterion("product_type =", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeNotEqualTo(String value) {
            addCriterion("product_type <>", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeGreaterThan(String value) {
            addCriterion("product_type >", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeGreaterThanOrEqualTo(String value) {
            addCriterion("product_type >=", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeLessThan(String value) {
            addCriterion("product_type <", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeLessThanOrEqualTo(String value) {
            addCriterion("product_type <=", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeLike(String value) {
            addCriterion("product_type like", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeNotLike(String value) {
            addCriterion("product_type not like", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeIn(List<String> values) {
            addCriterion("product_type in", values, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeNotIn(List<String> values) {
            addCriterion("product_type not in", values, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeBetween(String value1, String value2) {
            addCriterion("product_type between", value1, value2, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeNotBetween(String value1, String value2) {
            addCriterion("product_type not between", value1, value2, "productType");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameIsNull() {
            addCriterion("product_abbr_name is null");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameIsNotNull() {
            addCriterion("product_abbr_name is not null");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameEqualTo(String value) {
            addCriterion("product_abbr_name =", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameNotEqualTo(String value) {
            addCriterion("product_abbr_name <>", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameGreaterThan(String value) {
            addCriterion("product_abbr_name >", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameGreaterThanOrEqualTo(String value) {
            addCriterion("product_abbr_name >=", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameLessThan(String value) {
            addCriterion("product_abbr_name <", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameLessThanOrEqualTo(String value) {
            addCriterion("product_abbr_name <=", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameLike(String value) {
            addCriterion("product_abbr_name like", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameNotLike(String value) {
            addCriterion("product_abbr_name not like", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameIn(List<String> values) {
            addCriterion("product_abbr_name in", values, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameNotIn(List<String> values) {
            addCriterion("product_abbr_name not in", values, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameBetween(String value1, String value2) {
            addCriterion("product_abbr_name between", value1, value2, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameNotBetween(String value1, String value2) {
            addCriterion("product_abbr_name not between", value1, value2, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andAppointProductTypeIsNull() {
            addCriterion("appoint_product_type is null");
            return (Criteria) this;
        }

        public Criteria andAppointProductTypeIsNotNull() {
            addCriterion("appoint_product_type is not null");
            return (Criteria) this;
        }

        public Criteria andAppointProductTypeEqualTo(String value) {
            addCriterion("appoint_product_type =", value, "appointProductType");
            return (Criteria) this;
        }

        public Criteria andAppointProductTypeNotEqualTo(String value) {
            addCriterion("appoint_product_type <>", value, "appointProductType");
            return (Criteria) this;
        }

        public Criteria andAppointProductTypeGreaterThan(String value) {
            addCriterion("appoint_product_type >", value, "appointProductType");
            return (Criteria) this;
        }

        public Criteria andAppointProductTypeGreaterThanOrEqualTo(String value) {
            addCriterion("appoint_product_type >=", value, "appointProductType");
            return (Criteria) this;
        }

        public Criteria andAppointProductTypeLessThan(String value) {
            addCriterion("appoint_product_type <", value, "appointProductType");
            return (Criteria) this;
        }

        public Criteria andAppointProductTypeLessThanOrEqualTo(String value) {
            addCriterion("appoint_product_type <=", value, "appointProductType");
            return (Criteria) this;
        }

        public Criteria andAppointProductTypeLike(String value) {
            addCriterion("appoint_product_type like", value, "appointProductType");
            return (Criteria) this;
        }

        public Criteria andAppointProductTypeNotLike(String value) {
            addCriterion("appoint_product_type not like", value, "appointProductType");
            return (Criteria) this;
        }

        public Criteria andAppointProductTypeIn(List<String> values) {
            addCriterion("appoint_product_type in", values, "appointProductType");
            return (Criteria) this;
        }

        public Criteria andAppointProductTypeNotIn(List<String> values) {
            addCriterion("appoint_product_type not in", values, "appointProductType");
            return (Criteria) this;
        }

        public Criteria andAppointProductTypeBetween(String value1, String value2) {
            addCriterion("appoint_product_type between", value1, value2, "appointProductType");
            return (Criteria) this;
        }

        public Criteria andAppointProductTypeNotBetween(String value1, String value2) {
            addCriterion("appoint_product_type not between", value1, value2, "appointProductType");
            return (Criteria) this;
        }

        public Criteria andFeeRateIsNull() {
            addCriterion("fee_rate is null");
            return (Criteria) this;
        }

        public Criteria andFeeRateIsNotNull() {
            addCriterion("fee_rate is not null");
            return (Criteria) this;
        }

        public Criteria andFeeRateEqualTo(BigDecimal value) {
            addCriterion("fee_rate =", value, "feeRate");
            return (Criteria) this;
        }

        public Criteria andFeeRateNotEqualTo(BigDecimal value) {
            addCriterion("fee_rate <>", value, "feeRate");
            return (Criteria) this;
        }

        public Criteria andFeeRateGreaterThan(BigDecimal value) {
            addCriterion("fee_rate >", value, "feeRate");
            return (Criteria) this;
        }

        public Criteria andFeeRateGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("fee_rate >=", value, "feeRate");
            return (Criteria) this;
        }

        public Criteria andFeeRateLessThan(BigDecimal value) {
            addCriterion("fee_rate <", value, "feeRate");
            return (Criteria) this;
        }

        public Criteria andFeeRateLessThanOrEqualTo(BigDecimal value) {
            addCriterion("fee_rate <=", value, "feeRate");
            return (Criteria) this;
        }

        public Criteria andFeeRateIn(List<BigDecimal> values) {
            addCriterion("fee_rate in", values, "feeRate");
            return (Criteria) this;
        }

        public Criteria andFeeRateNotIn(List<BigDecimal> values) {
            addCriterion("fee_rate not in", values, "feeRate");
            return (Criteria) this;
        }

        public Criteria andFeeRateBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("fee_rate between", value1, value2, "feeRate");
            return (Criteria) this;
        }

        public Criteria andFeeRateNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("fee_rate not between", value1, value2, "feeRate");
            return (Criteria) this;
        }
    }

    /**
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}