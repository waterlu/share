package cn.zjhf.kingold.trade.service;


import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.dto.TradeOrderDto;
import cn.zjhf.kingold.trade.entity.TradePaymentSummary;
import cn.zjhf.kingold.trade.vo.TradeOrderVO;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;


/**
 * 定期交易相关接口
 *
 * Created by wangxun on 2016/11/04.
 * Copyright by zjinv
 */
public interface ITradeOrderService {

//
//    public Map getWithFilter(Map params) throws BusinessException;
//
//
//    public Map insert(Map userInfo) throws BusinessException;
//
//    public int update(Map userInfo) throws BusinessException;
//
//    public Integer delete(Map params) throws BusinessException;

    List<Map> getList(Map userMap) throws BusinessException;

    /**
     * 订单查询（现仅用于订单列表导出）
     * @param dto
     * @return
     * @throws BusinessException
     */
    List<TradeOrderVO> getOrderList(TradeOrderDto dto ) throws BusinessException;

    Integer getCount(Map userMap) throws BusinessException;

    /**
     * 根据交易编号获取定期交易单
     *
     * @param orderBillCode 交易编号
     * @return
     * @throws BusinessException
     */
    Map getTradeOrder(String orderBillCode) throws BusinessException;


    BigDecimal querySumAmountByUser(String userUuid) throws BusinessException;


    /**
     * 根据产品uuid获取产品还款信息
     *
     * @param productUuid
     * @return
     * @throws BusinessException
     */
    TradePaymentSummary getTradePaymentSummary(String productUuid) throws BusinessException;

}