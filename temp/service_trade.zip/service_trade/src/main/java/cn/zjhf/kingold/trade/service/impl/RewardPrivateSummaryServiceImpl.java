package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.constant.RewardError;
import cn.zjhf.kingold.trade.constant.RewardPrivateStatus;
import cn.zjhf.kingold.trade.constant.Separator;
import cn.zjhf.kingold.trade.dto.RewardPrivateSearchDto;
import cn.zjhf.kingold.trade.entity.Reward;
import cn.zjhf.kingold.trade.entity.RewardPrivateFund;
import cn.zjhf.kingold.trade.persistence.dao.RewardMapper;
import cn.zjhf.kingold.trade.persistence.dao.RewardPrivateFundMapper;
import cn.zjhf.kingold.trade.persistence.mq.message.RewardPrivateFundMessage;
import cn.zjhf.kingold.trade.persistence.mq.producer.RewardPrivateFundProducer;
import cn.zjhf.kingold.trade.service.IRewardPrivateSummaryService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * Created by lutiehua on 2017/6/7.
 */
@Service
public class RewardPrivateSummaryServiceImpl implements IRewardPrivateSummaryService {

    private final Logger LOGGER = LoggerFactory.getLogger(RewardPrivateSummaryServiceImpl.class);

    @Autowired
    private RewardPrivateFundMapper rewardPrivateFundMapper;

    @Autowired
    private RewardMapper rewardMapper;


    @Autowired
    private RewardPrivateFundProducer rewardPrivateFundProducer;

    @Override
    public List<RewardPrivateFund> searchRewardPrivate(RewardPrivateSearchDto rewardSearchDto) throws BusinessException {
        return rewardPrivateFundMapper.searchRewardPrivate(rewardSearchDto);
    }

    @Override
    public int searchRewardPrivateCount(RewardPrivateSearchDto rewardSearchDto) throws BusinessException {
        return rewardPrivateFundMapper.searchRewardPrivateCount(rewardSearchDto);
    }

    @Override
    public RewardPrivateFund getAwardPrivate(String rewardPrivateBillCode) throws BusinessException {
        return rewardPrivateFundMapper.selectByPrimaryKey(rewardPrivateBillCode);
    }

    /**
     * 批量审核
     *
     * @param param
     * @return
     */
    @Transactional(rollbackFor = BusinessException.class)
    public ResponseResult updateCheckStatus(Map<String, Object> param) throws BusinessException {
        List<String> finishList = new ArrayList<>();
        List<String> failedList = new ArrayList<>();

        String rewardPrivateBillCode = param.get("rewardPrivateBillCode").toString();
        int pass = Integer.parseInt(param.get("pass").toString());
        String [] billCodeList = rewardPrivateBillCode.split(Separator.DATA_SEPARATOR);
        for (String billCode : billCodeList) {
            if (pass == 1) {
                LOGGER.info("审核通过私募产品佣金：{}", billCode);
            } else {
                LOGGER.info("审核不通过私募产品佣金：{}", billCode);
            }

            RewardPrivateFund rewardPrivateFund = rewardPrivateFundMapper.selectByPrimaryKey(billCode);
            int status = rewardPrivateFund.getRewardPrivateStatus();
            LOGGER.info("status={}", status);
            if (status != RewardPrivateStatus.INIT && status!= RewardPrivateStatus.REJECT) {
                LOGGER.info("私募产品佣金状态错误：{}", status);
                failedList.add(billCode);
            } else {
                // 更新私募产品佣金状态
                LOGGER.info("更新私募产品佣金状态");
                param.put("rewardPrivateBillCode", billCode);
                rewardPrivateFundMapper.updateCheckStatus(param);

                if (pass == 1) {
                    // 更新奖励记录状态
                    LOGGER.info("更新奖励记录状态");
                    Map<String, Object> paramReward = new HashMap<>();
                    paramReward.put("summaryBillCode", billCode);
                    paramReward.put("checkTime", new Date());
                    rewardMapper.updateCheckTime(paramReward);
                }

                finishList.add(billCode);
            }
        }

        StringBuffer buffer = new StringBuffer();
        if (finishList.size() > 0) {
            buffer.append(RewardError.CHECK_FINISH_TXT);
            buffer.append("\n");
            for(String billCode : finishList) {
                buffer.append(billCode);
                buffer.append("\n");
            }

            buffer.append("\n");
            buffer.append("\n");
        }

        if (failedList.size() > 0) {
            buffer.append(RewardError.CHECK_FAILED_TXT);
            buffer.append("\n");
            for(String billCode : failedList) {
                buffer.append(billCode);
                buffer.append("\n");
            }
        }

        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(buffer.toString());
        return responseResult;
    }

    /**
     * 批量发放
     *
     * @param param
     * @return
     * @throws BusinessException
     */
    @Transactional(rollbackFor = BusinessException.class)
    public ResponseResult updateClearStatus(Map<String, Object> param) throws BusinessException {
        List<String> finishList = new ArrayList<>();
        List<String> failedList = new ArrayList<>();

        String rewardPrivateBillCode = param.get("rewardPrivateBillCode").toString();
        int pass = Integer.parseInt(param.get("pass").toString());
        String [] billCodeList = rewardPrivateBillCode.split(Separator.DATA_SEPARATOR);
        for (String billCode : billCodeList) {
            LOGGER.info("发放私募产品佣金：{}", billCode);

            RewardPrivateFund rewardPrivateFund = rewardPrivateFundMapper.selectByPrimaryKey(billCode);
            int status = rewardPrivateFund.getRewardPrivateStatus();
            LOGGER.info("status={}", status);
            if (status != RewardPrivateStatus.CHECKED) {
                LOGGER.info("私募产品佣金状态错误：{}", status);
                failedList.add(billCode);
            } else {
                // 更新私募产品佣金状态
                LOGGER.info("更新私募产品佣金状态");
                param.put("rewardPrivateBillCode", billCode);
                rewardPrivateFundMapper.updateClearStatus(param);

                if (pass == 1) {
                    // 更新奖励记录状态
                    LOGGER.info("更新奖励记录状态");
                    List<Reward> rewardList = rewardMapper.queryBySummaryBillCode(billCode);
                    for (Reward reward : rewardList) {
                        Map<String, Object> paramReward = new HashMap<>();
                        paramReward.put("clearTime", new Date());
                        paramReward.put("payAmount", reward.getRewardAmount());
                        paramReward.put("rewardBillCode", reward.getRewardBillCode());
                        rewardMapper.updateClearTime(paramReward);
                    }

                    //私募奖励发送mq消息
                    RewardPrivateFundMessage message = new RewardPrivateFundMessage();
                    message.setRewardPrivateFund(rewardPrivateFund);
                    rewardPrivateFundProducer.send(message);

                }

                finishList.add(billCode);
            }
        }

        StringBuffer buffer = new StringBuffer();
        if (finishList.size() > 0) {
            buffer.append(RewardError.CLEAR_FINISH_TXT);
            buffer.append("\n");
            for(String billCode : finishList) {
                buffer.append(billCode);
                buffer.append("\n");
            }

            buffer.append("\n");
            buffer.append("\n");
        }

        if (failedList.size() > 0) {
            buffer.append(RewardError.CLEAR_FAILED_TXT);
            buffer.append("\n");
            for(String billCode : failedList) {
                buffer.append(billCode);
                buffer.append("\n");
            }
        }

        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(buffer.toString());
        return responseResult;
    }

}
