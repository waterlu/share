package cn.zjhf.kingold.trade.dto;

import cn.zjhf.kingold.common.param.ParamVO;

/**
 * @author lutiehua
 * @date 2018/3/16
 */
public class UpdateTradeStatusDTO extends ParamVO {

    public String getOrderBillCode() {
        return orderBillCode;
    }

    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    /**
     * 订单号
     */
    private String orderBillCode;

}
