package cn.zjhf.kingold.trade.baofoo;

import java.util.*;

/**
 * Created by lutiehua on 2017/4/26.
 */
public class Map2Xml {

    /**
     * Map转XML
     *
     * @param param
     * @param rootString
     * @return
     * @throws Exception
     */
    public static String convert(Map<String, Object> param, String rootString) throws Exception {
        StringBuilder xmlString = new StringBuilder();
        xmlString.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        xmlString.append("<" + rootString + ">");
        for (String key : param.keySet()){
            xmlString.append("<").append(key.toString()).append(">");
            xmlString.append(convertString(param.get(key)));
            xmlString.append("</"+key.toString()+">");
        }
        xmlString.append("</" + rootString +">");
        return xmlString.toString();
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    private static String convertString(Object param) throws Exception{
        StringBuilder xmlString = new StringBuilder();
        if(param == null) {
            return "";
        } else if(param instanceof String) {
            return param.toString();
        } else if (param instanceof Long) {
            Long longValue = (Long) param;
            return Long.toString(longValue);
        } else if (param instanceof Integer) {
            Integer intValue = (Integer) param;
            return Integer.toString(intValue);
        } else if (param instanceof Double) {
            Double doubleValue = (Double) param;
            return Double.toString(doubleValue);
        } else if(param instanceof ArrayList) {
            List<Object> mapList = (List<Object>) param;
            Iterator it = mapList.iterator();
            while(it.hasNext()){
                xmlString.append(convertString(it.next()));
            }
        } else if(param instanceof HashMap) {
            Map mapTemp = (HashMap) param;
            for (Object key : mapTemp.keySet()){
                xmlString.append("<").append(key.toString()).append(">");
                xmlString.append(convertString(mapTemp.get(key)));
                xmlString.append("</").append(key.toString()).append(">");
            }
        } else{
            throw new Exception("Unknown:" + param.getClass().toString());
        }

        return xmlString.toString();
    }
}
