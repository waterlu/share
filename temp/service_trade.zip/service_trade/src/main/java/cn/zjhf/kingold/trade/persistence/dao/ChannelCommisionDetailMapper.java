package cn.zjhf.kingold.trade.persistence.dao;

import cn.zjhf.kingold.trade.entity.ChannelCommisionDetail;
import cn.zjhf.kingold.trade.entity.ChannelCommisionDetailExample;
import java.util.List;

import cn.zjhf.kingold.trade.utils.QueryUtils;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface ChannelCommisionDetailMapper {
    long countByExample(ChannelCommisionDetailExample example);

    int deleteByExample(ChannelCommisionDetailExample example);

    @Delete("DELETE FROM channel_commision_detail WHERE product_uuid = #{productUuid} AND merchant_num = #{merchantNum} ")
    int deleteByProductMerchant(@Param("productUuid") String productUuid, @Param("merchantNum") String merchantNum);

    int deleteByPrimaryKey(Long channelCommisionDetailId);

    int insert(ChannelCommisionDetail record);

    int insertSelective(ChannelCommisionDetail record);

    @Select("${condition}")
    @ResultMap("BaseResultMap")
    List<ChannelCommisionDetail> lstItemDatas(QueryUtils condition);

    @Update("${condition}")
    int updateDetail(QueryUtils condition);

    List<ChannelCommisionDetail> selectByExample(ChannelCommisionDetailExample example);

    ChannelCommisionDetail selectByPrimaryKey(Long channelCommisionDetailId);

    int updateByExampleSelective(@Param("record") ChannelCommisionDetail record, @Param("example") ChannelCommisionDetailExample example);

    int updateByExample(@Param("record") ChannelCommisionDetail record, @Param("example") ChannelCommisionDetailExample example);

    int updateByPrimaryKeySelective(ChannelCommisionDetail record);

    int updateByPrimaryKey(ChannelCommisionDetail record);
}