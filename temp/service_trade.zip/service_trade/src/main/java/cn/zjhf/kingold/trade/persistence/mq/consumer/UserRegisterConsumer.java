package cn.zjhf.kingold.trade.persistence.mq.consumer;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.rocketmq.annotation.RocketMQConsumer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQConsumer;
import cn.zjhf.kingold.service_consumer.service.UserServiceConsumer;
import cn.zjhf.kingold.trade.constant.BizDefine;
import cn.zjhf.kingold.trade.constant.MarketCampaignCodeEnum;
import cn.zjhf.kingold.trade.constant.URL;
import cn.zjhf.kingold.trade.dto.CouponSendConditionDto;
import cn.zjhf.kingold.trade.persistence.dao.OperationReportMapper;
import cn.zjhf.kingold.trade.persistence.mq.message.UserMessage;
import cn.zjhf.kingold.trade.service.IMarketCampaignService;
import cn.zjhf.kingold.trade.utils.DataUtils;
import cn.zjhf.kingold.trade.utils.DateUtil;
import cn.zjhf.kingold.trade.utils.QueryUtils;
import cn.zjhf.kingold.trade.utils.Tuple.TwoTuple;
import cn.zjhf.kingold.trade.utils.WhereCondition;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 用户注册成功，红包
 * <p>
 * Created by lutiehua on 2017/7/14.
 */
@RocketMQConsumer(topic = "user", tag = "register")
public class UserRegisterConsumer extends AbstractMQConsumer<UserMessage> {

    private final Logger LOGGER = LoggerFactory.getLogger(UserRegisterConsumer.class);

    @Autowired
    private IMarketCampaignService marketCampaignService;

    @Autowired
    private UserServiceConsumer userServiceConsumer;

    @Autowired
    private OperationReportMapper operationReportMapper;

    /**
     * 检查注册时间，只筛选出两小时之内的注册时间
     * @param userUuid
     * @return true 近期消息，继续处理；false 远期消息，放弃处理
     */
    private boolean checkRegistTime(String userUuid) {
        if(DataUtils.isNotEmpty(userUuid)) {
            String sql = "SELECT create_time FROM kingold_user.user WHERE user_uuid="
                    + WhereCondition.toSQLStr(userUuid)
                    + " AND delete_flag=0 ORDER BY create_time DESC LIMIT 0,1 ";
            String occuTimeStr = operationReportMapper.lstSingleString(new QueryUtils(sql));

            if(DataUtils.isNotEmpty(occuTimeStr)) {
                Date occuTime = DateUtil.strToTime(occuTimeStr);
                if(occuTime!=null) {
                    int diffTime = (int) (((new Date()).getTime() - occuTime.getTime()) / (1000 * 3600));
                    return diffTime <= 1;
                }
            }
        }

        return false;
    }

    private boolean insertCerLog(int key, String value) {
        int ret = -1;

        try {
            ret = operationReportMapper.insertCerMqLog(key, value);
        }catch(Exception e) {
            LOGGER.error("插入失败", e);
        }

        LOGGER.info("ret: ", ret);
        return ret > 0;
    }

    @Override
    public ResponseResult process(UserMessage userRegisterMessage) throws BusinessException {
        LOGGER.info("用户注册消息 {}", userRegisterMessage);
        //判断商户号不是金疙瘩不发放优惠券
        if (StringUtils.isNotBlank(userRegisterMessage.getMerchantNum()) && !BizDefine.KINGOLD_MERCHANT.equals(userRegisterMessage.getMerchantNum())) {
            logger.info("用户注册渠道商户号是：{}", userRegisterMessage.getMerchantNum());
            return new ResponseResult();
        }

        if(checkRegistTime(userRegisterMessage.getUserUuid())) {
            String inviterUuid = userRegisterMessage.getInviterUuid();
            if(DataUtils.isNotEmpty(inviterUuid)) {
                if(insertCerLog(MarketCampaignCodeEnum.BEING_INVITED_REGISTER.getCode(), inviterUuid + "&&" + userRegisterMessage.getUserUuid())) {
                    try {
                        TwoTuple<Integer, String> ret = marketCampaignService.marketCampaignTrigger(new CouponSendConditionDto(inviterUuid, MarketCampaignCodeEnum.BEING_INVITED_REGISTER.getCode(), null, userRegisterMessage.getUserUuid()));
                        LOGGER.info(ret.toString());
                    } catch (BusinessException e) {
                        LOGGER.error("UserRegisterConsumer fail", e);
                    }
                }else {
                    LOGGER.info("已处理过");
                }
            }

            if(insertCerLog(MarketCampaignCodeEnum.REGISTER.getCode(), userRegisterMessage.getUserUuid())) {
                try {
                    TwoTuple<Integer, String> ret = marketCampaignService.marketCampaignTrigger(new CouponSendConditionDto(userRegisterMessage.getUserUuid(), MarketCampaignCodeEnum.REGISTER.getCode(), null, null));
                    LOGGER.info(ret.toString());
                } catch (BusinessException e) {
                    logger.error("UserRegisterConsumer fail", e);
                }
            }else {
                LOGGER.info("已处理过");
            }
        }

        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        LOGGER.info("用户注册消息 END {}", responseResult);
        return responseResult;
    }

    private String getInviterUuid(String userUuid) throws BusinessException {
        Map params = new HashMap();
        params.put("userUuid", userUuid);
        ResponseResult result = userServiceConsumer.get(String.format(URL.URL_GET_USER, userUuid), params);
        if (result.isSuccessful()) {
            Map<String, Object> userInfo = (Map)result.getData();
            return userInfo.get("inviterUuid") == null ? null : userInfo.get("inviterUuid").toString();
        } else if (result.getCode() == 1109) {//用户被冻结
            logger.error("sendCoupon first invest user freezing. userUuid={}", userUuid);
            return null;
        } else {
            LOGGER.error("getInviterUuid get user info error.resultCode={}, msg={}", result.getCode(), result.getMsg());
            throw new BusinessException(result.getCode(), result.getMsg(), true);
        }
    }
}