package cn.zjhf.kingold.trade.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.UUID;

/**
 * Created by zhangyijie on 2017/5/19.
 */
public class UUIDKeyUtils {
    protected static final Logger logger = LoggerFactory.getLogger(UUIDKeyUtils.class);

    public static String getUuidKey() {
        return UUID.randomUUID().toString().replace("-", "");

    }

}
