package cn.zjhf.kingold.trade.persistence.dao;

import cn.zjhf.kingold.trade.dto.RewardPrivateSearchDto;
import cn.zjhf.kingold.trade.entity.RewardPrivateFund;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface RewardPrivateFundMapper {
    int deleteByPrimaryKey(String rewardPrivateBillCode);

    int insert(RewardPrivateFund record);

    int insertSelective(RewardPrivateFund record);

    RewardPrivateFund selectByPrimaryKey(String rewardPrivateBillCode);

    int updateByPrimaryKeySelective(RewardPrivateFund record);

    int updateByPrimaryKey(RewardPrivateFund record);

    /**
     * 查询私募奖励发放记录
     *
     * @param rewardPrivateSearchDto
     * @return
     */
    List<RewardPrivateFund> searchRewardPrivate(RewardPrivateSearchDto rewardPrivateSearchDto);

    /**
     * 查询私募奖励发放记录总条数
     *
     * @param rewardPrivateSearchDto
     * @return
     */
    int searchRewardPrivateCount(RewardPrivateSearchDto rewardPrivateSearchDto);

    /**
     * 更新审核状态
     *
     * @param param
     * @return
     */
    int updateCheckStatus(Map<String, Object> param);

    /**
     * 更新发放状态
     *
     * @param param
     * @return
     */
    int updateClearStatus(Map<String, Object> param);

    /**
     * 根据产品+用户查询私募奖励汇总记录条数
     *
     * @param param
     * @return
     */
    int queryByProductAndUser(Map<String, Object> param);
}