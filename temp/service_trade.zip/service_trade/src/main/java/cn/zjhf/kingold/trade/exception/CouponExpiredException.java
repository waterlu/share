package cn.zjhf.kingold.trade.exception;

import cn.zjhf.kingold.common.exception.BusinessException;

/**
 * 优惠券状态异常
 *
 * @author lutiehua
 * @date 2018/3/9
 */
public class CouponExpiredException extends BusinessException {

    public CouponExpiredException() {
        super(6022, "优惠券已经过期");
    }

}
