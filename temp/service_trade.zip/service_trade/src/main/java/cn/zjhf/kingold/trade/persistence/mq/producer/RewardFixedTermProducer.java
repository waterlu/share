package cn.zjhf.kingold.trade.persistence.mq.producer;

import cn.zjhf.kingold.rocketmq.annotation.RocketMQProducer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQProducer;
import cn.zjhf.kingold.trade.persistence.mq.message.RewardFixedTermMessage;

/**
 * Created by Xiaody on 17/7/27.
 */
@RocketMQProducer(topic = "reward", tag = "fixedTerm")
public class RewardFixedTermProducer extends AbstractMQProducer<RewardFixedTermMessage> {
}
