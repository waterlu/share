package cn.zjhf.kingold.trade.dto;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * 礼券发放条件
 */
public class CouponSendConditionDto extends ParamVO{

    @ApiModelProperty(required = true, value = "用户uuid")
    @NotEmpty
    private String userUuid;

    @ApiModelProperty(required = true, value = "活动编号")
    @NotEmpty
    private Integer mcCode;

    @ApiModelProperty(required = true, value = "orderBillCode")
    @NotEmpty
    private String orderBillCode;

    @ApiModelProperty(required = true, value = "被邀请用户UUID")
    private String invitedUserUuid;

    @ApiModelProperty(required = false, value = "生成领取的礼券code")
    private String couponExtendCode;

    public CouponSendConditionDto() {
    }
    public CouponSendConditionDto(String userUuid,Integer mcCode,String orderBillCode,String invitedUserUuid) {
        this.userUuid = userUuid;
        this.mcCode = mcCode;
        this.orderBillCode = orderBillCode;
        this.invitedUserUuid = invitedUserUuid;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public Integer getMcCode() {
        return mcCode;
    }

    public void setMcCode(Integer mcCode) {
        this.mcCode = mcCode;
    }

    public String getOrderBillCode() {
        return orderBillCode;
    }

    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    public String getInvitedUserUuid() {
        return invitedUserUuid;
    }

    public void setInvitedUserUuid(String invitedUserUuid) {
        this.invitedUserUuid = invitedUserUuid;
    }

    public String getCouponExtendCode() {
        return couponExtendCode;
    }

    public void setCouponExtendCode(String couponExtendCode) {
        this.couponExtendCode = couponExtendCode;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("userUuid:" + DataUtils.toString(userUuid) + ", ");
        sb.append("orderBillCode:" + DataUtils.toString(orderBillCode) + ", ");
        sb.append("invitedUserUuid:" + DataUtils.toString(invitedUserUuid) + ", ");
        sb.append("mcCode:" + DataUtils.toString(mcCode));
        sb.append("couponExtendCode:" + DataUtils.toString(couponExtendCode));
        return sb.toString();
    }
}
