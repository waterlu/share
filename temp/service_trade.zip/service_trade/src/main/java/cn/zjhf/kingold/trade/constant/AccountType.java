package cn.zjhf.kingold.trade.constant;

/**
 * Created by likenice on 17/3/20.
 */

public class AccountType {
    //11平台托管账户；12平台结算账户；21投资人宝付托管账户；31融资人宝付托管账户；

    /**
     * 账户类型 11平台托管账户
     */
    public static final String ACCOUNT_TYPE_PLATFORM_TRUST = "11";

    /**
     * 账户类型 12平台结算账户
     */
    public static final String ACCOUNT_TYPE_PLATFORM_SETTLEMENT = "12";

    /**
     * 账户类型 21投资人宝付托管账户
     */
    public static final String ACCOUNT_TYPE_INVESTOR = "21";

    /**
     * 账户类型 31融资人宝付托管账户
     */
    public static final String ACCOUNT_TYPE_FINANCIER = "31";

    /**
     * 账户类型 41宝付清算账户
     */
    public static final String ACCOUNT_TYPE_BAOFOO = "41";
}

