package cn.zjhf.kingold.trade.constant;

/**
 * Created by Xiaody on 17/4/20.
 */
public class TradeConstants {


    /**
     * 私募订单状态－待审核
     */
    public static final int PFO_STAUTS_WAIT_AUDIT = 0;
    /**
     * 私募订单状态－待确认
     */
    public static final int PFO_STAUTS_WAIT_VERIFY = 1;

    /**
     * 私募订单状态－审核驳回 （审核驳回后，只能从新生成订单。）
     */
    public static final int PFO_STAUTS_AUDIT_FAIL = 11;

    /**
     * 私募订单状态－确认驳回 （等同 待审核）
     */
    public static final int PFO_STAUTS_VERIFY_FAIL = 12;

    /**
     * 私募订单状态－已确认
     */
    public static final int PFO_STAUTS_DONE = 2;


}
