package cn.zjhf.kingold.trade.entity.InVO.CommGrant;

/**
 * Created by zhangyijie on 2018/2/2.
 */
public class RedPacketGrantVO extends CommGrantItemBaseVO {

    /**
     * 现金红包金额
     */
    private double redPacketAmt;

    public double getRedPacketAmt() {
        return redPacketAmt;
    }

    public void setRedPacketAmt(double redPacketAmt) {
        this.redPacketAmt = redPacketAmt;
    }

    @Override
    public String toString() {
        return "RedPacketGrantVO{" +
                super.toString() +
                "redPacketAmt=" + redPacketAmt +
                '}';
    }
}
