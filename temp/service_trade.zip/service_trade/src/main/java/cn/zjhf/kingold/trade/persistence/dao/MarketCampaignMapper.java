package cn.zjhf.kingold.trade.persistence.dao;

import cn.zjhf.kingold.trade.dto.MarketCampaignDto;
import cn.zjhf.kingold.trade.entity.MarketCampaign;
import cn.zjhf.kingold.trade.entity.MarketCampaignExample;
import cn.zjhf.kingold.trade.utils.WhereCondition;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Mapper
public interface MarketCampaignMapper {
    long countByExample(MarketCampaignExample example);

    int deleteByExample(MarketCampaignExample example);

    int deleteByPrimaryKey(Integer mcId);

    int insert(MarketCampaign record);

    int insertSelective(MarketCampaign record);

    List<MarketCampaign> selectByExample(MarketCampaignExample example);

    @Select("SELECT Count(*) FROM market_campaign ${condition}")
    int lstCountByCondition(WhereCondition condition);

    @Update("UPDATE market_campaign SET mc_status = #{newStatus}, update_user_id = 'sys'  " +
            "WHERE mc_id = #{mcId}")
    int updateStatus(@Param("mcId") int mcId, @Param("newStatus") int newStatus);

    @Select("SELECT Count(*) FROM market_campaign WHERE mc_id = #{mcId}")
    int isExists(@Param("mcId") String mcId);

    List<MarketCampaign> lstByCondition(WhereCondition condition);

    MarketCampaign selectByPrimaryKey(Integer mcId);

    int updateByExampleSelective(@Param("record") MarketCampaign record, @Param("example") MarketCampaignExample example);

    int updateByExample(@Param("record") MarketCampaign record, @Param("example") MarketCampaignExample example);

    /**
     * 更新活动场景可选部分字段
     * @param marketCampaign
     * @return
     */
    int updateByPrimaryKeySelective(MarketCampaign marketCampaign);

    /**
     * 更新活动场景全字段
     * @param record
     * @return
     */
    int updateByPrimaryKey(MarketCampaign record);

    /**
     * 获取金币场景列表
     * @param marketCampaignDto
     * @return
     */
    List<MarketCampaign> getMarketCampaignList(MarketCampaignDto marketCampaignDto);

    /**
     * 获取金币场景数量
     * @param marketCampaignDto
     * @return
     */
    int getMarketCampaignCount(MarketCampaignDto marketCampaignDto);
}