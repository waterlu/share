package cn.zjhf.kingold.trade.utils.Tuple;

/**
 * Created by zhangyijie on 2017/6/2.
 */
public class TwoTuple<A, B> {
    public final A first;
    public final B second;
    public TwoTuple(A a, B b) {
        first = a;
        second = b;
    }

    @Override
    public String toString() {
        return ((first != null) ? first.toString() : null) + ", " + ((second != null) ? second.toString() : null);
    }
}
