package cn.zjhf.kingold.trade.constant;

import sun.java2d.pipe.AAShapePipe;

/**
 * 交易类型
 *
 * Created by DELL on 2017/4/28.
 */
public interface TradeType {
    /**
     * 1.1 充值单
     */
    String TRADE_RE_CHARGE = "RCX";

    /**
     * 1.2 提现单
     */
    String TRADE_WITH_DROW = "WDX";

    /**
     * 1.3 日常_充值提现手续费_流水记录
     */
    String TRADE_WITHDRAW_FACTORAGE = "WFX";


    /**
     * 2.1 订单
     */
    String TRADE_PRODUCT_ORDER = "POX";

    /**
     * 2.2 投资单
     */
    String TRADE_INVEST = "INX";

    /**
     * 2.3 退款单
     */
    String TRADE_RE_FUND = "RFX";


    /**
     * 3.1 产品成立_客户资金
     */
    String TRADE_ACCOUNT_AMOUNT = "AAX";

    /**
     * 3.2 产品成立_平台营销费用
     */
    String TRADE_MARKETING_AMOUNT = "MAX";

    /**
     * 3.3 放款单
     */
    String TRADE_PAYMENT = "PAX";


    /**
     * 4.1 产品成立_平台佣金
     */
    String TRADE_COMMISION_PAYMENT_SYSTEM = "CPS";


    /**
     * 5.1 产品成立_理财顾问业绩
     */
    String TRADE_COMMISION_PAYMENT_ADVISER = "CPA";

    /**
     * 5.2 产品成立_1度邀请奖励佣金
     */
    String TRADE_COMMISION_PAYMENT_ONE_LEVEL = "CPO";

    /**
     * 5.3 产品成立_2度邀请奖励佣金
     */
    String TRADE_COMMISION_PAYMENT_TWO_LEVEL = "CPT";

    /**
     * 5.4 产品成立_私募服务津贴
     */
    String TRADE_COMMISION_PAYMENT_PRIVATE_PLACEMENT = "CPP";

    /**
     * 5.5 活动奖励(现金红包/导入用户发红包)
     */
    String TRADE_COMMISION_PAYMENT_EXPERIENCE_ACTIVITY = "CPE";

    /**
     * 5.6 邀请奖励
     */
    String TRADE_REWARD_SALE = "RSA";

    /**
     * 5.7 一度邀请津贴
     */
    String TRADE_REWARD_INVITER_ONE = "RIO";

    /**
     * 5.8 二度邀请津贴
     */
    String TRADE_REWARD_INVITER_TWO = "RIT";

    /**
     * 5.9 服务津贴
     */
    String TRADE_REWARD_SERVICE = "RSE";


    /**
     * 6.1 产品到期_融资方返还本金
     */
    String TRADE_PRINCIPAL_PAYMENT = "RPX";

    /**
     * 6.2 产品到期_融资方返还收益
     */
    String TRADE_PROFIT_PAYMENT = "IPX";

    /**
     * 6.3 产品到期_平台返还营销加息；
     */
    String TRADE_ADDED_INTEREST = "AIX";

    /**
     * 6.4 体验金产品到期_返还收益
     */
    String EXPERIENCE_PROFIT_PAYMENT = "EPP";

    /**
     * 9.1 回退（执行失败）
     */
    String TRADE_EXECUTE_ERROR = "EEX";

    /**
     * 定期奖励汇总
     */
    String TRADE_REWARD_FIXED_SUMMARY = "RFS";

    /**
     * 私募奖励汇总
     */
    String TRADE_REWARD_PRIVATE_FUND = "RPF";

    /**
     * 服务津贴汇总
     */
    String TRADE_REWARD_SERVICE_SUMMARY = "RSS";

    /**
     * 转账
     */
    String TRADE_P_TO_C = "TPC";

    /**
     * 宝付失败
     */
    String TRADE_BAOFOO_FAIL = "BFF";

    /**
     * 定期奖励汇总批次
     */
    String TRADE_REWARD_FIXED_SUMMARY_BATCH = "RFB";

    /**
     * 服务津贴汇总批次
     */
    String TRADE_REWARD_SERVICE_SUMMARY_BATCH = "RSB";
}
