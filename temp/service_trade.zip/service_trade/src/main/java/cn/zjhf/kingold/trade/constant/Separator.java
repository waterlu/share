package cn.zjhf.kingold.trade.constant;

/**
 * Created by lutiehua on 2017/6/12.
 */
public interface Separator {

    String DATA_SEPARATOR = "\\$\\$";

    String DATA = "$$";
}
