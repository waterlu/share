package cn.zjhf.kingold.trade.service;


import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.dto.AccountTransactionDto;
import cn.zjhf.kingold.trade.utils.WhereCondition;
import cn.zjhf.kingold.trade.vo.AccountTransactionVO;

import java.util.List;
import java.util.Map;


/**
 * Created by wangxun on 2016/11/04.
 * Copyright by zjinv
 */
public interface IAccountTransactionService {

    /**
     * 通过userID获取用户信息
     * @return 用户
     * @throws BusinessException 业务异常
     */
    public Map get(Map params) throws BusinessException;

    /**
     * 创建账户流水
     *
     * 注：请在账户信息操作后在记录流水。
     *
     * @param userInfo
     * @return
     * @throws BusinessException
     */
    public Map insert(Map userInfo) throws BusinessException;

    public int update(Map userInfo) throws BusinessException;

    public Integer delete(Map params) throws BusinessException;

    List<Map> getList(Map userMap) throws BusinessException;

    Integer getCount(Map userMap) throws BusinessException;

    public List<Map> getTransactionList(Map userMap) throws BusinessException;

    public Integer getTransactionCount(Map userMap) throws BusinessException;

    List<AccountTransactionVO> getInvestorTransactionList(AccountTransactionDto dto) throws BusinessException;

}