package cn.zjhf.kingold.trade.persistence.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Repository
@Mapper
public interface TradePrivateFundOrderMapper {


    Map get(Map params);

    Integer insert(Map map);

    Integer update(Map map);

    List<Map> getList(Map map);

    Integer getCount(Map map);

    /**
     * 获取指定产品生成订单的总金额
     * @param map
     * @return
     */
    BigDecimal getOrderPurchaseSum(Map map);

    /**
     * 获取指定产品确认过得订单的总金额
     * @param map
     * @return
     */
    BigDecimal getOrderVerifyPurchaseSum(Map map);

    /**
     * 根据用户ID查询私募预约金额
     *
     * @param param
     * @return
     */
    BigDecimal querySumAmountByUser(Map<String, String> param);

}