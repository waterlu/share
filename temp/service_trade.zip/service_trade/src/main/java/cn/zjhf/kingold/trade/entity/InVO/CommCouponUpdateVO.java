package cn.zjhf.kingold.trade.entity.InVO;

import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * Created by zhangyijie on 2017/7/5.
 */
public class CommCouponUpdateVO extends InVOBase {
    @ApiModelProperty(required = true, value = "通用唯一码")
    @NotEmpty
    private String commCode;

    @ApiModelProperty(required = false, value = "新状态： -1删除，其他见相应业务规则")
    @NotEmpty
    private int newStatus;

    @ApiModelProperty(required = false, value = "更新说明")
    private String updateRemark;

    @ApiModelProperty(required = false, value = "更新用户id")
    @NotEmpty
    private String updateUserId;

    public String getCommCode() {
        return commCode;
    }

    public void setCommCode(String commCode) {
        this.commCode = commCode;
    }

    public String getUpdateRemark() {
        return updateRemark;
    }

    public void setUpdateRemark(String updateRemark) {
        this.updateRemark = updateRemark;
    }

    public String getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(String updateUserId) {
        this.updateUserId = updateUserId;
    }

    public int getNewStatus() {
        return newStatus;
    }

    public void setNewStatus(int newStatus) {
        this.newStatus = newStatus;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(getTraceID()) + ", ");
        sb.append("commCode:" + DataUtils.toString(commCode) + ", ");
        sb.append("newStatus:" + DataUtils.toString(newStatus) + ", ");
        sb.append("updateRemark:" + DataUtils.toString(updateRemark) + ", ");
        sb.append("updateUserId:" + DataUtils.toString(updateUserId));
        return sb.toString();
    }
}
