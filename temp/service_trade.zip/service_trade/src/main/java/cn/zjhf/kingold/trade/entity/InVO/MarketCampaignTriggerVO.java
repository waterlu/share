package cn.zjhf.kingold.trade.entity.InVO;

import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Size;

/**
 * Created by zhangyijie on 2017/7/5.
 */
public class MarketCampaignTriggerVO extends InVOBase {
    @ApiModelProperty(required = true, value = "userUuid")
    @NotEmpty
    private String userUuid;

    @ApiModelProperty(required = true, value = "活动编号")
    @NotEmpty
    private Integer mcCode;

    @ApiModelProperty(required = true, value = "orderBillCode")
    @NotEmpty
    private String orderBillCode;

    @ApiModelProperty(required = true, value = "被邀请用户UUID")
    private String invitedUserUuid;

    @ApiModelProperty(required = false, value = "生成领取的礼券code")
    private String couponExtendCode;

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public Integer getMcCode() {
        return mcCode;
    }

    public void setMcCode(Integer mcCode) {
        this.mcCode = mcCode;
    }

    public String getInvitedUserUuid() {
        return invitedUserUuid;
    }

    public void setInvitedUserUuid(String invitedUserUuid) {
        this.invitedUserUuid = invitedUserUuid;
    }

    public String getCouponExtendCode() {
        return couponExtendCode;
    }

    public void setCouponExtendCode(String couponExtendCode) {
        this.couponExtendCode = couponExtendCode;
    }

    public String getOrderBillCode() {
        return orderBillCode;
    }

    public MarketCampaignTriggerVO setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
        return this;
    }

    public MarketCampaignTriggerVO() {
    }

    public MarketCampaignTriggerVO(String userUuid, int mcCode, String orderBillCode, String invitedUserUuid) {
        this.userUuid = userUuid;
        this.mcCode = mcCode;
        this.orderBillCode = orderBillCode;
        this.invitedUserUuid = invitedUserUuid;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(getTraceID()) + ", ");
        sb.append("userUuid:" + DataUtils.toString(userUuid) + ", ");
        sb.append("orderBillCode:" + DataUtils.toString(orderBillCode) + ", ");
        sb.append("invitedUserUuid:" + DataUtils.toString(invitedUserUuid) + ", ");
        sb.append("mcCode:" + DataUtils.toString(mcCode));
        sb.append("couponExtendCode:" + DataUtils.toString(couponExtendCode));
        return sb.toString();
    }


}
