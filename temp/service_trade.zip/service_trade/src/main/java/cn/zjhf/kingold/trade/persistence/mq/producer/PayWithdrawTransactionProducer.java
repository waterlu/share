package cn.zjhf.kingold.trade.persistence.mq.producer;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.rocketmq.annotation.RocketMQTransactionProducer;
import cn.zjhf.kingold.rocketmq.base.AbstractTransactionMQProducer;
import cn.zjhf.kingold.rocketmq.base.SimpleMessage;
import cn.zjhf.kingold.trade.service.IPayService;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 生产提现申请成功消息
 *
 * Created by lutiehua on 2017/7/13.
 */
@RocketMQTransactionProducer(topic = "pay", tag = "withdraw")
public class PayWithdrawTransactionProducer extends AbstractTransactionMQProducer<SimpleMessage> {

    @Autowired
    private IPayService payService;

    @Override
    public boolean checkState(SimpleMessage simpleMessage) throws BusinessException {
        return payService.checkWithdraw(simpleMessage.getData());
    }
}
