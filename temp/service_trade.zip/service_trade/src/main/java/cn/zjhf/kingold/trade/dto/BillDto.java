package cn.zjhf.kingold.trade.dto;

import java.math.BigDecimal;

/**
 * 单据凭证（用来区分用户交易，记录流水）
 *
 * Created by lutiehua on 2017/4/28.
 */
public class BillDto {

//    private String billUuid;//单据号uuid（冗余，为了流水使用）废弃

    private String billCode;//单据号

    private String accountUuid;//账户

    private String tradeType;//交易类型

    private BigDecimal amount;//金额（减钱就是负数）

    private String orderBillCodeExtend;//单据号扩展

    private String transactionChannel;//渠道

    /**
     * @param billCode
     * @param tradeType
     * @param amount
     * @param accountUuid
     */
    public BillDto( String billCode, String tradeType, BigDecimal amount, String accountUuid,String orderBillCodeExtend){
        this.billCode = billCode;
        this.amount = amount;
        this.tradeType = tradeType;
        this.accountUuid = accountUuid;
        this.orderBillCodeExtend = orderBillCodeExtend;
    }
    public String getAccountUuid() {
        return accountUuid;
    }

    public void setAccountUuid(String accountUuid) {
        this.accountUuid = accountUuid;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getTradeType() {
        return tradeType;
    }

    public void setTradeType(String tradeType) {
        this.tradeType = tradeType;
    }

    public String getBillCode() {
        return billCode;
    }

    public void setBillCode(String billCode) {
        this.billCode = billCode;
    }

    public String getOrderBillCodeExtend() {
        return orderBillCodeExtend;
    }

    public void setOrderBillCodeExtend(String orderBillCodeExtend) {
        this.orderBillCodeExtend = orderBillCodeExtend;
    }

    public String getTransactionChannel() {
        return transactionChannel;
    }

    public void setTransactionChannel(String transactionChannel) {
        this.transactionChannel = transactionChannel;
    }
}
