package cn.zjhf.kingold.trade.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.dto.CouponSendConditionDto;
import cn.zjhf.kingold.trade.entity.InVO.MarketCampaignVO;
import org.springframework.web.multipart.MultipartFile;

/**
 * Created by zhangyijie on 2018/1/31.
 */
public interface ICoinCouponService {

    /**
     * 给指定用户发放指定批次的礼券
     * @param userUuid
     * @param cashCouponCode
     * @param applyScene
     * @return 发放的礼券号码
     * @throws BusinessException
     */
    String establishCoinExtendRecord(String userUuid, String cashCouponCode, Byte applyScene) throws BusinessException;
}
