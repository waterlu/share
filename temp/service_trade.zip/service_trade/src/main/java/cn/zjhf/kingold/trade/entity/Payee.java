package cn.zjhf.kingold.trade.entity;

import cn.zjhf.kingold.trade.utils.DataUtils;

/**
 * @Author liuyao
 * @Description
 * @Date Created in 13:47 2017/5/18
 */

public class Payee {
    long userId;
    double amount;
    double fee;
    String orderNo;

    public Payee() {
    }

    public Payee(long userId, double amount, double fee) {
        this.userId = userId;
        this.amount = amount;
        this.fee = fee;
    }

    public Payee(long userId, double amount, double fee, String orderNo) {
        this.userId = userId;
        this.amount = amount;
        this.fee = fee;
        this.orderNo = orderNo;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public double getFee() {
        return fee;
    }

    public void setFee(double fee) {
        this.fee = fee;
    }

    @Override
    public String toString() {
        return "userId:" + userId + ", amount:" + amount + ", fee:" + fee + ", orderNo:" + DataUtils.toString(orderNo);
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }
}
