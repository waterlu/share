package cn.zjhf.kingold.trade.persistence.mq.message;

import cn.zjhf.kingold.rocketmq.base.MQMessage;

/**
 * 用户签到消息
 *
 * @author shengkao
 * @date 2018-01-10
 */
public class CheckInMessage implements MQMessage {

    private String id;

    private String userUuid;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    @Override
    public String getKey() {
        return id;
    }

}
