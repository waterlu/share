package cn.zjhf.kingold.trade.dto;

/**
 * Created by lutiehua on 2017/6/13.
 */
public class UserDto {

    private String userUuid;

    private String inviterUuid;

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getInviterUuid() {
        return inviterUuid;
    }

    public void setInviterUuid(String inviterUuid) {
        this.inviterUuid = inviterUuid;
    }
}
