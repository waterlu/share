package cn.zjhf.kingold.trade.persistence.mq.consumer;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.rocketmq.annotation.RocketMQConsumer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQConsumer;
import cn.zjhf.kingold.trade.entity.TradePrivateFundOrder;
import cn.zjhf.kingold.trade.persistence.mq.message.OrderConfirmMessage;
import cn.zjhf.kingold.trade.service.IAchievementService;
import cn.zjhf.kingold.trade.service.IRewardService;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 消费私募订单确认消息，生成奖励
 *
 * Created by lutiehua on 2017/7/14.
 */
@RocketMQConsumer(topic = "order", tag = "confirm")
public class OrderConfirmConsumer extends AbstractMQConsumer<OrderConfirmMessage> {

    @Autowired
    private IRewardService rewardService;

    @Autowired
    IAchievementService achievementService;

    @Override
    public ResponseResult process(OrderConfirmMessage orderConfirmMessage) throws BusinessException {
        ResponseResult responseResult = new ResponseResult();

        TradePrivateFundOrder privateFundOrder = new TradePrivateFundOrder();
        privateFundOrder.setPfoCode(orderConfirmMessage.getOrderBillCode());
        privateFundOrder.setCreateTime(orderConfirmMessage.getCreateTime());

        // 生成奖励
        rewardService.generatePFAwardRecord(privateFundOrder);

        // 记录业绩
        achievementService.generatePFAchievement(privateFundOrder);

        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        return responseResult;
    }
}
