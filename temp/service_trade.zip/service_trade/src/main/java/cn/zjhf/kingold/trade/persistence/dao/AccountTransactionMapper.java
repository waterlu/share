package cn.zjhf.kingold.trade.persistence.dao;

import cn.zjhf.kingold.trade.utils.WhereCondition;
import cn.zjhf.kingold.trade.vo.AccountTransactionVO;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
@Mapper
public interface AccountTransactionMapper {
    Map get(Map params);

    int insert(Map record);

    int update(Map userInfo);

    int delete(Map params);

    Integer getCount(Map userMap);

    @Update("update account_transaction set delete_flag = 1 where trade_order_uuid = #{OrderBillCode}")
    void deleteByOrderBillCode(@Param("OrderBillCode") String OrderBillCode);

    @Update("update account_transaction set is_transaction_check = 1 where trade_order_bill_code_extend = #{tradeBillCodeExtend}")
    void reconciliation(@Param("tradeBillCodeExtend") String tradeBillCodeExtend);

    List<Map> getList(Map userMap);

    List<Map> getTransactionList(Map userMap);

    Integer getTransactionCount(Map userMap);

    /**
     * 根据我们的订单号更新宝付的order_id
     *
     * @param param
     * @return
     */
    int updateBaofooOrderId(Map<String, Object> param);

    @Select("SELECT a.account_transaction_uuid,i.investor_mobile, a.transaction_amount, a.trade_type, a.trade_order_bill_code_extend, a.trade_order_bill_code, a.transaction_time FROM kingold_trade.account_transaction a, kingold_trade.account b,kingold_user.investor i ${condition}")
    @ResultMap("AccountTransactionVO")
    List<AccountTransactionVO> getInvestorTransactionList(WhereCondition condition);
}