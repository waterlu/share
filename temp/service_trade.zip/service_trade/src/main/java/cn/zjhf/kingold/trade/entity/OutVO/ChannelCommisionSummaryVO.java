package cn.zjhf.kingold.trade.entity.OutVO;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.trade.entity.ChannelCommisionSummary;
import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.Date;

@ApiModel(value = "ChannelCommisionSummaryVO", description = "渠道佣金汇总记录")
public class ChannelCommisionSummaryVO extends ParamVO {

    @ApiModelProperty(required = true, value = "请求结算单号")
    @NotEmpty
    @Size(min = 1, max = 40)
    private String channelCommisionSummaryId;

    @ApiModelProperty(required = true, value = "请求周期，格式: YYYY.MM")
    @NotEmpty
    @Size(min = 1, max = 10)
    private String requestCycle;

    @ApiModelProperty(required = false, value = "商户号，5位数字 （如：10001）")
    @Size(min = 1, max = 20)
    private String merchantNum;

    @ApiModelProperty(required = true, value = "APP名称/渠道名称")
    @NotEmpty
    @Size(min = 1, max = 30)
    private String channelAppName;

    @ApiModelProperty(required = true, value = "佣金")
    @NotEmpty
    private double commisionAmount;

    @ApiModelProperty(required = true, value = "结算状态: -1审核失败；1待审核；2已结算")
    @NotEmpty
    private int settleStatus;

    @ApiModelProperty(required = false, value = "审核结算操作人")
    @Size(min = 1, max = 30)
    private String settleOperator;

    @ApiModelProperty(required = false, value = "结算时间")
    private Date settleTime;

    @ApiModelProperty(required = false, value = "审核意见/备注")
    @Size(min = 1, max = 512)
    private String auditOpinion;

    @ApiModelProperty(required = true, value = "删除标记 0未删除，1已删除")
    @NotEmpty
    private int deleteFlag;

    @ApiModelProperty(required = true, value = "")
    @NotEmpty
    private Date createTime;

    @ApiModelProperty(required = true, value = "")
    @NotEmpty
    private Date updateTime;

    public ChannelCommisionSummaryVO() {
    }

    public ChannelCommisionSummaryVO(ChannelCommisionSummary channelCommisionSummary) {
        this.channelCommisionSummaryId = channelCommisionSummary.getChannelCommisionSummaryId();
        this.requestCycle = channelCommisionSummary.getRequestCycle();
        this.merchantNum = channelCommisionSummary.getMerchantNum();
        this.channelAppName = channelCommisionSummary.getChannelAppName();
        this.commisionAmount = channelCommisionSummary.getCommisionAmount().doubleValue();
        this.settleStatus = channelCommisionSummary.getSettleStatus();
        this.settleOperator = channelCommisionSummary.getSettleOperator();
        this.settleTime = channelCommisionSummary.getSettleTime();
        this.auditOpinion = channelCommisionSummary.getAuditOpinion();
        this.deleteFlag = channelCommisionSummary.getDeleteFlag();
        this.createTime = channelCommisionSummary.getCreateTime();
        this.updateTime = channelCommisionSummary.getUpdateTime();
    }

    public String getChannelCommisionSummaryId() {
        return channelCommisionSummaryId;
    }

    public void setChannelCommisionSummaryId(String channelCommisionSummaryId) {
        this.channelCommisionSummaryId = channelCommisionSummaryId;
    }

    public String getRequestCycle() {
        return requestCycle;
    }

    public void setRequestCycle(String requestCycle) {
        this.requestCycle = requestCycle;
    }

    public String getMerchantNum() {
        return merchantNum;
    }

    public void setMerchantNum(String merchantNum) {
        this.merchantNum = merchantNum;
    }

    public String getChannelAppName() {
        return channelAppName;
    }

    public void setChannelAppName(String channelAppName) {
        this.channelAppName = channelAppName;
    }

    public double getCommisionAmount() {
        return commisionAmount;
    }

    public void setCommisionAmount(double commisionAmount) {
        this.commisionAmount = commisionAmount;
    }

    public int getSettleStatus() {
        return settleStatus;
    }

    public void setSettleStatus(int settleStatus) {
        this.settleStatus = settleStatus;
    }

    public String getSettleOperator() {
        return settleOperator;
    }

    public void setSettleOperator(String settleOperator) {
        this.settleOperator = settleOperator;
    }

    public Date getSettleTime() {
        return settleTime;
    }

    public void setSettleTime(Date settleTime) {
        this.settleTime = settleTime;
    }

    public String getAuditOpinion() {
        return auditOpinion;
    }

    public void setAuditOpinion(String auditOpinion) {
        this.auditOpinion = auditOpinion;
    }

    public int getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(int deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public ChannelCommisionSummary get() {
        ChannelCommisionSummary channelCommisionSummary = new ChannelCommisionSummary();
        channelCommisionSummary.setChannelCommisionSummaryId(channelCommisionSummaryId);
        channelCommisionSummary.setRequestCycle(requestCycle);
        channelCommisionSummary.setMerchantNum(merchantNum);
        channelCommisionSummary.setChannelAppName(channelAppName);
        channelCommisionSummary.setCommisionAmount(new BigDecimal(commisionAmount));
        channelCommisionSummary.setSettleStatus(new Integer(settleStatus).byteValue());
        channelCommisionSummary.setSettleOperator(settleOperator);
        channelCommisionSummary.setSettleTime(settleTime);
        channelCommisionSummary.setAuditOpinion(auditOpinion);
        channelCommisionSummary.setDeleteFlag(new Integer(deleteFlag).byteValue());
        channelCommisionSummary.setCreateTime(createTime);
        channelCommisionSummary.setUpdateTime(updateTime);
        return channelCommisionSummary;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("channelCommisionSummaryId:" + DataUtils.toString(channelCommisionSummaryId) + ", ");
        sb.append("requestCycle:" + DataUtils.toString(requestCycle) + ", ");
        sb.append("merchantNum:" + DataUtils.toString(merchantNum) + ", ");
        sb.append("channelAppName:" + DataUtils.toString(channelAppName) + ", ");
        sb.append("commisionAmount:" + DataUtils.toString(commisionAmount) + ", ");
        sb.append("settleStatus:" + DataUtils.toString(settleStatus) + ", ");
        sb.append("settleOperator:" + DataUtils.toString(settleOperator) + ", ");
        sb.append("settleTime:" + DataUtils.toString(settleTime) + ", ");
        sb.append("auditOpinion:" + DataUtils.toString(auditOpinion) + ", ");
        sb.append("deleteFlag:" + DataUtils.toString(deleteFlag) + ", ");
        sb.append("createTime:" + DataUtils.toString(createTime) + ", ");
        sb.append("updateTime:" + DataUtils.toString(updateTime));
        return sb.toString();
    }
}
