package cn.zjhf.kingold.trade.entity.OutVO;

import cn.zjhf.kingold.trade.entity.InVO.CashCouponVO;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by liuyao on 2017/9/13.
 */
public class ProductCouponItemVO {
    private String productUuid;
    private BigDecimal maxProfit;

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public BigDecimal getMaxProfit() {
        return maxProfit;
    }

    public void setMaxProfit(BigDecimal maxProfit) {
        this.maxProfit = maxProfit;
    }
}
