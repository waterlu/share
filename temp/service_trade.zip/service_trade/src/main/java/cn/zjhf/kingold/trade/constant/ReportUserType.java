package cn.zjhf.kingold.trade.constant;

/**
 * @author xiexiaojie
 *         2018/4/14.
 */
public interface ReportUserType {
    /**
     * 普通投资人
     */
    Integer INVESTOR = 1;

    /**
     * 机构投资人
     */
    Integer ADVISOR = 3;
}
