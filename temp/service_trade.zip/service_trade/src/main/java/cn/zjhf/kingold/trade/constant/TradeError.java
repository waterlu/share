package cn.zjhf.kingold.trade.constant;

/**
 * Created by lutiehua on 2017/4/28.
 */
public interface TradeError {

    int OK = 200;

    String OK_TEXT = "成功";

    int ERROR_PARAMETER = -1;

    String ERROR_PARAMETER_TEXT = "参数错误";
}
