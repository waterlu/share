package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.constant.TradeStatusMsg;
import cn.zjhf.kingold.trade.entity.InVO.CommGrant.CashCouponGrantVO;
import cn.zjhf.kingold.trade.entity.InVO.CommGrant.CommGrantInfoVO;
import cn.zjhf.kingold.trade.entity.InVO.CommGrant.RedPacketGrantVO;
import cn.zjhf.kingold.trade.persistence.dao.OperationReportMapper;
import cn.zjhf.kingold.trade.service.ICoinCouponService;
import cn.zjhf.kingold.trade.service.ICommGrantService;
import cn.zjhf.kingold.trade.service.IRedPacketService;
import cn.zjhf.kingold.trade.utils.*;
import cn.zjhf.kingold.trade.utils.File.FileUtils;
import cn.zjhf.kingold.trade.utils.Tuple.ThreeTuple;
import cn.zjhf.kingold.trade.utils.Tuple.TwoTuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by zhangyijie on 2018/2/1.
 */
@Service
public class CommGrantServiceImpl extends ProductClearBase implements ICommGrantService {
    protected static final Logger logger = LoggerFactory.getLogger(CommGrantServiceImpl.class);

    @Autowired
    private ICoinCouponService coinCouponService;

    @Autowired
    private IRedPacketService redPacketService;

    @Autowired
    private OperationReportMapper operationReportMapper;

    /**
     * 运行最大耗时 2分钟
     */
    final int MAX_RUN_TIME = 2;

    private final static String COMM_SPECIFIED_DISTRIBUTION_KEY = "comm_specified_distribution_";

    private TwoTuple<String, String> getUserIdName(String phoneNumber) throws BusinessException {
        String sql = "SELECT user_uuid, investor_real_name FROM kingold_user.investor WHERE investor_mobile = ";
        sql += WhereCondition.toSQLStr(phoneNumber);
        sql += " ORDER BY create_time DESC LIMIT 0,1 ";

        List<Map> data = operationReportMapper.lstQueryData(new QueryUtils(sql));
        if ((data != null) && (data.size() > 0)) {
            BizParam bizParam = new BizParam(data.get(0));
            String userUuid = bizParam.getString("user_uuid");
            String investorName = bizParam.getString("investor_real_name");

            return new TwoTuple<>(userUuid, investorName);
        }

        throw new BusinessException(TradeStatusMsg.INVESTOR_NOEXIST_ERR, TradeStatusMsg.INVESTOR_NOEXIST_ERR_MSG, false);
    }

    private String getUserUuid(String phoneNumber) throws BusinessException {
        TwoTuple<String, String> ret = getUserIdName(phoneNumber);
        return (ret != null) ? ret.first : null;
    }

    private Map<Integer, String> commGrant(CommGrantInfoVO commGrantInfo) {
        for (CashCouponGrantVO cashCouponGrant : commGrantInfo.getCashCouponGrantList()) {
            try {
                String userUuid = getUserUuid(cashCouponGrant.getPhoneNumber());
                if (DataUtils.isNotEmpty(userUuid)) {
                    coinCouponService.establishCoinExtendRecord(userUuid, cashCouponGrant.getCcCode(), cashCouponGrant.getActivityNum());
                }
            } catch (BusinessException e) {
                commGrantInfo.setErrMess(cashCouponGrant.getRowNum(), e.getMessage());
                logger.error("BusinessException: ", e);
            }
        }

        for (RedPacketGrantVO redPacketGrant : commGrantInfo.getRedPacketGrantList()) {
            try {
                TwoTuple<String, String> ret = getUserIdName(redPacketGrant.getPhoneNumber());
                if (ret != null) {
                    redPacketService.establishRedPacketRecord(
                            new Long(redPacketGrant.getActivityNum()), ret.first, redPacketGrant.getPhoneNumber(),
                            ret.second, AmountUtils.toBigDecimal(redPacketGrant.getRedPacketAmt()));
                }
            } catch (BusinessException e) {
                commGrantInfo.setErrMess(redPacketGrant.getRowNum(), e.getMessage());
                logger.error("BusinessException: ", e);
            }
        }

        return commGrantInfo.getErrMap();
    }

    /**
     * 通用发放
     *
     * @param file
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Map<Integer, String> commGrant(MultipartFile file) throws BusinessException {
        InputStream input = null;
        try {
            input = file.getInputStream();
        } catch (IOException e) {
            logger.error("IOException", e);
        }

        if(input != null) {
            String md5Str = FileUtils.getMd5ByFile(input);

            if(!checkKeyLock(COMM_SPECIFIED_DISTRIBUTION_KEY + md5Str, MAX_RUN_TIME)) {
                CommGrantInfoVO commGrantInfo = XLSUtils.readInputMess(file);
                return commGrant(commGrantInfo);
            }else {
                throw new BusinessException(TradeStatusMsg.SPECDIST_BATCH_REPEAT_ERR,
                        TradeStatusMsg.SPECDIST_BATCH_REPEAT_ERR_MSG, false);
            }
        }

        return new HashMap<>();
    }

    /**
     * 通用发放
     *
     * @param fileName
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Map<Integer, String> commGrant(String fileName) throws BusinessException {
        String md5Str = FileUtils.getMd5ByFile(fileName);
        if (!checkKeyLock(COMM_SPECIFIED_DISTRIBUTION_KEY + md5Str, MAX_RUN_TIME)) {
            CommGrantInfoVO commGrantInfo = XLSUtils.readInputMess(fileName);
            return commGrant(commGrantInfo);
        } else {
            throw new BusinessException(TradeStatusMsg.SPECDIST_BATCH_REPEAT_ERR,
                    TradeStatusMsg.SPECDIST_BATCH_REPEAT_ERR_MSG, false);
        }
    }
}
