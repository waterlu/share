package cn.zjhf.kingold.trade.constant;

/**
 * Created by Xiaody on 17/4/28.
 */
public class TradeStatusMsg {

    public static final int USER_STATUS_WRONG_CODE = 6001;
    public static final String USER_STATUS_WRONG_MSG = "抱歉，您的账户目前被禁用,如有问题请联系客服";

    public static final int USER_VERIFY_STATUS_WRONG_CODE = 6002;
    public static final String USER_VERIFY_STATUS_WRONG_MSG = "用户身份未认证或者开户未完成";

    public static final int PRODUCT_CONNOT_BUY_CODE = 6003;
    public static final String PRODUCT_CONNOT_BUY_MSG = "产品目前不能购买(产品不是上架状态)";

    public static final int AMOUNT_LT_MININVESTMENT_CODE = 6004;
    public static final String AMOUNT_LT_MININVESTMENT_MSG = "认购金额不能小于起投金额，请重新输入";

    public static final int AMOUNT_GT_MAXINVESTMENT_CODE = 6005;
    public static final String AMOUNT_GT_MAXINVESTMENT_MSG = "超出本产品单人投资上限，请重新输入";

    public static final int AMOUNT_DISSATISFY_INCREASE_CODE = 6006;
    public static final String AMOUNT_DISSATISFY_INCREASE_MSG = "认购金额不满足递增规则，请重新输入";

    public static final int AMOUNT_GT_REMAIN_CODE = 6007;
    public static final String AMOUNT_GT_REMAIN_MSG = "认购金额不能大于最高可投金额，请重新输入";

    public static final int PRODUCT_STATUS_WRONG_CODE = 6008;
    public static final String PRODUCT_STATUS_WRONG_MSG = "产品目前不能购买(产品不是募集中状态)";

    public static final int NO_AVAILABLE_ACCOUNT_CODE = 6010;
    public static final String NO_AVAILABLE_ACCOUNT_MSG = "没有可用账户";

    public static final int BALANCE_INSUFFICIENT_CODE = 6011;
    public static final String BALANCE_INSUFFICIENT_MSG = "账户余额不足";

    public static final int NO_RECHARGE_BILL = 6012;
    public static final String NO_RECHARGE_BILL_MSG = "充值单不存在";

    public static final int RECHARGE_BILL_FAILURE = 6013;
    public static final String RECHARGE_BILL_FAILURE_MSG = "充值失败";


    public static final int ORDER_STATUS_WRONG_CODE = 6014;
    public static final String ORDER_STATUS_WRONG_MSG = "订单状态错误";

    public static final int USER_VIP_FLAG_TALENT_ERROR_CODE = 6015;
    public static final String USER_VIP_FLAG_TALENT_ERROR_MSG = "您还未开启理财达人特权，无法购买此产品";

    public static final int INVESTOR_NOEXIST_ERR = 6016;
    public static final String INVESTOR_NOEXIST_ERR_MSG = "该客户不是平台的注册用户";


    public static final int PRODUCT_STATUS_ERR = 9101;
    public static final String PRODUCT_STATUS_ERR_MSG = "产品状态错误";

    public static final int PRODUCT_DATE_ERR = 9102;
    public static final String PRODUCT_DATE_ERR_MSG = "该操作和产品的设定日期不符，请检查产品要素";

    public static final int PRODUCT_NOT_EXIST = 9103;
    public static final String PRODUCT_NOT_EXIST_MSG = "指定产品不存在";

    public static final int PRODUCT_UPDATE_PRODUCT_STATUS_ERR = 9104;
    public static final String PRODUCT_UPDATE_PRODUCT_STATUS_ERR_MSG = "更新产品状态失败";

    public static final int ACCOUNT_NOT_EXIST = 9105;
    public static final String ACCOUNT_NOT_EXIST_MSG = "账户不存在, 该用户未绑卡或开户！";

    public static final int PRODUCT_UPDATE_PRODUCT_SHELVES_ERR = 9106;
    public static final String PRODUCT_UPDATE_PRODUCT_SHELVES_ERR_MSG = "更新产品上下架状态失败";

    public static final int PRODUCT_UPDATE_PRODUCT_RAISEPROGRESS_ERR = 9107;
    public static final String PRODUCT_UPDATE_PRODUCT_RAISEPROGRESS_ERR_MSG = "更新产品募集进度失败";

    public static final int PRODUCT_UPDATE_PRODUCT_REPAYMENTDATE_ERR = 9108;
    public static final String PRODUCT_UPDATE_PRODUCT_REPAYMENTDATE_ERR_MSG = "更新产品实际还款日/兑付日期失败";

    public static final int PRODUCT_LOAN_FAIL = 9111;
    public static final String PRODUCT_LOAN_FAIL_MSG = "该产品放款失败";

    public static final int COUPON_LOAN_FAIL = 9112;
    public static final String COUPON_LOAN_FAIL_MSG = "现金券放款失败";

    public static final int PRODUCT_PAYMENT_FAIL = 9113;
    public static final String PRODUCT_PAYMENT_FAIL_MSG = "该产品还款失败";

    public static final int PRODUCT_ISLOAN_ERR = 9121;
    public static final String PRODUCT_ISLOAN_ERR_MSG = "该产品尚未放款，请检查产品的放款信息";

    public static final int ESCROW_ACCOUNT_LESS_BALANCE = 9122;
    public static final String ESCROW_ACCOUNT_LESS_BALANCE_MSG = "托管账户余额不足";

    public static final int FINANCIER_ACCOUNT_LESS_BALANCE = 9123;
    public static final String FINANCIER_ACCOUNT_LESS_BALANCE_MSG = "融资人账户余额不足";

    public static final int CLEAR_ACCOUNT_LESS_BALANCE = 9124;
    public static final String CLEAR_ACCOUNT_LESS_BALANCE_MSG = "平台结算账户余额不足";

    public static final int PRODUCT_SHELVESOFF_ERR = 9701;
//    public static final String PRODUCT_SHELVESOFF_ERR_MSG = "产品下架失败, 请检查是否处于募集期并且尚有未撤销的交易单。";
    public static final String PRODUCT_SHELVESOFF_ERR_MSG = "该产品已有订单产生，售罄前不能下架";

    public static final int WORKFLOW_STATUS_ERR = 9801;
    public static final String WORKFLOW_STATUS_ERR_MSG = "工作流状态错误, 请检查";

    public static final int CANCELTRADE_FAIL_ERR = 9811;
    public static final String CANCELTRADE_FAIL_ERR_MSG = "撤单失败，请检查交易和账户状态";

    public static final int SYSTEM_BIZ_ERR = 9901;
    public static final String SYSTEM_BIZ_ERR_MSG = "系统业务错误";

    public static final int WITHDRAW_MORE_CASH_AMOUNT_CODE = 6020;
    public static final String WITHDRAW_MORE_CASH_AMOUNT = "取现金额大于可用余额";

    public static final int WITHDRAW_MUST_POSITIVE_INTEGER_CODE = 6021;
    public static final String WITHDRAW_MUST_POSITIVE_INTEGER = "取现金额必须是正整数";

    public static final int FREEZE_WITH_DRAW_ERR_CODE = 6022;
    public static final String FREEZE_WITH_DRAW_ERR_MSG = "自动提现失败，请查看绑定的银行卡/账户状态，或者联系金疙瘩客服";

    public static final int OUT_OF_WITHDRAW_LIMIT_CODE = 6032;
    public static final String OUT_OF_WITHDRAW_LIMIT = "超过了最大单笔提现金额";

    public static final int OUT_OF_PLATFORM_SETTLEMENT_LIMIT_CODE = 6033;
    public static final String OUT_OF_PLATFORM_SETTLEMENT_LIMIT = "平台清算账户余额不足！";

    public static final int REPORT_UNDEFINED_ERR = 8301;
    public static final String REPORT_UNDEFINED_ERR_MSG = "该报表未定义";

    public static final int REPORT_PARAM_ERR = 8302;
    public static final String REPORT_PARAM_ERR_MSG = "该报表输入参数与所要求不一致";

    public static final int COUPON_LSTPRODUCT_ERR = 8304;
    public static final String COUPON_LSTPRODUCT_MSG = "现金券反查适用的产品，处理失败";

    public static final int REPORT_OTHER_ERR = 8303;
    public static final String REPORT_OTHER_ERR_MSG = "产品报表处理失败";


    public static final int CASHCOUPON_BATCH_NOEXIST = 1301;
    public static final String CASHCOUPON_BATCH_NOEXIST_MSG = "指定的优惠券批次不存在或已失效";

    public static final int CASHCOUPON_BATCH_PAPAM_ERR = 1302;
    public static final String CASHCOUPON_BATCH_PAPAM_ERR_MSG = "优惠券批次设置参数错误";

    public static final int CASHCOUPON_FACE_VALUE_ERR = 1303;
    public static final String CASHCOUPON_FACE_VALUE_ERR_MSG = "现金券面值无效";

    public static final int CASHCOUPON_YIELD_RATE_ERR = 1304;
    public static final String CASHCOUPON_YIELD_RATE_ERR_MSG = "加息券加息率无效";

    public static final int INTERESTCOUPON_BATCH_PAPAM_ERR = 1305;
    public static final String INTERESTCOUPON_BATCH_PAPAM_ERR_MSG = "现金券批次设置参数错误";

    public static final int CASHCOUPON_EXHAUSTED_ERR = 1306;
    public static final String CASHCOUPON_EXHAUSTED_MSG = "该批次的券已经被全部领完";

    public static final int TODAY_CASHCOUPON_EXHAUSTED_ERR = 1307;
    public static final String TODAY_CASHCOUPON_EXHAUSTED_MSG = "当日该批次的券已经达到领取限额";


    public static final int MARKETCAMPAIGN_NOEXIST = 1401;
    public static final String MARKETCAMPAIGN_NOEXIST_MSG = "指定的场景不存在或已失效";

    public static final int MARKETCAMPAIGN_PAPAM_ERR = 1402;
    public static final String MARKETCAMPAIGN_PAPAM_ERR_MSG = "活动设置参数错误";

    public static final int MARKETCAMPAIGN_ISCOIN_ERR = 1403;
    public static final String MARKETCAMPAIGN_ISCOIN_ERR_MSG = "isCoin值必须是1！";



    public static final int CASHCOUPON_EXTENDRECORD_NOEXIST = 1501;
    public static final String CASHCOUPON_EXTENDRECORD_NOEXIST_MSG = "指定的优惠券发放记表不存在";

    public static final int CASHCOUPON_SPECDIST_NOEXIST_ERR = 1502;
    public static final String CASHCOUPON_SPECDIST_NOEXIST_ERR_MSG = "存在非平台注册用户，请重新导入！";

    public static final int CASHCOUPON_EXTENDRECORD_ABOLISH_ERR = 1503;
    public static final String CASHCOUPON_EXTENDRECORD_ABOLISH_ERR_MSG = "作废失败，该优惠券已经使用/过期/作废";

    public static final int CASHCOUPON_EXTENDRECORD_USE_INVALID = 1504;
    public static final String CASHCOUPON_EXTENDRECORD_USE_INVALID_MSG = "优惠券无效，不可使用";

    public static final int CASHCOUPON_SPECDIST_REPEAT_ERR = 1505;
    public static final String CASHCOUPON_SPECDIST_REPEAT_ERR_MSG = "提交的现金券批次重复，请检查后重新提交";

    public static final int CASHCOUPON_SPECDIST_INVALID_ERR = 1506;
    public static final String CASHCOUPON_SPECDIST_INVALID_ERR_MSG = "现金券批次或者手机号列表为空，请检查后重新提交";

    public static final int CASHCOUPON_SPECDIST_MAX_ERR = 1507;
    public static final String CASHCOUPON_SPECDIST_MAX_ERR_MSG = "现金券指定发放用户条数已超最大上限";

    public static final int CASHCOUPON_SPECDIST_STATUS_ERR = 1508;
    public static final String CASHCOUPON_SPECDIST_STATUS_ERR_MSG = "现金券指定发放批次状态错误";

    public static final int SPECDIST_BATCH_REPEAT_ERR = 1509;
    public static final String SPECDIST_BATCH_REPEAT_ERR_MSG = "您已经对该批用户进行过指定发放，为避免大量数据误发，请稍等大约两分钟后再试";

    public static final int REDPACKET_SPECDIST_MAX_ERR = 1510;
    public static final String REDPACKET_SPECDIST_MAX_ERR_MSG = "现金红包指定发放用户条数已超最大上限";

    public static final int REDPACKET_SPECDIST_STATUS_ERR = 1511;
    public static final String REDPACKET_SPECDIST_STATUS_ERR_MSG = "现金红包指定发放批次状态错误";

    public static final int REDPACKET_SPECDIST_INVALID_ERR = 1512;
    public static final String REDPACKET_SPECDIST_INVALID_ERR_MSG = "现金红包批次或者手机号列表为空，请检查后重新提交";

    public static final int CASHCOUPON_INSUFFICIENT_QUANTITY_ERR = 1513;
    public static final String CASHCOUPON_INSUFFICIENT_QUANTITY_ERR_MSG = "该批次礼券已不满足指定发放要求的数量";

    public static final int PAID_ORDER = 6060;
    public static final String PAID_ORDER_MSG = "订单已经付过款";

    public static final int UNPAID_ORDER = 6061;
    public static final String UNPAID_ORDER_MSG = "订单还没有付款";

    public static final int WRONG_ORDER_STATUS = 6062;
    public static final String WRONG_ORDER_STATUS_MSG = "订单还没有付款";

    public static final int RED_PACKET_NOEXIST = 6101;
    public static final String RED_PACKET_NOEXIST_MSG = "指定的现金红包不存在";

    public static final int RED_PACKET_STATUS_ERR = 6102;
    public static final String RED_PACKET_STATUS_ERR_MSG = "指定的现金红包已被领取";

    public static final int PRODUCT_ABORT_ERR = 9201;
    public static final String PRODUCT_ABORT_ERR_MSG = "该产品已经产生交易，不可作废！";

    public static final int PAID_AMOUNT_LESS_THAN_ZERO = 6063;
    public static final String PAID_AMOUNT_LESS_THAN_ZERO_MSG = "认购金额不能小于现金券金额";

    public static final int TRADE_NOVICE_LABEL_CHECK_FAIL = 6064;
    public static final String TRADE_NOVICE_LABEL_CHECK_FAIL_MSG = "您已有有效投资记录，不可再购买新手标";

    public static final int CHANNEL_COMMISION_REQUEST_REPEAT = 6065;
    public static final String CHANNEL_COMMISION_REQUEST_REPEAT_MSG = "已有该月份的渠道佣金批量请求记录，不可重复产生";

    public static final int NO_ISSUER_USER = 6071;
    public static final String NO_ISSUER_USER_TXT = "没有读取到募集方用户信息";

    public static final int NO_ISSUER_ACCOUNT = 6072;
    public static final String NO_ISSUER_ACCOUNT_TXT = "没有读取到募集方账户信息";

    public static final int NO_INVESTOR_ACCOUNT = 6073;
    public static final String NO_INVESTOR_ACCOUNT_TXT = "没有读取到投资人账户信息";

    public static final int CREATE_ORDER_FAILED = 6074;
    public static final String CREATE_ORDER_FAILED_TXT = "创建订单失败";

    public static final int FREEZE_ACCOUNT_CASH_FAILED = 6201;
    public static final String FREEZE_ACCOUNT_CASH_FAILED_TXT = "扣减账户余额失败";

    public static final int NO_COUPON = 6202;
    public static final String NO_COUPON_TXT = "优惠券不存在";

    public static final int WRONG_COUPON_STATUS = 6203;
    public static final String WRONG_COUPON_STATUS_TXT = "优惠券状态错误";

    public static final int COUPON_EXPIRED = 6204;
    public static final String COUPON_EXPIRED_TXT = "优惠券已过期";

    public static final int COUPON_USED = 6205;
    public static final String COUPON_USED_TXT = "使用优惠券失败";

    public static final int ROOKIE_CHECK_FAILED = 6221;
    public static final String ROOKIE_CHECK_FAILED_TXT = "更新用户交易状态失败";

}
