package cn.zjhf.kingold.trade.utils;

import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by wangxun on 2017/4/19.
 */
public class RequestMapperConvert {
    public static Map<String, String> convert(Map<String, String[]> params) {
        Map<String, String> result = new HashMap<>();
        for (String key : params.keySet()) {
            if (params.get(key)[0] != null) {
                result.put(key, params.get(key)[0]);
            }
        }

        return result;
    }

    /**
     * 对params参数中增加一些标准数据
     *
     * @param params
     */
    public static void initParam(Map params) {
        //修改所有params中value为字符串
        for (Object key : params.keySet()) {
            Object value = params.get(key);
            if (value != null) {
                params.put(key, value.toString());
            }
        }

        //设置分页默认值
        if (params.get("pageSize") == null) {
            params.put("pageSize", 20);
        }
        if (params.get("startRow") == null) {
            params.put("startRow", 0);
        }

    }

    /**
     * 对params参数中增加一些标准数据
     *
     * @param params
     */
    public static void initAccountParam(Map params) {

        String tradeTypes = (String) params.get("tradeType");
        if (StringUtils.isNotBlank(tradeTypes)) {
            List<String> tradeTypeList = Arrays.asList(tradeTypes.split("\\$\\$"));
            params.put("tradeTypeList", tradeTypeList);
        }
        String userUuid = (String) params.get("userUuid");
        if (StringUtils.isNotBlank(userUuid)) {
            List<String> userUuidList = Arrays.asList(userUuid.split("\\$\\$"));
            params.put("userUuidList", userUuidList);
        }

    }


    public static void initTradeRechargeParam(Map paramMap) {

        String rechargeBillCode = MapParamUtils.getStringInMap(paramMap, "rechargeBillCode");
        if (StringUtils.isNotBlank(rechargeBillCode)) {
            List<String> rechargeBillCodeList = Arrays.asList(rechargeBillCode.split("\\$\\$"));
            paramMap.put("rechargeBillCodeList", rechargeBillCodeList);
        }


        String rechargeBillType = MapParamUtils.getStringInMap(paramMap, "rechargeBillType");
        if (StringUtils.isNotBlank(rechargeBillType)) {
            List<String> rechargeBillTypeList = Arrays.asList(rechargeBillType.split("\\$\\$"));
            paramMap.put("rechargeBillTypeList", rechargeBillTypeList);
        }

        String rechargeStatus = MapParamUtils.getStringInMap(paramMap, "rechargeStatus");
        if (StringUtils.isNotBlank(rechargeStatus)) {
            List<String> rechargeStatusList = Arrays.asList(rechargeStatus.split("\\$\\$"));
            paramMap.put("rechargeStatusList", rechargeStatusList);
        }

        String userUuid = (String) paramMap.get("userUuid");
        if (StringUtils.isNotBlank(userUuid)) {
            List<String> userUuidList = Arrays.asList(userUuid.split("\\$\\$"));
            paramMap.put("userUuidList", userUuidList);
        }
    }

    public static void initAccountTransactionParam(Map params) {

        String tradeType = (String) params.get("tradeTypes");
        if (StringUtils.isNotBlank(tradeType)) {
            List<String> tradeTypeList = Arrays.asList(tradeType.split("\\$\\$"));
            params.put("tradeTypeList", tradeTypeList);
        }

        String userUuid = (String) params.get("userUuid");
        if (StringUtils.isNotBlank(userUuid)) {
            List<String> userUuidList = Arrays.asList(userUuid.split("\\$\\$"));
            params.put("userUuidList", userUuidList);
        }

        String accountType = (String) params.get("accountType");
        if (StringUtils.isNotBlank(accountType)) {
            List<String> accountTypeList = Arrays.asList(accountType.split("\\$\\$"));
            params.put("accountTypeList", accountTypeList);
        }

        String tradeOrderBillCodes = (String) params.get("tradeOrderBillCodes");
        if (StringUtils.isNotBlank(tradeOrderBillCodes)) {
            List<String> tradeOrderBillCodeList = Arrays.asList(tradeOrderBillCodes.split("\\$\\$"));
            params.put("tradeOrderBillCodeList", tradeOrderBillCodeList);
        }
    }

    public static void initPrivateFundOrderParam(Map params) {
        String pfoStatus = (String) params.get("pfoStatus");
        if (StringUtils.isNotBlank(pfoStatus)) {
            List<String> pfoStatusList = Arrays.asList(pfoStatus.split("\\$\\$"));
            params.put("pfoStatusList", pfoStatusList);
        }

    }


    /**
     * 对params参数中增加一些标准数据
     * @param params
     */
    public static void initTradeOrderParam(Map params){

        String  orderStatus = (String)params.get("orderStatus");
        if(StringUtils.isNotBlank(orderStatus)){
            List<String> orderStatusList = Arrays.asList(orderStatus.split("\\$\\$"));
            params.put("orderStatusList",orderStatusList);
        }
        String orderBillCode = (String)params.get("orderBillCode");
        if(StringUtils.isNotBlank(orderBillCode)){
            List<String> orderBillCodeList = Arrays.asList(orderBillCode.split("\\$\\$"));
            params.put("orderBillCodeList",orderBillCodeList);
        }
    }

    /**
     * 对params参数中增加一些标准数据
     * @param params
     */
    public static void initCouponParam(Map params){

        String  couponStatus = (String)params.get("couponStatus");
        if(StringUtils.isNotBlank(couponStatus)){
            List<String> couponStatusList = Arrays.asList(couponStatus.split("\\$\\$"));
            params.put("couponStatusList",couponStatusList);
        }

        String  couponExtendCodes = (String)params.get("couponExtendCodes");
        if(StringUtils.isNotBlank(couponExtendCodes)){
            List<String> couponExtendCodeList = Arrays.asList(couponExtendCodes.split("\\$\\$"));
            params.put("couponExtendCodeList",couponExtendCodeList);
        }
    }
}


