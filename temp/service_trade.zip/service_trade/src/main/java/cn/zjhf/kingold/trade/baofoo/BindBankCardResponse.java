package cn.zjhf.kingold.trade.baofoo;

/**
 * Created by lutiehua on 2017/4/27.
 */
public class BindBankCardResponse extends BaoFooResponse {

    public String getCard_id() {
        return card_id;
    }

    public void setCard_id(String card_id) {
        this.card_id = card_id;
    }

    private String card_id;

}
