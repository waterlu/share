package cn.zjhf.kingold.trade.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.entity.TradeOrder;
import cn.zjhf.kingold.trade.entity.TradeRecharge;

/**
 * 定期产品订单的主要事务型方法
 *
 * @author lutiehua
 * @date 2017/6/26
 */
public interface ITradeTransactionService {

    /**
     * 投资
     *
     * @param order
     * @return
     * @throws BusinessException
     */
    ResponseResult invest(TradeOrder order) throws BusinessException;

    /**
     * 提现冻结余额
     *
     * @param tradeRecharge
     * @throws BusinessException
     */
    ResponseResult successWithDraw(TradeRecharge tradeRecharge) throws BusinessException;
}