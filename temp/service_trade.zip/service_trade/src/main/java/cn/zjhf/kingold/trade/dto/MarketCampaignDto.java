package cn.zjhf.kingold.trade.dto;

import cn.zjhf.kingold.common.param.ParamVO;

/**
 * 场景查询dto
 * @author guoxiaoming
 * @date 2018/1/10
 */
public class MarketCampaignDto extends ParamVO{

    /**
     * 前端接受分页页号
     */
    private Integer pageNo;

    /**
     * 每页数据量
     */
    private Integer pageSize;

    /**
     * (pageNo-1)*pageSize
     */
    private Integer startRow;

    /**
     * 场景状态(1未开始，2进行中，3已结束)
     */
    private Integer mcStatus;

    /**
     * 是否送金币（0否 1是）
     */
    private Integer isCoin;

    /**
     * 场景id
     */
    private Integer mcId;

    /**
     * 用户userUuid
     * @return
     */
    private String userUuid;

    /**
     * 场景编号
     */
    private Integer applyScene;

    public Integer getPageNo() {
        return pageNo;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getStartRow() {
        return startRow;
    }

    public void setStartRow(Integer startRow) {
        this.startRow = startRow;
    }

    public Integer getMcStatus() {
        return mcStatus;
    }

    public void setMcStatus(Integer mcStatus) {
        this.mcStatus = mcStatus;
    }

    public Integer getIsCoin() {
        return isCoin;
    }

    public void setIsCoin(Integer isCoin) {
        this.isCoin = isCoin;
    }

    public Integer getMcId() {
        return mcId;
    }

    public void setMcId(Integer mcId) {
        this.mcId = mcId;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public Integer getApplyScene() {
        return applyScene;
    }

    public void setApplyScene(Integer applyScene) {
        this.applyScene = applyScene;
    }
}
