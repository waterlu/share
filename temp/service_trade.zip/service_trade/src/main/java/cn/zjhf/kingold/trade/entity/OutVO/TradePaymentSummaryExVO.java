package cn.zjhf.kingold.trade.entity.OutVO;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.trade.constant.BizDefine;
import cn.zjhf.kingold.trade.entity.TradePaymentSummary;
import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.Date;

@ApiModel(value = "TradePaymentSummaryExVO", description = "产品(到期)兑付资金汇总")
public class TradePaymentSummaryExVO extends ParamVO {

    @ApiModelProperty(required = true, value = "到期返还申请编号  产品到期还款申请编号，自增ID")
    @NotEmpty
    private Long tradePaymentSummaryUuid;

    public double getTotalProfitAmount() {
        return totalProfitAmount;
    }

    public void setTotalProfitAmount(double totalProfitAmount) {
        this.totalProfitAmount = totalProfitAmount;
    }

    @ApiModelProperty(required = true, value = "产品UUID")
    @NotEmpty

    @Size(min = 1, max = 32)
    private String productUuid;

    @ApiModelProperty(required = true, value = "产品编码")
    @NotEmpty
    @Size(min = 1, max = 16)
    private String productCode;

    @ApiModelProperty(required = true, value = "产品类型")
    @NotEmpty
    @Size(min = 1, max = 16)
    private String productType;

    @ApiModelProperty(required = true, value = "产品名称  产品简称")
    @NotEmpty
    @Size(min = 1, max = 40)
    private String productAbbrName;

    @ApiModelProperty(required = true, value = "产品周期，单位 天")
    @NotEmpty
    private int productPeriod;

    @ApiModelProperty(required = true, value = "募集规模")
    @NotEmpty
    private double productScale;

    @ApiModelProperty(required = true, value = "本金 产品本金总金额")
    @NotEmpty
    private double clearPrincAmount;

    @ApiModelProperty(required = true, value = "募集方应还利息(收益) 产品收益总金额")
    @NotEmpty
    private double clearProfitAmount;

    @ApiModelProperty(required = true, value = "募集方应还总额  = clearPrincAmount + clearProfitAmount")
    @NotEmpty
    private double partyRaisedReturnTotalAmount;

    @ApiModelProperty(required = true, value = "平台应还营销利息 营销加息金额")
    @NotEmpty
    private double marketingRateAmount;

    @ApiModelProperty(required = true, value = "总收益  = clearProfitAmount + marketingRateAmount")
    @NotEmpty
    private double totalProfitAmount;

    @ApiModelProperty(required = true, value = "返还总额   产品兑付总金额")
    @NotEmpty
    private double clearTotalAmount;

    @ApiModelProperty(required = true, value = "有效投资用户(个数)   产品兑付总笔数")
    @NotEmpty
    private int clearCount;

    @ApiModelProperty(required = false, value = "审核人")
    @Size(min = 1, max = 32)
    private String auditOperator;

    @ApiModelProperty(required = false, value = "审核时间")
    private Date auditTime;

    @ApiModelProperty(required = false, value = "审核意见")
    @Size(min = 1, max = 512)
    private String auditOpinion;

    @ApiModelProperty(required = false, value = "还款人   兑付人")
    @Size(min = 1, max = 32)
    private String payedOperator;

    @ApiModelProperty(required = false, value = "还款时间   兑付时间")
    private Date payedTime;


    @ApiModelProperty(required = true, value = "用户UUID")
    @NotEmpty
    @Size(min = 1, max = 32)
    private String outClearUserUuid;

    @ApiModelProperty(required = true, value = "账户UUID")
    @NotEmpty
    @Size(min = 1, max = 32)
    private String outClearAccountUuid;

    @ApiModelProperty(required = true, value = "托管机构用户账号")
    @NotEmpty
    @Size(min = 1, max = 32)
    private String outClearAccountNo;

    @ApiModelProperty(required = true, value = "用户UUID")
    @NotEmpty
    @Size(min = 1, max = 32)
    private String outMarketingRateUserUuid;

    @ApiModelProperty(required = true, value = "账户UUID")
    @NotEmpty
    @Size(min = 1, max = 32)
    private String outMarketingRateAccountUuid;

    @ApiModelProperty(required = true, value = "托管机构用户账号")
    @NotEmpty
    @Size(min = 1, max = 32)
    private String outMarketingRateAccountNo;

    @ApiModelProperty(required = true, value = "还款状态： -1审核失败；1待审核；2审核通过；3已兑付")
    @NotEmpty
    private int transactionStatus;

    @ApiModelProperty(required = false, value = "签名")
    @Size(min = 1, max = 128)
    private String signature;

    @ApiModelProperty(required = true, value = "删除标记 0未删除，1已删除")
    @NotEmpty
    private int deleteFlag;

    @ApiModelProperty(required = true, value = "")
    @NotEmpty
    private Date createTime;

    @ApiModelProperty(required = true, value = "")
    @NotEmpty
    private Date updateTime;

    public TradePaymentSummaryExVO() {
    }

    public TradePaymentSummaryExVO(TradePaymentSummary tradePaymentSummary) {
        if(tradePaymentSummary != null) {
            this.tradePaymentSummaryUuid = tradePaymentSummary.getTradePaymentSummaryUuid();
            this.productUuid = tradePaymentSummary.getProductUuid();
            this.productCode = tradePaymentSummary.getProductCode();
            this.productType = tradePaymentSummary.getProductType();
            this.productAbbrName = tradePaymentSummary.getProductAbbrName();
            this.productPeriod = tradePaymentSummary.getProductPeriod();
            this.clearCount = tradePaymentSummary.getClearCount();
            this.clearTotalAmount = tradePaymentSummary.getClearTotalAmount().doubleValue();
            this.clearPrincAmount = tradePaymentSummary.getClearPrincAmount().doubleValue();
            this.clearProfitAmount = tradePaymentSummary.getClearProfitAmount().doubleValue();
            this.marketingRateAmount = tradePaymentSummary.getMarketingRateAmount().doubleValue();
            this.outClearUserUuid = tradePaymentSummary.getOutClearUserUuid();
            this.outClearAccountUuid = tradePaymentSummary.getOutClearAccountUuid();
            this.outClearAccountNo = tradePaymentSummary.getOutClearAccountNo();
            this.outMarketingRateUserUuid = tradePaymentSummary.getOutMarketingRateUserUuid();
            this.outMarketingRateAccountUuid = tradePaymentSummary.getOutMarketingRateAccountUuid();
            this.outMarketingRateAccountNo = tradePaymentSummary.getOutMarketingRateAccountNo();
            this.transactionStatus = tradePaymentSummary.getTransactionStatus();
            this.auditOperator = tradePaymentSummary.getAuditOperator();
            this.auditTime = tradePaymentSummary.getAuditTime();
            this.auditOpinion = tradePaymentSummary.getAuditOpinion();
            this.payedOperator = tradePaymentSummary.getPayedOperator();
            this.payedTime = tradePaymentSummary.getPayedTime();
            this.signature = tradePaymentSummary.getSignature();
            this.deleteFlag = tradePaymentSummary.getDeleteFlag();
            this.createTime = tradePaymentSummary.getCreateTime();
            this.updateTime = tradePaymentSummary.getUpdateTime();

            this.partyRaisedReturnTotalAmount = this.clearPrincAmount + this.clearProfitAmount;
            this.totalProfitAmount = this.clearProfitAmount + this.marketingRateAmount;
        }
    }

    public Long getTradePaymentSummaryUuid() {
        return tradePaymentSummaryUuid;
    }

    public void setTradePaymentSummaryUuid(Long tradePaymentSummaryUuid) {
        this.tradePaymentSummaryUuid = tradePaymentSummaryUuid;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getProductAbbrName() {
        return productAbbrName;
    }

    public void setProductAbbrName(String productAbbrName) {
        this.productAbbrName = productAbbrName;
    }

    public int getProductPeriod() {
        return productPeriod;
    }

    public void setProductPeriod(int productPeriod) {
        this.productPeriod = productPeriod;
    }

    public int getClearCount() {
        return clearCount;
    }

    public void setClearCount(int clearCount) {
        this.clearCount = clearCount;
    }

    public double getClearTotalAmount() {
        return clearTotalAmount;
    }

    public void setClearTotalAmount(double clearTotalAmount) {
        this.clearTotalAmount = clearTotalAmount;
    }

    public double getClearPrincAmount() {
        return clearPrincAmount;
    }

    public void setClearPrincAmount(double clearPrincAmount) {
        this.clearPrincAmount = clearPrincAmount;
    }

    public double getClearProfitAmount() {
        return clearProfitAmount;
    }

    public void setClearProfitAmount(double clearProfitAmount) {
        this.clearProfitAmount = clearProfitAmount;
    }

    public double getMarketingRateAmount() {
        return marketingRateAmount;
    }

    public void setMarketingRateAmount(double marketingRateAmount) {
        this.marketingRateAmount = marketingRateAmount;
    }

    public String getOutClearUserUuid() {
        return outClearUserUuid;
    }

    public void setOutClearUserUuid(String outClearUserUuid) {
        this.outClearUserUuid = outClearUserUuid;
    }

    public String getOutClearAccountUuid() {
        return outClearAccountUuid;
    }

    public void setOutClearAccountUuid(String outClearAccountUuid) {
        this.outClearAccountUuid = outClearAccountUuid;
    }

    public String getOutClearAccountNo() {
        return outClearAccountNo;
    }

    public void setOutClearAccountNo(String outClearAccountNo) {
        this.outClearAccountNo = outClearAccountNo;
    }

    public String getOutMarketingRateUserUuid() {
        return outMarketingRateUserUuid;
    }

    public void setOutMarketingRateUserUuid(String outMarketingRateUserUuid) {
        this.outMarketingRateUserUuid = outMarketingRateUserUuid;
    }

    public String getOutMarketingRateAccountUuid() {
        return outMarketingRateAccountUuid;
    }

    public void setOutMarketingRateAccountUuid(String outMarketingRateAccountUuid) {
        this.outMarketingRateAccountUuid = outMarketingRateAccountUuid;
    }

    public String getOutMarketingRateAccountNo() {
        return outMarketingRateAccountNo;
    }

    public void setOutMarketingRateAccountNo(String outMarketingRateAccountNo) {
        this.outMarketingRateAccountNo = outMarketingRateAccountNo;
    }

    public int getTransactionStatus() {
        return transactionStatus;
    }

    public void setTransactionStatus(int transactionStatus) {
        this.transactionStatus = transactionStatus;
    }

    public String getAuditOperator() {
        return auditOperator;
    }

    public void setAuditOperator(String auditOperator) {
        this.auditOperator = auditOperator;
    }

    public Date getAuditTime() {
        return auditTime;
    }

    public void setAuditTime(Date auditTime) {
        this.auditTime = auditTime;
    }

    public String getAuditOpinion() {
        return auditOpinion;
    }

    public void setAuditOpinion(String auditOpinion) {
        this.auditOpinion = auditOpinion;
    }

    public String getPayedOperator() {
        return payedOperator;
    }

    public void setPayedOperator(String payedOperator) {
        this.payedOperator = payedOperator;
    }

    public Date getPayedTime() {
        return payedTime;
    }

    public void setPayedTime(Date payedTime) {
        this.payedTime = payedTime;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public int getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(int deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public TradePaymentSummary get() {
        TradePaymentSummary tradePaymentSummary = new TradePaymentSummary();
        tradePaymentSummary.setTradePaymentSummaryUuid(tradePaymentSummaryUuid);
        tradePaymentSummary.setProductUuid(productUuid);
        tradePaymentSummary.setProductCode(productCode);
        tradePaymentSummary.setProductType(productType);
        tradePaymentSummary.setProductAbbrName(productAbbrName);
        tradePaymentSummary.setProductPeriod(productPeriod);
        tradePaymentSummary.setClearCount(clearCount);
        tradePaymentSummary.setClearTotalAmount(new BigDecimal(clearTotalAmount));
        tradePaymentSummary.setClearPrincAmount(new BigDecimal(clearPrincAmount));
        tradePaymentSummary.setClearProfitAmount(new BigDecimal(clearProfitAmount));
        tradePaymentSummary.setMarketingRateAmount(new BigDecimal(marketingRateAmount));
        tradePaymentSummary.setOutClearUserUuid(outClearUserUuid);
        tradePaymentSummary.setOutClearAccountUuid(outClearAccountUuid);
        tradePaymentSummary.setOutClearAccountNo(outClearAccountNo);
        tradePaymentSummary.setOutMarketingRateUserUuid(outMarketingRateUserUuid);
        tradePaymentSummary.setOutMarketingRateAccountUuid(outMarketingRateAccountUuid);
        tradePaymentSummary.setOutMarketingRateAccountNo(outMarketingRateAccountNo);
        tradePaymentSummary.setTransactionStatus(new Integer(transactionStatus).byteValue());
        tradePaymentSummary.setAuditOperator(auditOperator);
        tradePaymentSummary.setAuditTime(auditTime);
        tradePaymentSummary.setAuditOpinion(auditOpinion);
        tradePaymentSummary.setPayedOperator(payedOperator);
        tradePaymentSummary.setPayedTime(payedTime);
        tradePaymentSummary.setSignature(signature);
        tradePaymentSummary.setDeleteFlag(new Integer(deleteFlag).byteValue());
        tradePaymentSummary.setCreateTime(createTime);
        tradePaymentSummary.setUpdateTime(updateTime);
        return tradePaymentSummary;
    }

    public double getProductScale() {
        return productScale;
    }

    public void setProductScale(double productScale) {
        this.productScale = productScale;
    }

    public double getPartyRaisedReturnTotalAmount() {
        return partyRaisedReturnTotalAmount;
    }

    public void setPartyRaisedReturnTotalAmount(double partyRaisedReturnTotalAmount) {
        this.partyRaisedReturnTotalAmount = partyRaisedReturnTotalAmount;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("tradePaymentSummaryUuid:" + DataUtils.toString(tradePaymentSummaryUuid) + ", ");
        sb.append("productUuid:" + DataUtils.toString(productUuid) + ", ");
        sb.append("productCode:" + DataUtils.toString(productCode) + ", ");
        sb.append("productType:" + DataUtils.toString(productType) + ", ");
        sb.append("productAbbrName:" + DataUtils.toString(productAbbrName) + ", ");
        sb.append("productPeriod:" + DataUtils.toString(productPeriod) + ", ");
        sb.append("productScale:" + DataUtils.toString(productScale) + ", ");
        sb.append("clearPrincAmount:" + DataUtils.toString(clearPrincAmount) + ", ");
        sb.append("clearProfitAmount:" + DataUtils.toString(clearProfitAmount) + ", ");
        sb.append("partyRaisedReturnTotalAmount:" + DataUtils.toString(partyRaisedReturnTotalAmount) + ", ");
        sb.append("marketingRateAmount:" + DataUtils.toString(marketingRateAmount) + ", ");
        sb.append("totalProfitAmount:" + DataUtils.toString(totalProfitAmount) + ", ");
        sb.append("clearTotalAmount:" + DataUtils.toString(clearTotalAmount) + ", ");
        sb.append("clearCount:" + DataUtils.toString(clearCount) + ", ");
        sb.append("auditOperator:" + DataUtils.toString(auditOperator) + ", ");
        sb.append("auditTime:" + DataUtils.toString(auditTime) + ", ");
        sb.append("auditOpinion:" + DataUtils.toString(auditOpinion) + ", ");
        sb.append("payedOperator:" + DataUtils.toString(payedOperator) + ", ");
        sb.append("payedTime:" + DataUtils.toString(payedTime) + ", ");
        sb.append("outClearUserUuid:" + DataUtils.toString(outClearUserUuid) + ", ");
        sb.append("outClearAccountUuid:" + DataUtils.toString(outClearAccountUuid) + ", ");
        sb.append("outClearAccountNo:" + DataUtils.toString(outClearAccountNo) + ", ");
        sb.append("outMarketingRateUserUuid:" + DataUtils.toString(outMarketingRateUserUuid) + ", ");
        sb.append("outMarketingRateAccountUuid:" + DataUtils.toString(outMarketingRateAccountUuid) + ", ");
        sb.append("outMarketingRateAccountNo:" + DataUtils.toString(outMarketingRateAccountNo) + ", ");
        sb.append("transactionStatus:" + DataUtils.toString(transactionStatus) + ", ");
        sb.append("signature:" + DataUtils.toString(signature) + ", ");
        sb.append("deleteFlag:" + DataUtils.toString(deleteFlag) + ", ");
        sb.append("createTime:" + DataUtils.toString(createTime) + ", ");
        sb.append("updateTime:" + DataUtils.toString(updateTime));
        return sb.toString();
    }
}

