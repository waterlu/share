package cn.zjhf.kingold.trade.persistence.mq.message;

import cn.zjhf.kingold.rocketmq.base.MQMessage;

/**
 * 用户注册成功消息
 *
 * Created by lutiehua on 2017/7/14.
 */
public class UserMessage implements MQMessage {
    /**
     * 注册人
     */
    private String userUuid;

    /**
     * 注册人手机号
     */
    private String investorMobile;

    /**
     * 邀请人uuid
     */
    private String inviterUuid;

    /**
     * 商户号
     */
    private String merchantNum;

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getInvestorMobile() {
        return investorMobile;
    }

    public void setInvestorMobile(String investorMobile) {
        this.investorMobile = investorMobile;
    }

    public String getInviterUuid() {
        return inviterUuid;
    }

    public void setInviterUuid(String inviterUuid) {
        this.inviterUuid = inviterUuid;
    }

    public String getMerchantNum() {
        return merchantNum;
    }

    public void setMerchantNum(String merchantNum) {
        this.merchantNum = merchantNum;
    }

    @Override
    public String getKey() {
        return getUserUuid();
    }

    public UserMessage(){}
}
