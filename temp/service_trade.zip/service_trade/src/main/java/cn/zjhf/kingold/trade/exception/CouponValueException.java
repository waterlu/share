package cn.zjhf.kingold.trade.exception;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.constant.TradeStatusMsg;

/**
 * 优惠券状态异常
 *
 * @author lutiehua
 * @date 2018/3/9
 */
public class CouponValueException extends BusinessException {

    public CouponValueException() {
        super(TradeStatusMsg.PAID_AMOUNT_LESS_THAN_ZERO, TradeStatusMsg.PAID_AMOUNT_LESS_THAN_ZERO_MSG, true);
    }

}
