package cn.zjhf.kingold.trade.persistence.mq.producer;

import cn.zjhf.kingold.rocketmq.annotation.RocketMQProducer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQProducer;
import cn.zjhf.kingold.trade.persistence.mq.message.CouponMessage;
import cn.zjhf.kingold.trade.persistence.mq.message.GoldCoinMessage;

/**
 * Created by Xiaody on 17/7/27.
 */
@RocketMQProducer(topic = "gold_coin", tag = "establish")
public class EstablishGoldCoinProducer extends AbstractMQProducer<GoldCoinMessage> {


}
