package cn.zjhf.kingold.trade.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author
 */
public class TradePaymentSummary implements Serializable {
    /**
     * 产品到期还款申请编号，自增ID
     */
    private Long tradePaymentSummaryUuid;

    /**
     * 批次号
     */
    private String batchNo;

    /**
     * 产品UUID
     */
    private String productUuid;

    /**
     * 产品编码
     */
    private String productCode;

    /**
     * 产品类型
     */
    private String productType;

    /**
     * 产品简称
     */
    private String productAbbrName;

    /**
     * 产品周期，单位 天
     */
    private Integer productPeriod;

    /**
     * 产品兑付总笔数
     */
    private Integer clearCount;

    /**
     * 产品兑付总金额
     */
    private BigDecimal clearTotalAmount;

    /**
     * 产品本金总金额
     */
    private BigDecimal clearPrincAmount;

    /**
     * 产品收益总金额
     */
    private BigDecimal clearProfitAmount;

    /**
     * 营销加息金额
     */
    private BigDecimal marketingRateAmount;

    /**
     * 用户UUID
     */
    private String outClearUserUuid;

    /**
     * 账户UUID
     */
    private String outClearAccountUuid;

    /**
     * 托管机构用户账号
     */
    private String outClearAccountNo;

    /**
     * 用户UUID
     */
    private String outMarketingRateUserUuid;

    /**
     * 账户UUID
     */
    private String outMarketingRateAccountUuid;

    /**
     * 托管机构用户账号
     */
    private String outMarketingRateAccountNo;

    /**
     * 处理状态: -1审批失败；1待审核；2审核通过; 3已兑付
     */
    private Byte transactionStatus;

    /**
     * 审核人
     */
    private String auditOperator;

    /**
     * 审核时间
     */
    private Date auditTime;

    /**
     * 审核意见
     */
    private String auditOpinion;

    /**
     * 兑付人
     */
    private String payedOperator;

    /**
     * 兑付时间
     */
    private Date payedTime;

    /**
     * 签名
     */
    private String signature;

    /**
     * 删除标记 0未删除，1已删除
     */
    private Byte deleteFlag;

    private Date createTime;

    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public Long getTradePaymentSummaryUuid() {
        return tradePaymentSummaryUuid;
    }

    public void setTradePaymentSummaryUuid(Long tradePaymentSummaryUuid) {
        this.tradePaymentSummaryUuid = tradePaymentSummaryUuid;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getProductAbbrName() {
        return productAbbrName;
    }

    public void setProductAbbrName(String productAbbrName) {
        this.productAbbrName = productAbbrName;
    }

    public Integer getProductPeriod() {
        return productPeriod;
    }

    public void setProductPeriod(Integer productPeriod) {
        this.productPeriod = productPeriod;
    }

    public Integer getClearCount() {
        return clearCount;
    }

    public void setClearCount(Integer clearCount) {
        this.clearCount = clearCount;
    }

    public BigDecimal getClearTotalAmount() {
        return clearTotalAmount;
    }

    public void setClearTotalAmount(BigDecimal clearTotalAmount) {
        this.clearTotalAmount = clearTotalAmount;
    }

    public BigDecimal getClearPrincAmount() {
        return clearPrincAmount;
    }

    public void setClearPrincAmount(BigDecimal clearPrincAmount) {
        this.clearPrincAmount = clearPrincAmount;
    }

    public BigDecimal getClearProfitAmount() {
        return clearProfitAmount;
    }

    public void setClearProfitAmount(BigDecimal clearProfitAmount) {
        this.clearProfitAmount = clearProfitAmount;
    }

    public BigDecimal getMarketingRateAmount() {
        return marketingRateAmount;
    }

    public void setMarketingRateAmount(BigDecimal marketingRateAmount) {
        this.marketingRateAmount = marketingRateAmount;
    }

    public String getOutClearUserUuid() {
        return outClearUserUuid;
    }

    public void setOutClearUserUuid(String outClearUserUuid) {
        this.outClearUserUuid = outClearUserUuid;
    }

    public String getOutClearAccountUuid() {
        return outClearAccountUuid;
    }

    public void setOutClearAccountUuid(String outClearAccountUuid) {
        this.outClearAccountUuid = outClearAccountUuid;
    }

    public String getOutClearAccountNo() {
        return outClearAccountNo;
    }

    public void setOutClearAccountNo(String outClearAccountNo) {
        this.outClearAccountNo = outClearAccountNo;
    }

    public String getOutMarketingRateUserUuid() {
        return outMarketingRateUserUuid;
    }

    public void setOutMarketingRateUserUuid(String outMarketingRateUserUuid) {
        this.outMarketingRateUserUuid = outMarketingRateUserUuid;
    }

    public String getOutMarketingRateAccountUuid() {
        return outMarketingRateAccountUuid;
    }

    public void setOutMarketingRateAccountUuid(String outMarketingRateAccountUuid) {
        this.outMarketingRateAccountUuid = outMarketingRateAccountUuid;
    }

    public String getOutMarketingRateAccountNo() {
        return outMarketingRateAccountNo;
    }

    public void setOutMarketingRateAccountNo(String outMarketingRateAccountNo) {
        this.outMarketingRateAccountNo = outMarketingRateAccountNo;
    }

    public Byte getTransactionStatus() {
        return transactionStatus;
    }

    public void setTransactionStatus(Byte transactionStatus) {
        this.transactionStatus = transactionStatus;
    }

    public String getAuditOperator() {
        return auditOperator;
    }

    public void setAuditOperator(String auditOperator) {
        this.auditOperator = auditOperator;
    }

    public Date getAuditTime() {
        return auditTime;
    }

    public void setAuditTime(Date auditTime) {
        this.auditTime = auditTime;
    }

    public String getAuditOpinion() {
        return auditOpinion;
    }

    public void setAuditOpinion(String auditOpinion) {
        this.auditOpinion = auditOpinion;
    }

    public String getPayedOperator() {
        return payedOperator;
    }

    public void setPayedOperator(String payedOperator) {
        this.payedOperator = payedOperator;
    }

    public Date getPayedTime() {
        return payedTime;
    }

    public void setPayedTime(Date payedTime) {
        this.payedTime = payedTime;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}