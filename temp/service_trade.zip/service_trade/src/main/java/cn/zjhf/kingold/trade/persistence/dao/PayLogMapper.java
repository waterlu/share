package cn.zjhf.kingold.trade.persistence.dao;

import cn.zjhf.kingold.trade.entity.PayLog;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PayLogMapper {
    int deleteByPrimaryKey(String payOrderId);

    int insert(PayLog record);

    PayLog selectByPrimaryKey(String payOrderId);

    int updateByPrimaryKey(PayLog record);

    List<PayLog> queryByOrderBillCode(String orderBillCode);

    List<PayLog> querySuccessByOrderBillCode(String orderBillCode);

    int updatePayInfo(PayLog record);

    int updateRequestByOrderBillCode(PayLog record);

    int updateTimeoutStatus(String payOrderId);
}