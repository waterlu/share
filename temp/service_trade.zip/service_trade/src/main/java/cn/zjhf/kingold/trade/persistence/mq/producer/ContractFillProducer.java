package cn.zjhf.kingold.trade.persistence.mq.producer;

import cn.zjhf.kingold.rocketmq.annotation.RocketMQProducer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQProducer;
import cn.zjhf.kingold.trade.persistence.mq.message.ContractFillMessage;

/**
 * Created by zhangyijie on 2018/3/12.
 */
@RocketMQProducer(topic = "product", tag = "establishloanclear_contractfill")
public class ContractFillProducer extends AbstractMQProducer<ContractFillMessage> {
}
