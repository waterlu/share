package cn.zjhf.kingold.trade.constant;
/**
 * @Author liuyao
 * @Description
 * @Date Created in 9:58 2017/6/2
 */

public class PayResponseCode {

    public final static int OK = 200;
    public final static String OK_MSG = "成功";

    public final static int ERROR_UNKNOW_CODE = 0;
    public final static String ERROR_UNKNOW_MSG = "未知错误";

    public final static int SOCKET_TIMEOUT_ERROR_CODE = 8001;
    public final static String SOCKET_TIMEOUT_ERROR_MSG = "请求超时";

    public final static int ERROR_PARAMETER_CODE = 8002;
    public final static String ERROR_PARAMETER_MSG = "参数解析错误";

    public final static int ERROR_USER_EXIST_CODE = 8003;
    public final static String ERROR_USER_EXIST_MSG = "该会员已经存在";

    public final static int ERROR_USER_HAS_CANCLE_BIND_CODE = 8004;
    public final static String ERROR_USER_HAS_CANCLE_BIND_MSG = "该会员已注销资当前商户资金托管";

    public final static int ERROR_ORDER_REPEAT_CODE = 8005;
    public final static String ERROR_ORDER_REPEAT_MSG = "单号不能重复";

    public final static int ERROR_PAY_AMOUNT_SUM_CODE = 8006;
    public final static String ERROR_PAY_AMOUNT_SUM_MSG = "满标金额，与投资金额不一致";

    public final static int ERROR_USER_NOT_EXIST_CODE = 8007;
    public final static String ERROR_USER_NOT_EXIST_MSG = "该会员不存在";

    public final static int ERROR_DEAL_CODE = 8009;
    public final static String ERROR_DEAL_MSG = "处理失败";

    public final static int ERROR_SMS_VERIFY_CODE = 8010;
    public final static String ERROR_SMS_VERIFY_MSG = "验证码错误";

    public final static int ERROR_EXIST_ACCOUNT_BIND_CODE = 8011;
    public final static String ERROR_EXIST_ACCOUNT_BIND_MSG = "该账号已经被绑定";

    public final static int GET_STATUS_FAILED = 8100;
    public final static String GET_STATUS_FAILED_MSG = "获取支付状态失败";

    public final static int REPEATED_PAYMENT = 8101;
    public final static String REPEATED_PAYMENT_MSG = "发现重复支付记录";

    public final static int NO_PAY_ORDER_PAYMENT = 8104;
    public final static String NO_PAY_ORDER_PAYMENT_MSG = "没有充值单";

    public final static int FAILED_OPERATION = 8102;
    public final static String FAILED_OPERATION_MSG = "操作已经失败";

    public final static int PENDING_OPERATION = 8103;
    public final static String PENDING_OPERATION_MSG = "操作正在处理中";
}
