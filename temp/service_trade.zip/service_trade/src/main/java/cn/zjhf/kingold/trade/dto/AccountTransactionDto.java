package cn.zjhf.kingold.trade.dto;

import cn.zjhf.kingold.trade.dto.options.PageOptions;

import java.io.Serializable;

/**
 * @author
 */
public class AccountTransactionDto extends PageOptions implements Serializable {

    /**
     * 用户（电话号码）
     */
    private String investorMobile;

    /**
     * 交易类型
     */
    private String tradeTypes;

    /**
     * 用户类型（投资人21，融资方31）
     */
    private String accountType;

    /**
     * 企业邮箱
     */
    private String issuerEmail;

    /**
     * 企业名称
     */
    private String issuerName;

    /**
     * 查询开始时间
     */
    private String transactionTimeFrom;

    /**
     * 查询结束时间
     */
    private String transactionTimeTo;

    /**
     * 关联单
     */
    private String tradeOrderBillCode;

    public String getInvestorMobile() {
        return investorMobile;
    }

    public void setInvestorMobile(String investorMobile) {
        this.investorMobile = investorMobile;
    }

    public String getTradeTypes() {
        return tradeTypes;
    }

    public void setTradeTypes(String tradeTypes) {
        this.tradeTypes = tradeTypes;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getIssuerEmail() {
        return issuerEmail;
    }

    public void setIssuerEmail(String issuerEmail) {
        this.issuerEmail = issuerEmail;
    }

    public String getIssuerName() {
        return issuerName;
    }

    public void setIssuerName(String issuerName) {
        this.issuerName = issuerName;
    }

    public String getTransactionTimeFrom() {
        return transactionTimeFrom;
    }

    public void setTransactionTimeFrom(String transactionTimeFrom) {
        this.transactionTimeFrom = transactionTimeFrom;
    }

    public String getTransactionTimeTo() {
        return transactionTimeTo;
    }

    public void setTransactionTimeTo(String transactionTimeTo) {
        this.transactionTimeTo = transactionTimeTo;
    }

    public String getTradeOrderBillCode() {
        return tradeOrderBillCode;
    }

    public void setTradeOrderBillCode(String tradeOrderBillCode) {
        this.tradeOrderBillCode = tradeOrderBillCode;
    }

    @Override
    public String toString() {
        return "AccountTransactionDto{" +
                "investorMobile='" + investorMobile + '\'' +
                ", tradeTypes='" + tradeTypes + '\'' +
                ", accountType='" + accountType + '\'' +
                ", issuerEmail='" + issuerEmail + '\'' +
                ", issuerName='" + issuerName + '\'' +
                ", transactionTimeFrom='" + transactionTimeFrom + '\'' +
                ", transactionTimeTo='" + transactionTimeTo + '\'' +
                ", tradeOrderBillCode='" + tradeOrderBillCode + '\'' +
                '}';
    }
}