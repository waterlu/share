package cn.zjhf.kingold.trade.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.constant.ProductType;
import cn.zjhf.kingold.trade.constant.RewardType;
import cn.zjhf.kingold.trade.dto.RewardSearchDto;
import cn.zjhf.kingold.trade.entity.Reward;
import cn.zjhf.kingold.trade.service.IRewardService;
import cn.zjhf.kingold.trade.service.IRewardSummaryExecService;
import cn.zjhf.kingold.trade.service.ITradePrivateFundOrderService;
import cn.zjhf.kingold.trade.utils.MapParamUtils;
import cn.zjhf.kingold.trade.vo.RewardConfigVO;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.base.Splitter;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.*;

/**
 * @Author liuyao
 * @Description
 * @Date Created in 15:17 2017/5/31
 */

@RestController
@RequestMapping(value = "/reward")
public class RewardController {

    @Autowired
    private IRewardService rewardService;

    @Autowired
    private ITradePrivateFundOrderService tradePrivateFundOrderService;

    @Autowired
    private IRewardSummaryExecService rewardSummaryExecService;

    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public ResponseResult getAwardList(@RequestParam(value = "userUuid") String userUuid,
                                       @RequestParam(value = "rewardStatus", required = false) Integer rewardStatus,
                                       @RequestParam(value = "rewardType", required = false) Integer rewardType,
                                       @RequestParam(value = "traceID") String traceID,
                                       @RequestParam(value = "pageNo", defaultValue = "1") Integer pageNo,
                                       @RequestParam(value = "pageSize", defaultValue = "20") Integer pageSize) throws BusinessException {
        List<Reward> list = rewardService.getRewardList(userUuid, rewardStatus, rewardType, (pageNo - 1) * pageSize, pageSize);
        return new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS, "成功", list);
    }

    @RequestMapping(value = "/list/order/sum", method = RequestMethod.GET)
    public ResponseResult getAwardList(@RequestParam(value = "userUuid") String userUuid,
                                       @RequestParam(value = "traceID") String traceID,
                                       @RequestParam(value = "startRow", defaultValue = "0") Integer startRow,
                                       @RequestParam(value = "isInvest", defaultValue = "0") Integer isInvest,
                                       @RequestParam(value = "pageSize", defaultValue = "20") Integer pageSize) throws BusinessException {
        List<Map<String, BigDecimal>> result = rewardService.listOrderBySum(userUuid,isInvest,startRow, pageSize);
        return new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS, "成功", result);
    }

    @RequestMapping(value = "/list/invitedUuids", method = RequestMethod.GET)
    public ResponseResult getAwardSumListByUuids(@RequestParam(value = "invitedUuids") String invitedUuids,
                                                 @RequestParam(value = "userUuid") String userUuid,
                                                 @RequestParam(value = "productType", defaultValue = "FIXI", required = false) String productType,
                                                 @RequestParam(value = "traceID") String traceID) throws BusinessException {
        List<String> invitedUuidList = Lists.newArrayList(Splitter.on("$$").trimResults().omitEmptyStrings().split(invitedUuids));
        Map<String, BigDecimal> result = rewardService.getRewardSumListByUuids(invitedUuidList, userUuid, productType);
        return new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS, "成功", result);
    }

    @RequestMapping(value = "/count", method = RequestMethod.GET)
    public ResponseResult getAwardList(@RequestParam(value = "userUuid") String userUuid,
                                       @RequestParam(value = "rewardStatus", required = false) Integer rewardStatus,
                                       @RequestParam(value = "rewardType", required = false) Integer rewardType,
                                       @RequestParam(value = "traceID") String traceID) throws BusinessException {
        Integer count = rewardService.getRewardCount(userUuid, rewardStatus, rewardType);
        return new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS, "成功", count);
    }

    @RequestMapping(value = "/detail", method = RequestMethod.GET)
    public ResponseResult detail(@RequestParam(value = "rewardBillCode", required = false) String rewardBillCode,
                                 @RequestParam(value = "traceID") String traceID) throws BusinessException {
        Reward reward = rewardService.getRewardDetail(rewardBillCode);
        if (reward.getProductType().equals(ProductType.PRODUCT_PF)) {
            Map<String, String> params = new HashMap<>();
            params.put("pfoCode", reward.getOrderBillCode());
            Map map = tradePrivateFundOrderService.getWithFilter(params);
            JSONObject jsonObject = JSON.parseObject(JSON.toJSONString(reward));
            jsonObject.put("beInvitedUserName", map.get("customerName") == null ? "" : map.get("customerName"));
            jsonObject.put("beInvitedIdCardNo", map.get("customerIdCardNo") == null ? "" : map.get("customerIdCardNo"));
            jsonObject.put("beInvitedMobile", map.get("customerMobile") == null ? "" : map.get("customerMobile"));
            jsonObject.put("beInvitedAddress", map.get("customerAddress") == null ? "" : map.get("customerAddress"));
            return new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS, "成功", jsonObject);
        }
        return new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS, "成功", reward);
    }

    @RequestMapping(value = "/sum", method = RequestMethod.GET)
    public ResponseResult sum(@RequestParam(value = "userUuid") String userUuid,
                                    @RequestParam(value = "rewardType", required = false) Integer rewardType,
                                    @RequestParam(value = "traceID") String traceID) throws BusinessException {
        Map<String, String> result = rewardService.getRewardSum(userUuid, rewardType);
        return new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS, "成功", result);
    }

    /**
     * 查询奖励记录（运营后台用）
     *
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/search", method = RequestMethod.GET)
    public ResponseResult search(@RequestParam Map<String, Object> param) throws BusinessException {
        String jsonString = JSON.toJSONString(param);
        RewardSearchDto searchCondition = JSON.parseObject(jsonString, RewardSearchDto.class);

        // 保证""不作为查询条件
        if (StringUtils.isEmpty(searchCondition.getProductType())) {
            searchCondition.setProductType(null);
        }
        if (StringUtils.isEmpty(searchCondition.getOrderBillCode())) {
            searchCondition.setOrderBillCode(null);
        }
        if (StringUtils.isEmpty(searchCondition.getProductName())) {
            searchCondition.setProductName(null);
        }
        if (StringUtils.isEmpty(searchCondition.getUserMobile())) {
            searchCondition.setUserMobile(null);
        }
        if (StringUtils.isEmpty(searchCondition.getRewardBillCode())) {
            searchCondition.setRewardBillCode(null);
        }
        if((searchCondition.getRewardType() == null) || (searchCondition.getRewardType() == 0)) {
            List<Integer> rewardTypes = ImmutableList.of(RewardType.REWARD_SALE, RewardType.REWARD_INVITER_LEVEL_ONE, RewardType.REWARD_INVITER_LEVEL_TWO,
                    RewardType.REWARD_MASTER_INVITER_LEVEL_ONE,RewardType.REWARD_MASTER_INVITER_LEVEL_TWO,RewardType.REWARD_MASTER_INVITER_LEVEL_THREE);
            searchCondition.setRewardTypes(rewardTypes);
        }

        if (null != searchCondition.getToCreateTime()) {
            // 包括结束日期，查询时加1天
            Date endDate = searchCondition.getToCreateTime();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(endDate);
            calendar.add(Calendar.DAY_OF_YEAR, 1);
            endDate = calendar.getTime();
            searchCondition.setToCreateTime(endDate);
        }

        if (null != searchCondition.getToUpdateTime()) {
            // 包括结束日期，查询时加1天
            Date endDate = searchCondition.getToUpdateTime();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(endDate);
            calendar.add(Calendar.DAY_OF_YEAR, 1);
            endDate = calendar.getTime();
            searchCondition.setToUpdateTime(endDate);
        }

        // 不限制是否有效
        searchCondition.setIsEnabledReward(null);

        List<Reward> rewardList = rewardService.searchReward(searchCondition);
        int count = rewardService.searchRewardCount(searchCondition);
        Map<String, Object> data = new HashMap<>();
        data.put("list", rewardList);
        data.put("count", count);
        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        responseResult.setTraceID(searchCondition.getTraceID());
        responseResult.setData(data);
        return responseResult;
    }

    /**
     * @param param
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/summary/detail", method = RequestMethod.GET)
    public ResponseResult getFixedAward(@RequestParam Map<String, Object> param) throws BusinessException {
        String traceID = param.get("traceID").toString();
        String summaryBillCode = param.get("summaryBillCode").toString();
        int pageNo = Integer.parseInt(param.get("pageNo").toString());
        int pageSize = Integer.parseInt(param.get("pageSize").toString());

        List<Reward> rewardList = rewardService.searchSummaryReward(summaryBillCode, pageNo, pageSize);
        int count = rewardService.searchSummaryRewardCount(summaryBillCode);
        Map<String, Object> data = new HashMap<>();
        data.put("list", rewardList);
        data.put("count", count);
        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        responseResult.setTraceID(traceID);
        responseResult.setData(data);
        return responseResult;
    }

    /**
     * 预申请
     *
     * @param param
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/preApply", method = RequestMethod.GET)
    public ResponseResult preApply(@RequestParam Map<String, Object> param) throws BusinessException {
        String jsonString = JSON.toJSONString(param);
        RewardSearchDto searchCondition = JSON.parseObject(jsonString, RewardSearchDto.class);

        List<Reward> rewardList = rewardService.preApply(searchCondition);
        Map<String, Object> data = new HashMap<>();
        data.put("count", rewardList.size());
        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        if (null != param.get("traceID")) {
            String traceID = param.get("traceID").toString();
            responseResult.setTraceID(traceID);
        }
        responseResult.setData(data);
        return responseResult;
    }

    /**
     * 服务津贴预申请
     *
     * @param param
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/preApplyService", method = RequestMethod.GET)
    public ResponseResult preApplyService(@RequestParam Map<String, Object> param) throws BusinessException {
        String jsonString = JSON.toJSONString(param);
        RewardSearchDto searchCondition = JSON.parseObject(jsonString, RewardSearchDto.class);

        List<Reward> rewardList = rewardService.preApplyService(searchCondition);
        Map<String, Object> data = new HashMap<>();
        data.put("count", rewardList.size());
        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        if (null != param.get("traceID")) {
            String traceID = param.get("traceID").toString();
            responseResult.setTraceID(traceID);
        }
        responseResult.setData(data);
        return responseResult;
    }


    /**
     * 获取平台总共奖励额
     *
     * @param param
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/totalAmount", method = RequestMethod.GET)
    public ResponseResult getTotalAmount(@RequestParam Map<String, Object> param) throws BusinessException {
        BigDecimal totalAmount = rewardService.getTotalAmount();
        return new ResponseResult((String) param.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", totalAmount);
    }

//    /**
//     * 生成奖励
//     *
//     * @param param
//     * @return
//     * @throws BusinessException
//     */
//    @RequestMapping(value = "", method = RequestMethod.POST)
//    public ResponseResult create(@RequestBody Map<String, Object> param) throws BusinessException {
//        String jsonString = JSON.toJSONString(param);
//        AwardMessage awardMessage = JSON.parseObject(jsonString, AwardMessage.class);
//
////        rewardService.generateRewardRecord(awardMessage);
//
//        ResponseResult responseResult = new ResponseResult();
//        responseResult.setCode(ResponseCode.OK);
//        responseResult.setMsg(ResponseCode.OK_TEXT);
//        return responseResult;
//    }

//    /**
//     * 更新用户认证状态
//     *
//     * @param param
//     * @return
//     * @throws BusinessException
//     */
//    @RequestMapping(value = "/userAuth", method = RequestMethod.PUT)
//    public ResponseResult updateUserAuthStatus(@RequestBody Map<String, Object> param) throws BusinessException {
//        String jsonString = JSON.toJSONString(param);
//        AwardMessage awardMessage = JSON.parseObject(jsonString, AwardMessage.class);
//        String userUuid = awardMessage.getUserUuid();
//
////        rewardService.updateUserAuthStatus(userUuid);
//
//        ResponseResult responseResult = new ResponseResult();
//        responseResult.setCode(ResponseCode.OK);
//        responseResult.setMsg(ResponseCode.OK_TEXT);
//        return responseResult;
//    }

    /**
     * 活动奖励结算
     * @param param
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/campaignRewardClear", method = RequestMethod.POST)
    public ResponseResult campaignRewardClear(@RequestBody Map<String, Object> param) throws BusinessException {
        // 单号
        String campaignRewardBillCode = param.get("campaignRewardBillCode").toString();
        double paymentAmount = Double.parseDouble(param.get("paymentAmount").toString());
        ResponseResult responseResult = new ResponseResult();
        rewardSummaryExecService.executeCampaignRewardOperation((String)param.get("userUuid"),campaignRewardBillCode,new BigDecimal(paymentAmount));
        return new ResponseResult( MapParamUtils.getStringInMap( param,"traceID"), ResponseCode.REQUEST_SUCCESS,"成功");
    }

    @RequestMapping(value = "/config", method = RequestMethod.GET)
    public ResponseResult getRewardConfig() throws BusinessException {
        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        responseResult.setData(rewardService.getConfig());
        return responseResult;
    }

    @RequestMapping(value = "/config", method = RequestMethod.PUT)
    public ResponseResult updateRewardConfig(@RequestBody RewardConfigVO configVO) throws BusinessException {
        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        responseResult.setData(rewardService.setConfig(configVO));
        return responseResult;
    }
}
