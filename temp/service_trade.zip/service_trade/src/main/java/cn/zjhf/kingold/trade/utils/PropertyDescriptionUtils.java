package cn.zjhf.kingold.trade.utils;


import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.stream.XMLStreamException;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class PropertyDescriptionUtils {
    private static final Logger LOGGER = LoggerFactory.getLogger(PropertyDescriptionUtils.class);

    public static Map<String, Map<String, Map<String, String>>> ACCOUNT_DIC = null;

    public static Map<String, Map<String, Map<String, String>>> ACCOUNT_BAOFOO_DIC = null;

    public static Map<String, Map<String, Map<String, String>>> ACCOUNT_TRANSACTION_DIC = null;

    public static Map<String, Map<String, Map<String, String>>> ACCOUNT_AND_BAOFOO_DIC = null;

    public static Map<String, Map<String, Map<String, String>>> TRADE_RECHARGE_DIC = null;

    public static Map<String, Map<String, Map<String, String>>> TRADE_PRIVATE_FUND_ORDER_DIC = null;


    public static Map<String, Map<String, String>> PROVINCE_CITY_DISTRICT_ALL_IN_ONE_DIC = new HashMap<>();
    //省市区
    public static Map<String, Map<String, Map<String, String>>> PROVINCE_CITY_DISTRICT_DIC = new HashMap<>();


    static {

        try {
            ACCOUNT_DIC = initMap_Three("accountDic.xml");
            ACCOUNT_BAOFOO_DIC = initMap_Three("accountBaofooDic.xml");
            ACCOUNT_TRANSACTION_DIC = initMap_Three("accountTransactionDic.xml");
            TRADE_RECHARGE_DIC = initMap_Three("tradeRechargeDic.xml");

            TRADE_PRIVATE_FUND_ORDER_DIC = initMap_Three("tradePrivateFundOrderDic.xml");

            ACCOUNT_AND_BAOFOO_DIC = new HashMap<>();
            ACCOUNT_AND_BAOFOO_DIC.putAll(ACCOUNT_DIC);
            ACCOUNT_AND_BAOFOO_DIC.putAll(ACCOUNT_BAOFOO_DIC);

        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            e.printStackTrace();
        }

    }

    public static void checkProperties(List<String> properties) throws BusinessException {

    }

    public static Map<String, String> checkConvertParams(Map<String, String> sourceObject, List<String> properties, String desc) throws BusinessException {
        if (sourceObject == null) {
            return new HashMap<>();
        }

        if (properties == null) {
            throw new BusinessException(ResponseCode.REQUEST_ERROR_PROGRAM_EXCEPTION, "properties参数不能为空！", true);
        }
        return sourceObject;
    }


    /**
     * 根据properties 过滤 sourceObject值 ，返回仅有 properties 属性的map对象。
     *
     * @param sourceObject
     * @param properties
     * @param desc         返回properties 存在字典映射关系时，返回字典的哪个属性。 如果为空，则不与字典匹配
     * @return
     */
    public static Map convertProperty(Map sourceObject, String properties, String desc, Map<String, Map<String, Map<String, String>>> DICT) throws BusinessException {

        if (StringUtils.isBlank(properties)) {
            throw new BusinessException(ResponseCode.REQUEST_ERROR_PROGRAM_EXCEPTION, "入参：properties不能为空！", true);
        }
        String[] propArr = properties.split("\\$\\$");
        List<String> propList = Arrays.asList(propArr);
        if (sourceObject == null || sourceObject.keySet().size() == 0) {
            return new HashMap();
        }
        Map targetObject = PropertiesUtils.getNeedProperties(sourceObject, propList);

        for (String property : propList) {
            Object propertyValue = sourceObject.get(property);
            //过滤  当前对象对应 的key/value
            if (null != propertyValue) {
                if (!StringUtils.isBlank(desc)) {

                    String propertyDescValue = getDic(property, propertyValue.toString(), desc, DICT);
                    if (StringUtils.isNotBlank(propertyDescValue)) {
                        targetObject.put(property + "Desc", propertyDescValue);
                    }
                }
                //去掉 时间函数最后两位 如：返回 2017-01-03 12:13:14.0 去掉后面的.0后缀
                if (property.endsWith("Time") && propertyValue instanceof String) {
                    if (propertyValue.toString().length() == 21 && propertyValue.toString().endsWith(".0")) {
                        targetObject.put(property, propertyValue.toString().substring(0, 19));
                    }
                }
            }

        }

        return targetObject;
    }


    private static String getDic(String key, String values, String desc, Map<String, Map<String, Map<String, String>>> DICT) {
        if (DICT == null || StringUtils.isBlank(values))
            return null;

        Map<String, Map<String, String>> map = DICT.get(key);
        Map<String, String> map1 = null;
        String returnDesc = "";
        if (map != null) {
            String[] valueArray = values.split("\\$\\$");
            for (String value : valueArray) {
                map1 = map.get(value);
                if (map1 != null) {
                    returnDesc = returnDesc.concat("$$" + map1.get(desc));
                }
            }
            return StringUtils.isBlank(returnDesc) ? null : returnDesc.substring(2);
        }

        return null;
    }


    public static Map<String, Map<String, Map<String, String>>> initMap_Three(String xmlPath) throws XMLStreamException, ParserConfigurationException, BusinessException, IOException, SAXException {
        Map<String, Map<String, Map<String, String>>> countMap = new HashMap<String, Map<String, Map<String, String>>>();
        Map<String, Map<String, String>> towMap = null;
        Map<String, String> threeMap = null;
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();

        Document document = builder.parse(PropertyDescriptionUtils.class.getClassLoader().getResourceAsStream(xmlPath));
        Element element = document.getDocumentElement();
        NodeList elementNodes = element.getElementsByTagName("element");
        for (int i = 0; i < elementNodes.getLength(); i++) {
            Element childElement = (Element) elementNodes.item(i);
            towMap = new HashMap<String, Map<String, String>>();
            NodeList childNodes = childElement.getChildNodes();
            for (int j = 0; j < childNodes.getLength(); j++) {
                if (childNodes.item(j).getNodeType() == Node.ELEMENT_NODE) {
                    threeMap = new HashMap<String, String>();
                    Element element1 = (Element) childNodes.item(j);
                    threeMap.put("simpleName", element1.getAttribute("simpleName"));
                    threeMap.put("defaultName", element1.getAttribute("defaultName"));
                    threeMap.put("fullName", element1.getAttribute("fullName"));
                    towMap.put(element1.getAttribute("value"), threeMap);
                }
            }
            countMap.put(childElement.getAttribute("name"), towMap);

        }
        return countMap;

    }

    public static Map<String, Map<String, Map<String, String>>> initProvinceCityDistrictMap(String xmlPath) throws XMLStreamException, ParserConfigurationException, BusinessException, IOException, SAXException {

        Map<String, Map<String, Map<String, String>>> towMap = new HashMap<String, Map<String, Map<String, String>>>();
        Map<String, String> nodeMap = null;
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Map<String, Map<String, String>> provinceMap = new HashMap<String, Map<String, String>>();
        Map<String, Map<String, String>> cityMap = new HashMap<String, Map<String, String>>();
        Map<String, Map<String, String>> districtMap = new HashMap<String, Map<String, String>>();
        Document document = builder.parse(PropertyDescriptionUtils.class.getClassLoader().getResourceAsStream(xmlPath));
        Element element = document.getDocumentElement();
        NodeList elementNodes = element.getElementsByTagName("CityCode");
        for (int i = 0; i < elementNodes.getLength(); i++) {
            try {
                if (elementNodes.item(i).getNodeType() == Node.ELEMENT_NODE) {
                    nodeMap = new HashMap<>();
                    Element element1 = (Element) elementNodes.item(i);
                    String value = element1.getAttribute("value");
                    if (StringUtils.isBlank(value)) {
                        continue;
                    } else if (value.length() == 4) {
                        nodeMap.put("simpleName", element1.getAttribute("simpleName"));
                        nodeMap.put("defaultName", element1.getAttribute("defaultName"));
                        nodeMap.put("fullName", element1.getAttribute("fullName"));
                        provinceMap.put(value, nodeMap);
                    } else if (value.length() == 6) {
                        nodeMap.put("simpleName", element1.getAttribute("simpleName"));
                        nodeMap.put("defaultName", element1.getAttribute("defaultName"));
                        nodeMap.put("fullName", element1.getAttribute("fullName"));
                        cityMap.put(value, nodeMap);
                    } else if (value.length() == 8) {
                        nodeMap.put("simpleName", element1.getAttribute("simpleName"));
                        nodeMap.put("defaultName", element1.getAttribute("defaultName"));
                        nodeMap.put("fullName", element1.getAttribute("fullName"));
                        districtMap.put(value, nodeMap);
                    }
                }


            } catch (Exception e) {
                LOGGER.error(e.getMessage());
            }
        }

        towMap.put("province", provinceMap);
        towMap.put("city", cityMap);
        towMap.put("district", districtMap);

        return towMap;

    }


}