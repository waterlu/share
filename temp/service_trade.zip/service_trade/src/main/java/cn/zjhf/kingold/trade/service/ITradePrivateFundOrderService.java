package cn.zjhf.kingold.trade.service;


import cn.zjhf.kingold.common.exception.BusinessException;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;


/**
 * Created by wangxun on 2016/11/04.
 * Copyright by zjinv
 */
public interface ITradePrivateFundOrderService {


    public Map getWithFilter(Map params) throws BusinessException;


    public Integer insert(Map params) throws BusinessException;

    public int update(Map params) throws BusinessException;

    List<Map> getList(Map userMap) throws BusinessException;

    Integer getCount(Map userMap) throws BusinessException;

    BigDecimal getOrderPurchaseSum(Map params) throws BusinessException;

    BigDecimal getOrderVerifyPurchaseSum(Map params) throws BusinessException;

    /**
     * 根据用户ID查询私募预约金额
     *
     * @param userUuid
     * @return
     */
    BigDecimal querySumAmountByUser(String userUuid, String idCardNo) throws BusinessException;

}