package cn.zjhf.kingold.trade.persistence.mq.consumer;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.rocketmq.annotation.RocketMQConsumer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQConsumer;
import cn.zjhf.kingold.service_consumer.service.TradeServiceConsumer;
import cn.zjhf.kingold.trade.baofoo.RechargeNotify;
import cn.zjhf.kingold.trade.constant.MarketCampaignCodeEnum;
import cn.zjhf.kingold.trade.constant.NotificationType;
import cn.zjhf.kingold.trade.entity.TradeRecharge;
import cn.zjhf.kingold.trade.persistence.mq.message.PayRechargeMessage;
import cn.zjhf.kingold.trade.persistence.mq.producer.PayRechargeFinishProducer;
import cn.zjhf.kingold.trade.service.IMarketCampaignService;
import cn.zjhf.kingold.trade.service.ITradeRechargeService;
import cn.zjhf.kingold.trade.service.ITradeService;
import cn.zjhf.kingold.trade.utils.AmountUtils;
import cn.zjhf.kingold.trade.utils.DateUtil;
import com.alibaba.fastjson.JSON;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * 宝付通知充值成功，更新账户余额和流水。
 *
 * Created by lutiehua on 2017/7/13.
 */
@RocketMQConsumer(topic = "pay", tag = "recharge")
public class PayRechargeConsumer extends AbstractMQConsumer<PayRechargeMessage> {

    @Autowired
    private ITradeService tradeService;

    @Autowired
    private ITradeRechargeService tradeRechargeService;

    @Autowired
    private IMarketCampaignService marketCampaignService;

    @Autowired
    private RedisTemplate redisTemplate;

    @Autowired
    private PayRechargeFinishProducer payRechargeFinishProducer;

    private final Logger LOGGER = LoggerFactory.getLogger(PayRechargeConsumer.class);
    private final static String NOTIFY_KEY="consumer_pa_recharge";
    private final static int NOTIFY_DEALING_CODE=202;
    private final static String NOTIFY_DEALING_MSG="处理中";


    @Override
    public ResponseResult process(PayRechargeMessage payRechargeMessage) throws BusinessException {
        ResponseResult responseResult = new ResponseResult();
        boolean result = redisTemplate.opsForValue().setIfAbsent(NOTIFY_KEY + payRechargeMessage.getData().getBillCode(),"");
        if (!result) {
            LOGGER.info("PayRechargeConsumer two thread enter meanwhile deal same order, lock one. payRechargeMessage={}", responseResult);
            responseResult.setCode(NOTIFY_DEALING_CODE);
            responseResult.setMsg(NOTIFY_DEALING_MSG);
            return responseResult;
        } else {
            LOGGER.info("PayRechargeConsumer lock order. payRechargeMessage={}", responseResult);
            redisTemplate.expire(NOTIFY_KEY + payRechargeMessage.getData().getBillCode(), 1, TimeUnit.SECONDS);
        }
        responseResult = doTransaction(payRechargeMessage);
        redisTemplate.delete(NOTIFY_KEY + payRechargeMessage.getData().getBillCode());
        return responseResult;

    }

    private ResponseResult doTransaction(PayRechargeMessage payRechargeMessage) throws BusinessException {
        ResponseResult responseResult = new ResponseResult();
        RechargeNotify notify = payRechargeMessage.getData();
        String billCode = notify.getBillCode();
        double amount = notify.getAmount();
        int feeTakenOn = notify.getFeeTakenOn();
        double feeAmount = notify.getFee();
        Date time = notify.getTime();
        String result = notify.getResult();
        String transactionChannel = notify.getChannel();

        tradeService.executeRechargeOrder(billCode, amount, feeTakenOn,feeAmount, time, result, transactionChannel);

        payRechargeFinishProducer.send(payRechargeMessage);
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        return responseResult;
    }


}
