package cn.zjhf.kingold.trade.utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangyijie on 2017/7/13.
 */
public class ReportData {
    private List<List<String>> reportData;

    public ReportData(List<List<String>> reportData) {
        this.reportData = reportData;
    }

    public List<String> getColumnValues(String columnName) {
        List<String> result = new ArrayList<String>();

        int lineSize = reportData.size();
        if(lineSize > 1) {
            int index = reportData.get(0).indexOf(columnName);
            if(index >= 0) {
                for(int i=1; i<lineSize; i++) {
                    List<String> curLineData = reportData.get(i);
                    if(curLineData.size() > index) {
                        result.add(curLineData.get(index));
                    }
                }
            }
        }

        return result;
    }

    public int updateColumnValues(String columnName, List<String> values) {
        int count = 0;

        int lineSize = reportData.size();
        if(values.size() != (lineSize-1)) {
            return count;
        }

        if(lineSize > 1) {
            int index = reportData.get(0).indexOf(columnName);
            if(index >= 0) {
                for(int i=1; i<lineSize; i++) {
                    List<String> curLineData = reportData.get(i);
                    if(curLineData.size() > index) {
                        curLineData.set(index, values.get(i-1));
                        ++count;
                    }
                }
            }
        }

        return count;
    }

    public List<List<String>> get() {
        return reportData;
    }
}
