package cn.zjhf.kingold.trade.entity.InVO.CommGrant;

/**
 * Created by zhangyijie on 2018/2/2.
 */
public class CommGrantItemBaseVO {

    /**
     * 行号
     */
    private int rowNum;

    /**
     * 指定的活动号
     */
    private Byte activityNum;

    /**
     * 用户手机号
     */
    private String phoneNumber;

    public int getRowNum() {
        return rowNum;
    }

    public void setRowNum(int rowNum) {
        this.rowNum = rowNum;
    }

    public Byte getActivityNum() {
        return activityNum;
    }

    public void setActivityNum(Byte activityNum) {
        this.activityNum = activityNum;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @Override
    public String toString() {
        return "CommGrantItemBaseVO{" +
                "rowNum=" + rowNum +
                ", activityNum=" + activityNum +
                ", phoneNumber='" + phoneNumber + '\'' +
                '}';
    }
}
