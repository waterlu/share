package cn.zjhf.kingold.trade.vo;

import cn.zjhf.kingold.trade.utils.DataUtils;

import java.util.Date;

/**
 * Created by lutiehua on 2017/6/13.
 */
public class UserAuthVO {

    /**
     * 用户UUID
     */
    private String userUuid;

    /**
     * 是否有效奖励
     */
    private Integer isEnabledReward;

    /**
     * 投资者类型
     */
    private Integer investorType;

    /**
     * 用户认证时间
     */
    private Date userAuthTime;

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public Integer getIsEnabledReward() {
        return isEnabledReward;
    }

    public void setIsEnabledReward(Integer isEnabledReward) {
        this.isEnabledReward = isEnabledReward;
    }

    public Integer getInvestorType() {
        return investorType;
    }

    public void setInvestorType(Integer investorType) {
        this.investorType = investorType;
    }

    public Date getUserAuthTime() {
        return userAuthTime;
    }

    public void setUserAuthTime(Date userAuthTime) {
        this.userAuthTime = userAuthTime;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("userUuid:" + DataUtils.toString(userUuid) + ", ");
        sb.append("isEnabledReward:" + DataUtils.toString(isEnabledReward) + ", ");
        sb.append("investorType:" + DataUtils.toString(investorType) + ", ");
        sb.append("userAuthTime:" + DataUtils.toString(userAuthTime));
        return sb.toString();
    }
}
