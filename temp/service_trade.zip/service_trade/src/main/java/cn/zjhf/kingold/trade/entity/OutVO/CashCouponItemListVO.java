package cn.zjhf.kingold.trade.entity.OutVO;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.trade.entity.CashCoupon;
import cn.zjhf.kingold.trade.entity.InVO.CashCouponVO;
import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModelProperty;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangyijie on 2017/7/5.
 */
public class CashCouponItemListVO extends ParamVO {
    @ApiModelProperty(required = true, value = "总记录数")
    private int totalCount;

    @ApiModelProperty(required = true, value = "返回列表")
    private List<CashCouponVO> items;

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public List<CashCouponVO> getItems() {
        return items;
    }

    public void setItems(List<CashCouponVO> items) {
        this.items = items;
    }

    public void setItemsEx(List<CashCoupon> items) {
        this.items = new ArrayList<CashCouponVO>();
        if(items != null && items.size() > 0) {
            for(CashCoupon item : items) {
                this.items.add(new CashCouponVO(item));
            }
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(getTraceID()) + ", ");
        sb.append("totalCount:" + DataUtils.toString(totalCount) + ", ");
        sb.append("items:" + DataUtils.toString(items));
        return sb.toString();
    }
}
