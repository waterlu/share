package cn.zjhf.kingold.trade.entity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AccountUnpaidFundExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private Integer limit;

    private Integer offset;

    public AccountUnpaidFundExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andAccountTransactionUuidIsNull() {
            addCriterion("account_transaction_uuid is null");
            return (Criteria) this;
        }

        public Criteria andAccountTransactionUuidIsNotNull() {
            addCriterion("account_transaction_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andAccountTransactionUuidEqualTo(Long value) {
            addCriterion("account_transaction_uuid =", value, "accountTransactionUuid");
            return (Criteria) this;
        }

        public Criteria andAccountTransactionUuidNotEqualTo(Long value) {
            addCriterion("account_transaction_uuid <>", value, "accountTransactionUuid");
            return (Criteria) this;
        }

        public Criteria andAccountTransactionUuidGreaterThan(Long value) {
            addCriterion("account_transaction_uuid >", value, "accountTransactionUuid");
            return (Criteria) this;
        }

        public Criteria andAccountTransactionUuidGreaterThanOrEqualTo(Long value) {
            addCriterion("account_transaction_uuid >=", value, "accountTransactionUuid");
            return (Criteria) this;
        }

        public Criteria andAccountTransactionUuidLessThan(Long value) {
            addCriterion("account_transaction_uuid <", value, "accountTransactionUuid");
            return (Criteria) this;
        }

        public Criteria andAccountTransactionUuidLessThanOrEqualTo(Long value) {
            addCriterion("account_transaction_uuid <=", value, "accountTransactionUuid");
            return (Criteria) this;
        }

        public Criteria andAccountTransactionUuidIn(List<Long> values) {
            addCriterion("account_transaction_uuid in", values, "accountTransactionUuid");
            return (Criteria) this;
        }

        public Criteria andAccountTransactionUuidNotIn(List<Long> values) {
            addCriterion("account_transaction_uuid not in", values, "accountTransactionUuid");
            return (Criteria) this;
        }

        public Criteria andAccountTransactionUuidBetween(Long value1, Long value2) {
            addCriterion("account_transaction_uuid between", value1, value2, "accountTransactionUuid");
            return (Criteria) this;
        }

        public Criteria andAccountTransactionUuidNotBetween(Long value1, Long value2) {
            addCriterion("account_transaction_uuid not between", value1, value2, "accountTransactionUuid");
            return (Criteria) this;
        }

        public Criteria andTransactionBillCodeIsNull() {
            addCriterion("transaction_bill_code is null");
            return (Criteria) this;
        }

        public Criteria andTransactionBillCodeIsNotNull() {
            addCriterion("transaction_bill_code is not null");
            return (Criteria) this;
        }

        public Criteria andTransactionBillCodeEqualTo(String value) {
            addCriterion("transaction_bill_code =", value, "transactionBillCode");
            return (Criteria) this;
        }

        public Criteria andTransactionBillCodeNotEqualTo(String value) {
            addCriterion("transaction_bill_code <>", value, "transactionBillCode");
            return (Criteria) this;
        }

        public Criteria andTransactionBillCodeGreaterThan(String value) {
            addCriterion("transaction_bill_code >", value, "transactionBillCode");
            return (Criteria) this;
        }

        public Criteria andTransactionBillCodeGreaterThanOrEqualTo(String value) {
            addCriterion("transaction_bill_code >=", value, "transactionBillCode");
            return (Criteria) this;
        }

        public Criteria andTransactionBillCodeLessThan(String value) {
            addCriterion("transaction_bill_code <", value, "transactionBillCode");
            return (Criteria) this;
        }

        public Criteria andTransactionBillCodeLessThanOrEqualTo(String value) {
            addCriterion("transaction_bill_code <=", value, "transactionBillCode");
            return (Criteria) this;
        }

        public Criteria andTransactionBillCodeLike(String value) {
            addCriterion("transaction_bill_code like", value, "transactionBillCode");
            return (Criteria) this;
        }

        public Criteria andTransactionBillCodeNotLike(String value) {
            addCriterion("transaction_bill_code not like", value, "transactionBillCode");
            return (Criteria) this;
        }

        public Criteria andTransactionBillCodeIn(List<String> values) {
            addCriterion("transaction_bill_code in", values, "transactionBillCode");
            return (Criteria) this;
        }

        public Criteria andTransactionBillCodeNotIn(List<String> values) {
            addCriterion("transaction_bill_code not in", values, "transactionBillCode");
            return (Criteria) this;
        }

        public Criteria andTransactionBillCodeBetween(String value1, String value2) {
            addCriterion("transaction_bill_code between", value1, value2, "transactionBillCode");
            return (Criteria) this;
        }

        public Criteria andTransactionBillCodeNotBetween(String value1, String value2) {
            addCriterion("transaction_bill_code not between", value1, value2, "transactionBillCode");
            return (Criteria) this;
        }

        public Criteria andTradeOrderBillCodeIsNull() {
            addCriterion("trade_order_bill_code is null");
            return (Criteria) this;
        }

        public Criteria andTradeOrderBillCodeIsNotNull() {
            addCriterion("trade_order_bill_code is not null");
            return (Criteria) this;
        }

        public Criteria andTradeOrderBillCodeEqualTo(String value) {
            addCriterion("trade_order_bill_code =", value, "tradeOrderBillCode");
            return (Criteria) this;
        }

        public Criteria andTradeOrderBillCodeNotEqualTo(String value) {
            addCriterion("trade_order_bill_code <>", value, "tradeOrderBillCode");
            return (Criteria) this;
        }

        public Criteria andTradeOrderBillCodeGreaterThan(String value) {
            addCriterion("trade_order_bill_code >", value, "tradeOrderBillCode");
            return (Criteria) this;
        }

        public Criteria andTradeOrderBillCodeGreaterThanOrEqualTo(String value) {
            addCriterion("trade_order_bill_code >=", value, "tradeOrderBillCode");
            return (Criteria) this;
        }

        public Criteria andTradeOrderBillCodeLessThan(String value) {
            addCriterion("trade_order_bill_code <", value, "tradeOrderBillCode");
            return (Criteria) this;
        }

        public Criteria andTradeOrderBillCodeLessThanOrEqualTo(String value) {
            addCriterion("trade_order_bill_code <=", value, "tradeOrderBillCode");
            return (Criteria) this;
        }

        public Criteria andTradeOrderBillCodeLike(String value) {
            addCriterion("trade_order_bill_code like", value, "tradeOrderBillCode");
            return (Criteria) this;
        }

        public Criteria andTradeOrderBillCodeNotLike(String value) {
            addCriterion("trade_order_bill_code not like", value, "tradeOrderBillCode");
            return (Criteria) this;
        }

        public Criteria andTradeOrderBillCodeIn(List<String> values) {
            addCriterion("trade_order_bill_code in", values, "tradeOrderBillCode");
            return (Criteria) this;
        }

        public Criteria andTradeOrderBillCodeNotIn(List<String> values) {
            addCriterion("trade_order_bill_code not in", values, "tradeOrderBillCode");
            return (Criteria) this;
        }

        public Criteria andTradeOrderBillCodeBetween(String value1, String value2) {
            addCriterion("trade_order_bill_code between", value1, value2, "tradeOrderBillCode");
            return (Criteria) this;
        }

        public Criteria andTradeOrderBillCodeNotBetween(String value1, String value2) {
            addCriterion("trade_order_bill_code not between", value1, value2, "tradeOrderBillCode");
            return (Criteria) this;
        }

        public Criteria andTransactionTimeIsNull() {
            addCriterion("transaction_time is null");
            return (Criteria) this;
        }

        public Criteria andTransactionTimeIsNotNull() {
            addCriterion("transaction_time is not null");
            return (Criteria) this;
        }

        public Criteria andTransactionTimeEqualTo(Date value) {
            addCriterion("transaction_time =", value, "transactionTime");
            return (Criteria) this;
        }

        public Criteria andTransactionTimeNotEqualTo(Date value) {
            addCriterion("transaction_time <>", value, "transactionTime");
            return (Criteria) this;
        }

        public Criteria andTransactionTimeGreaterThan(Date value) {
            addCriterion("transaction_time >", value, "transactionTime");
            return (Criteria) this;
        }

        public Criteria andTransactionTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("transaction_time >=", value, "transactionTime");
            return (Criteria) this;
        }

        public Criteria andTransactionTimeLessThan(Date value) {
            addCriterion("transaction_time <", value, "transactionTime");
            return (Criteria) this;
        }

        public Criteria andTransactionTimeLessThanOrEqualTo(Date value) {
            addCriterion("transaction_time <=", value, "transactionTime");
            return (Criteria) this;
        }

        public Criteria andTransactionTimeIn(List<Date> values) {
            addCriterion("transaction_time in", values, "transactionTime");
            return (Criteria) this;
        }

        public Criteria andTransactionTimeNotIn(List<Date> values) {
            addCriterion("transaction_time not in", values, "transactionTime");
            return (Criteria) this;
        }

        public Criteria andTransactionTimeBetween(Date value1, Date value2) {
            addCriterion("transaction_time between", value1, value2, "transactionTime");
            return (Criteria) this;
        }

        public Criteria andTransactionTimeNotBetween(Date value1, Date value2) {
            addCriterion("transaction_time not between", value1, value2, "transactionTime");
            return (Criteria) this;
        }

        public Criteria andOutUserUuidIsNull() {
            addCriterion("out_user_uuid is null");
            return (Criteria) this;
        }

        public Criteria andOutUserUuidIsNotNull() {
            addCriterion("out_user_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andOutUserUuidEqualTo(String value) {
            addCriterion("out_user_uuid =", value, "outUserUuid");
            return (Criteria) this;
        }

        public Criteria andOutUserUuidNotEqualTo(String value) {
            addCriterion("out_user_uuid <>", value, "outUserUuid");
            return (Criteria) this;
        }

        public Criteria andOutUserUuidGreaterThan(String value) {
            addCriterion("out_user_uuid >", value, "outUserUuid");
            return (Criteria) this;
        }

        public Criteria andOutUserUuidGreaterThanOrEqualTo(String value) {
            addCriterion("out_user_uuid >=", value, "outUserUuid");
            return (Criteria) this;
        }

        public Criteria andOutUserUuidLessThan(String value) {
            addCriterion("out_user_uuid <", value, "outUserUuid");
            return (Criteria) this;
        }

        public Criteria andOutUserUuidLessThanOrEqualTo(String value) {
            addCriterion("out_user_uuid <=", value, "outUserUuid");
            return (Criteria) this;
        }

        public Criteria andOutUserUuidLike(String value) {
            addCriterion("out_user_uuid like", value, "outUserUuid");
            return (Criteria) this;
        }

        public Criteria andOutUserUuidNotLike(String value) {
            addCriterion("out_user_uuid not like", value, "outUserUuid");
            return (Criteria) this;
        }

        public Criteria andOutUserUuidIn(List<String> values) {
            addCriterion("out_user_uuid in", values, "outUserUuid");
            return (Criteria) this;
        }

        public Criteria andOutUserUuidNotIn(List<String> values) {
            addCriterion("out_user_uuid not in", values, "outUserUuid");
            return (Criteria) this;
        }

        public Criteria andOutUserUuidBetween(String value1, String value2) {
            addCriterion("out_user_uuid between", value1, value2, "outUserUuid");
            return (Criteria) this;
        }

        public Criteria andOutUserUuidNotBetween(String value1, String value2) {
            addCriterion("out_user_uuid not between", value1, value2, "outUserUuid");
            return (Criteria) this;
        }

        public Criteria andOutAccountUuidIsNull() {
            addCriterion("out_account_uuid is null");
            return (Criteria) this;
        }

        public Criteria andOutAccountUuidIsNotNull() {
            addCriterion("out_account_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andOutAccountUuidEqualTo(String value) {
            addCriterion("out_account_uuid =", value, "outAccountUuid");
            return (Criteria) this;
        }

        public Criteria andOutAccountUuidNotEqualTo(String value) {
            addCriterion("out_account_uuid <>", value, "outAccountUuid");
            return (Criteria) this;
        }

        public Criteria andOutAccountUuidGreaterThan(String value) {
            addCriterion("out_account_uuid >", value, "outAccountUuid");
            return (Criteria) this;
        }

        public Criteria andOutAccountUuidGreaterThanOrEqualTo(String value) {
            addCriterion("out_account_uuid >=", value, "outAccountUuid");
            return (Criteria) this;
        }

        public Criteria andOutAccountUuidLessThan(String value) {
            addCriterion("out_account_uuid <", value, "outAccountUuid");
            return (Criteria) this;
        }

        public Criteria andOutAccountUuidLessThanOrEqualTo(String value) {
            addCriterion("out_account_uuid <=", value, "outAccountUuid");
            return (Criteria) this;
        }

        public Criteria andOutAccountUuidLike(String value) {
            addCriterion("out_account_uuid like", value, "outAccountUuid");
            return (Criteria) this;
        }

        public Criteria andOutAccountUuidNotLike(String value) {
            addCriterion("out_account_uuid not like", value, "outAccountUuid");
            return (Criteria) this;
        }

        public Criteria andOutAccountUuidIn(List<String> values) {
            addCriterion("out_account_uuid in", values, "outAccountUuid");
            return (Criteria) this;
        }

        public Criteria andOutAccountUuidNotIn(List<String> values) {
            addCriterion("out_account_uuid not in", values, "outAccountUuid");
            return (Criteria) this;
        }

        public Criteria andOutAccountUuidBetween(String value1, String value2) {
            addCriterion("out_account_uuid between", value1, value2, "outAccountUuid");
            return (Criteria) this;
        }

        public Criteria andOutAccountUuidNotBetween(String value1, String value2) {
            addCriterion("out_account_uuid not between", value1, value2, "outAccountUuid");
            return (Criteria) this;
        }

        public Criteria andOutAccountNoIsNull() {
            addCriterion("out_account_no is null");
            return (Criteria) this;
        }

        public Criteria andOutAccountNoIsNotNull() {
            addCriterion("out_account_no is not null");
            return (Criteria) this;
        }

        public Criteria andOutAccountNoEqualTo(String value) {
            addCriterion("out_account_no =", value, "outAccountNo");
            return (Criteria) this;
        }

        public Criteria andOutAccountNoNotEqualTo(String value) {
            addCriterion("out_account_no <>", value, "outAccountNo");
            return (Criteria) this;
        }

        public Criteria andOutAccountNoGreaterThan(String value) {
            addCriterion("out_account_no >", value, "outAccountNo");
            return (Criteria) this;
        }

        public Criteria andOutAccountNoGreaterThanOrEqualTo(String value) {
            addCriterion("out_account_no >=", value, "outAccountNo");
            return (Criteria) this;
        }

        public Criteria andOutAccountNoLessThan(String value) {
            addCriterion("out_account_no <", value, "outAccountNo");
            return (Criteria) this;
        }

        public Criteria andOutAccountNoLessThanOrEqualTo(String value) {
            addCriterion("out_account_no <=", value, "outAccountNo");
            return (Criteria) this;
        }

        public Criteria andOutAccountNoLike(String value) {
            addCriterion("out_account_no like", value, "outAccountNo");
            return (Criteria) this;
        }

        public Criteria andOutAccountNoNotLike(String value) {
            addCriterion("out_account_no not like", value, "outAccountNo");
            return (Criteria) this;
        }

        public Criteria andOutAccountNoIn(List<String> values) {
            addCriterion("out_account_no in", values, "outAccountNo");
            return (Criteria) this;
        }

        public Criteria andOutAccountNoNotIn(List<String> values) {
            addCriterion("out_account_no not in", values, "outAccountNo");
            return (Criteria) this;
        }

        public Criteria andOutAccountNoBetween(String value1, String value2) {
            addCriterion("out_account_no between", value1, value2, "outAccountNo");
            return (Criteria) this;
        }

        public Criteria andOutAccountNoNotBetween(String value1, String value2) {
            addCriterion("out_account_no not between", value1, value2, "outAccountNo");
            return (Criteria) this;
        }

        public Criteria andInUserUuidIsNull() {
            addCriterion("in_user_uuid is null");
            return (Criteria) this;
        }

        public Criteria andInUserUuidIsNotNull() {
            addCriterion("in_user_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andInUserUuidEqualTo(String value) {
            addCriterion("in_user_uuid =", value, "inUserUuid");
            return (Criteria) this;
        }

        public Criteria andInUserUuidNotEqualTo(String value) {
            addCriterion("in_user_uuid <>", value, "inUserUuid");
            return (Criteria) this;
        }

        public Criteria andInUserUuidGreaterThan(String value) {
            addCriterion("in_user_uuid >", value, "inUserUuid");
            return (Criteria) this;
        }

        public Criteria andInUserUuidGreaterThanOrEqualTo(String value) {
            addCriterion("in_user_uuid >=", value, "inUserUuid");
            return (Criteria) this;
        }

        public Criteria andInUserUuidLessThan(String value) {
            addCriterion("in_user_uuid <", value, "inUserUuid");
            return (Criteria) this;
        }

        public Criteria andInUserUuidLessThanOrEqualTo(String value) {
            addCriterion("in_user_uuid <=", value, "inUserUuid");
            return (Criteria) this;
        }

        public Criteria andInUserUuidLike(String value) {
            addCriterion("in_user_uuid like", value, "inUserUuid");
            return (Criteria) this;
        }

        public Criteria andInUserUuidNotLike(String value) {
            addCriterion("in_user_uuid not like", value, "inUserUuid");
            return (Criteria) this;
        }

        public Criteria andInUserUuidIn(List<String> values) {
            addCriterion("in_user_uuid in", values, "inUserUuid");
            return (Criteria) this;
        }

        public Criteria andInUserUuidNotIn(List<String> values) {
            addCriterion("in_user_uuid not in", values, "inUserUuid");
            return (Criteria) this;
        }

        public Criteria andInUserUuidBetween(String value1, String value2) {
            addCriterion("in_user_uuid between", value1, value2, "inUserUuid");
            return (Criteria) this;
        }

        public Criteria andInUserUuidNotBetween(String value1, String value2) {
            addCriterion("in_user_uuid not between", value1, value2, "inUserUuid");
            return (Criteria) this;
        }

        public Criteria andInAccountUuidIsNull() {
            addCriterion("in_account_uuid is null");
            return (Criteria) this;
        }

        public Criteria andInAccountUuidIsNotNull() {
            addCriterion("in_account_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andInAccountUuidEqualTo(String value) {
            addCriterion("in_account_uuid =", value, "inAccountUuid");
            return (Criteria) this;
        }

        public Criteria andInAccountUuidNotEqualTo(String value) {
            addCriterion("in_account_uuid <>", value, "inAccountUuid");
            return (Criteria) this;
        }

        public Criteria andInAccountUuidGreaterThan(String value) {
            addCriterion("in_account_uuid >", value, "inAccountUuid");
            return (Criteria) this;
        }

        public Criteria andInAccountUuidGreaterThanOrEqualTo(String value) {
            addCriterion("in_account_uuid >=", value, "inAccountUuid");
            return (Criteria) this;
        }

        public Criteria andInAccountUuidLessThan(String value) {
            addCriterion("in_account_uuid <", value, "inAccountUuid");
            return (Criteria) this;
        }

        public Criteria andInAccountUuidLessThanOrEqualTo(String value) {
            addCriterion("in_account_uuid <=", value, "inAccountUuid");
            return (Criteria) this;
        }

        public Criteria andInAccountUuidLike(String value) {
            addCriterion("in_account_uuid like", value, "inAccountUuid");
            return (Criteria) this;
        }

        public Criteria andInAccountUuidNotLike(String value) {
            addCriterion("in_account_uuid not like", value, "inAccountUuid");
            return (Criteria) this;
        }

        public Criteria andInAccountUuidIn(List<String> values) {
            addCriterion("in_account_uuid in", values, "inAccountUuid");
            return (Criteria) this;
        }

        public Criteria andInAccountUuidNotIn(List<String> values) {
            addCriterion("in_account_uuid not in", values, "inAccountUuid");
            return (Criteria) this;
        }

        public Criteria andInAccountUuidBetween(String value1, String value2) {
            addCriterion("in_account_uuid between", value1, value2, "inAccountUuid");
            return (Criteria) this;
        }

        public Criteria andInAccountUuidNotBetween(String value1, String value2) {
            addCriterion("in_account_uuid not between", value1, value2, "inAccountUuid");
            return (Criteria) this;
        }

        public Criteria andInAccountNoIsNull() {
            addCriterion("in_account_no is null");
            return (Criteria) this;
        }

        public Criteria andInAccountNoIsNotNull() {
            addCriterion("in_account_no is not null");
            return (Criteria) this;
        }

        public Criteria andInAccountNoEqualTo(String value) {
            addCriterion("in_account_no =", value, "inAccountNo");
            return (Criteria) this;
        }

        public Criteria andInAccountNoNotEqualTo(String value) {
            addCriterion("in_account_no <>", value, "inAccountNo");
            return (Criteria) this;
        }

        public Criteria andInAccountNoGreaterThan(String value) {
            addCriterion("in_account_no >", value, "inAccountNo");
            return (Criteria) this;
        }

        public Criteria andInAccountNoGreaterThanOrEqualTo(String value) {
            addCriterion("in_account_no >=", value, "inAccountNo");
            return (Criteria) this;
        }

        public Criteria andInAccountNoLessThan(String value) {
            addCriterion("in_account_no <", value, "inAccountNo");
            return (Criteria) this;
        }

        public Criteria andInAccountNoLessThanOrEqualTo(String value) {
            addCriterion("in_account_no <=", value, "inAccountNo");
            return (Criteria) this;
        }

        public Criteria andInAccountNoLike(String value) {
            addCriterion("in_account_no like", value, "inAccountNo");
            return (Criteria) this;
        }

        public Criteria andInAccountNoNotLike(String value) {
            addCriterion("in_account_no not like", value, "inAccountNo");
            return (Criteria) this;
        }

        public Criteria andInAccountNoIn(List<String> values) {
            addCriterion("in_account_no in", values, "inAccountNo");
            return (Criteria) this;
        }

        public Criteria andInAccountNoNotIn(List<String> values) {
            addCriterion("in_account_no not in", values, "inAccountNo");
            return (Criteria) this;
        }

        public Criteria andInAccountNoBetween(String value1, String value2) {
            addCriterion("in_account_no between", value1, value2, "inAccountNo");
            return (Criteria) this;
        }

        public Criteria andInAccountNoNotBetween(String value1, String value2) {
            addCriterion("in_account_no not between", value1, value2, "inAccountNo");
            return (Criteria) this;
        }

        public Criteria andTransactionAmountIsNull() {
            addCriterion("transaction_amount is null");
            return (Criteria) this;
        }

        public Criteria andTransactionAmountIsNotNull() {
            addCriterion("transaction_amount is not null");
            return (Criteria) this;
        }

        public Criteria andTransactionAmountEqualTo(BigDecimal value) {
            addCriterion("transaction_amount =", value, "transactionAmount");
            return (Criteria) this;
        }

        public Criteria andTransactionAmountNotEqualTo(BigDecimal value) {
            addCriterion("transaction_amount <>", value, "transactionAmount");
            return (Criteria) this;
        }

        public Criteria andTransactionAmountGreaterThan(BigDecimal value) {
            addCriterion("transaction_amount >", value, "transactionAmount");
            return (Criteria) this;
        }

        public Criteria andTransactionAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("transaction_amount >=", value, "transactionAmount");
            return (Criteria) this;
        }

        public Criteria andTransactionAmountLessThan(BigDecimal value) {
            addCriterion("transaction_amount <", value, "transactionAmount");
            return (Criteria) this;
        }

        public Criteria andTransactionAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("transaction_amount <=", value, "transactionAmount");
            return (Criteria) this;
        }

        public Criteria andTransactionAmountIn(List<BigDecimal> values) {
            addCriterion("transaction_amount in", values, "transactionAmount");
            return (Criteria) this;
        }

        public Criteria andTransactionAmountNotIn(List<BigDecimal> values) {
            addCriterion("transaction_amount not in", values, "transactionAmount");
            return (Criteria) this;
        }

        public Criteria andTransactionAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("transaction_amount between", value1, value2, "transactionAmount");
            return (Criteria) this;
        }

        public Criteria andTransactionAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("transaction_amount not between", value1, value2, "transactionAmount");
            return (Criteria) this;
        }

        public Criteria andTradeTypeIsNull() {
            addCriterion("trade_type is null");
            return (Criteria) this;
        }

        public Criteria andTradeTypeIsNotNull() {
            addCriterion("trade_type is not null");
            return (Criteria) this;
        }

        public Criteria andTradeTypeEqualTo(String value) {
            addCriterion("trade_type =", value, "tradeType");
            return (Criteria) this;
        }

        public Criteria andTradeTypeNotEqualTo(String value) {
            addCriterion("trade_type <>", value, "tradeType");
            return (Criteria) this;
        }

        public Criteria andTradeTypeGreaterThan(String value) {
            addCriterion("trade_type >", value, "tradeType");
            return (Criteria) this;
        }

        public Criteria andTradeTypeGreaterThanOrEqualTo(String value) {
            addCriterion("trade_type >=", value, "tradeType");
            return (Criteria) this;
        }

        public Criteria andTradeTypeLessThan(String value) {
            addCriterion("trade_type <", value, "tradeType");
            return (Criteria) this;
        }

        public Criteria andTradeTypeLessThanOrEqualTo(String value) {
            addCriterion("trade_type <=", value, "tradeType");
            return (Criteria) this;
        }

        public Criteria andTradeTypeLike(String value) {
            addCriterion("trade_type like", value, "tradeType");
            return (Criteria) this;
        }

        public Criteria andTradeTypeNotLike(String value) {
            addCriterion("trade_type not like", value, "tradeType");
            return (Criteria) this;
        }

        public Criteria andTradeTypeIn(List<String> values) {
            addCriterion("trade_type in", values, "tradeType");
            return (Criteria) this;
        }

        public Criteria andTradeTypeNotIn(List<String> values) {
            addCriterion("trade_type not in", values, "tradeType");
            return (Criteria) this;
        }

        public Criteria andTradeTypeBetween(String value1, String value2) {
            addCriterion("trade_type between", value1, value2, "tradeType");
            return (Criteria) this;
        }

        public Criteria andTradeTypeNotBetween(String value1, String value2) {
            addCriterion("trade_type not between", value1, value2, "tradeType");
            return (Criteria) this;
        }

        public Criteria andSubjectCodeIsNull() {
            addCriterion("subject_code is null");
            return (Criteria) this;
        }

        public Criteria andSubjectCodeIsNotNull() {
            addCriterion("subject_code is not null");
            return (Criteria) this;
        }

        public Criteria andSubjectCodeEqualTo(String value) {
            addCriterion("subject_code =", value, "subjectCode");
            return (Criteria) this;
        }

        public Criteria andSubjectCodeNotEqualTo(String value) {
            addCriterion("subject_code <>", value, "subjectCode");
            return (Criteria) this;
        }

        public Criteria andSubjectCodeGreaterThan(String value) {
            addCriterion("subject_code >", value, "subjectCode");
            return (Criteria) this;
        }

        public Criteria andSubjectCodeGreaterThanOrEqualTo(String value) {
            addCriterion("subject_code >=", value, "subjectCode");
            return (Criteria) this;
        }

        public Criteria andSubjectCodeLessThan(String value) {
            addCriterion("subject_code <", value, "subjectCode");
            return (Criteria) this;
        }

        public Criteria andSubjectCodeLessThanOrEqualTo(String value) {
            addCriterion("subject_code <=", value, "subjectCode");
            return (Criteria) this;
        }

        public Criteria andSubjectCodeLike(String value) {
            addCriterion("subject_code like", value, "subjectCode");
            return (Criteria) this;
        }

        public Criteria andSubjectCodeNotLike(String value) {
            addCriterion("subject_code not like", value, "subjectCode");
            return (Criteria) this;
        }

        public Criteria andSubjectCodeIn(List<String> values) {
            addCriterion("subject_code in", values, "subjectCode");
            return (Criteria) this;
        }

        public Criteria andSubjectCodeNotIn(List<String> values) {
            addCriterion("subject_code not in", values, "subjectCode");
            return (Criteria) this;
        }

        public Criteria andSubjectCodeBetween(String value1, String value2) {
            addCriterion("subject_code between", value1, value2, "subjectCode");
            return (Criteria) this;
        }

        public Criteria andSubjectCodeNotBetween(String value1, String value2) {
            addCriterion("subject_code not between", value1, value2, "subjectCode");
            return (Criteria) this;
        }

        public Criteria andProductUuidIsNull() {
            addCriterion("product_uuid is null");
            return (Criteria) this;
        }

        public Criteria andProductUuidIsNotNull() {
            addCriterion("product_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andProductUuidEqualTo(String value) {
            addCriterion("product_uuid =", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotEqualTo(String value) {
            addCriterion("product_uuid <>", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidGreaterThan(String value) {
            addCriterion("product_uuid >", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidGreaterThanOrEqualTo(String value) {
            addCriterion("product_uuid >=", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidLessThan(String value) {
            addCriterion("product_uuid <", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidLessThanOrEqualTo(String value) {
            addCriterion("product_uuid <=", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidLike(String value) {
            addCriterion("product_uuid like", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotLike(String value) {
            addCriterion("product_uuid not like", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidIn(List<String> values) {
            addCriterion("product_uuid in", values, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotIn(List<String> values) {
            addCriterion("product_uuid not in", values, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidBetween(String value1, String value2) {
            addCriterion("product_uuid between", value1, value2, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotBetween(String value1, String value2) {
            addCriterion("product_uuid not between", value1, value2, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductCodeIsNull() {
            addCriterion("product_code is null");
            return (Criteria) this;
        }

        public Criteria andProductCodeIsNotNull() {
            addCriterion("product_code is not null");
            return (Criteria) this;
        }

        public Criteria andProductCodeEqualTo(String value) {
            addCriterion("product_code =", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotEqualTo(String value) {
            addCriterion("product_code <>", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeGreaterThan(String value) {
            addCriterion("product_code >", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeGreaterThanOrEqualTo(String value) {
            addCriterion("product_code >=", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLessThan(String value) {
            addCriterion("product_code <", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLessThanOrEqualTo(String value) {
            addCriterion("product_code <=", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLike(String value) {
            addCriterion("product_code like", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotLike(String value) {
            addCriterion("product_code not like", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeIn(List<String> values) {
            addCriterion("product_code in", values, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotIn(List<String> values) {
            addCriterion("product_code not in", values, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeBetween(String value1, String value2) {
            addCriterion("product_code between", value1, value2, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotBetween(String value1, String value2) {
            addCriterion("product_code not between", value1, value2, "productCode");
            return (Criteria) this;
        }

        public Criteria andTradeOrderUuidIsNull() {
            addCriterion("trade_order_uuid is null");
            return (Criteria) this;
        }

        public Criteria andTradeOrderUuidIsNotNull() {
            addCriterion("trade_order_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andTradeOrderUuidEqualTo(String value) {
            addCriterion("trade_order_uuid =", value, "tradeOrderUuid");
            return (Criteria) this;
        }

        public Criteria andTradeOrderUuidNotEqualTo(String value) {
            addCriterion("trade_order_uuid <>", value, "tradeOrderUuid");
            return (Criteria) this;
        }

        public Criteria andTradeOrderUuidGreaterThan(String value) {
            addCriterion("trade_order_uuid >", value, "tradeOrderUuid");
            return (Criteria) this;
        }

        public Criteria andTradeOrderUuidGreaterThanOrEqualTo(String value) {
            addCriterion("trade_order_uuid >=", value, "tradeOrderUuid");
            return (Criteria) this;
        }

        public Criteria andTradeOrderUuidLessThan(String value) {
            addCriterion("trade_order_uuid <", value, "tradeOrderUuid");
            return (Criteria) this;
        }

        public Criteria andTradeOrderUuidLessThanOrEqualTo(String value) {
            addCriterion("trade_order_uuid <=", value, "tradeOrderUuid");
            return (Criteria) this;
        }

        public Criteria andTradeOrderUuidLike(String value) {
            addCriterion("trade_order_uuid like", value, "tradeOrderUuid");
            return (Criteria) this;
        }

        public Criteria andTradeOrderUuidNotLike(String value) {
            addCriterion("trade_order_uuid not like", value, "tradeOrderUuid");
            return (Criteria) this;
        }

        public Criteria andTradeOrderUuidIn(List<String> values) {
            addCriterion("trade_order_uuid in", values, "tradeOrderUuid");
            return (Criteria) this;
        }

        public Criteria andTradeOrderUuidNotIn(List<String> values) {
            addCriterion("trade_order_uuid not in", values, "tradeOrderUuid");
            return (Criteria) this;
        }

        public Criteria andTradeOrderUuidBetween(String value1, String value2) {
            addCriterion("trade_order_uuid between", value1, value2, "tradeOrderUuid");
            return (Criteria) this;
        }

        public Criteria andTradeOrderUuidNotBetween(String value1, String value2) {
            addCriterion("trade_order_uuid not between", value1, value2, "tradeOrderUuid");
            return (Criteria) this;
        }

        public Criteria andRemark1IsNull() {
            addCriterion("remark1 is null");
            return (Criteria) this;
        }

        public Criteria andRemark1IsNotNull() {
            addCriterion("remark1 is not null");
            return (Criteria) this;
        }

        public Criteria andRemark1EqualTo(String value) {
            addCriterion("remark1 =", value, "remark1");
            return (Criteria) this;
        }

        public Criteria andRemark1NotEqualTo(String value) {
            addCriterion("remark1 <>", value, "remark1");
            return (Criteria) this;
        }

        public Criteria andRemark1GreaterThan(String value) {
            addCriterion("remark1 >", value, "remark1");
            return (Criteria) this;
        }

        public Criteria andRemark1GreaterThanOrEqualTo(String value) {
            addCriterion("remark1 >=", value, "remark1");
            return (Criteria) this;
        }

        public Criteria andRemark1LessThan(String value) {
            addCriterion("remark1 <", value, "remark1");
            return (Criteria) this;
        }

        public Criteria andRemark1LessThanOrEqualTo(String value) {
            addCriterion("remark1 <=", value, "remark1");
            return (Criteria) this;
        }

        public Criteria andRemark1Like(String value) {
            addCriterion("remark1 like", value, "remark1");
            return (Criteria) this;
        }

        public Criteria andRemark1NotLike(String value) {
            addCriterion("remark1 not like", value, "remark1");
            return (Criteria) this;
        }

        public Criteria andRemark1In(List<String> values) {
            addCriterion("remark1 in", values, "remark1");
            return (Criteria) this;
        }

        public Criteria andRemark1NotIn(List<String> values) {
            addCriterion("remark1 not in", values, "remark1");
            return (Criteria) this;
        }

        public Criteria andRemark1Between(String value1, String value2) {
            addCriterion("remark1 between", value1, value2, "remark1");
            return (Criteria) this;
        }

        public Criteria andRemark1NotBetween(String value1, String value2) {
            addCriterion("remark1 not between", value1, value2, "remark1");
            return (Criteria) this;
        }

        public Criteria andTransactionStatusIsNull() {
            addCriterion("transaction_status is null");
            return (Criteria) this;
        }

        public Criteria andTransactionStatusIsNotNull() {
            addCriterion("transaction_status is not null");
            return (Criteria) this;
        }

        public Criteria andTransactionStatusEqualTo(Byte value) {
            addCriterion("transaction_status =", value, "transactionStatus");
            return (Criteria) this;
        }

        public Criteria andTransactionStatusNotEqualTo(Byte value) {
            addCriterion("transaction_status <>", value, "transactionStatus");
            return (Criteria) this;
        }

        public Criteria andTransactionStatusGreaterThan(Byte value) {
            addCriterion("transaction_status >", value, "transactionStatus");
            return (Criteria) this;
        }

        public Criteria andTransactionStatusGreaterThanOrEqualTo(Byte value) {
            addCriterion("transaction_status >=", value, "transactionStatus");
            return (Criteria) this;
        }

        public Criteria andTransactionStatusLessThan(Byte value) {
            addCriterion("transaction_status <", value, "transactionStatus");
            return (Criteria) this;
        }

        public Criteria andTransactionStatusLessThanOrEqualTo(Byte value) {
            addCriterion("transaction_status <=", value, "transactionStatus");
            return (Criteria) this;
        }

        public Criteria andTransactionStatusIn(List<Byte> values) {
            addCriterion("transaction_status in", values, "transactionStatus");
            return (Criteria) this;
        }

        public Criteria andTransactionStatusNotIn(List<Byte> values) {
            addCriterion("transaction_status not in", values, "transactionStatus");
            return (Criteria) this;
        }

        public Criteria andTransactionStatusBetween(Byte value1, Byte value2) {
            addCriterion("transaction_status between", value1, value2, "transactionStatus");
            return (Criteria) this;
        }

        public Criteria andTransactionStatusNotBetween(Byte value1, Byte value2) {
            addCriterion("transaction_status not between", value1, value2, "transactionStatus");
            return (Criteria) this;
        }

        public Criteria andAuditOperatorIsNull() {
            addCriterion("audit_operator is null");
            return (Criteria) this;
        }

        public Criteria andAuditOperatorIsNotNull() {
            addCriterion("audit_operator is not null");
            return (Criteria) this;
        }

        public Criteria andAuditOperatorEqualTo(String value) {
            addCriterion("audit_operator =", value, "auditOperator");
            return (Criteria) this;
        }

        public Criteria andAuditOperatorNotEqualTo(String value) {
            addCriterion("audit_operator <>", value, "auditOperator");
            return (Criteria) this;
        }

        public Criteria andAuditOperatorGreaterThan(String value) {
            addCriterion("audit_operator >", value, "auditOperator");
            return (Criteria) this;
        }

        public Criteria andAuditOperatorGreaterThanOrEqualTo(String value) {
            addCriterion("audit_operator >=", value, "auditOperator");
            return (Criteria) this;
        }

        public Criteria andAuditOperatorLessThan(String value) {
            addCriterion("audit_operator <", value, "auditOperator");
            return (Criteria) this;
        }

        public Criteria andAuditOperatorLessThanOrEqualTo(String value) {
            addCriterion("audit_operator <=", value, "auditOperator");
            return (Criteria) this;
        }

        public Criteria andAuditOperatorLike(String value) {
            addCriterion("audit_operator like", value, "auditOperator");
            return (Criteria) this;
        }

        public Criteria andAuditOperatorNotLike(String value) {
            addCriterion("audit_operator not like", value, "auditOperator");
            return (Criteria) this;
        }

        public Criteria andAuditOperatorIn(List<String> values) {
            addCriterion("audit_operator in", values, "auditOperator");
            return (Criteria) this;
        }

        public Criteria andAuditOperatorNotIn(List<String> values) {
            addCriterion("audit_operator not in", values, "auditOperator");
            return (Criteria) this;
        }

        public Criteria andAuditOperatorBetween(String value1, String value2) {
            addCriterion("audit_operator between", value1, value2, "auditOperator");
            return (Criteria) this;
        }

        public Criteria andAuditOperatorNotBetween(String value1, String value2) {
            addCriterion("audit_operator not between", value1, value2, "auditOperator");
            return (Criteria) this;
        }

        public Criteria andAuditTimeIsNull() {
            addCriterion("audit_time is null");
            return (Criteria) this;
        }

        public Criteria andAuditTimeIsNotNull() {
            addCriterion("audit_time is not null");
            return (Criteria) this;
        }

        public Criteria andAuditTimeEqualTo(Date value) {
            addCriterion("audit_time =", value, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditTimeNotEqualTo(Date value) {
            addCriterion("audit_time <>", value, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditTimeGreaterThan(Date value) {
            addCriterion("audit_time >", value, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("audit_time >=", value, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditTimeLessThan(Date value) {
            addCriterion("audit_time <", value, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditTimeLessThanOrEqualTo(Date value) {
            addCriterion("audit_time <=", value, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditTimeIn(List<Date> values) {
            addCriterion("audit_time in", values, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditTimeNotIn(List<Date> values) {
            addCriterion("audit_time not in", values, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditTimeBetween(Date value1, Date value2) {
            addCriterion("audit_time between", value1, value2, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditTimeNotBetween(Date value1, Date value2) {
            addCriterion("audit_time not between", value1, value2, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionIsNull() {
            addCriterion("audit_opinion is null");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionIsNotNull() {
            addCriterion("audit_opinion is not null");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionEqualTo(String value) {
            addCriterion("audit_opinion =", value, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionNotEqualTo(String value) {
            addCriterion("audit_opinion <>", value, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionGreaterThan(String value) {
            addCriterion("audit_opinion >", value, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionGreaterThanOrEqualTo(String value) {
            addCriterion("audit_opinion >=", value, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionLessThan(String value) {
            addCriterion("audit_opinion <", value, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionLessThanOrEqualTo(String value) {
            addCriterion("audit_opinion <=", value, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionLike(String value) {
            addCriterion("audit_opinion like", value, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionNotLike(String value) {
            addCriterion("audit_opinion not like", value, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionIn(List<String> values) {
            addCriterion("audit_opinion in", values, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionNotIn(List<String> values) {
            addCriterion("audit_opinion not in", values, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionBetween(String value1, String value2) {
            addCriterion("audit_opinion between", value1, value2, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionNotBetween(String value1, String value2) {
            addCriterion("audit_opinion not between", value1, value2, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andPayedOperatorIsNull() {
            addCriterion("payed_operator is null");
            return (Criteria) this;
        }

        public Criteria andPayedOperatorIsNotNull() {
            addCriterion("payed_operator is not null");
            return (Criteria) this;
        }

        public Criteria andPayedOperatorEqualTo(String value) {
            addCriterion("payed_operator =", value, "payedOperator");
            return (Criteria) this;
        }

        public Criteria andPayedOperatorNotEqualTo(String value) {
            addCriterion("payed_operator <>", value, "payedOperator");
            return (Criteria) this;
        }

        public Criteria andPayedOperatorGreaterThan(String value) {
            addCriterion("payed_operator >", value, "payedOperator");
            return (Criteria) this;
        }

        public Criteria andPayedOperatorGreaterThanOrEqualTo(String value) {
            addCriterion("payed_operator >=", value, "payedOperator");
            return (Criteria) this;
        }

        public Criteria andPayedOperatorLessThan(String value) {
            addCriterion("payed_operator <", value, "payedOperator");
            return (Criteria) this;
        }

        public Criteria andPayedOperatorLessThanOrEqualTo(String value) {
            addCriterion("payed_operator <=", value, "payedOperator");
            return (Criteria) this;
        }

        public Criteria andPayedOperatorLike(String value) {
            addCriterion("payed_operator like", value, "payedOperator");
            return (Criteria) this;
        }

        public Criteria andPayedOperatorNotLike(String value) {
            addCriterion("payed_operator not like", value, "payedOperator");
            return (Criteria) this;
        }

        public Criteria andPayedOperatorIn(List<String> values) {
            addCriterion("payed_operator in", values, "payedOperator");
            return (Criteria) this;
        }

        public Criteria andPayedOperatorNotIn(List<String> values) {
            addCriterion("payed_operator not in", values, "payedOperator");
            return (Criteria) this;
        }

        public Criteria andPayedOperatorBetween(String value1, String value2) {
            addCriterion("payed_operator between", value1, value2, "payedOperator");
            return (Criteria) this;
        }

        public Criteria andPayedOperatorNotBetween(String value1, String value2) {
            addCriterion("payed_operator not between", value1, value2, "payedOperator");
            return (Criteria) this;
        }

        public Criteria andPayedTimeIsNull() {
            addCriterion("payed_time is null");
            return (Criteria) this;
        }

        public Criteria andPayedTimeIsNotNull() {
            addCriterion("payed_time is not null");
            return (Criteria) this;
        }

        public Criteria andPayedTimeEqualTo(Date value) {
            addCriterion("payed_time =", value, "payedTime");
            return (Criteria) this;
        }

        public Criteria andPayedTimeNotEqualTo(Date value) {
            addCriterion("payed_time <>", value, "payedTime");
            return (Criteria) this;
        }

        public Criteria andPayedTimeGreaterThan(Date value) {
            addCriterion("payed_time >", value, "payedTime");
            return (Criteria) this;
        }

        public Criteria andPayedTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("payed_time >=", value, "payedTime");
            return (Criteria) this;
        }

        public Criteria andPayedTimeLessThan(Date value) {
            addCriterion("payed_time <", value, "payedTime");
            return (Criteria) this;
        }

        public Criteria andPayedTimeLessThanOrEqualTo(Date value) {
            addCriterion("payed_time <=", value, "payedTime");
            return (Criteria) this;
        }

        public Criteria andPayedTimeIn(List<Date> values) {
            addCriterion("payed_time in", values, "payedTime");
            return (Criteria) this;
        }

        public Criteria andPayedTimeNotIn(List<Date> values) {
            addCriterion("payed_time not in", values, "payedTime");
            return (Criteria) this;
        }

        public Criteria andPayedTimeBetween(Date value1, Date value2) {
            addCriterion("payed_time between", value1, value2, "payedTime");
            return (Criteria) this;
        }

        public Criteria andPayedTimeNotBetween(Date value1, Date value2) {
            addCriterion("payed_time not between", value1, value2, "payedTime");
            return (Criteria) this;
        }

        public Criteria andSignatureIsNull() {
            addCriterion("signature is null");
            return (Criteria) this;
        }

        public Criteria andSignatureIsNotNull() {
            addCriterion("signature is not null");
            return (Criteria) this;
        }

        public Criteria andSignatureEqualTo(String value) {
            addCriterion("signature =", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureNotEqualTo(String value) {
            addCriterion("signature <>", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureGreaterThan(String value) {
            addCriterion("signature >", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureGreaterThanOrEqualTo(String value) {
            addCriterion("signature >=", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureLessThan(String value) {
            addCriterion("signature <", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureLessThanOrEqualTo(String value) {
            addCriterion("signature <=", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureLike(String value) {
            addCriterion("signature like", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureNotLike(String value) {
            addCriterion("signature not like", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureIn(List<String> values) {
            addCriterion("signature in", values, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureNotIn(List<String> values) {
            addCriterion("signature not in", values, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureBetween(String value1, String value2) {
            addCriterion("signature between", value1, value2, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureNotBetween(String value1, String value2) {
            addCriterion("signature not between", value1, value2, "signature");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNull() {
            addCriterion("delete_flag is null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNotNull() {
            addCriterion("delete_flag is not null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagEqualTo(Byte value) {
            addCriterion("delete_flag =", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotEqualTo(Byte value) {
            addCriterion("delete_flag <>", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThan(Byte value) {
            addCriterion("delete_flag >", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThanOrEqualTo(Byte value) {
            addCriterion("delete_flag >=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThan(Byte value) {
            addCriterion("delete_flag <", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThanOrEqualTo(Byte value) {
            addCriterion("delete_flag <=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIn(List<Byte> values) {
            addCriterion("delete_flag in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotIn(List<Byte> values) {
            addCriterion("delete_flag not in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagBetween(Byte value1, Byte value2) {
            addCriterion("delete_flag between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotBetween(Byte value1, Byte value2) {
            addCriterion("delete_flag not between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("update_time is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("update_time is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("update_time =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("update_time <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("update_time >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("update_time >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("update_time <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("update_time <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("update_time in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("update_time not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("update_time between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("update_time not between", value1, value2, "updateTime");
            return (Criteria) this;
        }
    }

    /**
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}