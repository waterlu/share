package cn.zjhf.kingold.trade.constant;

/**
 * Created by lutiehua on 2017/6/5.
 */
public interface InvestorType {

    /**
     * 普通投资者
     */
    int INVESTOR = 11;

    /**
     * 理财达人
     */
    int FINANCIAL_PLANNER = 12;

    /**
     * 专职理财师
     */
    int FULL_TIME = 19;
}
