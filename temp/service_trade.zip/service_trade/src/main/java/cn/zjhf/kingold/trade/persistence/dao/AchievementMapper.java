package cn.zjhf.kingold.trade.persistence.dao;

import cn.zjhf.kingold.trade.entity.Achievement;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface AchievementMapper {
    int deleteByPrimaryKey(String achievementUuid);

    int insert(Achievement record);

    Achievement selectByPrimaryKey(String achievementUuid);

    int updateByPrimaryKey(Achievement record);

    /**
     * 查询总业绩金额
     *
     * @param userUuid
     * @return
     */
    BigDecimal queryTotalAchievement(String userUuid);

    /**
     * 根据订单号查询产生的业绩
     *
     * @param orderBillCode
     * @return
     */
    List<Achievement> queryByOrderBillCode(String orderBillCode);
}