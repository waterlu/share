package cn.zjhf.kingold.trade.dto;

import cn.zjhf.kingold.common.param.ParamVO;

import java.math.BigDecimal;

/**
 * @author xiexiaojie
 *         2018/4/25.
 */
public class SendCashDTO extends ParamVO{
    /**
     * 宝付账户账号or用户ID
     */
    private Long accountNo;
    /**
     * 账户可用余额
     */
    private BigDecimal accountCashAmount;
    /**
     * 1.提现;2.全部提现
     */
    private Integer sendType;
    /**
     * 用户UUID
     */
    private String userUuid;

    public Long getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(Long accountNo) {
        this.accountNo = accountNo;
    }

    public BigDecimal getAccountCashAmount() {
        return accountCashAmount;
    }

    public void setAccountCashAmount(BigDecimal accountCashAmount) {
        this.accountCashAmount = accountCashAmount;
    }

    public Integer getSendType() {
        return sendType;
    }

    public void setSendType(Integer sendType) {
        this.sendType = sendType;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    @Override
    public String toString() {
        return "SendCashDTO{" +
                "accountNo=" + accountNo +
                ", accountCashAmount=" + accountCashAmount +
                ", sendType=" + sendType +
                ", userUuid='" + userUuid + '\'' +
                '}';
    }
}
