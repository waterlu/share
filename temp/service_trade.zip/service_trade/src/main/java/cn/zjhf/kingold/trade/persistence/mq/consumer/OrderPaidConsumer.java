package cn.zjhf.kingold.trade.persistence.mq.consumer;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.rocketmq.annotation.RocketMQConsumer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQConsumer;
import cn.zjhf.kingold.trade.constant.BizDefine;
import cn.zjhf.kingold.trade.constant.MarketCampaignCodeEnum;
import cn.zjhf.kingold.trade.constant.TradeStatus;
import cn.zjhf.kingold.trade.dto.CouponSendConditionDto;
import cn.zjhf.kingold.trade.entity.InVO.MarketCampaignVO;
import cn.zjhf.kingold.trade.entity.TradeOrder;
import cn.zjhf.kingold.trade.persistence.dao.AccountTransactionMapper;
import cn.zjhf.kingold.trade.persistence.dao.OperationReportMapper;
import cn.zjhf.kingold.trade.persistence.dao.TradeOrderMapper;
import cn.zjhf.kingold.trade.persistence.mq.message.OrderPaidMessage;
import cn.zjhf.kingold.trade.service.*;
import cn.zjhf.kingold.trade.utils.DataUtils;
import cn.zjhf.kingold.trade.utils.DateUtil;
import cn.zjhf.kingold.trade.utils.WhereCondition;
import com.alibaba.fastjson.JSON;
import com.google.common.collect.ImmutableList;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 定期订单认购成功，更新宝付orderId（支付的时候还不知道哪个orderId是成功的，所以事后刷新）
 *
 * Created by lutiehua on 2017/7/13.
 */
@RocketMQConsumer(topic = "order", tag = "paid")
public class OrderPaidConsumer extends AbstractMQConsumer<OrderPaidMessage> {

    @Autowired
    private IPayService payService;

    @Autowired
    private AccountTransactionMapper accountTransactionMapper;

    @Autowired
    private TradeOrderMapper tradeOrderMapper;

    @Autowired
    private OperationReportMapper operationReportMapper;

    @Autowired
    private ITradeOrderService iTradeOrderService;

    @Autowired
    private IMarketCampaignService marketCampaignService;

    @Autowired
    private IUserService userService;

    @Autowired
    private IAccountService accountService;

    private final Logger LOGGER = LoggerFactory.getLogger(OrderPaidConsumer.class);

    /**
     * 检查交易时间，只筛选出两小时之内的交易
     * @param orderBillCode
     * @return true 近期消息，继续处理；false 远期消息，放弃处理
     */
    private boolean checkTradeTime(String orderBillCode) {
        if(orderBillCode.length() >= 17) {
            String orderTime = orderBillCode.substring(3,17);
            Date occuTime = DateUtil.strToTime(orderTime, "yyyyMMddHHmmss") ;
            if(occuTime!=null) {
                int diffTime = (int) (((new Date()).getTime() - occuTime.getTime()) / (1000 * 3600));
                return diffTime <= 1;
            }
        }

        return false;
    }

    @Override
    public ResponseResult process(OrderPaidMessage order) throws BusinessException {
        if((order!=null) & (checkTradeTime(order.getOrderBillCode()))) {
            ResponseResult transactionResult = doTransaction(order);
            if (transactionResult.getCode() != ResponseCode.OK) {
                return transactionResult;
            }
            ResponseResult couponResult = sendCoupon(order);
            if (couponResult.getCode() != ResponseCode.OK) {
                return couponResult;
            }
            return couponResult;
        }

        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        return responseResult;
    }

    private ResponseResult doTransaction(OrderPaidMessage order) {
        logger.info("==== onFixedOrderSuccess is started ====");
        ResponseResult responseResult = new ResponseResult();
        try {
            // 检查订单状态
            String orderBillCode = order.getOrderBillCode();
            Map<String, Object> orderInfo = tradeOrderMapper.get(orderBillCode);
            int orderStatus = Integer.parseInt(orderInfo.get("orderStatus").toString());
            logger.info("orderStatus={}", orderStatus);
            if (orderStatus == BizDefine.ORDER_STATUS_APPLY) {
                logger.error("订单还没付款：{}", orderStatus);
                responseResult.setCode(ResponseCode.OK);
                responseResult.setMsg(ResponseCode.OK_TEXT);
                return responseResult;
            }

            // 检查支付状态
            String orderBillCodeExtend = payService.getSuccessfulOrderId(orderBillCode);
            if (StringUtils.isBlank(orderBillCodeExtend)) {
                logger.info("订单支付没有成功");
                responseResult.setCode(ResponseCode.OK);
                responseResult.setMsg(ResponseCode.OK_TEXT);
                return responseResult;
            }
            // 更新流水
            Map param = new HashMap();
            param.put("tradeOrderBillCode", orderBillCode);
            param.put("tradeOrderBillCodeExtend", orderBillCodeExtend);
            accountTransactionMapper.updateBaofooOrderId(param);

            // 收款方加钱
            String jsonString = JSON.toJSONString(orderInfo);
            TradeOrder tradeOrder = JSON.parseObject(jsonString, TradeOrder.class);
            accountService.raise(tradeOrder, orderBillCodeExtend);

        } catch (Exception e) {
            logger.error(e.getMessage());
            responseResult.setCode(ResponseCode.EXCEPTION);
            responseResult.setMsg(e.getMessage());
            logger.error("调用认购接口异常：{}", e.getMessage());
        }

        logger.info("==== onFixedOrderSuccess is finished ====");
        return responseResult;
    }

    private boolean insertCerLog(int key, String value) {
        int ret = -1;

        try {
            ret = operationReportMapper.insertCerMqLog(key, value);
        }catch(Exception e) {
            LOGGER.error("插入失败", e);
        }

        LOGGER.info("ret: ", ret);
        return ret > 0;
    }

    private ResponseResult sendCoupon(OrderPaidMessage order) {
        //判断商户号不是金疙瘩不发放优惠券
        if (StringUtils.isNotBlank(order.getBelongMerchantNum()) && !BizDefine.KINGOLD_MERCHANT.equals(order.getBelongMerchantNum())) {
            logger.info("用户投资渠道商户号是：{}", order.getBelongMerchantNum());
            return new ResponseResult();
        }

        long curTime = (new Date()).getTime();
        LOGGER.info("{} sendCoupon start {}", curTime, DataUtils.toString(order));
        LOGGER.info("{} 收到认购消息.orderId={}", curTime, order.getOrderBillCode());
        ResponseResult responseResult = new ResponseResult();
        try {
            String userUuid=order.getUserUuid();
            //获取邀请人uuid
            String inviterUuid = userService.getInviterUuid(order.getUserUuid());
            //触发送金币
            try {
                marketCampaignService.marketCampaignTrigger(new CouponSendConditionDto(userUuid, MarketCampaignCodeEnum.SELF_INVEST.getCode(), order.getOrderBillCode(), null));
            }catch (BusinessException e) {
                LOGGER.error("用户投资触发送金币失败", e);
            }
            if(inviterUuid != null) {
                try {
                    marketCampaignService.marketCampaignTrigger(new CouponSendConditionDto(inviterUuid, MarketCampaignCodeEnum.FRIEND_INVEST.getCode(), order.getOrderBillCode(), null));
                }catch (BusinessException e) {
                    LOGGER.error("邀友投资触发送金币失败", e);
                }
            }

            //触发送红包，需要判断首次
            Map<String, Object> param = new HashMap<>();
            param.put("userUuid", userUuid);
            List<Integer> orderStatus = ImmutableList.of(TradeStatus.ORDER_STATUS_INVEST,
                    TradeStatus.ORDER_STATUS_REFUND, TradeStatus.ORDER_STATUS_LOAN, TradeStatus.ORDER_STATUS_RETURN);
            param.put("orderStatusList", orderStatus);
            param.put("deleteFlag", 0);
            Integer count = iTradeOrderService.getCount(param);
            LOGGER.info("{} tradeOrder count.orderId={}, count={}", curTime, order.getOrderBillCode(), count);
            if (count == 1) {
                LOGGER.info("{} sendCoupon first invest. userUuid={}, orderCode={}", curTime, order.getUserUuid(), order.getOrderBillCode());

                if(insertCerLog(MarketCampaignCodeEnum.FIRST_INVEST.getCode(), order.getOrderBillCode())) {
                    try {
                        marketCampaignService.marketCampaignTrigger(new CouponSendConditionDto(userUuid, MarketCampaignCodeEnum.FIRST_INVEST.getCode(), order.getOrderBillCode(), null));
                    } catch (BusinessException e) {
                        LOGGER.error("首投场景触发失败", e);
                    }
                }

                if (inviterUuid != null) {
                    LOGGER.info("{} sendCoupon friend first invest . userUuid={}, orderCode={}, inviterUuid={}", curTime, order.getUserUuid(), order.getOrderBillCode(), inviterUuid);

                    if(insertCerLog(MarketCampaignCodeEnum.FRIEND_FIRST_INVEST.getCode(), order.getOrderBillCode())) {
                        try {
                            marketCampaignService.marketCampaignTrigger(new CouponSendConditionDto(inviterUuid, MarketCampaignCodeEnum.FRIEND_FIRST_INVEST.getCode(), order.getOrderBillCode(), null));
                        } catch (BusinessException e) {
                            LOGGER.error("邀请好友场景触发失败", e);
                        }
                    }
                }
            } else {
                LOGGER.info("{} 再检查一次", curTime);

                Boolean isFirstInvest = false;

                MarketCampaignVO MarketCampaign = marketCampaignService.getVaildMarketCampaign(MarketCampaignCodeEnum.FRIEND_FIRST_INVEST.getCode());
                LOGGER.info("{} MarketCampaign: {}", curTime, MarketCampaign);
                if(MarketCampaign != null) {
                    WhereCondition where = new WhereCondition();
                    where.setCondi("trade.user_uuid", userUuid);
                    where.setInInt("trade.order_status", TradeStatus.ORDER_STATUS_INVEST,
                            TradeStatus.ORDER_STATUS_REFUND, TradeStatus.ORDER_STATUS_LOAN, TradeStatus.ORDER_STATUS_RETURN);
                    where.setBetween("trade.transaction_time", MarketCampaign.getInvestigateStartTime(), MarketCampaign.getInvestigateEndTime());
                    where.setCondi(" trade.delete_flag=0 ");

                    // 1首次场景有效
                    // 2在该场景的考察时间区间内首次投资
                    LOGGER.info("{} Where: {}", curTime, where.toString());
                    if(tradeOrderMapper.listCountByCondition(where) <= 1) {
                        LOGGER.info("{} 触发首投场景", curTime);
                        isFirstInvest = true;

                        if(insertCerLog(MarketCampaignCodeEnum.FIRST_INVEST.getCode(), order.getOrderBillCode())) {
                            try {
                                marketCampaignService.marketCampaignTrigger(new CouponSendConditionDto(userUuid, MarketCampaignCodeEnum.FIRST_INVEST.getCode(), order.getOrderBillCode(), null));
                            } catch (BusinessException e) {
                                LOGGER.error("首投场景触发失败", e);
                            }
                        }

                        if (inviterUuid != null) {
                            logger.info("sendCoupon friend first invest . userUuid={}, orderCode={}, inviterUuid={}", order.getUserUuid(), order.getOrderBillCode(), inviterUuid);

                            if(insertCerLog(MarketCampaignCodeEnum.FRIEND_FIRST_INVEST.getCode(), order.getOrderBillCode())) {
                                try {
                                    marketCampaignService.marketCampaignTrigger(new CouponSendConditionDto(inviterUuid, MarketCampaignCodeEnum.FRIEND_FIRST_INVEST.getCode(), order.getOrderBillCode(), null));
                                } catch (BusinessException e) {
                                    LOGGER.error("邀请好友首投场景触发失败", e);
                                }
                            }
                        }
                    }
                }else {
                    LOGGER.info("{} MarketCampaign 无效", curTime);
                }

                if(!isFirstInvest) {
                    if(insertCerLog(MarketCampaignCodeEnum.REPEATED_INVESTMENT.getCode(), order.getOrderBillCode())) {
                        try {
                            marketCampaignService.marketCampaignTrigger(new CouponSendConditionDto(userUuid, MarketCampaignCodeEnum.REPEATED_INVESTMENT.getCode(), order.getOrderBillCode(), null));
                        } catch (BusinessException e) {
                            LOGGER.error("复投场景触发失败", e);
                        }
                    }
                }
            }
        } catch (BusinessException e) {
            LOGGER.error("首次投资分发红包失败", e);
        }

        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);

        LOGGER.info("{} sendCoupon end {}", curTime, DataUtils.toString(responseResult));
        return responseResult;
    }

}
