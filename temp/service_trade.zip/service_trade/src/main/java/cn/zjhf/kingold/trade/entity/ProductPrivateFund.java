package cn.zjhf.kingold.trade.entity;

import java.math.BigDecimal;

/**
 * Created by zhangyijie on 2017/6/3.
 */
public class ProductPrivateFund extends Product {

    /**
     * 产品募集(人工)调整金额
     */
    private BigDecimal productAccumulation;

    /**
     * 产品已募集金额
     */
    private BigDecimal productManual;

    /**
     * 外包服务费
     */
    private BigDecimal productServiceFee;

    public BigDecimal getProductAccumulation() {
        return productAccumulation;
    }

    public void setProductAccumulation(BigDecimal productAccumulation) {
        this.productAccumulation = productAccumulation;
    }

    public BigDecimal getProductManual() {
        return productManual;
    }

    public void setProductManual(BigDecimal productManual) {
        this.productManual = productManual;
    }

    public BigDecimal getProductServiceFee() {
        return productServiceFee;
    }

    public void setProductServiceFee(BigDecimal productServiceFee) {
        this.productServiceFee = productServiceFee;
    }
}
