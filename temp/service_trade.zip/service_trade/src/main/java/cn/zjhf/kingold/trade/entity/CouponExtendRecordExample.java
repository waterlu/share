package cn.zjhf.kingold.trade.entity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CouponExtendRecordExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private Integer limit;

    private Integer offset;

    public CouponExtendRecordExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andCouponExtendCodeIsNull() {
            addCriterion("coupon_extend_code is null");
            return (Criteria) this;
        }

        public Criteria andCouponExtendCodeIsNotNull() {
            addCriterion("coupon_extend_code is not null");
            return (Criteria) this;
        }

        public Criteria andCouponExtendCodeEqualTo(String value) {
            addCriterion("coupon_extend_code =", value, "couponExtendCode");
            return (Criteria) this;
        }

        public Criteria andCouponExtendCodeNotEqualTo(String value) {
            addCriterion("coupon_extend_code <>", value, "couponExtendCode");
            return (Criteria) this;
        }

        public Criteria andCouponExtendCodeGreaterThan(String value) {
            addCriterion("coupon_extend_code >", value, "couponExtendCode");
            return (Criteria) this;
        }

        public Criteria andCouponExtendCodeGreaterThanOrEqualTo(String value) {
            addCriterion("coupon_extend_code >=", value, "couponExtendCode");
            return (Criteria) this;
        }

        public Criteria andCouponExtendCodeLessThan(String value) {
            addCriterion("coupon_extend_code <", value, "couponExtendCode");
            return (Criteria) this;
        }

        public Criteria andCouponExtendCodeLessThanOrEqualTo(String value) {
            addCriterion("coupon_extend_code <=", value, "couponExtendCode");
            return (Criteria) this;
        }

        public Criteria andCouponExtendCodeLike(String value) {
            addCriterion("coupon_extend_code like", value, "couponExtendCode");
            return (Criteria) this;
        }

        public Criteria andCouponExtendCodeNotLike(String value) {
            addCriterion("coupon_extend_code not like", value, "couponExtendCode");
            return (Criteria) this;
        }

        public Criteria andCouponExtendCodeIn(List<String> values) {
            addCriterion("coupon_extend_code in", values, "couponExtendCode");
            return (Criteria) this;
        }

        public Criteria andCouponExtendCodeNotIn(List<String> values) {
            addCriterion("coupon_extend_code not in", values, "couponExtendCode");
            return (Criteria) this;
        }

        public Criteria andCouponExtendCodeBetween(String value1, String value2) {
            addCriterion("coupon_extend_code between", value1, value2, "couponExtendCode");
            return (Criteria) this;
        }

        public Criteria andCouponExtendCodeNotBetween(String value1, String value2) {
            addCriterion("coupon_extend_code not between", value1, value2, "couponExtendCode");
            return (Criteria) this;
        }

        public Criteria andCouponCodeIsNull() {
            addCriterion("coupon_code is null");
            return (Criteria) this;
        }

        public Criteria andCouponCodeIsNotNull() {
            addCriterion("coupon_code is not null");
            return (Criteria) this;
        }

        public Criteria andCouponCodeEqualTo(String value) {
            addCriterion("coupon_code =", value, "couponCode");
            return (Criteria) this;
        }

        public Criteria andCouponCodeNotEqualTo(String value) {
            addCriterion("coupon_code <>", value, "couponCode");
            return (Criteria) this;
        }

        public Criteria andCouponCodeGreaterThan(String value) {
            addCriterion("coupon_code >", value, "couponCode");
            return (Criteria) this;
        }

        public Criteria andCouponCodeGreaterThanOrEqualTo(String value) {
            addCriterion("coupon_code >=", value, "couponCode");
            return (Criteria) this;
        }

        public Criteria andCouponCodeLessThan(String value) {
            addCriterion("coupon_code <", value, "couponCode");
            return (Criteria) this;
        }

        public Criteria andCouponCodeLessThanOrEqualTo(String value) {
            addCriterion("coupon_code <=", value, "couponCode");
            return (Criteria) this;
        }

        public Criteria andCouponCodeLike(String value) {
            addCriterion("coupon_code like", value, "couponCode");
            return (Criteria) this;
        }

        public Criteria andCouponCodeNotLike(String value) {
            addCriterion("coupon_code not like", value, "couponCode");
            return (Criteria) this;
        }

        public Criteria andCouponCodeIn(List<String> values) {
            addCriterion("coupon_code in", values, "couponCode");
            return (Criteria) this;
        }

        public Criteria andCouponCodeNotIn(List<String> values) {
            addCriterion("coupon_code not in", values, "couponCode");
            return (Criteria) this;
        }

        public Criteria andCouponCodeBetween(String value1, String value2) {
            addCriterion("coupon_code between", value1, value2, "couponCode");
            return (Criteria) this;
        }

        public Criteria andCouponCodeNotBetween(String value1, String value2) {
            addCriterion("coupon_code not between", value1, value2, "couponCode");
            return (Criteria) this;
        }

        public Criteria andCouponTypeIsNull() {
            addCriterion("coupon_type is null");
            return (Criteria) this;
        }

        public Criteria andCouponTypeIsNotNull() {
            addCriterion("coupon_type is not null");
            return (Criteria) this;
        }

        public Criteria andCouponTypeEqualTo(Byte value) {
            addCriterion("coupon_type =", value, "couponType");
            return (Criteria) this;
        }

        public Criteria andCouponTypeNotEqualTo(Byte value) {
            addCriterion("coupon_type <>", value, "couponType");
            return (Criteria) this;
        }

        public Criteria andCouponTypeGreaterThan(Byte value) {
            addCriterion("coupon_type >", value, "couponType");
            return (Criteria) this;
        }

        public Criteria andCouponTypeGreaterThanOrEqualTo(Byte value) {
            addCriterion("coupon_type >=", value, "couponType");
            return (Criteria) this;
        }

        public Criteria andCouponTypeLessThan(Byte value) {
            addCriterion("coupon_type <", value, "couponType");
            return (Criteria) this;
        }

        public Criteria andCouponTypeLessThanOrEqualTo(Byte value) {
            addCriterion("coupon_type <=", value, "couponType");
            return (Criteria) this;
        }

        public Criteria andCouponTypeIn(List<Byte> values) {
            addCriterion("coupon_type in", values, "couponType");
            return (Criteria) this;
        }

        public Criteria andCouponTypeNotIn(List<Byte> values) {
            addCriterion("coupon_type not in", values, "couponType");
            return (Criteria) this;
        }

        public Criteria andCouponTypeBetween(Byte value1, Byte value2) {
            addCriterion("coupon_type between", value1, value2, "couponType");
            return (Criteria) this;
        }

        public Criteria andCouponTypeNotBetween(Byte value1, Byte value2) {
            addCriterion("coupon_type not between", value1, value2, "couponType");
            return (Criteria) this;
        }

        public Criteria andCouponFaceValueIsNull() {
            addCriterion("coupon_face_value is null");
            return (Criteria) this;
        }

        public Criteria andCouponFaceValueIsNotNull() {
            addCriterion("coupon_face_value is not null");
            return (Criteria) this;
        }

        public Criteria andCouponFaceValueEqualTo(BigDecimal value) {
            addCriterion("coupon_face_value =", value, "couponFaceValue");
            return (Criteria) this;
        }

        public Criteria andCouponFaceValueNotEqualTo(BigDecimal value) {
            addCriterion("coupon_face_value <>", value, "couponFaceValue");
            return (Criteria) this;
        }

        public Criteria andCouponFaceValueGreaterThan(BigDecimal value) {
            addCriterion("coupon_face_value >", value, "couponFaceValue");
            return (Criteria) this;
        }

        public Criteria andCouponFaceValueGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("coupon_face_value >=", value, "couponFaceValue");
            return (Criteria) this;
        }

        public Criteria andCouponFaceValueLessThan(BigDecimal value) {
            addCriterion("coupon_face_value <", value, "couponFaceValue");
            return (Criteria) this;
        }

        public Criteria andCouponFaceValueLessThanOrEqualTo(BigDecimal value) {
            addCriterion("coupon_face_value <=", value, "couponFaceValue");
            return (Criteria) this;
        }

        public Criteria andCouponFaceValueIn(List<BigDecimal> values) {
            addCriterion("coupon_face_value in", values, "couponFaceValue");
            return (Criteria) this;
        }

        public Criteria andCouponFaceValueNotIn(List<BigDecimal> values) {
            addCriterion("coupon_face_value not in", values, "couponFaceValue");
            return (Criteria) this;
        }

        public Criteria andCouponFaceValueBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("coupon_face_value between", value1, value2, "couponFaceValue");
            return (Criteria) this;
        }

        public Criteria andCouponFaceValueNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("coupon_face_value not between", value1, value2, "couponFaceValue");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldRateIsNull() {
            addCriterion("coupon_interest_yield_rate is null");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldRateIsNotNull() {
            addCriterion("coupon_interest_yield_rate is not null");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldRateEqualTo(BigDecimal value) {
            addCriterion("coupon_interest_yield_rate =", value, "couponInterestYieldRate");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldRateNotEqualTo(BigDecimal value) {
            addCriterion("coupon_interest_yield_rate <>", value, "couponInterestYieldRate");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldRateGreaterThan(BigDecimal value) {
            addCriterion("coupon_interest_yield_rate >", value, "couponInterestYieldRate");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldRateGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("coupon_interest_yield_rate >=", value, "couponInterestYieldRate");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldRateLessThan(BigDecimal value) {
            addCriterion("coupon_interest_yield_rate <", value, "couponInterestYieldRate");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldRateLessThanOrEqualTo(BigDecimal value) {
            addCriterion("coupon_interest_yield_rate <=", value, "couponInterestYieldRate");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldRateIn(List<BigDecimal> values) {
            addCriterion("coupon_interest_yield_rate in", values, "couponInterestYieldRate");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldRateNotIn(List<BigDecimal> values) {
            addCriterion("coupon_interest_yield_rate not in", values, "couponInterestYieldRate");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldRateBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("coupon_interest_yield_rate between", value1, value2, "couponInterestYieldRate");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldRateNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("coupon_interest_yield_rate not between", value1, value2, "couponInterestYieldRate");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldTypeIsNull() {
            addCriterion("coupon_interest_yield_type is null");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldTypeIsNotNull() {
            addCriterion("coupon_interest_yield_type is not null");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldTypeEqualTo(Integer value) {
            addCriterion("coupon_interest_yield_type =", value, "couponInterestYieldType");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldTypeNotEqualTo(Integer value) {
            addCriterion("coupon_interest_yield_type <>", value, "couponInterestYieldType");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldTypeGreaterThan(Integer value) {
            addCriterion("coupon_interest_yield_type >", value, "couponInterestYieldType");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("coupon_interest_yield_type >=", value, "couponInterestYieldType");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldTypeLessThan(Integer value) {
            addCriterion("coupon_interest_yield_type <", value, "couponInterestYieldType");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldTypeLessThanOrEqualTo(Integer value) {
            addCriterion("coupon_interest_yield_type <=", value, "couponInterestYieldType");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldTypeIn(List<Integer> values) {
            addCriterion("coupon_interest_yield_type in", values, "couponInterestYieldType");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldTypeNotIn(List<Integer> values) {
            addCriterion("coupon_interest_yield_type not in", values, "couponInterestYieldType");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldTypeBetween(Integer value1, Integer value2) {
            addCriterion("coupon_interest_yield_type between", value1, value2, "couponInterestYieldType");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("coupon_interest_yield_type not between", value1, value2, "couponInterestYieldType");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldPeriodIsNull() {
            addCriterion("coupon_interest_yield_period is null");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldPeriodIsNotNull() {
            addCriterion("coupon_interest_yield_period is not null");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldPeriodEqualTo(Integer value) {
            addCriterion("coupon_interest_yield_period =", value, "couponInterestYieldPeriod");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldPeriodNotEqualTo(Integer value) {
            addCriterion("coupon_interest_yield_period <>", value, "couponInterestYieldPeriod");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldPeriodGreaterThan(Integer value) {
            addCriterion("coupon_interest_yield_period >", value, "couponInterestYieldPeriod");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldPeriodGreaterThanOrEqualTo(Integer value) {
            addCriterion("coupon_interest_yield_period >=", value, "couponInterestYieldPeriod");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldPeriodLessThan(Integer value) {
            addCriterion("coupon_interest_yield_period <", value, "couponInterestYieldPeriod");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldPeriodLessThanOrEqualTo(Integer value) {
            addCriterion("coupon_interest_yield_period <=", value, "couponInterestYieldPeriod");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldPeriodIn(List<Integer> values) {
            addCriterion("coupon_interest_yield_period in", values, "couponInterestYieldPeriod");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldPeriodNotIn(List<Integer> values) {
            addCriterion("coupon_interest_yield_period not in", values, "couponInterestYieldPeriod");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldPeriodBetween(Integer value1, Integer value2) {
            addCriterion("coupon_interest_yield_period between", value1, value2, "couponInterestYieldPeriod");
            return (Criteria) this;
        }

        public Criteria andCouponInterestYieldPeriodNotBetween(Integer value1, Integer value2) {
            addCriterion("coupon_interest_yield_period not between", value1, value2, "couponInterestYieldPeriod");
            return (Criteria) this;
        }

        public Criteria andValidStartTimeIsNull() {
            addCriterion("valid_start_time is null");
            return (Criteria) this;
        }

        public Criteria andValidStartTimeIsNotNull() {
            addCriterion("valid_start_time is not null");
            return (Criteria) this;
        }

        public Criteria andValidStartTimeEqualTo(Date value) {
            addCriterion("valid_start_time =", value, "validStartTime");
            return (Criteria) this;
        }

        public Criteria andValidStartTimeNotEqualTo(Date value) {
            addCriterion("valid_start_time <>", value, "validStartTime");
            return (Criteria) this;
        }

        public Criteria andValidStartTimeGreaterThan(Date value) {
            addCriterion("valid_start_time >", value, "validStartTime");
            return (Criteria) this;
        }

        public Criteria andValidStartTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("valid_start_time >=", value, "validStartTime");
            return (Criteria) this;
        }

        public Criteria andValidStartTimeLessThan(Date value) {
            addCriterion("valid_start_time <", value, "validStartTime");
            return (Criteria) this;
        }

        public Criteria andValidStartTimeLessThanOrEqualTo(Date value) {
            addCriterion("valid_start_time <=", value, "validStartTime");
            return (Criteria) this;
        }

        public Criteria andValidStartTimeIn(List<Date> values) {
            addCriterion("valid_start_time in", values, "validStartTime");
            return (Criteria) this;
        }

        public Criteria andValidStartTimeNotIn(List<Date> values) {
            addCriterion("valid_start_time not in", values, "validStartTime");
            return (Criteria) this;
        }

        public Criteria andValidStartTimeBetween(Date value1, Date value2) {
            addCriterion("valid_start_time between", value1, value2, "validStartTime");
            return (Criteria) this;
        }

        public Criteria andValidStartTimeNotBetween(Date value1, Date value2) {
            addCriterion("valid_start_time not between", value1, value2, "validStartTime");
            return (Criteria) this;
        }

        public Criteria andValidEndTimeIsNull() {
            addCriterion("valid_end_time is null");
            return (Criteria) this;
        }

        public Criteria andValidEndTimeIsNotNull() {
            addCriterion("valid_end_time is not null");
            return (Criteria) this;
        }

        public Criteria andValidEndTimeEqualTo(Date value) {
            addCriterion("valid_end_time =", value, "validEndTime");
            return (Criteria) this;
        }

        public Criteria andValidEndTimeNotEqualTo(Date value) {
            addCriterion("valid_end_time <>", value, "validEndTime");
            return (Criteria) this;
        }

        public Criteria andValidEndTimeGreaterThan(Date value) {
            addCriterion("valid_end_time >", value, "validEndTime");
            return (Criteria) this;
        }

        public Criteria andValidEndTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("valid_end_time >=", value, "validEndTime");
            return (Criteria) this;
        }

        public Criteria andValidEndTimeLessThan(Date value) {
            addCriterion("valid_end_time <", value, "validEndTime");
            return (Criteria) this;
        }

        public Criteria andValidEndTimeLessThanOrEqualTo(Date value) {
            addCriterion("valid_end_time <=", value, "validEndTime");
            return (Criteria) this;
        }

        public Criteria andValidEndTimeIn(List<Date> values) {
            addCriterion("valid_end_time in", values, "validEndTime");
            return (Criteria) this;
        }

        public Criteria andValidEndTimeNotIn(List<Date> values) {
            addCriterion("valid_end_time not in", values, "validEndTime");
            return (Criteria) this;
        }

        public Criteria andValidEndTimeBetween(Date value1, Date value2) {
            addCriterion("valid_end_time between", value1, value2, "validEndTime");
            return (Criteria) this;
        }

        public Criteria andValidEndTimeNotBetween(Date value1, Date value2) {
            addCriterion("valid_end_time not between", value1, value2, "validEndTime");
            return (Criteria) this;
        }

        public Criteria andCouponStatusIsNull() {
            addCriterion("coupon_status is null");
            return (Criteria) this;
        }

        public Criteria andCouponStatusIsNotNull() {
            addCriterion("coupon_status is not null");
            return (Criteria) this;
        }

        public Criteria andCouponStatusEqualTo(Byte value) {
            addCriterion("coupon_status =", value, "couponStatus");
            return (Criteria) this;
        }

        public Criteria andCouponStatusNotEqualTo(Byte value) {
            addCriterion("coupon_status <>", value, "couponStatus");
            return (Criteria) this;
        }

        public Criteria andCouponStatusGreaterThan(Byte value) {
            addCriterion("coupon_status >", value, "couponStatus");
            return (Criteria) this;
        }

        public Criteria andCouponStatusGreaterThanOrEqualTo(Byte value) {
            addCriterion("coupon_status >=", value, "couponStatus");
            return (Criteria) this;
        }

        public Criteria andCouponStatusLessThan(Byte value) {
            addCriterion("coupon_status <", value, "couponStatus");
            return (Criteria) this;
        }

        public Criteria andCouponStatusLessThanOrEqualTo(Byte value) {
            addCriterion("coupon_status <=", value, "couponStatus");
            return (Criteria) this;
        }

        public Criteria andCouponStatusIn(List<Byte> values) {
            addCriterion("coupon_status in", values, "couponStatus");
            return (Criteria) this;
        }

        public Criteria andCouponStatusNotIn(List<Byte> values) {
            addCriterion("coupon_status not in", values, "couponStatus");
            return (Criteria) this;
        }

        public Criteria andCouponStatusBetween(Byte value1, Byte value2) {
            addCriterion("coupon_status between", value1, value2, "couponStatus");
            return (Criteria) this;
        }

        public Criteria andCouponStatusNotBetween(Byte value1, Byte value2) {
            addCriterion("coupon_status not between", value1, value2, "couponStatus");
            return (Criteria) this;
        }

        public Criteria andUserUuidIsNull() {
            addCriterion("user_uuid is null");
            return (Criteria) this;
        }

        public Criteria andUserUuidIsNotNull() {
            addCriterion("user_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andUserUuidEqualTo(String value) {
            addCriterion("user_uuid =", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidNotEqualTo(String value) {
            addCriterion("user_uuid <>", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidGreaterThan(String value) {
            addCriterion("user_uuid >", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidGreaterThanOrEqualTo(String value) {
            addCriterion("user_uuid >=", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidLessThan(String value) {
            addCriterion("user_uuid <", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidLessThanOrEqualTo(String value) {
            addCriterion("user_uuid <=", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidLike(String value) {
            addCriterion("user_uuid like", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidNotLike(String value) {
            addCriterion("user_uuid not like", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidIn(List<String> values) {
            addCriterion("user_uuid in", values, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidNotIn(List<String> values) {
            addCriterion("user_uuid not in", values, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidBetween(String value1, String value2) {
            addCriterion("user_uuid between", value1, value2, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidNotBetween(String value1, String value2) {
            addCriterion("user_uuid not between", value1, value2, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNumberIsNull() {
            addCriterion("user_phone_number is null");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNumberIsNotNull() {
            addCriterion("user_phone_number is not null");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNumberEqualTo(String value) {
            addCriterion("user_phone_number =", value, "userPhoneNumber");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNumberNotEqualTo(String value) {
            addCriterion("user_phone_number <>", value, "userPhoneNumber");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNumberGreaterThan(String value) {
            addCriterion("user_phone_number >", value, "userPhoneNumber");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNumberGreaterThanOrEqualTo(String value) {
            addCriterion("user_phone_number >=", value, "userPhoneNumber");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNumberLessThan(String value) {
            addCriterion("user_phone_number <", value, "userPhoneNumber");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNumberLessThanOrEqualTo(String value) {
            addCriterion("user_phone_number <=", value, "userPhoneNumber");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNumberLike(String value) {
            addCriterion("user_phone_number like", value, "userPhoneNumber");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNumberNotLike(String value) {
            addCriterion("user_phone_number not like", value, "userPhoneNumber");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNumberIn(List<String> values) {
            addCriterion("user_phone_number in", values, "userPhoneNumber");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNumberNotIn(List<String> values) {
            addCriterion("user_phone_number not in", values, "userPhoneNumber");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNumberBetween(String value1, String value2) {
            addCriterion("user_phone_number between", value1, value2, "userPhoneNumber");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNumberNotBetween(String value1, String value2) {
            addCriterion("user_phone_number not between", value1, value2, "userPhoneNumber");
            return (Criteria) this;
        }

        public Criteria andUserNameIsNull() {
            addCriterion("user_name is null");
            return (Criteria) this;
        }

        public Criteria andUserNameIsNotNull() {
            addCriterion("user_name is not null");
            return (Criteria) this;
        }

        public Criteria andUserNameEqualTo(String value) {
            addCriterion("user_name =", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameNotEqualTo(String value) {
            addCriterion("user_name <>", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameGreaterThan(String value) {
            addCriterion("user_name >", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameGreaterThanOrEqualTo(String value) {
            addCriterion("user_name >=", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameLessThan(String value) {
            addCriterion("user_name <", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameLessThanOrEqualTo(String value) {
            addCriterion("user_name <=", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameLike(String value) {
            addCriterion("user_name like", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameNotLike(String value) {
            addCriterion("user_name not like", value, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameIn(List<String> values) {
            addCriterion("user_name in", values, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameNotIn(List<String> values) {
            addCriterion("user_name not in", values, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameBetween(String value1, String value2) {
            addCriterion("user_name between", value1, value2, "userName");
            return (Criteria) this;
        }

        public Criteria andUserNameNotBetween(String value1, String value2) {
            addCriterion("user_name not between", value1, value2, "userName");
            return (Criteria) this;
        }

        public Criteria andApplySceneIsNull() {
            addCriterion("apply_scene is null");
            return (Criteria) this;
        }

        public Criteria andApplySceneIsNotNull() {
            addCriterion("apply_scene is not null");
            return (Criteria) this;
        }

        public Criteria andApplySceneEqualTo(Byte value) {
            addCriterion("apply_scene =", value, "applyScene");
            return (Criteria) this;
        }

        public Criteria andApplySceneNotEqualTo(Byte value) {
            addCriterion("apply_scene <>", value, "applyScene");
            return (Criteria) this;
        }

        public Criteria andApplySceneGreaterThan(Byte value) {
            addCriterion("apply_scene >", value, "applyScene");
            return (Criteria) this;
        }

        public Criteria andApplySceneGreaterThanOrEqualTo(Byte value) {
            addCriterion("apply_scene >=", value, "applyScene");
            return (Criteria) this;
        }

        public Criteria andApplySceneLessThan(Byte value) {
            addCriterion("apply_scene <", value, "applyScene");
            return (Criteria) this;
        }

        public Criteria andApplySceneLessThanOrEqualTo(Byte value) {
            addCriterion("apply_scene <=", value, "applyScene");
            return (Criteria) this;
        }

        public Criteria andApplySceneIn(List<Byte> values) {
            addCriterion("apply_scene in", values, "applyScene");
            return (Criteria) this;
        }

        public Criteria andApplySceneNotIn(List<Byte> values) {
            addCriterion("apply_scene not in", values, "applyScene");
            return (Criteria) this;
        }

        public Criteria andApplySceneBetween(Byte value1, Byte value2) {
            addCriterion("apply_scene between", value1, value2, "applyScene");
            return (Criteria) this;
        }

        public Criteria andApplySceneNotBetween(Byte value1, Byte value2) {
            addCriterion("apply_scene not between", value1, value2, "applyScene");
            return (Criteria) this;
        }

        public Criteria andCancelTimeIsNull() {
            addCriterion("cancel_time is null");
            return (Criteria) this;
        }

        public Criteria andCancelTimeIsNotNull() {
            addCriterion("cancel_time is not null");
            return (Criteria) this;
        }

        public Criteria andCancelTimeEqualTo(Date value) {
            addCriterion("cancel_time =", value, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeNotEqualTo(Date value) {
            addCriterion("cancel_time <>", value, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeGreaterThan(Date value) {
            addCriterion("cancel_time >", value, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("cancel_time >=", value, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeLessThan(Date value) {
            addCriterion("cancel_time <", value, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeLessThanOrEqualTo(Date value) {
            addCriterion("cancel_time <=", value, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeIn(List<Date> values) {
            addCriterion("cancel_time in", values, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeNotIn(List<Date> values) {
            addCriterion("cancel_time not in", values, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeBetween(Date value1, Date value2) {
            addCriterion("cancel_time between", value1, value2, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelTimeNotBetween(Date value1, Date value2) {
            addCriterion("cancel_time not between", value1, value2, "cancelTime");
            return (Criteria) this;
        }

        public Criteria andCancelRemarkIsNull() {
            addCriterion("cancel_remark is null");
            return (Criteria) this;
        }

        public Criteria andCancelRemarkIsNotNull() {
            addCriterion("cancel_remark is not null");
            return (Criteria) this;
        }

        public Criteria andCancelRemarkEqualTo(String value) {
            addCriterion("cancel_remark =", value, "cancelRemark");
            return (Criteria) this;
        }

        public Criteria andCancelRemarkNotEqualTo(String value) {
            addCriterion("cancel_remark <>", value, "cancelRemark");
            return (Criteria) this;
        }

        public Criteria andCancelRemarkGreaterThan(String value) {
            addCriterion("cancel_remark >", value, "cancelRemark");
            return (Criteria) this;
        }

        public Criteria andCancelRemarkGreaterThanOrEqualTo(String value) {
            addCriterion("cancel_remark >=", value, "cancelRemark");
            return (Criteria) this;
        }

        public Criteria andCancelRemarkLessThan(String value) {
            addCriterion("cancel_remark <", value, "cancelRemark");
            return (Criteria) this;
        }

        public Criteria andCancelRemarkLessThanOrEqualTo(String value) {
            addCriterion("cancel_remark <=", value, "cancelRemark");
            return (Criteria) this;
        }

        public Criteria andCancelRemarkLike(String value) {
            addCriterion("cancel_remark like", value, "cancelRemark");
            return (Criteria) this;
        }

        public Criteria andCancelRemarkNotLike(String value) {
            addCriterion("cancel_remark not like", value, "cancelRemark");
            return (Criteria) this;
        }

        public Criteria andCancelRemarkIn(List<String> values) {
            addCriterion("cancel_remark in", values, "cancelRemark");
            return (Criteria) this;
        }

        public Criteria andCancelRemarkNotIn(List<String> values) {
            addCriterion("cancel_remark not in", values, "cancelRemark");
            return (Criteria) this;
        }

        public Criteria andCancelRemarkBetween(String value1, String value2) {
            addCriterion("cancel_remark between", value1, value2, "cancelRemark");
            return (Criteria) this;
        }

        public Criteria andCancelRemarkNotBetween(String value1, String value2) {
            addCriterion("cancel_remark not between", value1, value2, "cancelRemark");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNull() {
            addCriterion("delete_flag is null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNotNull() {
            addCriterion("delete_flag is not null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagEqualTo(Byte value) {
            addCriterion("delete_flag =", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotEqualTo(Byte value) {
            addCriterion("delete_flag <>", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThan(Byte value) {
            addCriterion("delete_flag >", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThanOrEqualTo(Byte value) {
            addCriterion("delete_flag >=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThan(Byte value) {
            addCriterion("delete_flag <", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThanOrEqualTo(Byte value) {
            addCriterion("delete_flag <=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIn(List<Byte> values) {
            addCriterion("delete_flag in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotIn(List<Byte> values) {
            addCriterion("delete_flag not in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagBetween(Byte value1, Byte value2) {
            addCriterion("delete_flag between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotBetween(Byte value1, Byte value2) {
            addCriterion("delete_flag not between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("update_time is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("update_time is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("update_time =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("update_time <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("update_time >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("update_time >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("update_time <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("update_time <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("update_time in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("update_time not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("update_time between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("update_time not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNull() {
            addCriterion("update_user_id is null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIsNotNull() {
            addCriterion("update_user_id is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdEqualTo(String value) {
            addCriterion("update_user_id =", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotEqualTo(String value) {
            addCriterion("update_user_id <>", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThan(String value) {
            addCriterion("update_user_id >", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdGreaterThanOrEqualTo(String value) {
            addCriterion("update_user_id >=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThan(String value) {
            addCriterion("update_user_id <", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLessThanOrEqualTo(String value) {
            addCriterion("update_user_id <=", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdLike(String value) {
            addCriterion("update_user_id like", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotLike(String value) {
            addCriterion("update_user_id not like", value, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdIn(List<String> values) {
            addCriterion("update_user_id in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotIn(List<String> values) {
            addCriterion("update_user_id not in", values, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdBetween(String value1, String value2) {
            addCriterion("update_user_id between", value1, value2, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andUpdateUserIdNotBetween(String value1, String value2) {
            addCriterion("update_user_id not between", value1, value2, "updateUserId");
            return (Criteria) this;
        }

        public Criteria andOrderBillCodeIsNull() {
            addCriterion("order_bill_code is null");
            return (Criteria) this;
        }

        public Criteria andOrderBillCodeIsNotNull() {
            addCriterion("order_bill_code is not null");
            return (Criteria) this;
        }

        public Criteria andOrderBillCodeEqualTo(String value) {
            addCriterion("order_bill_code =", value, "orderBillCode");
            return (Criteria) this;
        }

        public Criteria andOrderBillCodeNotEqualTo(String value) {
            addCriterion("order_bill_code <>", value, "orderBillCode");
            return (Criteria) this;
        }

        public Criteria andOrderBillCodeGreaterThan(String value) {
            addCriterion("order_bill_code >", value, "orderBillCode");
            return (Criteria) this;
        }

        public Criteria andOrderBillCodeGreaterThanOrEqualTo(String value) {
            addCriterion("order_bill_code >=", value, "orderBillCode");
            return (Criteria) this;
        }

        public Criteria andOrderBillCodeLessThan(String value) {
            addCriterion("order_bill_code <", value, "orderBillCode");
            return (Criteria) this;
        }

        public Criteria andOrderBillCodeLessThanOrEqualTo(String value) {
            addCriterion("order_bill_code <=", value, "orderBillCode");
            return (Criteria) this;
        }

        public Criteria andOrderBillCodeLike(String value) {
            addCriterion("order_bill_code like", value, "orderBillCode");
            return (Criteria) this;
        }

        public Criteria andOrderBillCodeNotLike(String value) {
            addCriterion("order_bill_code not like", value, "orderBillCode");
            return (Criteria) this;
        }

        public Criteria andOrderBillCodeIn(List<String> values) {
            addCriterion("order_bill_code in", values, "orderBillCode");
            return (Criteria) this;
        }

        public Criteria andOrderBillCodeNotIn(List<String> values) {
            addCriterion("order_bill_code not in", values, "orderBillCode");
            return (Criteria) this;
        }

        public Criteria andOrderBillCodeBetween(String value1, String value2) {
            addCriterion("order_bill_code between", value1, value2, "orderBillCode");
            return (Criteria) this;
        }

        public Criteria andOrderBillCodeNotBetween(String value1, String value2) {
            addCriterion("order_bill_code not between", value1, value2, "orderBillCode");
            return (Criteria) this;
        }
    }

    /**
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}