package cn.zjhf.kingold.trade.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author 
 */
public class AccountUnpaidFund implements Serializable {
    /**
     * 自增ID
     */
    private Long accountTransactionUuid;

    /**
     * 交易流水单编号
     */
    private String transactionBillCode;

    /**
     * 资金凭证单号，如宝付的资金流水号
     */
    private String tradeOrderBillCode;

    /**
     * 交易时间
     */
    private Date transactionTime;

    /**
     * 用户UUID
     */
    private String outUserUuid;

    /**
     * 账户UUID
     */
    private String outAccountUuid;

    /**
     * 托管机构用户账号
     */
    private String outAccountNo;

    /**
     * 对手方用户UUID
     */
    private String inUserUuid;

    /**
     * 对手方账户UUID
     */
    private String inAccountUuid;

    /**
     * 对手方托管机构用户账号
     */
    private String inAccountNo;

    /**
     * 金额
     */
    private BigDecimal transactionAmount;

    /**
     * 交易类型：
  1充值手续费；
  2提现手续费；
  21产品募集资金1_客户缴纳部分；
  22产品募集资金2_平台代金券部分；
  23产品成立_平台佣金；
  12产品成立_理财顾问业绩(佣金)；
  13产品成立_1度邀请奖励佣金；
  14产品成立_2度邀请奖励佣金；
  31产品到期本金和收益；
  32产品到期营销加息
     */
    private String tradeType;

    /**
     * 会计科目
     */
    private String subjectCode;

    /**
     * 产品UUID
     */
    private String productUuid;

    /**
     * 产品编码(冗余)
     */
    private String productCode;

    /**
     * 产品相关涉及，交易单号
     */
    private String tradeOrderUuid;

    /**
     * 产品相关涉及，如是购买/撤销/赎回/到期产品，则填写购买的产品名称、数量、金额等
     */
    private String remark1;

    /**
     * 处理状态 1待审核；2审核通过, 审批失败仍然回到 待审核 的状态；3已兑付
     */
    private Byte transactionStatus;

    /**
     * 审核人
     */
    private String auditOperator;

    /**
     * 审核时间
     */
    private Date auditTime;

    /**
     * 审核意见
     */
    private String auditOpinion;

    /**
     * 兑付人
     */
    private String payedOperator;

    /**
     * 兑付时间
     */
    private Date payedTime;

    /**
     * 签名
     */
    private String signature;

    /**
     * 删除标记 0未删除，1已删除
     */
    private Byte deleteFlag;

    private Date createTime;

    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public Long getAccountTransactionUuid() {
        return accountTransactionUuid;
    }

    public void setAccountTransactionUuid(Long accountTransactionUuid) {
        this.accountTransactionUuid = accountTransactionUuid;
    }

    public String getTransactionBillCode() {
        return transactionBillCode;
    }

    public void setTransactionBillCode(String transactionBillCode) {
        this.transactionBillCode = transactionBillCode;
    }

    public String getTradeOrderBillCode() {
        return tradeOrderBillCode;
    }

    public void setTradeOrderBillCode(String tradeOrderBillCode) {
        this.tradeOrderBillCode = tradeOrderBillCode;
    }

    public Date getTransactionTime() {
        return transactionTime;
    }

    public void setTransactionTime(Date transactionTime) {
        this.transactionTime = transactionTime;
    }

    public String getOutUserUuid() {
        return outUserUuid;
    }

    public void setOutUserUuid(String outUserUuid) {
        this.outUserUuid = outUserUuid;
    }

    public String getOutAccountUuid() {
        return outAccountUuid;
    }

    public void setOutAccountUuid(String outAccountUuid) {
        this.outAccountUuid = outAccountUuid;
    }

    public String getOutAccountNo() {
        return outAccountNo;
    }

    public void setOutAccountNo(String outAccountNo) {
        this.outAccountNo = outAccountNo;
    }

    public String getInUserUuid() {
        return inUserUuid;
    }

    public void setInUserUuid(String inUserUuid) {
        this.inUserUuid = inUserUuid;
    }

    public String getInAccountUuid() {
        return inAccountUuid;
    }

    public void setInAccountUuid(String inAccountUuid) {
        this.inAccountUuid = inAccountUuid;
    }

    public String getInAccountNo() {
        return inAccountNo;
    }

    public void setInAccountNo(String inAccountNo) {
        this.inAccountNo = inAccountNo;
    }

    public BigDecimal getTransactionAmount() {
        return transactionAmount;
    }

    public void setTransactionAmount(BigDecimal transactionAmount) {
        this.transactionAmount = transactionAmount;
    }

    public String getTradeType() {
        return tradeType;
    }

    public void setTradeType(String tradeType) {
        this.tradeType = tradeType;
    }

    public String getSubjectCode() {
        return subjectCode;
    }

    public void setSubjectCode(String subjectCode) {
        this.subjectCode = subjectCode;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getTradeOrderUuid() {
        return tradeOrderUuid;
    }

    public void setTradeOrderUuid(String tradeOrderUuid) {
        this.tradeOrderUuid = tradeOrderUuid;
    }

    public String getRemark1() {
        return remark1;
    }

    public void setRemark1(String remark1) {
        this.remark1 = remark1;
    }

    public Byte getTransactionStatus() {
        return transactionStatus;
    }

    public void setTransactionStatus(Byte transactionStatus) {
        this.transactionStatus = transactionStatus;
    }

    public String getAuditOperator() {
        return auditOperator;
    }

    public void setAuditOperator(String auditOperator) {
        this.auditOperator = auditOperator;
    }

    public Date getAuditTime() {
        return auditTime;
    }

    public void setAuditTime(Date auditTime) {
        this.auditTime = auditTime;
    }

    public String getAuditOpinion() {
        return auditOpinion;
    }

    public void setAuditOpinion(String auditOpinion) {
        this.auditOpinion = auditOpinion;
    }

    public String getPayedOperator() {
        return payedOperator;
    }

    public void setPayedOperator(String payedOperator) {
        this.payedOperator = payedOperator;
    }

    public Date getPayedTime() {
        return payedTime;
    }

    public void setPayedTime(Date payedTime) {
        this.payedTime = payedTime;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}