package cn.zjhf.kingold.trade.entity.ReconVO;

import cn.zjhf.kingold.trade.service.impl.ReconciliationServiceImpl;
import cn.zjhf.kingold.trade.utils.AmountUtils;
import cn.zjhf.kingold.trade.utils.DataUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * 充值提现的对账信息
 * Created by zhangyijie on 2017/7/21.
 */
public class ReconRechargeInfo {
    private static final Logger logger = LoggerFactory.getLogger(ReconRechargeInfo.class);

    public static final int TYPE_RECON = 1;
    public static final int TYPE_RECHARGE = 2;

    private int reconRechargeType;

    private String orderCode;
    private String investorName;
    private String investorMobile;
    private Long accountNo = 0L;

    private String platformTime;
    private String baoFooTime;
    private double platformAmt;
    private double baoFooAmt;
    private double platformFeeAmt;
    private double baoFooFeeAmt;
    private int platformFeeTakenOn;
    private int baoFooFeeTakenOn;
    private int platformStatus;
    private int baoFooStatus;
    private String errMess;

    public static List<String> getRechargeHeader() {
        List<String> header = new ArrayList<String>();
        header.add("充值单号");
        header.add("用户姓名");
        header.add("手机号");
        header.add("宝付ID");

        header.add("金疙瘩充值时间");
        header.add("宝付充值时间");
        header.add("金疙瘩充值金额(元)");
        header.add("宝付充值金额(元)");
        header.add("金疙瘩手续费(元)");
        header.add("宝付手续费(元)");
        header.add("金疙瘩显示费用承担方");
        header.add("宝付显示费用承担方");
        header.add("金疙瘩状态");
        header.add("宝付状态");

        header.add("错误原因");
        return header;
    }

    public static List<String> getWithdrawalsHeader() {
        List<String> header = new ArrayList<String>();
        header.add("充值单号");
        header.add("用户姓名");
        header.add("手机号");
        header.add("宝付ID");

        header.add("金疙瘩提现时间");
        header.add("宝付提现时间");
        header.add("金疙瘩提现金额(元)");
        header.add("宝付提现金额(元)");
        header.add("金疙瘩手续费(元)");
        header.add("宝付手续费(元)");
        header.add("金疙瘩显示费用承担方");
        header.add("宝付显示费用承担方");
        header.add("金疙瘩状态");
        header.add("宝付状态");

        header.add("错误原因");

        return header;
    }

    public List<String> getContent() {
        List<String> curLine = new ArrayList<String>();
        curLine.add(orderCode);
        curLine.add(investorName);
        curLine.add(investorMobile);
        curLine.add(accountNo + "");

        curLine.add(platformTime);
        curLine.add(baoFooTime);

        curLine.add(AmountUtils.toString(platformAmt));
        curLine.add(AmountUtils.toString(baoFooAmt));
        curLine.add(AmountUtils.toString(platformFeeAmt));
        curLine.add(AmountUtils.toString(baoFooFeeAmt));

        curLine.add(getFeeTakenOn(platformFeeTakenOn));
        curLine.add(getFeeTakenOn(baoFooFeeTakenOn));
        curLine.add(getStatus(platformStatus));
        curLine.add(getBaofooStatus(baoFooStatus));

        curLine.add(errMess);
        return curLine;
    }

    public ReconRechargeInfo() {
    }

    //1 平台支付 2 个人支付
    private String getFeeTakenOn(int takenOnType) {
        if(1 == takenOnType) {
            return "平台";
        }else if(2 == takenOnType){
            return "个人";
        }

        return "其他";
    }

    //0:新建，1：成功，2：失败, 3:取消
    private String getStatus(int status) {
        if(0 == status) {
            return "处理中";
        }else if(1 == status){
            return "成功";
        }else if(2 == status){
            return "失败";
        }else if(3 == status){
            return "取消";
        }

        return "其他";
    }

    //0:处理中/初始化，1：成功，-1：失败, 5:转账处理中
    private String getBaofooStatus(int status) {
        if(1 == status) {
            return "成功";
        }else {
            return "不成功";
        }

//        if(TYPE_RECHARGE == reconRechargeType) {
//            if(0 == status) {
//                return "处理中";
//            }else if(1 == status) {
//                return "成功";
//            }
//        }
//
//        if(TYPE_RECON == reconRechargeType) {
//            if(0 == status) {
//                return "初始化";
//            }else if(1 == status) {
//                return "成功";
//            }else if(-1 == status) {
//                return "失败";
//            }else if(5 == status) {
//                return "转账处理中";
//            }
//        }
//
//        return "其他";
    }

    public Boolean failOrder(int baoFooStatus) {
        logger.info("platformStatus:" + platformStatus + ", " + "baoFooStatus:" + baoFooStatus);
        if((1 != baoFooStatus) && (1 != platformStatus)) {
            return true;
        }

        return false;
    }

    public Boolean checkBaoFooStatus(int baoFooStatus) {
        logger.info("platformStatus:" + platformStatus + ", " + "baoFooStatus:" + baoFooStatus);
        if(((1 == baoFooStatus) && (1 != platformStatus)) || ((1 != baoFooStatus) && (1 == platformStatus))) {
            return false;
        }else {
            return true;
        }

//        if(TYPE_RECHARGE == reconRechargeType) {
//            if((1 == baoFooStatus) && (1 == platformStatus)) {
//                return true;
//            }else if((0 == baoFooStatus) && (0 == platformStatus)) {
//                return true;
//            }
//
//            return false;
//        }
//
//        if(TYPE_RECON == reconRechargeType) {
//            if((0 == baoFooStatus) && (0 == platformStatus)) {
//                return true;
//            }
//
//            if((1 == baoFooStatus) && (1 == platformStatus)) {
//                return true;
//            }
//
//            if((-1 == baoFooStatus) && (2 == platformStatus)) {
//                return true;
//            }
//
//            return false;
//        }
//
//        return false;
    }

    public String getOrderCode() {
        return orderCode;
    }

    public void setOrderCode(String orderCode) {
        this.orderCode = orderCode;
    }

    public String getInvestorName() {
        return investorName;
    }

    public void setInvestorName(String investorName) {
        this.investorName = investorName;
    }

    public String getInvestorMobile() {
        return investorMobile;
    }

    public void setInvestorMobile(String investorMobile) {
        this.investorMobile = investorMobile;
    }

    public Long getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(Long accountNo) {
        this.accountNo = accountNo;
    }

    public String getPlatformTime() {
        return platformTime;
    }

    public void setPlatformTime(String platformTime) {
        this.platformTime = platformTime;
    }

    public String getBaoFooTime() {
        return baoFooTime;
    }

    public void setBaoFooTime(String baoFooTime) {
        this.baoFooTime = baoFooTime;
    }

    public Double getPlatformAmt() {
        return platformAmt;
    }

    public void setPlatformAmt(Double platformAmt) {
        this.platformAmt = platformAmt;
    }

    public Double getBaoFooAmt() {
        return baoFooAmt;
    }

    public void setBaoFooAmt(Double baoFooAmt) {
        this.baoFooAmt = baoFooAmt;
    }

    public Double getPlatformFeeAmt() {
        return platformFeeAmt;
    }

    public void setPlatformFeeAmt(Double platformFeeAmt) {
        this.platformFeeAmt = platformFeeAmt;
    }

    public Double getBaoFooFeeAmt() {
        return baoFooFeeAmt;
    }

    public void setBaoFooFeeAmt(Double baoFooFeeAmt) {
        this.baoFooFeeAmt = baoFooFeeAmt;
    }

    public int getPlatformFeeTakenOn() {
        return platformFeeTakenOn;
    }

    public void setPlatformFeeTakenOn(int platformFeeTakenOn) {
        this.platformFeeTakenOn = platformFeeTakenOn;
    }

    public int getBaoFooFeeTakenOn() {
        return baoFooFeeTakenOn;
    }

    public void setBaoFooFeeTakenOn(int baoFooFeeTakenOn) {
        this.baoFooFeeTakenOn = baoFooFeeTakenOn;
    }

    public int getPlatformStatus() {
        return platformStatus;
    }

    public void setPlatformStatus(int platformStatus) {
        this.platformStatus = platformStatus;
    }

    public int getBaoFooStatus() {
        return baoFooStatus;
    }

    public void setBaoFooStatus(int baoFooStatus) {
        this.baoFooStatus = baoFooStatus;
    }

    public String getErrMess() {
        return errMess;
    }

    public void setErrMess(String errMess) {
        if(DataUtils.isEmpty(this.errMess)) {
            this.errMess = errMess;
        }else {
            this.errMess += "|" + errMess;
        }
    }

    public int getReconRechargeType() {
        return reconRechargeType;
    }

    public void setReconRechargeType(int reconRechargeType) {
        this.reconRechargeType = reconRechargeType;
    }
}
