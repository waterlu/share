package cn.zjhf.kingold.trade.exception;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.constant.TradeStatusMsg;

/**
 * 创建订单失败通用异常
 *
 * @author lutiehua
 * @date 2018/3/9
 */
public class CreateOrderException extends BusinessException {

    public CreateOrderException() {
        super(TradeStatusMsg.CREATE_ORDER_FAILED, TradeStatusMsg.CREATE_ORDER_FAILED_TXT);
    }

}
