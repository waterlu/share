package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.constant.BizDefine;
import cn.zjhf.kingold.trade.constant.TradeStatus;
import cn.zjhf.kingold.trade.dto.TradeOrderDto;
import cn.zjhf.kingold.trade.entity.TradePaymentSummary;
import cn.zjhf.kingold.trade.persistence.dao.TradeOrderMapper;
import cn.zjhf.kingold.trade.persistence.dao.TradePaymentSummaryMapper;
import cn.zjhf.kingold.trade.persistence.dao.TradeRechargeMapper;
import cn.zjhf.kingold.trade.service.ITradeOrderService;
import cn.zjhf.kingold.trade.utils.DataUtils;
import cn.zjhf.kingold.trade.utils.WhereCondition;
import cn.zjhf.kingold.trade.vo.TradeOrderVO;
import com.google.common.collect.ImmutableList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * Created by wangxun on 2016/11/04.
 * Copyright by zjinv
 */
@Service
public class TradeOrderServiceImpl implements ITradeOrderService {
    private static final Logger LOGGER = LoggerFactory.getLogger(TradeOrderServiceImpl.class);

    @Autowired
    private TradeOrderMapper tradeOrderMapper;

    @Autowired
    private TradePaymentSummaryMapper tradePaymentSummaryMapper;

    @Autowired
    private TradeRechargeMapper tradeRechargeMapper;

    @Value("${system.run.model}")
    public String runModel;

    @Value("${app.admin.verify.code}")
    public String adminVerifyCode;


    /**
     * 获取订单列表
     *
     * @param userMap 参数必填：todo： 参数
     * @return
     * @throws BusinessException
     */
    @Override
    public List<Map> getList(Map userMap) throws BusinessException {

        List<Map> userList = tradeOrderMapper.getList(userMap);

        return userList;
    }

    /**
     * 订单查询（现仅用于订单列表导出）
     * @param dto
     * @return
     * @throws BusinessException
     */
    @Override
    public List<TradeOrderVO> getOrderList(TradeOrderDto dto ) throws BusinessException{
        WhereCondition where = new WhereCondition();
        where.setCondiEx(" o.order_bill_code = t.trade_order_bill_code AND o.user_uuid = i.user_uuid AND t.account_type = 21 AND o.delete_flag = 0 ");
        if (DataUtils.isNotEmpty(dto.getOrderBillCode())) {
            where.setCondiEx(" and (o.order_bill_code = '" + dto.getOrderBillCode() + "' or t.trade_order_bill_code_extend = '" + dto.getOrderBillCode() + "' ) ");
        }
        where.setLike("o.product_abbr_name", dto.getProductAbbrName());
        where.setCondi("o.user_phone", dto.getUserPhone(), true);
        if(dto.getOrderStatus() == null){
            List<Integer> orderStatus = ImmutableList.of(BizDefine.ORDER_STATUS_APPLY,BizDefine.ORDER_STATUS_CONFIRM,BizDefine.
                    ORDER_STATUS_PRODUCT_INTEREST,BizDefine.ORDER_STATUS_PRODUCT_END,BizDefine.ORDER_STATUS_CLEAR,BizDefine.ORDER_STATUS_CANCEL);
            where.setInInt("o.order_status",orderStatus);
        }else{
            where.setCondi("o.order_status", dto.getOrderStatus(), true);
        }
        if(DataUtils.isNotEmpty(dto.getTransactionTimeFrom())){
            where.setCondiEx(" and  o.create_time >= '"+dto.getTransactionTimeFrom()+"'");
        }
        if(DataUtils.isNotEmpty(dto.getTransactionTimeTo())){
            where.setCondiEx(" and  o.create_time <= '"+dto.getTransactionTimeTo()+"'");
        }
        if(DataUtils.isNotEmpty(dto.getPayedTimeFrom())){
            where.setCondiEx(" and  o.payed_time >= '"+dto.getPayedTimeFrom()+"'");
        }
        if(DataUtils.isNotEmpty(dto.getPayedTimeTo())){
            where.setCondiEx(" and  o.payed_time <= '"+dto.getPayedTimeTo()+"'");
        }
        where.setPage(dto.getPageNo(),dto.getPageSize(),"o.create_time");
        return tradeOrderMapper.getOrderList(where);
    }

    /**
     * 获取订单总数
     *
     * @param userMap 参数必填：todo： 参数
     * @return
     * @throws BusinessException
     */
    @Override
    public Integer getCount(Map userMap) throws BusinessException {
        Integer result = tradeOrderMapper.getCount(userMap);
        return result;
    }

    /**
     * 根据交易编号获取定期交易单
     *
     * @param orderBillCode 交易编号
     * @return
     * @throws BusinessException
     */
    @Override
    public Map getTradeOrder(String orderBillCode) throws BusinessException {
        return tradeOrderMapper.get(orderBillCode);
    }

    /**
     * 查询某个人的交易订单金额总和（订单类型为：2已付款，3产品成立，4已到期）
     * @param userUuid
     * @return
     * @throws BusinessException
     */
    @Override
    public BigDecimal querySumAmountByUser(String userUuid) throws BusinessException {
        return tradeOrderMapper.querySumAmountByUser(userUuid);
    }

    /**
     * 根据产品uuid获取产品还款信息
     *
     * @param productUuid
     * @return
     * @throws BusinessException
     */
    @Override
    public TradePaymentSummary getTradePaymentSummary(String productUuid) throws BusinessException {
        WhereCondition condition = new WhereCondition();
        condition.setCondi("product_uuid", productUuid);
        List<TradePaymentSummary> items = tradePaymentSummaryMapper.lstByCondition(condition);
        return items.size() > 0 ? items.get(0) : null;
    }

}