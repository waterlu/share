package cn.zjhf.kingold.trade.entity;

import cn.zjhf.kingold.trade.utils.DataUtils;
import cn.zjhf.kingold.trade.utils.Tuple.TwoTuple;
import com.itextpdf.text.Image;

/**
 * Created by zhangyijie on 2017/7/17.
 */
public class ContractFillInfoVO {
    /**
     * 模板文件路径
     */
    private String templateFilePath;

    /**
     * 合同文件路径
     */
    private String contractFilePath;

    /**
     * 合同文件名称
     */
    private String contractFileName;

    /**
     * 合同编号
     */
    private String contractNo;

    /**
     * 产品说明书编号
     */
    private String productManualNo;

    /**
     * 投资者姓名
     */
    private String investorName;

    /**
     * 投资者身份证号
     */
    private String investorIDNumber;

    /**
     * 发行人名称
     */
    private String issuerName;

    /**
     * 发行人住所
     */
    private String issuerResidence;

    /**
     * 发行人法人代表名称
     */
    private String legalPersonName;

    /**
     * 认购金额
     */
    private Double subAmt;

    /**
     * 发行人图章图像：first法人公章, second法定代表人公章
     */
    private TwoTuple<Image, Image> sealImages;

    public String getContractNo() {
        return contractNo;
    }

    public void setContractNo(String contractNo) {
        this.contractNo = contractNo;
    }

    public String getProductManualNo() {
        return productManualNo;
    }

    public void setProductManualNo(String productManualNo) {
        this.productManualNo = productManualNo;
    }

    public String getInvestorName() {
        return investorName;
    }

    public void setInvestorName(String investorName) {
        this.investorName = investorName;
    }

    public String getInvestorIDNumber() {
        return investorIDNumber;
    }

    public void setInvestorIDNumber(String investorIDNumber) {
        this.investorIDNumber = investorIDNumber;
    }

    public Double getSubAmt() {
        return subAmt;
    }

    public void setSubAmt(Double subAmt) {
        this.subAmt = subAmt;
    }

    public String getTemplateFilePath() {
        return templateFilePath;
    }

    public void setTemplateFilePath(String templateFilePath) {
        this.templateFilePath = templateFilePath;
    }

    public String getContractFilePath() {
        return contractFilePath;
    }

    public void setContractFilePath(String contractFilePath) {
        this.contractFilePath = contractFilePath;
    }

    public String getContractFileName() {
        return contractFileName;
    }

    public void setContractFileName(String contractFileName) {
        this.contractFileName = contractFileName;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("templateFilePath:" + DataUtils.toString(templateFilePath) + ", ");
        sb.append("contractFilePath:" + DataUtils.toString(contractFilePath) + ", ");
        sb.append("contractFileName:" + DataUtils.toString(contractFileName) + ", ");
        sb.append("contractNo:" + DataUtils.toString(contractNo) + ", ");
        sb.append("productManualNo:" + DataUtils.toString(productManualNo) + ", ");
        sb.append("investorName:" + DataUtils.toString(investorName) + ", ");
        sb.append("investorIDNumber:" + DataUtils.toString(investorIDNumber) + ", ");
        sb.append("issuerName:" + DataUtils.toString(issuerName) + ", ");
        sb.append("issuerResidence:" + DataUtils.toString(issuerResidence) + ", ");
        sb.append("legalPersonName:" + DataUtils.toString(legalPersonName) + ", ");
        sb.append("subAmt:" + DataUtils.toString(subAmt));
        return sb.toString();
    }

    public String getIssuerName() {
        return issuerName;
    }

    public void setIssuerName(String issuerName) {
        this.issuerName = issuerName;
    }

    public String getLegalPersonName() {
        return legalPersonName;
    }

    public void setLegalPersonName(String legalPersonName) {
        this.legalPersonName = legalPersonName;
    }

    public String getIssuerResidence() {
        return issuerResidence;
    }

    public void setIssuerResidence(String issuerResidence) {
        this.issuerResidence = issuerResidence;
    }

    public TwoTuple<Image, Image> getSealImages() {
        return sealImages;
    }

    public void setSealImages(TwoTuple<Image, Image> sealImages) {
        this.sealImages = sealImages;
    }
}
