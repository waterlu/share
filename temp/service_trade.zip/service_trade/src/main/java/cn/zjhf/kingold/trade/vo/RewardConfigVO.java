package cn.zjhf.kingold.trade.vo;

/**
 * @author lutiehua
 * @date 2018/3/21
 */
public class RewardConfigVO {

    /**
     * 激活时间
     */
    private String activeTime;

    /**
     * 时间长度
     */
    private Long period;

    /**
     * 时间单位
     */
    private String periodUnit;

    public Long getExpiredActiveTime() {
        return expiredActiveTime;
    }

    public void setExpiredActiveTime(Long expiredActiveTime) {
        this.expiredActiveTime = expiredActiveTime;
    }

    public Long getExpiredPeriod() {
        return expiredPeriod;
    }

    public void setExpiredPeriod(Long expiredPeriod) {
        this.expiredPeriod = expiredPeriod;
    }

    private Long expiredActiveTime;

    private Long expiredPeriod;

    public String getActiveTime() {
        return activeTime;
    }

    public void setActiveTime(String activeTime) {
        this.activeTime = activeTime;
    }

    public Long getPeriod() {
        return period;
    }

    public void setPeriod(Long period) {
        this.period = period;
    }

    public String getPeriodUnit() {
        return periodUnit;
    }

    public void setPeriodUnit(String periodUnit) {
        this.periodUnit = periodUnit;
    }
}