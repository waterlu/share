package cn.zjhf.kingold.trade.utils.File;

import cn.zjhf.kingold.trade.utils.DataUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Created by zhangyijie on 2017/7/17.
 */
public class FileUtils {
    protected static final Logger logger = LoggerFactory.getLogger(FileUtils.class);

    public static boolean isExist(String srcFilePath) {
        File file = new File(srcFilePath);
        return file.exists();
    }

    public static String andExp(String srcFilePath, String... sn) {
        File file = new File(srcFilePath);
        String[] fileNames = file.getName().split("\\.");

        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < (fileNames.length - 1); i++) {
            sb.append(fileNames[i]);
        }

        for(String str : sn) {
            sb.append("_").append(str);
        }

        sb.append(".").append(fileNames[fileNames.length - 1]);

        return sb.toString();
    }

    public static String getFileName(String filePath) {
        File file = new File(filePath);
        return file.getName();
    }

    public static boolean makeDirs(String folderName) {
        if (DataUtils.isEmpty(folderName)) {
            return false;
        }

        File folder = new File(folderName);
        return (folder.exists() && folder.isDirectory()) ? true : folder.mkdirs();
    }

    public static String getMd5ByFile(InputStream input) {
        String value = "";

        byte[] b = new byte[1024*10];
        int count = 0;
        int curCount = 0;
        try {
            logger.info("InputStream Available: {}", input.available());
            MessageDigest md5 = MessageDigest.getInstance("MD5");

            if(input.markSupported()) {
                input.reset();
            }

            while((curCount = input.read(b)) > 0) {
                md5.update(b, 0, curCount);
                count += curCount;
            }
            input.close();
            BigInteger bi = new BigInteger(1, md5.digest());

            value = bi.toString(16);
        } catch (IOException e) {
            logger.error("IOException: ", e);
        } catch (NoSuchAlgorithmException e) {
            logger.error("NoSuchAlgorithmException: ", e);
        }

        logger.info("InputStream Len: {}", count);
        if(value.length() < 32) {
            value = DataUtils.padStr(32-value.length(),'0') + value;
        }
        return value;
    }

    public static String getMd5ByFile(String fileName) {
        File file = new File(fileName);
        String value = null;

        FileInputStream in = null;
        try {
            in = new FileInputStream(file);
            MappedByteBuffer byteBuffer = in.getChannel().map(FileChannel.MapMode.READ_ONLY, 0, file.length());
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            md5.update(byteBuffer);
            BigInteger bi = new BigInteger(1, md5.digest());
            value = bi.toString(16);

            if(value.length() < 32) {
                value = DataUtils.padStr(32-value.length(),'0') + value;
            }
        } catch (Exception e) {
            logger.error("异常，", e);
        } finally {
            if(null != in) {
                try {
                    in.close();
                } catch (IOException e) {
                    logger.error("IOException，", e);
                }
            }
        }
        return value;
    }

    public static void delete(String filename) {
        File file = new File(filename);
        // 路径为文件且不为空则进行删除
        if (file.isFile() && file.exists()) {
            file.delete();
        }
    }
}
