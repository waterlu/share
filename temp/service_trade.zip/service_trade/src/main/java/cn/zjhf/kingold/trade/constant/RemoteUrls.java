//package cn.zjhf.kingold.trade.constant;
//
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Component;
//import org.springframework.stereotype.Repository;
//
//import javax.annotation.Resource;
//
///**
// * Created by DELL on 2017/5/17.
// */
//@Component
//public class RemoteUrls {
//
//    @Value("${url.user.info}")
//    public String userInfoUrl;
//
//    /**
//     * 根据userUuid 获取用户信息的url
//     *
//     * @param userUuid
//     * @return
//     */
//    public String getUserUrl(String userUuid) {
//        return userInfoUrl + "/" + userUuid;
//    }
//
//    /**
//     * 获取用户CheckPayPassword的url
//     *
//     * @return
//     */
//    public String getCheckPayPasswordUrl() {
//
//        return userInfoUrl + "/checkPayPassword";
//    }
//
//    /**
//     * 获取获取用户邀请人信息的url
//     *
//     * @return
//     */
//    public String getInvestorRelationUrl(String userUuid) {
//
//        return userInfoUrl + "/investorRelation/" + userUuid;
//    }
//
//
//}
