package cn.zjhf.kingold.trade.entity.ReconVO;

import cn.zjhf.kingold.trade.utils.AmountUtils;
import cn.zjhf.kingold.trade.utils.DataUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangyijie on 2017/7/21.
 */
public class ReconTradeInfo extends ReconBase {
    public static List<String> getTradeHeader() {
        List<String> header = new ArrayList<String>();
        header.add("投资订单号");
        header.add("用户姓名");
        header.add("手机号");
        header.add("宝付ID");

        //产品名称	投资期限	预期收益	金疙瘩投资时间	宝付投资时间	金疙瘩投资金额	宝付投资金额	金疙瘩状态	宝付状态	错误原因
        header.add("产品名称");
        header.add("投资期限(天)");
        header.add("预期收益(元)");
        header.add("金疙瘩投资时间");
        header.add("宝付投资时间");
        header.add("金疙瘩投资金额(元)");
        header.add("宝付投资金额(元)");

        header.add("金疙瘩状态");
        header.add("宝付状态");
        header.add("错误原因");
        return header;
    }

    public List<String> getTradeContent() {
        List<String> curLine = new ArrayList<String>();
        curLine.add(orderCode);
        curLine.add(investorName);
        curLine.add(investorMobile);
        curLine.add(accountNo + "");

        curLine.add(productAbbrName);
        curLine.add(productTerm + "");
        curLine.add(AmountUtils.toString(profitAmt));

        curLine.add(platformTime);
        curLine.add(baoFooTime);
        curLine.add(AmountUtils.toString(platformAmt));
        curLine.add(AmountUtils.toString(baoFooAmt));

        curLine.add(getStatus(platformStatus));
        curLine.add(getBaofooStatus(baoFooStatus));
        curLine.add(errMess);
        return curLine;
    }

    public static List<String> getLoanHeader() {
        List<String> header = new ArrayList<String>();
        header.add("放款订单号");

        header.add("产品名称");
        header.add("投资期限(天)");
        header.add("预期收益(元)");

        header.add("金疙瘩放款时间");
        header.add("宝付放款时间");
        header.add("金疙瘩放款金额(元)");
        header.add("宝付放款金额(元)");
        header.add("金疙瘩显示手续费(元)");
        header.add("宝付显示手续费(元)");

        header.add("金疙瘩状态");
        header.add("宝付状态");
        header.add("错误原因");
        return header;
    }

    public List<String> getLoanContent() {
        List<String> curLine = new ArrayList<String>();
        curLine.add(orderCode);

        curLine.add(productAbbrName);
        curLine.add(productTerm + "");
        curLine.add(AmountUtils.toString(profitAmt));

        curLine.add(platformTime);
        curLine.add(baoFooTime);
        curLine.add(AmountUtils.toString(platformAmt));
        curLine.add(AmountUtils.toString(baoFooAmt));
        curLine.add(AmountUtils.toString(platformFeeAmt));
        curLine.add(AmountUtils.toString(baoFooFeeAmt));

        curLine.add(getStatus(platformStatus));
        curLine.add(getBaofooStatus(baoFooStatus));
        curLine.add(errMess);
        return curLine;
    }

    public static List<String> getRepaymentHeader() {
        List<String> header = new ArrayList<String>();
        header.add("放款订单号");

        header.add("产品名称");
        header.add("投资期限(天)");
        header.add("预期收益(元)");

        header.add("金疙瘩还款时间");
        header.add("宝付还款时间");
        header.add("金疙瘩还款金额(元)");
        header.add("宝付还款金额(元)");

        header.add("金疙瘩状态");
        header.add("宝付状态");
        header.add("错误原因");
        return header;
    }

    public List<String> getRepaymentContent() {
        List<String> curLine = new ArrayList<String>();
        curLine.add(orderCode);

        curLine.add(productAbbrName);
        curLine.add(productTerm + "");
        curLine.add(AmountUtils.toString(profitAmt));

        curLine.add(platformTime);
        curLine.add(baoFooTime);
        curLine.add(AmountUtils.toString(platformAmt));
        curLine.add(AmountUtils.toString(baoFooAmt));

        curLine.add(getStatus(platformStatus));
        curLine.add(getBaofooStatus(baoFooStatus));
        curLine.add(errMess);
        return curLine;
    }

    public String getOrderCode() {
        return orderCode;
    }

    public void setOrderCode(String orderCode) {
        this.orderCode = orderCode;
    }

    public String getInvestorName() {
        return investorName;
    }

    public void setInvestorName(String investorName) {
        this.investorName = investorName;
    }

    public String getInvestorMobile() {
        return investorMobile;
    }

    public void setInvestorMobile(String investorMobile) {
        this.investorMobile = investorMobile;
    }

    public Long getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(Long accountNo) {
        this.accountNo = accountNo;
    }

    public String getProductAbbrName() {
        return productAbbrName;
    }

    public void setProductAbbrName(String productAbbrName) {
        this.productAbbrName = productAbbrName;
    }

    public int getProductTerm() {
        return productTerm;
    }

    public void setProductTerm(int productTerm) {
        this.productTerm = productTerm;
    }

    public double getProfitAmt() {
        return profitAmt;
    }

    public void setProfitAmt(double profitAmt) {
        this.profitAmt = profitAmt;
    }

    public String getPlatformTime() {
        return platformTime;
    }

    public void setPlatformTime(String platformTime) {
        this.platformTime = platformTime;
    }

    public String getBaoFooTime() {
        return baoFooTime;
    }

    public void setBaoFooTime(String baoFooTime) {
        this.baoFooTime = baoFooTime;
    }

    public double getPlatformAmt() {
        return platformAmt;
    }

    public void setPlatformAmt(double platformAmt) {
        this.platformAmt = platformAmt;
    }

    public double getBaoFooAmt() {
        return baoFooAmt;
    }

    public void setBaoFooAmt(double baoFooAmt) {
        this.baoFooAmt = baoFooAmt;
    }

    public double getPlatformFeeAmt() {
        return platformFeeAmt;
    }

    public void setPlatformFeeAmt(double platformFeeAmt) {
        this.platformFeeAmt = platformFeeAmt;
    }

    public double getBaoFooFeeAmt() {
        return baoFooFeeAmt;
    }

    public void setBaoFooFeeAmt(double baoFooFeeAmt) {
        this.baoFooFeeAmt = baoFooFeeAmt;
    }

    public int getPlatformStatus() {
        return platformStatus;
    }

    public void setPlatformStatus(int platformStatus) {
        this.platformStatus = platformStatus;
    }

    public int getBaoFooStatus() {
        return baoFooStatus;
    }

    public void setBaoFooStatus(int baoFooStatus) {
        this.baoFooStatus = baoFooStatus;
    }

    public String getErrMess() {
        return errMess;
    }

    public void setErrMess(String errMess) {
        if(DataUtils.isEmpty(this.errMess)) {
            this.errMess = errMess;
        }else {
            this.errMess += "|" + errMess;
        }
    }
}
