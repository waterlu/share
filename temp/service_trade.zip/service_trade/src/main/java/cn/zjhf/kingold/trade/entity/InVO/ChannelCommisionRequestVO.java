package cn.zjhf.kingold.trade.entity.InVO;

import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModelProperty;

/**
 * Created by zhangyijie on 2017/10/18.
 */
public class ChannelCommisionRequestVO extends InVOBase {
    @ApiModelProperty(required = true, value = "请求周期，格式: YYYY.MM")
    private String requestCycle;

    public String getRequestCycle() {
        return requestCycle;
    }

    public void setRequestCycle(String requestCycle) {
        this.requestCycle = requestCycle;
    }

    @Override
    public String toString() {
        return "ChannelCommisionRequestVO{" +
                "traceID=" + DataUtils.toString(getTraceID()) + ", " +
                ", requestCycle='" + requestCycle + '\'' +
                '}';
    }
}
