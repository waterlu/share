package cn.zjhf.kingold.trade.entity.InVO;

import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import java.util.Date;

/**
 * Created by zhangyijie on 2017/6/5.
 */
@ApiModel(value = "LstProductRewardSummaryItemsVO", description = "报表_产品奖励记录_(维度:产品，列表) 查询入参")
public class LstProductRewardSummaryItemsVO extends InVOBase {
    @ApiModelProperty(required = true, value = "traceID")
    @NotEmpty
    private String traceID;

    @ApiModelProperty(required = true, value = "产品Uuid")
    private String productUuid;

    @ApiModelProperty(required = true, value = "产品编号")
    private String productCode;

    @ApiModelProperty(required = true, value = "产品类型")
    private String productType;

    @ApiModelProperty(required = true, value = "产品名称")
    @NotEmpty
    private String productAbbrName;

    @ApiModelProperty(required = true, value = "收入报税处理状态：-1审批失败；1待审核；2审核通过; 3已结算")
    private int incomeTaxClearStatus;

    @ApiModelProperty(required = true, value = "管理费处理状态：-1审批失败；1待审核；2审核通过; 3已结算")
    private int exchangeManagefeeClearStatus;

    @ApiModelProperty(required = true, value = "产品起息日期_起始日")
    private Date productInterestDateFrom;

    @ApiModelProperty(required = true, value = "产品起息日期_截止日")
    private Date productInterestDateTo;

    @ApiModelProperty(required = true, value = "产品成立日期_截止日")
    private Date productEstablishmentDateFrom;

    @ApiModelProperty(required = true, value = "产品成立日期_截止日")
    private Date productEstablishmentDateTo;

    @ApiModelProperty(required = true, value = "起始序号")
    private int beginSN;

    @ApiModelProperty(required = true, value = "结束序号")
    private int endSN;

    @ApiModelProperty(required = true, value = "产品期限")
    private int productPeriod;

    @ApiModelProperty(required = true, value = "排序字段，暂不使用")
    private String orderByFields;

    @ApiModelProperty(required = true, value = "募集方名称")
    private String productIssuerName;

    @Override
    public String getTraceID() {
        return traceID;
    }

    @Override
    public void setTraceID(String traceID) {
        this.traceID = traceID;
    }

    public String getProductAbbrName() {
        return productAbbrName;
    }

    public void setProductAbbrName(String productAbbrName) {
        this.productAbbrName = productAbbrName;
    }

    public int getIncomeTaxClearStatus() {
        return incomeTaxClearStatus;
    }

    public void setIncomeTaxClearStatus(int incomeTaxClearStatus) {
        this.incomeTaxClearStatus = incomeTaxClearStatus;
    }

    public int getExchangeManagefeeClearStatus() {
        return exchangeManagefeeClearStatus;
    }

    public void setExchangeManagefeeClearStatus(int exchangeManagefeeClearStatus) {
        this.exchangeManagefeeClearStatus = exchangeManagefeeClearStatus;
    }

    public Date getProductInterestDateFrom() {
        return productInterestDateFrom;
    }

    public void setProductInterestDateFrom(Date productInterestDateFrom) {
        this.productInterestDateFrom = productInterestDateFrom;
    }

    public Date getProductInterestDateTo() {
        return convertEndDate(productInterestDateTo);
    }

    public void setProductInterestDateTo(Date productInterestDateTo) {
        this.productInterestDateTo = productInterestDateTo;
    }

    public int getBeginSN() {
        return beginSN;
    }

    public void setBeginSN(int beginSN) {
        this.beginSN = beginSN;
    }

    public int getEndSN() {
        return endSN;
    }

    public void setEndSN(int endSN) {
        this.endSN = endSN;
    }

    public String getOrderByFields() {
        return orderByFields;
    }

    public void setOrderByFields(String orderByFields) {
        this.orderByFields = orderByFields;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public Date getProductEstablishmentDateFrom() {
        return productEstablishmentDateFrom;
    }

    public void setProductEstablishmentDateFrom(Date productEstablishmentDateFrom) {
        this.productEstablishmentDateFrom = productEstablishmentDateFrom;
    }

    public Date getProductEstablishmentDateTo() {
        return productEstablishmentDateTo;
    }

    public void setProductEstablishmentDateTo(Date productEstablishmentDateTo) {
        this.productEstablishmentDateTo = productEstablishmentDateTo;
    }

    public int getProductPeriod() {
        return productPeriod;
    }

    public void setProductPeriod(int productPeriod) {
        this.productPeriod = productPeriod;
    }

    public String getProductIssuerName() {
        return productIssuerName;
    }

    public void setProductIssuerName(String productIssuerName) {
        this.productIssuerName = productIssuerName;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(traceID) + ", ");
        sb.append("productUuid:" + DataUtils.toString(productUuid) + ", ");
        sb.append("productUuid:" + DataUtils.toString(productCode) + ", ");
        sb.append("productAbbrName:" + DataUtils.toString(productAbbrName) + ", ");
        sb.append("incomeTaxClearStatus:" + DataUtils.toString(incomeTaxClearStatus) + ", ");
        sb.append("exchangeManagefeeClearStatus:" + DataUtils.toString(exchangeManagefeeClearStatus) + ", ");
        sb.append("productInterestDateFrom:" + DataUtils.toString(productInterestDateFrom) + ", ");
        sb.append("productInterestDateTo:" + DataUtils.toString(productInterestDateTo) + ", ");
        sb.append("beginSN:" + DataUtils.toString(beginSN) + ", ");
        sb.append("endSN:" + DataUtils.toString(endSN) + ", ");
        sb.append("orderByFields:" + DataUtils.toString(orderByFields));
        sb.append("productType:" + DataUtils.toString(productType));
        sb.append("productEstablishmentDateFrom:" + DataUtils.toString(productEstablishmentDateFrom));
        sb.append("productEstablishmentDateTo:" + DataUtils.toString(productEstablishmentDateTo));
        sb.append("productPeriod:" + DataUtils.toString(productPeriod));
        sb.append("productIssuerName:" + DataUtils.toString(productIssuerName));
        return sb.toString();
    }
}
