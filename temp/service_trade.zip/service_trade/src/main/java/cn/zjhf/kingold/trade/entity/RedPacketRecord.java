package cn.zjhf.kingold.trade.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author 
 */
public class RedPacketRecord implements Serializable {
    /**
     * 序号
     */
    private Long id;

    /**
     * 审核编号/审核批次号
     */
    private Long auditId;

    /**
     * 用户UUID
     */
    private String userUuid;

    /**
     * 用户名/用户手机号
     */
    private String phoneNumber;

    /**
     * 用户姓名
     */
    private String phoneName;

    /**
     * 红包金额/发放金额
     */
    private BigDecimal redPacketAmount;

    /**
     * 领取状态: 1已发放(待领取)；2已领取
     */
    private Byte receiveStatus;

    /**
     * 领取的结果消息，主要存放领取失败的消息
     */
    private String receiveMess;

    /**
     * 领取时间
     */
    private Date receiveTime;

    /**
     * 红包备注
     */
    private String remarks;

    /**
     * 创建时间/发放时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 删除标记 0未删除，1已删除
     */
    private Byte deleteFlag;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getAuditId() {
        return auditId;
    }

    public void setAuditId(Long auditId) {
        this.auditId = auditId;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getPhoneName() {
        return phoneName;
    }

    public void setPhoneName(String phoneName) {
        this.phoneName = phoneName;
    }

    public BigDecimal getRedPacketAmount() {
        return redPacketAmount;
    }

    public void setRedPacketAmount(BigDecimal redPacketAmount) {
        this.redPacketAmount = redPacketAmount;
    }

    public Byte getReceiveStatus() {
        return receiveStatus;
    }

    public void setReceiveStatus(Byte receiveStatus) {
        this.receiveStatus = receiveStatus;
    }

    public Date getReceiveTime() {
        return receiveTime;
    }

    public void setReceiveTime(Date receiveTime) {
        this.receiveTime = receiveTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public String getReceiveMess() {
        return receiveMess;
    }

    public void setReceiveMess(String receiveMess) {
        this.receiveMess = receiveMess;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}