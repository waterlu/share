package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.constant.*;
import cn.zjhf.kingold.trade.entity.*;
import cn.zjhf.kingold.trade.entity.InVO.LstProductEstablishLoanItemsVO;
import cn.zjhf.kingold.trade.entity.InVO.LstProductEstablishLoanVO;
import cn.zjhf.kingold.trade.entity.OutVO.*;
import cn.zjhf.kingold.trade.entity.OutVO.TradeOrderVO;
import cn.zjhf.kingold.trade.persistence.dao.ExchangeManagerfeeConfigMapper;
import cn.zjhf.kingold.trade.persistence.dao.PlatformCommissionConfigMapper;
import cn.zjhf.kingold.trade.persistence.dao.ProductRewardSummaryMapper;
import cn.zjhf.kingold.trade.persistence.dao.RewardMapper;
import cn.zjhf.kingold.trade.persistence.mq.message.ProductMessage;
import cn.zjhf.kingold.trade.persistence.mq.producer.ProductEstablishProducer;
import cn.zjhf.kingold.trade.persistence.mq.producer.ProductPFEstablishProducer;
import cn.zjhf.kingold.trade.service.IProductEstablishService;
import cn.zjhf.kingold.trade.service.IRewardService;
import cn.zjhf.kingold.trade.utils.*;
import cn.zjhf.kingold.trade.vo.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;

import static cn.zjhf.kingold.trade.constant.TradeType.TRADE_ACCOUNT_AMOUNT;
import static cn.zjhf.kingold.trade.constant.TradeType.TRADE_MARKETING_AMOUNT;

/**
 * Created by zhangyijie on 2017/5/19.
 */
@Service
public class ProductEstablishServiceImpl extends ProductClearBase implements IProductEstablishService {
    protected static final Logger logger = LoggerFactory.getLogger(ProductEstablishServiceImpl.class);

    @Autowired
    protected PlatformCommissionConfigMapper platformCommissionConfigMapper;

    @Autowired
    ExchangeManagerfeeConfigMapper exchangeManagerfeeConfigMapper;

    @Autowired
    ProductRewardSummaryMapper productRewardSummaryMapper;

    @Autowired
    RewardMapper rewardMapper;

    @Autowired
    IRewardService rewardService;

    @Autowired
    ProductPFEstablishProducer productPFEstablishProducer;

    @Autowired
    ChannelCommisionServiceImpl channelCommisionServiceImpl;

    @Autowired
    private ProductEstablishProducer productEstablishProducer;

    private TradeInvestSummary lstTradeInvestSummaryByProduct(String productUuid) {
        WhereCondition condition = new WhereCondition();
        condition.setCondi("product_uuid", productUuid);
        condition.noDelete();
        condition.setOrderByDesc("trade_invest_summary_uuid");
        List<TradeInvestSummary> items = tradeInvestSummaryMapper.lstByCondition(condition);
        return items.size() > 0 ? items.get(0) : null;
    }

    //增补放款(募集汇总)的其他信息
    private TradeInvestSummaryExVO getTradeInvestSummaryExVO(TradeInvestSummary tradeInvestSummary) throws BusinessException {
        TradeInvestSummaryExVO tradeInvestSummaryExVO = new TradeInvestSummaryExVO(tradeInvestSummary);

        //完善其他数据
        ProductFixedIncome productInfo = getFixedIncomeProductById(tradeInvestSummary.getProductUuid());
        tradeInvestSummaryExVO.setProductPeriod(productInfo.getProductPeriod());
        tradeInvestSummaryExVO.setProductScale(productInfo.getProductScale().doubleValue());

        return tradeInvestSummaryExVO;
    }

    /**
     * 获取平台服务费
     * @param productUuid
     * @param productPeriod
     * @param rateFormulaParam
     * @param raiseAmount
     * @return
     */
    @Override
    public double getPlatformServiceFee(String productUuid, int productPeriod, int rateFormulaParam, double raiseAmount) {
        rateFormulaParam = (rateFormulaParam > 0) ? rateFormulaParam: RATEFORMULAPARAM;
        WhereCondition where = new WhereCondition();
        where.setCondi("product_uuid", productUuid);
        List<PlatformCommissionConfig> platformCommissionConfigs = platformCommissionConfigMapper.lstByCondition(where);
        PlatformCommissionConfig platformCommissionConfig = (platformCommissionConfigs.size() > 0) ? platformCommissionConfigs.get(0) : null;

        if(platformCommissionConfig == null) {
            where = where.clear();
            where.setCondi("platform_commission_type", 2);
            platformCommissionConfigs = platformCommissionConfigMapper.lstByCondition(where);
            platformCommissionConfig = (platformCommissionConfigs.size() > 0) ? platformCommissionConfigs.get(0) : null;
        }

        if(platformCommissionConfig!=null) {
            /*
            平台服务费：产品实际募集金额*X%/365*产品期限-投资人收益之和，结果大于0，负数亦取0；
            收益不包括加息券、产品加息等平台支出的营销费用收益，只为募集方应该返还部分收益之和。
            X为平台服务费率基数值，默认值12，实际募集金额包括现金券部分金额。
            * */
            logger.info("FeeRate: " + platformCommissionConfig.getFeeRate().doubleValue() + ", ProductPeriod: " + productPeriod + ", RateFormulaParam: " + rateFormulaParam);
            double feebase = ((platformCommissionConfig.getFeeRate().doubleValue() * productPeriod) / rateFormulaParam);
            logger.info("Feebase: " + feebase + ", RaiseAmount: " + raiseAmount);
            double baseFeeAmt = feebase * raiseAmount;
            logger.info("BaseFeeAmt: " + baseFeeAmt);

            Double raiserProfitAmount = tradeOrderMapper.lstRaiserProfitAmount(productUuid);
            raiserProfitAmount = ((raiserProfitAmount == null) ? 0.0 : raiserProfitAmount);
            logger.info("RaiserProfitAmount: " + raiserProfitAmount);

            /*
            平台服务费=实际募集金额*服务费率*(产品期限/365)-募集方返还收益之和-交易所发行费  张以杰/20180228
            */
            double exchangeManagerFee = getExchangeManagerFee(productUuid, productPeriod, rateFormulaParam, raiseAmount);
            logger.info("baseFeeAmt:{}, raiserProfitAmount:{}, exchangeManagerFee{}", baseFeeAmt, raiserProfitAmount, exchangeManagerFee);
            double feeAmt = AmountUtils.exac(baseFeeAmt-raiserProfitAmount-exchangeManagerFee);
            feeAmt=((feeAmt<0)?0.0:feeAmt);
            return feeAmt;
        }

        return 0;
    }

    //获取交易所管理费(年化)
    private double getExchangeManagerFee(String productUuid, int productPeriod, int rateFormulaParam, double raiseAmount) {
        rateFormulaParam = (rateFormulaParam > 0) ? rateFormulaParam: RATEFORMULAPARAM;
        WhereCondition where = new WhereCondition();
        where.setCondi("product_uuid", productUuid);
        List<ExchangeManagerfeeConfig>  exchangeManagerConfigs = exchangeManagerfeeConfigMapper.lstByCondition(where);
        ExchangeManagerfeeConfig exchangeManagerfeeConfig = (exchangeManagerConfigs.size() > 0) ? exchangeManagerConfigs.get(0) : null;

        if(exchangeManagerfeeConfig != null) {
            double feebase = ((exchangeManagerfeeConfig.getFeeRate().doubleValue() * productPeriod) / rateFormulaParam);
            return AmountUtils.exac(feebase * raiseAmount);
        }else {
            where = where.clear();
            where.setCondi("exchange_managerfee_type", 2);
            exchangeManagerConfigs = exchangeManagerfeeConfigMapper.lstByCondition(where);
            exchangeManagerfeeConfig = (exchangeManagerConfigs.size() > 0) ? exchangeManagerConfigs.get(0) : null;
            if(exchangeManagerfeeConfig != null) {
                double feebase = ((exchangeManagerfeeConfig.getFeeRate().doubleValue() * productPeriod) / rateFormulaParam);
                return AmountUtils.exac(feebase * raiseAmount);
            }
        }

        return 0;
    }

    /**
     * 插入私募产品的产品奖励
     */
    private void insertProductRewardSummaryMapper(ProductPrivateFund productInfo) {
        productRewardSummaryMapper.deleteByProductUuid(productInfo.getProductUuid());
        ProductRewardSummary productRewardSummary = new ProductRewardSummary();

        logger.info("Step1 添加产品信息");
        productRewardSummary.setProductUuid(productInfo.getProductUuid());
        productRewardSummary.setProductCode(productInfo.getProductCode());
        productRewardSummary.setProductAbbrName(productInfo.getProductAbbrName());
        productRewardSummary.setProductType(productInfo.getProductType());
        productRewardSummary.setProductPeriod(productInfo.getProductPeriod());//产品期限
        productRewardSummary.setProductScale(productInfo.getProductScale());//募集金额/产品规模
        productRewardSummary.setProductAccumulation(productInfo.getProductAccumulation());//实际募集金额


        logger.info("Step2 添加佣金信息");
        WhereCondition where = new WhereCondition();
        where.setCondi("product_uuid", productInfo.getProductUuid());
        List<Reward> rewardList = rewardMapper.lstByCondition(where);

        Set<String> userUuids = new HashSet<String>();
        int clearCount = 0;
        BigDecimal pretaxRewardAmount = new BigDecimal(0);
        for(Reward reward : rewardList) {
            userUuids.add(reward.getUserUuid());
            if(RewardStatus.PAID == reward.getRewardStatus()) {
                ++clearCount;
            }
            pretaxRewardAmount = pretaxRewardAmount.add(reward.getRewardAmount());
        }
        pretaxRewardAmount = new BigDecimal(AmountUtils.exac(pretaxRewardAmount));

        productRewardSummary.setRewardCount(rewardList.size());//奖励记录数
        productRewardSummary.setRewardClearCount(clearCount);//已结算奖励记录数
        productRewardSummary.setFinancialAdvisorCount(userUuids.size());//理财顾问数量
        productRewardSummary.setPretaxRewardAmount(pretaxRewardAmount);// 税前理顾佣金

        logger.info("Step3 添加相应费用信息");
        productRewardSummary.setManagementFee(new BigDecimal(0.0));//管理费率
        //服务费率=(私募创建)外包服务费率
        if(productInfo.getProductServiceFee() != null) {
            productRewardSummary.setPlatformCommission(productInfo.getProductServiceFee());//服务费率
        }else{
            productRewardSummary.setPlatformCommission(new BigDecimal(0));
        }
       // 私募服务费=平台服务费=投资金额*服务费率*投资期限/12
        BigDecimal pretaxPlatformServicefee=(productRewardSummary.getProductAccumulation().multiply(productRewardSummary.getPlatformCommission()).multiply(new BigDecimal(productInfo.getProductPeriod()))).divide(new BigDecimal(12),4, BigDecimal.ROUND_HALF_EVEN);
        productRewardSummary.setPretaxPlatformServicefee(pretaxPlatformServicefee);//税前平台服务费
        productRewardSummary.setPlatformServicefeeTax(new BigDecimal(0.0));//(平台服务费的)扣税
        productRewardSummary.setAftertaxPlatformServicefee(new BigDecimal(0.0));//税后平台服务费
        productRewardSummary.setExchangeManageFee(new BigDecimal(0.0));//交易所管理费
        //平台收入=平台服务费-佣金总额
        BigDecimal platformIncome=pretaxPlatformServicefee.subtract(pretaxRewardAmount);
        productRewardSummary.setPlatformIncome(platformIncome);//平台收入

        logger.info("Step4 添加默认状态等信息");
        productRewardSummary.setExchangeManagefeeClearStatus(BizDefine.WORKFLOW_STATUS_CREATE);//管理费处理状态：-1审批失败；1待审核；2审核通过; 3已结算
        productRewardSummary.setIncomeTaxClearStatus(BizDefine.WORKFLOW_STATUS_CREATE);//收入报税处理状态：-1审批失败；1待审核；2审核通过; 3已结算

        productRewardSummary.setDeleteFlag((new Integer(0)).byteValue());
        productRewardSummary.setCreateTime(new Date());
        productRewardSummary.setUpdateTime(new Date());
        //产品成立时间
        if(rewardList!=null && rewardList.size() > 0){
            productRewardSummary.setProductEstablishmentDate(rewardList.get(0).getProductInterestDate());
        }
        productRewardSummaryMapper.insert(productRewardSummary);
    }

    /**
     * 插入固收产品的产品奖励
     */
    private void insertProductRewardSummaryMapper(ProductFixedIncome productInfo, BigDecimal platformServiceFee, double exchangeManagerFee) {
        //平台服务费税率
        final BigDecimal platformServicefeeTaxRate = new BigDecimal(0.0336);

        productRewardSummaryMapper.deleteByProductUuid(productInfo.getProductUuid());
        ProductRewardSummary productRewardSummary = new ProductRewardSummary();

        logger.info("Step1 添加产品信息");
        productRewardSummary.setProductUuid(productInfo.getProductUuid());
        productRewardSummary.setProductCode(productInfo.getProductCode());
        productRewardSummary.setProductAbbrName(productInfo.getProductAbbrName());
        productRewardSummary.setProductType(productInfo.getProductType());
        productRewardSummary.setProductEstablishmentDate(productInfo.getProductEstablishmentDate());
        productRewardSummary.setProductPeriod(productInfo.getProductPeriod());
        productRewardSummary.setProductScale(productInfo.getProductScale());
        productRewardSummary.setProductAccumulation(productInfo.getProductAccumulation());
        productRewardSummary.setPlatformCommission(productInfo.getPlatformCommission());
        productRewardSummary.setManagementFee(productInfo.getManagementFee());

        logger.info("Step2 添加佣金信息");
        WhereCondition where = new WhereCondition();
        where.setCondi("product_uuid", productInfo.getProductUuid());
        List<Reward> rewardList = rewardMapper.lstByCondition(where);

        Set<String> userUuids = new HashSet<String>();
        int clearCount = 0;
        BigDecimal pretaxRewardAmount = new BigDecimal(0);
        for(Reward reward : rewardList) {
            userUuids.add(reward.getUserUuid());
            if(RewardStatus.PAID == reward.getRewardStatus()) {
                ++clearCount;
            }
            pretaxRewardAmount = pretaxRewardAmount.add(reward.getRewardAmount());
        }
        pretaxRewardAmount = new BigDecimal(AmountUtils.exac(pretaxRewardAmount));

        productRewardSummary.setRewardCount(rewardList.size());
        productRewardSummary.setRewardClearCount(clearCount);
        productRewardSummary.setFinancialAdvisorCount(userUuids.size());
        productRewardSummary.setPretaxRewardAmount(pretaxRewardAmount);

        logger.info("Step3 添加相应费用信息");
        productRewardSummary.setPretaxPlatformServicefee(platformServiceFee);

        //扣税 = 税前平台服务费 * 0.0336
        productRewardSummary.setPlatformServicefeeTax(new BigDecimal(AmountUtils.exac(productRewardSummary.getPretaxPlatformServicefee().multiply(platformServicefeeTaxRate))));

        //税后平台服务费 = 税前平台服务费 - 扣税
        productRewardSummary.setAftertaxPlatformServicefee(platformServiceFee.subtract(productRewardSummary.getPlatformServicefeeTax()));

        productRewardSummary.setExchangeManageFee(new BigDecimal(exchangeManagerFee));

        //平台收入 = 税前平台服务费 - 税前理顾佣金
        productRewardSummary.setPlatformIncome(platformServiceFee.subtract(pretaxRewardAmount));

        productRewardSummary.setExchangeManagefeeClearStatus(BizDefine.WORKFLOW_STATUS_CREATE);
        productRewardSummary.setIncomeTaxClearStatus(BizDefine.WORKFLOW_STATUS_CREATE);

        productRewardSummary.setDeleteFlag((new Integer(0)).byteValue());
        productRewardSummary.setCreateTime(new Date());
        productRewardSummary.setUpdateTime(new Date());

        productRewardSummaryMapper.insert(productRewardSummary);
    }

    /**
     * 产品成立
     *
     * @param productUUId 产品ID
     * @param productType
     * @param createBy
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void productEstablish(String productUUId, String productType, String createBy) throws BusinessException{
        if(productType.equals(ProductType.PRODUCT_PF)) {
            privateProductEstablish(productUUId, createBy);
        }else if(productType.equals(ProductType.PRODUCT_FT)) {
            fixedProductEstablish(productUUId, createBy);
        }

        logger.info("Step11 发送产品成立mq消息");
        ProductMessage message = new ProductMessage();
        message.setProductUuid(productUUId);
        message.setProductType(productType);
        productEstablishProducer.send(message);
    }

    /**
     * 私募类产品成立
     * @param productUUId 产品ID
     * @param createBy
     * @return
     * @throws BusinessException
     */
    private void privateProductEstablish(String productUUId, String createBy) throws BusinessException{
        ProductPrivateFund productInfo = getPrivateProductById(productUUId);
        //Step1.1 检查状态
        logger.info("Step1 检查并更新产品状态");
        if(productInfo.getProductStatus() != BizDefine.PRODUCT_STATUS_ENDRAISE) {
            throw new BusinessException(TradeStatusMsg.PRODUCT_STATUS_ERR, TradeStatusMsg.PRODUCT_STATUS_ERR_MSG, true);
        }

        updateProductStatus(productUUId, BizDefine.PRODUCT_STATUS_ESTABLISH, createBy, null);

        logger.info("Step2 更新奖励状态");
        rewardService.updatePrivateProductRewardRecord(productUUId);

        logger.info("Step3 插入产品奖励记录");
        insertProductRewardSummaryMapper(productInfo);


        logger.info("Step4 发送私募产品成立mq消息");
        ProductMessage message = new ProductMessage();
        message.setProductUuid(productUUId);
        productPFEstablishProducer.send(message);
    }

    /**
     * 固收类产品成立
     * @param productUUId 产品ID
     * @param createBy
     * @return
     * @throws BusinessException
     */
    private void fixedProductEstablish(String productUUId, String createBy) throws BusinessException{
        //如果已经成立过，则直接返回
        if(lstTradeInvestSummaryByProduct(productUUId) != null) {
            return;
        }

        //Step1 检查产品信息：成立日、状态等
        logger.info("Step1 检查产品信息：成立日、状态等");
        ProductFixedIncome productInfo = getFixedIncomeProductById(productUUId);
        //Step1.1 检查状态
        if(productInfo.getProductStatus() != BizDefine.PRODUCT_STATUS_ENDRAISE) {
            throw new BusinessException(TradeStatusMsg.PRODUCT_STATUS_ERR, TradeStatusMsg.PRODUCT_STATUS_ERR_MSG, true);
        }

//        //Step1.2 检查 成立/起息 日
//        if(!baseService.dateCheck(productInfo.getProductInterestDate())) {
//           throw new BusinessException(TradeStatusMsg.PRODUCT_DATE_ERR, TradeStatusMsg.PRODUCT_DATE_ERR_MSG, true);
//        }

        //Step3 填充产品信息
        logger.info("Step2 填充产品信息");
        TradeInvestSummaryVO tradeInvestSummaryVO = new TradeInvestSummaryVO();
        tradeInvestSummaryVO.setProductUuid(productUUId);
        tradeInvestSummaryVO.setProductCode(productInfo.getProductCode());
        tradeInvestSummaryVO.setProductType(productInfo.getProductType());
        tradeInvestSummaryVO.setProductAbbrName(productInfo.getProductAbbrName());

        //Step4 汇总产品的交易信息
        logger.info("Step3 汇总产品的交易信息");
        WhereCondition condition = new WhereCondition();
        condition.setCondi("product_uuid", productUUId);
        condition.setCondi("order_status", BizDefine.ORDER_STATUS_CONFIRM);
        condition.noDelete();
        Set<String> userIds = new HashSet<String>();
        for(TradeOrder tradeOrder : lstTradeOrdersByCondition(condition)) {
            userIds.add(tradeOrder.getUserUuid());

            //增加投资者账户冻结科目检查
            Account account = getAccountByAccountUuid(tradeOrder.getAccountUuid());
            checkAccount(account);

            if(account.getAccountFreezeAmount().doubleValue() < tradeOrder.getPaidAmount().doubleValue()) {
                throw new BusinessException(AccountStatusMsg.ACCOUNT_MONEY_NOT_ENOUGH_CODE, "账户" + tradeOrder.getAccountUuid() + "冻结科目，" + AccountStatusMsg.ACCOUNT_MONEY_NOT_ENOUGH, false);
            }

            //累计 募集总金额
            tradeInvestSummaryVO.setRaiseAmount(tradeInvestSummaryVO.getRaiseAmount() + tradeOrder.getOrderAmount().doubleValue());

            //累计 募集金额_客户缴纳部分
            tradeInvestSummaryVO.setRaiseInvestorAmount(tradeInvestSummaryVO.getRaiseInvestorAmount() + tradeOrder.getPaidAmount().doubleValue());

            //累计 募集金额_平台营销费用部分
            tradeInvestSummaryVO.setRaisePlatformAmount(tradeInvestSummaryVO.getRaisePlatformAmount() + tradeOrder.getMarketingAmount().doubleValue());
        }
        //有效投资用户
        tradeInvestSummaryVO.setRaiseCount(userIds.size());

        logger.info("Step4 更新产品的平台服务费和交易所管理费");
        //计算平台服务费
        double platformServiceFee = getPlatformServiceFee(productInfo.getProductUuid(), productInfo.getProductPeriod(),
                productInfo.getRateFormulaParam(), tradeInvestSummaryVO.getRaiseAmount());
        tradeInvestSummaryVO.setPlatformServerFeeAmount(platformServiceFee);

        //计算交易所管理费
        double exchangeManagerFee = getExchangeManagerFee(productInfo.getProductUuid(), productInfo.getProductPeriod(),
                productInfo.getRateFormulaParam(), tradeInvestSummaryVO.getRaiseAmount());
        tradeInvestSummaryVO.setExchangeManagerFeeAmount(exchangeManagerFee);

        //Step5 填充出入账户信息
        logger.info("Step5 填充出入账户信息");
        Account outAccount = getAccountByType(BizDefine.ACCOUNT_TYPE_ZJ_DEPOSIT);
        checkAccount(outAccount);
        tradeInvestSummaryVO.setOutAccountNo(outAccount.getAccountUuid());
        tradeInvestSummaryVO.setOutAccountUuid(outAccount.getAccountUuid());
        tradeInvestSummaryVO.setOutUserUuid(outAccount.getUserUuid());

        String productIssuerUuid = productInfo.getProductIssuerUuid();
        Account inAccount = getAccountByUserUuid(BizDefine.ACCOUNT_TYPE_ZJ_FINANCIER_DEPOSIT, productIssuerUuid);
        checkAccount(inAccount);
        tradeInvestSummaryVO.setInAccountNo(inAccount.getAccountUuid());
        tradeInvestSummaryVO.setInAccountUuid(inAccount.getAccountUuid());
        tradeInvestSummaryVO.setInUserUuid(inAccount.getUserUuid());

        //Step6 检查托管账户余额是否充足
        logger.info("所需金额" + tradeInvestSummaryVO.getRaiseInvestorAmount());
        if(outAccount.getAccountCashAmount().doubleValue() < tradeInvestSummaryVO.getRaiseInvestorAmount()) {
            throw new BusinessException(TradeStatusMsg.ESCROW_ACCOUNT_LESS_BALANCE, TradeStatusMsg.ESCROW_ACCOUNT_LESS_BALANCE_MSG, false);
        }

        //Step7 填充创建和更新信息
        logger.info("Step6 填充创建和更新时间信息");
        Date curTime = new Date();
        tradeInvestSummaryVO.setCreateTime(curTime);
        tradeInvestSummaryVO.setUpdateTime(curTime);
        tradeInvestSummaryVO.setTransactionStatus(BizDefine.WORKFLOW_STATUS_CREATE);

        //Step7 添加募集汇总信息
        logger.info("Step7 添加募集汇总信息");
        tradeInvestSummaryVO.setBatchNo(generateBatchNo(TRADE_ACCOUNT_AMOUNT));
        TradeInvestSummary tradeInvestSummary = tradeInvestSummaryVO.get();
        tradeInvestSummaryMapper.insert(tradeInvestSummary);

        //Step8 更新产品状态
        logger.info("Step8 更新产品状态");
        ProductCriticalDateVO productCriticalDate = new ProductCriticalDateVO();
        productCriticalDate.setProductEstablishmentDate(StringOrDate.getCurDate());
        productInfo.setProductEstablishmentDate(StringOrDate.getCurDate());
        updateProductStatus(productUUId, BizDefine.PRODUCT_STATUS_ESTABLISH, createBy, productCriticalDate);

        //Step9 更新交易信息
        //logger.info("Step9 更新交易状态");
        //tradeOrderMapper.updateStatus(productUUId, BizDefine.ORDER_STATUS_PRODUCT_ESTABLISH, BizDefine.ORDER_STATUS_CONFIRM);

        logger.info("Step10 插入产品奖励记录");
        insertProductRewardSummaryMapper(productInfo, new BigDecimal(platformServiceFee), exchangeManagerFee);
    }

    /**
     * Step2 产品成立_放款查询(维度:产品，列表)
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public TradeInvestSummaryListVO lstProductEstablishLoan(LstProductEstablishLoanVO lstProductEstablishLoanVO) throws BusinessException {
        TradeInvestSummaryListVO tradeInvestSummaryListVO = new TradeInvestSummaryListVO();

        WhereCondition condition = new WhereCondition();
        condition.setCondi("trade_invest_summary_uuid", lstProductEstablishLoanVO.getApplyUUId(), true);
        condition.setLike("product_abbr_name", lstProductEstablishLoanVO.getProductName());
        if(0 != lstProductEstablishLoanVO.getTransStatus()){
            condition.setCondi("transaction_status", lstProductEstablishLoanVO.getTransStatus());
        }
        condition.setBetween("create_time", lstProductEstablishLoanVO.getBeginDate(), lstProductEstablishLoanVO.getEndDate());
        condition.noDelete();
        tradeInvestSummaryListVO.setTotalCount(tradeInvestSummaryMapper.lstCountByCondition(condition));

        condition.setPage(lstProductEstablishLoanVO.getBeginSN(), lstProductEstablishLoanVO.getEndSN(), "trade_invest_summary_uuid");
        List<TradeInvestSummary> items = tradeInvestSummaryMapper.lstByCondition(condition);

        List<TradeInvestSummaryVO> VOItems = new ArrayList<TradeInvestSummaryVO>();
        for(TradeInvestSummary tradeInvestSummary : items) {
            VOItems.add(new TradeInvestSummaryVO(tradeInvestSummary));
        }
        tradeInvestSummaryListVO.setItems(VOItems);

        return tradeInvestSummaryListVO;
    }

    /**
     * Step3 产品成立_放款详情(维度:产品，单记录)
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public TradeInvestSummaryExVO getProductEstablishLoanDetail(String productUuid) throws BusinessException {
        TradeInvestSummary tradeInvestSummary = lstTradeInvestSummaryByProduct(productUuid);

        if(tradeInvestSummary == null) {
            throw new BusinessException(TradeStatusMsg.SYSTEM_BIZ_ERR, TradeStatusMsg.SYSTEM_BIZ_ERR_MSG, false);
        }

        return getTradeInvestSummaryExVO(tradeInvestSummary);
    }

    /**
     * Step4 产品成立_放款明细(维度:产品-交易，列表)
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public CommItemListVO<LoanCashedDetailVO> lstProductEstablishLoanItems(LstProductEstablishLoanItemsVO param) throws BusinessException {
        Integer count = 0;
        List<LoanCashedDetailVO> list = new ArrayList<LoanCashedDetailVO>();
        //已指定了状态，并且与放款状态不一致，则返回空记录
//        if(param.getStatus() > 0) {
//            TradeInvestSummary tradeInvestSummary = lstTradeInvestSummaryByProduct(param.getProductUuid());
//            if (tradeInvestSummary.getTransactionStatus() != param.getStatus()) {
//                return new CommItemListVO<LoanCashedDetailVO>(count,list);
//            }
//        }
        WhereCondition condition = new WhereCondition();
        condition.setCondiEx(" trade.order_bill_code = trans.trade_order_bill_code AND trade.delete_flag = 0 ");
        condition.setInInt("trade.order_status", BizDefine.ORDER_STATUS_CONFIRM, BizDefine.ORDER_STATUS_PRODUCT_INTEREST, BizDefine.ORDER_STATUS_PRODUCT_END, BizDefine.ORDER_STATUS_CLEAR);
        condition.setCondi("trans.trade_type",  TradeType.TRADE_INVEST);
        condition.setCondi("trans.account_type", AccountType.ACCOUNT_TYPE_INVESTOR);
        condition.setCondi("trade.product_uuid", param.getProductUuid(), true);
        condition.setCondi("trade.user_phone", param.getUserPhone(), true);
        condition.setBetween("trade.payed_time", param.getBeginDate(), param.getEndDate());
        if(DataUtils.isNotEmpty(param.getOrderNo())){
            condition.setCondiEx(" AND (trade.order_bill_code = '"+param.getOrderNo()+"' OR trans.trade_order_bill_code_extend = '"+param.getOrderNo() + "' )");
        }
        count=tradeOrderMapper.getLoanCashedDetailCount(condition);
        condition.setPage(param.getBeginSN(), param.getEndSN(), "trade.order_bill_code");
        list = tradeOrderMapper.getLoanCashedDetail(condition);
        for(LoanCashedDetailVO vo:list){
            if(DataUtils.isNotEmpty(vo.getTradeOrderBillCodeExtend())){
                vo.setOrderBillCode(vo.getTradeOrderBillCodeExtend());
            }
        }
        return new CommItemListVO<LoanCashedDetailVO>(count,list);
    }

    /**
     * Step5 产品成立_放款_审核
     * isAudited 1审核通过  0审核未通过
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean productEstablishLoanAudit(String userPhone, String productUUId, int isAudited, String message) throws BusinessException{
        TradeInvestSummary tradeInvestSummary = lstTradeInvestSummaryByProduct(productUUId);

        bizCheck(tradeInvestSummary);
        statusCheck(tradeInvestSummary.getTransactionStatus(), BizDefine.WORKFLOW_STATUS_AUDIT_FAIL, BizDefine.WORKFLOW_STATUS_CREATE);

        tradeInvestSummary.setAuditOperator(userPhone);
        tradeInvestSummary.setAuditTime(new Date());

        if (isAudited > 0) {
            //审核通过
            tradeInvestSummary.setTransactionStatus(BizDefine.WORKFLOW_STATUS_AUDITED);
        } else {
            //审核不通过
            tradeInvestSummary.setTransactionStatus(BizDefine.WORKFLOW_STATUS_AUDIT_FAIL);
            tradeInvestSummary.setAuditOpinion(message);
        }

        return (tradeInvestSummaryMapper.updateByPrimaryKey(tradeInvestSummary) > 0);
    }

    //添加资金流水
    private String insertAccountTransaction(String orderCode, Account outAccount, Account inAccount, double amount, String type) throws BusinessException {
        //Step1 记录平台托管账户流水
        String sn = insertAccountTransactionEx(orderCode, outAccount, inAccount, amount, type, null, null);

        //Step2 记录融资方账户流水
        insertAccountTransactionEx(orderCode, inAccount, outAccount, amount, type, null, null);

        return sn;
    }

    /**
     * 将现金券的汇总金额通过平台的基本户划付给募集方的托管账户 检查
     * @param orderNo
     * @param outAccountUuid
     * @param inAccountUuid
     * @param amount
     * @throws BusinessException
     */
    private void loanCashCouponSummaryAmountCheck(String orderNo, String outAccountUuid, String inAccountUuid, double amount) throws BusinessException {
        Account outAccount = getAccountByAccountUuid(outAccountUuid);
        Account inAccount = getAccountByAccountUuid(inAccountUuid);

        logger.info("现金券放款Step1，账户检查");
        checkAccount(outAccount, inAccount);

        logger.info("现金券放款Step2，平台结算账户检查");
        if (outAccount.getAccountCashAmount().doubleValue() < amount) {
            throw new BusinessException(TradeStatusMsg.CLEAR_ACCOUNT_LESS_BALANCE, TradeStatusMsg.CLEAR_ACCOUNT_LESS_BALANCE_MSG, false);
        }
    }

    /**
     * 将现金券的汇总金额通过平台的基本户划付给募集方的托管账户
     * @param orderNo
     * @param outAccountUuid
     * @param inAccountUuid
     * @param amount
     * @throws BusinessException
     */
    private void loanCashCouponSummaryAmount(String orderNo, String outAccountUuid, String inAccountUuid, double amount) throws BusinessException {
        Account outAccount = getAccountByAccountUuid(outAccountUuid);
        Account inAccount = getAccountByAccountUuid(inAccountUuid);

        logger.info("现金券放款Step1，账户检查");
        checkAccount(outAccount, inAccount);

        logger.info("现金券放款Step2，平台结算账户检查");
        if(outAccount.getAccountCashAmount().doubleValue() < amount) {
            throw new BusinessException(TradeStatusMsg.CLEAR_ACCOUNT_LESS_BALANCE, TradeStatusMsg.CLEAR_ACCOUNT_LESS_BALANCE_MSG, false);
        }

        //调减平台结算账户的可用资金
        logger.info("现金券放款Step3，募集资金，调整平台结算账户和融资人托管账户");
        accountMapper.reduceCashAmount(outAccountUuid, amount);

        //调增融资人托管账户的可用资金
        accountMapper.addCashAmount(inAccountUuid, amount);

        logger.info("现金券放款Step4，处理资金流水");
        insertAccountTransaction(orderNo, outAccount, inAccount, amount, TRADE_MARKETING_AMOUNT);

        logger.info("现金券放款Step5，实际调宝付的接口做转账");
        logger.info("payService.transferP2C orderID:" + orderNo + ", userID:"
                + inAccount.getAccountNo() + ", amount:" + amount);

        try {
            ResponseResult responseResult = payService.transferP2C(orderNo, inAccount.getAccountNo(), amount);
            logger.info((responseResult != null) ? responseResult.toString() : "null");

            if((responseResult == null)||(responseResult.getCode() != TradeError.OK)) {
                throw new BusinessException(TradeStatusMsg.COUPON_LOAN_FAIL, TradeStatusMsg.COUPON_LOAN_FAIL_MSG, false);
            }
        }catch(BusinessException e) {
            logger.error("现金券放款，宝付转账异常", e);
            throw(e);
        }
    }

    /**
     * 将投资者的实缴资金放款给宝付
     * @param productInfo
     * @param orderNo
     * @param outAccountUuid
     * @param inAccountUuid
     * @param amount
     * @param platformServiceFee
     * @throws BusinessException
     */
    private void loanInvestorPaidAmount(ProductFixedIncome productInfo, String orderNo, String outAccountUuid, String inAccountUuid, double amount, double platformServiceFee) throws BusinessException {
        Account outAccount = getAccountByAccountUuid(outAccountUuid);
        Account inAccount = getAccountByAccountUuid(inAccountUuid);

        logger.info("投资者资金放款Step1，账户检查");
        checkAccount(outAccount, inAccount);

        //放款处理
        //Step1 维护账户
        //调减平台托管账户的可用资金
        logger.info("投资者资金放款Step2，募集资金，调整平台托管账户和融资人托管账户");
        accountMapper.reduceCashAmount(outAccountUuid, amount);

        //调增融资人托管账户的可用资金
        accountMapper.addCashAmount(inAccountUuid, amount);

        //Step3 添加资金流水
        logger.info("投资者资金放款Step3，处理 募集资金 资金流水");
        insertAccountTransaction(orderNo, outAccount, inAccount, amount, TRADE_ACCOUNT_AMOUNT);

        //平台服务费处理
//        logger.info("投资者资金放款Step4，平台服务费，调整融资人托管账户和平台清算账户");
//        Account clearAccount = getAccountByType(BizDefine.ACCOUNT_TYPE_ZJ_CLEAR);
//        checkAccount(clearAccount);
//        logger.info(clearAccount.getAccountUuid() + " " + platformServiceFee);
//
//        //调减融资人托管账户的可用资金
//        accountMapper.reduceCashAmount(inAccountUuid, platformServiceFee);
//        //调增平台清算账户的可用资金
//        accountMapper.addCashAmount(clearAccount.getAccountUuid(), platformServiceFee);
//
//        //添加资金流水
//        logger.info("投资者资金放款Step5，处理 平台服务费 资金流水");
//        insertAccountTransaction(orderNo, inAccount, clearAccount, platformServiceFee, TradeType.TRADE_COMMISION_PAYMENT_SYSTEM);

        //Step2 调用宝付接口做转账
        logger.info("投资者资金放款Step6，实际调宝付的接口做放款并处理平台服务费");

        if(amount > 0) {
            logger.info("payService.payment orderID:" + orderNo + ", productID:" + productInfo.getProductID() + ", productName:"
                    + productInfo.getProductName() + ", borrowUserID:" + inAccount.getAccountNo() + ", amount:" + amount + ", fee:" + 0);
            try {
                //orderNo 资金流水的ID

                ResponseResult responseResult = null;

                Long productId = 0L;
                Long errId =0L;

                //2018-01-09  线上出现投资时借款人账户(93002)和放款时借款人账户（93001）不一致  zhangyijie
                Boolean isTest = false;
                if(isTest) {
                    productId = 153214138573L;
                    //errId = 6100000086402L;
                    errId = 6100000073385L;
                }else {
                    productId = 1286L;
                    errId = 93002L;
                }

                if(productInfo.getProductID().equals(productId)) {
                    logger.info("临时处理 {} {} {}", productInfo.getProductID(), errId, inAccount.getAccountNo());
                    responseResult = payService.paymentEx(orderNo, productInfo.getProductID(), productInfo.getProductName(), errId, inAccount.getAccountNo(), amount, 0);
                }else {
                    logger.info("正常处理");
                    responseResult = payService.payment(orderNo, productInfo.getProductID(), productInfo.getProductName(), inAccount.getAccountNo(), amount, 0);
                }
                logger.info((responseResult != null) ? responseResult.toString() : "null");

                if ((responseResult == null) || (responseResult.getCode() != TradeError.OK)) {
                    throw new BusinessException(TradeStatusMsg.PRODUCT_LOAN_FAIL, TradeStatusMsg.PRODUCT_LOAN_FAIL_MSG, false);
                }
            } catch (BusinessException e) {
                logger.error("宝付放款异常", e);
                throw (e);
            }
        }else {
            logger.error("募集金额为0，无法做放款处理");
        }
    }

    //募集结束更新投资者相关信息
    private void updateInvestorInfo(String productUUId) {
        //Step1 更新投资者账户信息
        WhereCondition condition = new WhereCondition();
        condition.setCondi("product_uuid", productUUId);
        condition.setCondi("order_status", BizDefine.ORDER_STATUS_CONFIRM);
        condition.noDelete();
        for(TradeOrder tradeOrder : lstTradeOrdersByCondition(condition)) {
            double inveAmount = tradeOrder.getPaidAmount().doubleValue();
            double marketAmount = tradeOrder.getMarketingAmount().doubleValue();
            String accountUuid = tradeOrder.getAccountUuid();
            accountMapper.investorRaiseEnd(accountUuid, inveAmount, marketAmount);
        }
    }

    /**
     * 锁住放款记录
     * @param productUUId
     * @throws BusinessException
     */
    public void lockTradePayment(String productUUId) throws BusinessException {
        TradeInvestSummary tradeInvestSummary = lstTradeInvestSummaryByProduct(productUUId);
        statusCheck(tradeInvestSummary.getTransactionStatus(), BizDefine.WORKFLOW_STATUS_AUDITED);
        tradeInvestSummaryMapper.lockTradePayment(productUUId, BizDefine.WORKFLOW_STATUS_ING, BizDefine.WORKFLOW_STATUS_AUDITED);
    }

    /**
     * 解锁放款记录
     * @param productUUId
     * @throws BusinessException
     */
    public void unLockTradePayment(String productUUId) throws BusinessException {
        tradeInvestSummaryMapper.unLockTradePayment(productUUId, BizDefine.WORKFLOW_STATUS_ING, BizDefine.WORKFLOW_STATUS_AUDITED);
    }

    /**
     * Step6 产品成立_放款_结算
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public TradeInvestSummaryExVO productEstablishLoanClear(String userPhone, String productUUId, String createBy) throws BusinessException {
        logger.info("产品成立_放款_结算Step1，读取放款记录和产品信息");
        TradeInvestSummary tradeInvestSummary = lstTradeInvestSummaryByProduct(productUUId);
        if(tradeInvestSummary == null) {
            throw new BusinessException(TradeStatusMsg.WORKFLOW_STATUS_ERR, TradeStatusMsg.WORKFLOW_STATUS_ERR_MSG, false);
        }

        ProductFixedIncome productInfo = getFixedIncomeProductById(tradeInvestSummary.getProductUuid());

        //Step1 检查是否已经审核通过/锁定状态
        logger.info("产品成立_放款_结算Step2，检查是否已经审核通过/锁定状态");
        statusCheck(tradeInvestSummary.getTransactionStatus(), BizDefine.WORKFLOW_STATUS_AUDITED);
        //statusCheck(tradeInvestSummary.getTransactionStatus(), BizDefine.WORKFLOW_STATUS_ING);

        logger.info("产品成立_放款_结算Step3，更新放款信息");
        tradeInvestSummary.setTransactionStatus(BizDefine.WORKFLOW_STATUS_CLEAR);
        tradeInvestSummary.setPayedOperator(userPhone);

        Date loanTime = new Date();
        tradeInvestSummary.setPayedTime(loanTime);

        productRewardSummaryMapper.updateLoanTime(productUUId, loanTime);

        logger.info("产品成立_放款_结算Step4，更新宝付流水号");
        //更换流水号
        String newBatchNo = generateBatchNo(TRADE_ACCOUNT_AMOUNT);
        //tradeInvestSummaryMapper.updateBatchNo(newBatchNo, tradeInvestSummary.getBatchNo());
        tradeInvestSummary.setBatchNo(newBatchNo);

        //更新募集汇总信息
        tradeInvestSummaryMapper.updateByPrimaryKey(tradeInvestSummary);

        //更新相应投资者和交易信息
        logger.info("产品成立_放款_结算Step5，更新投资者信息，对每一笔交易都做产品募集结束处理");
        updateInvestorInfo(productUUId);

        logger.info("产品成立_放款_结算Step6，资金处理和检查");
        //放款处理转账
        double raiseAmt = AmountUtils.exac(tradeInvestSummary.getRaiseInvestorAmount());
        double cashCouponAmt = AmountUtils.exac(tradeInvestSummary.getRaisePlatformAmount());
        double fee = AmountUtils.exac(tradeInvestSummary.getPlatformServiceFee());

        //检查结算账户
        Account clearAccount = getAccountByType(AccountType.ACCOUNT_TYPE_PLATFORM_SETTLEMENT);
        if(clearAccount.getAccountCashAmount().doubleValue() < cashCouponAmt) {
            throw new BusinessException(TradeStatusMsg.CLEAR_ACCOUNT_LESS_BALANCE, TradeStatusMsg.CLEAR_ACCOUNT_LESS_BALANCE_MSG, false);
        }

        //现金券放款，检查结算账户内余额是否充足
        loanCashCouponSummaryAmountCheck(newBatchNo, clearAccount.getAccountUuid(), tradeInvestSummary.getInAccountNo(), cashCouponAmt);

        //将投资者的实缴资金放款给宝付
        logger.info("产品成立_放款_结算Step7，将投资者的实缴资金放款给宝付");
        loanInvestorPaidAmount(productInfo, tradeInvestSummary.getBatchNo(), tradeInvestSummary.getOutAccountNo(), tradeInvestSummary.getInAccountNo(), raiseAmt, fee);

        logger.info("产品成立_放款_结算Step8，将投资者的现金券资金转账给宝付");
        if(cashCouponAmt > 0) {
            newBatchNo = generateBatchNo(TRADE_ACCOUNT_AMOUNT);
            loanCashCouponSummaryAmount(newBatchNo, clearAccount.getAccountUuid(), tradeInvestSummary.getInAccountNo(), cashCouponAmt);
        }

        // 更新奖励结算状态
        logger.info("产品成立_放款_结算Step9，更新奖励结算状态");
        rewardService.updateProductRewardRecord(productUUId);

        //更新产品状态为已放款
        logger.info("产品成立_放款_结算Step10，更新产品状态为已放款");
        ProductCriticalDateVO productCriticalDate = new ProductCriticalDateVO();
        productCriticalDate.setPaymentDate(StringOrDate.getCurDate());
        updateProductStatus(productUUId, BizDefine.PRODUCT_STATUS_LOAN, createBy, productCriticalDate);

        logger.info("产品成立_放款_结算Step11，生成第三方渠道佣金明细");
        channelCommisionServiceImpl.creatClearData(productUUId);

        TradeInvestSummaryExVO tradeInvestSummaryExVO = getTradeInvestSummaryExVO(tradeInvestSummary);
        return tradeInvestSummaryExVO;
    }

    public boolean isLoan(String productUUId) {
        TradeInvestSummary tradeInvestSummary = lstTradeInvestSummaryByProduct(productUUId);
        if((tradeInvestSummary != null) && (tradeInvestSummary.getTransactionStatus().equals(BizDefine.WORKFLOW_STATUS_CLEAR))) {
            return true;
        }

        return false;
    }
}
