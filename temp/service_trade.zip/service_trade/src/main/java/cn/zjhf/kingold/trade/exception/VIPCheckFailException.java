package cn.zjhf.kingold.trade.exception;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.constant.TradeStatusMsg;

/**
 * 达人标检查失败异常
 *
 * @author lutiehua
 * @date 2018/3/9
 */
public class VIPCheckFailException extends BusinessException {

    public VIPCheckFailException() {
        super(TradeStatusMsg.USER_VIP_FLAG_TALENT_ERROR_CODE, TradeStatusMsg.USER_VIP_FLAG_TALENT_ERROR_MSG, true);
    }
}
