package cn.zjhf.kingold.trade.persistence.mq.consumer;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.rocketmq.annotation.RocketMQConsumer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQConsumer;
import cn.zjhf.kingold.rocketmq.base.SimpleMessage;
import cn.zjhf.kingold.service_consumer.service.TradeServiceConsumer;
import cn.zjhf.kingold.trade.entity.TradeRecharge;
import cn.zjhf.kingold.trade.service.IPayService;
import cn.zjhf.kingold.trade.service.ITradeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 检查支付是否超时（通过延时消息实现，目前只检查支付操作超时）
 *
 * Created by lutiehua on 2017/7/13.
 */
@RocketMQConsumer(topic = "pay", tag = "timeout")
public class PayTimeoutConsumer extends AbstractMQConsumer<SimpleMessage> {

    @Autowired
    private IPayService payService;

    @Autowired
    private RedisTemplate redisTemplate;

    @Autowired
    private ITradeService tradeService;

    private final static int ONE_HOUR_MILLIS = 60 * 60 * 1000;;

    private final Logger LOGGER = LoggerFactory.getLogger(PayTimeoutConsumer.class);

    private final static String NOTIFY_KEY="consumer_recharge_timeout_repeat";
    private final static int NOTIFY_DEALING_CODE=202;
    private final static String NOTIFY_DEALING_MSG="处理中";

    @Override
    public ResponseResult process(SimpleMessage simpleMessage) throws BusinessException {
        ResponseResult responseResult = new ResponseResult();
        String payOrderId = simpleMessage.getData();
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        //过滤超时消息
        if (payOrderId != null && payOrderId.length() == 24) {
            try {
                String time = payOrderId.substring(3,17);
                Date date = dateFormat.parse(time);
                if (System.currentTimeMillis() - date.getTime() > 24 * ONE_HOUR_MILLIS) {
                    logger.info("PayTimeoutConsumer overflow 24 hours, commit message. orderId={}, code={}, msg={}", payOrderId, responseResult.getCode(), responseResult.getMsg());
                    responseResult.setCode(ResponseCode.OK);
                    return responseResult;
                }
            } catch (ParseException e) {
                logger.error("date parse error. billCode={}", payOrderId, e);
            }
        }
        boolean repeat = redisTemplate.opsForValue().setIfAbsent(NOTIFY_KEY + simpleMessage.getKey(),"");
        if (!repeat) {
            LOGGER.info("PayTimeOutConsumer two thread enter meanwhile deal same order, lock one. massage={}", simpleMessage);
            responseResult.setCode(NOTIFY_DEALING_CODE);
            responseResult.setMsg(NOTIFY_DEALING_MSG);
            return responseResult;
        }

        logger.info("PayTimeoutConsumer check timeout, notify timeout 1m, trigger query. orderId={}", payOrderId);
        responseResult = payService.queryTimeoutStatus(payOrderId);
        logger.info("PayTimeoutConsumer result. orderId={}, code={}, msg={}", payOrderId, responseResult.getCode(), responseResult.getMsg());
        redisTemplate.delete(NOTIFY_KEY + simpleMessage.getKey());
        TradeRecharge tradeRecharge = tradeService.queryRechargeOrderByBillCode(payOrderId);
        if (tradeRecharge != null && tradeRecharge.getCreateTime() != null &&
                (System.currentTimeMillis()-tradeRecharge.getCreateTime().getTime()) > 10 * ONE_HOUR_MILLIS) {
            logger.info("PayTimeoutConsumer overflow 10 hours, commit message. orderId={}, code={}, msg={}", payOrderId, responseResult.getCode(), responseResult.getMsg());
            responseResult.setCode(ResponseCode.OK);
        }
        return responseResult;
    }

}
