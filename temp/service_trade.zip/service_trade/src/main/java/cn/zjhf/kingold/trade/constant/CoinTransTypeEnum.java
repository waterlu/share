package cn.zjhf.kingold.trade.constant;


import cn.zjhf.kingold.common.exception.BusinessException;

/**
 * Created by wangxun on 2017/7/11.
 */
public enum CoinTransTypeEnum {
    ADD(0, "收入"), SUB(1, "支出"), SYS_SUB(2, "扣除"), SYS_ADD(3, "补偿");

    private Integer code;
    private String msg;

    CoinTransTypeEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public static CoinTransTypeEnum getCampaignCodeEnum(Integer code) throws BusinessException {
        for (CoinTransTypeEnum paramEnum: CoinTransTypeEnum.values()) {
            if(paramEnum.getCode().equals(code)) {
                return paramEnum;
            }
        }
        throw new BusinessException(-1, "no enum match");
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
