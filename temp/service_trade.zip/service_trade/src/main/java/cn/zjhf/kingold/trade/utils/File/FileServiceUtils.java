package cn.zjhf.kingold.trade.utils.File;

import cn.zjhf.kingold.trade.utils.DataUtils;
import com.aliyun.oss.OSSClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Date;
import java.util.UUID;

/**
 * Created by zhangyijie on 2017/7/24.
 */
@Service
public class FileServiceUtils implements IFileServiceUtilsBase {
    private static final Logger logger = LoggerFactory.getLogger(FileServiceUtils.class);

    @Value("${aliyun.oss.endpoint}")
    String endpoint;

    @Value("${aliyun.oss.accessKeyId}")
    String accessKeyId;

    @Value("${aliyun.oss.accessKeySecret}")
    String accessKeySecret;

    @Value("${aliyun.oss.publicBucket}")
    String publicBucket;

    @Value("${aliyun.oss.privateBucket}")
    String privateBucket;

    @Value("${aliyun.oss.privateMap}")
    String privateBucketMap;

    @Value("${aliyun.oss.publicMap}")
    String publicBucketMap;

    /**
     * 上传文件
     *
     * @param fileName 原始文件名称(包含路径)
     * @return 访问地址
     */
    @Override
    public String uploadFile(String fileName) {
        InputStream inputStream = null;
        try {
            inputStream = new FileInputStream(fileName);
            String newFileName = FileUtils.getFileName(fileName);
            String uriFilePath = uploadFile(inputStream, newFileName, true);

            inputStream.close();
            //FileUtils.delete(fileName);

            return uriFilePath;
        }catch(Exception e) {
            logger.error("uploadFile Exception:", e);
        }

        return "";
    }

    @Override
    public String uploadFile(InputStream inputStream, String sourceFileName, boolean secret) {
        String server = "http://" + endpoint;

        OSSClient client = new OSSClient(server, accessKeyId, accessKeySecret);

        // 是否对外部用户可见
        String bucketName = publicBucket;
        if (secret) {
            bucketName = privateBucket;
        }

        // UUID作为上传的文件名
        String key = UUID.randomUUID().toString();
        key = key.replaceAll("-", "");
        String fileName = key;
        int pos = sourceFileName.lastIndexOf(".");
        if (pos > 0) {
            String postFix = sourceFileName.substring(pos);
            fileName += postFix;
        }

        client.putObject(bucketName, fileName, inputStream);
        client.shutdown();

        // 上传成功返回访问地址
//        String bucketUrl = publicBucketMap;
//        if (secret) {
//            bucketUrl = privateBucketMap;
//        }
//        String url = "https://" + bucketUrl + "/" + fileName;
        // 上传成功返回访问地址
        String url = "http://" + bucketName + "." + endpoint + "/" + fileName;
        return url;
    }

    @Override
    public String getAccessFileUrl(String file){
        OSSClient client = new OSSClient(endpoint, accessKeyId, accessKeySecret);
        Date expiration = new Date(new Date().getTime() + 3600 * 1000);
        String fileName = file;
        //原始访问地址需要获取文件名
        if(file.startsWith("http:")){
            fileName = file.substring(file.lastIndexOf("/") + 1);
        }
        URL url = client.generatePresignedUrl(privateBucket, fileName, expiration);
        return url.toString();
    }
}
