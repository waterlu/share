package cn.zjhf.kingold.trade.client;

import cn.zjhf.kingold.common.param.ParamVO;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
 * @author lutiehua
 * @date 2017/12/18
 */
public class ProductRemainDTO extends ParamVO {

    /**
     * 用户UUID
     *
     */
    @ApiModelProperty(value = "用户UUID", required = true)
    private String userUuid;

    /**
     * 订单号
     *
     */
    @ApiModelProperty(value = "订单号", required = true)
    private String orderBillCode;

    /**
     * 募集金额
     */
    @NotNull
    @ApiModelProperty(value = "募集金额", required = true)
    private BigDecimal amount;

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getOrderBillCode() {
        return orderBillCode;
    }

    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
}
