package cn.zjhf.kingold.trade.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class AccountBaofoo implements Serializable {
    /**
     * 自增ID
     */
    private Long accountBaofooId;

    /**
     * 账户UUID
     */
    private String accountUuid;

    /**
     * 托管机构用户账号授权状态
     */
    private Byte accountAuthStatus;

    /**
     * 绑定的银行卡信息（JSON）
     */
    private String bankCardInfo;

    private Byte deleteFlag;

    private Date createTime;

    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public Long getAccountBaofooId() {
        return accountBaofooId;
    }

    public void setAccountBaofooId(Long accountBaofooId) {
        this.accountBaofooId = accountBaofooId;
    }

    public String getAccountUuid() {
        return accountUuid;
    }

    public void setAccountUuid(String accountUuid) {
        this.accountUuid = accountUuid;
    }

    public Byte getAccountAuthStatus() {
        return accountAuthStatus;
    }

    public void setAccountAuthStatus(Byte accountAuthStatus) {
        this.accountAuthStatus = accountAuthStatus;
    }

    public String getBankCardInfo() {
        return bankCardInfo;
    }

    public void setBankCardInfo(String bankCardInfo) {
        this.bankCardInfo = bankCardInfo;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}