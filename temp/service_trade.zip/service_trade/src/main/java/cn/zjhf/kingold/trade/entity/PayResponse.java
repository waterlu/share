package cn.zjhf.kingold.trade.entity;

/**
 * Created by DELL on 2017/4/26.
 */
public class PayResponse {

    public static final String OK = "200";

    public static final String SUCCESS = "成功";

    private String code;

    private String msg;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    @Override
    public String toString() {
        return "PayResponse{" +
                "code='" + code + '\'' +
                ", msg='" + msg + '\'' +
                '}';
    }
}
