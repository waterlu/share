package cn.zjhf.kingold.trade.message;

import java.util.Date;

/**
 * Created by lutiehua on 2017/6/2.
 */
public class TradePaymentMessage {
    /**
     * 产品类型
     */
    private String productType;

    /**
     * 订单编号
     */
    private String orderBillCode;

    /**
     * 消息产生的时间
     */
    private Date createTime;

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getOrderBillCode() {
        return orderBillCode;
    }

    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

}
