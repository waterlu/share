package cn.zjhf.kingold.trade.exception;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.constant.TradeStatusMsg;

/**
 * 用户未完成绑卡开户操作
 *
 * @author lutiehua
 * @date 2018/3/9
 */
public class UserVerifyStatusException extends BusinessException {

    public UserVerifyStatusException() {
        super(TradeStatusMsg.USER_VERIFY_STATUS_WRONG_CODE, TradeStatusMsg.USER_VERIFY_STATUS_WRONG_MSG, true);
    }

}
