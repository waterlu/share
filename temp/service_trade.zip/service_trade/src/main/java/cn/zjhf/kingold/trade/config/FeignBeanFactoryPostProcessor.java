package cn.zjhf.kingold.trade.config;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.stereotype.Component;

import java.util.Arrays;

/**
 * 没有这个，单元测试完成后会抛出BeanCreationNotAllowedException异常
 * <p>org.springframework.beans.factory.BeanCreationNotAllowedException:
 * Error creating bean with name 'eurekaAutoServiceRegistration':
 * Singleton bean creation not allowed while singletons of this factory are in destruction
 * (Do not request a bean from a BeanFactory in a destroy method implementation!)</p>
 * <p>详见https://github.com/spring-cloud/spring-cloud-netflix/issues/1952</p>
 * <p>The root cause is when closing ApplicationContext, it will destroy all singleton bean,
 * eurekaAutoServiceRegistration is destroyed first, then feignContext.
 * When destroy feignContext, it will close the ApplicationContext associated with each FeignClient.
 * Since eurekaAutoServiceRegistration listen on ContextClosedEvent, those events will be sent to that bean.
 * Unfortunately because it has been destroyed, so we got the above exception (try to create bean in destruction).</p>
 * <p>简单说就是让feignContext在eurekaServiceRegistry之前释放，如果eurekaServiceRegistry先释放就抛异常</p>
 *
 * @author lutiehua
 * @date 2018/3/12
 */
@Component
public class FeignBeanFactoryPostProcessor implements BeanFactoryPostProcessor {

    @Override
    public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {
        if (containsBeanDefinition(beanFactory, "feignContext", "eurekaAutoServiceRegistration")) {
            BeanDefinition bd = beanFactory.getBeanDefinition("feignContext");
            bd.setDependsOn("eurekaAutoServiceRegistration");
        }
    }

    private boolean containsBeanDefinition(ConfigurableListableBeanFactory beanFactory, String... beans) {
        return Arrays.stream(beans).allMatch(b -> beanFactory.containsBeanDefinition(b));
    }

}
