package cn.zjhf.kingold.trade.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author
 */
public class TradeInvestSummary implements Serializable {
    /**
     * 放款申请编号,自增ID
     */
    private Long tradeInvestSummaryUuid;

    /**
     * 批次号
     */
    private String batchNo;

    /**
     * 产品UUID
     */
    private String productUuid;

    /**
     * 产品编码
     */
    private String productCode;

    /**
     * 产品类型
     */
    private String productType;

    /**
     * 产品简称
     */
    private String productAbbrName;

    /**
     * 募集总笔数
     */
    private BigDecimal raiseCount;

    /**
     * 募集总金额 = 募集金额_客户缴纳部分 + 募集金额_平台营销费用部分
     */
    private BigDecimal raiseAmount;

    /**
     * 募集金额_客户缴纳部分
     */
    private BigDecimal raiseInvestorAmount;

    /**
     * 募集金额_平台营销费用部分
     */
    private BigDecimal raisePlatformAmount;

    /**
     * 平台服务费
     */
    private BigDecimal platformServiceFee;

    /**
     * 交易所管理费
     */
    private BigDecimal exchangeManageFee;

    /**
     * 用户UUID
     */
    private String outUserUuid;

    /**
     * 账户UUID
     */
    private String outAccountUuid;

    /**
     * 托管机构用户账号
     */
    private String outAccountNo;

    /**
     * 对手方用户UUID
     */
    private String inUserUuid;

    /**
     * 对手方账户UUID
     */
    private String inAccountUuid;

    /**
     * 对手方托管机构用户账号
     */
    private String inAccountNo;

    /**
     * 处理状态: -1审批失败；1待审核；2审核通过; 3已兑付
     */
    private Byte transactionStatus;

    /**
     * 审核人
     */
    private String auditOperator;

    /**
     * 审核时间
     */
    private Date auditTime;

    /**
     * 审核意见
     */
    private String auditOpinion;

    /**
     * 兑付人
     */
    private String payedOperator;

    /**
     * 兑付时间
     */
    private Date payedTime;

    /**
     * 签名
     */
    private String signature;

    /**
     * 删除标记 0未删除，1已删除
     */
    private Byte deleteFlag;

    private Date createTime;

    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public Long getTradeInvestSummaryUuid() {
        return tradeInvestSummaryUuid;
    }

    public void setTradeInvestSummaryUuid(Long tradeInvestSummaryUuid) {
        this.tradeInvestSummaryUuid = tradeInvestSummaryUuid;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getProductAbbrName() {
        return productAbbrName;
    }

    public void setProductAbbrName(String productAbbrName) {
        this.productAbbrName = productAbbrName;
    }

    public BigDecimal getRaiseCount() {
        return raiseCount;
    }

    public void setRaiseCount(BigDecimal raiseCount) {
        this.raiseCount = raiseCount;
    }

    public BigDecimal getRaiseAmount() {
        return raiseAmount;
    }

    public void setRaiseAmount(BigDecimal raiseAmount) {
        this.raiseAmount = raiseAmount;
    }

    public BigDecimal getRaiseInvestorAmount() {
        return raiseInvestorAmount;
    }

    public void setRaiseInvestorAmount(BigDecimal raiseInvestorAmount) {
        this.raiseInvestorAmount = raiseInvestorAmount;
    }

    public BigDecimal getRaisePlatformAmount() {
        return raisePlatformAmount;
    }

    public void setRaisePlatformAmount(BigDecimal raisePlatformAmount) {
        this.raisePlatformAmount = raisePlatformAmount;
    }

    public BigDecimal getPlatformServiceFee() {
        return platformServiceFee;
    }

    public void setPlatformServiceFee(BigDecimal platformServiceFee) {
        this.platformServiceFee = platformServiceFee;
    }

    public BigDecimal getExchangeManageFee() {
        return exchangeManageFee;
    }

    public void setExchangeManageFee(BigDecimal exchangeManageFee) {
        this.exchangeManageFee = exchangeManageFee;
    }

    public String getOutUserUuid() {
        return outUserUuid;
    }

    public void setOutUserUuid(String outUserUuid) {
        this.outUserUuid = outUserUuid;
    }

    public String getOutAccountUuid() {
        return outAccountUuid;
    }

    public void setOutAccountUuid(String outAccountUuid) {
        this.outAccountUuid = outAccountUuid;
    }

    public String getOutAccountNo() {
        return outAccountNo;
    }

    public void setOutAccountNo(String outAccountNo) {
        this.outAccountNo = outAccountNo;
    }

    public String getInUserUuid() {
        return inUserUuid;
    }

    public void setInUserUuid(String inUserUuid) {
        this.inUserUuid = inUserUuid;
    }

    public String getInAccountUuid() {
        return inAccountUuid;
    }

    public void setInAccountUuid(String inAccountUuid) {
        this.inAccountUuid = inAccountUuid;
    }

    public String getInAccountNo() {
        return inAccountNo;
    }

    public void setInAccountNo(String inAccountNo) {
        this.inAccountNo = inAccountNo;
    }

    public Byte getTransactionStatus() {
        return transactionStatus;
    }

    public void setTransactionStatus(Byte transactionStatus) {
        this.transactionStatus = transactionStatus;
    }

    public String getAuditOperator() {
        return auditOperator;
    }

    public void setAuditOperator(String auditOperator) {
        this.auditOperator = auditOperator;
    }

    public Date getAuditTime() {
        return auditTime;
    }

    public void setAuditTime(Date auditTime) {
        this.auditTime = auditTime;
    }

    public String getAuditOpinion() {
        return auditOpinion;
    }

    public void setAuditOpinion(String auditOpinion) {
        this.auditOpinion = auditOpinion;
    }

    public String getPayedOperator() {
        return payedOperator;
    }

    public void setPayedOperator(String payedOperator) {
        this.payedOperator = payedOperator;
    }

    public Date getPayedTime() {
        return payedTime;
    }

    public void setPayedTime(Date payedTime) {
        this.payedTime = payedTime;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}