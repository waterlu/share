package cn.zjhf.kingold.trade.entity;

/**
 * Created by DELL on 2017/4/26.
 */
public class BankCard {
    private String baofooCardId;//绑卡id
    private String bankUserName;//姓名
    private  String bankUserIDCardNo;//身份证号
    private  String bankUserCardNo;//银行卡号
    private String bankUserPhone;//银行预留手机号

    public String getBankUserName() {
        return bankUserName;
    }

    public void setBankUserName(String bankUserName) {
        this.bankUserName = bankUserName;
    }

    public String getBankUserIDCardNo() {
        return bankUserIDCardNo;
    }

    public void setBankUserIDCardNo(String bankUserIDCardNo) {
        this.bankUserIDCardNo = bankUserIDCardNo;
    }

    public String getBankUserCardNo() {
        return bankUserCardNo;
    }

    public void setBankUserCardNo(String bankUserCardNo) {
        this.bankUserCardNo = bankUserCardNo;
    }

    public String getBankUserPhone() {
        return bankUserPhone;
    }

    public void setBankUserPhone(String bankUserPhone) {
        this.bankUserPhone = bankUserPhone;
    }

    public String getBaofooCardId() {
        return baofooCardId;
    }

    public void setBaofooCardId(String baofooCardId) {
        this.baofooCardId = baofooCardId;
    }
}
