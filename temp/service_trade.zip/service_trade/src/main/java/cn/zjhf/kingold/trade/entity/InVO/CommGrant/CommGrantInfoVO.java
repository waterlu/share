package cn.zjhf.kingold.trade.entity.InVO.CommGrant;

import cn.zjhf.kingold.trade.utils.DataUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by zhangyijie on 2018/2/2.
 */
public class CommGrantInfoVO {

    /**
     * 错误消息，key行号，value错误消息
     */
    private Map<Integer, String> errMap;

    /**
     * 生成礼券列表
     */
    private List<CashCouponGrantVO> cashCouponGrantList;

    /**
     * 生成现金红包列表
     */
    private List<RedPacketGrantVO> redPacketGrantList;

    public CommGrantInfoVO() {
        errMap = new HashMap<>();
        cashCouponGrantList = new ArrayList<>();
        redPacketGrantList = new ArrayList<>();
    }

    public void setErrMess(int rowNum, String errMess) {
        if((rowNum<0) || DataUtils.isEmpty(errMess)) {
            return;
        }

        if(!errMap.containsKey(rowNum)) {
            errMap.put(rowNum, errMess);
        }else {
            String value = errMap.get(rowNum);
            value += "; ";
            value += errMess;
            errMap.replace(rowNum, value);
        }
    }

    public void addCashCoupon(int rowNum, Byte activityNum, String phoneNumber, String ccCode) {
        CashCouponGrantVO cashCouponGrant = new CashCouponGrantVO();
        cashCouponGrant.setRowNum(rowNum);
        cashCouponGrant.setActivityNum(activityNum);
        cashCouponGrant.setPhoneNumber(phoneNumber);
        cashCouponGrant.setCcCode(ccCode);

        cashCouponGrantList.add(cashCouponGrant);
    }

    public void addRedPacketGrant(int rowNum, Byte activityNum, String phoneNumber, double amt) {
        RedPacketGrantVO redPacketGrant = new RedPacketGrantVO();
        redPacketGrant.setRowNum(rowNum);
        redPacketGrant.setActivityNum(activityNum);
        redPacketGrant.setPhoneNumber(phoneNumber);
        redPacketGrant.setRedPacketAmt(amt);

        redPacketGrantList.add(redPacketGrant);
    }

    public Map<Integer, String> getErrMap() {
        return errMap;
    }

    public List<CashCouponGrantVO> getCashCouponGrantList() {
        return cashCouponGrantList;
    }

    public List<RedPacketGrantVO> getRedPacketGrantList() {
        return redPacketGrantList;
    }

    @Override
    public String toString() {
        return "CommGrantInfoVO{" +
                "errMap=" + errMap +
                ", cashCouponGrantList=" + cashCouponGrantList +
                ", redPacketGrantList=" + redPacketGrantList +
                '}';
    }
}
