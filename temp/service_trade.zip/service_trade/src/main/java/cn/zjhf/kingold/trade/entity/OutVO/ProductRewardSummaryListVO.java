package cn.zjhf.kingold.trade.entity.OutVO;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangyijie on 2017/6/5.
 */
@ApiModel(value = "ProductRewardSummaryListVO", description = "定期产品奖励记录_列表")
public class ProductRewardSummaryListVO extends ParamVO {
    @ApiModelProperty(required = true, value = "总记录数")
    private int totalCount;

    @ApiModelProperty(required = true, value = "返回列表")
    private List<ProductRewardSummaryVO> items;

    public ProductRewardSummaryListVO() {
        totalCount = 0;
        items = new ArrayList<ProductRewardSummaryVO>();
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public List<ProductRewardSummaryVO> getItems() {
        return items;
    }

    public void setItems(List<ProductRewardSummaryVO> items) {
        this.items = items;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("totalCount:" + DataUtils.toString(totalCount) + ", ");
        sb.append("items:" + DataUtils.toString(items));
        return sb.toString();
    }
}
