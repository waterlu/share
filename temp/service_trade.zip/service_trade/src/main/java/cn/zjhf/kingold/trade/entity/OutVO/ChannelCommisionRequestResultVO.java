package cn.zjhf.kingold.trade.entity.OutVO;

import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * Created by zhangyijie on 2017/10/13.
 */
public class ChannelCommisionRequestResultVO {
    @ApiModelProperty(required = true, value = "请求周期，格式: YYYY.MM")
    private String requestCycle;

    @ApiModelProperty(required = true, value = "总佣金")
    private double commisionAmount;

    public String getRequestCycle() {
        return requestCycle;
    }

    public void setRequestCycle(String requestCycle) {
        this.requestCycle = requestCycle;
    }

    public double getCommisionAmount() {
        return commisionAmount;
    }

    public void setCommisionAmount(double commisionAmount) {
        this.commisionAmount = commisionAmount;
    }

    @Override
    public String toString() {
        return "ChannelCommisionRequestResultVO{" +
                "requestCycle='" + requestCycle + '\'' +
                ", commisionAmount=" + commisionAmount +
                '}';
    }
}
