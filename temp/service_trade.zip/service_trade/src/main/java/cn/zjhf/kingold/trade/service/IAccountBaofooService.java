package cn.zjhf.kingold.trade.service;


import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.dto.AccountDTO;
import cn.zjhf.kingold.trade.dto.SendCashDTO;
import cn.zjhf.kingold.trade.entity.OutVO.CommItemListVO;
import cn.zjhf.kingold.trade.vo.AccountVO;
import cn.zjhf.kingold.trade.vo.SendCashVO;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;


/**
 * Created by wangxun on 2016/11/04.
 * Copyright by zjinv
 */
public interface IAccountBaofooService {

    /**
     * 通过userID获取用户信息
     * @return 用户
     * @throws BusinessException 业务异常
     */
    public Map get(Map params) throws BusinessException;

    public Map insert(Map userInfo) throws BusinessException;

    Map insertAll(Map params) throws BusinessException;

    public int update(Map userInfo) throws BusinessException;

    int updateAll(Map params) throws BusinessException;

    public Integer delete(Map params) throws BusinessException;

    List<Map> getList(Map userMap) throws BusinessException;

    String openAccountWithAuth(Map paramMap) throws BusinessException ;


    Integer getCount(Map userMap) throws BusinessException;

    /**
     * 企业开户
     *
     * @param paramMap 参数 userId,userName,userPhone,bankUserCardNo,userIdCardNumber,openChanne
     * @throws BusinessException
     */
    String enterpriseOpenAccount(Map paramMap) throws BusinessException;

    void bindBankCard(Map paramMap) throws BusinessException;

    void unBindBankCard(String userUuid, Map paramMap) throws BusinessException;

    String openAccount(Map paramMap) throws BusinessException;

    List getBankCardList(Map paramMap) throws BusinessException;

    Map getBaofooAndAccount(Map paramMap) throws BusinessException;
    /**
     * 获取账户资产查询列表
     * @return
     * @throws BusinessException
     */
    CommItemListVO<AccountVO> getAccountList(AccountDTO dto) throws BusinessException;

    /**
     * 获取全部提现数据
     * @param dto
     * @return
     * @throws BusinessException
     */
    SendCashVO getSendCashInfo(SendCashDTO dto) throws BusinessException;

    /**
     * 运营后台全部提现
     * @param dto
     * @return
     * @throws BusinessException
     */
    Integer sendcCash(SendCashDTO dto) throws BusinessException;

}