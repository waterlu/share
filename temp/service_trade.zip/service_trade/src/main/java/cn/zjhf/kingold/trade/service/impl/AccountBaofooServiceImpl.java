package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.common.utils.MapUtils;
import cn.zjhf.kingold.service_consumer.service.UserServiceConsumer;
import cn.zjhf.kingold.trade.constant.AccountStatusMsg;
import cn.zjhf.kingold.trade.constant.AccountType;
import cn.zjhf.kingold.trade.constant.PayResponseCode;
import cn.zjhf.kingold.trade.constant.URL;
import cn.zjhf.kingold.trade.dto.AccountDTO;
import cn.zjhf.kingold.trade.dto.SendCashDTO;
import cn.zjhf.kingold.trade.entity.BankCard;
import cn.zjhf.kingold.trade.entity.OutVO.CommItemListVO;
import cn.zjhf.kingold.trade.entity.TradeRecharge;
import cn.zjhf.kingold.trade.entity.UserUnbindBankCardChangeLog;
import cn.zjhf.kingold.trade.persistence.dao.AccountBaofooCustodyMapper;
import cn.zjhf.kingold.trade.persistence.dao.AccountMapper;
import cn.zjhf.kingold.trade.persistence.dao.AccountTransactionMapper;
import cn.zjhf.kingold.trade.persistence.dao.UserUnbindBankCardChangeLogMapper;
import cn.zjhf.kingold.trade.service.IAccountBaofooService;
import cn.zjhf.kingold.trade.service.IInvestorRemoteService;
import cn.zjhf.kingold.trade.service.IPayService;
import cn.zjhf.kingold.trade.service.ITradeService;
import cn.zjhf.kingold.trade.utils.MapParamUtils;
import cn.zjhf.kingold.trade.utils.PropertyDescriptionUtils;
import cn.zjhf.kingold.trade.vo.AccountVO;
import cn.zjhf.kingold.trade.vo.SendCashVO;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Created by wangxun on 2016/11/04.
 * Copyright by zjinv
 */
@Service
public class AccountBaofooServiceImpl implements IAccountBaofooService {
    private static final Logger LOGGER = LoggerFactory.getLogger(AccountBaofooServiceImpl.class);

    @Autowired
    private AccountBaofooCustodyMapper accountBaofooMapper;

    @Autowired
    private AccountMapper accountMapper;

    @Autowired
    private UserServiceConsumer userServiceConsumer;

    @Autowired
    private AccountTransactionMapper accountTransactionMapper;

    @Autowired
    private IPayService payService;

    @Autowired
    private IInvestorRemoteService investorRemoteService;

    @Autowired
    private UserUnbindBankCardChangeLogMapper userUnbindBankCardChangeLogMapper;

    @Autowired
    private ITradeService tradeService;

    @Value("${system.run.model}")
    public String runModel ;

    @Value("${app.admin.verify.code}")
    public String adminVerifyCode;

    @Value("${open.baofoo.interface}")
    public boolean isOpenBaofooInterface;

    private final static int NEED_BIND_CARD_STATUS = 2;


    public AccountBaofooServiceImpl() {
    }

    /**
     * 注册宝付，自动授权
     *
     * @param paramMap 参数 userId,userName,userPhone,bankUserCardNo,userIdCardNumber,openChanne
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = {BusinessException.class, RuntimeException.class})
    public String openAccountWithAuth(Map paramMap) throws BusinessException {
        LOGGER.info("openAccount isOpenBaofooInterface："+isOpenBaofooInterface);
        if(isOpenBaofooInterface) {
            boolean isBind = paramMap.get("smsCode") == null ? false : true;
            ResponseResult rr;
            LOGGER.info("openAccount isBind："+isBind);
            if (isBind) {
                rr= payService.bindPlatform(MapParamUtils.getStringInMap( paramMap,"userPhone"), MapParamUtils.getLongInMap( paramMap,"userId"),
                        MapParamUtils.getStringInMap( paramMap,"userName"), MapParamUtils.getStringInMap( paramMap,"userIdCardNumber"), MapParamUtils.getStringInMap( paramMap,"smsCode"), 1);
            } else {
                rr= payService.createAccount(MapParamUtils.getStringInMap( paramMap,"userPhone"), MapParamUtils.getLongInMap( paramMap,"userId"),
                        MapParamUtils.getStringInMap( paramMap,"userName"), MapParamUtils.getStringInMap( paramMap,"userIdCardNumber"), 1);
            }
            if (rr.getCode() == PayResponseCode.ERROR_USER_EXIST_CODE) {
                LOGGER.error("用户信息在宝付中已经存在，尝试从新创建此用户下的账户");
                throw new BusinessException(rr.getCode(), rr.getMsg(), true);
            } else if (rr.getCode() == PayResponseCode.ERROR_DEAL_CODE) {
                throw new BusinessException(rr.getCode(), "身份信息有误，请重新填写", true);
            } else if (rr.getCode() != 200) {
                throw new BusinessException(rr.getCode(), rr.getMsg(), true);
            }
        }

        paramMap.put("accountNo",MapParamUtils.getStringInMap( paramMap,"userId"));
        Map checkAccountParam = new HashMap();
        checkAccountParam.put("accountNo",MapParamUtils.getStringInMap( paramMap,"userId"));
        //判断创建账户是否存在。
        if(checkAccountHasExist(checkAccountParam)){
            throw new BusinessException(AccountStatusMsg.ACCOUNT_HAS_EXIST_CODE,AccountStatusMsg.ACCOUNT_HAS_EXIST,true);
        }

        String uuid = UUID.randomUUID().toString().replace("-","");
        paramMap.put("accountUuid",uuid);
        if(StringUtils.isBlank(MapParamUtils.getStringInMap( paramMap,"accountType"))) {
            paramMap.put("accountType", AccountType.ACCOUNT_TYPE_INVESTOR);//设置账户类型为个人账户
        }


        //创建账户信息
        LOGGER.info("创建账户信息");
        int accountInsert = accountMapper.insert(paramMap);

        if(paramMap.get("bankCardInfo") == null ){
            paramMap.put("bankCardInfo","[]");
        }
        //创建宝付账户信息
        LOGGER.info("创建宝付账户信息");
        int accountBaofooInsert = accountBaofooMapper.insert(paramMap);

        if(accountInsert != 1 ||  accountBaofooInsert != 1){
            throw new BusinessException(AccountStatusMsg.INNER_ERROR_CODE,AccountStatusMsg.INNER_ERROR,true);
        }
        return uuid;
    }


    /**
     * 老版本开户不进行自动授权
     *
     * @param paramMap 参数 userId,userName,userPhone,bankUserCardNo,userIdCardNumber,openChanne
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = {BusinessException.class, RuntimeException.class})
    public String openAccount(Map paramMap) throws BusinessException {
        LOGGER.info("openAccount isOpenBaofooInterface："+isOpenBaofooInterface);
        if(isOpenBaofooInterface) {
            boolean isBind = paramMap.get("smsCode") == null ? false : true;
            ResponseResult rr;
            LOGGER.info("openAccount isBind："+isBind);
            if (isBind) {
                rr= payService.bindPlatform(MapParamUtils.getStringInMap( paramMap,"userPhone"), MapParamUtils.getLongInMap( paramMap,"userId"),
                        MapParamUtils.getStringInMap( paramMap,"userName"), MapParamUtils.getStringInMap( paramMap,"userIdCardNumber"), MapParamUtils.getStringInMap( paramMap,"smsCode"), 0);
            } else {
                rr= payService.createAccount(MapParamUtils.getStringInMap( paramMap,"userPhone"), MapParamUtils.getLongInMap( paramMap,"userId"),
                        MapParamUtils.getStringInMap( paramMap,"userName"), MapParamUtils.getStringInMap( paramMap,"userIdCardNumber"), 0);
            }
            if (rr.getCode() == PayResponseCode.ERROR_USER_EXIST_CODE) {
                LOGGER.error("用户信息在宝付中已经存在，尝试从新创建此用户下的账户");
                throw new BusinessException(rr.getCode(), rr.getMsg(), true);
            }else if (rr.getCode() != 200) {
                throw new BusinessException(rr.getCode(), rr.getMsg(), true);
            }
        }

        paramMap.put("accountNo",MapParamUtils.getStringInMap( paramMap,"userId"));
        Map checkAccountParam = new HashMap();
        checkAccountParam.put("accountNo",MapParamUtils.getStringInMap( paramMap,"userId"));
        //判断创建账户是否存在。
        if(checkAccountHasExist(checkAccountParam)){
            throw new BusinessException(AccountStatusMsg.ACCOUNT_HAS_EXIST_CODE,AccountStatusMsg.ACCOUNT_HAS_EXIST,true);
        }

        String uuid = UUID.randomUUID().toString().replace("-","");
        paramMap.put("accountUuid",uuid);
        if(StringUtils.isBlank(MapParamUtils.getStringInMap( paramMap,"accountType"))) {
            paramMap.put("accountType", AccountType.ACCOUNT_TYPE_INVESTOR);//设置账户类型为个人账户
        }


        //创建账户信息
        LOGGER.info("创建账户信息");
        int accountInsert = accountMapper.insert(paramMap);

        if(paramMap.get("bankCardInfo") == null ){
            paramMap.put("bankCardInfo","[]");
        }
        //创建宝付账户信息
        LOGGER.info("创建宝付账户信息");
        int accountBaofooInsert = accountBaofooMapper.insert(paramMap);

        if(accountInsert != 1 ||  accountBaofooInsert != 1){
            throw new BusinessException(AccountStatusMsg.INNER_ERROR_CODE,AccountStatusMsg.INNER_ERROR,true);
        }
        return uuid;
    }


    @Override
    @Transactional(rollbackFor = {BusinessException.class, RuntimeException.class})
    /**
     * 企业开户
     *
     * @param paramMap 参数 userId,userName,userPhone,bankUserCardNo,userIdCardNumber,openChanne
     * @throws BusinessException
     */
    public String enterpriseOpenAccount(Map paramMap) throws BusinessException {
        LOGGER.info("openAccount isOpenBaofooInterface："+isOpenBaofooInterface);
        if(isOpenBaofooInterface) {

            ResponseResult rr = null;//payService.createAccount((String)paramMap.get("userPhone"),Long.parseLong((String)paramMap.get("userId")),(String)paramMap.get("userName"),(String)paramMap.get("userIdCardNumber"));
            if ("BD009|该会员已经存在".equals(rr.getMsg())) {
                LOGGER.error("用户信息在宝付中已经存在，尝试从新创建此用户下的账户");
            }else if(rr.getCode() != 200){
                throw new BusinessException(rr.getCode(),rr.getMsg(),true);
            }

        }

        paramMap.put("accountNo",MapParamUtils.getStringInMap( paramMap,"userId"));

        Map checkAccountParam = new HashMap();
        checkAccountParam.put("accountNo",MapParamUtils.getStringInMap( paramMap,"userId"));
        //判断创建账户是否存在。
        if(checkAccountHasExist(checkAccountParam)){
            throw new BusinessException(AccountStatusMsg.ACCOUNT_HAS_EXIST_CODE,AccountStatusMsg.ACCOUNT_HAS_EXIST,true);
        }


        String uuid = UUID.randomUUID().toString().replace("-","");
        paramMap.put("accountUuid",uuid);
        if(StringUtils.isBlank(MapParamUtils.getStringInMap( paramMap,"accountType"))) {
            paramMap.put("accountType", AccountType.ACCOUNT_TYPE_FINANCIER);//设置账户类型为个人账户
        }

        //创建账户信息
        LOGGER.info("创建账户信息");
        int accountInsert = accountMapper.insert(paramMap);

        if(paramMap.get("bankCardInfo") == null ){
            paramMap.put("bankCardInfo","[]");
        }
        //创建宝付账户信息
        LOGGER.info("创建宝付账户信息");
        int accountBaofooInsert = accountBaofooMapper.insert(paramMap);

        if(accountInsert != 1 ||  accountBaofooInsert != 1){
            throw new BusinessException(AccountStatusMsg.INNER_ERROR_CODE,AccountStatusMsg.INNER_ERROR,true);
        }
        return uuid;
    }


    /**
     * 判断创建账户是否存在
     * @param paramMap 参数选填 accountNo，accountUuid,userUuid
     * @return
     */
    private boolean checkAccountHasExist(Map paramMap){
        List accountList = accountBaofooMapper.getList(paramMap);
        if(accountList != null && accountList.size() > 0){
            return true;
        }else{
            return false;
        }

    }

    /**
     * 绑卡
     *
     * @param paramMap 参数 userUuid,accountNo,userName,verifyCode,bankUserPhone,bankUserCardNo,bankUserIDCardNo
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = {BusinessException.class, RuntimeException.class})
    public void bindBankCard(Map paramMap) throws BusinessException {
        LOGGER.info("bindBankCard isOpenBaofooInterface："+isOpenBaofooInterface);
        BankCard bankCard = new BankCard();
        if(isOpenBaofooInterface) {

            ResponseResult rr = null;
            rr = payService.bindBankCard(Long.parseLong(MapParamUtils.getStringInMap(paramMap,"accountNo")), MapParamUtils.getStringInMap(paramMap,"bankUserPhone"),
                    MapParamUtils.getStringInMap(paramMap,"bankUserCardNo"), MapParamUtils.getStringInMap(paramMap,"verifyCode"));

            if (rr.getCode() != 200) {
                    throw new BusinessException(rr.getCode(), rr.getMsg(), true);
            }
            bankCard.setBaofooCardId(((HashMap)rr.getData()).get("cardID").toString());
            LOGGER.info("baofoo bindBankCard success");
        }
        Map accountParam = new HashMap();
        accountParam.put("userUuid",paramMap.get("userUuid"));
        accountParam.put("accountType", AccountType.ACCOUNT_TYPE_INVESTOR);

        LOGGER.info("bindBankCard 获取账户列表");
        List accountList = accountMapper.getList(accountParam);
        if(accountList != null && accountList.size() == 1){
            Map accountMap = (Map)accountList.get(0);
            paramMap.put("accountUuid",accountMap.get("accountUuid"));
        }else{
            throw new BusinessException(AccountStatusMsg.ACCOUNT_NOT_EXIST_CODE,AccountStatusMsg.ACCOUNT_NOT_EXIST,true);
        }

        bankCard.setBankUserPhone(MapParamUtils.getStringInMap( paramMap,"bankUserPhone"));
        bankCard.setBankUserCardNo(MapParamUtils.getStringInMap( paramMap,"bankUserCardNo"));
        bankCard.setBankUserIDCardNo(MapParamUtils.getStringInMap( paramMap,"bankUserIDCardNo"));
        bankCard.setBankUserName(MapParamUtils.getStringInMap( paramMap,"userName"));

        String bankCardJson = JSON.toJSONString(bankCard);
        if(StringUtils.isBlank(MapParamUtils.getStringInMap( paramMap,"accountUuid")) ){
            throw new BusinessException(AccountStatusMsg.REQUEST_PARAM_ERROR_CODE,AccountStatusMsg.REQUEST_PARAM_ERROR,true);
        }
        LOGGER.info("bindBankCard 检查银行卡是否绑定");
        Map accountBaofoo = accountBaofooMapper.checkBankCard(paramMap);
        if( accountBaofoo != null ){
            throw new BusinessException(AccountStatusMsg.BANK_CARD_HAS_EXIST_CODE,AccountStatusMsg.BANK_CARD_HAS_EXIST,true);
        }
        Map addBankCard = new HashMap();
        addBankCard.put("accountUuid",paramMap.get("accountUuid"));
        addBankCard.put("bankCardJson",bankCardJson);
        accountBaofooMapper.insertBankCard(addBankCard);

    }

    /**
     * 解绑卡
     *
     * @param userUuid
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = {BusinessException.class, RuntimeException.class})
    public void unBindBankCard(String userUuid, Map param) throws BusinessException {
        LOGGER.info("unBindBankCard careful must unbind baofoo first.");
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("userUuid", userUuid);
        Map account = accountMapper.get(paramMap);
        if( account == null ){
            throw new BusinessException(AccountStatusMsg.ACCOUNT_NOT_EXIST_CODE,AccountStatusMsg.ACCOUNT_NOT_EXIST,true);
        }
        String accountUuid = MapParamUtils.getStringInMap(account,"accountUuid");
        paramMap.put("accountUuid", accountUuid);
        Map accountBaofoo = accountBaofooMapper.checkBankCard(paramMap);
        LOGGER.info("unBindBankCard log old data. account={}", JSONObject.toJSONString(accountBaofoo));
        int count = accountBaofooMapper.unBindBankCard(accountUuid);
        if (count != 1) {
            throw new BusinessException(AccountStatusMsg.INNER_ERROR_CODE,AccountStatusMsg.INNER_ERROR,true);
        }
        Map<String, Object> userParam = new HashMap<>();
        userParam.put("userVerifyStatus", NEED_BIND_CARD_STATUS);
        ResponseResult result = userServiceConsumer.put(String.format(URL.URL_USER_PUT, userUuid), userParam);
        if (!result.isSuccessful()) {
            LOGGER.info("unBindBankCard update user status error. result={}", result);
        }
        userUnbindBankCardChangeLogMapper.insert(new UserUnbindBankCardChangeLog(userUuid,accountBaofoo.get("bank_card_info").toString(),"客户需求",param.get("operator").toString()));
    }

    /**
     * 获取绑卡列表
     *
     * @param paramMap 参数选填：accountUuid，accountNo，userUuid，accountType，accountStatus
     * @return
     * @throws BusinessException
     */
    @Override
    public List<Map> getBankCardList(Map paramMap) throws BusinessException {
        LOGGER.info("获取绑卡列表");
        Map accountBaofoo = accountBaofooMapper.getBaofooAndAccount(paramMap);
        if(accountBaofoo != null) {
            return  (List<Map>) accountBaofoo.get("bankCardInfo");
        }
        return null;
    }

    /**
     * 获取账户和宝付信息列表
     *
     * @param paramMap 参数选填：accountUuid，accountNo，userUuid，accountType，accountStatus
     * @return
     * @throws BusinessException
     */
    @Override
    public Map getBaofooAndAccount(Map paramMap) throws BusinessException {
        LOGGER.info("getBaofooAndAccount");
        //远程获取用户信息
//        Map investor = investorRemoteService.getInvestorInfo(MapParamUtils.getStringInMap(paramMap,"userUuid"));
        Map accountBaofoo = accountBaofooMapper.getBaofooAndAccount(paramMap);
        if(MapUtils.isEmpty(accountBaofoo)){
            throw new BusinessException(AccountStatusMsg.ACCOUNT_NOT_EXIST_CODE,AccountStatusMsg.ACCOUNT_NOT_EXIST,true);
        }
        //增加资金总额，收益额总额，管理资产总额，我的佣金总额
        //资金总额 accountBaofoo.get("accountTotalAssets")
        //收益额总额（利息）
        //收益总额accountTotalInterests 为 accountAccumProfit  ================之后去掉================
        accountBaofoo.put("accountTotalInterests",accountBaofoo.get("accountAccumProfit"));

        //管理资产总额(已经作废)
        accountBaofoo.put("accountTotalManage",0.0);
        //我的佣金总额 accountBaofoo.get("accountCommission")
        return accountBaofoo;
    }

    /**
     * 获取宝付信息
     *
     * @param params 参数选填：accountUuid，accountNo
     * @return
     * @throws BusinessException
     */
    @Override
    public Map get(Map params) throws BusinessException {

        Map ui = accountBaofooMapper.get(params);
        if(ui == null || ui.isEmpty()){
            throw new BusinessException(AccountStatusMsg.REQUEST_PARAM_ERROR_CODE, AccountStatusMsg.REQUEST_PARAM_ERROR,true);
        }
        Map resultMap = PropertyDescriptionUtils.convertProperty(ui,MapParamUtils.getStringInMap( params,"properties"),MapParamUtils.getStringInMap( params,"desc"),PropertyDescriptionUtils.ACCOUNT_BAOFOO_DIC);
        return resultMap;
    }

    /**
     * 插入 宝付表
     * @param params
     * @return
     * @throws BusinessException
     */
    @Override
    public Map insert(Map params) throws BusinessException {
        String userPhone = MapParamUtils.getStringInMap( params,"userPhone");
        if(StringUtils.isNotBlank(userPhone)){
            Map paramTemp = new HashMap();
            paramTemp.put("userPhone",userPhone);
            if(null != get(paramTemp)){
//                throw new BusinessException(AccountStatusMsg.REGISTER_PHONE_IS_EXIST_CODE, AccountStatusMsg.REGISTER_PHONE_IS_EXIST,true);
            }
        }
        params.put("userUuid", UUID.randomUUID().toString().replace("-",""));
        accountBaofooMapper.insert(params);
        return params;
    }

    /**
     * 插入 宝付表 和 账户表
     * @param params
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = {BusinessException.class, RuntimeException.class})
    public Map insertAll(Map params) throws BusinessException {
        LOGGER.info("insert account");
        accountMapper.insert(params);
        params.put("userUuid", UUID.randomUUID().toString().replace("-",""));
        LOGGER.info("insert accountBaofoo");
        accountBaofooMapper.insert(params);

        return params;
    }

    /**
     * 更新宝付表
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @Override
    public int update( Map params) throws BusinessException {
        return accountBaofooMapper.update(params);
    }

    /**
     * 更新宝付表 和 账户表
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = {BusinessException.class, RuntimeException.class})
    public int updateAll(Map params) throws BusinessException {
        LOGGER.info("update account");
        //如果更新了account表字段
        accountMapper.update(params);
        //如果更新了account_baofoo_custody字段
        LOGGER.info("update accountBaofoo");
        return accountBaofooMapper.update(params);
    }

    /**
     * 删除宝付表记录
     * @param params 参数必填：accountUuid
     * @return
     * @throws BusinessException
     */
    @Override
    public Integer delete(Map params) throws BusinessException {
        int num = accountBaofooMapper.delete(params);
        return num;
    }

    /**
     * 获取 宝付和账户表 列表
     * @param userMap 参数选填：accountUuid，accountNo，userUuid，accountType，accountStatus
     * @return
     * @throws BusinessException
     */
    @Override
    public List<Map> getList(Map userMap) throws BusinessException {
        List<Map> userList = accountBaofooMapper.getList(userMap);
        return userList;
    }

    /**
     * 获取 宝付和账户表 总数
     * @param userMap 参数选填：accountUuid，accountNo，userUuid，accountType，accountStatus
     * @return
     * @throws BusinessException
     */
    @Override
    public Integer getCount(Map userMap) throws BusinessException {
        Integer result = accountBaofooMapper.getCount(userMap);
        return result;
    }
    /**
     * 获取账户资产查询列表
     * @return
     * @throws BusinessException
     */
    @Override
    public CommItemListVO<AccountVO> getAccountList(AccountDTO dto) throws BusinessException{
        return new CommItemListVO<AccountVO>(accountBaofooMapper.getAccountCount(dto),accountBaofooMapper.getAccountList(dto));
    }
    /**
     * 获取全部提现数据
     * @param dto
     * @return
     * @throws BusinessException
     */
    @Override
    public SendCashVO getSendCashInfo(SendCashDTO dto) throws BusinessException{
        return accountBaofooMapper.getSendCashInfo(dto);
    }

    @Override
    public Integer sendcCash(SendCashDTO dto) throws BusinessException{
        AccountDTO seachDto = new AccountDTO();
        seachDto.setAccountType(AccountType.ACCOUNT_TYPE_INVESTOR);
        seachDto.setBalanceType(1);
        seachDto.setPageSize(1000);
        seachDto.setStartRow(0);
        List<AccountVO> list=accountBaofooMapper.getAccountList(seachDto);
        Map<String, Object> param = new HashedMap();
        param.put("callSystemID","1111");
        param.put("accountType",AccountType.ACCOUNT_TYPE_INVESTOR);
        Integer sussesCount = 0;
        Integer errorCount = 0;
        if(list != null && list.size() > 0){
            for(AccountVO vo:list){
                ResponseResult rr= new ResponseResult();
                BigDecimal rechargeAmount=vo.getAccountCashAmount();
                param.put("userUuid",vo.getUserUuid());
                if(rechargeAmount.doubleValue() <= 500000){
                    param.put("rechargeAmount",rechargeAmount);
                    rr=sendCash(param);
                }else{
                    int count=(int)Math.ceil(rechargeAmount.doubleValue()/500000);
                    for(int i = 1;i <= count;i++){
                        if(i<count){
                            param.put("rechargeAmount",500000);
                        }else{
                            param.put("rechargeAmount",rechargeAmount.subtract(BigDecimal.valueOf(500000).multiply(BigDecimal.valueOf(count-1))));
                        }
                        rr=sendCash(param);
                    }
                }
                if(rr.getCode() == ResponseCode.OK){
                    sussesCount++;
                }else{
                    LOGGER.info("运营后台：提现失败 Exception:{} errorCount:{}",rr.getMsg());
                    errorCount++;
                }
            }
        }
        LOGGER.error("运营后台 提现 sussesCount:{} errorCount:{}",sussesCount,errorCount);
        return sussesCount;
    }

    private ResponseResult sendCash( Map<String, Object> params)throws BusinessException{
        ResponseResult rr = new ResponseResult();
        try {
            LOGGER.info("运营后台：创建提现订单;params:{}",JSONObject.toJSONString(params));
            TradeRecharge tradeRecharge = tradeService.createRechargeOrder(params);
            LOGGER.info("运营后台：宝付 提现;params:{}",JSONObject.toJSONString(tradeRecharge));
            rr = tradeService.baofooWithDraw(tradeRecharge);
        }catch (Exception e){
            LOGGER.error("宝付 提现 Exception:{}",JSONObject.toJSONString(e));
        }
        if(rr.getCode() != ResponseCode.OK){
            LOGGER.error("宝付 提现 失败;params:{}",JSONObject.toJSONString(rr));
        }
        return rr;
    }
}