package cn.zjhf.kingold.trade.persistence.dao;

import cn.zjhf.kingold.trade.entity.OperationReport;
import cn.zjhf.kingold.trade.entity.OperationReportExample;
import cn.zjhf.kingold.trade.entity.OperationReportKey;
import java.util.List;
import java.util.Map;

import cn.zjhf.kingold.trade.utils.QueryUtils;
import cn.zjhf.kingold.trade.utils.ReportUtils;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface OperationReportMapper {
    long countByExample(OperationReportExample example);

    int deleteByExample(OperationReportExample example);

    int deleteByPrimaryKey(OperationReportKey key);

    int insert(OperationReport record);

    int insertSelective(OperationReport record);

    List<OperationReport> selectByExample(OperationReportExample example);

    OperationReport selectByPrimaryKey(OperationReportKey key);
	
    @Select("${condition}")
    List<Map> lstReportData(ReportUtils condition);


    @Select("${condition}")
    List<String> lstStrList(QueryUtils condition);


    @Select("${condition}")
    List<Map> lstQueryData(QueryUtils condition);

    @Select("${condition}")
    String lstSingleString(QueryUtils condition);

    @Insert("INSERT INTO cer_mq_log (apply_scene, messkey) VALUES (#{applyScene}, #{messKey})")
    int insertCerMqLog(@Param("applyScene") int applyScene, @Param("messKey") String messKey);

    @Select("SELECT rewardset.product_invite_award AS inviteAward, product_talent_award AS talentAward " +
            "FROM kingold_product.product product, kingold_product.product_reward_set rewardset " +
            "WHERE product.product_uuid = rewardset.product_uuid " +
            "AND product.product_id=#{productId}")
    Map lstProductReward(@Param("productId") Long productId);

    @Select("${condition}")
    int lstQueryCount(QueryUtils condition);

    @Update("UPDATE kingold_user.user SET user_trade_status = 1 WHERE user_trade_status<1 AND user_uuid = #{userUUId} AND user_status<>1 ")
    int updateUserRechargeStatus(@Param("userUUId") String userUUId);

    @Update("UPDATE kingold_user.user SET user_trade_status = 2 WHERE user_trade_status<2 AND user_uuid = #{userUUId} AND user_status<>1 ")
    int updateUserTradeStatus(@Param("userUUId") String userUUId);

    int updateByExampleSelective(@Param("record") OperationReport record, @Param("example") OperationReportExample example);

    int updateByExample(@Param("record") OperationReport record, @Param("example") OperationReportExample example);

    int updateByPrimaryKeySelective(OperationReport record);

    int updateByPrimaryKey(OperationReport record);
}