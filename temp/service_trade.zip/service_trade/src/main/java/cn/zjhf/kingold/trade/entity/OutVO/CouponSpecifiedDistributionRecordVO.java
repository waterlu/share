package cn.zjhf.kingold.trade.entity.OutVO;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.trade.entity.CouponSpecifiedDistributionRecord;
import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.Date;

@ApiModel(value = "CouponSpecifiedDistributionRecordVO", description = "现金券指定发放记录表")
public class CouponSpecifiedDistributionRecordVO extends ParamVO {

    @ApiModelProperty(required = true, value = "审核编号")
    @NotEmpty
    private Long auditId;

    @ApiModelProperty(required = true, value = "指定发放名称")
    @Size(min = 1, max = 256)
    private String specifiedName;

    @ApiModelProperty(required = true, value = "类型： 1指定发放礼券，2是现金红包")
    private Integer specifiedType;

    @ApiModelProperty(required = true, value = "红包金额/发放金额")
    private BigDecimal redPacketAmount;

    @ApiModelProperty(required = true, value = "礼券批次, 批次号-名称, 多个礼券用英文“,”间隔")
    @Size(min = 1, max = 1024)
    private String ccCodes;

    @ApiModelProperty(required = false, value = "导入用户记录条数(人)")
    private int userCount;

    @ApiModelProperty(required = false, value = "已领取数量")
    private int drawCount;

    @ApiModelProperty(required = false, value = "未领取数量")
    private int unDrawCount;

    @ApiModelProperty(required = true, value = "处理状态: -1审核作废；1待审核；2审核通过")
    @NotEmpty
    private int auditStatus;

    @ApiModelProperty(required = false, value = "审核人")
    @Size(min = 1, max = 32)
    private String auditOperator;

    @ApiModelProperty(required = false, value = "审核时间")
    private Date auditTime;

    @ApiModelProperty(required = false, value = "审核意见")
    @Size(min = 1, max = 512)
    private String auditOpinion;

    @ApiModelProperty(required = false, value = "更新用户id")
    @Size(min = 1, max = 32)
    private String creatorUserid;

    @ApiModelProperty(required = false, value = "创建/发放/导入发放时间")
    private Date createTime;

    @ApiModelProperty(required = true, value = "删除标记 0未删除，1已删除")
    @NotEmpty
    private int deleteFlag;

    @ApiModelProperty(required = false, value = "更新时间")
    private Date updateTime;

    public CouponSpecifiedDistributionRecordVO() {
    }

    public CouponSpecifiedDistributionRecordVO(CouponSpecifiedDistributionRecord couponSpecifiedDistributionRecord) {
        this.auditId = couponSpecifiedDistributionRecord.getAuditId();
        this.specifiedName = couponSpecifiedDistributionRecord.getSpecifiedName();
        this.specifiedType = couponSpecifiedDistributionRecord.getSpecifiedType();
        this.redPacketAmount = couponSpecifiedDistributionRecord.getRedPacketAmount();
        this.ccCodes = couponSpecifiedDistributionRecord.getCcCodes();
        this.userCount = couponSpecifiedDistributionRecord.getUserCount();
        this.auditStatus = couponSpecifiedDistributionRecord.getAuditStatus();
        this.auditOperator = couponSpecifiedDistributionRecord.getAuditOperator();
        this.auditTime = couponSpecifiedDistributionRecord.getAuditTime();
        this.auditOpinion = couponSpecifiedDistributionRecord.getAuditOpinion();
        this.creatorUserid = couponSpecifiedDistributionRecord.getCreatorUserid();
        this.createTime = couponSpecifiedDistributionRecord.getCreateTime();
        this.deleteFlag = couponSpecifiedDistributionRecord.getDeleteFlag();
        this.updateTime = couponSpecifiedDistributionRecord.getUpdateTime();
    }

    public Long getAuditId() {
        return auditId;
    }

    public void setAuditId(Long auditId) {
        this.auditId = auditId;
    }

    public String getCcCodes() {
        return ccCodes;
    }

    public void setCcCodes(String ccCodes) {
        this.ccCodes = ccCodes;
    }

    public int getUserCount() {
        return userCount;
    }

    public void setUserCount(int userCount) {
        this.userCount = userCount;
    }

    public int getAuditStatus() {
        return auditStatus;
    }

    public void setAuditStatus(int auditStatus) {
        this.auditStatus = auditStatus;
    }

    public String getAuditOperator() {
        return auditOperator;
    }

    public void setAuditOperator(String auditOperator) {
        this.auditOperator = auditOperator;
    }

    public Date getAuditTime() {
        return auditTime;
    }

    public void setAuditTime(Date auditTime) {
        this.auditTime = auditTime;
    }

    public String getAuditOpinion() {
        return auditOpinion;
    }

    public void setAuditOpinion(String auditOpinion) {
        this.auditOpinion = auditOpinion;
    }

    public String getCreatorUserid() {
        return creatorUserid;
    }

    public void setCreatorUserid(String creatorUserid) {
        this.creatorUserid = creatorUserid;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public int getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(int deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public CouponSpecifiedDistributionRecord get() {
        CouponSpecifiedDistributionRecord couponSpecifiedDistributionRecord = new CouponSpecifiedDistributionRecord();
        couponSpecifiedDistributionRecord.setAuditId(auditId);
        couponSpecifiedDistributionRecord.setSpecifiedName(specifiedName);
        couponSpecifiedDistributionRecord.setSpecifiedType(specifiedType);
        couponSpecifiedDistributionRecord.setRedPacketAmount(redPacketAmount);
        couponSpecifiedDistributionRecord.setCcCodes(ccCodes);
        couponSpecifiedDistributionRecord.setUserCount(userCount);
        couponSpecifiedDistributionRecord.setAuditStatus(new Integer(auditStatus).byteValue());
        couponSpecifiedDistributionRecord.setAuditOperator(auditOperator);
        couponSpecifiedDistributionRecord.setAuditTime(auditTime);
        couponSpecifiedDistributionRecord.setAuditOpinion(auditOpinion);
        couponSpecifiedDistributionRecord.setCreatorUserid(creatorUserid);
        couponSpecifiedDistributionRecord.setCreateTime(createTime);
        couponSpecifiedDistributionRecord.setDeleteFlag(new Integer(deleteFlag).byteValue());
        couponSpecifiedDistributionRecord.setUpdateTime(updateTime);
        return couponSpecifiedDistributionRecord;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("auditId:" + DataUtils.toString(auditId) + ", ");
        sb.append("specifiedName:" + DataUtils.toString(specifiedName) + ", ");
        sb.append("specifiedType:" + DataUtils.toString(specifiedType) + ", ");
        sb.append("redPacketAmount:" + DataUtils.toString(redPacketAmount) + ", ");
        sb.append("ccCodes:" + DataUtils.toString(ccCodes) + ", ");
        sb.append("userCount:" + DataUtils.toString(userCount) + ", ");
        sb.append("auditStatus:" + DataUtils.toString(auditStatus) + ", ");
        sb.append("auditOperator:" + DataUtils.toString(auditOperator) + ", ");
        sb.append("auditTime:" + DataUtils.toString(auditTime) + ", ");
        sb.append("auditOpinion:" + DataUtils.toString(auditOpinion) + ", ");
        sb.append("creatorUserid:" + DataUtils.toString(creatorUserid) + ", ");
        sb.append("createTime:" + DataUtils.toString(createTime) + ", ");
        sb.append("deleteFlag:" + DataUtils.toString(deleteFlag) + ", ");
        sb.append("updateTime:" + DataUtils.toString(updateTime));
        return sb.toString();
    }

    public String getSpecifiedName() {
        return specifiedName;
    }

    public void setSpecifiedName(String specifiedName) {
        this.specifiedName = specifiedName;
    }

    public Integer getSpecifiedType() {
        return specifiedType;
    }

    public void setSpecifiedType(Integer specifiedType) {
        this.specifiedType = specifiedType;
    }

    public BigDecimal getRedPacketAmount() {
        return redPacketAmount;
    }

    public void setRedPacketAmount(BigDecimal redPacketAmount) {
        this.redPacketAmount = redPacketAmount;
    }

    public int getDrawCount() {
        return drawCount;
    }

    public void setDrawCount(int drawCount) {
        this.drawCount = drawCount;
    }

    public int getUnDrawCount() {
        int unCount = userCount-drawCount;
        return (unCount>=0)?unCount:0;
    }

    public void setUnDrawCount(int unDrawCount) {
        this.unDrawCount = unDrawCount;
    }
}
