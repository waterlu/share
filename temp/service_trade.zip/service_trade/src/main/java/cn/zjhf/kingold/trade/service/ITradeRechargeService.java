package cn.zjhf.kingold.trade.service;


import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.dto.BillDto;
import cn.zjhf.kingold.trade.entity.TradeRecharge;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;


/**
 * Created by wangxun on 2017/05/04.
 * Copyright by zjinv
 */
public interface ITradeRechargeService {

//    public Map getWithFilter(Map params) throws BusinessException;
//
//    public Map insert(Map userInfo) throws BusinessException;
//
//    public int update(Map userInfo) throws BusinessException;
//
//    public Integer delete(Map params) throws BusinessException;

    TradeRecharge getTradeReacharge(String rechargeBillcCode) throws BusinessException;

    List<Map> getList(Map userMap) throws BusinessException;

    Integer getCount(Map userMap) throws BusinessException;

}