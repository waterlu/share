package cn.zjhf.kingold.trade.dto;

import cn.zjhf.kingold.trade.entity.RewardFixedTerm;
import cn.zjhf.kingold.trade.entity.RewardServiceAllowance;

import java.text.SimpleDateFormat;

/**
 * Created by lutiehua on 2017/6/2.
 */
public class RewardSummaryCollideDto {

    public String getSummaryBillCode() {
        return summaryBillCode;
    }

    public void setSummaryBillCode(String summaryBillCode) {
        this.summaryBillCode = summaryBillCode;
    }

    private String summaryBillCode;

    private String userUuid;

    private String userMobile;

    private String rewardBillCode;

    private String rewardStartDate;

    private String rewardEndDate;

    public RewardSummaryCollideDto(RewardFixedTerm rewardFixedTerm) {
        this.setRewardBillCode(rewardFixedTerm.getRewardFixedBillCode());
        this.setUserUuid(rewardFixedTerm.getUserUuid());
        this.setUserMobile(rewardFixedTerm.getUserMobile());

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        this.setRewardStartDate(dateFormat.format(rewardFixedTerm.getRewardFixedStartDate()));
        this.setRewardEndDate(dateFormat.format(rewardFixedTerm.getRewardFixedEndDate()));
    }

    public RewardSummaryCollideDto(RewardServiceAllowance rewardServiceAllowance) {
        this.setRewardBillCode(rewardServiceAllowance.getRewardAllowanceBillCode());
        this.setUserUuid(rewardServiceAllowance.getUserUuid());
        this.setUserMobile(rewardServiceAllowance.getUserMobile());

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        this.setRewardStartDate(dateFormat.format(rewardServiceAllowance.getRewardAllowanceStartDate()));
        this.setRewardEndDate(dateFormat.format(rewardServiceAllowance.getRewardAllowanceEndDate()));
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getUserMobile() {
        return userMobile;
    }

    public void setUserMobile(String userMobile) {
        this.userMobile = userMobile;
    }


    public String getRewardBillCode() {
        return rewardBillCode;
    }

    public void setRewardBillCode(String rewardBillCode) {
        this.rewardBillCode = rewardBillCode;
    }

    public String getRewardStartDate() {
        return rewardStartDate;
    }

    public void setRewardStartDate(String rewardStartDate) {
        this.rewardStartDate = rewardStartDate;
    }

    public String getRewardEndDate() {
        return rewardEndDate;
    }

    public void setRewardEndDate(String rewardEndDate) {
        this.rewardEndDate = rewardEndDate;
    }
}
