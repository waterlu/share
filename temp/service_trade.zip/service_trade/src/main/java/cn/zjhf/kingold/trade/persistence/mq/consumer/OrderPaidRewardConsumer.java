package cn.zjhf.kingold.trade.persistence.mq.consumer;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.rocketmq.annotation.RocketMQConsumer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQConsumer;
import cn.zjhf.kingold.trade.constant.BizDefine;
import cn.zjhf.kingold.trade.persistence.dao.OperationReportMapper;
import cn.zjhf.kingold.trade.persistence.mq.message.OrderPaidMessage;
import cn.zjhf.kingold.trade.service.IAchievementService;
import cn.zjhf.kingold.trade.service.IRewardService;
import cn.zjhf.kingold.trade.utils.BizParam;
import cn.zjhf.kingold.trade.utils.DataUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Map;

/**
 * 定期订单认购成功，生成奖励明细记录，生成业绩
 *
 * @author lutiehua
 * @date 2017/7/13
 */
@RocketMQConsumer(topic = "order", tag = "paid", consumerGroup = "c_service_reward_lu")
public class OrderPaidRewardConsumer extends AbstractMQConsumer<OrderPaidMessage> {

    @Autowired
    private IRewardService rewardService;

    @Autowired
    private IAchievementService achievementService;

    @Autowired
    OperationReportMapper operationReportMapper;

    @Override
    public ResponseResult process(OrderPaidMessage order) throws BusinessException {
        ResponseResult responseResult = new ResponseResult();
        if(!BizDefine.KINGOLD_MERCHANT.equals(order.getBelongMerchantNum())){
            return responseResult;
        }

        // 生成奖励
        Map productReward = operationReportMapper.lstProductReward(order.getProductID());
        BizParam bizParam = new BizParam(productReward);
        if(DataUtils.isNotEmpty(bizParam.get("inviteAward"))) {
            logger.info("生成邀请奖励");
            rewardService.generateFTAwardRecord(order);
        }

        if(DataUtils.isNotEmpty(bizParam.get("talentAward"))) {
            logger.info("生成达人奖励");
            String masterAward = bizParam.get("talentAward");
            rewardService.generateMasterFTAwardRecord(order, masterAward);
        }

        // 记录业绩
        // 2018-03-21 lutiehua 达人升级记录在`kingold_user`.`achievement`表中，这里不需要再记录了
//        logger.info("记录业绩");
//        achievementService.generateFTAchievement(order);

        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        return responseResult;
    }
}
