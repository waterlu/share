package cn.zjhf.kingold.trade.persistence.dao;


import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.dto.InvestAssetDto;
import cn.zjhf.kingold.trade.dto.TradeOrderProfitEverydayDto;
import cn.zjhf.kingold.trade.entity.TradeOrder;
import cn.zjhf.kingold.trade.entity.TradeOrderPayStatusDO;
import cn.zjhf.kingold.trade.utils.WhereCondition;
import cn.zjhf.kingold.trade.vo.AmendTradeOrderVO;
import cn.zjhf.kingold.trade.vo.LoanCashedDetailVO;
import cn.zjhf.kingold.trade.vo.TradeOrderVO;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Repository
@Mapper
public interface TradeOrderMapper {
    Integer insert(Map map);

    Map get(@Param("orderBillCode") String orderBillCode);

    void update(Map map);

    List<Map> getList(Map map);

    Integer getCount(Map map);

    BigDecimal getTotalInvestAmount(Map map);

    List<InvestAssetDto> getInvestAsset(Map map);

    BigDecimal querySumAmountByUser(String userUuid);

    /**
     * 更新订单支付状态
     *
     * @param param
     * @return
     */
    int updatePaySuccessStatus(Map<String, Object> param);

    /**
     * 更新支付处理中状态
     *
     * @param orderBillCode
     * @return
     */
    int updatePayPendingStatus(String orderBillCode);

    /**
     * 更新支付状态
     *
     * @param orderBillCode
     * @return
     */
    int updatePayApplyStatus(String orderBillCode);

    @Select("SELECT trade.order_bill_code, trade.paid_amount, investsummary.batch_no " +
            "FROM trade_order trade, trade_invest_summary investsummary " +
            "where trade.product_uuid = investsummary.product_uuid " +
            "and trade.product_uuid = #{productUuid}")
    List<Map> queryReport(@Param("productUuid") String productUuid);

    @Select("SELECT * FROM trade_order ${condition}")
    List<Map> lstByCondition(WhereCondition condition);

    @Select("SELECT order_bill_code FROM trade_order ${condition} AND order_status NOT IN (1,9) AND delete_flag = 0 LIMIT 0,1")
    String havaValidOrder(WhereCondition condition);

    @Select("SELECT SUM(profit_amount) FROM trade_order WHERE product_uuid = #{productUuid} AND order_status NOT IN(1,9) AND delete_flag=0")
    Double lstRaiserProfitAmount(@Param("productUuid") String productUuid);

    @Select("SELECT SUM(order_amount) FROM trade_order WHERE product_uuid = #{productUuid} AND order_status NOT IN (1,9) AND delete_flag = 0")
    String lstRaiseAmt(@Param("productUuid") String productUuid);

    @Select("SELECT Count(*) FROM trade_order ${condition}")
    int lstCountByCondition(WhereCondition condition);

    @Update("UPDATE trade_order SET cash_amount = #{cashAmount} WHERE order_bill_code = #{orderNo}")
    void updateProductEndAmount(@Param("orderNo") String orderNo, @Param("cashAmount") double cashAmount);

    @Update("UPDATE trade_order SET order_status = #{status} WHERE order_bill_code = #{OrderBillCode}")
    void updateStatusByOrderBillCode(@Param("OrderBillCode") String OrderBillCode, @Param("status") int status);

    @Update("UPDATE trade_order SET product_increase_interest_rate = product_increase_interest_rate+#{couponInterestYieldRate}, coupon_interest_yield_rate=#{couponInterestYieldRate} WHERE order_bill_code=#{OrderBillCode}")
    void processCouponInterestYieldRate(@Param("OrderBillCode") String OrderBillCode, @Param("couponInterestYieldRate") double couponInterestYieldRate);

    @Update("UPDATE trade_order SET order_status = #{status} WHERE product_uuid = #{productUUId} and order_status = #{originalStatus}")
    void updateStatus(@Param("productUUId") String productUUId, @Param("status") int status, @Param("originalStatus") int originalStatus);

    @Update("update trade_order set subcontract_filepath = #{filePath}, subcontract_no = #{contractNo}, subcontract_time = now() where order_bill_code = #{orderBillCode}")
    int updateContractInfo(@Param("orderBillCode") String orderBillCode, @Param("filePath") String filePath, @Param("contractNo") String contractNo);

    @Select("SELECT Max(subcontract_no) FROM trade_order WHERE subcontract_no LIKE #{IdMode}")
    String lstLastSubContractNo(@Param("IdMode") String IdMode);

    @Update("DELETE FROM trade_order_back WHERE product_uuid = #{productUUId}")
    void deleteBackRecord(@Param("productUUId") String productUUId);

    @Update("INSERT INTO trade_order_back SELECT * FROM trade_order WHERE product_uuid = #{productUUId}")
    void backTradeOrderRecord(@Param("productUUId") String productUUId);

    List<Map> selectByUniqueIdentifier(@Param("uniqueIdentifier")String uniqueIdentifier);

    /**
     * 通过产品编号获取营销费用和
     * @param productUuid
     * @return
     */
    BigDecimal getSumMarketingAmountByProductUuid(String productUuid);

    @Select("SELECT trade.user_uuid, trans.trade_order_bill_code_extend, trade.product_uuid, trade.product_abbr_name, trade.user_name, " +
            "trade.user_phone, trade.payed_time, trade.marketing_amount, trade.product_increase_interest_rate, trade.order_amount, " +
            "trade.marketing_rate_amount, trade.product_period, trade.coupon_interest_yield_rate, trade.coupon_interest_period, product.product_establishment_date,inv.investor_id_card_no as idCardNo " +
            " FROM kingold_trade.trade_order trade , kingold_trade.account_transaction trans ,kingold_product.product_fixed_income product ,kingold_user.investor inv  ${condition}")
    @ResultMap("linkedList")
    List<Map> listByCondition(WhereCondition condition);

    @Select("SELECT Count(*)  FROM kingold_trade.trade_order trade, kingold_trade.account_transaction trans ,kingold_product.product_fixed_income product ,kingold_user.investor inv  ${condition}")
    int listCountByConditionEx(WhereCondition condition);

    @Select("SELECT trade.user_uuid, trans.trade_order_bill_code_extend, trade.product_uuid, trade.product_abbr_name, trade.user_name, " +
            "trade.user_phone, trade.payed_time, trade.marketing_amount, trade.product_increase_interest_rate, trade.order_amount, " +
            "trade.marketing_rate_amount, trade.product_period, trade.coupon_interest_yield_rate, trade.coupon_interest_period, product.product_establishment_date,eninv.legal_person_id_card_no as idCardNo " +
            " FROM kingold_trade.trade_order trade , kingold_trade.account_transaction trans ,kingold_product.product_fixed_income product ,kingold_user.enterprise_investor eninv  ${condition}")
    @ResultMap("linkedList")
    List<Map> listByConditionEnterprise(WhereCondition condition);

    @Select("SELECT Count(*)  FROM kingold_trade.trade_order trade, kingold_trade.account_transaction trans ,kingold_product.product_fixed_income product ,kingold_user.enterprise_investor eninv  ${condition}")
    int listCountByConditionEnterprise(WhereCondition condition);

    @Select("SELECT Count(*)  FROM trade_order trade  ${condition}")
    int listCountByCondition(WhereCondition condition);

    @Select("SELECT * FROM  kingold_market.experience exper ${condition}")
    List<Map> listMarketByCondition(WhereCondition condition);

    @Select("SELECT COUNT(*) FROM kingold_market.experience exper ${condition}")
    int listMarketCountByCondition(WhereCondition condition);

    @Select("SELECT product_uuid FROM  kingold_product.product  ${condition}")
    List<String> listProductByCondition(WhereCondition condition);

    @Select("SELECT fixed.product_attachment,fixed.product_abbr_name,trade.user_uuid,trade.user_name,trade.user_phone,trade.order_amount,trade.product_period,trade.payed_time,trade.product_interest_date,trade.product_expiring_date FROM kingold_product.product fixed,kingold_trade.trade_order trade ${condition}")
    List<Map> listProAndTradeByCondition(WhereCondition condition);

    @Select("SELECT Count(trade.product_uuid) FROM kingold_product.product fixed,kingold_trade.trade_order trade ${condition}")
    int listProAndTradeCountByCondition(WhereCondition condition);

    @Select("SELECT * FROM trade_order WHERE product_uuid = #{productUUId}")
    @ResultMap("TradeOrderVO")
    List<TradeOrderVO> getOrderListByProductUuid(@Param("productUUId") String productUUId);

    @Select("SELECT order_bill_code, product_annual_interest_rate, coupon_interest_yield_rate, " +
            "coupon_interest_period, order_amount, expected_profit_amount, profit_amount, " +
            "marketing_rate_amount, cash_amount FROM trade_order WHERE product_uuid = #{productUUId}")
    @ResultMap("AmendTradeOrderVO")
    List<AmendTradeOrderVO> getOrderListByProductUuidEx(@Param("productUUId") String productUUId);

    @Update("UPDATE trade_order SET expected_profit_amount=#{expectedProfitAmount}," +
            "profit_amount=#{raisedProfitAmount}," +
            "coupon_interest_period=#{couponInterestPeriod}," +
            "marketing_rate_amount=#{marketingRateAmount}," +
            "cash_amount=#{cashAmount} " +
            " WHERE order_bill_code = #{orderBillCode}")
    int updateTradeOrderProfit(@Param("expectedProfitAmount") Double expectedProfitAmount,
                               @Param("raisedProfitAmount") Double raisedProfitAmount,
                               @Param("couponInterestPeriod") Integer couponInterestPeriod,
                               @Param("marketingRateAmount") Double marketingRateAmount,
                               @Param("cashAmount") Double cashAmount,
                               @Param("orderBillCode") String orderBillCode);

    @Select("SELECT o.order_bill_code,t.trade_order_bill_code_extend,o.user_phone,o.user_name,i.investor_id_card_no,o.product_abbr_name,o.product_period,o.product_period_type,o.marketing_amount,o.coupon_interest_yield_rate,o.user_uuid, " +
            " o.strategy_ids,o.product_annual_interest_rate,o.product_increase_interest_rate,o.order_amount,o.paid_amount,o.expected_profit_amount,o.create_time,o.payed_time,o.transaction_channel,o.order_status,o.user_type " +
            " FROM kingold_trade.trade_order o,kingold_trade.account_transaction t,kingold_user.investor i ${condition}")
    @ResultMap("TradeOrderVO")
    List<TradeOrderVO> getOrderList(WhereCondition where);

    List<TradeOrderProfitEverydayDto> calculateYesterdayProfit(@Param("nowDay") Integer nowDay, @Param("startRow") Integer startRow,
                                                               @Param("pageSize") Integer pageSize) throws BusinessException;

    List<TradeOrderProfitEverydayDto> calculateYesterdayPaidProfit(@Param("productUuidList") List<String> productUuidList, @Param("startRow") Integer startRow,
                                                               @Param("pageSize") Integer pageSize) throws BusinessException;

    /**
     * 读取用户的有效订单数量
     *
     * @param userUuid
     * @return
     */
    int getOrderCountByUser(String userUuid);

    /**
     * 更新订单支付状态为处理中
     *
     * @param orderPayStatusDO
     * @return
     */
    int updateOrderPayPendingStatus(TradeOrderPayStatusDO orderPayStatusDO);

    /**
     * 更新订单支付状态为失败
     *
     * @param orderPayStatusDO
     * @return
     */
    int updateOrderPayFailedStatus(TradeOrderPayStatusDO orderPayStatusDO);

    /**
     * 募集放款、到期兑付对应明细
     * @param condition
     * @return
     */
    @Select("SELECT trans.trade_order_bill_code_extend,trade.order_bill_code,trade.user_phone,trade.paid_amount,trade.marketing_amount,trade.order_amount,trade.order_status, " +
            " trade.cash_amount,trade.product_uuid,trade.transaction_time,trade.expected_profit_amount,trade.profit_amount,trade.marketing_rate_amount" +
            " FROM kingold_trade.trade_order trade , kingold_trade.account_transaction trans  ${condition}")
    @ResultMap("LoanCashedDetailVO")
    List<LoanCashedDetailVO> getLoanCashedDetail(WhereCondition condition);
    /**
     * 募集放款、到期兑付对应明细总数
     * @param condition
     * @return
     */
    @Select("SELECT COUNT(trade.order_bill_code)  FROM kingold_trade.trade_order trade , kingold_trade.account_transaction trans   ${condition}")
    int getLoanCashedDetailCount(WhereCondition condition);

    /**
     * 刷新用户收益
     *
     * @param tradeOrder
     * @return
     */
    int fixProductClear(AmendTradeOrderVO tradeOrder);

    /**
     * 获取需要刷新的产品
     *
     * @return
     */
    List<String> getFixProductUuidList(Integer status);
}