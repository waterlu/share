package cn.zjhf.kingold.trade.entity.OutVO;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.trade.entity.InVO.CouponExtendRecordVO;
import cn.zjhf.kingold.trade.entity.InVO.MarketCampaignVO;
import cn.zjhf.kingold.trade.entity.MarketCampaign;
import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModelProperty;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangyijie on 2017/7/5.
 */
public class MarketCampaignItemListVO extends ParamVO {
    @ApiModelProperty(required = true, value = "总记录数")
    private int count;

    @ApiModelProperty(required = true, value = "返回列表")
    private List<MarketCampaignVO> list;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public List<MarketCampaignVO> getList() {
        return list;
    }

    public void setList(List<MarketCampaignVO> list) {
        this.list = list;
    }

    public void setListEx(List<MarketCampaign> list) {
        if(null == list) {
            return;
        }

        this.list = new ArrayList<MarketCampaignVO>();
        if(list != null && list.size() > 0) {
            for(MarketCampaign item : list) {
                this.list.add(new MarketCampaignVO(item));
            }
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(getTraceID()) + ", ");
        sb.append("count:" + DataUtils.toString(count) + ", ");
        sb.append("list:" + DataUtils.toString(list));
        return sb.toString();
    }
}
