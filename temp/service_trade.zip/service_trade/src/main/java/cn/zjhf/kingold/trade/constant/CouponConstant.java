package cn.zjhf.kingold.trade.constant;

/**
 * 优惠券常量
 *
 * @author lutiehua
 * @date 2018/3/9
 */
public interface CouponConstant {

    /**
     * 类型：现金抵扣券
     */
    int TYPE_SUB_CASH = 1;

    /**
     * 类型：加息券
     */
    int TYPE_ADD_PROFIT = 2;

    /**
     * 状态：已发放
     */
    int STATUS_INIT = 1;

    /**
     * 状态：已使用
     */
    int STATUS_USED = 2;

    /**
     * 状态：已过期
     */
    int STATUS_EXPIRED = 3;

    /**
     * 状态：已废弃
     */
    int STATUS_DELETED = 4;

    /**
     * 状态：已赠送
     */
    int STATUS_TRANSFERRED = 5;
}
