package cn.zjhf.kingold.trade.persistence.mq.message;

import cn.zjhf.kingold.rocketmq.base.MQMessage;
import cn.zjhf.kingold.trade.dto.InvestorDto;

/**
 * 用户升级为理财师的消息
 *
 * Created by lutiehua on 2017/7/13.
 */
public class UserUpgradeMessage implements MQMessage {

    private InvestorDto data;

    public UserUpgradeMessage(InvestorDto investorDto) {
        this.data = investorDto;
    }

    @Override
    public String getKey() {
        return data.getUserUuid();
    }

    public InvestorDto getData() {
        return data;
    }

    public void setData(InvestorDto data) {
        this.data = data;
    }
}
