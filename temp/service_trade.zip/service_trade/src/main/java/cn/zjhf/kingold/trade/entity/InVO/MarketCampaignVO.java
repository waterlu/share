package cn.zjhf.kingold.trade.entity.InVO;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.trade.entity.MarketCampaign;
import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author DELL
 */
@ApiModel(value = "MarketCampaignVO", description = "营销活动表")
public class MarketCampaignVO extends InVOBase {

    @ApiModelProperty(required = true, value = "序号")
    @NotEmpty
    private int mcId;

    @ApiModelProperty(required = false, value = "活动名称")
    @Size(min = 1, max = 32)
    private String mcName;

    @ApiModelProperty(required = true, value = "活动状态(1未开始，2进行中，3已结束)")
    @NotEmpty
    private int mcStatus;

    @ApiModelProperty(value = "是否送金币（0否 1是）")
    private Byte isCoin;

    @ApiModelProperty(required = false, value = "开始时间")
    private Date startTime;

    @ApiModelProperty(required = false, value = "结束时间")
    private Date endTime;

    @ApiModelProperty(required = false, value = "说明")
    @Size(min = 1, max = 1024)
    private String mcMark;

    @ApiModelProperty(required = true, value = "场景编码(1注册,2实名,3首次绑卡,4首次充值,5首次投资,6邀请好友首次投资，7复投，8邀请好友注册，9分享)")
    @NotEmpty
    private Integer applyScene;

    @ApiModelProperty(required = true, value = "礼券批次号(多个同时存在用$$分隔)")
    @NotEmpty
    @Size(min = 1, max = 1024)
    private String applyCashCoupon;

    @ApiModelProperty(required = true, value = "删除标记 0未删除，1已删除")
    @NotEmpty
    private int deleteFlag;

    @ApiModelProperty(required = false, value = "创建时间")
    private Date createTime;

    @ApiModelProperty(required = false, value = "更新时间")
    private Date updateTime;

    @ApiModelProperty(required = false, value = "更新用户id")
    @Size(min = 1, max = 32)
    private String updateUserId;

    @ApiModelProperty(required = false, value = "触发频率，1单次触发，2多次触发")
    private Byte frequencyLimit;

    @ApiModelProperty(required = false, value = "考察开始时间")
    private Date investigateStartTime;

    @ApiModelProperty(required = false, value = "考察结束时间")
    private Date investigateEndTime;

    @ApiModelProperty(required = false, value = "复投奖励次数")
    private Integer recastCount;

    @ApiModelProperty(required = false, value = "金币场景名称")
    private String coinTaskName;

    @ApiModelProperty(required = false, value = "任务送的金币数量")
    private Integer coinTaskAmount;

    @ApiModelProperty(required = false, value = "任务送达人的金币数量")
    private Integer coinTaskDrAmount;

    @ApiModelProperty(required = false, value = "多长时间后金币才可收取（小时）")
    private Integer coinTaskAfterHour;

    @ApiModelProperty(required = false, value = "金币任务显示顺序（正序排序）")
    private Integer coinTaskShowOrder;

    @ApiModelProperty(required = false, value = "每日触发最大次数")
    private Integer coinTaskLimit;

    @ApiModelProperty(required = false, value = "金币场景描述")
    private String coinTaskMark;

    @ApiModelProperty(required = false, value = "每日金币场景任务完成数量")
    private Integer coinTaskCompleteNum;

    public MarketCampaignVO() {
    }

    public MarketCampaignVO(MarketCampaign marketCampaign) {
        this.mcId = marketCampaign.getMcId();
        this.mcName = marketCampaign.getMcName();
        this.mcStatus = marketCampaign.getMcStatus();
        this.isCoin = marketCampaign.getIsCoin();
        this.startTime = marketCampaign.getStartTime();
        this.endTime = marketCampaign.getEndTime();
        this.mcMark = marketCampaign.getMcMark();
        this.applyScene = marketCampaign.getApplyScene();
        this.applyCashCoupon = marketCampaign.getApplyCashCoupon();
        this.deleteFlag = marketCampaign.getDeleteFlag();
        this.createTime = marketCampaign.getCreateTime();
        this.updateTime = marketCampaign.getUpdateTime();
        this.updateUserId = marketCampaign.getUpdateUserId();
        this.frequencyLimit = marketCampaign.getFrequencyLimit();
        this.investigateStartTime = marketCampaign.getInvestigateStartTime();
        this.investigateEndTime = marketCampaign.getInvestigateEndTime();
        this.recastCount = marketCampaign.getRecastCount();
        this.coinTaskName = marketCampaign.getCoinTaskName();
        this.coinTaskAfterHour = marketCampaign.getCoinTaskAfterHour();
        this.coinTaskAmount = marketCampaign.getCoinTaskAmount();
        this.coinTaskDrAmount = marketCampaign.getCoinTaskDrAmount();
        this.coinTaskShowOrder = marketCampaign.getCoinTaskShowOrder();
        this.coinTaskLimit = marketCampaign.getCoinTaskLimit();
        this.coinTaskMark = marketCampaign.getCoinTaskMark();
    }

    public int getMcId() {
        return mcId;
    }

    public void setMcId(int mcId) {
        this.mcId = mcId;
    }

    public String getMcName() {
        return mcName;
    }

    public void setMcName(String mcName) {
        this.mcName = mcName;
    }

    public int getMcStatus() {
        return mcStatus;
    }

    public void setMcStatus(int mcStatus) {
        this.mcStatus = mcStatus;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getMcMark() {
        return mcMark;
    }

    public void setMcMark(String mcMark) {
        this.mcMark = mcMark;
    }

    public Integer getApplyScene() {
        return applyScene;
    }

    public void setApplyScene(Integer applyScene) {
        this.applyScene = applyScene;
    }

    public String getApplyCashCoupon() {
        return applyCashCoupon;
    }

    public void setApplyCashCoupon(String applyCashCoupon) {
        this.applyCashCoupon = applyCashCoupon;
    }

    public int getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(int deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(String updateUserId) {
        this.updateUserId = updateUserId;
    }

    public Date getInvestigateStartTime() {
        return investigateStartTime;
    }

    public void setInvestigateStartTime(Date investigateStartTime) {
        this.investigateStartTime = investigateStartTime;
    }

    public Date getInvestigateEndTime() {
        return investigateEndTime;
    }

    public void setInvestigateEndTime(Date investigateEndTime) {
        this.investigateEndTime = investigateEndTime;
    }

    public Integer getRecastCount() {
        return recastCount;
    }

    public void setRecastCount(Integer recastCount) {
        this.recastCount = recastCount;
    }

    public Integer getCoinTaskAmount() {
        return coinTaskAmount;
    }

    public void setCoinTaskAmount(Integer coinTaskAmount) {
        this.coinTaskAmount = coinTaskAmount;
    }

    public Integer getCoinTaskDrAmount() {
        return coinTaskDrAmount;
    }

    public void setCoinTaskDrAmount(Integer coinTaskDrAmount) {
        this.coinTaskDrAmount = coinTaskDrAmount;
    }

    public Integer getCoinTaskAfterHour() {
        return coinTaskAfterHour;
    }

    public void setCoinTaskAfterHour(Integer coinTaskAfterHour) {
        this.coinTaskAfterHour = coinTaskAfterHour;
    }

    public Integer getCoinTaskShowOrder() {
        return coinTaskShowOrder;
    }

    public void setCoinTaskShowOrder(Integer coinTaskShowOrder) {
        this.coinTaskShowOrder = coinTaskShowOrder;
    }

    public Integer getCoinTaskLimit() {
        return coinTaskLimit;
    }

    public void setCoinTaskLimit(Integer coinTaskLimit) {
        this.coinTaskLimit = coinTaskLimit;
    }

    public Byte getIsCoin() {
        return isCoin;
    }

    public void setIsCoin(Byte isCoin) {
        this.isCoin = isCoin;
    }

    public String getCoinTaskName() {
        return coinTaskName;
    }

    public void setCoinTaskName(String coinTaskName) {
        this.coinTaskName = coinTaskName;
    }

    public String getCoinTaskMark() {
        return coinTaskMark;
    }

    public void setCoinTaskMark(String coinTaskMark) {
        this.coinTaskMark = coinTaskMark;
    }

    public Integer getCoinTaskCompleteNum() {
        return coinTaskCompleteNum;
    }

    public void setCoinTaskCompleteNum(Integer coinTaskCompleteNum) {
        this.coinTaskCompleteNum = coinTaskCompleteNum;
    }

    public MarketCampaign get() {
        MarketCampaign marketCampaign = new MarketCampaign();
        marketCampaign.setMcId(mcId);
        marketCampaign.setMcName(mcName);
        marketCampaign.setMcStatus(new Integer(mcStatus).byteValue());
        marketCampaign.setIsCoin(isCoin);
        marketCampaign.setStartTime(startTime);
        marketCampaign.setEndTime(endTime);
        marketCampaign.setMcMark(mcMark);
        marketCampaign.setApplyScene(applyScene);
        marketCampaign.setApplyCashCoupon(applyCashCoupon);
        marketCampaign.setDeleteFlag(new Integer(deleteFlag).byteValue());
        marketCampaign.setCreateTime(createTime);
        marketCampaign.setUpdateTime(updateTime);
        marketCampaign.setUpdateUserId(updateUserId);
        marketCampaign.setFrequencyLimit(frequencyLimit);
        marketCampaign.setInvestigateStartTime(investigateStartTime);
        marketCampaign.setInvestigateEndTime(investigateEndTime);
        marketCampaign.setRecastCount(recastCount);
        marketCampaign.setCoinTaskName(coinTaskName);
        marketCampaign.setCoinTaskAfterHour(coinTaskAfterHour);
        marketCampaign.setCoinTaskAmount(coinTaskAmount);
        marketCampaign.setCoinTaskDrAmount(coinTaskDrAmount);
        marketCampaign.setCoinTaskLimit(coinTaskLimit);
        marketCampaign.setCoinTaskShowOrder(coinTaskShowOrder);
        marketCampaign.setCoinTaskMark(coinTaskMark);
        return marketCampaign;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(getTraceID()) + ", ");

        sb.append("mcId:" + DataUtils.toString(mcId) + ", ");
        sb.append("mcName:" + DataUtils.toString(mcName) + ", ");
        sb.append("frequencyLimit:" + DataUtils.toString(frequencyLimit) + ", ");
        sb.append("mcStatus:" + DataUtils.toString(mcStatus) + ", ");
        sb.append("isCoin:" + DataUtils.toString(isCoin) + ", ");
        sb.append("startTime:" + DataUtils.toString(startTime) + ", ");
        sb.append("endTime:" + DataUtils.toString(endTime) + ", ");

        sb.append("mcMark:" + DataUtils.toString(mcMark) + ", ");
        sb.append("applyScene:" + DataUtils.toString(applyScene) + ", ");
        sb.append("applyCashCoupon:" + DataUtils.toString(applyCashCoupon) + ", ");
        sb.append("deleteFlag:" + DataUtils.toString(deleteFlag) + ", ");
        sb.append("createTime:" + DataUtils.toString(createTime) + ", ");
        sb.append("updateTime:" + DataUtils.toString(updateTime) + ", ");
        sb.append("investigateStartTime:" + DataUtils.toString(investigateStartTime) + ", ");
        sb.append("investigateEndTime:" + DataUtils.toString(investigateEndTime) + ", ");
        sb.append("recastCount:" + DataUtils.toString(recastCount) + ", ");
        sb.append("updateUserId:" + DataUtils.toString(updateUserId));

        sb.append("coinTaskName:" + DataUtils.toString(coinTaskName));
        sb.append("coinTaskAfterHour:" + DataUtils.toString(coinTaskAfterHour));
        sb.append("coinTaskAmount:" + DataUtils.toString(coinTaskAmount));
        sb.append("coinTaskDrAmount:" + DataUtils.toString(coinTaskDrAmount));
        sb.append("coinTaskLimit:" + DataUtils.toString(coinTaskLimit));
        sb.append("coinTaskShowOrder:" + DataUtils.toString(coinTaskShowOrder));
        sb.append("coinTaskMark:" + DataUtils.toString(coinTaskMark));

        sb.append("coinTaskCompleteNum:" + DataUtils.toString(coinTaskCompleteNum));
        return sb.toString();
    }

    public Byte getFrequencyLimit() {
        return frequencyLimit;
    }

    public void setFrequencyLimit(Byte frequencyLimit) {
        this.frequencyLimit = frequencyLimit;
    }

}
