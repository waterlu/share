package cn.zjhf.kingold.trade.persistence.mq.consumer;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.rocketmq.annotation.RocketMQConsumer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQConsumer;
import cn.zjhf.kingold.trade.constant.MarketCampaignCodeEnum;
import cn.zjhf.kingold.trade.dto.CouponSendConditionDto;
import cn.zjhf.kingold.trade.persistence.dao.OperationReportMapper;
import cn.zjhf.kingold.trade.persistence.mq.message.CheckInMessage;
import cn.zjhf.kingold.trade.persistence.mq.message.UserMessage;
import cn.zjhf.kingold.trade.service.IMarketCampaignService;
import cn.zjhf.kingold.trade.service.IUserService;
import cn.zjhf.kingold.trade.utils.DataUtils;
import cn.zjhf.kingold.trade.utils.DateUtil;
import cn.zjhf.kingold.trade.utils.QueryUtils;
import cn.zjhf.kingold.trade.utils.Tuple.TwoTuple;
import cn.zjhf.kingold.trade.utils.WhereCondition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;

/**
 * 用户绑卡成功，红包
 * <p>
 * Created by lutiehua on 2017/7/14.
 */
@RocketMQConsumer(topic = "coin", tag = "checkInPublish")
public class CoinCheckInConsumer extends AbstractMQConsumer<CheckInMessage> {

    private final Logger LOGGER = LoggerFactory.getLogger(CoinCheckInConsumer.class);

    @Autowired
    private IMarketCampaignService marketCampaignService;


    @Override
    public ResponseResult process(CheckInMessage checkInMessage) throws BusinessException {
        marketCampaignService.marketCampaignTrigger(new CouponSendConditionDto(checkInMessage.getUserUuid(), MarketCampaignCodeEnum.EVERYDAY_SIGN.getCode(), checkInMessage.getKey(), ""));
        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        LOGGER.info("用户注册消息 END {}", responseResult);
        return responseResult;
    }
}