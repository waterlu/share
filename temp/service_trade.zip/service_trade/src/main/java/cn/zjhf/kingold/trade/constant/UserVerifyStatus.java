package cn.zjhf.kingold.trade.constant;

/**
 * Created by liuyao on 2017/7/12.
 */
public enum UserVerifyStatus {
    INIT(0, "初始状态"), REGISTER_BAOFOO(1, "宝付注册成功"), USER_AUTH_SUCCESS(2, "授权成功"),
    USER_BIND_CARD_SUCCESS(3, "绑卡成功"), OPEN_ACCOUNT_SUCCESS(9, "开户流程完成");

    private Integer status;
    private String msg;

    UserVerifyStatus(Integer status, String msg) {
        this.status = status;
        this.msg = msg;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
