package cn.zjhf.kingold.trade.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.constant.RewardSummaryStatus;
import cn.zjhf.kingold.trade.constant.Separator;
import cn.zjhf.kingold.trade.dto.RewardApplyDto;
import cn.zjhf.kingold.trade.dto.RewardFixedClearDto;
import cn.zjhf.kingold.trade.dto.RewardFixedSearchDto;
import cn.zjhf.kingold.trade.entity.RewardFixedTerm;
import cn.zjhf.kingold.trade.service.IRewardSummaryService;
import com.alibaba.fastjson.JSON;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.math.BigDecimal;
import java.util.*;

/**
 * Created by lutiehua on 2017/6/2.
 */
@RestController
@RequestMapping(value = "/reward/summary/fixed")
public class RewardSummaryController {

    private final Logger LOGGER = LoggerFactory.getLogger(RewardSummaryController.class);

    @Autowired
    private IRewardSummaryService rewardSummaryService;

    /**
     * 请求生成批量奖励结算单
     *
     * @param rewardApplyDto
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "", method = RequestMethod.POST)
    public ResponseResult applyFixedAward(@RequestBody @Valid RewardApplyDto rewardApplyDto) throws BusinessException {
        return rewardSummaryService.applyFixedAward(rewardApplyDto);
    }

    @RequestMapping(value = "/{rewardFixedBillCode}", method = RequestMethod.GET)
    public ResponseResult getFixedAward(@PathVariable("rewardFixedBillCode") String rewardFixedBillCode) throws BusinessException {
        RewardFixedTerm rewardFixedTerm = rewardSummaryService.getFixedAward(rewardFixedBillCode);
        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        responseResult.setData(rewardFixedTerm);
        return responseResult;
    }

    /**
     * 查询定期奖励结算记录
     *
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/search", method = RequestMethod.GET)
    public ResponseResult getFixedAwardSummaryList(@RequestParam Map<String, Object> param) throws BusinessException {
        String jsonString = JSON.toJSONString(param);
        RewardFixedSearchDto searchCondition = JSON.parseObject(jsonString, RewardFixedSearchDto.class);

        // 保证""不作为查询条件
        if(StringUtils.isEmpty(searchCondition.getOrderBillCode())) {
            searchCondition.setOrderBillCode(null);
        }
        if (StringUtils.isEmpty(searchCondition.getUserMobile())) {
            searchCondition.setUserMobile(null);
        }
        if (StringUtils.isEmpty(searchCondition.getUserName())) {
            searchCondition.setUserName(null);
        }
        if (StringUtils.isEmpty(searchCondition.getRewardFixedBatchCode())) {
            searchCondition.setRewardFixedBatchCode(null);
        }

        if (null != searchCondition.getClearEndDate()) {
            // 包括结束日期，查询时加1天
            Date endDate = searchCondition.getClearEndDate();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(endDate);
            calendar.add(Calendar.DAY_OF_YEAR, 1);
            endDate = calendar.getTime();
            searchCondition.setClearEndDate(endDate);
        }

        List<RewardFixedTerm> rewardList = rewardSummaryService.searchRewardFixed(searchCondition);
        int count = rewardSummaryService.searchRewardFixedCount(searchCondition);
        Map<String, Object> data = new HashMap<>();
        data.put("list", rewardList);
        data.put("count", count);
        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        responseResult.setTraceID(searchCondition.getTraceID());
        responseResult.setData(data);
        return responseResult;
    }

    /**
     * 审核
     *
     * @param param
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/check", method = RequestMethod.PUT)
    public ResponseResult check(@RequestBody Map<String, Object> param) throws BusinessException {
        String rewardFixedBillCode = param.get("rewardFixedBillCode").toString();
        int pass = Integer.parseInt(param.get("pass").toString());

        Map<String, Object>  checkMap = new HashMap<>();
        checkMap.put("rewardFixedBillCode", rewardFixedBillCode);

        if (null != param.get("userUuid")) {
            String userString = param.get("userUuid").toString();
            if (StringUtils.isNotEmpty(userString)) {
                checkMap.put("checkUser", userString);
            }
        }

        if (pass == 1) {
            checkMap.put("rewardFixedStatus", RewardSummaryStatus.CHECKED);
            checkMap.put("checkTime", new Date());
            // 审核成功，清除以前的备注
            checkMap.put("remark", "");
        } else {
            checkMap.put("rewardFixedStatus", RewardSummaryStatus.DELETE);
            checkMap.put("checkTime", null);
            if (null != param.get("remark")) {
                String remarkString = param.get("remark").toString();
                if (StringUtils.isNotEmpty(remarkString)) {
                    checkMap.put("remark", remarkString);
                }
            }
        }

        return rewardSummaryService.updateCheckStatus(checkMap);
    }

    /**
     * 结算
     *
     * @param param
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/clear", method = RequestMethod.PUT)
    public ResponseResult clear(@RequestBody Map<String, Object> param) throws BusinessException {
        // 是否通过
        int pass = Integer.parseInt(param.get("pass").toString());

        // 操作人
        String operator = null;
        if (null != param.get("userUuid")) {
            String userString = param.get("userUuid").toString();
            if (StringUtils.isNotEmpty(userString)) {
                operator = userString;
            }
        }

        // 备注
        String remark = null;
        if (null != param.get("remark")) {
            String remarkString = param.get("remark").toString();
            if (StringUtils.isNotEmpty(remarkString)) {
                remark = remarkString;
            }
        }

        // 单号
        String rewardFixedBillCode = param.get("rewardFixedBillCode").toString();
        BigDecimal paymentAmount = new BigDecimal(param.get("paymentAmount").toString());

        // 参数拼装
        RewardFixedClearDto clearDto = new RewardFixedClearDto();
        clearDto.setOperator(operator);
        clearDto.setPass(pass);
        clearDto.setRemark(remark);
        clearDto.setPaymentAmount(paymentAmount);
        String [] codeList = rewardFixedBillCode.split(Separator.DATA_SEPARATOR);
        for(int i=0; i<codeList.length; i++) {
            clearDto.addRewardCode(codeList[i]);
        }

        return rewardSummaryService.updateClearStatus(clearDto);
    }

    /**
     * 读取一个批次的汇总信息
     *
     * @param batchCode
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/batch/{batchCode}", method = RequestMethod.GET)
    public ResponseResult getOneBatch(@PathVariable("batchCode") String batchCode) throws BusinessException {
        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        responseResult.setData(rewardSummaryService.getOneBatchInfo(batchCode));
        return responseResult;
    }

    /**
     * 按批次审核
     *
     * @param batchCode
     * @param param
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/batch/{batchCode}/check", method = RequestMethod.PUT)
    public ResponseResult checkBatch(@PathVariable("batchCode") String batchCode,
                                     @RequestBody Map<String, Object> param) throws BusinessException {
        int pass = Integer.parseInt(param.get("pass").toString());

        Map<String, Object>  checkMap = new HashMap<>();
        checkMap.put("batchCode", batchCode);

        if (null != param.get("userUuid")) {
            String userString = param.get("userUuid").toString();
            if (StringUtils.isNotEmpty(userString)) {
                checkMap.put("checkUser", userString);
            }
        }

        if (pass == 1) {
            checkMap.put("rewardFixedStatus", RewardSummaryStatus.CHECKED);
            checkMap.put("checkTime", new Date());
            // 审核成功，清除以前的备注
            checkMap.put("remark", "");
        } else {
            checkMap.put("rewardFixedStatus", RewardSummaryStatus.DELETE);
            checkMap.put("checkTime", null);
            if (null != param.get("remark")) {
                String remarkString = param.get("remark").toString();
                if (StringUtils.isNotEmpty(remarkString)) {
                    checkMap.put("remark", remarkString);
                }
            }
        }

        return rewardSummaryService.updateCheckBatchStatus(checkMap);
    }

    /**
     * 按批次结算
     *
     * @param param
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/batch/{batchCode}/clear", method = RequestMethod.PUT)
    public ResponseResult clearBatch(@PathVariable("batchCode") String batchCode,
                                     @RequestBody Map<String, Object> param) throws BusinessException {
        // 是否通过
        int pass = Integer.parseInt(param.get("pass").toString());

        // 操作人
        String operator = null;
        if (null != param.get("userUuid")) {
            String userString = param.get("userUuid").toString();
            if (StringUtils.isNotEmpty(userString)) {
                operator = userString;
            }
        }

        // 备注
        String remark = null;
        if (null != param.get("remark")) {
            String remarkString = param.get("remark").toString();
            if (StringUtils.isNotEmpty(remarkString)) {
                remark = remarkString;
            }
        }

        // 金额
        BigDecimal paymentAmount = new BigDecimal(param.get("paymentAmount").toString());

        // 参数拼装
        RewardFixedClearDto clearDto = new RewardFixedClearDto();
        clearDto.setOperator(operator);
        clearDto.setPass(pass);
        clearDto.setRemark(remark);
        clearDto.setPaymentAmount(paymentAmount);
        clearDto.setBatchCode(batchCode);

        return rewardSummaryService.updateClearBatchStatus(clearDto);
    }
}
