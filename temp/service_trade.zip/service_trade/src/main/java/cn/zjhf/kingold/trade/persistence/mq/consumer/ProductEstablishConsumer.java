package cn.zjhf.kingold.trade.persistence.mq.consumer;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.rocketmq.annotation.RocketMQConsumer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQConsumer;
import cn.zjhf.kingold.rocketmq.base.SimpleMessage;
import cn.zjhf.kingold.trade.service.IRewardService;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 产品成立放款，更新奖励结算状态
 *
 * Created by lutiehua on 2017/7/14.
 */
@RocketMQConsumer(topic = "product", tag = "establish")
public class ProductEstablishConsumer extends AbstractMQConsumer<SimpleMessage> {

    @Autowired
    private IRewardService rewardService;

    @Override
    public ResponseResult process(SimpleMessage simpleMessage) throws BusinessException {
        ResponseResult responseResult = new ResponseResult();
        String productUUId = simpleMessage.getData();

        // 更新奖励结算状态
        rewardService.updateProductRewardRecord(productUUId);

        return responseResult;
    }
}
