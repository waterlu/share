package cn.zjhf.kingold.trade.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.entity.InVO.ReconcConditionVO;
import cn.zjhf.kingold.trade.entity.OutVO.CommReportDataVO;
import cn.zjhf.kingold.trade.utils.Tuple.TwoTuple;

import java.util.Date;
import java.util.List;

/**
 * Created by zhangyijie on 2017/6/1.
 */
public interface IReconciliationService {

    public TwoTuple<Integer, Double> getAccountBalance(Long accountNo) throws BusinessException;

    /**
     * 账户余额对账
     * @param
     * @return
     * @throws BusinessException
     */
    public CommReportDataVO checkAccount(ReconcConditionVO condition) throws BusinessException;

    /**
     * 充值提现对账
     * @return
     * @throws BusinessException
     */
    public CommReportDataVO reconciliationRecharge(ReconcConditionVO condition) throws BusinessException;

    /**
     * 交易(投资/放款/还款)对账
     * @return
     * @throws BusinessException
     */
    public CommReportDataVO reconciliationTrade(ReconcConditionVO condition) throws BusinessException;
}
