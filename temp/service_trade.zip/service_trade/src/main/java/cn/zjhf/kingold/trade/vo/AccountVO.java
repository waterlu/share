package cn.zjhf.kingold.trade.vo;

import com.alibaba.fastjson.annotation.JSONField;

import java.math.BigDecimal;

/**
 * @author xiexiaojie
 *         2018/4/8.
 */
public class AccountVO {
    /**
     * 宝付账户账号or用户ID
     */
    private Long accountNo;
    /**
     * 投资人电话
     */
    private String investorMobile;
    /**
     * 开户日期
     */
    private String createTime;
    /**
     * 账户总资产
     */
    private BigDecimal accountTotalAssets;
    /**
     * 账户可用余额
     */
    private BigDecimal accountCashAmount;
    /**
     * 账户冻结金额
     */
    private BigDecimal accountFreezeAmount;
    /**
     * 账户投资金额、在投金额
     */
    private BigDecimal accountInveAmount;
    /**
     * 账户累计收益，包括分红
     */
    private BigDecimal accountAccumProfit;
    /**
     * 账户未兑付产品收益、累计待收收益
     */
    private BigDecimal accountUnpaidProfit;
    /**
     * 用户UUID
     */
    private String userUuid;
    /**
     * 账户类型（层级编码）：11平台托管账户；12平台结算账户；21投资人宝付托管账户；31融资人宝付托管账户；41宝付清算账户；99平台费用账户；
     */
    private String accountType;
    /**
     * 账户状态：1正常；2冻结；3注销；4暂停使用
     */
    private Byte accountStatus;
    /**
     * 开户渠道，1 app, 2 官网，3 内部
     */
    private Integer openChannel;

    public Long getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(Long accountNo) {
        this.accountNo = accountNo;
    }

    public String getInvestorMobile() {
        return investorMobile;
    }

    public void setInvestorMobile(String investorMobile) {
        this.investorMobile = investorMobile;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public BigDecimal getAccountTotalAssets() {
        return accountTotalAssets;
    }

    public void setAccountTotalAssets(BigDecimal accountTotalAssets) {
        this.accountTotalAssets = accountTotalAssets;
    }

    public BigDecimal getAccountCashAmount() {
        return accountCashAmount;
    }

    public void setAccountCashAmount(BigDecimal accountCashAmount) {
        this.accountCashAmount = accountCashAmount;
    }

    public BigDecimal getAccountFreezeAmount() {
        return accountFreezeAmount;
    }

    public void setAccountFreezeAmount(BigDecimal accountFreezeAmount) {
        this.accountFreezeAmount = accountFreezeAmount;
    }

    public BigDecimal getAccountInveAmount() {
        return accountInveAmount;
    }

    public void setAccountInveAmount(BigDecimal accountInveAmount) {
        this.accountInveAmount = accountInveAmount;
    }

    public BigDecimal getAccountAccumProfit() {
        return accountAccumProfit;
    }

    public void setAccountAccumProfit(BigDecimal accountAccumProfit) {
        this.accountAccumProfit = accountAccumProfit;
    }

    public BigDecimal getAccountUnpaidProfit() {
        return accountUnpaidProfit;
    }

    public void setAccountUnpaidProfit(BigDecimal accountUnpaidProfit) {
        this.accountUnpaidProfit = accountUnpaidProfit;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public Byte getAccountStatus() {
        return accountStatus;
    }

    public void setAccountStatus(Byte accountStatus) {
        this.accountStatus = accountStatus;
    }

    public Integer getOpenChannel() {
        return openChannel;
    }

    public void setOpenChannel(Integer openChannel) {
        this.openChannel = openChannel;
    }
}
