package cn.zjhf.kingold.trade.persistence.mq.producer;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.rocketmq.annotation.RocketMQTransactionProducer;
import cn.zjhf.kingold.rocketmq.base.AbstractTransactionMQProducer;
import cn.zjhf.kingold.trade.constant.TradeOrderConstant;
import cn.zjhf.kingold.trade.exception.PendingException;
import cn.zjhf.kingold.trade.persistence.dao.TradeOrderMapper;
import cn.zjhf.kingold.trade.persistence.mq.message.OrderPaidMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

/**
 * 生产定期订单认购成功消息（事务型）
 *
 * @author lutiehua
 * @date 2017/7/13
 */
@RocketMQTransactionProducer(topic = "order", tag = "paid")
public class OrderPaidTransactionProducer extends AbstractTransactionMQProducer<OrderPaidMessage> {

    private final static Logger LOGGER = LoggerFactory.getLogger(OrderPaidTransactionProducer.class);

    @Autowired
    private TradeOrderMapper tradeOrderMapper;

    /**
     * 3分钟还没有处理完，超时取消
     */
    private long TIMEOUT = 3 * 60 * 1000;

    @Override
    public boolean checkState(OrderPaidMessage orderPaidMessage) throws BusinessException {

        // 订单号
        String orderBillCode = orderPaidMessage.getOrderBillCode();

        // 超时，等同于支付失败
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        try {
            Date time = dateFormat.parse(orderBillCode.substring(3,20));
            long now = System.currentTimeMillis();
            if (now - time.getTime() > TIMEOUT) {
                LOGGER.error("订单[{}]支付超时失败", orderBillCode);
                return false;
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }

        // 查询订单
        Map<String, Object> orderInfo = tradeOrderMapper.get(orderBillCode);
        if (orderInfo == null || orderInfo.size() == 0) {
            // 订单不存在
            LOGGER.error("订单[{}]不存在", orderBillCode);
            throw new PendingException();
        }

        // 检查订单状态
        int orderStatus = Integer.parseInt(orderInfo.get("orderStatus").toString());
        if (orderStatus == TradeOrderConstant.ORDER_STATUS_APPLY) {
            int orderPayStatus = Integer.parseInt(orderInfo.get("orderPayStatus").toString());
            if (orderPayStatus == TradeOrderConstant.ORDER_PAY_STATUS_FAILED) {
                // 支付失败
                LOGGER.info("订单[{}]支付失败", orderBillCode);
                return false;
            }
            // 处理中
            LOGGER.info("订单[{}]处理中", orderBillCode);
            throw new PendingException();
        } else {
            // 已经支付完成
            LOGGER.info("订单[{}]支付成功", orderBillCode);
            return true;
        }
    }
}