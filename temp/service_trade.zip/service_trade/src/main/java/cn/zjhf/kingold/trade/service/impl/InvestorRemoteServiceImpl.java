package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.service_consumer.service.UserServiceConsumer;
import cn.zjhf.kingold.trade.constant.URL;
import cn.zjhf.kingold.trade.service.IInvestorRemoteService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Created by wangxun on 2016/11/04.
 * Copyright by zjinv
 */
@Service
public class InvestorRemoteServiceImpl implements IInvestorRemoteService {
    private static final Logger LOGGER = LoggerFactory.getLogger(InvestorRemoteServiceImpl.class);

    @Autowired
    UserServiceConsumer userServiceConsumer;

    /**
     * 远程 获取投资者信息
     *
     * @param userUuid
     * @return
     * @throws BusinessException
     */
    @Override
    public Map getInvestorInfo(String userUuid) throws BusinessException{
        LOGGER.info("获取投资者信息,userUuid:"+userUuid);
        Map<String, Object> urlParam = new HashMap<>();
        urlParam.put("callSystemID", 2003);
        urlParam.put("traceID", UUID.randomUUID().toString());
        ResponseResult responseResult = userServiceConsumer.get(String.format(URL.URL_GET_USER, userUuid), urlParam);
        if (responseResult.isSuccessful()) {
            Map user = userServiceConsumer.getData(responseResult, new HashMap().getClass());
//            user.put("userPhone",user.get("investorMobile"));
            user.put("userPhone",user.get("mobile"));
            return user;
        } else {
            int errorCode = responseResult.getCode();
            String errorMessage = responseResult.getMsg();
            LOGGER.error("errorCode:" + errorCode + ",errorMessage:" + errorMessage);
            throw new BusinessException(errorCode,errorMessage, true);
        }

    }

    /**
     * 检查用户支付密码是否正确
     * @param userUuid
     * @param payPassword
     * @return
     * @throws BusinessException
     */
    @Override
    public boolean checkPayPassword(String userUuid, String payPassword) throws BusinessException{
        LOGGER.info("检查用户支付密码是否正确,userUuid:{},payPassword:{}",userUuid,payPassword);
        Map<String, Object> urlParam = new HashMap<>();
        urlParam.put("callSystemID", 2003);
        urlParam.put("traceID", UUID.randomUUID().toString());
        urlParam.put("userUuid",userUuid);
        urlParam.put("userPayPassword",payPassword);
        ResponseResult responseResult = userServiceConsumer.post(URL.URL_CHECK_PAY_PASSWORD, urlParam);
        if (responseResult.isSuccessful()) {
            String isPass = userServiceConsumer.getData(responseResult, String.class);

            return Boolean.getBoolean(isPass);
        } else {
            int errorCode = responseResult.getCode();
            String errorMessage = responseResult.getMsg();
            LOGGER.error("errorCode:" + errorCode + ",errorMessage:" + errorMessage);
            throw new BusinessException(errorCode, errorMessage, true);
        }

    }


}