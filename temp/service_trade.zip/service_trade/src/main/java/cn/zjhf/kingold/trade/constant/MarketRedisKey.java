package cn.zjhf.kingold.trade.constant;

/**
 * 金币任务redis中存储key
 * @author guoxiaoming
 * @date 2018/1/11
 */
public interface MarketRedisKey {

    /**
     * 每日登录hash key
     */
    String COIN_TASK_LOGIN = "coin_task_login_";

    /**
     * 邀友注册hash key
     */
    String COIN_TASK_FRIEND_REGISTER = "coin_task_friend_register_";

    /**
     * 邀友投资hash key
     */
    String COIN_TASK_FRIEND_INVEST = "coin_task_friend_invest_";

    /**
     * 自己投资hash key
     */
    String COIN_TASK_INVEST = "coin_task_invest_";

    /**
     * 邀友参与金币活动hash key
     */
    String COIN_TASK_FRIEND_JOIN = "coin_task_friend_join_";
}
