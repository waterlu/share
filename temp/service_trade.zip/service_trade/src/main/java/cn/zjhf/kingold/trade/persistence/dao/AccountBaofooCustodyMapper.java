package cn.zjhf.kingold.trade.persistence.dao;

import cn.zjhf.kingold.trade.dto.AccountDTO;
import cn.zjhf.kingold.trade.dto.SendCashDTO;
import cn.zjhf.kingold.trade.utils.WhereCondition;
import cn.zjhf.kingold.trade.vo.AccountVO;
import cn.zjhf.kingold.trade.vo.SendCashVO;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface AccountBaofooCustodyMapper {
    Map get(Map params);

    int insert(Map record);

    int update(Map userInfo);

    int delete(Map params);

    @Select("SELECT account_no FROM account_baofoo_custody where account_uuid = #{accountUUId}")
    String getAccountNoByUUId(String accountUUId);

    Integer getCount(Map userMap);

    List<Map> getList(Map userMap);

    void insertBankCard(Map paramMap);

    int unBindBankCard(@Param("accountUuid") String accountUuid);

    Map checkBankCard(Map checkMap);

    /**
     * 获取一条宝付信息和关联的账户信息
     * @param paramMap
     * @return
     */
    Map getBaofooAndAccount(Map paramMap);

    void freezeWithdrawAmount(Map paramMap);

    /**
     * 获取账户资产查询列表
     * @return
     */
    List<AccountVO> getAccountList(AccountDTO dto);
    /**
     * 获取账户资产查询总数
     * @return
     */
    Integer getAccountCount(AccountDTO dto);
    /**
     * 获取全部提现数据
     * @param dto
     * @return
     */
    SendCashVO getSendCashInfo(SendCashDTO dto);


}