package cn.zjhf.kingold.trade.dto;

import java.util.Date;

/**
 * 投资人信息
 *
 * Created by lutiehua on 2017/5/27.
 */
public class InvestorDto {

    /**
     * 用户UUID
     */
    private String userUuid;

    /**
     * 投资人类型
     */
    private Integer investorType;

    /**
     * 手机号码
     */
    private String investorMobile;

    /**
     * 真实姓名
     */
    private String investorRealName;

    /**
     * 身份证号码
     */
    private String investorIdCardNo;

    /**
     * 住址
     */
    private String userAddress;

    /**
     * 注册时间
     */
    private Date registerTime;

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public Integer getInvestorType() {
        return investorType;
    }

    public void setInvestorType(Integer investorType) {
        this.investorType = investorType;
    }

    public String getInvestorMobile() {
        return investorMobile;
    }

    public void setInvestorMobile(String investorMobile) {
        this.investorMobile = investorMobile;
    }

    public String getUserAddress() {
        return userAddress;
    }

    public void setUserAddress(String userAddress) {
        this.userAddress = userAddress;
    }

    public String getInvestorRealName() {
        return investorRealName;
    }

    public void setInvestorRealName(String investorRealName) {
        this.investorRealName = investorRealName;
    }

    public String getInvestorIdCardNo() {
        return investorIdCardNo;
    }

    public void setInvestorIdCardNo(String investorIdCardNo) {
        this.investorIdCardNo = investorIdCardNo;
    }

    public Date getRegisterTime() {
        return registerTime;
    }

    public void setRegisterTime(Date registerTime) {
        this.registerTime = registerTime;
    }
}
