package cn.zjhf.kingold.trade.persistence.dao;

import cn.zjhf.kingold.trade.entity.UserUnbindBankCardChangeLog;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface UserUnbindBankCardChangeLogMapper {
    int insert(UserUnbindBankCardChangeLog record);
}