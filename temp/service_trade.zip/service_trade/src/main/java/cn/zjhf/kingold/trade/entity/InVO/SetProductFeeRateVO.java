package cn.zjhf.kingold.trade.entity.InVO;

import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * Created by zhangyijie on 2017/6/7.
 */
@ApiModel(value = "SetProductFeeRateVO", description = "设置产品的费率, 通用入参")
public class SetProductFeeRateVO extends InVOBase {
    @ApiModelProperty(required = true, value = "traceID")
    @NotEmpty
    private String traceID;

    @ApiModelProperty(required = true, value = "product_uuid")
    @NotEmpty
    private String product_uuid;

    @ApiModelProperty(required = true, value = "平台服务费率(年化)")
    private double platformServiceFeeRate;

    @ApiModelProperty(required = true, value = "交易所管理费率(年化)")
    private double exchangeManagerFeeRate;

    public String getTraceID() {
        return traceID;
    }

    public void setTraceID(String traceID) {
        this.traceID = traceID;
    }

    public String getProduct_uuid() {
        return product_uuid;
    }

    public void setProduct_uuid(String product_uuid) {
        this.product_uuid = product_uuid;
    }

    public double getPlatformServiceFeeRate() {
        return platformServiceFeeRate;
    }

    public void setPlatformServiceFeeRate(double platformServiceFeeRate) {
        this.platformServiceFeeRate = platformServiceFeeRate;
    }

    public double getExchangeManagerFeeRate() {
        return exchangeManagerFeeRate;
    }

    public void setExchangeManagerFeeRate(double exchangeManagerFeeRate) {
        this.exchangeManagerFeeRate = exchangeManagerFeeRate;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(traceID) + ", ");
        sb.append("product_uuid:" + DataUtils.toString(product_uuid) + ", ");
        sb.append("platformServiceFeeRate:" + DataUtils.toString(platformServiceFeeRate) + ", ");
        sb.append("exchangeManagerFeeRate:" + DataUtils.toString(exchangeManagerFeeRate));
        return sb.toString();
    }
}
