package cn.zjhf.kingold.trade.entity;

/**
 * 充值订单
 *
 * Created by lutiehua on 2017/4/28.
 */
public class RechargeOrder {

}
