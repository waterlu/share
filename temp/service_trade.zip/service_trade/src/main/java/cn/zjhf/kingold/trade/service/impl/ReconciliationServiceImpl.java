package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.constant.PayResponseCode;
import cn.zjhf.kingold.trade.entity.InVO.ReconcConditionVO;
import cn.zjhf.kingold.trade.entity.OutVO.CommReportDataVO;
import cn.zjhf.kingold.trade.entity.ReconVO.ReconAcctInfo;
import cn.zjhf.kingold.trade.entity.ReconVO.ReconRechargeInfo;
import cn.zjhf.kingold.trade.entity.ReconVO.ReconTradeInfo;
import cn.zjhf.kingold.trade.entity.ReconVO.ReconTransAcctInfo;
import cn.zjhf.kingold.trade.persistence.dao.AccountTransactionMapper;
import cn.zjhf.kingold.trade.persistence.dao.OperationReportMapper;
import cn.zjhf.kingold.trade.persistence.dao.TradeRechargeMapper;
import cn.zjhf.kingold.trade.service.IPayService;
import cn.zjhf.kingold.trade.service.IReconciliationService;
import cn.zjhf.kingold.trade.utils.*;
import cn.zjhf.kingold.trade.utils.Tuple.TwoTuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.util.*;

/**
 * 对账服务
 * Created by zhangyijie on 2017/6/1.
 */
@Service
public class ReconciliationServiceImpl extends ProductClearBase implements IReconciliationService {
    private static final Logger logger = LoggerFactory.getLogger(ReconciliationServiceImpl.class);

    private static final Integer BFACCOUNT_NORMAL = 1;
    private static final Integer BFACCOUNT_NOEXIST = 0;
    private static final Integer BFACCOUNT_STATUS_ERR = -1;
    private static final Integer BFACCOUNT_OTHER_ERR = -2;

    private static final String NOEXIST_MSG = "该记录在宝付系统中不存在";

    //账户类型，个人
    private static final int ACCTTYPE_INVE = 1;

    //账户类型，机构
    private static final int ACCTTYPE_INST = 2;

    @Autowired
    OperationReportMapper operationReportMapper;

    /**
     * 获取所有的宝付账户清单
     * @return
     * @throws BusinessException
     */
    private TwoTuple<Integer, List<ReconAcctInfo>> lstAccount(ReconcConditionVO condition) throws BusinessException {
        if(condition.getAcctType() == ACCTTYPE_INST) {
            return lstInstAccount(condition);
        }else {
            return lstInvestorAccount(condition);
        }
    }

    /**
     * 获取所有的个人宝付账户清单
     * @return
     * @throws BusinessException
     */
    private TwoTuple<Integer, List<ReconAcctInfo>> lstInstAccount(ReconcConditionVO condition) throws BusinessException {
        String sql = "SELECT issuer.legal_person_name, issuer.legal_person_mobile, acctbaofoo.account_no, acct.account_cash_amount " +
                "from kingold_trade.account_baofoo_custody acctbaofoo, kingold_trade.account acct, kingold_user.issuer issuer, kingold_user.user user " +
                "where acctbaofoo.account_uuid = acct.account_uuid " +
                "and acct.user_uuid = issuer.user_uuid " +
                "and issuer.user_uuid = user.user_uuid " +
                "and user.user_verify_status >= 3 " +
                "and account_type = 31 ";

        int totalCount = operationReportMapper.lstQueryData(new QueryUtils(sql)).size();

        sql += condition.getPageCondi("acctbaofoo.create_time");
        List<ReconAcctInfo> accounts = new ArrayList<ReconAcctInfo>();
        List<Map> retMapList = operationReportMapper.lstQueryData(new QueryUtils(sql));

        for(Map map : retMapList) {
            BizParam bizParam = new BizParam(map);

            ReconAcctInfo reconAcctInfo = new ReconAcctInfo();
            reconAcctInfo.setInvestorName(bizParam.getString("legal_person_name"));
            reconAcctInfo.setInvestorMobile(bizParam.getString("legal_person_mobile"));
            reconAcctInfo.setAccountNo(bizParam.getLong("account_no"));
            reconAcctInfo.setCashAmount(bizParam.getDouble("account_cash_amount"));
            accounts.add(reconAcctInfo);
        }

        return new TwoTuple<Integer, List<ReconAcctInfo>>(totalCount, accounts);
    }

    /**
     * 获取所有的个人宝付账户清单
     * @return
     * @throws BusinessException
     */
    private TwoTuple<Integer, List<ReconAcctInfo>> lstInvestorAccount(ReconcConditionVO condition) throws BusinessException {
        String sql = "SELECT investor.investor_real_name, investor.investor_mobile, acctbaofoo.account_no, acct.account_cash_amount " +
                "from kingold_trade.account_baofoo_custody acctbaofoo, kingold_trade.account acct, kingold_user.investor investor, kingold_user.user user " +
                "where acctbaofoo.account_uuid = acct.account_uuid " +
                "and acct.user_uuid = investor.user_uuid " +
                "and investor.user_uuid = user.user_uuid " +
                "and user.user_verify_status >= 3 " +
                "and account_type=21 ";

        int totalCount = operationReportMapper.lstQueryData(new QueryUtils(sql)).size();

        sql += condition.getPageCondi("acctbaofoo.create_time");
        List<ReconAcctInfo> accounts = new ArrayList<ReconAcctInfo>();
        List<Map> retMapList = operationReportMapper.lstQueryData(new QueryUtils(sql));

        for(Map map : retMapList) {
            BizParam bizParam = new BizParam(map);

            ReconAcctInfo reconAcctInfo = new ReconAcctInfo();
            reconAcctInfo.setInvestorName(bizParam.getString("investor_real_name"));
            reconAcctInfo.setInvestorMobile(bizParam.getString("investor_mobile"));
            reconAcctInfo.setAccountNo(bizParam.getLong("account_no"));
            reconAcctInfo.setCashAmount(bizParam.getDouble("account_cash_amount"));
            accounts.add(reconAcctInfo);
        }

        return new TwoTuple<Integer, List<ReconAcctInfo>>(totalCount, accounts);
    }

    /**
     * 获取指定账号的宝付方状态和余额
     * @param accountNo
     * @return
     * @throws BusinessException
     */
    public TwoTuple<Integer, Double> getAccountBalance(Long accountNo) throws BusinessException {
        logger.debug(" " + accountNo);
        ResponseResult resResult = payService.getAccountBalance(accountNo);

        if(resResult.getCode() == PayResponseCode.OK) {
            if((resResult.getData() != null) && (resResult.getData() instanceof Double)) {
                return new TwoTuple<Integer, Double>(BFACCOUNT_NORMAL, (Double)resResult.getData());
            }else {
                return new TwoTuple<Integer, Double>(BFACCOUNT_OTHER_ERR, 0.0);
            }
        }else if(resResult.getCode() == PayResponseCode.ERROR_USER_HAS_CANCLE_BIND_CODE) {
            return new TwoTuple<Integer, Double>(BFACCOUNT_STATUS_ERR, 0.0);
        }else if(resResult.getCode() == PayResponseCode.ERROR_USER_NOT_EXIST_CODE) {
            return new TwoTuple<Integer, Double>(BFACCOUNT_NOEXIST, 0.0);
        }

        return new TwoTuple<Integer, Double>(BFACCOUNT_OTHER_ERR, 0.0);
    }

    /**
     * 账户余额对账
     * @param
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public CommReportDataVO checkAccount(ReconcConditionVO condition) throws BusinessException {
        CommReportDataVO commReportData = new CommReportDataVO();
        List<List<String>> retData = new ArrayList<List<String>>();

        retData.add(ReconAcctInfo.getHeader());

        TwoTuple<Integer, List<ReconAcctInfo>> reconAcctSummaryInfo = lstAccount(condition);
        commReportData.setTotalCount(reconAcctSummaryInfo.first);

        List<ReconAcctInfo> reconAcctInfos = reconAcctSummaryInfo.second;
        for(ReconAcctInfo reconAcctInfo : reconAcctInfos) {
            TwoTuple<Integer, Double> accountBalance = getAccountBalance(reconAcctInfo.getAccountNo());

            if(BFACCOUNT_NOEXIST == accountBalance.first){
                reconAcctInfo.addBaofooAcctInfo(0.0,"该账户在宝付系统中不存在");
            }else if(BFACCOUNT_STATUS_ERR == accountBalance.first){
                reconAcctInfo.addBaofooAcctInfo(0.0,"该账户在宝付系统中状态异常");
            }else if(BFACCOUNT_OTHER_ERR == accountBalance.first) {
                reconAcctInfo.addBaofooAcctInfo(0.0,"该账户在宝付系统中有其他错误");
            }else if(BFACCOUNT_NORMAL == accountBalance.first) {
                if(!accountBalance.second.equals(reconAcctInfo.getCashAmount())) {
                    reconAcctInfo.addBaofooAcctInfo(accountBalance.second,"金疙瘩和宝付记录的账户余额不一致");
                }else {
                    continue;
                }
            }

            retData.add(reconAcctInfo.getContent());
        }

        commReportData.setItems(retData);
        return commReportData;
    }

    public static class BaofooQueryData {
        public static final int FLAG_SUCC = 1;

        public String getOrder_id() {
            return order_id;
        }

        public void setOrder_id(String order_id) {
            this.order_id = order_id;
        }

        public double getSucc_amount() {
            return succ_amount;
        }

        public void setSucc_amount(double succ_amount) {
            this.succ_amount = succ_amount;
        }

        public double getBaofoo_fee() {
            return baofoo_fee;
        }

        public void setBaofoo_fee(double baofoo_fee) {
            this.baofoo_fee = baofoo_fee;
        }

        public double getFee() {
            return fee;
        }

        public void setFee(double fee) {
            this.fee = fee;
        }

        public Date getSucc_time() {
            return succ_time;
        }

        public void setSucc_time(Date succ_time) {
            this.succ_time = succ_time;
        }

        public int getState() {
            return state;
        }

        public void setState(int state) {
            this.state = state;
        }

        public int getFee_taken_on() {
            return fee_taken_on;
        }

        public void setFee_taken_on(int fee_taken_on) {
            this.fee_taken_on = fee_taken_on;
        }

        private String order_id;

        private double succ_amount;
        private double baofoo_fee;
        private double fee;

        private Date succ_time;

        //充值：1成功  0处理中
        //提现：1成功  0初始化  -1失败  5转账处理中
        private int state;
        private int fee_taken_on;

        /**
         * 将返回的数据转换成账户列表
         * @param resData
         * @return
         */
        public static Map<String, BaofooQueryData> getList(Object resData) {
            Map<String, BaofooQueryData> dataMap = new HashMap<String, BaofooQueryData>();

            if ((resData != null) && (resData instanceof ArrayList)) {
                ArrayList<HashMap> userMap = (ArrayList<HashMap>) resData;
                if (userMap != null) {
                    for (HashMap map : userMap) {
                        if ((map != null) && (map.keySet().size() > 0)) {
                            BaofooQueryData baofooQueryData = new BaofooQueryData(map);
                            dataMap.put(baofooQueryData.order_id, baofooQueryData);
                        }
                    }
                }
            }

            return dataMap;
        }

        public BaofooQueryData() {
        }

        /**
         * 将map转成对象
         * @param userMap
         */
        public BaofooQueryData(HashMap userMap) {
            BizParam bizParam = new BizParam(userMap);
            order_id = bizParam.get("order_id");

            succ_amount = bizParam.getDouble("succ_amount");
            baofoo_fee = bizParam.getDouble("baofoo_fee");
            fee = bizParam.getDouble("fee");

            succ_time = bizParam.getDate("succ_time");
            state = bizParam.getInt("state");
            fee_taken_on = bizParam.getInt("fee_taken_on");
        }

        @Override
        public boolean equals(Object obj) {
            if (obj instanceof BaofooQueryData) {
                BaofooQueryData baofooQueryData = (BaofooQueryData) obj;
                if(DataUtils.isNotEmpty(this.order_id) && DataUtils.isNotEmpty(baofooQueryData.order_id)) {
                    if ((this.order_id.trim().equals(baofooQueryData.order_id.trim())) &&
                            (this.succ_amount == baofooQueryData.succ_amount) &&
                            (this.baofoo_fee == baofooQueryData.baofoo_fee) &&
                            (this.state == baofooQueryData.state) &&
                            (this.fee_taken_on == baofooQueryData.fee_taken_on)) {
                        return true;
                    } else {
                        return false;
                    }
                }
            }
            return false;
        }

        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder("");
            sb.append("order_id:" + DataUtils.toString(order_id) + ", ");
            sb.append("succ_amount:" + AmountUtils.toString(succ_amount) + ", ");
            sb.append("baofoo_fee:" + AmountUtils.toString(baofoo_fee) + ", ");
            sb.append("fee:" + AmountUtils.toString(fee) + ", ");
            sb.append("succ_time:" + DataUtils.toString(succ_time) + ", ");
            sb.append("state:" + DataUtils.toString(state) + ", ");
            sb.append("fee_taken_on:" + DataUtils.toString(fee_taken_on) + ", ");
            return sb.toString();
        }
    }

    /**
     * 获取宝付指定时间区间的对账文件
     * @param startTime
     * @param endTime
     * @param tryCount
     * @return
     */
    private String getReconciliationFile(Date startTime, Date endTime, int tryCount) throws BusinessException {
        //尝试次数的上限
        final int maxTryCount = 5;

        String filename = null;
        try {
            logger.info(DataUtils.toString(startTime, endTime));
            ResponseResult result = payService.queryTranscationExcel(startTime, endTime);
            if(result.getCode() == PayResponseCode.OK) {
                if(result.getData() instanceof String) {
                    filename = (String)result.getData();
                }else {
                    logger.error("result数据类型错误：" + result.getData().toString());
                }
            }else {
                logger.error("获取宝付对账文件，第" + (++tryCount) + "次失败");
                logger.error(result.getCode() + "|" + result.getMsg());

                if(tryCount <= maxTryCount) {
                    filename = getReconciliationFile(startTime, endTime, tryCount);
                }else {
                    return null;
                }
            }
        } catch (BusinessException e) {
            logger.error("获取宝付对账文件失败！", e);
            throw e;
        }

        return filename;
    }

    private TwoTuple<Integer, List<ReconRechargeInfo>> lstReconRechargeInfo(ReconcConditionVO condition, int reconRechargeType) throws BusinessException {
        List<ReconRechargeInfo> reconRechargeInfos = new ArrayList<ReconRechargeInfo>();
        String sql = "SELECT recharge.trade_order_bill_code_extend as orderCode, investor.investor_real_name as investorName, "
                + "investor.investor_mobile as investorMobile, recharge.agency_account_no as accountNo, "
                + "recharge.recharge_time as platformTime, recharge.recharge_amount as platformAmt, recharge.recharge_fee as platformFeeAmt,"
                + "recharge.recharge_fee_type as platformFeeBearSide, recharge.recharge_status as platformStatus "
                + "from kingold_trade.trade_recharge recharge, kingold_user.investor investor, kingold_user.user user "
                + "where recharge.user_uuid = investor.user_uuid "
                + "and investor.user_uuid = user.user_uuid "
                + "and recharge.create_time BETWEEN " + WhereCondition.toSQLStr(DataUtils.toString(condition.getStartTime())) + " AND " + WhereCondition.toSQLStr(DataUtils.toString(condition.getEndTime())) + " ";

        if(condition.getReconcType() == IPayService.TYPE_RECHARGE) {
            sql += "and recharge.recharge_bill_type = 'RCX' ";
        }else if(condition.getReconcType() == IPayService.TYPE_WITHDRAW) {
            sql += "and recharge.recharge_bill_type = 'WDX' ";
        }else{
            return new TwoTuple<Integer, List<ReconRechargeInfo>>(0, reconRechargeInfos);
        }

        int totalCount = operationReportMapper.lstQueryData(new QueryUtils(sql)).size();

        List<Map> retMapList = operationReportMapper.lstQueryData(new QueryUtils(sql));

        if(retMapList != null) {
            for (Map map : retMapList) {
                BizParam bizParam = new BizParam(map);

                ReconRechargeInfo item = new ReconRechargeInfo();
                item.setOrderCode(bizParam.get("orderCode"));
                item.setInvestorName(bizParam.get("investorName"));
                item.setInvestorMobile(bizParam.get("investorMobile"));
                item.setAccountNo(bizParam.getLong("accountNo"));

                item.setPlatformTime(bizParam.getTimeStr("platformTime"));
                item.setPlatformAmt(bizParam.getDouble("platformAmt"));
                item.setPlatformFeeAmt(bizParam.getDouble("platformFeeAmt"));
                item.setPlatformFeeTakenOn(bizParam.getInt("platformFeeBearSide"));
                item.setPlatformStatus(bizParam.getInt("platformStatus"));

                item.setReconRechargeType(reconRechargeType);
                reconRechargeInfos.add(item);
            }
        }

        return new TwoTuple<Integer, List<ReconRechargeInfo>>(totalCount, reconRechargeInfos);
    }

    /**
     * 充值提现对账
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public CommReportDataVO reconciliationRecharge(ReconcConditionVO condition) throws BusinessException {
        CommReportDataVO reportData = new CommReportDataVO();
        List<List<String>> retData = new ArrayList<List<String>>();

        int reconRechargeType = 0;
        if(condition.getReconcType() == IPayService.TYPE_RECHARGE) {
            retData.add(ReconRechargeInfo.getRechargeHeader());
            reconRechargeType = ReconRechargeInfo.TYPE_RECHARGE;
        }else if(condition.getReconcType() == IPayService.TYPE_WITHDRAW) {
            retData.add(ReconRechargeInfo.getWithdrawalsHeader());
            reconRechargeType = ReconRechargeInfo.TYPE_RECON;
        }else{
            return reportData;
        }

        TwoTuple<Integer, List<ReconRechargeInfo>> reconRechargeSummaryInfo = lstReconRechargeInfo(condition, reconRechargeType);

        reportData.setTotalCount(reconRechargeSummaryInfo.first);
        List<ReconRechargeInfo> reconRechargeInfos = reconRechargeSummaryInfo.second;

        ResponseResult resResult = payService.query(condition.getReconcType(), condition.getStartTime(), condition.getEndTime());
        logger.info("resResult:" + DataUtils.toString(resResult));

        Map<String, BaofooQueryData> baofooQueryDataMap = BaofooQueryData.getList(resResult.getData());

        for(ReconRechargeInfo reconRechargeInfo : reconRechargeInfos) {
            if(baofooQueryDataMap.containsKey(reconRechargeInfo.getOrderCode())) {
                logger.info("OrderCode:" + reconRechargeInfo.getOrderCode());
                BaofooQueryData baofooQueryData = baofooQueryDataMap.get(reconRechargeInfo.getOrderCode());

                if(!reconRechargeInfo.failOrder(baofooQueryData.state)) {
                    if ((!reconRechargeInfo.getPlatformAmt().equals(baofooQueryData.succ_amount))
                            || (!reconRechargeInfo.getPlatformFeeAmt().equals(baofooQueryData.baofoo_fee))
                            || (reconRechargeInfo.getPlatformFeeTakenOn() != baofooQueryData.fee_taken_on)
                            || (!(reconRechargeInfo.checkBaoFooStatus(baofooQueryData.state)))) {
                        reconRechargeInfo.setBaoFooTime(DateUtil.formatTime(baofooQueryData.succ_time));
                        reconRechargeInfo.setBaoFooAmt(baofooQueryData.succ_amount);
                        reconRechargeInfo.setBaoFooFeeAmt(baofooQueryData.baofoo_fee);
                        reconRechargeInfo.setBaoFooFeeTakenOn(baofooQueryData.fee_taken_on);
                        reconRechargeInfo.setBaoFooStatus(baofooQueryData.state);

                        if (!(reconRechargeInfo.checkBaoFooStatus(baofooQueryData.state))) {
                            reconRechargeInfo.setErrMess("状态不一致");
                        }

                        if (!reconRechargeInfo.getPlatformAmt().equals(baofooQueryData.succ_amount)) {
                            reconRechargeInfo.setErrMess("金额不一致");
                        }

                        if (!reconRechargeInfo.getPlatformFeeAmt().equals(baofooQueryData.baofoo_fee)) {
                            reconRechargeInfo.setErrMess("手续费金额不一致");
                        }

                        if (reconRechargeInfo.getPlatformFeeTakenOn() != baofooQueryData.fee_taken_on) {
                            reconRechargeInfo.setErrMess("手续费承担方不一致");
                        }
                    } else {
                        continue;
                    }
                } else {
                    continue;
                }
            }else {
                reconRechargeInfo.setErrMess(NOEXIST_MSG);
            }

            retData.add(reconRechargeInfo.getContent());
        }

        reportData.setItems(retData);
        return reportData;
    }

    private TwoTuple<Integer, List<ReconTradeInfo>> lstReconTradeInfo(ReconcConditionVO condition) throws BusinessException {
        List<ReconTradeInfo> reconTradeInfos = new ArrayList<ReconTradeInfo>();
        String sql = "SELECT account_transaction.trade_order_bill_code_extend as orderCode, investor.investor_real_name as investorName, " +
                "investor.investor_mobile as investorMobile, trade_order.account_no as accountNo, " +
                "trade_order.product_abbr_name as productAbbrName, trade_order.product_period as productTerm, trade_order.expected_profit_amount as profitAmt, " +
                "trade_order.payed_time as platformTime, trade_order.paid_amount as platformAmt, 1 as platformStatus " +
                "from kingold_trade.trade_order trade_order, kingold_trade.account_transaction account_transaction, kingold_user.investor investor, kingold_user.user user " +
                "where trade_order.order_bill_code = account_transaction.trade_order_bill_code and trade_order.user_uuid = investor.user_uuid and investor.user_uuid = user.user_uuid " +
                "and trade_order.payed_time BETWEEN " + WhereCondition.toSQLStr(DataUtils.toString(condition.getStartTime())) + " AND " + WhereCondition.toSQLStr(DataUtils.toString(condition.getEndTime())) + " " +
                "and order_status>1 and order_status<>9 order by trade_order.payed_time desc";

        int totalCount = operationReportMapper.lstQueryData(new QueryUtils(sql)).size();

        List<Map> retMapList = operationReportMapper.lstQueryData(new QueryUtils(sql));

        Set<String> orderCodes = new HashSet<String>();

        if(retMapList != null) {
            for (Map map : retMapList) {
                BizParam bizParam = new BizParam(map);

                ReconTradeInfo item = new ReconTradeInfo();
                item.setOrderCode(bizParam.get("orderCode"));
                item.setInvestorName(bizParam.get("investorName"));
                item.setInvestorMobile(bizParam.get("investorMobile"));
                item.setAccountNo(bizParam.getLong("accountNo"));

                item.setProductAbbrName(bizParam.get("productAbbrName"));
                item.setProductTerm(bizParam.getInt("productTerm"));
                item.setProfitAmt(bizParam.getDouble("profitAmt"));

                item.setPlatformTime(bizParam.getTimeStr("platformTime"));
                item.setPlatformAmt(bizParam.getDouble("platformAmt"));

                item.setPlatformStatus(bizParam.getInt("platformStatus"));

                if(DataUtils.isNotEmpty(item.getOrderCode()) && (!orderCodes.contains(item.getOrderCode()))) {
                    orderCodes.add(item.getOrderCode());
                }else {
                    continue;
                }

                reconTradeInfos.add(item);
            }
        }

        return new TwoTuple<Integer, List<ReconTradeInfo>>(totalCount, reconTradeInfos);
    }

    private Map<String, BaofooQueryData> lstBaofooQueryDataMap(ReconcConditionVO condition) throws BusinessException {
        String filename = getReconciliationFile(condition.getStartTime(), condition.getEndTime(), 0);
        filename = (new File(filename)).exists() ? filename : null;
        logger.info(DataUtils.toString(filename));

        Map<String, BaofooQueryData> baofooQueryDataMap = new HashMap<String, BaofooQueryData>();

        if(filename == null) {
            logger.info("payService.query: " + DataUtils.toString(condition.getReconcType()) + ", " + DataUtils.toString(condition.getStartTime()) + ", " + condition.getEndTime());
            ResponseResult resResult = payService.query(condition.getReconcType(), condition.getStartTime(), condition.getEndTime());
            logger.info(DataUtils.toString(resResult));
            baofooQueryDataMap = BaofooQueryData.getList(resResult.getData());
        }else {
            baofooQueryDataMap = XLSUtils.read(filename, condition.getReconcType());
        }

        return baofooQueryDataMap;
    }

    private CommReportDataVO lstReconTradeData(ReconcConditionVO condition) throws BusinessException {
        CommReportDataVO reportData = new CommReportDataVO();
        List<List<String>> retData = new ArrayList<List<String>>();
        retData.add(ReconTradeInfo.getTradeHeader());

        TwoTuple<Integer, List<ReconTradeInfo>> reconTradeSummaryInfos = lstReconTradeInfo(condition);
        reportData.setTotalCount(reconTradeSummaryInfos.first);

        Map<String, BaofooQueryData> lstBaofooQueryDataMap = lstBaofooQueryDataMap(condition);
        for(ReconTradeInfo reconTradeInfo : reconTradeSummaryInfos.second) {
            if(lstBaofooQueryDataMap.containsKey(reconTradeInfo.getOrderCode())) {
                BaofooQueryData baofooQueryData = lstBaofooQueryDataMap.get(reconTradeInfo.getOrderCode());
                if((reconTradeInfo.getPlatformAmt() != baofooQueryData.succ_amount) || (reconTradeInfo.getPlatformStatus() != baofooQueryData.state)) {
                    reconTradeInfo.setBaoFooAmt(baofooQueryData.succ_amount);
                    reconTradeInfo.setBaoFooStatus(baofooQueryData.state);
                    reconTradeInfo.setBaoFooTime(DataUtils.toString(baofooQueryData.succ_time));
                    if(reconTradeInfo.getPlatformAmt() != baofooQueryData.succ_amount) {
                        reconTradeInfo.setErrMess("金额不一致");
                    }

                    if(reconTradeInfo.getPlatformStatus() != baofooQueryData.state) {
                        reconTradeInfo.setErrMess("状态不一致");
                    }
                }else {
                    continue;
                }
            }else {
                reconTradeInfo.setErrMess(NOEXIST_MSG);
            }

            retData.add(reconTradeInfo.getTradeContent());
        }

        reportData.setItems(retData);
        return reportData;
    }

    private TwoTuple<Integer, List<ReconTradeInfo>> lstReconLoanInfo(ReconcConditionVO condition) throws BusinessException {
        List<ReconTradeInfo> reconTradeInfos = new ArrayList<ReconTradeInfo>();
        String sql = "SELECT trade_invest_summary.batch_no as orderCode, trade_invest_summary.product_abbr_name as productAbbrName, product.product_period as productTerm, " +
                "(SELECT SUM(expected_profit_amount) FROM kingold_trade.trade_order WHERE product_uuid = product.product_uuid and order_status>1 and order_status<>9 ) as profitAmt, " +
                "trade_invest_summary.payed_time as platformTime, trade_invest_summary.raise_investor_amount as platformAmt, " +
                "trade_invest_summary.platform_service_fee as platformFeeAmt, 1 as platformStatus " +
                "from kingold_trade.trade_invest_summary trade_invest_summary, kingold_product.product product  " +
                "where trade_invest_summary.product_uuid = product.product_uuid  " +
                "and trade_invest_summary.payed_time BETWEEN " + WhereCondition.toSQLStr(DataUtils.toString(condition.getStartTime()))
                + " AND " + WhereCondition.toSQLStr(DataUtils.toString(condition.getEndTime())) + " " +
                "and trade_invest_summary.transaction_status = 3 order by trade_invest_summary.payed_time desc ";

        int totalCount = operationReportMapper.lstQueryData(new QueryUtils(sql)).size();

        List<Map> retMapList = operationReportMapper.lstQueryData(new QueryUtils(sql));

        if(retMapList != null) {
            for (Map map : retMapList) {
                BizParam bizParam = new BizParam(map);

                ReconTradeInfo item = new ReconTradeInfo();
                item.setOrderCode(bizParam.get("orderCode"));

                item.setProductAbbrName(bizParam.get("productAbbrName"));
                item.setProductTerm(bizParam.getInt("productTerm"));
                item.setProfitAmt(bizParam.getDouble("profitAmt"));

                item.setPlatformTime(bizParam.getTimeStr("platformTime"));
                item.setPlatformAmt(bizParam.getDouble("platformAmt"));
                item.setPlatformFeeAmt(bizParam.getDouble("platformFeeAmt"));

                item.setPlatformStatus(bizParam.getInt("platformStatus"));

                reconTradeInfos.add(item);
            }
        }

        return new TwoTuple<Integer, List<ReconTradeInfo>>(totalCount, reconTradeInfos);
    }

    private CommReportDataVO lstReconLoanData(ReconcConditionVO condition) throws BusinessException {
        CommReportDataVO reportData = new CommReportDataVO();
        List<List<String>> retData = new ArrayList<List<String>>();
        retData.add(ReconTradeInfo.getLoanHeader());

        TwoTuple<Integer, List<ReconTradeInfo>> reconTradeLoanInfos = lstReconLoanInfo(condition);
        reportData.setTotalCount(reconTradeLoanInfos.first);

        Map<String, BaofooQueryData> lstBaofooQueryDataMap = lstBaofooQueryDataMap(condition);
        for(ReconTradeInfo reconTradeInfo : reconTradeLoanInfos.second) {
            if(lstBaofooQueryDataMap.containsKey(reconTradeInfo.getOrderCode())) {
                BaofooQueryData baofooQueryData = lstBaofooQueryDataMap.get(reconTradeInfo.getOrderCode());
                if((reconTradeInfo.getPlatformAmt() != baofooQueryData.succ_amount) ||
                        (reconTradeInfo.getPlatformStatus() != baofooQueryData.state)/* ||
                        (reconTradeInfo.getPlatformFeeAmt() != baofooQueryData.fee)*/) {
                    reconTradeInfo.setBaoFooAmt(baofooQueryData.succ_amount);
                    reconTradeInfo.setBaoFooFeeAmt(baofooQueryData.fee);
                    reconTradeInfo.setBaoFooStatus(baofooQueryData.state);
                    reconTradeInfo.setBaoFooTime(DataUtils.toString(baofooQueryData.succ_time));
                    if((reconTradeInfo.getPlatformAmt() != baofooQueryData.succ_amount)) {
                        reconTradeInfo.setErrMess("金额不一致");
                    }

                    if(reconTradeInfo.getPlatformStatus() != baofooQueryData.state) {
                        reconTradeInfo.setErrMess("状态不一致");
                    }
                }else {
                    continue;
                }
            }else {
                reconTradeInfo.setErrMess(NOEXIST_MSG);
            }

            retData.add(reconTradeInfo.getLoanContent());
        }

        reportData.setItems(retData);
        return reportData;
    }

    private TwoTuple<Integer, List<ReconTradeInfo>> lstReconRepaymentInfo(ReconcConditionVO condition) throws BusinessException {
        List<ReconTradeInfo> reconTradeInfos = new ArrayList<ReconTradeInfo>();
        String sql = "SELECT trade_payment_summary.batch_no as orderCode, trade_payment_summary.product_abbr_name as productAbbrName, product.product_period as productTerm, " +
                "(SELECT SUM(expected_profit_amount) FROM kingold_trade.trade_order WHERE product_uuid = product.product_uuid) as profitAmt, " +
                "trade_payment_summary.payed_time as platformTime, trade_payment_summary.clear_total_amount as platformAmt, " +
                "1 as platformStatus " +
                "from kingold_trade.trade_payment_summary trade_payment_summary, kingold_product.product product " +
                "where trade_payment_summary.product_uuid = product.product_uuid  " +
                "and trade_payment_summary.payed_time BETWEEN " + WhereCondition.toSQLStr(DataUtils.toString(condition.getStartTime()))
                + " AND " + WhereCondition.toSQLStr(DataUtils.toString(condition.getEndTime())) + " " +
                "and trade_payment_summary.transaction_status = 3 order by trade_payment_summary.payed_time desc ";

        int totalCount = operationReportMapper.lstQueryData(new QueryUtils(sql)).size();

        List<Map> retMapList = operationReportMapper.lstQueryData(new QueryUtils(sql));

        if(retMapList != null) {
            for (Map map : retMapList) {
                BizParam bizParam = new BizParam(map);

                ReconTradeInfo item = new ReconTradeInfo();
                item.setOrderCode(bizParam.get("orderCode"));

                item.setProductAbbrName(bizParam.get("productAbbrName"));
                item.setProductTerm(bizParam.getInt("productTerm"));
                item.setProfitAmt(bizParam.getDouble("profitAmt"));

                item.setPlatformTime(bizParam.getTimeStr("platformTime"));
                item.setPlatformAmt(bizParam.getDouble("platformAmt"));

                item.setPlatformStatus(bizParam.getInt("platformStatus"));

                reconTradeInfos.add(item);
            }
        }

        return new TwoTuple<Integer, List<ReconTradeInfo>>(totalCount, reconTradeInfos);
    }

    private CommReportDataVO lstReconRepaymentData(ReconcConditionVO condition) throws BusinessException {
        CommReportDataVO reportData = new CommReportDataVO();
        List<List<String>> retData = new ArrayList<List<String>>();
        retData.add(ReconTradeInfo.getRepaymentHeader());

        TwoTuple<Integer, List<ReconTradeInfo>> reconRepaymentSummaryInfos = lstReconRepaymentInfo(condition);
        reportData.setTotalCount(reconRepaymentSummaryInfos.first);

        Map<String, BaofooQueryData> lstBaofooQueryDataMap = lstBaofooQueryDataMap(condition);
        for(ReconTradeInfo reconTradeInfo : reconRepaymentSummaryInfos.second) {
            if(lstBaofooQueryDataMap.containsKey(reconTradeInfo.getOrderCode())) {
                BaofooQueryData baofooQueryData = lstBaofooQueryDataMap.get(reconTradeInfo.getOrderCode());
                if((reconTradeInfo.getPlatformAmt() != baofooQueryData.succ_amount) || (reconTradeInfo.getPlatformStatus() != baofooQueryData.state)) {
                    reconTradeInfo.setBaoFooAmt(baofooQueryData.succ_amount);
                    reconTradeInfo.setBaoFooStatus(baofooQueryData.state);
                    reconTradeInfo.setBaoFooTime(DataUtils.toString(baofooQueryData.succ_time));
                    if(reconTradeInfo.getPlatformAmt() != baofooQueryData.succ_amount) {
                        reconTradeInfo.setErrMess("金额不一致");
                    }

                    if(reconTradeInfo.getPlatformStatus() != baofooQueryData.state) {
                        reconTradeInfo.setErrMess("状态不一致");
                    }
                }else {
                    continue;
                }
            }else {
                reconTradeInfo.setErrMess(NOEXIST_MSG);
            }

            retData.add(reconTradeInfo.getRepaymentContent());
        }

        reportData.setItems(retData);
        return reportData;
    }

    private TwoTuple<Integer, List<ReconTransAcctInfo>> lstReconTransAcctInfo(ReconcConditionVO condition) throws BusinessException {
        List<ReconTransAcctInfo> reconTransAcctInfos = new ArrayList<ReconTransAcctInfo>();
        String sql = "SELECT paylog.pay_order_id as orderCode, transaction.account_no as accountNo, " +
                "transaction.transaction_time as platformTime, transaction.transaction_amount as platformAmt, 1 AS platformStatus " +
                "FROM account_transaction transaction, pay_log paylog " +
                "WHERE transaction.trade_order_bill_code_extend = paylog.order_bill_code AND transaction.trade_type in ('CPA') and transaction.transaction_amount>0 " +
                "and transaction.transaction_time BETWEEN " + WhereCondition.toSQLStr(DataUtils.toString(condition.getStartTime())) +
                " AND " + WhereCondition.toSQLStr(DataUtils.toString(condition.getEndTime())) +
                " order by transaction.transaction_time desc ";

        int totalCount = operationReportMapper.lstQueryData(new QueryUtils(sql)).size();

        List<Map> retMapList = operationReportMapper.lstQueryData(new QueryUtils(sql));

        if(retMapList != null) {
            for (Map map : retMapList) {
                BizParam bizParam = new BizParam(map);

                ReconTransAcctInfo item = new ReconTransAcctInfo();
                item.setOrderCode(bizParam.getString("orderCode"));
                item.setAccountNo(bizParam.getLong("accountNo"));
                item.setPlatformTime(bizParam.getTimeStr("platformTime"));
                item.setPlatformAmt(bizParam.getDouble("platformAmt"));
                item.setPlatformStatus(bizParam.getInt("platformStatus"));
                reconTransAcctInfos.add(item);
            }
        }

        return new TwoTuple<Integer, List<ReconTransAcctInfo>>(totalCount, reconTransAcctInfos);
    }

    public CommReportDataVO lstReconTransAcctData(ReconcConditionVO condition) throws BusinessException {
        CommReportDataVO reportData = new CommReportDataVO();
        List<List<String>> retData = new ArrayList<List<String>>();
        retData.add(ReconTransAcctInfo.getHeader());

        TwoTuple<Integer, List<ReconTransAcctInfo>> reconTransAcctInfos = lstReconTransAcctInfo(condition);
        reportData.setTotalCount(reconTransAcctInfos.first);

        Map<String, BaofooQueryData> lstBaofooQueryDataMap = lstBaofooQueryDataMap(condition);
        for(ReconTransAcctInfo reconTransAcctInfo : reconTransAcctInfos.second) {
            if(lstBaofooQueryDataMap.containsKey(reconTransAcctInfo.getOrderCode())) {
                BaofooQueryData baofooQueryData = lstBaofooQueryDataMap.get(reconTransAcctInfo.getOrderCode());
                if((reconTransAcctInfo.getPlatformAmt() != baofooQueryData.succ_amount) || (reconTransAcctInfo.getPlatformStatus() != baofooQueryData.state)) {
                    reconTransAcctInfo.setBaoFooAmt(baofooQueryData.succ_amount);
                    reconTransAcctInfo.setBaoFooStatus(baofooQueryData.state);
                    reconTransAcctInfo.setBaoFooTime(DataUtils.toString(baofooQueryData.succ_time));
                    if(reconTransAcctInfo.getPlatformAmt() != baofooQueryData.succ_amount) {
                        reconTransAcctInfo.setErrMess("金额不一致");
                    }

                    if(reconTransAcctInfo.getPlatformStatus() != baofooQueryData.state) {
                        reconTransAcctInfo.setErrMess("状态不一致");
                    }
                }else {
                    continue;
                }
            }else {
                reconTransAcctInfo.setErrMess(NOEXIST_MSG);
            }

            retData.add(reconTransAcctInfo.getContent());
        }

        reportData.setItems(retData);
        return reportData;
    }

    /**
     * 交易(投资/放款/还款)对账
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public CommReportDataVO reconciliationTrade(ReconcConditionVO condition) throws BusinessException {
        if(condition.getReconcType() == IPayService.TYPE_INVEST) {
            return lstReconTradeData(condition);
        }else if(condition.getReconcType() == IPayService.TYPE_PAYMENT) {
            return lstReconLoanData(condition);
        }else if(condition.getReconcType() == IPayService.TYPE_REPAYMENT){
            return lstReconRepaymentData(condition);
        }else if(condition.getReconcType() == IPayService.TYPE_TRANSFER) {
            return lstReconTransAcctData(condition);
        }

        return new CommReportDataVO();
    }
}