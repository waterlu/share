package cn.zjhf.kingold.trade.entity;

/**
 * @author lutiehua
 * @date 2018/3/26
 */
public class AccountDO {

    /**
     * 用户UUId
     */
    private String userUuid;

    /**
     * 账户UUId
     */
    private String accountUuid;

    /**
     * 宝付账号
     */
    private Long accountNo;

    /**
     * 账户类型
     */
    private String accountType;

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getAccountUuid() {
        return accountUuid;
    }

    public void setAccountUuid(String accountUuid) {
        this.accountUuid = accountUuid;
    }

    public Long getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(Long accountNo) {
        this.accountNo = accountNo;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    @Override
    public String toString() {
        return "AccountDO{" +
                "userUuid='" + userUuid + '\'' +
                ", accountUuid='" + accountUuid + '\'' +
                ", accountNo=" + accountNo +
                ", accountType='" + accountType + '\'' +
                '}';
    }
}
