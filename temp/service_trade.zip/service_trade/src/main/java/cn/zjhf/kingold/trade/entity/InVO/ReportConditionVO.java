package cn.zjhf.kingold.trade.entity.InVO;

import cn.zjhf.kingold.trade.utils.DataUtils;
import cn.zjhf.kingold.trade.utils.StringOrDate;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import java.util.Date;

/**
 * Created by zhangyijie on 2017/6/29.
 */
@ApiModel(value = "ReportConditionVO", description = "报表查询条件")
public class ReportConditionVO extends InVOBase {
    @ApiModelProperty(required = true, value = "traceID")
    @NotEmpty
    private String traceID;

    @ApiModelProperty(required = true, value = "报告编号")
    @NotEmpty
    private String reportNo;

    @ApiModelProperty(required = true, value = "productUuid")
    private String productUuid;

    @ApiModelProperty(required = true, value = "产品简称")
    private String productAbbrName;

    @ApiModelProperty(required = true, value = "产品编号")
    private String productCode;

    @ApiModelProperty(required = true, value = "产品状态")
    private Integer productStatus;

    @ApiModelProperty(required = true, value = "产品类型：固收产品FIXI，私募产品PRIF")
    private String productType;

    @ApiModelProperty(required = true, value = "产品募集起始日_开始日期")
    private Date productStartRaiseBeginDate;

    @ApiModelProperty(required = true, value = "产品募集起始日_结束日期")
    private Date productStartRaiseEndDate;

    @ApiModelProperty(required = true, value = "产品成立日_开始日期")
    private Date productEstablishmentBeginDate;

    @ApiModelProperty(required = true, value = "产品成立日_截止日期")
    private Date productEstablishmentEndDate;

    @ApiModelProperty(required = true, value = "产品起息日_开始日期")
    private Date productInterestBeginDate;

    @ApiModelProperty(required = true, value = "产品起息日_结束日期")
    private Date productInterestEndDate;

    @ApiModelProperty(required = true, value = "产品到期日_开始日期")
    private Date productExpiringBeginDate;

    @ApiModelProperty(required = true, value = "产品到期日_结束日期")
    private Date productExpiringEndDate;

    @ApiModelProperty(required = true, value = "用户userUuid user_uuid")
    private String userUuid;

    @ApiModelProperty(required = true, value = "用户ID account_no")
    private String userId;

    @ApiModelProperty(required = true, value = "用户姓名")
    private String userName;

    @ApiModelProperty(required = true, value = "用户手机号")
    private String userPhoneNumber;

    @ApiModelProperty(required = true, value = "订单号")
    private String orderId;

    @ApiModelProperty(required = true, value = "身份证号")
    private String idCard;

    @ApiModelProperty(required = true, value = "活动计税类型 1.现金券 2.产品加息 3.体验金 4.加息券")
    private Integer activityType;

    @ApiModelProperty(required = true, value = "附件编号")
    private String fileCode;

    @ApiModelProperty(required = true, value = "交易起始日期")
    private Date tradeBeginDate;

    @ApiModelProperty(required = true, value = "交易起始日期")
    private Date tradeEndDate;

    @ApiModelProperty(required = true, value = "是否导出数据,导出数据,1  默认 0")
    private int exportExcel;

    @ApiModelProperty(required = true, value = "产品期限")
    private Integer productPeriod;

    @ApiModelProperty(required = true, value = "起始序号")
    private int beginSN;

    @ApiModelProperty(required = true, value = "结束序号")
    private int endSN;

    /**
     * 用户类型
     * 1.普通投资人
     * 2.机构投资人
     */
    private Integer userType;

    @Override
    public String getTraceID() {
        return traceID;
    }

    @Override
    public void setTraceID(String traceID) {
        this.traceID = traceID;
    }

    public String getReportNo() {
        return reportNo;
    }

    public void setReportNo(String reportNo) {
        this.reportNo = reportNo;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductAbbrName() {
        return productAbbrName;
    }

    public void setProductAbbrName(String productAbbrName) {
        this.productAbbrName = productAbbrName;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public Integer getProductStatus() {
        return productStatus;
    }

    public void setProductStatus(Integer productStatus) {
        this.productStatus = productStatus;
    }

    public Date getProductInterestBeginDate() {
        return productInterestBeginDate;
    }

    public void setProductInterestBeginDate(Date productInterestBeginDate) {
        this.productInterestBeginDate = productInterestBeginDate;
    }

    public Date getProductInterestEndDate() {
        return productInterestEndDate;
    }

    public void setProductInterestEndDate(Date productInterestEndDate) {
        this.productInterestEndDate = productInterestEndDate;
    }

    public Date getProductExpiringBeginDate() {
        return productExpiringBeginDate;
    }

    public void setProductExpiringBeginDate(Date productExpiringBeginDate) {
        this.productExpiringBeginDate = productExpiringBeginDate;
    }

    public Date getProductExpiringEndDate() {
        return productExpiringEndDate;
    }

    public void setProductExpiringEndDate(Date productExpiringEndDate) {
        this.productExpiringEndDate = productExpiringEndDate;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public Integer getActivityType() {
        return activityType;
    }

    public void setActivityType(Integer activityType) {
        this.activityType = activityType;
    }

    public String getFileCode() {
        return fileCode;
    }

    public void setFileCode(String fileCode) {
        this.fileCode = fileCode;
    }

    public int getBeginSN() {
        return beginSN;
    }

    public void setBeginSN(int beginSN) {
        this.beginSN = beginSN;
    }

    public int getEndSN() {
        return endSN;
    }

    public void setEndSN(int endSN) {
        this.endSN = endSN;
    }

    public Integer getProductPeriod() {
        return productPeriod;
    }

    public void setProductPeriod(Integer productPeriod) {
        this.productPeriod = productPeriod;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public Date getTradeBeginDate() {
        return tradeBeginDate;
    }

    public void setTradeBeginDate(Date tradeBeginDate) {
        this.tradeBeginDate = tradeBeginDate;
    }

    public Date getTradeEndDate() {
        return tradeEndDate;
    }

    public void setTradeEndDate(Date tradeEndDate) {
        this.tradeEndDate = tradeEndDate;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserPhoneNumber() {
        return userPhoneNumber;
    }

    public void setUserPhoneNumber(String userPhoneNumber) {
        this.userPhoneNumber = userPhoneNumber;
    }

    public Date getProductStartRaiseBeginDate() {
        return productStartRaiseBeginDate;
    }

    public void setProductStartRaiseBeginDate(Date productStartRaiseBeginDate) {
        this.productStartRaiseBeginDate = productStartRaiseBeginDate;
    }

    public Date getProductStartRaiseEndDate() {
        return productStartRaiseEndDate;
    }

    public void setProductStartRaiseEndDate(Date productStartRaiseEndDate) {
        this.productStartRaiseEndDate = productStartRaiseEndDate;
    }

    public Date getProductEstablishmentBeginDate() {
        return productEstablishmentBeginDate;
    }

    public void setProductEstablishmentBeginDate(Date productEstablishmentBeginDate) {
        this.productEstablishmentBeginDate = productEstablishmentBeginDate;
    }

    public Date getProductEstablishmentEndDate() {
        return productEstablishmentEndDate;
    }

    public void setProductEstablishmentEndDate(Date productEstablishmentEndDate) {
        this.productEstablishmentEndDate = productEstablishmentEndDate;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public int getExportExcel() {
        return exportExcel;
    }

    public void setExportExcel(int exportExcel) {
        this.exportExcel = exportExcel;
    }

    public Integer getUserType() {
        return userType;
    }

    public void setUserType(Integer userType) {
        this.userType = userType;
    }

    public static String getTimeSection(Date beginDate, Date endDate) {
        StringBuilder sb = new StringBuilder();
        if ((null != beginDate) && (null != endDate)) {
            sb.append(StringOrDate.formatDate(beginDate, "yyyy/MM/dd"));
            sb.append("-");
            sb.append(StringOrDate.formatDate(endDate, "yyyy/MM/dd"));
        }
        return sb.toString();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(traceID) + ", ");
        sb.append("reportNo:" + DataUtils.toString(reportNo) + ", ");
        sb.append("productUuid:" + DataUtils.toString(productUuid) + ", ");
        sb.append("productAbbrName:" + DataUtils.toString(productAbbrName) + ", ");
        sb.append("productCode:" + DataUtils.toString(productCode) + ", ");
        sb.append("productStatus:" + DataUtils.toString(productStatus) + ", ");
        sb.append("productType:" + DataUtils.toString(productType) + ", ");

        sb.append("productStartRaiseBeginDate:" + DataUtils.toString(productStartRaiseBeginDate) + ", ");
        sb.append("productStartRaiseEndDate:" + DataUtils.toString(productStartRaiseEndDate) + ", ");
        sb.append("productEstablishmentBeginDate:" + DataUtils.toString(productEstablishmentBeginDate) + ", ");
        sb.append("productEstablishmentEndDate:" + DataUtils.toString(productEstablishmentEndDate) + ", ");

        sb.append("productInterestBeginDate:" + DataUtils.toString(productInterestBeginDate) + ", ");
        sb.append("productInterestEndDate:" + DataUtils.toString(productInterestEndDate) + ", ");
        sb.append("productExpiringBeginDate:" + DataUtils.toString(productExpiringBeginDate) + ", ");
        sb.append("productExpiringEndDate:" + DataUtils.toString(productExpiringEndDate) + ", ");

        sb.append("tradeBeginDate:" + DataUtils.toString(tradeBeginDate) + ", ");
        sb.append("tradeEndDate:" + DataUtils.toString(tradeEndDate) + ", ");

        sb.append("orderId:" + DataUtils.toString(orderId) + ", ");
        sb.append("idCard:" + DataUtils.toString(idCard) + ", ");
        sb.append("activityType:" + DataUtils.toString(activityType) + ", ");
        sb.append("fileCode:" + DataUtils.toString(fileCode) + ", ");
        sb.append("exportExcel:" + DataUtils.toString(exportExcel) + ", ");

        sb.append("productPeriod:" + DataUtils.toString(productPeriod) + ", ");
        sb.append("userType:" + DataUtils.toString(userType) + ", ");
        sb.append("beginSN:" + DataUtils.toString(beginSN) + ", ");
        sb.append("endSN:" + DataUtils.toString(endSN));
        return sb.toString();
    }

}
