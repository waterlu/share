package cn.zjhf.kingold.trade.entity.ReconVO;

import cn.zjhf.kingold.trade.utils.AmountUtils;
import cn.zjhf.kingold.trade.utils.BizParam;
import cn.zjhf.kingold.trade.utils.DataUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 对账的账户信息
 * Created by zhangyijie on 2017/7/21.
 */
public class ReconAcctInfo {
    private String investorName;

    private String investorMobile;

    private Long accountNo = 0L;
    public Long getAccountNo() {
        return accountNo;
    }

    private Double cashAmount = 0.0;
    public Double getCashAmount() {
        return cashAmount;
    }

    private Double baoFooAmount = 0.0;

    private String checkMess;

    public static List<String> getHeader() {
        List<String> header = new ArrayList<String>();
        header.add("用户姓名");
        header.add("手机号");
        header.add("宝付ID");
        header.add("金疙瘩账户余额");
        header.add("宝付账户余额");
        header.add("错误原因");

        return header;
    }

    public ReconAcctInfo() {
    }

    public List<String> getContent() {
        List<String> curLine = new ArrayList<String>();
        curLine.add(investorName);
        curLine.add(investorMobile);
        curLine.add(accountNo + "");

        curLine.add(AmountUtils.toString(cashAmount));
        curLine.add(AmountUtils.toString(baoFooAmount));
        curLine.add(checkMess);
        return curLine;
    }

    public void addBaofooAcctInfo(Double baoFooAmount, String checkMess) {
        this.baoFooAmount = baoFooAmount;
        this.checkMess = checkMess;
    }

    public String getInvestorName() {
        return investorName;
    }

    public void setInvestorName(String investorName) {
        this.investorName = investorName;
    }

    public String getInvestorMobile() {
        return investorMobile;
    }

    public void setInvestorMobile(String investorMobile) {
        this.investorMobile = investorMobile;
    }

    public void setAccountNo(Long accountNo) {
        this.accountNo = accountNo;
    }

    public void setCashAmount(Double cashAmount) {
        this.cashAmount = cashAmount;
    }

    public Double getBaoFooAmount() {
        return baoFooAmount;
    }

    public void setBaoFooAmount(Double baoFooAmount) {
        this.baoFooAmount = baoFooAmount;
    }

    public String getCheckMess() {
        return checkMess;
    }

    public void setCheckMess(String checkMess) {
        if(DataUtils.isEmpty(this.checkMess)) {
            this.checkMess = checkMess;
        }else {
            this.checkMess += "|" + checkMess;
        }
    }
}
