package cn.zjhf.kingold.trade.persistence.mq.consumer;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.rocketmq.base.AbstractMQConsumer;
import cn.zjhf.kingold.rocketmq.base.SimpleMessage;
import cn.zjhf.kingold.trade.client.ProductClient;
import cn.zjhf.kingold.trade.constant.BizDefine;
import cn.zjhf.kingold.trade.constant.TradeError;
import cn.zjhf.kingold.trade.constant.TradeStatusMsg;
import cn.zjhf.kingold.trade.entity.ProductFixedIncome;
import cn.zjhf.kingold.trade.entity.TradeOrder;
import cn.zjhf.kingold.trade.persistence.dao.TradeOrderMapper;
import cn.zjhf.kingold.trade.service.ITradeExecService;
import cn.zjhf.kingold.trade.utils.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by lutiehua on 2017/8/4.
 */
//@RocketMQConsumer(topic = "product", tag = "expire")
@Deprecated
public class ProductExpireConsumer extends AbstractMQConsumer<SimpleMessage> {

    @Autowired
    private ITradeExecService tradeExecService;

    @Autowired
    protected TradeOrderMapper tradeOrderMapper;

    @Autowired
    protected ProductClient productClient;

    @Override
    public ResponseResult process(SimpleMessage simpleMessage) throws BusinessException {
        ResponseResult responseResult = new ResponseResult();
        String productUUId = simpleMessage.getData();
        ProductFixedIncome productFixedIncome = getFixedIncomeProductById(productUUId);
        if (productFixedIncome.getProductStatus() != BizDefine.PRODUCT_STATUS_CLEAR) {
            // 产品状态可能还没有改，等一下
            logger.warn("productUUId={}, status={}", productUUId, productFixedIncome.getProductStatus());
            responseResult.setCode(ResponseCode.EXCEPTION);
            responseResult.setMsg(ResponseCode.EXCEPTION_TEXT);
            return responseResult;
        }

        //对于渠道方的订单，自动做提现处理
        WhereCondition condition = new WhereCondition();
        condition.setCondi("product_uuid", productUUId);
        condition.setCondi("order_status", BizDefine.ORDER_STATUS_CLEAR);
        condition.noDelete();
        for(TradeOrder tradeOrder : lstTradeOrdersByCondition(condition)) {
            if(DataUtils.isNotEmpty(tradeOrder.getTransactionChannel())) {
                double tradeCashAmount = AmountUtils.normal(tradeOrder.getOrderAmount().doubleValue() + tradeOrder.getExpectedProfitAmount().doubleValue());

                try {
                    tradeExecService.freezeWithdraw(tradeOrder.getUserUuid(), tradeCashAmount, tradeOrder.getTransactionChannel());
                }catch(BusinessException exception) {
                    logger.error("自动提现失败:{}", exception.getMessage());
                }
            }
        }

        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        return responseResult;
    }

    //获取固收产品
    protected ProductFixedIncome getFixedIncomeProductById(String productUUId) throws BusinessException {
        Map<String, Object> param = new HashMap<>();
        ResponseResult responseResult = productClient.getFixedIncome(productUUId, param);
        logger.info("responseResult: {}", (responseResult != null) ? responseResult.toString() : "null");

        if ((responseResult == null) || (responseResult.getCode() != TradeError.OK) || (responseResult.getData() == null)) {
            throw new BusinessException(TradeStatusMsg.PRODUCT_NOT_EXIST, TradeStatusMsg.PRODUCT_NOT_EXIST_MSG, false);
        }

        ProductFixedIncome productInfo = JsonUtil.getData(responseResult, ProductFixedIncome.class);
        if (productInfo == null) {
            throw new BusinessException(TradeStatusMsg.PRODUCT_NOT_EXIST, TradeStatusMsg.PRODUCT_NOT_EXIST_MSG, false);
        }

        return productInfo;
    }

    //根据条件查询指定交易记录
    protected List<TradeOrder> lstTradeOrdersByCondition(WhereCondition condition) {
        List<TradeOrder> items = new ArrayList<TradeOrder>();
        List<Map> maps = tradeOrderMapper.lstByCondition(condition);
        for(Map map : maps) {
            BizParam bizParam = new BizParam(map);
            TradeOrder tradeOrder = new TradeOrder();
            tradeOrder.setUserUuid(bizParam.get("user_uuid"));
            tradeOrder.setAccountUuid(bizParam.get("account_uuid"));

            tradeOrder.setOrderBillCode(bizParam.get("order_bill_code"));
            tradeOrder.setUserName(bizParam.get("user_name"));
            tradeOrder.setUserPhone(bizParam.get("user_phone"));
            tradeOrder.setTransactionChannel(bizParam.get("transaction_channel"));
            tradeOrder.setTransactionTime(bizParam.getDate("transaction_time"));
            tradeOrder.setProductUuid(bizParam.get("product_uuid"));
            tradeOrder.setOrderAmount(bizParam.getBigDecimal("order_amount"));

            tradeOrder.setExpectedProfitAmount(bizParam.getBigDecimal("expected_profit_amount"));
            tradeOrder.setPaidAmount(bizParam.getBigDecimal("paid_amount"));
            tradeOrder.setMarketingAmount(bizParam.getBigDecimal("marketing_amount"));
            tradeOrder.setProfitAmount(bizParam.getBigDecimal("profit_amount"));
            tradeOrder.setCashAmount(bizParam.getBigDecimal("cash_amount"));

            tradeOrder.setOrderStatus(bizParam.getByte("order_status"));
            tradeOrder.setMarketingRateAmount(bizParam.getBigDecimal("marketing_rate_amount"));

            items.add(tradeOrder);
        }

        return items;
    }
}
