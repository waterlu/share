package cn.zjhf.kingold.trade.entity.InVO.CommGrant;

/**
 * Created by zhangyijie on 2018/2/2.
 */
public class CashCouponGrantVO extends CommGrantItemBaseVO {
    /**
     * 批次号
     */
    private String ccCode;

    public String getCcCode() {
        return ccCode;
    }

    public void setCcCode(String ccCode) {
        this.ccCode = ccCode;
    }

    @Override
    public String toString() {
        return "CashCouponGrantVO{" +
                super.toString() +
                "ccCode='" + ccCode + '\'' +
                '}';
    }
}
