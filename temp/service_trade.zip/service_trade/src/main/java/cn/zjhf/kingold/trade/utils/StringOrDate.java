package cn.zjhf.kingold.trade.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class StringOrDate {

    /**
     * 常用的日期格式常量
     */
    public static String DAY_FROMAT = "yyyy-MM-dd";
    public static String TIME_FROMAT = "HH:mm:ss";
    public static String YEAR_MONTH_DATE_HOUR_MINUTE = "yyyy-MM-dd HH:mm";
    public static String CURRENTTIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
    public static String TIMESTAMP_FORMAT = "yyyy-MM-dd kk:mm:ss.SSS";
    public static String YEAR_FROMAT = "yyyy";
    public static final String YEAR_MONTH_DATE_HOUR_MINUTE_CN = "yyyy年MM月dd日 HH:mm";
    public static String FORMT1="yyyyMMddHHmmss";

    public static String SHORT = "SHORT";
    public static String MEDIUM = "MEDIUM";
    public static String FULL = "FULL";

    /**
     * @Title: formatDate
     * @Description: ( 日期格式化为字符串)
     * @param @param date日期
     * @param @param formatStr需要的格式
     * @return String    返回类型
     * @throws
     */
    public static String formatDate(Date date,String formatStr){
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat();
        simpleDateFormat.applyPattern(formatStr);
        return simpleDateFormat.format(date );
    }


    public static String dateToString(Date date, String type) {
        String str = null;
        DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        if (type.equals("SHORT")) {
            // 07-1-18
            format = DateFormat.getDateInstance(DateFormat.SHORT);
            str = format.format(date);
        } else if (type.equals("MEDIUM")) {
            // 2007-1-18
            str = format.format(date);
        } else if (type.equals("FULL")) {
            // 2007年1月18日 星期四
            format = DateFormat.getDateInstance(DateFormat.FULL);
            str = format.format(date);
        }
        return str;
    }

    public static Date strToDate(String str) {
        DateFormat format = new SimpleDateFormat(CURRENTTIME_FORMAT);
        Date date = null;
        try {
            // Fri Feb 24 00:00:00 CST 2012
            date = format.parse(str);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return date;
    }
    public static Date newStrToDate(String stringDate) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(CURRENTTIME_FORMAT);
        try {
            return simpleDateFormat.parse(stringDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static Date stringToDate(String str) {
        DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Date date = null;
        try {
            // Fri Feb 24 00:00:00 CST 2012
            date = format.parse(str);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        // 2012-02-24
        date = java.sql.Date.valueOf(str);

        return date;
    }

    /**
     * 将Date偏移count年，正数往前偏移，负数往后偏移
     * @param date
     * @param count
     * @return
     */
    public static Date addYear(Date date, int count) {
        Calendar calendar   =   new GregorianCalendar();
        calendar.setTime(date);
        calendar.add(calendar.YEAR, count);//把日期往后增加count年.整数往后推,负数往前移动
        return calendar.getTime();   //这个时间就是日期往后推count年的结果
    }

    /**
     * 将Date偏移count月，正数往前偏移，负数往后偏移
     * @param date
     * @param count
     * @return
     */
    public static Date addMonth(Date date, int count) {
        Calendar calendar   =   new GregorianCalendar();
        calendar.setTime(date);
        calendar.add(calendar.MONTH, count);//把日期往后增加count月.整数往后推,负数往前移动
        return calendar.getTime();   //这个时间就是日期往后推count月的结果
    }

    /**
     * 将date向前增加 offsetDay 天
     * @param date
     * @param offsetDay //把日期往后增加一天.整数往后推,负数往前移动
     * @return
     */
    public static Date dateOffsetDay(Date date, int offsetDay) {

        Calendar calendar   =   new GregorianCalendar();
        calendar.setTime(date);
        calendar.add(calendar.DATE,offsetDay);//把日期往后增加一天.整数往后推,负数往前移动
        return calendar.getTime();   //这个时间就是日期往后推一天的结果
    }

    /**
     * 获取当月第一天
     * @return
     */
    public static String getFirstDayOfMonth(){
        Calendar cale = Calendar.getInstance();

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String firstday;
        // 获取前月的第一天
        cale = Calendar.getInstance();
        cale.add(Calendar.MONTH, 0);
        cale.set(Calendar.DAY_OF_MONTH, 1);
        firstday = format.format(cale.getTime());
        return firstday + " 00:00:00";
    }

    public static Date getCurDate() {
        Date now = new Date();
        Calendar cal1 = Calendar.getInstance();
        cal1.setTime(now);
        // 将时分秒,毫秒域清零
        cal1.set(Calendar.HOUR_OF_DAY, 0);
        cal1.set(Calendar.MINUTE, 0);
        cal1.set(Calendar.SECOND, 0);
        cal1.set(Calendar.MILLISECOND, 0);
        return cal1.getTime();
    }
}
