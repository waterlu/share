package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.constant.TradeStatusMsg;
import cn.zjhf.kingold.trade.entity.ChannelCommisionDetail;
import cn.zjhf.kingold.trade.entity.ChannelCommisionSummary;
import cn.zjhf.kingold.trade.entity.InVO.*;
import cn.zjhf.kingold.trade.entity.OutVO.*;
import cn.zjhf.kingold.trade.persistence.dao.ChannelCommisionDetailMapper;
import cn.zjhf.kingold.trade.persistence.dao.ChannelCommisionSummaryMapper;
import cn.zjhf.kingold.trade.service.IChannelCommisionService;
import cn.zjhf.kingold.trade.utils.*;
import cn.zjhf.kingold.trade.utils.Tuple.TwoTuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;

/**
 * Created by zhangyijie on 2017/10/12.
 */
@Service
public class ChannelCommisionServiceImpl extends ProductClearBase implements IChannelCommisionService {
    protected static final Logger logger = LoggerFactory.getLogger(ChannelCommisionServiceImpl.class);

    /**
     * 1未结算
     */
    public static final int DETAIL_STATUS_UNSETTLE = 1;

    /**
     * 2结算请求中
     */
    public static final int DETAIL_STATUS_SETTLEREQUEST = 2;

    /**
     * 3已结算
     */
    public static final int DETAIL_STATUS_SETTLED = 3;

    /**
     * 汇总数据 -1审核失败
     */
    public static final int SUMMARY_STATUS_AUDIT_FAIL = -1;

    /**
     * 汇总数据 1待审核
     */
    public static final int SUMMARY_STATUS_CREATE = 1;

    /**
     * 汇总数据 2已审核/已结算
     */
    public static final int SUMMARY_STATUS_SETTLED = 2;

    @Autowired
    ChannelCommisionDetailMapper channelCommisionDetailMapper;

    @Autowired
    ChannelCommisionSummaryMapper channelCommisionSummaryMapper;

    private double getChargeRateBase(String productUuid, String merchantNum) {
        WhereCondition where = new WhereCondition();
        where.setCondi("PCR.product_uuid", productUuid);
        where.setCondi("PCR.merchant_num", merchantNum);

        String sql = "SELECT PCR.channel_charge_rate, PRO.product_period, FIXED.rate_formula_param  " +
                "FROM kingold_product.product_channel_relational PCR, kingold_product.product PRO, kingold_product.product_fixed_income FIXED " +
                "WHERE PCR.product_uuid = PRO.product_uuid " +
                "AND PCR.product_uuid = FIXED.product_uuid " + where.toAnd().toString();
        List<Map> listMap = operationReportMapper.lstQueryData(new QueryUtils(sql));

        double chargeRateBase = 0.0;
        for(Map map : listMap) {
            BizParam bizParam = new BizParam(map);
            double chargeRate = bizParam.getDouble("channel_charge_rate");
            int productPeriod = bizParam.getInt("product_period");
            int formulaParam = bizParam.getInt("rate_formula_param");
            formulaParam = (formulaParam<=0)?365:formulaParam;

            chargeRateBase = (chargeRate*productPeriod)/formulaParam;
            chargeRateBase = (chargeRateBase<0)?0.0:chargeRateBase;
            break;
        }
        return chargeRateBase;
    }

    /**
     * 生成渠道佣金明细记录
     * @param productUuid
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int creatClearData(String productUuid) throws BusinessException {
        String sql = "SELECT merchant_num, channel_app_name FROM kingold_product.product_channel_relational WHERE product_uuid = " + WhereCondition.toSQLStr(productUuid);
        List<Map> listMap = operationReportMapper.lstQueryData(new QueryUtils(sql));

        logger.info("Step1 获取该产品关联的渠道方信息");
        List<TwoTuple<String, String>> channelInfoList = new ArrayList<TwoTuple<String, String>>();
        for(Map map : listMap) {
            BizParam bizParam = new BizParam(map);
            String merchantNum = bizParam.get("merchant_num");
            String channelAppName = bizParam.get("channel_app_name");
            channelInfoList.add(new TwoTuple<String, String>(merchantNum, channelAppName));

            channelCommisionDetailMapper.deleteByProductMerchant(productUuid, merchantNum);
        }

        Date now = new Date();
        int count = 0;
        for(TwoTuple<String, String> channelInfo : channelInfoList) {
            String merchantNum = channelInfo.first;

            logger.info("Step2 填充基础信息");
            ChannelCommisionDetail item = new ChannelCommisionDetail();
            item.setProductUuid(productUuid);
            item.setMerchantNum(merchantNum);
            item.setChannelAppName(channelInfo.second);
            item.setLoanTime(now);

            logger.info("Step3 填充产品汇总信息");
            sql = "SELECT product_abbr_name, COUNT(*) AS orderCount, SUM(order_amount) AS allOrderAmount " +
                  " FROM trade_order WHERE product_uuid = " + WhereCondition.toSQLStr(productUuid) +
                    " AND order_status NOT IN(1,9) AND delete_flag=0";
            listMap = operationReportMapper.lstQueryData(new QueryUtils(sql));
            for(Map map : listMap) {
                BizParam bizParam = new BizParam(map);

                item.setProductAbbrName(bizParam.get("product_abbr_name"));
                item.setOrderCount(bizParam.getInt("orderCount"));
                item.setRaiseAmount(bizParam.getBigDecimal("allOrderAmount"));
            }

            logger.info("Step4 填充有效成交信息");
            sql = "SELECT COUNT(*) AS orderCount, SUM(order_amount) AS allOrderAmount " +
                    " FROM trade_order WHERE product_uuid = " + WhereCondition.toSQLStr(productUuid) +
                    " AND belong_merchant_num = " + WhereCondition.toSQLStr(merchantNum) +
                    " AND order_status NOT IN(1,9) AND delete_flag=0";
            listMap = operationReportMapper.lstQueryData(new QueryUtils(sql));
            for(Map map : listMap) {
                BizParam bizParam = new BizParam(map);
                item.setValidOrderCount(bizParam.getInt("orderCount"));
                item.setValidRaiseAmount(bizParam.getBigDecimal("allOrderAmount"));
            }

            logger.info("Step5 填充有效成交不结算信息");
            sql = "SELECT COUNT(*) AS orderCount, SUM(order_amount) AS allOrderAmount " +
                    " FROM trade_order WHERE product_uuid = " + WhereCondition.toSQLStr(productUuid) +
                    " AND belong_merchant_num = " + WhereCondition.toSQLStr(merchantNum) +
                    " AND channel_commission_flag=0" +
                    " AND order_status NOT IN(1,9) AND delete_flag=0";
            listMap = operationReportMapper.lstQueryData(new QueryUtils(sql));
            for(Map map : listMap) {
                BizParam bizParam = new BizParam(map);
                item.setValidOrderUnsettleCount(bizParam.getInt("orderCount"));
                item.setValidRaiseUnsettleAmount(bizParam.getBigDecimal("allOrderAmount"));
            }

            logger.info("Step6 佣金和状态处理");
            double chargeRateBase = getChargeRateBase(productUuid, merchantNum);
            double commisionAmount = AmountUtils.exac(item.getValidRaiseAmount().subtract(item.getValidRaiseUnsettleAmount()).multiply(new BigDecimal(chargeRateBase)));
            item.setCommisionAmount(new BigDecimal(commisionAmount));
            item.setSettleStatus(DataUtils.intToByte(DETAIL_STATUS_UNSETTLE));
            item.setCreateTime(now);
            item.setUpdateTime(now);
            item.setDeleteFlag(DataUtils.intToByte(0));

            count += channelCommisionDetailMapper.insert(item);
        }
        return count;
    }

    /**
     * 查询渠道佣金明细记录
     * @param lstCondition
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public CommItemListVO<ChannelCommisionDetailVO> lstDetail(LstChannelCommisionDetailConditionVO lstCondition) throws BusinessException {
        CommItemListVO<ChannelCommisionDetailVO> itemList = new CommItemListVO<ChannelCommisionDetailVO>();
        WhereCondition where = new WhereCondition();
        where.setLike("product_abbr_name", lstCondition.getProductAbbrName());
        where.setLike("channel_app_name", lstCondition.getChannelAppName());

        where.setCondi("settle_status", lstCondition.getSettleStatus(), true);
        where.setBetween("loan_time", lstCondition.getBeginLoanDate(), lstCondition.getEndLoanDate());
        where.setPage(lstCondition.getBeginSN(), lstCondition.getEndSN(), "loan_time");

        String sql = "SELECT * FROM channel_commision_detail " + where.toString();
        itemList.setCount(lstQueryDataCount(sql));

        List<ChannelCommisionDetail> items = channelCommisionDetailMapper.lstItemDatas(new QueryUtils(sql));
        if(items != null) {
            for(ChannelCommisionDetail item : items) {
                itemList.addItem(new ChannelCommisionDetailVO(item));
            }
        }

        return itemList;
    }

    /**
     * 查询渠道 交易佣金记录， 使用产品ID和渠道商户号
     * @param lstCondition
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public CommItemListVO<ChannelTradeCommisionItemVO> lstTradeCommisionsByMerchantNum(LstTradeCommisionsByMerchantNumConditionVO lstCondition) throws BusinessException {
        CommItemListVO<ChannelTradeCommisionItemVO> itemList = new CommItemListVO<ChannelTradeCommisionItemVO>();
        double chargeRateBase = getChargeRateBase(lstCondition.getProductUuid(), lstCondition.getMerchantNum());

        String sql = "SELECT DISTINCT trans.trade_order_bill_code_extend, trade.user_phone, trade.user_name, trade.product_abbr_name, " +
                "trade.payed_time, trade.order_amount " +
                " FROM trade_order trade, account_transaction trans " +
                " WHERE trade.order_bill_code = trans.trade_order_bill_code " +
                " AND trade.order_status NOT IN(1,9) " +
                " AND trans.account_type = 21 " +
                " AND trade.channel_commission_flag = 1 AND trade.belong_merchant_num = " + WhereCondition.toSQLStr(lstCondition.getMerchantNum()) +
                " AND trade.product_uuid = " + WhereCondition.toSQLStr(lstCondition.getProductUuid()) +
                WhereCondition.getPageCondi(lstCondition.getBeginSN(), lstCondition.getEndSN(), "trade.payed_time").toString();

        itemList.setCount(lstQueryDataCount(sql));

        List<Map> listMap = operationReportMapper.lstQueryData(new QueryUtils(sql));
        for(Map map : listMap) {
            BizParam bizParam = new BizParam(map);
            ChannelTradeCommisionItemVO item = new ChannelTradeCommisionItemVO();

            item.setOrderBillCode(bizParam.get("trade_order_bill_code_extend"));
            item.setUserPhone(bizParam.get("user_phone"));
            item.setUserName(bizParam.get("user_name"));
            item.setProductAbbrName(bizParam.get("product_abbr_name"));

            item.setPayedTime(bizParam.getDate("payed_time"));
            item.setOrderAmount(bizParam.getDouble("order_amount"));

            item.setCommisionAmount(AmountUtils.exac(item.getOrderAmount() * chargeRateBase));
            itemList.addItem(item);
        }

        return itemList;
    }

    private int updateDetailStatus(int newStatus, String requestCycle, String merchantNum) {
        requestCycle = requestCycle.replace(".", "-");
        String beginTime = requestCycle + "-01 00:00:00";
        String endTime = requestCycle + "-31 23:59:59";

        String between = " loan_time>=" + WhereCondition.toSQLStr(beginTime) + " AND loan_time<=" + WhereCondition.toSQLStr(endTime);

        WhereCondition where = new WhereCondition();
        where.setCondi(between);
        //where.setBetween("loan_time", beginTime, endTime);
        where.setCondi("merchant_num", merchantNum, true);
        where.noDelete();

        String sql = "UPDATE channel_commision_detail SET settle_status = " + newStatus + where.toString();
        return channelCommisionDetailMapper.updateDetail(new QueryUtils(sql));
    }

    private List<ChannelCommisionDetail> lstDetailByRequestCycle(String requestCycle, int settleStatus, String merchantNum) throws BusinessException {
        List<ChannelCommisionDetail> detailList = new ArrayList<ChannelCommisionDetail>();
        requestCycle = requestCycle.replace(".", "-");
        //Date beginTime = DateUtil.strToDate(requestCycle + "-01");
        //Date endTime = DateUtil.strToDate(requestCycle + "-31");
        //endTime = StringOrDate.dateOffsetDay(endTime, 1);

        String beginTime = requestCycle + "-01 00:00:00";
        String endTime = requestCycle + "-31 23:59:59";

        String between = " loan_time>=" + WhereCondition.toSQLStr(beginTime) + " AND loan_time<=" + WhereCondition.toSQLStr(endTime);

        WhereCondition where = new WhereCondition();
        where.setCondi(between);
        //where.setBetween("loan_time", beginTime, endTime);
        where.setCondi("settle_status", settleStatus, true);
        where.setCondi("merchant_num", merchantNum);
        where.noDelete();

        String sql = "SELECT * FROM channel_commision_detail " + where.toString();
        detailList = channelCommisionDetailMapper.lstItemDatas(new QueryUtils(sql));
        return detailList;
    }

    /**
     * 批量请求结算
     * @param requestCycle 请求周期，格式: YYYY.MM
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public ChannelCommisionRequestResultVO request(String requestCycle) throws BusinessException {
        ChannelCommisionRequestResultVO requestResult = new ChannelCommisionRequestResultVO();
        requestResult.setRequestCycle(requestCycle);

        List<ChannelCommisionDetail> detailList = lstDetailByRequestCycle(requestCycle, DETAIL_STATUS_UNSETTLE, null);

        Date now = new Date();
        double totalCommisionAmount = 0.0;
        Map<String, ChannelCommisionSummary> channelCommisionSummaryMap = new HashMap<String, ChannelCommisionSummary>();
        for(ChannelCommisionDetail detailItem : detailList) {
            totalCommisionAmount += detailItem.getCommisionAmount().doubleValue();

            String merchantNum = detailItem.getMerchantNum();
            if(!channelCommisionSummaryMap.containsKey(merchantNum)) {
                ChannelCommisionSummary channelCommisionSummary = new ChannelCommisionSummary();

                channelCommisionSummary.setChannelCommisionSummaryId(generateBatchNoEx("CCS"));
                channelCommisionSummary.setCommisionAmount(new BigDecimal(0.0));
                channelCommisionSummary.setRequestCycle(requestCycle);
                channelCommisionSummary.setMerchantNum(merchantNum);
                channelCommisionSummary.setChannelAppName(detailItem.getChannelAppName());

                channelCommisionSummary.setSettleStatus(DataUtils.intToByte(SUMMARY_STATUS_CREATE));
                channelCommisionSummary.setCreateTime(now);
                channelCommisionSummary.setUpdateTime(now);
                channelCommisionSummary.setDeleteFlag(DataUtils.intToByte(0));

                channelCommisionSummaryMap.put(merchantNum, channelCommisionSummary);
            }

            //累加佣金
            ChannelCommisionSummary curChannelCommisionSummary = channelCommisionSummaryMap.get(merchantNum);
            curChannelCommisionSummary.setCommisionAmount(curChannelCommisionSummary.getCommisionAmount().add(detailItem.getCommisionAmount()));
        }

        //更新状态为 结算请求中
        updateDetailStatus(DETAIL_STATUS_SETTLEREQUEST, requestCycle, null);
        totalCommisionAmount = AmountUtils.exac(totalCommisionAmount);

        logger.info("request 开始检查");
        List<String> requestIdList = channelCommisionSummaryMapper.lstAuditFailRequestID(requestCycle);
        logger.info(DataUtils.toString(requestIdList));
        if((requestIdList!=null) && (requestIdList.size()>0)) {
            throw new BusinessException(TradeStatusMsg.CHANNEL_COMMISION_REQUEST_REPEAT, TradeStatusMsg.CHANNEL_COMMISION_REQUEST_REPEAT_MSG, false);
        }

        logger.info("request 插入数据");
        for(ChannelCommisionSummary channelCommisionSummary : channelCommisionSummaryMap.values()) {
            if(DataUtils.isEmpty(channelCommisionSummaryMapper.lstRequestID(channelCommisionSummary.getRequestCycle(), channelCommisionSummary.getMerchantNum()))) {
                channelCommisionSummaryMapper.insert(channelCommisionSummary);
            }
        }
        logger.info("request 插入数据 End");

        requestResult.setCommisionAmount(totalCommisionAmount);
        return requestResult;
    }

    /**
     * 获取批量请求条数/佣金总和
     * @param requestCycle 请求周期，格式: YYYY.MM
     * @return
     * @throws BusinessException
     */
    @Override
    public ChannelCommisionRequestResultVO getBatchCountAndCommission(String requestCycle) throws BusinessException {
        ChannelCommisionRequestResultVO requestResult = new ChannelCommisionRequestResultVO();
        requestResult.setRequestCycle(requestCycle);
        List<ChannelCommisionDetail> detailList = lstDetailByRequestCycle(requestCycle, DETAIL_STATUS_UNSETTLE, null);
        Date now = new Date();
        double totalCommisionAmount = 0.0;
        Map<String, ChannelCommisionSummary> channelCommisionSummaryMap = new HashMap<String, ChannelCommisionSummary>();
        for(ChannelCommisionDetail detailItem : detailList) {
            totalCommisionAmount += detailItem.getCommisionAmount().doubleValue();
        }
        totalCommisionAmount = AmountUtils.exac(totalCommisionAmount);
        requestResult.setCommisionAmount(totalCommisionAmount);
        return requestResult;
    }

    /**
     * 查询渠道佣金汇总记录
     * @param lstCondition
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public CommItemListVO<ChannelCommisionSummaryVO> lstSummary(LstChannelCommisionSummaryConditionVO lstCondition) throws BusinessException {
        CommItemListVO<ChannelCommisionSummaryVO> itemList = new CommItemListVO<ChannelCommisionSummaryVO>();
        WhereCondition where = new WhereCondition();
        where.setLike("channel_app_name", lstCondition.getChannelAppName());
        where.setCondi("request_cycle", lstCondition.getRequestCycle());
        if(lstCondition.getSettleStatus() < 0){
            where.setCondi("settle_status", lstCondition.getSettleStatus());
        }else{
            where.setCondi("settle_status", lstCondition.getSettleStatus(),true);
        }
        where.setBetween("create_time", lstCondition.getBeginCreateDate(), lstCondition.getEndCreateDate());
        where.setBetween("settle_time", lstCondition.getBeginSettleDate(), lstCondition.getEndSettleDate());
        where.setPage(lstCondition.getBeginSN(), lstCondition.getEndSN(), "create_time");

        String sql = "SELECT * FROM channel_commision_summary " + where.toString();
        itemList.setCount(lstQueryDataCount(sql));

        List<ChannelCommisionSummary> items = channelCommisionSummaryMapper.lstItemDatas(new QueryUtils(sql));
        if(items != null) {
            for(ChannelCommisionSummary item : items) {
                itemList.addItem(new ChannelCommisionSummaryVO(item));
            }
        }

        return itemList;
    }

    /**
     * 查询渠道 交易佣金记录， 使用 请求结算单号
     * @param lstCondition
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public CommItemListVO<ChannelTradeCommisionItemVO> lstTradeCommisionsByRequestId(LstTradeCommisionsByRequestIdConditionVO lstCondition) throws BusinessException {
        CommItemListVO<ChannelTradeCommisionItemVO> itemList = new CommItemListVO<ChannelTradeCommisionItemVO>();
        ChannelCommisionSummary channelCommisionSummary = channelCommisionSummaryMapper.selectByPrimaryKey(lstCondition.getRequestId());
        if(channelCommisionSummary != null) {
            String requestCycle = channelCommisionSummary.getRequestCycle();
            String merchantNum = channelCommisionSummary.getMerchantNum();

            List<ChannelCommisionDetail> channelCommisionDetailList = lstDetailByRequestCycle(requestCycle, 0, merchantNum);
            List<String> productUuidList = new ArrayList<>();
            if (channelCommisionDetailList != null) {
                for (ChannelCommisionDetail channelCommisionDetail : channelCommisionDetailList) {
                    productUuidList.add(channelCommisionDetail.getProductUuid());
                }
            }

            if (productUuidList.size() > 0) {
                WhereCondition where = new WhereCondition();
                where.setInString("trade.product_uuid", productUuidList);
                where.setPage(lstCondition.getBeginSN(), lstCondition.getEndSN(), "trade.payed_time");

                String sql = "SELECT DISTINCT trans.trade_order_bill_code_extend, trade.product_uuid, trade.user_phone, trade.user_name, trade.product_abbr_name, " +
                        "trade.payed_time, trade.order_amount " +
                        " FROM trade_order trade, account_transaction trans " +
                        " WHERE trade.order_bill_code = trans.trade_order_bill_code " +
                        " AND trade.order_status NOT IN(1,9) " +
                        " AND trans.account_type = 21 " +
                        " AND trade.channel_commission_flag =1" +
                        " AND trade.belong_merchant_num = " +
                        WhereCondition.toSQLStr(merchantNum) + where.toAnd().toString();

                itemList.setCount(lstQueryDataCount(sql));

                //Key:ProductUuid, Vaule:ChargeRateBase
                Map<String, Double> chargeRateBaseMap = new HashMap<String, Double>();

                List<Map> listMap = operationReportMapper.lstQueryData(new QueryUtils(sql));
                for (Map map : listMap) {
                    BizParam bizParam = new BizParam(map);
                    ChannelTradeCommisionItemVO item = new ChannelTradeCommisionItemVO();

                    item.setOrderBillCode(bizParam.get("trade_order_bill_code_extend"));
                    item.setUserPhone(bizParam.get("user_phone"));
                    item.setUserName(bizParam.get("user_name"));
                    item.setProductAbbrName(bizParam.get("product_abbr_name"));

                    item.setPayedTime(bizParam.getDate("payed_time"));
                    item.setOrderAmount(bizParam.getDouble("order_amount"));

                    String productUuid = bizParam.get("product_uuid");

                    double chargeRateBase = 0.0;
                    if (!chargeRateBaseMap.containsKey(productUuid)) {
                        chargeRateBaseMap.put(productUuid, getChargeRateBase(productUuid, merchantNum));
                    }
                    chargeRateBase = chargeRateBaseMap.get(productUuid);

                    item.setCommisionAmount(AmountUtils.exac(item.getOrderAmount() * chargeRateBase));
                    itemList.addItem(item);
                }
            }
        }

        return itemList;
    }

    /**
     * 根据 佣金请求结算ID列表 查询总佣金记录数/总佣金
     * @param requestIds
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public ChannelCommisionCountVO lstChannelCommisionCount(String requestIds) throws BusinessException {
        ChannelCommisionCountVO vo=new ChannelCommisionCountVO();
        int count = 0;
        double totalCommisionAmount = 0.0;
        List<String> requestIdList =DataUtils.split(requestIds,",");
        if(requestIdList != null && requestIdList.size() > 0) {
            for (String requestId : requestIdList) {
                ChannelCommisionSummary channelCommisionSummary = channelCommisionSummaryMapper.selectByPrimaryKey(requestId);
                if (channelCommisionSummary != null) {
                    String requestCycle = channelCommisionSummary.getRequestCycle();
                    String merchantNum = channelCommisionSummary.getMerchantNum();

                    List<ChannelCommisionDetail> channelCommisionDetailList = lstDetailByRequestCycle(requestCycle, 0, merchantNum);
                    if (channelCommisionDetailList != null) {
                        for (ChannelCommisionDetail channelCommisionDetail : channelCommisionDetailList) {
                            ++count;
                            totalCommisionAmount += channelCommisionDetail.getCommisionAmount().doubleValue();
                        }
                    }
                }
            }
        }
        totalCommisionAmount = AmountUtils.exac(totalCommisionAmount);
        vo.setCount(count);
        vo.setCommisionAmount(totalCommisionAmount);
        return vo;
    }

    /**
     * 结算渠道佣金
     * @param channelCommisionSettle
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int channelCommisionSettle(ChannelCommisionSettleVO channelCommisionSettle) throws BusinessException {
        int count = 0;
        boolean isPass = channelCommisionSettle.getIsAudited() > 0;
        Date now = new Date();
        if((channelCommisionSettle!=null) && (channelCommisionSettle.getRequestIdList()!=null)) {
            List<String> requestIdList = channelCommisionSettle.getRequestIdList();

            WhereCondition where = new WhereCondition();
            where.setInString("channel_commision_summary_id", requestIdList);
            where.setInInt("settle_status", SUMMARY_STATUS_AUDIT_FAIL, SUMMARY_STATUS_CREATE);
            where.noDelete();

            if(isPass) {
                String sql = "UPDATE channel_commision_summary SET settle_status = " + SUMMARY_STATUS_SETTLED +
                        ", settle_time = NOW(), audit_opinion = '通过', update_time = NOW(), " +
                        " settle_operator = " + WhereCondition.toSQLStr(channelCommisionSettle.getAuditor());
                sql += where.toString();

                count += channelCommisionSummaryMapper.updateSummary(new QueryUtils(sql));

                where.clear();
                where.setInString("channel_commision_summary_id", requestIdList);
                where.noDelete();
                sql = "SELECT * FROM channel_commision_summary " + where.toString();
                List<ChannelCommisionSummary> channelCommisionSummaryList = channelCommisionSummaryMapper.lstItemDatas(new QueryUtils(sql));
                for(ChannelCommisionSummary channelCommisionSummary : channelCommisionSummaryList) {
                    if (channelCommisionSummary != null) {
                        String requestCycle = channelCommisionSummary.getRequestCycle();
                        String merchantNum = channelCommisionSummary.getMerchantNum();

                        List<ChannelCommisionDetail> channelCommisionDetailList = lstDetailByRequestCycle(requestCycle, 0, merchantNum);
                        if (channelCommisionDetailList != null) {
                            for (ChannelCommisionDetail channelCommisionDetail : channelCommisionDetailList) {
                                channelCommisionDetail.setSettleStatus(DataUtils.intToByte(DETAIL_STATUS_SETTLED));
                                channelCommisionDetail.setUpdateTime(now);

                                channelCommisionDetailMapper.updateByPrimaryKey(channelCommisionDetail);
                            }
                        }
                    }
                }
            }else {
                String sql = "UPDATE channel_commision_summary SET settle_status = " + SUMMARY_STATUS_AUDIT_FAIL +
                        ", audit_opinion = " + WhereCondition.toSQLStr(channelCommisionSettle.getMessage()) +
                        ", update_time = NOW(), settle_operator = " + WhereCondition.toSQLStr(channelCommisionSettle.getAuditor());
                sql += where.toString();

                count += channelCommisionSummaryMapper.updateSummary(new QueryUtils(sql));
            }
        }
        return count;
    }
}
