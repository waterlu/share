package cn.zjhf.kingold.trade.service;


import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.entity.FeeTypeResult;
import cn.zjhf.kingold.trade.entity.TradeRecharge;
import cn.zjhf.kingold.trade.utils.Tuple.ThreeTuple;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 交易接口
 * <p>
 * Created by lutiehua on 2017/4/28.
 */
public interface ITradeService {



    /**
     * 创建充值订单
     *
     * @param userUUID        用户UUID
     * @param userPhone       用户手机号码
     * @param accountUUID     账户UUID
     * @param agencyAccountNo 代理机构对应账户
     * @param amount          充值金额
     * @param tradeOrderBillCodeExtend          宝付交易流水编号
     * @param transactionChannel
     * @param belongMerchantNum  所属商户号
     * @return 充值单编号
     */
    String createRechargeOrder(String userUUID, String userPhone, String accountUUID, String agencyAccountNo,
                               double amount, String tradeOrderBillCodeExtend, String transactionChannel, String accountType,
                               String belongMerchantNum, Integer payMethod) throws BusinessException;

    /**
     * 创建取现订单
     * 这里只能获取投资用户 信息。
     *
     * @param accountUuid accountUuid
     * @param amount      取现金额
     * @param feeType     手续费支付方      PayMsg.FEE_TOKEN_ON_PLATFORM  PayMsg.FEE_TOKEN_ON_PERSON
     * @param tradeOrderBillCodeExtend      宝付交易流水编号
     * @param transactionChannel
     * @param belongMerchantNum  商户号
     * @return 充值单编号
     */
    TradeRecharge createWithdrawOrder(String accountUuid, double amount, byte feeType, String tradeOrderBillCodeExtend,
                                      String transactionChannel, String accountType, String belongMerchantNum) throws BusinessException;

    /**
     * 修正交易信息
     *
     * @param product_uuid
     * @return
     * @throws Exception
     */
    void fixTradeOrder(String product_uuid) throws BusinessException;

    /**
     *
     * @param productUuid
     * @throws BusinessException
     */
    void advanceProductEndFix(String productUuid) throws BusinessException;


    /**
     * 查询充值记录
     * @param billCode
     * @return
     * @throws Exception
     */
    TradeRecharge queryRechargeOrderByBillCode(String billCode) throws BusinessException;

    /**
     * 创建充值提现凭证
     *
     * @param billCode   充值单编号
     * @param amount     充值金额
     * @param feeTakenOn 手续费付费方式：1 平台，2 个人
     * @param feeAmount 手续费金额
     *@param time       充值时间
     * @param result     充值返回值
     * @param transactionChannel    @return
     */
    String executeRechargeOrder(String billCode, double amount, int feeTakenOn, double feeAmount, Date time, String result, String transactionChannel) throws BusinessException;

    /**
     * 设置充值，并跟新订单状态
     *
     * @param billCode 充值单编号
     * @return
     * @throws BusinessException
     */
    int updateRechargeOrder(String billCode, String request, Integer orderStatus) throws BusinessException;

    /**
     * 检查该投资者是否可以购买此新手标
     * @param userUuid
     * @return
     * @throws BusinessException
     */
    boolean checkNoviceProduct(String userUuid) throws BusinessException;

    /**
     * 获取交易单
     * @param orderUuid
     * @return
     * @throws BusinessException
     */
    Map getTradeOrder(String orderUuid) throws BusinessException;

    /**
     * 投资
     *
     * @param map
     * @return
     * @throws BusinessException
     */
    ResponseResult invest(Map map) throws BusinessException;

    BigDecimal getTotalInvestAmount(Map map) throws BusinessException;

    TradeRecharge createRechargeOrder(Map params) throws BusinessException;

    ResponseResult baofooWithDraw(TradeRecharge tradeRecharge);

    /**
     * 获取手续费支付方 和 支付金额
     * @param params 参数必填：userUuid,amount,accountType
     * @return
     */
    FeeTypeResult getFeeType(Map params);

    FeeTypeResult getFeeType(String userUuid);


    /**
     * 执行凭证（提现）（幂等）
     *
     * @param billCode 取现单号
     * @return
     * @throws BusinessException
     */
    void executeBill(String billCode) throws BusinessException;


    /**
     * 取消执行凭证（提现）（幂等）
     *
     * @param billCode 取现单号
     * @return
     * @throws BusinessException
     */
    void cancelExecuteBill(String billCode, String remark) throws BusinessException;

    /**
     * 固收产品认购
     *
     * @param map
     * @return
     * @throws BusinessException
     */
    void productSubscription(Map map) throws BusinessException;

    /**
     * 修改订单所属机构和专职理财师信息
     *
     * @param orderBillCode
     * @param serviceUserUuid
     * @param serviceUserOrgPath
     * @throws BusinessException
     */
    void updateServiceUserInfo(String orderBillCode, String serviceUserUuid, String serviceUserOrgPath) throws BusinessException;

    /**
     * 将电子合同的订单信息更新进trade表
     * @throws BusinessException
     */
    int updateContractFileInfo(List<ThreeTuple<String, String, String>> contractFileInfoList) throws BusinessException;

    /**
     * 给指定产品生成电子合同, 返回需要更新trade表的信息
     * @param productUuid
     * @throws BusinessException
     */
    List<ThreeTuple<String, String, String>> contractFill(String productUuid) throws BusinessException;

    /**
     * 给指定产品生成电子合同
     * @param productUuid
     * @throws BusinessException
     */
    void contractFillEx(String productUuid) throws BusinessException;

    /**
     * 获取阿里private 文件访问路径
     * @param fileName
     * @return
     * @throws BusinessException
     */
    String getAccessFileUrl(String fileName) throws BusinessException;

    ResponseResult recoverWithdraw(String orderBillCode) throws BusinessException;

    ResponseResult recoverWithdrawTimer() throws BusinessException;
}