package cn.zjhf.kingold.trade.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.entity.TradeOrder;
import cn.zjhf.kingold.trade.entity.TradePrivateFundOrder;
import cn.zjhf.kingold.trade.message.AwardMessage;

import java.math.BigDecimal;

/**
 * 业绩服务
 *
 * Created by lutiehua on 2017/6/15.
 */
public interface IAchievementService {

    /**
     * 生成定期业绩
     *
     * @param tradeOrder
     * @return
     * @throws BusinessException
     */
    boolean generateFTAchievement(TradeOrder tradeOrder) throws BusinessException;

    /**
     * 生成私募业绩
     *
     * @param tradeOrder
     * @return
     * @throws BusinessException
     */
    boolean generatePFAchievement(TradePrivateFundOrder tradeOrder) throws BusinessException;

    /**
     * 查询业绩
     *
     * @param userUUid
     * @return
     * @throws BusinessException
     */
    BigDecimal queryAchievement(String userUUid) throws BusinessException;

    /**
     * 更新用户的认证状态
     *
     * @param userUuid
     * @return
     * @throws BusinessException
     */
    boolean updateUserAuthStatus(String userUuid) throws BusinessException;

}
