package cn.zjhf.kingold.trade.constant;

/**
 * Created by lutiehua on 2017/6/2.
 */
public interface BizConstant {

    /**
     * 金额默认保留4位小数
     */
    int CASH_FRACTION_COUNT = 2;

}
