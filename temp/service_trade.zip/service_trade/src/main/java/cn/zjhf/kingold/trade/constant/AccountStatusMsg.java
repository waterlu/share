package cn.zjhf.kingold.trade.constant;

/**
 * Created by likenice on 17/3/20.
 */

public class AccountStatusMsg {
    public static final String REQUEST_PROPERTIES_IS_NOT_EXIST = "param:properties is not exist!";

    public static final int REQUEST_REMOTE_ERROR_CODE = -100;
    public static final String REQUEST_REMOTE_ERROR = "远程调用失败";

    public static final int REQUEST_PARAM_ERROR_CODE = -1;
    public static final String REQUEST_PARAM_ERROR = "入参参数错误";
    public static final String REQUEST_PINGTAITUOGUAN_FAIL = "获取平台托管账户失败";

    public static final int SUCCESS_CODE = 200;
    public static final String SUCCESS = "发送成功";


    public static final int INNER_ERROR_CODE = 500;
    public static final String INNER_ERROR = "系统异常";



    public static final int USER_HAS_EXIST_CODE = 1113;
    public static final String USER_HAS_EXIST = "用户已经存在";


    public static final int ACCOUNT_NOT_EXIST_CODE = 7001;
    public static final String ACCOUNT_NOT_EXIST = "账户不存在";

    public static final int BANK_CARD_HAS_EXIST_CODE = 7002;
    public static final String BANK_CARD_HAS_EXIST = "账户下已经存在此银行卡";

    public static final int ACCOUNT_HAS_EXIST_CODE = 7003;
    public static final String ACCOUNT_HAS_EXIST = "账户已经存在";

    public static final int ACCOUNT_MONEY_NOT_ENOUGH_CODE = 7004;
    public static final String ACCOUNT_MONEY_NOT_ENOUGH = "账户余额不足";

    public static final int TRANSACTION_AMOUNT_MUST_LESS_ZERO_CODE = 7010;
    public static final String TRANSACTION_AMOUNT_MUST_LESS_ZERO = "输入的金额必须小于0";


    public static final int TRANSACTION_AMOUNT_MUST_GREATER_ZERO_CODE = 7011;
    public static final String TRANSACTION_AMOUNT_MUST_GREATER_ZERO = "输入的金额必须大于0";


    public static final int ORDER_BILL_CODE_EXTEND_IS_NULL_CODE = 7998;
    public static final String ORDER_BILL_CODE_EXTEND_IS_NULL = "订单编号扩展不允许为空";

    public static final int PAY_SYSTEM_ERROR_CODE = 7999;
    public static final String PAY_SYSTEM_ERROR = "支付接口异常";

}

