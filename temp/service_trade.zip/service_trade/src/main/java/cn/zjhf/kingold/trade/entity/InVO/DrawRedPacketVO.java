package cn.zjhf.kingold.trade.entity.InVO;

import io.swagger.annotations.ApiModelProperty;

/**
 * Created by zhangyijie on 2018/1/26.
 */
public class DrawRedPacketVO extends InVOBase {

    @ApiModelProperty(required = true, value = "用户UserUUID, 注意：app查询专用")
    private String userUuid;

    @ApiModelProperty(required = true, value = "红包Id, 多个以$$符号间隔， 注意：运营后台批量领取专用")
    private String redPacketIds;

    @ApiModelProperty(required = true, value = "红包Id")
    private Long redPacketId;

    @ApiModelProperty(required = true, value = "操作人")
    private String operator;

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public Long getRedPacketId() {
        return redPacketId;
    }

    public void setRedPacketId(Long redPacketId) {
        this.redPacketId = redPacketId;
    }

    public String getRedPacketIds() {
        return redPacketIds;
    }

    public void setRedPacketIds(String redPacketIds) {
        this.redPacketIds = redPacketIds;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    @Override
    public String toString() {
        return "DrawRedPacketVO{" +
                "userUuid='" + userUuid + '\'' +
                ", redPacketIds='" + redPacketIds + '\'' +
                ", redPacketId=" + redPacketId +
                ", operator='" + operator + '\'' +
                '}';
    }
}
