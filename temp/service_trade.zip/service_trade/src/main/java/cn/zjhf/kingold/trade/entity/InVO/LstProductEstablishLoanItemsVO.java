package cn.zjhf.kingold.trade.entity.InVO;

import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import java.util.Date;

/**
 * Created by DELL on 2017/5/18.
 */
@ApiModel(value = "LstProductEstablishLoanItemsVO", description = "产品成立_放款明细(维度:产品-交易，列表) 查询入参")
public class LstProductEstablishLoanItemsVO extends InVOBase {
    @ApiModelProperty(required = true, value = "traceID")
    @NotEmpty
    private String traceID;

    @ApiModelProperty(required = true, value = "产品UUId")
    @NotEmpty
    private String productUuid;

    @ApiModelProperty(required = true, value = "用户名")
    private String userPhone;

    @ApiModelProperty(required = true, value = "订单号")
    private String orderNo;

    @ApiModelProperty(required = true, value = "状态：-1审核失败；1待审核；2审核通过；3已兑付；0全部")
    private int status;

    @ApiModelProperty(required = true, value = "申请时间_起始")
    private Date beginDate;

    @ApiModelProperty(required = true, value = "申请时间_结束")
    private Date endDate;

    @ApiModelProperty(required = true, value = "起始序号")
    private int beginSN;

    @ApiModelProperty(required = true, value = "结束序号")
    private int endSN;

    @ApiModelProperty(required = true, value = "排序字段，暂不使用")
    private String orderByFields;

    @Override
    public String getTraceID() {
        return traceID;
    }

    @Override
    public void setTraceID(String traceID) {
        this.traceID = traceID;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public Date getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(Date beginDate) {
        this.beginDate = beginDate;
    }

    public Date getEndDate() {
        return convertEndDate(endDate);
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public int getBeginSN() {
        return beginSN;
    }

    public void setBeginSN(int beginSN) {
        this.beginSN = beginSN;
    }

    public int getEndSN() {
        return endSN;
    }

    public void setEndSN(int endSN) {
        this.endSN = endSN;
    }

    public String getOrderByFields() {
        return orderByFields;
    }

    public void setOrderByFields(String orderByFields) {
        this.orderByFields = orderByFields;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(traceID) + ", ");
        sb.append("productUuid:" + DataUtils.toString(productUuid) + ", ");
        sb.append("userPhone:" + DataUtils.toString(userPhone) + ", ");
        sb.append("orderNo:" + DataUtils.toString(orderNo) + ", ");
        sb.append("status:" + DataUtils.toString(status) + ", ");
        sb.append("beginDate:" + DataUtils.toString(beginDate) + ", ");
        sb.append("endDate:" + DataUtils.toString(endDate) + ", ");
        sb.append("beginSN:" + DataUtils.toString(beginSN) + ", ");
        sb.append("endSN:" + DataUtils.toString(endSN) + ", ");
        sb.append("orderByFields:" + DataUtils.toString(orderByFields));
        return sb.toString();
    }
}
