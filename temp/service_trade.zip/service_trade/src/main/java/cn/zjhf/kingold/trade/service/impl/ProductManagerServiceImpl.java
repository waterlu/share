package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.constant.*;
import cn.zjhf.kingold.trade.entity.*;
import cn.zjhf.kingold.trade.entity.OutVO.ProductProfitVO;
import cn.zjhf.kingold.trade.entity.OutVO.ProductRaiseProgressVO;
import cn.zjhf.kingold.trade.entity.OutVO.TradeInvestSummaryExVO;
import cn.zjhf.kingold.trade.persistence.dao.AccountTransactionMapper;
import cn.zjhf.kingold.trade.persistence.dao.ExchangeManagerfeeConfigMapper;
import cn.zjhf.kingold.trade.persistence.dao.PlatformCommissionConfigMapper;
import cn.zjhf.kingold.trade.persistence.dao.TradePrivateFundOrderMapper;
import cn.zjhf.kingold.trade.service.IProductEndService;
import cn.zjhf.kingold.trade.service.IProductEstablishService;
import cn.zjhf.kingold.trade.service.IProductManagerService;
import cn.zjhf.kingold.trade.service.ITradeService;
import cn.zjhf.kingold.trade.utils.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;

/**
 * Created by zhangyijie on 2017/5/19.
 */
@Service
public class ProductManagerServiceImpl extends ProductClearBase implements IProductManagerService {
    protected static final Logger logger = LoggerFactory.getLogger(ProductManagerServiceImpl.class);

    @Autowired
    IProductEstablishService productEstablishService;

    @Autowired
    IProductEndService productEndService;

    @Autowired
    ITradeService tradeService;

    @Autowired
    AccountTransactionMapper accountTransactionMapper;

    @Autowired
    TradePrivateFundOrderMapper tradePrivateFundOrderMapper;

    @Autowired
    ExchangeManagerfeeConfigMapper exchangeManagerfeeConfigMapper;

    @Autowired
    PlatformCommissionConfigMapper platformCommissionConfigMapper;

    private void checkStatus(int status, int targetStatus) throws BusinessException {
        if (status != targetStatus) {
            throw new BusinessException(TradeStatusMsg.WORKFLOW_STATUS_ERR, TradeStatusMsg.WORKFLOW_STATUS_ERR_MSG, false);
        }
    }

    /**
     * 查询募集金额
     *
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public ProductRaiseProgressVO lstRaiseAmount(String product_uuid, String productType) throws BusinessException {
        double productScale = 0;
        double productAccumulation = 0;
        double productManual = 0;

        if(productType.equals(ProductType.PRODUCT_FT)) {
            ProductFixedIncome productInfo = getFixedIncomeProductById(product_uuid);
            productScale = productInfo.getProductScale().doubleValue();
            productAccumulation = productInfo.getProductAccumulation().doubleValue();
            productManual = productInfo.getProductManual().doubleValue();
        }else {
            ProductPrivateFund productInfo = getPrivateProductById(product_uuid);
            productScale = productInfo.getProductScale().doubleValue();
            productAccumulation = productInfo.getProductAccumulation().doubleValue();
            productManual = productInfo.getProductManual().doubleValue();
        }

        ProductRaiseProgressVO productRaiseProgress = new ProductRaiseProgressVO();
        productRaiseProgress.setProductUuid(product_uuid);
        productRaiseProgress.setProductScale(productScale);
        productRaiseProgress.setProductAccumulation(productAccumulation);
        productRaiseProgress.setProductManual(productManual);
        // 可输入调整金额范围下限 = 已调整金额 * -1
        productRaiseProgress.setMinProductManual(0 - productManual);
        //可输入调整金额范围上限 = 产品规模 - 已募集金额（实）- 已调整金额
        productRaiseProgress.setMaxProductManual(productRaiseProgress.getProductScale() - productRaiseProgress.getProductManual() - productRaiseProgress.getProductAccumulation());

        double progressRate = 0;
        if (productScale > 0) {
            progressRate = (productAccumulation + productManual) / (productScale);
            progressRate = progressRate <= 1.0 ? progressRate : 1.0;
        }

        productRaiseProgress.setProductProgressRate(progressRate);
        return productRaiseProgress;
    }

    /**
     * 更新募集金额
     * @param createBy 操作人
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updateRaiseAmount(String product_uuid, String productType, String userPhone, Double amount, String createBy) throws BusinessException {
        double productScale = 0;
        double productAccumulation = 0;
        double productManual = 0;

        if(productType.equals(ProductType.PRODUCT_FT)) {
            ProductFixedIncome productInfo = getFixedIncomeProductById(product_uuid);
            productScale = productInfo.getProductScale().doubleValue();
            productAccumulation = productInfo.getProductAccumulation().doubleValue();
            productManual = productInfo.getProductManual().doubleValue();
        }else {
            ProductPrivateFund productInfo = getPrivateProductById(product_uuid);
            productScale = productInfo.getProductScale().doubleValue();
            productAccumulation = productInfo.getProductAccumulation().doubleValue();
            productManual = productInfo.getProductManual().doubleValue();
        }

        logger.info("updateRaiseAmount productScale:" + productScale + ", productAccumulation:" + productAccumulation + ", productManual:" + productManual + ", Amount:" + amount);

        if(DataUtils.isNotEmpty(userPhone)) {
            if (((productAccumulation + productManual) + amount) >= productScale) {
                ProductCriticalDateVO productCriticalDate = new ProductCriticalDateVO();
                productCriticalDate.setRaiseEndDate(StringOrDate.getCurDate());

                updateProductStatus(product_uuid, BizDefine.PRODUCT_STATUS_ENDRAISE, createBy, productCriticalDate);
            }
        }

        updateProductProgress(product_uuid, amount + productManual, productType, createBy);

        return true;
    }

    /**
     * 取消交易
     * @param orderBillCode 订单号
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean cancelTrade(String orderBillCode, String userPhone, String cancelReason) throws BusinessException {
        TradeOrder tradeOrder = lstTradeOrderByOrderBillCode(orderBillCode);

        //Step1 撤单检查，1交易状态   2账户中有足够的冻结金额
        if (tradeOrder != null) {
            if (DataUtils.isContain(tradeOrder.getOrderStatus(), BizDefine.ORDER_STATUS_APPLY, BizDefine.ORDER_STATUS_CONFIRM)) {
                if (DataUtils.isContain(tradeOrder.getOrderStatus(), BizDefine.ORDER_STATUS_CONFIRM)) {
                    Account investorAccount = getAccountByAccountUuid(tradeOrder.getAccountUuid());
                    Account issuerAccount = getAccountByProductUuid(tradeOrder.getProductUuid());
                    checkAccount(investorAccount, issuerAccount);
                    if (investorAccount.getAccountFreezeAmount().doubleValue() < tradeOrder.getPaidAmount().doubleValue()) {
                        throw new BusinessException(TradeStatusMsg.CANCELTRADE_FAIL_ERR, TradeStatusMsg.CANCELTRADE_FAIL_ERR_MSG, false);
                    }

                    //Step2 正式开始做退款
                    //Step2.1 删除流水表
                    accountTransactionMapper.deleteByOrderBillCode(tradeOrder.getOrderBillCode());

                    //Step2.2 变更投资者账户表
                    accountMapper.investorCancelTrade(tradeOrder.getAccountUuid(), tradeOrder.getPaidAmount().doubleValue());

                    //Step2.3 变更平台融资账户
                    accountMapper.reduceCashAmount(issuerAccount.getAccountUuid(), tradeOrder.getPaidAmount().doubleValue());
                }

                //Step3 修改交易表
                tradeOrderMapper.updateStatusByOrderBillCode(tradeOrder.getOrderBillCode(), BizDefine.ORDER_STATUS_CANCEL);

                return true;
            } else if (DataUtils.isContain(tradeOrder.getOrderStatus(), BizDefine.ORDER_STATUS_CANCEL)) {
                return true;
            } else {
                throw new BusinessException(TradeStatusMsg.CANCELTRADE_FAIL_ERR, TradeStatusMsg.CANCELTRADE_FAIL_ERR_MSG, false);
            }
        }

        return false;
    }

    /**
     * 计算收益
     *
     * @param product_uuid 产品ID
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public ProductProfitVO calculationProfit(String product_uuid) throws BusinessException {
        ProductProfitVO productProfitVO = new ProductProfitVO();
        ProductFixedIncome productInfo = getFixedIncomeProductById(product_uuid);

        productProfitVO.setProductUuid(product_uuid);
        productProfitVO.setProductAbbrName(productInfo.getProductAbbrName());

        double profitRate = productInfo.getAnnualInterestRate().doubleValue();
        int productPerid = productInfo.getProductPeriod();
        int rateFormulaParam = productInfo.getRateFormulaParam();
        rateFormulaParam = (rateFormulaParam > 0) ? rateFormulaParam : RATEFORMULAPARAM;
        double profitBase = (profitRate * productPerid) / rateFormulaParam;

        WhereCondition condition = new WhereCondition();
        condition.setCondi("product_uuid", product_uuid);
        condition.noDelete();

        for (TradeOrder tradeOrder : lstTradeOrdersByCondition(condition)) {
            //本金
            double raiseAmt = AmountUtils.exac(tradeOrder.getOrderAmount());
            productProfitVO.setClearPrincAmount(productProfitVO.getClearPrincAmount() + raiseAmt);

            //收益
            double profitAmount = raiseAmt * profitBase;
            profitAmount = AmountUtils.exac(profitAmount);
            productProfitVO.setClearProfitAmount(productProfitVO.getClearProfitAmount() + profitAmount);

            //营销加息
            double maketAmount = 0;
            productProfitVO.setMarketingRateAmount(productProfitVO.getMarketingRateAmount() + maketAmount);

            //兑付总金额
            double cashAmount = raiseAmt + profitAmount + maketAmount;
            productProfitVO.setClearTotalAmount(productProfitVO.getClearTotalAmount() + cashAmount);
        }

        return productProfitVO;
    }

    /**
     * 产品提前到期
     * @param product_uuid 产品ID
     * @param createBy 操作人
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void advanceProductEnd(String product_uuid, String createBy) throws BusinessException {
        logger.info("Step1 检查产品状态");
        ProductFixedIncome productInfo = getFixedIncomeProductById(product_uuid);
        if(productInfo.getProductStatus() != BizDefine.PRODUCT_STATUS_INTEREST) {
            throw new BusinessException(TradeStatusMsg.PRODUCT_STATUS_ERR, TradeStatusMsg.PRODUCT_STATUS_ERR_MSG, true);
        }

        logger.info("Step2 加锁处理");
        if(checkKeyLock("advanceProductEnd_"+product_uuid, 1)) {
            return;
        }

        logger.info("Step3 修正交易信息");
        logger.info("Step3.1 备份trade表");
        tradeOrderMapper.deleteBackRecord(product_uuid);
        tradeOrderMapper.backTradeOrderRecord(product_uuid);

        logger.info("Step3.2 修正交易信息");
        tradeService.fixTradeOrder(product_uuid);

        logger.info("Step4 做产品到期处理 {}, {}", product_uuid, createBy);
        productEndService.fixedProductEnd(product_uuid, createBy);
    }

    /**
     * 定时更新更新固收产品的状态
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void fixedTimeUpdateFixedProductStatus() throws BusinessException {
        String curDate = DateUtil.formateDate(new Date());
        String yesterday = DateUtil.formateDate(StringOrDate.dateOffsetDay(new Date(), -1));

        List<ProductFixedIncome> productList = getFixedIncomeProductList(BizDefine.PRODUCT_STATUS_LOAN);
        for(ProductFixedIncome productInfo : productList){
            if(DataUtils.isNotEmpty(productInfo.getProductUuid())) {
                TradeInvestSummaryExVO tradeInvestSummary = null;

                try {
                    tradeInvestSummary = productEstablishService.getProductEstablishLoanDetail(productInfo.getProductUuid());
                }catch(BusinessException e) {
                    //属于内部错误，只记录不抛出
                    logger.error("取放款信息异常", e);
                    continue;
                }

                if((tradeInvestSummary != null) &&
                        (tradeInvestSummary.getTransactionStatus() == BizDefine.WORKFLOW_STATUS_CLEAR) &&
                        (null != tradeInvestSummary.getPayedTime())) {
                    String payDate = DateUtil.formateDate(tradeInvestSummary.getPayedTime());
                    String interestDate = DateUtil.formateDate(productInfo.getProductInterestDate());

                    //将产品的状态设置为计息中，满足两个条件：
                    //1、放款日期 <= (T-1)    T为当前日，下同
                    //--2、T >= 起息日
                    if((payDate.compareTo(yesterday) <= 0) /*&& (curDate.compareTo(interestDate) > 0)*/) {
                        ProductCriticalDateVO productCriticalDate = null;
                        //ProductCriticalDateVO productCriticalDate = new ProductCriticalDateVO();
                        //productCriticalDate.setProductInterestDate(StringOrDate.getCurDate());
                        updateProductStatus(productInfo.getProductUuid(), BizDefine.PRODUCT_STATUS_INTEREST, BizDefine.DEFAULT_OPERATOR, productCriticalDate);

                        tradeOrderMapper.updateStatus(productInfo.getProductUuid(), BizDefine.ORDER_STATUS_PRODUCT_INTEREST, BizDefine.ORDER_STATUS_CONFIRM );
                    }
                }
            }
        }

        productList = getFixedIncomeProductList(BizDefine.PRODUCT_STATUS_INTEREST);
        for(ProductFixedIncome productInfo : productList){
            if(DataUtils.isNotEmpty(productInfo.getProductUuid()) && (productInfo.getProductExpiringDate() != null)) {
                String expiringDate = DateUtil.formateDate(productInfo.getProductExpiringDate());
                if(expiringDate.compareTo(curDate) <= 0) {
                    try {
                        productEndService.fixedProductEnd(productInfo.getProductUuid(), BizDefine.DEFAULT_OPERATOR);
                    }catch(BusinessException e) {
                        //属于内部错误，只记录不抛出
                        logger.error("产品到期处理异常", e);
                        continue;
                    }
                }
            }
        }
    }

    /**
     * 自动更新固收产品的状态
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void autoUpdateFixedProductStatus() throws BusinessException {
        List<ProductFixedIncome> productList = getFixedIncomeProductList(BizDefine.PRODUCT_STATUS_PREHEAT);
        String curDate = DateUtil.formateDate(new Date(),DateUtil.CURRENTTIME_FORMAT);//当前时间 yyyy-MM-dd HH:mm:ss
        for(ProductFixedIncome productInfo : productList){
            if(DataUtils.isNotEmpty(productInfo.getProductUuid()) && (null != productInfo.getRaiseStartDate()) && (null != productInfo.getRaiseEndDate()))
            {
                String raiseEndDate=DateUtil.stringAppendEndTime(DateUtil.formateDate(productInfo.getRaiseEndDate()));
                if ((DateUtil.formateDate(productInfo.getRaiseStartDate(),DateUtil.CURRENTTIME_FORMAT).compareTo(curDate) <= 0)
                        && ( raiseEndDate.compareTo(curDate) > 0)) {
                    updateProductStatus(productInfo.getProductUuid(), BizDefine.PRODUCT_STATUS_RAISE, BizDefine.DEFAULT_OPERATOR, null);
                }else if(raiseEndDate.compareTo(curDate) < 0) {
                    updateProductStatus(productInfo.getProductUuid(), BizDefine.PRODUCT_STATUS_ENDRAISE, BizDefine.DEFAULT_OPERATOR, null);
                }
            }
        }

        productList = getFixedIncomeProductList(BizDefine.PRODUCT_STATUS_RAISE);
        curDate =  DateUtil.formateDate(new Date(),DateUtil.CURRENTTIME_FORMAT);
        for (ProductFixedIncome productInfo : productList) {
            if (DataUtils.isNotEmpty(productInfo.getProductUuid()) && (null != productInfo.getRaiseEndDate())) {
                String raiseEndDate=DateUtil.stringAppendEndTime(DateUtil.formateDate(productInfo.getRaiseEndDate()));
                if (raiseEndDate.compareTo(curDate) < 0) {
                    //检查募集情况, 如没有募集金额，则做募集失败(废弃)处理
                    if (lstRaiseAmt(productInfo.getProductUuid()) > 0) {
                        updateProductStatus(productInfo.getProductUuid(), BizDefine.PRODUCT_STATUS_ENDRAISE, BizDefine.DEFAULT_OPERATOR, null);
                    } else {
                        updateProductStatus(productInfo.getProductUuid(), BizDefine.PRODUCT_STATUS_ABORT, BizDefine.DEFAULT_OPERATOR, null);
                    }
                }
            }
        }
    }

    /**
     * 产品确认
     * @param product_uuid 产品ID
     * @param createBy 操作人
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void fixedProductConfirm(String product_uuid, String createBy) throws BusinessException {
        ProductFixedIncome productInfo = getFixedIncomeProductById(product_uuid);

        if(DataUtils.byteToInt(productInfo.getProductStatus()) == BizDefine.PRODUCT_STATUS_UNCONFIRMED) {
            Date raiseStartDate = productInfo.getRaiseStartDate();

            ProductCriticalDateVO productCriticalDate = new ProductCriticalDateVO();
            //产品发布日
            productCriticalDate.setProductPublishDate(StringOrDate.getCurDate());
            if((raiseStartDate != null) && ((new Date()).getTime() > raiseStartDate.getTime())) {
                updateProductStatus(product_uuid, BizDefine.PRODUCT_STATUS_RAISE, createBy, productCriticalDate);
            }else {
                updateProductStatus(product_uuid, BizDefine.PRODUCT_STATUS_PREHEAT, createBy, productCriticalDate);
            }
        }
    }

    /**
     * 产品作废
     * @param product_uuid 产品ID
     * @param createBy 操作人
     * @return
     * @throws BusinessException
     */
    @Override
    public void fixedProductAbort(String product_uuid, String createBy) throws BusinessException {
        ProductFixedIncome productInfo = getFixedIncomeProductById(product_uuid);
        int productStatus = DataUtils.byteToInt(productInfo.getProductStatus());

        if(BizDefine.PRODUCT_STATUS_PREHEAT == productStatus) {
            updateProductStatus(product_uuid, BizDefine.PRODUCT_STATUS_ABORT, createBy, null);
            return;
        }else if(BizDefine.PRODUCT_STATUS_RAISE == productStatus) {
            if(lstRaiseAmt(product_uuid) <= 0) {
                updateProductStatus(product_uuid, BizDefine.PRODUCT_STATUS_ABORT, createBy, null);
                return;
            }
        }else if(BizDefine.PRODUCT_STATUS_ABORT == productStatus) {
            throw new BusinessException(TradeStatusMsg.WORKFLOW_STATUS_ERR, TradeStatusMsg.WORKFLOW_STATUS_ERR_MSG, false);
        }

        throw new BusinessException(TradeStatusMsg.PRODUCT_ABORT_ERR, TradeStatusMsg.PRODUCT_ABORT_ERR_MSG, false);
    }

    /**
     * 产品开始募集
     * @param product_uuid 产品ID
     * @param productType
     * @param createBy 操作人
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void productBeginRasie(String product_uuid, String productType, String createBy) throws BusinessException{
        int productStatus = getProductStatus(product_uuid, productType);
        checkStatus(productStatus, BizDefine.PRODUCT_STATUS_PREHEAT);

        if(productType.equals(ProductType.PRODUCT_PF)) {
            updatePrivateProductRaiseStatus(product_uuid, BizDefine.PRODUCT_STATUS_RAISE, createBy);
        }else if(productType.equals(ProductType.PRODUCT_FT)) {
            ProductFixedIncome productInfo = getFixedIncomeProductById(product_uuid);

            ProductCriticalDateVO productCriticalDate = null;
            //将募集开始日期提前
            if(productInfo.getRaiseStartDate().getTime() > (new Date()).getTime()) {
                productCriticalDate = new ProductCriticalDateVO();
                productCriticalDate.setRaiseStartDate(StringOrDate.getCurDate());
            }

            updateProductStatus(product_uuid, BizDefine.PRODUCT_STATUS_RAISE, createBy, productCriticalDate);
        }
    }

    /**
     * 产品结束募集
     * @param product_uuid 产品ID
     * @param productType
     * @param createBy 操作人
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void productEndRasie(String product_uuid, String productType, String createBy) throws BusinessException{
        int productStatus = getProductStatus(product_uuid, productType);
        checkStatus(productStatus, BizDefine.PRODUCT_STATUS_RAISE);

        if(productType.equals(ProductType.PRODUCT_PF)) {
            //更新募集进度
            ProductRaiseProgressVO raiseProgressVO = lstRaiseAmount(product_uuid, productType);
            if ((raiseProgressVO.getProductManual() + raiseProgressVO.getProductAccumulation()) < raiseProgressVO.getProductScale()) {
                Double amount = raiseProgressVO.getProductScale() - (raiseProgressVO.getProductManual() + raiseProgressVO.getProductAccumulation());
                updateRaiseAmount(product_uuid, productType, "", amount, "system");
            }
            updatePrivateProductRaiseStatus(product_uuid, BizDefine.PRODUCT_STATUS_ENDRAISE, createBy);
        }else if(productType.equals(ProductType.PRODUCT_FT)) {
            //更新募集进度
            ProductRaiseProgressVO raiseProgressVO = lstRaiseAmount(product_uuid, productType);
            if ((raiseProgressVO.getProductManual() + raiseProgressVO.getProductAccumulation()) < raiseProgressVO.getProductScale()) {
                Double amount = raiseProgressVO.getProductScale() - (raiseProgressVO.getProductManual() + raiseProgressVO.getProductAccumulation());
                updateRaiseAmount(product_uuid, productType, "", amount, "system");
            }

            ProductCriticalDateVO productCriticalDate = new ProductCriticalDateVO();
            productCriticalDate.setRaiseEndDate(StringOrDate.getCurDate());
            updateProductStatus(product_uuid, BizDefine.PRODUCT_STATUS_ENDRAISE, createBy, productCriticalDate);
        }
    }

    /**
     * 产品进入封闭期
     * @param product_uuid 产品ID
     * @param productType
     * @param createBy 操作人
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void productBeginClosedPeriod(String product_uuid, String productType, String createBy) throws BusinessException {
        if(productType.equals(ProductType.PRODUCT_PF)) {
            int productStatus = getProductStatus(product_uuid, productType);
            checkStatus(productStatus, BizDefine.PRODUCT_STATUS_ESTABLISH);
            updateProductStatus(product_uuid, BizDefine.PRODUCT_PRIVATE_STATUS_CLOSED_PERIOD, createBy, null);
        }
    }

    /**
     * 产品进入存续期
     * @param product_uuid 产品ID
     * @param productType
     * @param createBy 操作人
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void productBeginDuration(String product_uuid, String productType, String createBy) throws BusinessException {
        if(productType.equals(ProductType.PRODUCT_PF)) {
            int productStatus = getProductStatus(product_uuid, productType);
            checkStatus(productStatus, BizDefine.PRODUCT_PRIVATE_STATUS_CLOSED_PERIOD);
            updateProductStatus(product_uuid, BizDefine.PRODUCT_PRIVATE_STATUS_DURATION, createBy, null);
        }
    }

    /**
     * 产品上架
     * @param product_uuid 产品ID
     * @param productType
     * @param createBy 操作人
     * @return
     * @throws BusinessException
     */
    @Override
    public void productShelvesOn(String product_uuid, String productType, String createBy) throws BusinessException{
        //只是为了检查该产品是否存在
        int productOnStatus = getProductOnStatus(product_uuid, productType);
        if(BizDefine.PRODUCT_SHELVES_ON == productOnStatus) {
            throw new BusinessException(TradeStatusMsg.WORKFLOW_STATUS_ERR, TradeStatusMsg.WORKFLOW_STATUS_ERR_MSG, false);
        }

        updateProductShelves(product_uuid, BizDefine.PRODUCT_SHELVES_ON, createBy);
    }

    /**
     * 产品下架
     * @param product_uuid 产品ID
     * @param productType
     * @param createBy 操作人
     * @return
     * @throws BusinessException
     */
    @Override
    public void productShelvesOff(String product_uuid, String productType, String createBy) throws BusinessException{
        //获取产品上架状态
        int productOnStatus = getProductOnStatus(product_uuid, productType);
        //判断产品是否为下架or未上架
        if((BizDefine.PRODUCT_SHELVES_OFF == productOnStatus) || (BizDefine.PRODUCT_SHELVES_INIT == productOnStatus)) {
            throw new BusinessException(TradeStatusMsg.WORKFLOW_STATUS_ERR, TradeStatusMsg.WORKFLOW_STATUS_ERR_MSG, false);
        }
        //如果为定期产品
        if(productType.equals(ProductType.PRODUCT_FT)) {
            ProductFixedIncome productInfo = getFixedIncomeProductById(product_uuid);

            if (productInfo.getProductStatus() == BizDefine.PRODUCT_STATUS_RAISE) {
                WhereCondition condition = new WhereCondition();
                condition.setCondi("product_uuid", product_uuid);
                condition.setCondi("order_status", BizDefine.ORDER_STATUS_CONFIRM);
                condition.noDelete();
                if (lstTradeOrdersByCondition(condition).size() > 0) {
                    throw new BusinessException(TradeStatusMsg.PRODUCT_SHELVESOFF_ERR, TradeStatusMsg.PRODUCT_SHELVESOFF_ERR_MSG, false);
                }
            }
        }else if(productType.equals(ProductType.PRODUCT_PF)) {
            ProductPrivateFund productInfo = getPrivateProductById(product_uuid);
            if (productInfo.getProductStatus() == BizDefine.PRODUCT_STATUS_RAISE) {
                Map userMap = new HashMap();
                userMap.put("productUuid", product_uuid);
                //产品订单状态（0： 待审核 ,1：待确认 ,2： 已确认,11：审核驳回，12：确认驳回 ）',
                userMap.put("pfoStatusList", new int[]{TradeConstants.PFO_STAUTS_WAIT_AUDIT,TradeConstants.PFO_STAUTS_WAIT_VERIFY,TradeConstants.PFO_STAUTS_DONE,TradeConstants.PFO_STAUTS_VERIFY_FAIL});
                if (tradePrivateFundOrderMapper.getCount(userMap) > 0) {
                    throw new BusinessException(TradeStatusMsg.PRODUCT_SHELVESOFF_ERR, TradeStatusMsg.PRODUCT_SHELVESOFF_ERR_MSG, false);
                }
            }
        }

        updateProductShelves(product_uuid, BizDefine.PRODUCT_SHELVES_OFF, createBy);
    }

    /**
     * 更新产品费用
     * @param
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void setProductFeeRate(String product_uuid, double platformServiceFeeRate, double exchangeManagerFeeRate) throws BusinessException {
        exchangeManagerfeeConfigMapper.deleteByProductUuid(product_uuid);

        ExchangeManagerfeeConfig config = new ExchangeManagerfeeConfig();
        config.setExchangeManagerfeeType(new Integer(1).byteValue());
        config.setProductUuid(product_uuid);

        config.setProductCode("");
        config.setProductType("");
        config.setProductAbbrName("");
        config.setAppointProductType("");

        config.setFeeRate(new BigDecimal(exchangeManagerFeeRate));
        exchangeManagerfeeConfigMapper.insert(config);

        platformCommissionConfigMapper.deleteByProductUuid(product_uuid);
        PlatformCommissionConfig config1 = new PlatformCommissionConfig();
        config1.setPlatformCommissionType(new Integer(1).byteValue());
        config1.setProductUuid(product_uuid);

        config1.setProductCode("");
        config1.setProductType("");
        config1.setProductAbbrName("");
        config1.setAppointProductType("");

        config1.setFeeRate(new BigDecimal(platformServiceFeeRate));
        platformCommissionConfigMapper.insert(config1);
    }
}