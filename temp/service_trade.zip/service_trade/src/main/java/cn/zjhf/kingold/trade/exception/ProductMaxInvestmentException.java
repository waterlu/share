package cn.zjhf.kingold.trade.exception;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.constant.TradeStatusMsg;

/**
 * 大于产品最大投资金额
 *
 * @author lutiehua
 * @date 2018/3/9
 */
public class ProductMaxInvestmentException extends BusinessException {

    public ProductMaxInvestmentException() {
        super(TradeStatusMsg.AMOUNT_GT_MAXINVESTMENT_CODE, TradeStatusMsg.AMOUNT_GT_MAXINVESTMENT_MSG, true);
    }
}
