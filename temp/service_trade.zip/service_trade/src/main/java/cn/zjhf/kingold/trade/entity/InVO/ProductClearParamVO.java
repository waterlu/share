package cn.zjhf.kingold.trade.entity.InVO;

import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * Created by zhangyijie on 2017/5/23.
 */
@ApiModel(value = "ProductClearParamVO", description = "产品清结算通用入参")
public class ProductClearParamVO extends InVOBase {
    @ApiModelProperty(required = true, value = "traceID")
    @NotEmpty
    private String traceID;

    @ApiModelProperty(required = true, value = "执行人，当前运营管理系统用户")
    private String userPhone;

    @ApiModelProperty(required = true, value = "执行人，当前运营管理系统用户名称")
    private String createBy;

    @ApiModelProperty(required = true, value = "product_uuid")
    @NotEmpty
    private String product_uuid;

    @ApiModelProperty(required = true, value = "是否审核通过，仅在审核时使用，1审核通过  0审核未通过")
    private int isAudited;

    @ApiModelProperty(required = true, value = "审核不通过的原因，仅在审核失败(isAudited == 0)时使用")
    private String message;

    public String getTraceID() {
        return traceID;
    }

    public void setTraceID(String traceID) {
        this.traceID = traceID;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public String getProduct_uuid() {
        return product_uuid;
    }

    public void setProduct_uuid(String product_uuid) {
        this.product_uuid = product_uuid;
    }

    public int getIsAudited() {
        return isAudited;
    }

    public void setIsAudited(int isAudited) {
        this.isAudited = isAudited;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(traceID) + ", ");
        sb.append("userPhone:" + DataUtils.toString(userPhone) + ", ");
        sb.append("product_uuid:" + DataUtils.toString(product_uuid) + ", ");
        sb.append("isAudited:" + DataUtils.toString(isAudited) + ", ");
        sb.append("message:" + DataUtils.toString(message));
        return sb.toString();
    }
}
