package cn.zjhf.kingold.trade.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.dto.RewardApplyDto;
import cn.zjhf.kingold.trade.dto.RewardFixedClearDto;
import cn.zjhf.kingold.trade.dto.RewardFixedSearchDto;
import cn.zjhf.kingold.trade.entity.RewardFixedTerm;
import cn.zjhf.kingold.trade.vo.RewardBatchInfoVO;

import java.util.List;
import java.util.Map;

/**
 * Created by lutiehua on 2017/6/2.
 */
public interface IRewardSummaryService {

    /**
     * 申请生成定期产品奖励的结算
     *
     * @param rewardApplyDto
     * @return
     * @throws BusinessException
     */
    ResponseResult applyFixedAward(RewardApplyDto rewardApplyDto) throws BusinessException;

    /**
     * 查询定期奖励结算记录
     *
     * @return
     * @throws BusinessException
     */
    List<RewardFixedTerm> searchRewardFixed(RewardFixedSearchDto rewardFixedSearchDto) throws BusinessException;

    /**
     * 查询定期奖励结算记录的总条数
     *
     * @param rewardFixedSearchDto
     * @return
     * @throws BusinessException
     */
    int searchRewardFixedCount(RewardFixedSearchDto rewardFixedSearchDto) throws BusinessException;

    /**
     *
     * @param rewardFixedBillCode
     * @return
     */
    RewardFixedTerm getFixedAward(String rewardFixedBillCode) throws BusinessException;

    /**
     * 更新审核状态
     *
     * @param param
     * @return
     */
    ResponseResult updateCheckStatus(Map<String, Object> param) throws BusinessException;

    /**
     * 更新结算状态
     *
     * @param clearDtoList
     * @return
     * @throws BusinessException
     */
    ResponseResult updateClearStatus(RewardFixedClearDto clearDtoList) throws BusinessException;

    /**
     * 读取一个批次的汇总信息
     *
     * @param batchCode
     * @return
     * @throws BusinessException
     */
    List<RewardBatchInfoVO> getOneBatchInfo(String batchCode) throws BusinessException;

    /**
     * 按批次更新审核状态
     *
     * @param param
     * @return
     * @throws BusinessException
     */
    ResponseResult updateCheckBatchStatus(Map<String, Object> param) throws BusinessException;

    /**
     * 按批次更新结算状态
     *
     * @param clearDto
     * @return
     * @throws BusinessException
     */
    ResponseResult updateClearBatchStatus(RewardFixedClearDto clearDto) throws BusinessException;
}
