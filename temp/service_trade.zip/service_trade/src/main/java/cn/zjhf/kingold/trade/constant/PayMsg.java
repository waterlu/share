package cn.zjhf.kingold.trade.constant;

/**
 * Created by likenice on 17/3/20.
 */

public class PayMsg {

    /**
     * 宝付单笔手续费
     */
    public static final double FEE_PER = 2.0;

    /**
     * 宝付免手续费次数
     */
    public static final int FREE_FEE_PER_MONTH = 3;

    /*
    *手续费付费方式（平台支付）
    */
    public static final int FEE_TOKEN_ON_PLATFORM = 1;

    /*
     *手续费付费方式（个人支付）
     */
    public static final int FEE_TOKEN_ON_PERSON = 2;


}

