package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.service.IBaseService;
import cn.zjhf.kingold.trade.service.ITradeService;
import cn.zjhf.kingold.trade.utils.StringOrDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by DELL on 2017/5/18.
 */
@Service
public class BaseServiceImpl implements IBaseService {
    protected static final Logger logger = LoggerFactory.getLogger(BaseServiceImpl.class);

    /**
     * 日期检查，将指定日期和当前系统日相对比
     * 目前系统日取的是计算机的系统时间
     * @return
     * @throws BusinessException
     */
    public boolean dateCheck(Date date) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(StringOrDate.DAY_FROMAT);

        logger.debug("当前日期：" + dateFormat.format(new Date()));
        logger.debug("检查日期：" + dateFormat.format(date));

        if(dateFormat.format(date).equals(dateFormat.format(new Date()))) {
            return true;
        }else {
            return false;
        }
    }
}
