package cn.zjhf.kingold.trade.service;


import cn.zjhf.kingold.common.exception.BusinessException;

/**
 * 用户接口
 * <p>
 * Created by xiexiaojie on 2017/12/25.
 */
public interface IUserService {
    /**
     * 获取邀请人uuid
     * @param userUuid
     * @return
     * @throws BusinessException
     */
    public String getInviterUuid(String userUuid) throws BusinessException;
}