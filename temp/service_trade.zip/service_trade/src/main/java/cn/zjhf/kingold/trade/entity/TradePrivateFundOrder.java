package cn.zjhf.kingold.trade.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author 
 */
public class TradePrivateFundOrder implements Serializable {
    /**
     * 产品订单编号
     */
    private String pfoCode;

    /**
     * 产品订单状态（0： 待审核 ,1：待确认 ,2： 已确认,11：审核不通过，12：确认失败 ）
     */
    private Byte pfoStatus;

    /**
     * 审核人uuid
     */
    private String pfoAuditUserUuid;

    /**
     * 审核时间
     */
    private Date pfoAuditTime;

    /**
     * 确认人uuid
     */
    private String pfoVerifyUserUuid;

    /**
     * 确认时间
     */
    private Date pfoVerifyTime;

    /**
     * 私募预约单编号
     */
    private String reservationBillCode;

    /**
     * 产品UUID
     */
    private String productUuid;

    /**
     * 产品编码
     */
    private String productCode;

    /**
     * 预约产品名称
     */
    private String productName;

    /**
     * 产品期限
     */
    private Integer productPeriod;

    /**
     * 产品期限类型： Y(year,年)； M(month,月)； W(week,周)； D(day,自然日)
     */
    private String productPeriodType;

    /**
     * 处理人用户UUID（专职理财师或者客服）
     */
    private String serviceUserUuid;

    /**
     * 处理人用户姓名
     */
    private String serviceUserName;

    /**
     * 处理人用户类型（1: 专职理财师 , 2: 客服）
     */
    private Byte serviceUserType;

    /**
     * 处理人用户电话
     */
    private String serviceUserMobile;

    /**
     * 处理人所属机构UUID
     */
    private String serviceUserOrgUuid;

    /**
     * 处理人所属机构Path
     */
    private String serviceUserOrgPath;

    /**
     * 投资人所属理顾UUID
     */
    private String investorUserUuid;

    /**
     * 投资人所属理顾电话
     */
    private String investorUserMobile;

    /**
     * 投资人所属理顾姓名
     */
    private String investorUserName;

    /**
     * 客户姓名
     */
    private String customerName;

    /**
     * 客户身份证号码
     */
    private String customerIdCardNo;

    /**
     * 客户手机号码
     */
    private String customerMobile;

    /**
     * 客户所在地区编码
     */
    private String customerRegionCode;

    /**
     * 客户详细住址
     */
    private String customerAddress;

    /**
     * 支付金额
     */
    private BigDecimal purchaseAmount;

    /**
     * 支付时间
     */
    private Date purchaseTime;

    /**
     * 签名
     */
    private String signature;

    /**
     * 删除标记 0未删除，1已删除
     */
    private Byte deleteFlag;

    private Date createTime;

    private Date updateTime;

    /**
     * 备注
     */
    private String pfoRemark;

    private static final long serialVersionUID = 1L;

    public String getPfoCode() {
        return pfoCode;
    }

    public void setPfoCode(String pfoCode) {
        this.pfoCode = pfoCode;
    }

    public Byte getPfoStatus() {
        return pfoStatus;
    }

    public void setPfoStatus(Byte pfoStatus) {
        this.pfoStatus = pfoStatus;
    }

    public String getPfoAuditUserUuid() {
        return pfoAuditUserUuid;
    }

    public void setPfoAuditUserUuid(String pfoAuditUserUuid) {
        this.pfoAuditUserUuid = pfoAuditUserUuid;
    }

    public Date getPfoAuditTime() {
        return pfoAuditTime;
    }

    public void setPfoAuditTime(Date pfoAuditTime) {
        this.pfoAuditTime = pfoAuditTime;
    }

    public String getPfoVerifyUserUuid() {
        return pfoVerifyUserUuid;
    }

    public void setPfoVerifyUserUuid(String pfoVerifyUserUuid) {
        this.pfoVerifyUserUuid = pfoVerifyUserUuid;
    }

    public Date getPfoVerifyTime() {
        return pfoVerifyTime;
    }

    public void setPfoVerifyTime(Date pfoVerifyTime) {
        this.pfoVerifyTime = pfoVerifyTime;
    }

    public String getReservationBillCode() {
        return reservationBillCode;
    }

    public void setReservationBillCode(String reservationBillCode) {
        this.reservationBillCode = reservationBillCode;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Integer getProductPeriod() {
        return productPeriod;
    }

    public void setProductPeriod(Integer productPeriod) {
        this.productPeriod = productPeriod;
    }

    public String getProductPeriodType() {
        return productPeriodType;
    }

    public void setProductPeriodType(String productPeriodType) {
        this.productPeriodType = productPeriodType;
    }

    public String getServiceUserUuid() {
        return serviceUserUuid;
    }

    public void setServiceUserUuid(String serviceUserUuid) {
        this.serviceUserUuid = serviceUserUuid;
    }

    public String getServiceUserName() {
        return serviceUserName;
    }

    public void setServiceUserName(String serviceUserName) {
        this.serviceUserName = serviceUserName;
    }

    public Byte getServiceUserType() {
        return serviceUserType;
    }

    public void setServiceUserType(Byte serviceUserType) {
        this.serviceUserType = serviceUserType;
    }

    public String getServiceUserMobile() {
        return serviceUserMobile;
    }

    public void setServiceUserMobile(String serviceUserMobile) {
        this.serviceUserMobile = serviceUserMobile;
    }

    public String getServiceUserOrgUuid() {
        return serviceUserOrgUuid;
    }

    public void setServiceUserOrgUuid(String serviceUserOrgUuid) {
        this.serviceUserOrgUuid = serviceUserOrgUuid;
    }

    public String getServiceUserOrgPath() {
        return serviceUserOrgPath;
    }

    public void setServiceUserOrgPath(String serviceUserOrgPath) {
        this.serviceUserOrgPath = serviceUserOrgPath;
    }

    public String getInvestorUserUuid() {
        return investorUserUuid;
    }

    public void setInvestorUserUuid(String investorUserUuid) {
        this.investorUserUuid = investorUserUuid;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerIdCardNo() {
        return customerIdCardNo;
    }

    public void setCustomerIdCardNo(String customerIdCardNo) {
        this.customerIdCardNo = customerIdCardNo;
    }

    public String getCustomerMobile() {
        return customerMobile;
    }

    public void setCustomerMobile(String customerMobile) {
        this.customerMobile = customerMobile;
    }

    public String getCustomerRegionCode() {
        return customerRegionCode;
    }

    public void setCustomerRegionCode(String customerRegionCode) {
        this.customerRegionCode = customerRegionCode;
    }

    public String getCustomerAddress() {
        return customerAddress;
    }

    public void setCustomerAddress(String customerAddress) {
        this.customerAddress = customerAddress;
    }

    public BigDecimal getPurchaseAmount() {
        return purchaseAmount;
    }

    public void setPurchaseAmount(BigDecimal purchaseAmount) {
        this.purchaseAmount = purchaseAmount;
    }

    public Date getPurchaseTime() {
        return purchaseTime;
    }

    public void setPurchaseTime(Date purchaseTime) {
        this.purchaseTime = purchaseTime;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getPfoRemark() {
        return pfoRemark;
    }

    public void setPfoRemark(String pfoRemark) {
        this.pfoRemark = pfoRemark;
    }

    public String getInvestorUserMobile() {
        return investorUserMobile;
    }

    public void setInvestorUserMobile(String investorUserMobile) {
        this.investorUserMobile = investorUserMobile;
    }

    public String getInvestorUserName() {
        return investorUserName;
    }

    public void setInvestorUserName(String investorUserName) {
        this.investorUserName = investorUserName;
    }
}