package cn.zjhf.kingold.trade.entity;

import org.hibernate.validator.constraints.NotEmpty;

import java.math.BigDecimal;
import java.util.Date;

public class TradeRecharge {
    private String tradeRechargeUuid;

    private String rechargeBillCode;

    private String rechargeBillType;

    private String userUuid;

    private String userPhone;

    private String accountUuid;

    private String agency;

    private String accountType;//账户类型

    private String agencyAccountNo;

    private String bankAccountNo;

    private BigDecimal rechargeAmount;

    private BigDecimal rechargeFee;


    private Byte rechargeFeeType;//手续费类型（1 平台支付 2 个人支付）

    private Byte rechargeStatus;

    private Byte payMethod;

    private String rechargeRemark;

    private Byte deleteFlag;

    private Date createTime;

    private Date updateTime;

    private Date rechargeTime;

    private String  tradeOrderBillCodeExtend;


    private String belongTopUserUuid;

    private String belongTopOrgPath;

    private String belongMerchantNum;

    public String getBelongTopUserUuid() {
        return belongTopUserUuid;
    }

    public void setBelongTopUserUuid(String belongTopUserUuid) {
        this.belongTopUserUuid = belongTopUserUuid;
    }

    public String getBelongTopOrgPath() {
        return belongTopOrgPath;
    }

    public void setBelongTopOrgPath(String belongTopOrgPath) {
        this.belongTopOrgPath = belongTopOrgPath;
    }

    private String  transactionChannel;

    public String getTradeOrderBillCodeExtend() {
        return tradeOrderBillCodeExtend;
    }

    public void setTradeOrderBillCodeExtend(String tradeOrderBillCodeExtend) {
        this.tradeOrderBillCodeExtend = tradeOrderBillCodeExtend;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public Byte getRechargeFeeType() {
        return rechargeFeeType;
    }

    public void setRechargeFeeType(Byte rechargeFeeType) {
        this.rechargeFeeType = rechargeFeeType;
    }

    public BigDecimal getRechargeFee() {
        return rechargeFee;
    }

    public void setRechargeFee(BigDecimal rechargeFee) {
        this.rechargeFee = rechargeFee;
    }

    public String getTradeRechargeUuid() {
        return tradeRechargeUuid;
    }

    public void setTradeRechargeUuid(String tradeRechargeUuid) {
        this.tradeRechargeUuid = tradeRechargeUuid == null ? null : tradeRechargeUuid.trim();
    }

    public String getRechargeBillCode() {
        return rechargeBillCode;
    }

    public void setRechargeBillCode(String rechargeBillCode) {
        this.rechargeBillCode = rechargeBillCode == null ? null : rechargeBillCode.trim();
    }

    public String getRechargeBillType() {
        return rechargeBillType;
    }

    public void setRechargeBillType(String rechargeBillType) {
        this.rechargeBillType = rechargeBillType == null ? null : rechargeBillType.trim();
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid == null ? null : userUuid.trim();
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone == null ? null : userPhone.trim();
    }

    public String getAccountUuid() {
        return accountUuid;
    }

    public void setAccountUuid(String accountUuid) {
        this.accountUuid = accountUuid == null ? null : accountUuid.trim();
    }

    public String getAgency() {
        return agency;
    }

    public void setAgency(String agency) {
        this.agency = agency == null ? null : agency.trim();
    }

    public String getAgencyAccountNo() {
        return agencyAccountNo;
    }

    public void setAgencyAccountNo(String agencyAccountNo) {
        this.agencyAccountNo = agencyAccountNo == null ? null : agencyAccountNo.trim();
    }

    public String getBankAccountNo() {
        return bankAccountNo;
    }

    public void setBankAccountNo(String bankAccountNo) {
        this.bankAccountNo = bankAccountNo == null ? null : bankAccountNo.trim();
    }

    public BigDecimal getRechargeAmount() {
        return rechargeAmount;
    }

    public void setRechargeAmount(BigDecimal rechargeAmount) {
        this.rechargeAmount = rechargeAmount;
    }

    public Byte getRechargeStatus() {
        return rechargeStatus;
    }

    public void setRechargeStatus(Byte rechargeStatus) {
        this.rechargeStatus = rechargeStatus;
    }

    public Byte getPayMethod() {
        return payMethod;
    }

    public void setPayMethod(Byte payMethod) {
        this.payMethod = payMethod;
    }

    public String getRechargeRemark() {
        return rechargeRemark;
    }

    public void setRechargeRemark(String rechargeRemark) {
        this.rechargeRemark = rechargeRemark == null ? null : rechargeRemark.trim();
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getRechargeTime() {
        return rechargeTime;
    }

    public void setRechargeTime(Date rechargeTime) {
        this.rechargeTime = rechargeTime;
    }

    public String getTransactionChannel() {
        return transactionChannel;
    }

    public void setTransactionChannel(String transactionChannel) {
        this.transactionChannel = transactionChannel;
    }

    public String getBelongMerchantNum() {
        return belongMerchantNum;
    }

    public void setBelongMerchantNum(String belongMerchantNum) {
        this.belongMerchantNum = belongMerchantNum;
    }

    @Override
    public String toString() {
        return "TradeRecharge{" +
                "tradeRechargeUuid='" + tradeRechargeUuid + '\'' +
                ", rechargeBillCode='" + rechargeBillCode + '\'' +
                ", rechargeBillType='" + rechargeBillType + '\'' +
                ", userUuid='" + userUuid + '\'' +
                ", userPhone='" + userPhone + '\'' +
                ", accountUuid='" + accountUuid + '\'' +
                ", agency='" + agency + '\'' +
                ", accountType='" + accountType + '\'' +
                ", agencyAccountNo='" + agencyAccountNo + '\'' +
                ", bankAccountNo='" + bankAccountNo + '\'' +
                ", rechargeAmount=" + rechargeAmount +
                ", rechargeFee=" + rechargeFee +
                ", rechargeFeeType=" + rechargeFeeType +
                ", rechargeStatus=" + rechargeStatus +
                ", payMethod=" + payMethod +
                ", rechargeRemark='" + rechargeRemark + '\'' +
                ", deleteFlag=" + deleteFlag +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                ", rechargeTime=" + rechargeTime +
                ", tradeOrderBillCodeExtend='" + tradeOrderBillCodeExtend + '\'' +
                ", belongTopUserUuid='" + belongTopUserUuid + '\'' +
                ", belongTopOrgPath='" + belongTopOrgPath + '\'' +
                ", belongMerchantNum='" + belongMerchantNum + '\'' +
                ", transactionChannel='" + transactionChannel + '\'' +
                '}';
    }
}