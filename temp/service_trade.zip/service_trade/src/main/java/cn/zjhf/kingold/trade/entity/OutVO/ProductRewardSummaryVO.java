package cn.zjhf.kingold.trade.entity.OutVO;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.trade.entity.ProductRewardSummary;
import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@ApiModel(value = "ProductRewardSummaryVO", description = "产品奖励记录(汇总)")
public class ProductRewardSummaryVO extends ParamVO {

    @ApiModelProperty(required = true, value = "产品奖励记录申请编号,自增ID")
    @NotEmpty
    private Long productRewardSummaryUuid;

    @ApiModelProperty(required = true, value = "产品UUID")
    @NotEmpty
    @Size(min = 1, max = 32)
    private String productUuid;

    @ApiModelProperty(required = true, value = "产品编码")
    @NotEmpty
    @Size(min = 1, max = 16)
    private String productCode;

    @ApiModelProperty(required = true, value = "产品简称")
    @NotEmpty
    @Size(min = 1, max = 40)
    private String productAbbrName;

    @ApiModelProperty(required = true, value = "产品类型")
    @NotEmpty
    @Size(min = 1, max = 16)
    private String productType;

    @ApiModelProperty(required = false, value = "产品成立日, 格式为 YYYY-MM-DD")
    private Date productEstablishmentDate;

    @ApiModelProperty(required = false, value = "奖励记录数")
    private int rewardCount;

    @ApiModelProperty(required = false, value = "已结算奖励记录数")
    private int rewardClearCount;

    @ApiModelProperty(required = false, value = "理财顾问数量")
    private int financialAdvisorCount;

    @ApiModelProperty(required = true, value = "税前理顾佣金")
    @NotEmpty
    private double pretaxRewardAmount;

    @ApiModelProperty(required = true, value = "税前平台服务费")
    @NotEmpty
    private double pretaxPlatformServicefee;

    @ApiModelProperty(required = true, value = "(平台服务费的)扣税")
    @NotEmpty
    private double platformServicefeeTax;

    @ApiModelProperty(required = true, value = "税后平台服务费")
    @NotEmpty
    private double aftertaxPlatformServicefee;

    @ApiModelProperty(required = true, value = "交易所管理费")
    @NotEmpty
    private double exchangeManageFee;

    @ApiModelProperty(required = true, value = "平台收入")
    @NotEmpty
    private double platformIncome;

    @ApiModelProperty(required = false, value = "放款时间")
    private Date loanTime;

    @ApiModelProperty(required = false, value = "收入报税审核人")
    @Size(min = 1, max = 32)
    private String incomeTaxAuditOperator;

    @ApiModelProperty(required = false, value = "收入报税审核时间")
    private Date incomeTaxAuditTime;

    @ApiModelProperty(required = false, value = "收入报税审核意见")
    @Size(min = 1, max = 512)
    private String incomeTaxAuditOpinion;

    @ApiModelProperty(required = false, value = "收入报税结算人")
    @Size(min = 1, max = 32)
    private String incomeTaxClearOperator;

    @ApiModelProperty(required = false, value = "收入报税结算时间")
    private Date incomeTaxClearTime;

    @ApiModelProperty(required = true, value = "收入报税处理状态：-1审批失败；1待审核；2审核通过; 3已结算")
    @NotEmpty
    private int incomeTaxClearStatus;

    @ApiModelProperty(required = false, value = "管理费审核人")
    @Size(min = 1, max = 32)
    private String exchangeManagefeeAuditOperator;

    @ApiModelProperty(required = false, value = "管理费审核时间")
    private Date exchangeManagefeeAuditTime;

    @ApiModelProperty(required = false, value = "管理费审核意见")
    @Size(min = 1, max = 512)
    private String exchangeManagefeeAuditOpinion;

    @ApiModelProperty(required = false, value = "管理费结算人")
    @Size(min = 1, max = 32)
    private String exchangeManagefeeClearOperator;

    @ApiModelProperty(required = false, value = "管理费结算时间")
    private Date exchangeManagefeeClearTime;

    @ApiModelProperty(required = true, value = "管理费处理状态：-1审批失败；1待审核；2审核通过; 3已结算")
    @NotEmpty
    private int exchangeManagefeeClearStatus;

    @ApiModelProperty(required = false, value = "签名")
    @Size(min = 1, max = 128)
    private String signature;

    @ApiModelProperty(required = true, value = "删除标记 0未删除，1已删除")
    @NotEmpty
    private int deleteFlag;

    @ApiModelProperty(required = true, value = "产品期限")
    private int productPeriod;

    @ApiModelProperty(required = true, value = "募集金额/产品规模")
    private BigDecimal productScale;

    @ApiModelProperty(required = true, value = "实际募集金额")
    private BigDecimal productAccumulation;

    @ApiModelProperty(required = true, value = "平台服务费")
    private BigDecimal platformCommission;

    @ApiModelProperty(required = true, value = "交易所管理费")
    private BigDecimal managementFee;

    @ApiModelProperty(required = true, value = "现金券使用总额")
    private double marketingAmout;

    @ApiModelProperty(required = true, value = "税前现金券总额")
    private double pretaxMarketingAmout;

    @ApiModelProperty(required = true, value = "现金券扣税")
    private double deductionMarketingAmout;

    @ApiModelProperty(required = true, value = "")
    @NotEmpty
    private Date createTime;

    @ApiModelProperty(required = true, value = "")
    @NotEmpty
    private Date updateTime;

    @ApiModelProperty(required = true, value = "募集方名称")
    private String productIssuerName;

    public ProductRewardSummaryVO() {
    }

    public static List<ProductRewardSummaryVO> toList(List<ProductRewardSummary> items) {
        List<ProductRewardSummaryVO> voItems = new ArrayList<ProductRewardSummaryVO>();

        for(ProductRewardSummary item : items) {
            voItems.add(new ProductRewardSummaryVO(item));
        }

        return voItems;
    }

    public ProductRewardSummaryVO(ProductRewardSummary productRewardSummary) {
        if(null != productRewardSummary) {
            this.productRewardSummaryUuid = productRewardSummary.getProductRewardSummaryUuid();
            this.productUuid = productRewardSummary.getProductUuid();
            this.productCode = productRewardSummary.getProductCode();
            this.productAbbrName = productRewardSummary.getProductAbbrName();
            this.productType = productRewardSummary.getProductType();
            this.productEstablishmentDate = productRewardSummary.getProductEstablishmentDate();
            this.rewardCount = productRewardSummary.getRewardCount();
            this.rewardClearCount = productRewardSummary.getRewardClearCount();
            this.financialAdvisorCount = productRewardSummary.getFinancialAdvisorCount();
            this.pretaxRewardAmount = productRewardSummary.getPretaxRewardAmount().doubleValue();
            this.pretaxPlatformServicefee = productRewardSummary.getPretaxPlatformServicefee().doubleValue();
            this.platformServicefeeTax = productRewardSummary.getPlatformServicefeeTax().doubleValue();
            this.aftertaxPlatformServicefee = productRewardSummary.getAftertaxPlatformServicefee().doubleValue();
            this.exchangeManageFee = productRewardSummary.getExchangeManageFee().doubleValue();
            this.platformIncome = productRewardSummary.getPlatformIncome().doubleValue();
            this.loanTime = productRewardSummary.getLoanTime();
            this.incomeTaxAuditOperator = productRewardSummary.getIncomeTaxAuditOperator();
            this.incomeTaxAuditTime = productRewardSummary.getIncomeTaxAuditTime();
            this.incomeTaxAuditOpinion = productRewardSummary.getIncomeTaxAuditOpinion();
            this.incomeTaxClearOperator = productRewardSummary.getIncomeTaxClearOperator();
            this.incomeTaxClearTime = productRewardSummary.getIncomeTaxClearTime();
            this.incomeTaxClearStatus = productRewardSummary.getIncomeTaxClearStatus();
            this.exchangeManagefeeAuditOperator = productRewardSummary.getExchangeManagefeeAuditOperator();
            this.exchangeManagefeeAuditTime = productRewardSummary.getExchangeManagefeeAuditTime();
            this.exchangeManagefeeAuditOpinion = productRewardSummary.getExchangeManagefeeAuditOpinion();
            this.exchangeManagefeeClearOperator = productRewardSummary.getExchangeManagefeeClearOperator();
            this.exchangeManagefeeClearTime = productRewardSummary.getExchangeManagefeeClearTime();
            this.exchangeManagefeeClearStatus = productRewardSummary.getExchangeManagefeeClearStatus();
            this.signature = productRewardSummary.getSignature();
            this.deleteFlag = productRewardSummary.getDeleteFlag();
            this.productPeriod = productRewardSummary.getProductPeriod();
            this.productScale = productRewardSummary.getProductScale();
            this.productAccumulation = productRewardSummary.getProductAccumulation();
            this.platformCommission = productRewardSummary.getPlatformCommission();
            this.managementFee = productRewardSummary.getManagementFee();
            this.createTime = productRewardSummary.getCreateTime();
            this.updateTime = productRewardSummary.getUpdateTime();
            this.productIssuerName = productRewardSummary.getProductIssuerName();
        }
    }

    public Long getProductRewardSummaryUuid() {
        return productRewardSummaryUuid;
    }

    public void setProductRewardSummaryUuid(Long productRewardSummaryUuid) {
        this.productRewardSummaryUuid = productRewardSummaryUuid;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductAbbrName() {
        return productAbbrName;
    }

    public void setProductAbbrName(String productAbbrName) {
        this.productAbbrName = productAbbrName;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public Date getProductEstablishmentDate() {
        return productEstablishmentDate;
    }

    public void setProductEstablishmentDate(Date productEstablishmentDate) {
        this.productEstablishmentDate = productEstablishmentDate;
    }

    public int getRewardCount() {
        return rewardCount;
    }

    public void setRewardCount(int rewardCount) {
        this.rewardCount = rewardCount;
    }

    public int getRewardClearCount() {
        return rewardClearCount;
    }

    public void setRewardClearCount(int rewardClearCount) {
        this.rewardClearCount = rewardClearCount;
    }

    public int getFinancialAdvisorCount() {
        return financialAdvisorCount;
    }

    public void setFinancialAdvisorCount(int financialAdvisorCount) {
        this.financialAdvisorCount = financialAdvisorCount;
    }

    public double getPretaxRewardAmount() {
        return pretaxRewardAmount;
    }

    public void setPretaxRewardAmount(double pretaxRewardAmount) {
        this.pretaxRewardAmount = pretaxRewardAmount;
    }

    public double getPretaxPlatformServicefee() {
        return pretaxPlatformServicefee;
    }

    public void setPretaxPlatformServicefee(double pretaxPlatformServicefee) {
        this.pretaxPlatformServicefee = pretaxPlatformServicefee;
    }

    public double getPlatformServicefeeTax() {
        return platformServicefeeTax;
    }

    public void setPlatformServicefeeTax(double platformServicefeeTax) {
        this.platformServicefeeTax = platformServicefeeTax;
    }

    public double getAftertaxPlatformServicefee() {
        return aftertaxPlatformServicefee;
    }

    public void setAftertaxPlatformServicefee(double aftertaxPlatformServicefee) {
        this.aftertaxPlatformServicefee = aftertaxPlatformServicefee;
    }

    public double getExchangeManageFee() {
        return exchangeManageFee;
    }

    public void setExchangeManageFee(double exchangeManageFee) {
        this.exchangeManageFee = exchangeManageFee;
    }

    public double getPlatformIncome() {
        return platformIncome;
    }

    public void setPlatformIncome(double platformIncome) {
        this.platformIncome = platformIncome;
    }

    public Date getLoanTime() {
        return loanTime;
    }

    public void setLoanTime(Date loanTime) {
        this.loanTime = loanTime;
    }

    public String getIncomeTaxAuditOperator() {
        return incomeTaxAuditOperator;
    }

    public void setIncomeTaxAuditOperator(String incomeTaxAuditOperator) {
        this.incomeTaxAuditOperator = incomeTaxAuditOperator;
    }

    public Date getIncomeTaxAuditTime() {
        return incomeTaxAuditTime;
    }

    public void setIncomeTaxAuditTime(Date incomeTaxAuditTime) {
        this.incomeTaxAuditTime = incomeTaxAuditTime;
    }

    public String getIncomeTaxAuditOpinion() {
        return incomeTaxAuditOpinion;
    }

    public void setIncomeTaxAuditOpinion(String incomeTaxAuditOpinion) {
        this.incomeTaxAuditOpinion = incomeTaxAuditOpinion;
    }

    public String getIncomeTaxClearOperator() {
        return incomeTaxClearOperator;
    }

    public void setIncomeTaxClearOperator(String incomeTaxClearOperator) {
        this.incomeTaxClearOperator = incomeTaxClearOperator;
    }

    public Date getIncomeTaxClearTime() {
        return incomeTaxClearTime;
    }

    public void setIncomeTaxClearTime(Date incomeTaxClearTime) {
        this.incomeTaxClearTime = incomeTaxClearTime;
    }

    public int getIncomeTaxClearStatus() {
        return incomeTaxClearStatus;
    }

    public void setIncomeTaxClearStatus(int incomeTaxClearStatus) {
        this.incomeTaxClearStatus = incomeTaxClearStatus;
    }

    public String getExchangeManagefeeAuditOperator() {
        return exchangeManagefeeAuditOperator;
    }

    public void setExchangeManagefeeAuditOperator(String exchangeManagefeeAuditOperator) {
        this.exchangeManagefeeAuditOperator = exchangeManagefeeAuditOperator;
    }

    public Date getExchangeManagefeeAuditTime() {
        return exchangeManagefeeAuditTime;
    }

    public void setExchangeManagefeeAuditTime(Date exchangeManagefeeAuditTime) {
        this.exchangeManagefeeAuditTime = exchangeManagefeeAuditTime;
    }

    public String getExchangeManagefeeAuditOpinion() {
        return exchangeManagefeeAuditOpinion;
    }

    public void setExchangeManagefeeAuditOpinion(String exchangeManagefeeAuditOpinion) {
        this.exchangeManagefeeAuditOpinion = exchangeManagefeeAuditOpinion;
    }

    public String getExchangeManagefeeClearOperator() {
        return exchangeManagefeeClearOperator;
    }

    public void setExchangeManagefeeClearOperator(String exchangeManagefeeClearOperator) {
        this.exchangeManagefeeClearOperator = exchangeManagefeeClearOperator;
    }

    public Date getExchangeManagefeeClearTime() {
        return exchangeManagefeeClearTime;
    }

    public void setExchangeManagefeeClearTime(Date exchangeManagefeeClearTime) {
        this.exchangeManagefeeClearTime = exchangeManagefeeClearTime;
    }

    public int getExchangeManagefeeClearStatus() {
        return exchangeManagefeeClearStatus;
    }

    public void setExchangeManagefeeClearStatus(int exchangeManagefeeClearStatus) {
        this.exchangeManagefeeClearStatus = exchangeManagefeeClearStatus;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public int getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(int deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public int getProductPeriod() {
        return productPeriod;
    }

    public void setProductPeriod(int productPeriod) {
        this.productPeriod = productPeriod;
    }

    public BigDecimal getProductScale() {
        return productScale;
    }

    public void setProductScale(BigDecimal productScale) {
        this.productScale = productScale;
    }

    public BigDecimal getProductAccumulation() {
        return productAccumulation;
    }

    public void setProductAccumulation(BigDecimal productAccumulation) {
        this.productAccumulation = productAccumulation;
    }

    public BigDecimal getPlatformCommission() {
        return platformCommission;
    }

    public void setPlatformCommission(BigDecimal platformCommission) {
        this.platformCommission = platformCommission;
    }

    public BigDecimal getManagementFee() {
        return managementFee;
    }

    public void setManagementFee(BigDecimal managementFee) {
        this.managementFee = managementFee;
    }

    public double getMarketingAmout() {
        return marketingAmout;
    }

    public void setMarketingAmout(double marketingAmout) {
        this.marketingAmout = marketingAmout;
    }

    public double getPretaxMarketingAmout() {
        return pretaxMarketingAmout;
    }

    public void setPretaxMarketingAmout(double pretaxMarketingAmout) {
        this.pretaxMarketingAmout = pretaxMarketingAmout;
    }

    public double getDeductionMarketingAmout() {
        return deductionMarketingAmout;
    }

    public void setDeductionMarketingAmout(double deductionMarketingAmout) {
        this.deductionMarketingAmout = deductionMarketingAmout;
    }

    public String getProductIssuerName() {
        return productIssuerName;
    }

    public void setProductIssuerName(String productIssuerName) {
        this.productIssuerName = productIssuerName;
    }

    public ProductRewardSummary get() {
        ProductRewardSummary productRewardSummary = new ProductRewardSummary();
        productRewardSummary.setProductRewardSummaryUuid(productRewardSummaryUuid);
        productRewardSummary.setProductUuid(productUuid);
        productRewardSummary.setProductCode(productCode);
        productRewardSummary.setProductAbbrName(productAbbrName);
        productRewardSummary.setProductType(productType);
        productRewardSummary.setProductEstablishmentDate(productEstablishmentDate);
        productRewardSummary.setRewardCount(rewardCount);
        productRewardSummary.setRewardClearCount(rewardClearCount);
        productRewardSummary.setFinancialAdvisorCount(financialAdvisorCount);
        productRewardSummary.setPretaxRewardAmount(new BigDecimal(pretaxRewardAmount));
        productRewardSummary.setPretaxPlatformServicefee(new BigDecimal(pretaxPlatformServicefee));
        productRewardSummary.setPlatformServicefeeTax(new BigDecimal(platformServicefeeTax));
        productRewardSummary.setAftertaxPlatformServicefee(new BigDecimal(aftertaxPlatformServicefee));
        productRewardSummary.setExchangeManageFee(new BigDecimal(exchangeManageFee));
        productRewardSummary.setPlatformIncome(new BigDecimal(platformIncome));
        productRewardSummary.setLoanTime(loanTime);
        productRewardSummary.setIncomeTaxAuditOperator(incomeTaxAuditOperator);
        productRewardSummary.setIncomeTaxAuditTime(incomeTaxAuditTime);
        productRewardSummary.setIncomeTaxAuditOpinion(incomeTaxAuditOpinion);
        productRewardSummary.setIncomeTaxClearOperator(incomeTaxClearOperator);
        productRewardSummary.setIncomeTaxClearTime(incomeTaxClearTime);
        productRewardSummary.setIncomeTaxClearStatus(new Integer(incomeTaxClearStatus).byteValue());
        productRewardSummary.setExchangeManagefeeAuditOperator(exchangeManagefeeAuditOperator);
        productRewardSummary.setExchangeManagefeeAuditTime(exchangeManagefeeAuditTime);
        productRewardSummary.setExchangeManagefeeAuditOpinion(exchangeManagefeeAuditOpinion);
        productRewardSummary.setExchangeManagefeeClearOperator(exchangeManagefeeClearOperator);
        productRewardSummary.setExchangeManagefeeClearTime(exchangeManagefeeClearTime);
        productRewardSummary.setExchangeManagefeeClearStatus(new Integer(exchangeManagefeeClearStatus).byteValue());
        productRewardSummary.setSignature(signature);
        productRewardSummary.setDeleteFlag(new Integer(deleteFlag).byteValue());
        productRewardSummary.setProductPeriod(productPeriod);
        productRewardSummary.setProductScale(productScale);
        productRewardSummary.setProductAccumulation(productAccumulation);
        productRewardSummary.setPlatformCommission(platformCommission);
        productRewardSummary.setManagementFee(managementFee);
        productRewardSummary.setCreateTime(createTime);
        productRewardSummary.setUpdateTime(updateTime);
        productRewardSummary.setProductIssuerName(productIssuerName);
        return productRewardSummary;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("productRewardSummaryUuid:" + DataUtils.toString(productRewardSummaryUuid) + ", ");
        sb.append("productUuid:" + DataUtils.toString(productUuid) + ", ");
        sb.append("productCode:" + DataUtils.toString(productCode) + ", ");
        sb.append("productAbbrName:" + DataUtils.toString(productAbbrName) + ", ");
        sb.append("productType:" + DataUtils.toString(productType) + ", ");
        sb.append("productEstablishmentDate:" + DataUtils.toString(productEstablishmentDate) + ", ");
        sb.append("rewardCount:" + DataUtils.toString(rewardCount) + ", ");
        sb.append("rewardClearCount:" + DataUtils.toString(rewardClearCount) + ", ");
        sb.append("financialAdvisorCount:" + DataUtils.toString(financialAdvisorCount) + ", ");
        sb.append("pretaxRewardAmount:" + DataUtils.toString(pretaxRewardAmount) + ", ");
        sb.append("pretaxPlatformServicefee:" + DataUtils.toString(pretaxPlatformServicefee) + ", ");
        sb.append("platformServicefeeTax:" + DataUtils.toString(platformServicefeeTax) + ", ");
        sb.append("aftertaxPlatformServicefee:" + DataUtils.toString(aftertaxPlatformServicefee) + ", ");
        sb.append("exchangeManageFee:" + DataUtils.toString(exchangeManageFee) + ", ");
        sb.append("platformIncome:" + DataUtils.toString(platformIncome) + ", ");
        sb.append("loanTime:" + DataUtils.toString(loanTime) + ", ");
        sb.append("incomeTaxAuditOperator:" + DataUtils.toString(incomeTaxAuditOperator) + ", ");
        sb.append("incomeTaxAuditTime:" + DataUtils.toString(incomeTaxAuditTime) + ", ");
        sb.append("incomeTaxAuditOpinion:" + DataUtils.toString(incomeTaxAuditOpinion) + ", ");
        sb.append("incomeTaxClearOperator:" + DataUtils.toString(incomeTaxClearOperator) + ", ");
        sb.append("incomeTaxClearTime:" + DataUtils.toString(incomeTaxClearTime) + ", ");
        sb.append("incomeTaxClearStatus:" + DataUtils.toString(incomeTaxClearStatus) + ", ");
        sb.append("exchangeManagefeeAuditOperator:" + DataUtils.toString(exchangeManagefeeAuditOperator) + ", ");
        sb.append("exchangeManagefeeAuditTime:" + DataUtils.toString(exchangeManagefeeAuditTime) + ", ");
        sb.append("exchangeManagefeeAuditOpinion:" + DataUtils.toString(exchangeManagefeeAuditOpinion) + ", ");
        sb.append("exchangeManagefeeClearOperator:" + DataUtils.toString(exchangeManagefeeClearOperator) + ", ");
        sb.append("exchangeManagefeeClearTime:" + DataUtils.toString(exchangeManagefeeClearTime) + ", ");
        sb.append("exchangeManagefeeClearStatus:" + DataUtils.toString(exchangeManagefeeClearStatus) + ", ");
        sb.append("signature:" + DataUtils.toString(signature) + ", ");
        sb.append("deleteFlag:" + DataUtils.toString(deleteFlag) + ", ");
        sb.append("productPeriod:" + DataUtils.toString(productPeriod) + ", ");
        sb.append("productScale:" + DataUtils.toString(productScale) + ", ");
        sb.append("productAccumulation:" + DataUtils.toString(productAccumulation) + ", ");
        sb.append("platformCommission:" + DataUtils.toString(platformCommission) + ", ");
        sb.append("managementFee:" + DataUtils.toString(managementFee) + ", ");
        sb.append("createTime:" + DataUtils.toString(createTime) + ", ");
        sb.append("productIssuerName:" + DataUtils.toString(productIssuerName) + ", ");
        sb.append("updateTime:" + DataUtils.toString(updateTime));
        return sb.toString();
    }
}
