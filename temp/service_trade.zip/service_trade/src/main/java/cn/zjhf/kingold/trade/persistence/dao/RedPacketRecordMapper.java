package cn.zjhf.kingold.trade.persistence.dao;

import cn.zjhf.kingold.trade.entity.InVO.LstRedPacketConditionVO;
import cn.zjhf.kingold.trade.entity.RedPacketRecord;
import cn.zjhf.kingold.trade.entity.RedPacketRecordExample;
import java.util.List;

import cn.zjhf.kingold.trade.utils.QueryUtils;
import cn.zjhf.kingold.trade.utils.WhereCondition;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface RedPacketRecordMapper {
    long countByExample(RedPacketRecordExample example);

    int deleteByExample(RedPacketRecordExample example);

    int deleteByPrimaryKey(Long id);

    int insert(RedPacketRecord record);

    @Insert("${condition}")
    int deleteRecord(QueryUtils condition);

    @Insert("${condition}")
    int insertMultipleRecord(QueryUtils condition);

    @Select("SELECT Count(*) FROM red_packet_record " +
            " WHERE audit_id=#{auditId} AND receive_status=#{receiveStatus} ")
    int lstCountByAuditId(@Param("auditId") Long auditId, @Param("receiveStatus") int receiveStatus);

    @Update("UPDATE red_packet_record SET remarks=#{remarks} WHERE audit_id=#{auditId}")
    int updateRemarks(@Param("remarks") String remarks, @Param("auditId") Long auditId);

    @Update("UPDATE red_packet_record SET receive_status=2, receive_time=now(), receive_mess='' " +
            "WHERE id=#{redPacketId} AND user_uuid=#{userUuid} " +
            "AND receive_status=1 AND delete_flag=0")
    int drawRedPacket(@Param("userUuid") String userUuid, @Param("redPacketId") Long redPacketId);

    @Update("UPDATE red_packet_record SET receive_mess=#{receiveMess} " +
            "WHERE id=#{redPacketId} AND receive_status=1 AND delete_flag=0")
    int drawRedPacketFail(@Param("redPacketId") Long redPacketId, @Param("receiveMess") String receiveMess);

    @Update("UPDATE red_packet_record SET phone_name=#{userName} " +
            "WHERE id=#{redPacketId} ")
    int updateInvestorName(@Param("redPacketId") Long redPacketId, @Param("userName") String userName);

    @Select("SELECT * FROM red_packet_record ${condition}")
    @ResultMap("BaseResultMap")
    List<RedPacketRecord> lstByCondition(WhereCondition condition);

    int insertSelective(RedPacketRecord record);

    List<RedPacketRecord> selectByExample(RedPacketRecordExample example);

    RedPacketRecord selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") RedPacketRecord record, @Param("example") RedPacketRecordExample example);

    int updateByExample(@Param("record") RedPacketRecord record, @Param("example") RedPacketRecordExample example);

    int updateByPrimaryKeySelective(RedPacketRecord record);

    int updateByPrimaryKey(RedPacketRecord record);

    int countRedPacketRecord(LstRedPacketConditionVO lstCondition);

    Double totalRedPacketRecord(LstRedPacketConditionVO lstCondition);

}