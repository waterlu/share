package cn.zjhf.kingold.trade.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author 
 */
public class Account implements Serializable {
    /**
     * JGG账户UUID
     */
    private String accountUuid;

    /**
     * 宝付账户账号
     */
    private long accountNo;

    /**
     * 用户UUID
     */
    private String userUuid;

    /**
     * 账户类型（层级编码）：11平台托管账户；12平台结算账户；21投资人宝付托管账户；31融资人宝付托管账户；41宝付清算账户；99平台费用账户；
     */
    private String accountType;

    /**
     * 账户状态：1正常；2冻结；3注销；4暂停使用
     */
    private Byte accountStatus;

    /**
     * 开户日期
     */
    private Date createTime;

    /**
     * 开户渠道，1 app, 2 官网，3 内部
     */
    private Integer openChannel;

    /**
     * 账户总资产
     */
    private BigDecimal accountTotalAssets;

    /**
     * 账户可用余额
     */
    private BigDecimal accountCashAmount;

    /**
     * 账户投资金额
     */
    private BigDecimal accountInveAmount;

    /**
     * 账户未兑付产品收益
     */
    private BigDecimal accountUnpaidProfit;

    /**
     * 账户未兑付活期利息，不确定，建议先不加
     */
    private BigDecimal accountUnpaidInterest;

    /**
     * 账户冻结金额
     */
    private BigDecimal accountFreezeAmount;

    /**
     * 账户在途资金
     */
    private BigDecimal accountTransitAmount;

    /**
     * 账户累计收益，包括分红
     */
    private BigDecimal accountAccumProfit;

    /**
     * 账户已兑付收益
     */
    private BigDecimal accountPaidProfit;

    /**
     * 昨日收益
     */
    private BigDecimal accountYesterdayProfit;

    /**
     * 佣金累计
     */
    private BigDecimal accountCommission;

    /**
     * 理财佣金
     */
    private BigDecimal accountFinaCommission;

    /**
     * 1度邀请奖励
     */
    private BigDecimal accountInviBonus1;

    /**
     * 2度邀请奖励
     */
    private BigDecimal accountInviBonus2;

    /**
     * 签名
     */
    private String signature;

    private Byte deleteFlag;

    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public String getAccountUuid() {
        return accountUuid;
    }

    public void setAccountUuid(String accountUuid) {
        this.accountUuid = accountUuid;
    }

    public long getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(long accountNo) {
        this.accountNo = accountNo;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public Byte getAccountStatus() {
        return accountStatus;
    }

    public void setAccountStatus(Byte accountStatus) {
        this.accountStatus = accountStatus;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getOpenChannel() {
        return openChannel;
    }

    public void setOpenChannel(Integer openChannel) {
        this.openChannel = openChannel;
    }

    public BigDecimal getAccountTotalAssets() {
        return accountTotalAssets;
    }

    public void setAccountTotalAssets(BigDecimal accountTotalAssets) {
        this.accountTotalAssets = accountTotalAssets;
    }

    public BigDecimal getAccountCashAmount() {
        return accountCashAmount;
    }

    public void setAccountCashAmount(BigDecimal accountCashAmount) {
        this.accountCashAmount = accountCashAmount;
    }

    public BigDecimal getAccountInveAmount() {
        return accountInveAmount;
    }

    public void setAccountInveAmount(BigDecimal accountInveAmount) {
        this.accountInveAmount = accountInveAmount;
    }

    public BigDecimal getAccountUnpaidProfit() {
        return accountUnpaidProfit;
    }

    public void setAccountUnpaidProfit(BigDecimal accountUnpaidProfit) {
        this.accountUnpaidProfit = accountUnpaidProfit;
    }

    public BigDecimal getAccountUnpaidInterest() {
        return accountUnpaidInterest;
    }

    public void setAccountUnpaidInterest(BigDecimal accountUnpaidInterest) {
        this.accountUnpaidInterest = accountUnpaidInterest;
    }

    public BigDecimal getAccountFreezeAmount() {
        return accountFreezeAmount;
    }

    public void setAccountFreezeAmount(BigDecimal accountFreezeAmount) {
        this.accountFreezeAmount = accountFreezeAmount;
    }

    public BigDecimal getAccountTransitAmount() {
        return accountTransitAmount;
    }

    public void setAccountTransitAmount(BigDecimal accountTransitAmount) {
        this.accountTransitAmount = accountTransitAmount;
    }

    public BigDecimal getAccountAccumProfit() {
        return accountAccumProfit;
    }

    public void setAccountAccumProfit(BigDecimal accountAccumProfit) {
        this.accountAccumProfit = accountAccumProfit;
    }

    public BigDecimal getAccountPaidProfit() {
        return accountPaidProfit;
    }

    public void setAccountPaidProfit(BigDecimal accountPaidProfit) {
        this.accountPaidProfit = accountPaidProfit;
    }

    public BigDecimal getAccountYesterdayProfit() {
        return accountYesterdayProfit;
    }

    public void setAccountYesterdayProfit(BigDecimal accountYesterdayProfit) {
        this.accountYesterdayProfit = accountYesterdayProfit;
    }

    public BigDecimal getAccountCommission() {
        return accountCommission;
    }

    public void setAccountCommission(BigDecimal accountCommission) {
        this.accountCommission = accountCommission;
    }

    public BigDecimal getAccountFinaCommission() {
        return accountFinaCommission;
    }

    public void setAccountFinaCommission(BigDecimal accountFinaCommission) {
        this.accountFinaCommission = accountFinaCommission;
    }

    public BigDecimal getAccountInviBonus1() {
        return accountInviBonus1;
    }

    public void setAccountInviBonus1(BigDecimal accountInviBonus1) {
        this.accountInviBonus1 = accountInviBonus1;
    }

    public BigDecimal getAccountInviBonus2() {
        return accountInviBonus2;
    }

    public void setAccountInviBonus2(BigDecimal accountInviBonus2) {
        this.accountInviBonus2 = accountInviBonus2;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}