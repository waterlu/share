package cn.zjhf.kingold.trade.constant;

/**
 * 奖励状态
 *
 * Created by lutiehua on 2017/5/27.
 */
public interface RewardStatus {

    /**
     * 初始状态（钱不一定给）
     *
     */
    int INIT = 0;

    /**
     * 未结算（钱可以给，但是还没到账）
     *
     */
    int UNPAID = 1;


    /**
     * 已结算（钱已经到账）
     *
     */
    int PAID = 2;

}
