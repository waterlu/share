package cn.zjhf.kingold.trade.exception;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.constant.TradeStatusMsg;

/**
 * 订单已经支付成功
 *
 * @author lutiehua
 * @date 2018/3/9
 */
public class OrderPayAgainException extends BusinessException {

    public OrderPayAgainException() {
        super(TradeStatusMsg.PAID_ORDER, TradeStatusMsg.PAID_ORDER_MSG, true);
    }
}
