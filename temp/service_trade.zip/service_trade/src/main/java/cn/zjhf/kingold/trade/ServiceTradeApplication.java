package cn.zjhf.kingold.trade;

import cn.zjhf.kingold.rocketmq.annotation.EnableRocketMQConfiguration;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.cloud.client.SpringCloudApplication;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;

/**
 * 应用程序入口
 *
 * @author lutiehua
 * @date 2017/4/17
 *
 */
@EnableFeignClients
@EnableHystrix
@SpringCloudApplication
@MapperScan("cn.zjhf.kingold.trade.persistence.dao")
@EnableRocketMQConfiguration
public class ServiceTradeApplication{

	public static void main(String[] args) {
		SpringApplication.run(ServiceTradeApplication.class, args);
	}
}
