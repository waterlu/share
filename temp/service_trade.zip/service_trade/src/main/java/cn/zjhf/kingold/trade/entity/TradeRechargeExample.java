package cn.zjhf.kingold.trade.entity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TradeRechargeExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public TradeRechargeExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andTradeRechargeUuidIsNull() {
            addCriterion("trade_recharge_uuid is null");
            return (Criteria) this;
        }

        public Criteria andTradeRechargeUuidIsNotNull() {
            addCriterion("trade_recharge_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andTradeRechargeUuidEqualTo(String value) {
            addCriterion("trade_recharge_uuid =", value, "tradeRechargeUuid");
            return (Criteria) this;
        }

        public Criteria andTradeRechargeUuidNotEqualTo(String value) {
            addCriterion("trade_recharge_uuid <>", value, "tradeRechargeUuid");
            return (Criteria) this;
        }

        public Criteria andTradeRechargeUuidGreaterThan(String value) {
            addCriterion("trade_recharge_uuid >", value, "tradeRechargeUuid");
            return (Criteria) this;
        }

        public Criteria andTradeRechargeUuidGreaterThanOrEqualTo(String value) {
            addCriterion("trade_recharge_uuid >=", value, "tradeRechargeUuid");
            return (Criteria) this;
        }

        public Criteria andTradeRechargeUuidLessThan(String value) {
            addCriterion("trade_recharge_uuid <", value, "tradeRechargeUuid");
            return (Criteria) this;
        }

        public Criteria andTradeRechargeUuidLessThanOrEqualTo(String value) {
            addCriterion("trade_recharge_uuid <=", value, "tradeRechargeUuid");
            return (Criteria) this;
        }

        public Criteria andTradeRechargeUuidLike(String value) {
            addCriterion("trade_recharge_uuid like", value, "tradeRechargeUuid");
            return (Criteria) this;
        }

        public Criteria andTradeRechargeUuidNotLike(String value) {
            addCriterion("trade_recharge_uuid not like", value, "tradeRechargeUuid");
            return (Criteria) this;
        }

        public Criteria andTradeRechargeUuidIn(List<String> values) {
            addCriterion("trade_recharge_uuid in", values, "tradeRechargeUuid");
            return (Criteria) this;
        }

        public Criteria andTradeRechargeUuidNotIn(List<String> values) {
            addCriterion("trade_recharge_uuid not in", values, "tradeRechargeUuid");
            return (Criteria) this;
        }

        public Criteria andTradeRechargeUuidBetween(String value1, String value2) {
            addCriterion("trade_recharge_uuid between", value1, value2, "tradeRechargeUuid");
            return (Criteria) this;
        }

        public Criteria andTradeRechargeUuidNotBetween(String value1, String value2) {
            addCriterion("trade_recharge_uuid not between", value1, value2, "tradeRechargeUuid");
            return (Criteria) this;
        }

        public Criteria andRechargeBillCodeIsNull() {
            addCriterion("recharge_bill_code is null");
            return (Criteria) this;
        }

        public Criteria andRechargeBillCodeIsNotNull() {
            addCriterion("recharge_bill_code is not null");
            return (Criteria) this;
        }

        public Criteria andRechargeBillCodeEqualTo(String value) {
            addCriterion("recharge_bill_code =", value, "rechargeBillCode");
            return (Criteria) this;
        }

        public Criteria andRechargeBillCodeNotEqualTo(String value) {
            addCriterion("recharge_bill_code <>", value, "rechargeBillCode");
            return (Criteria) this;
        }

        public Criteria andRechargeBillCodeGreaterThan(String value) {
            addCriterion("recharge_bill_code >", value, "rechargeBillCode");
            return (Criteria) this;
        }

        public Criteria andRechargeBillCodeGreaterThanOrEqualTo(String value) {
            addCriterion("recharge_bill_code >=", value, "rechargeBillCode");
            return (Criteria) this;
        }

        public Criteria andRechargeBillCodeLessThan(String value) {
            addCriterion("recharge_bill_code <", value, "rechargeBillCode");
            return (Criteria) this;
        }

        public Criteria andRechargeBillCodeLessThanOrEqualTo(String value) {
            addCriterion("recharge_bill_code <=", value, "rechargeBillCode");
            return (Criteria) this;
        }

        public Criteria andRechargeBillCodeLike(String value) {
            addCriterion("recharge_bill_code like", value, "rechargeBillCode");
            return (Criteria) this;
        }

        public Criteria andRechargeBillCodeNotLike(String value) {
            addCriterion("recharge_bill_code not like", value, "rechargeBillCode");
            return (Criteria) this;
        }

        public Criteria andRechargeBillCodeIn(List<String> values) {
            addCriterion("recharge_bill_code in", values, "rechargeBillCode");
            return (Criteria) this;
        }

        public Criteria andRechargeBillCodeNotIn(List<String> values) {
            addCriterion("recharge_bill_code not in", values, "rechargeBillCode");
            return (Criteria) this;
        }

        public Criteria andRechargeBillCodeBetween(String value1, String value2) {
            addCriterion("recharge_bill_code between", value1, value2, "rechargeBillCode");
            return (Criteria) this;
        }

        public Criteria andRechargeBillCodeNotBetween(String value1, String value2) {
            addCriterion("recharge_bill_code not between", value1, value2, "rechargeBillCode");
            return (Criteria) this;
        }

        public Criteria andRechargeBillTypeIsNull() {
            addCriterion("recharge_bill_type is null");
            return (Criteria) this;
        }

        public Criteria andRechargeBillTypeIsNotNull() {
            addCriterion("recharge_bill_type is not null");
            return (Criteria) this;
        }

        public Criteria andRechargeBillTypeEqualTo(String value) {
            addCriterion("recharge_bill_type =", value, "rechargeBillType");
            return (Criteria) this;
        }

        public Criteria andRechargeBillTypeNotEqualTo(String value) {
            addCriterion("recharge_bill_type <>", value, "rechargeBillType");
            return (Criteria) this;
        }

        public Criteria andRechargeBillTypeGreaterThan(String value) {
            addCriterion("recharge_bill_type >", value, "rechargeBillType");
            return (Criteria) this;
        }

        public Criteria andRechargeBillTypeGreaterThanOrEqualTo(String value) {
            addCriterion("recharge_bill_type >=", value, "rechargeBillType");
            return (Criteria) this;
        }

        public Criteria andRechargeBillTypeLessThan(String value) {
            addCriterion("recharge_bill_type <", value, "rechargeBillType");
            return (Criteria) this;
        }

        public Criteria andRechargeBillTypeLessThanOrEqualTo(String value) {
            addCriterion("recharge_bill_type <=", value, "rechargeBillType");
            return (Criteria) this;
        }

        public Criteria andRechargeBillTypeLike(String value) {
            addCriterion("recharge_bill_type like", value, "rechargeBillType");
            return (Criteria) this;
        }

        public Criteria andRechargeBillTypeNotLike(String value) {
            addCriterion("recharge_bill_type not like", value, "rechargeBillType");
            return (Criteria) this;
        }

        public Criteria andRechargeBillTypeIn(List<String> values) {
            addCriterion("recharge_bill_type in", values, "rechargeBillType");
            return (Criteria) this;
        }

        public Criteria andRechargeBillTypeNotIn(List<String> values) {
            addCriterion("recharge_bill_type not in", values, "rechargeBillType");
            return (Criteria) this;
        }

        public Criteria andRechargeBillTypeBetween(String value1, String value2) {
            addCriterion("recharge_bill_type between", value1, value2, "rechargeBillType");
            return (Criteria) this;
        }

        public Criteria andRechargeBillTypeNotBetween(String value1, String value2) {
            addCriterion("recharge_bill_type not between", value1, value2, "rechargeBillType");
            return (Criteria) this;
        }

        public Criteria andUserUuidIsNull() {
            addCriterion("user_uuid is null");
            return (Criteria) this;
        }

        public Criteria andUserUuidIsNotNull() {
            addCriterion("user_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andUserUuidEqualTo(String value) {
            addCriterion("user_uuid =", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidNotEqualTo(String value) {
            addCriterion("user_uuid <>", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidGreaterThan(String value) {
            addCriterion("user_uuid >", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidGreaterThanOrEqualTo(String value) {
            addCriterion("user_uuid >=", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidLessThan(String value) {
            addCriterion("user_uuid <", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidLessThanOrEqualTo(String value) {
            addCriterion("user_uuid <=", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidLike(String value) {
            addCriterion("user_uuid like", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidNotLike(String value) {
            addCriterion("user_uuid not like", value, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidIn(List<String> values) {
            addCriterion("user_uuid in", values, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidNotIn(List<String> values) {
            addCriterion("user_uuid not in", values, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidBetween(String value1, String value2) {
            addCriterion("user_uuid between", value1, value2, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserUuidNotBetween(String value1, String value2) {
            addCriterion("user_uuid not between", value1, value2, "userUuid");
            return (Criteria) this;
        }

        public Criteria andUserPhoneIsNull() {
            addCriterion("user_phone is null");
            return (Criteria) this;
        }

        public Criteria andUserPhoneIsNotNull() {
            addCriterion("user_phone is not null");
            return (Criteria) this;
        }

        public Criteria andUserPhoneEqualTo(String value) {
            addCriterion("user_phone =", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNotEqualTo(String value) {
            addCriterion("user_phone <>", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneGreaterThan(String value) {
            addCriterion("user_phone >", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneGreaterThanOrEqualTo(String value) {
            addCriterion("user_phone >=", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneLessThan(String value) {
            addCriterion("user_phone <", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneLessThanOrEqualTo(String value) {
            addCriterion("user_phone <=", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneLike(String value) {
            addCriterion("user_phone like", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNotLike(String value) {
            addCriterion("user_phone not like", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneIn(List<String> values) {
            addCriterion("user_phone in", values, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNotIn(List<String> values) {
            addCriterion("user_phone not in", values, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneBetween(String value1, String value2) {
            addCriterion("user_phone between", value1, value2, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNotBetween(String value1, String value2) {
            addCriterion("user_phone not between", value1, value2, "userPhone");
            return (Criteria) this;
        }

        public Criteria andAccountUuidIsNull() {
            addCriterion("account_uuid is null");
            return (Criteria) this;
        }

        public Criteria andAccountUuidIsNotNull() {
            addCriterion("account_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andAccountUuidEqualTo(String value) {
            addCriterion("account_uuid =", value, "accountUuid");
            return (Criteria) this;
        }

        public Criteria andAccountUuidNotEqualTo(String value) {
            addCriterion("account_uuid <>", value, "accountUuid");
            return (Criteria) this;
        }

        public Criteria andAccountUuidGreaterThan(String value) {
            addCriterion("account_uuid >", value, "accountUuid");
            return (Criteria) this;
        }

        public Criteria andAccountUuidGreaterThanOrEqualTo(String value) {
            addCriterion("account_uuid >=", value, "accountUuid");
            return (Criteria) this;
        }

        public Criteria andAccountUuidLessThan(String value) {
            addCriterion("account_uuid <", value, "accountUuid");
            return (Criteria) this;
        }

        public Criteria andAccountUuidLessThanOrEqualTo(String value) {
            addCriterion("account_uuid <=", value, "accountUuid");
            return (Criteria) this;
        }

        public Criteria andAccountUuidLike(String value) {
            addCriterion("account_uuid like", value, "accountUuid");
            return (Criteria) this;
        }

        public Criteria andAccountUuidNotLike(String value) {
            addCriterion("account_uuid not like", value, "accountUuid");
            return (Criteria) this;
        }

        public Criteria andAccountUuidIn(List<String> values) {
            addCriterion("account_uuid in", values, "accountUuid");
            return (Criteria) this;
        }

        public Criteria andAccountUuidNotIn(List<String> values) {
            addCriterion("account_uuid not in", values, "accountUuid");
            return (Criteria) this;
        }

        public Criteria andAccountUuidBetween(String value1, String value2) {
            addCriterion("account_uuid between", value1, value2, "accountUuid");
            return (Criteria) this;
        }

        public Criteria andAccountUuidNotBetween(String value1, String value2) {
            addCriterion("account_uuid not between", value1, value2, "accountUuid");
            return (Criteria) this;
        }

        public Criteria andAgencyIsNull() {
            addCriterion("agency is null");
            return (Criteria) this;
        }

        public Criteria andAgencyIsNotNull() {
            addCriterion("agency is not null");
            return (Criteria) this;
        }

        public Criteria andAgencyEqualTo(String value) {
            addCriterion("agency =", value, "agency");
            return (Criteria) this;
        }

        public Criteria andAgencyNotEqualTo(String value) {
            addCriterion("agency <>", value, "agency");
            return (Criteria) this;
        }

        public Criteria andAgencyGreaterThan(String value) {
            addCriterion("agency >", value, "agency");
            return (Criteria) this;
        }

        public Criteria andAgencyGreaterThanOrEqualTo(String value) {
            addCriterion("agency >=", value, "agency");
            return (Criteria) this;
        }

        public Criteria andAgencyLessThan(String value) {
            addCriterion("agency <", value, "agency");
            return (Criteria) this;
        }

        public Criteria andAgencyLessThanOrEqualTo(String value) {
            addCriterion("agency <=", value, "agency");
            return (Criteria) this;
        }

        public Criteria andAgencyLike(String value) {
            addCriterion("agency like", value, "agency");
            return (Criteria) this;
        }

        public Criteria andAgencyNotLike(String value) {
            addCriterion("agency not like", value, "agency");
            return (Criteria) this;
        }

        public Criteria andAgencyIn(List<String> values) {
            addCriterion("agency in", values, "agency");
            return (Criteria) this;
        }

        public Criteria andAgencyNotIn(List<String> values) {
            addCriterion("agency not in", values, "agency");
            return (Criteria) this;
        }

        public Criteria andAgencyBetween(String value1, String value2) {
            addCriterion("agency between", value1, value2, "agency");
            return (Criteria) this;
        }

        public Criteria andAgencyNotBetween(String value1, String value2) {
            addCriterion("agency not between", value1, value2, "agency");
            return (Criteria) this;
        }

        public Criteria andAgencyAccountNoIsNull() {
            addCriterion("agency_account_no is null");
            return (Criteria) this;
        }

        public Criteria andAgencyAccountNoIsNotNull() {
            addCriterion("agency_account_no is not null");
            return (Criteria) this;
        }

        public Criteria andAgencyAccountNoEqualTo(String value) {
            addCriterion("agency_account_no =", value, "agencyAccountNo");
            return (Criteria) this;
        }

        public Criteria andAgencyAccountNoNotEqualTo(String value) {
            addCriterion("agency_account_no <>", value, "agencyAccountNo");
            return (Criteria) this;
        }

        public Criteria andAgencyAccountNoGreaterThan(String value) {
            addCriterion("agency_account_no >", value, "agencyAccountNo");
            return (Criteria) this;
        }

        public Criteria andAgencyAccountNoGreaterThanOrEqualTo(String value) {
            addCriterion("agency_account_no >=", value, "agencyAccountNo");
            return (Criteria) this;
        }

        public Criteria andAgencyAccountNoLessThan(String value) {
            addCriterion("agency_account_no <", value, "agencyAccountNo");
            return (Criteria) this;
        }

        public Criteria andAgencyAccountNoLessThanOrEqualTo(String value) {
            addCriterion("agency_account_no <=", value, "agencyAccountNo");
            return (Criteria) this;
        }

        public Criteria andAgencyAccountNoLike(String value) {
            addCriterion("agency_account_no like", value, "agencyAccountNo");
            return (Criteria) this;
        }

        public Criteria andAgencyAccountNoNotLike(String value) {
            addCriterion("agency_account_no not like", value, "agencyAccountNo");
            return (Criteria) this;
        }

        public Criteria andAgencyAccountNoIn(List<String> values) {
            addCriterion("agency_account_no in", values, "agencyAccountNo");
            return (Criteria) this;
        }

        public Criteria andAgencyAccountNoNotIn(List<String> values) {
            addCriterion("agency_account_no not in", values, "agencyAccountNo");
            return (Criteria) this;
        }

        public Criteria andAgencyAccountNoBetween(String value1, String value2) {
            addCriterion("agency_account_no between", value1, value2, "agencyAccountNo");
            return (Criteria) this;
        }

        public Criteria andAgencyAccountNoNotBetween(String value1, String value2) {
            addCriterion("agency_account_no not between", value1, value2, "agencyAccountNo");
            return (Criteria) this;
        }

        public Criteria andBankAccountNoIsNull() {
            addCriterion("bank_account_no is null");
            return (Criteria) this;
        }

        public Criteria andBankAccountNoIsNotNull() {
            addCriterion("bank_account_no is not null");
            return (Criteria) this;
        }

        public Criteria andBankAccountNoEqualTo(String value) {
            addCriterion("bank_account_no =", value, "bankAccountNo");
            return (Criteria) this;
        }

        public Criteria andBankAccountNoNotEqualTo(String value) {
            addCriterion("bank_account_no <>", value, "bankAccountNo");
            return (Criteria) this;
        }

        public Criteria andBankAccountNoGreaterThan(String value) {
            addCriterion("bank_account_no >", value, "bankAccountNo");
            return (Criteria) this;
        }

        public Criteria andBankAccountNoGreaterThanOrEqualTo(String value) {
            addCriterion("bank_account_no >=", value, "bankAccountNo");
            return (Criteria) this;
        }

        public Criteria andBankAccountNoLessThan(String value) {
            addCriterion("bank_account_no <", value, "bankAccountNo");
            return (Criteria) this;
        }

        public Criteria andBankAccountNoLessThanOrEqualTo(String value) {
            addCriterion("bank_account_no <=", value, "bankAccountNo");
            return (Criteria) this;
        }

        public Criteria andBankAccountNoLike(String value) {
            addCriterion("bank_account_no like", value, "bankAccountNo");
            return (Criteria) this;
        }

        public Criteria andBankAccountNoNotLike(String value) {
            addCriterion("bank_account_no not like", value, "bankAccountNo");
            return (Criteria) this;
        }

        public Criteria andBankAccountNoIn(List<String> values) {
            addCriterion("bank_account_no in", values, "bankAccountNo");
            return (Criteria) this;
        }

        public Criteria andBankAccountNoNotIn(List<String> values) {
            addCriterion("bank_account_no not in", values, "bankAccountNo");
            return (Criteria) this;
        }

        public Criteria andBankAccountNoBetween(String value1, String value2) {
            addCriterion("bank_account_no between", value1, value2, "bankAccountNo");
            return (Criteria) this;
        }

        public Criteria andBankAccountNoNotBetween(String value1, String value2) {
            addCriterion("bank_account_no not between", value1, value2, "bankAccountNo");
            return (Criteria) this;
        }

        public Criteria andRechargeAmountIsNull() {
            addCriterion("recharge_amount is null");
            return (Criteria) this;
        }

        public Criteria andRechargeAmountIsNotNull() {
            addCriterion("recharge_amount is not null");
            return (Criteria) this;
        }

        public Criteria andRechargeAmountEqualTo(BigDecimal value) {
            addCriterion("recharge_amount =", value, "rechargeAmount");
            return (Criteria) this;
        }

        public Criteria andRechargeAmountNotEqualTo(BigDecimal value) {
            addCriterion("recharge_amount <>", value, "rechargeAmount");
            return (Criteria) this;
        }

        public Criteria andRechargeAmountGreaterThan(BigDecimal value) {
            addCriterion("recharge_amount >", value, "rechargeAmount");
            return (Criteria) this;
        }

        public Criteria andRechargeAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("recharge_amount >=", value, "rechargeAmount");
            return (Criteria) this;
        }

        public Criteria andRechargeAmountLessThan(BigDecimal value) {
            addCriterion("recharge_amount <", value, "rechargeAmount");
            return (Criteria) this;
        }

        public Criteria andRechargeAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("recharge_amount <=", value, "rechargeAmount");
            return (Criteria) this;
        }

        public Criteria andRechargeAmountIn(List<BigDecimal> values) {
            addCriterion("recharge_amount in", values, "rechargeAmount");
            return (Criteria) this;
        }

        public Criteria andRechargeAmountNotIn(List<BigDecimal> values) {
            addCriterion("recharge_amount not in", values, "rechargeAmount");
            return (Criteria) this;
        }

        public Criteria andRechargeAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("recharge_amount between", value1, value2, "rechargeAmount");
            return (Criteria) this;
        }

        public Criteria andRechargeAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("recharge_amount not between", value1, value2, "rechargeAmount");
            return (Criteria) this;
        }

        public Criteria andRechargeStatusIsNull() {
            addCriterion("recharge_status is null");
            return (Criteria) this;
        }

        public Criteria andRechargeStatusIsNotNull() {
            addCriterion("recharge_status is not null");
            return (Criteria) this;
        }

        public Criteria andRechargeStatusEqualTo(Byte value) {
            addCriterion("recharge_status =", value, "rechargeStatus");
            return (Criteria) this;
        }

        public Criteria andRechargeStatusNotEqualTo(Byte value) {
            addCriterion("recharge_status <>", value, "rechargeStatus");
            return (Criteria) this;
        }

        public Criteria andRechargeStatusGreaterThan(Byte value) {
            addCriterion("recharge_status >", value, "rechargeStatus");
            return (Criteria) this;
        }

        public Criteria andRechargeStatusGreaterThanOrEqualTo(Byte value) {
            addCriterion("recharge_status >=", value, "rechargeStatus");
            return (Criteria) this;
        }

        public Criteria andRechargeStatusLessThan(Byte value) {
            addCriterion("recharge_status <", value, "rechargeStatus");
            return (Criteria) this;
        }

        public Criteria andRechargeStatusLessThanOrEqualTo(Byte value) {
            addCriterion("recharge_status <=", value, "rechargeStatus");
            return (Criteria) this;
        }

        public Criteria andRechargeStatusIn(List<Byte> values) {
            addCriterion("recharge_status in", values, "rechargeStatus");
            return (Criteria) this;
        }

        public Criteria andRechargeStatusNotIn(List<Byte> values) {
            addCriterion("recharge_status not in", values, "rechargeStatus");
            return (Criteria) this;
        }

        public Criteria andRechargeStatusBetween(Byte value1, Byte value2) {
            addCriterion("recharge_status between", value1, value2, "rechargeStatus");
            return (Criteria) this;
        }

        public Criteria andRechargeStatusNotBetween(Byte value1, Byte value2) {
            addCriterion("recharge_status not between", value1, value2, "rechargeStatus");
            return (Criteria) this;
        }

        public Criteria andPayMethodIsNull() {
            addCriterion("pay_method is null");
            return (Criteria) this;
        }

        public Criteria andPayMethodIsNotNull() {
            addCriterion("pay_method is not null");
            return (Criteria) this;
        }

        public Criteria andPayMethodEqualTo(Byte value) {
            addCriterion("pay_method =", value, "payMethod");
            return (Criteria) this;
        }

        public Criteria andPayMethodNotEqualTo(Byte value) {
            addCriterion("pay_method <>", value, "payMethod");
            return (Criteria) this;
        }

        public Criteria andPayMethodGreaterThan(Byte value) {
            addCriterion("pay_method >", value, "payMethod");
            return (Criteria) this;
        }

        public Criteria andPayMethodGreaterThanOrEqualTo(Byte value) {
            addCriterion("pay_method >=", value, "payMethod");
            return (Criteria) this;
        }

        public Criteria andPayMethodLessThan(Byte value) {
            addCriterion("pay_method <", value, "payMethod");
            return (Criteria) this;
        }

        public Criteria andPayMethodLessThanOrEqualTo(Byte value) {
            addCriterion("pay_method <=", value, "payMethod");
            return (Criteria) this;
        }

        public Criteria andPayMethodIn(List<Byte> values) {
            addCriterion("pay_method in", values, "payMethod");
            return (Criteria) this;
        }

        public Criteria andPayMethodNotIn(List<Byte> values) {
            addCriterion("pay_method not in", values, "payMethod");
            return (Criteria) this;
        }

        public Criteria andPayMethodBetween(Byte value1, Byte value2) {
            addCriterion("pay_method between", value1, value2, "payMethod");
            return (Criteria) this;
        }

        public Criteria andPayMethodNotBetween(Byte value1, Byte value2) {
            addCriterion("pay_method not between", value1, value2, "payMethod");
            return (Criteria) this;
        }

        public Criteria andRechargeRemarkIsNull() {
            addCriterion("recharge_remark is null");
            return (Criteria) this;
        }

        public Criteria andRechargeRemarkIsNotNull() {
            addCriterion("recharge_remark is not null");
            return (Criteria) this;
        }

        public Criteria andRechargeRemarkEqualTo(String value) {
            addCriterion("recharge_remark =", value, "rechargeRemark");
            return (Criteria) this;
        }

        public Criteria andRechargeRemarkNotEqualTo(String value) {
            addCriterion("recharge_remark <>", value, "rechargeRemark");
            return (Criteria) this;
        }

        public Criteria andRechargeRemarkGreaterThan(String value) {
            addCriterion("recharge_remark >", value, "rechargeRemark");
            return (Criteria) this;
        }

        public Criteria andRechargeRemarkGreaterThanOrEqualTo(String value) {
            addCriterion("recharge_remark >=", value, "rechargeRemark");
            return (Criteria) this;
        }

        public Criteria andRechargeRemarkLessThan(String value) {
            addCriterion("recharge_remark <", value, "rechargeRemark");
            return (Criteria) this;
        }

        public Criteria andRechargeRemarkLessThanOrEqualTo(String value) {
            addCriterion("recharge_remark <=", value, "rechargeRemark");
            return (Criteria) this;
        }

        public Criteria andRechargeRemarkLike(String value) {
            addCriterion("recharge_remark like", value, "rechargeRemark");
            return (Criteria) this;
        }

        public Criteria andRechargeRemarkNotLike(String value) {
            addCriterion("recharge_remark not like", value, "rechargeRemark");
            return (Criteria) this;
        }

        public Criteria andRechargeRemarkIn(List<String> values) {
            addCriterion("recharge_remark in", values, "rechargeRemark");
            return (Criteria) this;
        }

        public Criteria andRechargeRemarkNotIn(List<String> values) {
            addCriterion("recharge_remark not in", values, "rechargeRemark");
            return (Criteria) this;
        }

        public Criteria andRechargeRemarkBetween(String value1, String value2) {
            addCriterion("recharge_remark between", value1, value2, "rechargeRemark");
            return (Criteria) this;
        }

        public Criteria andRechargeRemarkNotBetween(String value1, String value2) {
            addCriterion("recharge_remark not between", value1, value2, "rechargeRemark");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNull() {
            addCriterion("delete_flag is null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNotNull() {
            addCriterion("delete_flag is not null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagEqualTo(Byte value) {
            addCriterion("delete_flag =", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotEqualTo(Byte value) {
            addCriterion("delete_flag <>", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThan(Byte value) {
            addCriterion("delete_flag >", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThanOrEqualTo(Byte value) {
            addCriterion("delete_flag >=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThan(Byte value) {
            addCriterion("delete_flag <", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThanOrEqualTo(Byte value) {
            addCriterion("delete_flag <=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIn(List<Byte> values) {
            addCriterion("delete_flag in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotIn(List<Byte> values) {
            addCriterion("delete_flag not in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagBetween(Byte value1, Byte value2) {
            addCriterion("delete_flag between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotBetween(Byte value1, Byte value2) {
            addCriterion("delete_flag not between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("update_time is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("update_time is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("update_time =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("update_time <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("update_time >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("update_time >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("update_time <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("update_time <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("update_time in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("update_time not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("update_time between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("update_time not between", value1, value2, "updateTime");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}