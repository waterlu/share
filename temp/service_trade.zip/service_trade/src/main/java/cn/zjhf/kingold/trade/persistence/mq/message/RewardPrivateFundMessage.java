package cn.zjhf.kingold.trade.persistence.mq.message;

import cn.zjhf.kingold.rocketmq.base.MQMessage;
import cn.zjhf.kingold.trade.entity.RewardPrivateFund;

/**
 * Created by Xiaody on 17/7/27.
 */
public class RewardPrivateFundMessage implements MQMessage {
    private RewardPrivateFund rewardPrivateFund;


    public RewardPrivateFund getRewardPrivateFund() {
        return rewardPrivateFund;
    }

    public void setRewardPrivateFund(RewardPrivateFund rewardPrivateFund) {
        this.rewardPrivateFund = rewardPrivateFund;
    }

    @Override
    public String getKey() {
        return getRewardPrivateFund().getRewardPrivateBillCode();
    }
}
