package cn.zjhf.kingold.trade.entity.InVO;

import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import java.math.BigDecimal;

/**
 * Created by zhangyijie on 2017/5/23.
 */
@ApiModel(value = "ProductUuidVO", description = "产品Uuid, 通用入参")
public class ProductUuidVO extends InVOBase {
    @ApiModelProperty(required = true, value = "traceID")
    @NotEmpty
    private String traceID;

    @ApiModelProperty(required = true, value = "product_uuid")
    @NotEmpty
    private String product_uuid;

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    //FIXI 固收产品    PRIF 私募产品
    @ApiModelProperty(required = true, value = "productType")
    private String productType = "FIXI";

    @ApiModelProperty(required = true, value = "createBy")
    @NotEmpty
    private String createBy;

    private Integer productPeriod;

    private double annualInterestRate;

    public ProductUuidVO(){

    }

    public ProductUuidVO(String traceID, String product_uuid) {
        this.traceID = traceID;
        this.product_uuid = product_uuid;
    }

    public Integer getProductPeriod() {
        return productPeriod;
    }

    public void setProductPeriod(Integer productPeriod) {
        this.productPeriod = productPeriod;
    }

    public double getAnnualInterestRate() {
        return annualInterestRate;
    }

    public void setAnnualInterestRate(double annualInterestRate) {
        this.annualInterestRate = annualInterestRate;
    }

    public String getTraceID() {
        return traceID;
    }

    public void setTraceID(String traceID) {
        this.traceID = traceID;
    }

    public String getProduct_uuid() {
        return product_uuid;
    }

    public void setProduct_uuid(String product_uuid) {
        this.product_uuid = product_uuid;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    @Override
    public String toString() {
        return "ProductUuidVO{" +
                "traceID='" + traceID + '\'' +
                ", product_uuid='" + product_uuid + '\'' +
                ", productType='" + productType + '\'' +
                ", createBy='" + createBy + '\'' +
                ", productPeriod=" + productPeriod +
                ", annualInterestRate=" + annualInterestRate +
                '}';
    }
}
