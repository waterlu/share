package cn.zjhf.kingold.trade.utils;

import cn.zjhf.kingold.trade.constant.CouponTypeConstant;
import cn.zjhf.kingold.trade.entity.InVO.CommGrant.CommGrantInfoVO;
import cn.zjhf.kingold.trade.service.IPayService;
import cn.zjhf.kingold.trade.service.impl.ReconciliationServiceImpl;
import cn.zjhf.kingold.trade.utils.Tuple.ThreeTuple;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.util.*;
import java.util.regex.Pattern;

/**
 * Created by zhangyijie on 2017/6/7.
 */
public class  XLSUtils {
    private static final Logger logger = LoggerFactory.getLogger(XLSUtils.class);

    /**
     * 正则表达式：验证手机号
     */
    public static final String REGEX_MOBILE = "^((17[0-9])|(14[0-9])|(13[0-9])|(15[0-9])|(18[0-9]))\\d{8}$";

    /**
     * 过滤手机号
     * @param mobile 手机号
     * @return 校验通过则返回处理过的手机号，否则返回null
     */
    private static String filterMobile(String mobile) {
        if(mobile == null) {
            return null;
        }

        //过滤掉 空格, \t为制表符, \n为换行, \r为回车 等符号
        mobile = mobile.replaceAll("[\\t\\n\\r\\ ]", "");

        if(Pattern.matches(REGEX_MOBILE, mobile)) {
            return mobile;
        }else {
            return null;
        }
    }

    private static String getValue(HSSFCell cell) {
        switch(cell.getCellType()) {
            case HSSFCell.CELL_TYPE_NUMERIC:
                return "" + cell.getNumericCellValue();
            case HSSFCell.CELL_TYPE_STRING:
                return cell.getRichStringCellValue().getString();
            default:
                return cell.getRichStringCellValue().getString();
        }
    }

    private static String getStrValue(Cell cell) {
        if(cell == null) {
            return null;
        }

        switch(cell.getCellType()) {
            case Cell.CELL_TYPE_NUMERIC:
                DecimalFormat decimalFormat = new DecimalFormat("###.##");
                return decimalFormat.format(new Double(cell.toString()));
            case Cell.CELL_TYPE_STRING:
                return cell.getRichStringCellValue().getString();
            default:
                return cell.getRichStringCellValue().getString();
        }
    }

    private static Workbook getWorkBook(String fileName) {
        //创建Workbook工作薄对象，表示整个excel
        Workbook workbook = null;
        try {
            //获取excel文件的io流

            //根据文件后缀名不同(xls和xlsx)获得不同的Workbook实现类对象
            if(fileName.endsWith("xls")){
                //2003
                workbook = new HSSFWorkbook(new FileInputStream(fileName));
            }else if(fileName.endsWith("xlsx")){
                //2007
                workbook = new XSSFWorkbook(new FileInputStream(fileName));
            }
        } catch (IOException e) {
            logger.info(e.getMessage());
        }
        return workbook;
    }

    private static CommGrantInfoVO readInputMess(Workbook workbook) {
        CommGrantInfoVO commGrantInfo = new CommGrantInfoVO();

        if((workbook!=null)&& (workbook.getNumberOfSheets() > 0)) {
            Sheet sheet = workbook.getSheetAt(0);
            if(sheet != null) {
                int lastRowNum = sheet.getLastRowNum();

                //数据开始的起始行
                final int dataBeginRow = 1;
                for(int rowNum = dataBeginRow; rowNum <= lastRowNum; rowNum++) {
                    Row row = sheet.getRow(rowNum);

                    // 手机号|类型|礼券批次或者现金红包金额|活动号
                    if((row!=null) && (row.getLastCellNum()>=4)) {
                        //取初始数据
                        String phoneNumber = getStrValue(row.getCell((short) 0)).trim();
                        String itemTypeStr = getStrValue(row.getCell((short) 1)).trim();
                        String ccCodeOrAmt = getStrValue(row.getCell((short) 2)).trim();
                        Byte activityNum = new Byte(getStrValue(row.getCell((short) 3)).trim());
                        activityNum = (activityNum.byteValue()>0)?(new Byte((byte)(0-activityNum.byteValue()))):activityNum;

                        if(DataUtils.isEmpty(phoneNumber)) {
                            commGrantInfo.setErrMess(rowNum, "手机号为空");
                            continue;
                        }

                        int itemType = 0;
                        if(itemTypeStr.startsWith("" + CouponTypeConstant.CASH_INTEREST_TYPE)) {
                            itemType = CouponTypeConstant.CASH_INTEREST_TYPE;
                        }else if(itemTypeStr.startsWith("" + CouponTypeConstant.RED_PACKET_TYPE)) {
                            itemType = CouponTypeConstant.RED_PACKET_TYPE;
                        }else {
                            commGrantInfo.setErrMess(rowNum, "指定的类型 " + itemTypeStr + " 暂不支持");
                            continue;
                        }

                        if(DataUtils.isEmpty(ccCodeOrAmt)) {
                            String errMess = "";
                            if(itemType == CouponTypeConstant.CASH_INTEREST_TYPE) {
                                errMess = "指定的礼券批次为空";
                            }else if(itemType == CouponTypeConstant.RED_PACKET_TYPE) {
                                errMess = "指定的现金红包金额为空";
                            }
                            commGrantInfo.setErrMess(rowNum, errMess);
                            continue;
                        }

                        if(itemType == CouponTypeConstant.CASH_INTEREST_TYPE) {
                            commGrantInfo.addCashCoupon(rowNum,activityNum,phoneNumber,ccCodeOrAmt);
                        }else if(itemType == CouponTypeConstant.RED_PACKET_TYPE) {
                            Double redPacketAmt = null;
                            try {
                                redPacketAmt = Double.parseDouble(ccCodeOrAmt);
                            }catch(Exception e) {
                                logger.error(e.getMessage());
                            }
                            if((redPacketAmt!=null) && (redPacketAmt.doubleValue()>0)) {
                                commGrantInfo.addRedPacketGrant(rowNum,activityNum,phoneNumber,redPacketAmt);
                            }else {
                                commGrantInfo.setErrMess(rowNum, "指定的现金红包金额不合法");
                                continue;
                            }
                        }
                    }
                }
            }
        }

        return commGrantInfo;
    }

    public static CommGrantInfoVO readInputMess(MultipartFile file) {
        Workbook workbook = getWorkBook(file);
        return readInputMess(workbook);
    }

    public static CommGrantInfoVO readInputMess(String fileName) {
        Workbook workbook = getWorkBook(fileName);
        return readInputMess(workbook);
    }

    private static Workbook getWorkBook(MultipartFile file) {
        //获得文件名
        String fileName = file.getOriginalFilename();

        //创建Workbook工作薄对象，表示整个excel
        Workbook workbook = null;
        try {
            //获取excel文件的io流
            InputStream is = file.getInputStream();

            //根据文件后缀名不同(xls和xlsx)获得不同的Workbook实现类对象
            if(fileName.endsWith("xls")){
                //2003
                workbook = new HSSFWorkbook(is);
            }else if(fileName.endsWith("xlsx")){
                //2007
                workbook = new XSSFWorkbook(is);
            }
        } catch (IOException e) {
            logger.info(e.getMessage());
        }
        return workbook;
    }

    /**
     * 筛选出格式错误的手机号
     * @param file
     * @return
     */
    public static List<String> getErrPhoneNum(MultipartFile file) {
        List<String> phoneNums = readUserPhone(file, true);
        List<String> errPhones = new ArrayList<>();

        for(String phoneNum : phoneNums) {
            if(DataUtils.isEmpty(filterMobile(phoneNum))) {
                errPhones.add(phoneNum);
            }
        }

        return errPhones;
    }

    /**
     * 读取Excel文件中的用户手机号
     * @param file
     * @param removeRepeat
     * @return
     */
    public static List<String> readUserPhone(MultipartFile file, boolean removeRepeat){
        List<String> userPhones = new ArrayList<String>();

        Workbook workbook = getWorkBook(file);
        if((workbook!=null)&& (workbook.getNumberOfSheets() > 0)) {
            Sheet sheet = workbook.getSheetAt(0);
            if(sheet != null) {
                int lastRowNum = sheet.getLastRowNum();

                //数据开始的起始行
                final int dataBeginRow = 1;
                for(int rowNum = dataBeginRow; rowNum <= lastRowNum; rowNum++) {
                    Row row = sheet.getRow(rowNum);

                    if(row!=null) {
                        String phoneNumber = null;
                        if(DataUtils.isNotEmpty(getStrValue(row.getCell((short) 0)))){
                            phoneNumber = getStrValue(row.getCell((short) 0)).trim();
                        }
                        if (DataUtils.isNotEmpty(phoneNumber)) {
                            userPhones.add(phoneNumber);
                        }
                    }
                }
            }
        }

        if(removeRepeat) {
            return DataUtils.removeRepeat(userPhones);
        }else {
            return userPhones;
        }
    }

    /**
     * 转换业务类型名称
     * @param type
     * @return
     */
    private static String getTargetType(int type) {
        switch (type) {
            case IPayService.TYPE_INVEST:
                return "投标";
            case IPayService.TYPE_PAYMENT:
                return "满标";
            case IPayService.TYPE_REPAYMENT:
                return "还标";
            case IPayService.TYPE_TRANSFER:
                return "转账";
            default:
                return "";
        }
    }

    //其实写的不太好，一个阶段性的工具，先这样吧
    public static Map<String, ReconciliationServiceImpl.BaofooQueryData> read(String fileName, int type) {
        Map<String, ReconciliationServiceImpl.BaofooQueryData> result = new HashMap<String, ReconciliationServiceImpl.BaofooQueryData>();
        String targetType = getTargetType(type);
        if(DataUtils.isEmpty(targetType)) {
            return result;
        }

        InputStream is = null;
        try {
            is = new FileInputStream(fileName);
        } catch (FileNotFoundException e) {
            logger.error("文件未找到", e);
            return result;
        }

        HSSFWorkbook hssfWorkbook = null;
        try {
            hssfWorkbook = new HSSFWorkbook(is);
        } catch (IOException e) {
            logger.error("IO异常", e);
            return result;
        }

        for(int numSheet = 0; numSheet < hssfWorkbook.getNumberOfSheets(); numSheet++) {
            HSSFSheet hssfSheet = hssfWorkbook.getSheetAt(numSheet);
            if(hssfSheet == null) {
                continue;
            }

            int lastRowNum = hssfSheet.getLastRowNum();

            //数据开始的起始行
            final int dataBeginRow = 7;
            for(int rowNum = dataBeginRow; rowNum <= hssfSheet.getLastRowNum(); rowNum++) {
                HSSFRow hssfRow = hssfSheet.getRow(rowNum);
                if(hssfRow.getLastCellNum() != 5) {
                    break;
                }

                ReconciliationServiceImpl.BaofooQueryData data = new ReconciliationServiceImpl.BaofooQueryData();
                String tradeType = getValue(hssfRow.getCell((short)2));

                //过滤类型
                if(!targetType.equals(tradeType)) {
                    continue;
                }

                data.setOrder_id(getValue(hssfRow.getCell((short)0)).trim());

                String strTime = getValue(hssfRow.getCell((short)1));
                strTime = strTime.substring(0, strTime.length() - 2);
                Date succTime = StringOrDate.strToDate(strTime);
                data.setSucc_time(succTime);

                double amt = Double.parseDouble(getValue(hssfRow.getCell((short)3)));
                data.setSucc_amount(amt);

                String status = getValue(hssfRow.getCell((short)4));
                if(status.trim().equals("成功")) {
                    data.setState(ReconciliationServiceImpl.BaofooQueryData.FLAG_SUCC);
                }else if(status.trim().equals("失败")) {
                    data.setState(0);
                }

                result.put(data.getOrder_id(), data);
            }
        }

        return result;
    }
}
