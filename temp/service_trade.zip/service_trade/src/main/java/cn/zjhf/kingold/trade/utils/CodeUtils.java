package cn.zjhf.kingold.trade.utils;

import java.util.UUID;

/**
 * Created by DELL on 2017/5/2.
 */
public class CodeUtils {

    /**
     *  RC
     * @return
     */
    public static String createRCCode(){
        return  UUID.randomUUID().toString().replace("-","");
    }



}
