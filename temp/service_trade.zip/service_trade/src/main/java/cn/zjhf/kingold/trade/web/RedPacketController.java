package cn.zjhf.kingold.trade.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.constant.TradeStatusMsg;
import cn.zjhf.kingold.trade.entity.InVO.*;
import cn.zjhf.kingold.trade.entity.OutVO.CommItemListVO;
import cn.zjhf.kingold.trade.entity.OutVO.CouponSpecifiedDistributionRecordItemDetailVO;
import cn.zjhf.kingold.trade.entity.OutVO.CouponSpecifiedDistributionRecordItemListVO;
import cn.zjhf.kingold.trade.entity.OutVO.RedPacketRecordVO;
import cn.zjhf.kingold.trade.service.ICommGrantService;
import cn.zjhf.kingold.trade.service.IDrawRedPacketService;
import cn.zjhf.kingold.trade.service.IRedPacketService;
import cn.zjhf.kingold.trade.utils.DataUtils;
import cn.zjhf.kingold.trade.utils.Tuple.TwoTuple;
import cn.zjhf.kingold.trade.utils.XLSUtils;
import com.alibaba.fastjson.JSON;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by zhangyijie on 2018/1/25.
 */
@RestController
@RequestMapping(value = "/redpacket")
public class RedPacketController {
    protected static final Logger logger = LoggerFactory.getLogger(RedPacketController.class);

    @Autowired
    IRedPacketService redPacketService;

    @Autowired
    IDrawRedPacketService drawRedPacketService;

    @Autowired
    ICommGrantService commGrantService;

    private ResponseResult creatOKRespResult(String traceID) {
        ResponseResult respResult = new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS,"成功");
        return respResult;
    }

    private ResponseResult creatOKRespResult(String traceID, Object data) {
        ResponseResult respResult = new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS,"成功", data);
        return respResult;
    }

    /**
     * Step1.1 检查指定发放现金红包的记录(excel导入批量发放)
     * @return 重复的手机号列表；如该列表为空，则无重复的数据
     * @throws BusinessException
     */
    @RequestMapping(value = "/checkSpecifiedDistributionByExcelList", method = RequestMethod.POST)
    public ResponseResult checkSpecifiedDistributionByExcelList(InsertCouponSpecifiedDistributionAuditVO record, @RequestParam(value = "file", required = false)MultipartFile file) throws BusinessException {
        logger.info("redpacket_checkSpecifiedDistributionByExcelList start: " + DataUtils.toString(record));
        List<String> repeatUser = new ArrayList<>();
            if(file!=null) {
                List<String> userPhones = XLSUtils.readUserPhone(file, false);
                repeatUser = DataUtils.getRepeat(userPhones);
            }

        logger.info("redpacket_checkSpecifiedDistributionByExcelList end: " + DataUtils.toString(record.getTraceID(), repeatUser));
        return creatOKRespResult(record.getTraceID(), repeatUser);
    }

    /**
     * Step1.1 添加指定发放现金红包的记录(excel导入批量发放)
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/insertSpecifiedDistributionByExcelList", method = RequestMethod.POST)
    public ResponseResult insertSpecifiedDistributionByExcelList(InsertCouponSpecifiedDistributionAuditVO record, @RequestParam(value = "file", required = false)MultipartFile file) throws BusinessException {
        logger.info("redpacket_insertSpecifiedDistributionByExcelList start: " + DataUtils.toString(record));
        boolean result = false;
        List<String> unregistUser = new ArrayList<>();
        if(record != null) {
            if(file!=null) {
                List<String> userPhones = XLSUtils.readUserPhone(file, true);
                logger.info("UserPhoneCount: {}", userPhones.size());
                record.setUserPhoneList(userPhones);
            }
            if((record.getRedPacketAmount() != null) && (record.getRedPacketAmount().doubleValue() > 0)
                    && (record.getUserPhoneList() != null) && (record.getUserPhoneList().size() > 0)) {
                if(record.getUserPhoneList().size() > (1000)){
                    throw new BusinessException(TradeStatusMsg.REDPACKET_SPECDIST_MAX_ERR, TradeStatusMsg.REDPACKET_SPECDIST_MAX_ERR_MSG);
                }

                unregistUser = redPacketService.getUnRegistUserphone(record.getUserPhoneList());
                if(unregistUser.size() == 0) {
                    try {
                        result = redPacketService.insertSpecifiedDistributionByExcel(record.getRedPacketAmount(), record.getSpecifiedName(), record.getUserPhoneList(), record.getOperator(), file.getInputStream());
                    } catch (IOException e) {
                        logger.error("IOException: ", e);
                    }
                    //result = redPacketService.insertSpecifiedDistribution(record.getRedPacketAmount(), record.getSpecifiedName(), record.getUserPhoneList(), record.getOperator());
                }
            } else {
                throw new BusinessException(TradeStatusMsg.REDPACKET_SPECDIST_INVALID_ERR, TradeStatusMsg.REDPACKET_SPECDIST_INVALID_ERR_MSG);
            }
        }

        Map<String, Object> map = new HashMap<>();
        map.put("result", result);
        map.put("unregistUser", unregistUser);

        logger.info("redpacket_insertSpecifiedDistributionByExcelList end: " + DataUtils.toString(record.getTraceID(), map));
        return creatOKRespResult(record.getTraceID(), map);
    }

    /**
     * Step1.2 检查指定发放现金红包的记录
     * @return 重复的手机号列表；如该列表为空，则无重复的数据
     * @throws BusinessException
     */
    @RequestMapping(value = "/checkSpecifiedDistributionByList", method = RequestMethod.POST)
    public ResponseResult checkSpecifiedDistributionByList(InsertCouponSpecifiedDistributionAuditVO record) throws BusinessException {
        logger.info("redpacket_checkSpecifiedDistributionByList start: " + DataUtils.toString(record));
        List<String> repeatUser = new ArrayList<>();
        if((record!=null) && (record.getUserPhoneList()!=null)) {
            repeatUser = DataUtils.getRepeat(record.getUserPhoneList());
        }

        logger.info("redpacket_checkSpecifiedDistributionByList end: " + DataUtils.toString(record.getTraceID(), repeatUser));
        return creatOKRespResult(record.getTraceID(), repeatUser);
    }

    /**
     * Step1.2 添加指定发放现金红包的记录
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/insertSpecifiedDistributionByList", method = RequestMethod.POST)
    public ResponseResult insertSpecifiedDistributionByList(@RequestBody InsertCouponSpecifiedDistributionAuditVO record) throws BusinessException {
        logger.info("redpacket_insertSpecifiedDistributionByList start: " + DataUtils.toString(record));
        boolean result = false;
        List<String> unregistUser = new ArrayList<>();
        if(record != null) {
            record.setUserPhoneList(record.getUserPhoneList());
            if((record.getRedPacketAmount() != null) && (record.getRedPacketAmount().doubleValue() > 0)
                    && (record.getUserPhoneList() != null) && (record.getUserPhoneList().size() > 0)) {
                if(record.getUserPhoneList().size() > (1000)){
                    throw new BusinessException(TradeStatusMsg.REDPACKET_SPECDIST_MAX_ERR, TradeStatusMsg.REDPACKET_SPECDIST_MAX_ERR_MSG);
                }

                unregistUser = redPacketService.getUnRegistUserphone(record.getUserPhoneList());
                if(unregistUser.size() == 0) {
                    result = redPacketService.insertSpecifiedDistributionByList(record.getRedPacketAmount(), record.getSpecifiedName(), record.getUserPhoneList(), record.getOperator());
                    //result = redPacketService.insertSpecifiedDistribution(record.getRedPacketAmount(), record.getSpecifiedName(), record.getUserPhoneList(), record.getOperator());
                }
            } else {
                throw new BusinessException(TradeStatusMsg.REDPACKET_SPECDIST_INVALID_ERR, TradeStatusMsg.REDPACKET_SPECDIST_INVALID_ERR_MSG);
            }
        }

        Map<String, Object> map = new HashMap<>();
        map.put("result", result);
        map.put("unregistUser", unregistUser);

        logger.info("redpacket_insertSpecifiedDistributionByList end: " + DataUtils.toString(record.getTraceID(), map));
        return creatOKRespResult(record.getTraceID(), map);
    }

    /**
     * Step2  查询现金券指定发放记录
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/lstCouponSpecifiedDistributionRecord", method = RequestMethod.GET)
    public ResponseResult lstCouponSpecifiedDistributionRecord(@RequestParam Map<String, Object> param) throws BusinessException {
        logger.info("redpacket_lstCouponSpecifiedDistributionRecord start: " + DataUtils.toString(param));
        String jsonString = JSON.toJSONString(param);
        LstCouponSpecifiedDistributionConditionVO lstCondition = JSON.parseObject(jsonString, LstCouponSpecifiedDistributionConditionVO.class);

        CouponSpecifiedDistributionRecordItemListVO result = redPacketService.lstCouponSpecifiedDistributionRecord(lstCondition);

        logger.info("redpacket_lstCouponSpecifiedDistributionRecord end: " + DataUtils.toString(lstCondition.getTraceID(), result));
        return creatOKRespResult(lstCondition.getTraceID(), result);
    }

    /**
     * Step3  查询现金券指定发放记录明细
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/lstCouponSpecifiedDistributionDetail", method = RequestMethod.GET)
    public ResponseResult lstCouponSpecifiedDistributionDetail(LstCouponSpecifiedDistributionDetailConditionVO lstCondition) throws BusinessException {
        logger.info("redpacket_lstCouponSpecifiedDistributionDetail start: " + DataUtils.toString(lstCondition));

        CouponSpecifiedDistributionRecordItemDetailVO result = redPacketService.lstCouponSpecifiedDistributionDetail(lstCondition);

        logger.info("redpacket_lstCouponSpecifiedDistributionDetail end: " + DataUtils.toString(lstCondition.getTraceID(), result));
        return creatOKRespResult(lstCondition.getTraceID(), result);
    }

    /**
     * Step4  删除未审核通过的指定发放批次
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/deleteCouponSpecifiedDistribution", method = RequestMethod.POST)
    public ResponseResult deleteCouponSpecifiedDistribution(@RequestBody DeleteCouponSpecifiedDistributionVO deleteInfo) throws BusinessException {
        logger.info("redpacket_deleteCouponSpecifiedDistribution start: " + DataUtils.toString(deleteInfo));
        DataUtils.checkParam(deleteInfo.getAuditId());

        boolean result = redPacketService.deleteCouponSpecifiedDistribution(deleteInfo.getAuditId());

        logger.info("redpacket_deleteCouponSpecifiedDistribution end: " + DataUtils.toString(deleteInfo.getTraceID(), result));
        return creatOKRespResult(deleteInfo.getTraceID(), result);
    }

    /**
     * Step5  现金券指定发放记录审核
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/couponSpecifiedDistributionAudit", method = RequestMethod.POST)
    public ResponseResult couponSpecifiedDistributionAudit(@RequestBody CouponSpecifiedDistributionAuditVO auditInfo) throws BusinessException {
        logger.info("redpacket_couponSpecifiedDistributionAudit start: " + DataUtils.toString(auditInfo));

        boolean result = redPacketService.couponSpecifiedDistributionAudit(auditInfo);

        logger.info("redpacket_couponSpecifiedDistributionAudit end: " + DataUtils.toString(auditInfo.getTraceID(), result));
        return creatOKRespResult(auditInfo.getTraceID(), result);
    }

    /**
     * Step6  查询现金红包
     * userUuid!=null 前端使用；其他 运营后台使用
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/lstRedPacketRecord", method = RequestMethod.GET)
    public ResponseResult lstRedPacketRecord(@RequestParam Map<String, Object> param) throws BusinessException {
        String jsonString = JSON.toJSONString(param);
        LstRedPacketConditionVO lstCondition = JSON.parseObject(jsonString, LstRedPacketConditionVO.class);
        logger.info("redpacket_lstRedPacketRecord start: " + DataUtils.toString(lstCondition));

        CommItemListVO<RedPacketRecordVO> result = redPacketService.lstRedPacketRecord(lstCondition);

        logger.info("redpacket_lstRedPacketRecord end: " + DataUtils.toString(lstCondition.getTraceID(), result));
        return creatOKRespResult(lstCondition.getTraceID(), result);
    }

    /**
     * Step7  领取红包, 指定红包ID列表
     * @return 1成功，0失败
     * @throws BusinessException
     */
    @RequestMapping(value = "/drawRedPacketEx", method = RequestMethod.POST)
    public ResponseResult drawRedPacketEx(@RequestBody DrawRedPacketVO drawRedPacketVO) throws BusinessException {
        logger.info("redpacket_drawRedPacketEx start: " + DataUtils.toString(drawRedPacketVO));

        DataUtils.checkParam(drawRedPacketVO.getRedPacketIds());

        int result = redPacketService.drawRedPacketList(drawRedPacketVO.getRedPacketIds());

        logger.info("redpacket_drawRedPacketEx end: " + DataUtils.toString(drawRedPacketVO.getTraceID(), result));
        return creatOKRespResult(drawRedPacketVO.getTraceID(), result);
    }

    /**
     * Step7  领取红包
     * @return result: 1成功，0失败;  errMess: 失败时的消息
     * @throws BusinessException
     */
    @RequestMapping(value = "/drawRedPacket", method = RequestMethod.POST)
    public ResponseResult drawRedPacket(@RequestBody DrawRedPacketVO drawRedPacketVO) throws BusinessException {
        logger.info("redpacket_drawRedPacket start: " + DataUtils.toString(drawRedPacketVO));

        DataUtils.checkParam(drawRedPacketVO.getUserUuid());
        DataUtils.checkParam(drawRedPacketVO.getRedPacketId());
        TwoTuple<Integer, String> result = null;
        Map<String, Object> map = new HashMap<>();
        try {
            result = drawRedPacketService.drawRedPacket(drawRedPacketVO.getUserUuid(), drawRedPacketVO.getRedPacketId());
            map.put("result", result.first);
            map.put("errMess", result.second);
        }catch(BusinessException e) {
            logger.error("BusinessException: ", e);
            map.put("result", 0);
            map.put("errMess", e.getMessage());
            drawRedPacketService.drawRedPacketFail(drawRedPacketVO.getRedPacketId(), e.getMessage());
            logger.info("redpacket_drawRedPacket end: " + DataUtils.toString(drawRedPacketVO.getTraceID(), map));
            throw e;
        }
        logger.info("redpacket_drawRedPacket end: " + DataUtils.toString(drawRedPacketVO.getTraceID(), map));
        return creatOKRespResult(drawRedPacketVO.getTraceID(), map);
    }

    /**
     * 通用发放
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/commGrant", method = RequestMethod.POST)
    public ResponseResult commGrant(@RequestParam(value = "file", required = false)MultipartFile file) throws BusinessException {
        logger.info("commGrant start: ");

        Map<Integer, String> result = commGrantService.commGrant(file);

        logger.info("commGrant end: " + DataUtils.toString(result));
        return creatOKRespResult("", result);
    }

    /**
     * 根据条件查询现金红包数量
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/countRedPacketRecord", method = RequestMethod.GET)
    public ResponseResult countRedPacketRecord(LstRedPacketConditionVO listCondition) throws BusinessException {
        int result = redPacketService.countRedPacketRecord(listCondition);
        return creatOKRespResult(listCondition.getTraceID(), result);
    }

    /**
     * 根据条件查询现金红包总额
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/totalRedPacketRecord", method = RequestMethod.GET)
    public ResponseResult totalRedPacketRecord(LstRedPacketConditionVO listCondition) throws BusinessException {
        double result = redPacketService.totalRedPacketRecord(listCondition);
        return creatOKRespResult(listCondition.getTraceID(), result);
    }

}
