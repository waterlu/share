package cn.zjhf.kingold.trade.entity.InVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Created by zhangyijie on 2018/1/31.
 */
@ApiModel(value = "CoinExchangeVO", description = "指定发券的入参")
public class CoinExchangeVO extends InVOBase {

    @ApiModelProperty(required = true, value = "现金券批次号")
    private String cashCouponCode;

    @ApiModelProperty(required = true, value = "用户userUuid")
    private String userUuid;

    @ApiModelProperty(required = true, value = "适用场景号码：该号码由调用方指定，只做记录适用不做校验，特殊用途建议用一个特别的负数以作区别")
    private Byte applyScene;

    public String getCashCouponCode() {
        return cashCouponCode;
    }

    public void setCashCouponCode(String cashCouponCode) {
        this.cashCouponCode = cashCouponCode;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public Byte getApplyScene() {
        return applyScene;
    }

    public void setApplyScene(Byte applyScene) {
        this.applyScene = applyScene;
    }

    @Override
    public String toString() {
        return "CoinExchangeVO{" +
                "cashCouponCode='" + cashCouponCode + '\'' +
                ", userUuid='" + userUuid + '\'' +
                ", applyScene=" + applyScene +
                '}';
    }
}
