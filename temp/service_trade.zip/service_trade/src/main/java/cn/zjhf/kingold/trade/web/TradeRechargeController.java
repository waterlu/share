package cn.zjhf.kingold.trade.web;


import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.common.utils.MapRemoveNullUtil;
import cn.zjhf.kingold.trade.entity.TradeRecharge;
import cn.zjhf.kingold.trade.service.ITradeRechargeService;
import cn.zjhf.kingold.trade.service.ITradeService;
import cn.zjhf.kingold.trade.utils.DataUtils;
import cn.zjhf.kingold.trade.utils.PropertyDescriptionUtils;
import cn.zjhf.kingold.trade.utils.RequestMapperConvert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


@RestController
@RequestMapping("/traderecharge")
public class TradeRechargeController {

    private static final Logger logger = LoggerFactory.getLogger(TradeRechargeController.class);


    @Autowired
    private ITradeRechargeService tradeRechargeService;

    @Autowired
    private ITradeService tradeService;

    /**
     * 充值提现单据列表
     *
     * @param paramMap 参数选填 ：tradeRechargeUuid，accountType，rechargeBillCode（多个）， rechargeBillType(多个),rechargeStatus（多个）,rechargeTimeBegin，rechargeTimeTo，userPhone，userUuid
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public ResponseResult getList(@RequestParam Map paramMap) throws BusinessException {
        logger.info("getList start: " + DataUtils.toString(paramMap));

        MapRemoveNullUtil.removeNullEntry(paramMap);
        RequestMapperConvert.initParam(paramMap);
        RequestMapperConvert.initTradeRechargeParam(paramMap);
        List<Map> result = new ArrayList<>();
        List<Map> userList = tradeRechargeService.getList(paramMap);
        for (Map map : userList) {
            result.add(PropertyDescriptionUtils.convertProperty(map, (String) paramMap.get("properties"), (String) paramMap.get("desc"), PropertyDescriptionUtils.TRADE_RECHARGE_DIC));
        }

        logger.info("getList end: " + DataUtils.toString(paramMap.get("traceID"), result));
        return new ResponseResult((String) paramMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", result);
    }

    /**
     *  充值提现单据总数
     *
     * @param paramMap 参数选填 ： tradeRechargeUuid，accountType，rechargeBillCode（多个）， rechargeBillType(多个),rechargeStatus（多个）,rechargeTimeBegin，rechargeTimeTo，userPhone，userUuid
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/count", method = RequestMethod.GET)
    public ResponseResult getCount(@RequestParam Map paramMap) throws BusinessException {
        logger.info("getCount start: " + DataUtils.toString(paramMap));

        MapRemoveNullUtil.removeNullEntry(paramMap);
        RequestMapperConvert.initParam(paramMap);
        RequestMapperConvert.initTradeRechargeParam(paramMap);
        Integer count = tradeRechargeService.getCount(paramMap);

        logger.info("getCount end: " + DataUtils.toString(paramMap.get("traceID"), count));
        return new ResponseResult((String) paramMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", count);
    }

    /**
     *  查询充值单
     *
     * @param paramMap 参数选填 ： tradeRechargeUuid，accountType，rechargeBillCode（多个）， rechargeBillType(多个),rechargeStatus（多个）,rechargeTimeBegin，rechargeTimeTo，userPhone，userUuid
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/{billCode}", method = RequestMethod.GET)
    public ResponseResult get(@PathVariable String billCode, @RequestParam Map paramMap) throws BusinessException {
        logger.info("get start: " + DataUtils.toString(paramMap));

        TradeRecharge tradeRecharge = tradeService.queryRechargeOrderByBillCode(billCode);

        logger.info("get end: " + DataUtils.toString(paramMap.get("traceID"), tradeRecharge));
        return new ResponseResult((String) paramMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", tradeRecharge);
    }
}
