package cn.zjhf.kingold.trade.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.baofoo.BaofooAccountEnum;
import cn.zjhf.kingold.trade.baofoo.RechargeNotify;
import cn.zjhf.kingold.trade.entity.InVO.RechargeSdkVo;
import cn.zjhf.kingold.trade.entity.OutVO.BaofooPayParamVO;
import cn.zjhf.kingold.trade.entity.PayLog;
import cn.zjhf.kingold.trade.entity.Payee;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 支付类接口
 *
 * Created by lutiehua on 2017/4/26.
 */
public interface IPayService {

    /**
     * 投资
     */
    int TYPE_INVEST = 1;

    /**
     * 放款
     */
    int TYPE_PAYMENT = 2;

    /**
     * 退款
     */
    int TYPE_REFUND = 3;

    /**
     * 还款
     */
    int TYPE_REPAYMENT = 4;

    /**
     * 充值
     */
    int TYPE_RECHARGE = 5;

    /**
     * 提现
     */
    int TYPE_WITHDRAW = 6;

    /**
     * 转账
     */
    int TYPE_TRANSFER = 7;

    /**
     * 用户信息
     */
    int TYPE_USER = 8;

    /**
     * 绑定银行卡
     */
    int SMS_BIND_BANK_CARD = 1;

    /**
     * 平台绑定验证码
     */
    int SMS_BIND_PLATFORM = 2;

    /**
     * 获取平台宝付信息
     *
     */
    Map<String, String> getPlatformInfo();

    /**
     * 创建账户（注册宝付账号）
     *
     * @param phone 手机号码
     * @param userID 用户ID
     * @param realName 真实姓名
     * @param idCard 身份证号码
     * @return PayResponse
     */
    ResponseResult createAccount(String phone, long userID, String realName, String idCard, int isAccredit) throws BusinessException;

    /**
     * 绑定平台
     *
     * @param phone 手机号码
     * @param userID 用户ID
     * @param realName 真实姓名
     * @param idCard 身份证号码
     * @param smsCode 验证码
     * @return PayResponse
     */
    ResponseResult bindPlatform(String phone, long userID, String realName, String idCard, String smsCode, int isAccredit) throws BusinessException;

    /**
     * 募集方企业开户
     *
     * @param email 企业邮箱
     * @param mobile 法人手机号码
     * @param userID 用户ID
     * @param realName 真实姓名
     * @param idCard 身份证号码
     * @param license 营业执照号码
     * @param enterpriseName 企业名称
     * @return
     * @throws Exception
     */
    public ResponseResult createIssueAccount(String email, long userID, String realName, String idCard, String enterpriseName, String license, String mobile ) throws BusinessException;

    /**
     * 发送短信验证码
     *
     * @param userID 商户会员ID
     * @return
     * @throws BusinessException
     */
    ResponseResult sendVerifyCode(long userID) throws BusinessException;

    /**
     * 发送绑定账号短信验证码
     *
     * @param accountMobile 商户会员账号
     * @return
     * @throws BusinessException
     */
    ResponseResult sendAccountBindVerifyCode(String accountMobile) throws BusinessException;


    /**
     * 查询商户平台账户相关信息
     * @param baofooAccountEnum
     * @return
     * @throws BusinessException
     */
    ResponseResult platformAccountQuery(BaofooAccountEnum baofooAccountEnum) throws BusinessException;

    /**
     * 查询所有账户余额
     *
     * @return
     * @throws BusinessException
     */
    ResponseResult getAllAccountBalance() throws BusinessException;

    /**
     * 个人用户绑定银行卡
     *
     * @param userID 商户会员ID
     * @param mobile 银行预留手机号码
     * @param bankNo 银行卡号
     * @param validateCode 手机验证码
     * @return
     * @throws BusinessException
     */
    ResponseResult bindBankCard(long userID, String mobile, String bankNo, String validateCode) throws BusinessException;

    /**
     * 投资
     *
     * @param orderID 订单编号（唯一不允许重复）
     * @param productID 产品ID
     * @param productName 产品名称
     * @param borrowUserID 融资方用户ID
     * @param userID 投资方用户ID
     * @param amount 投资金额
     * @return
     * @throws BusinessException
     */
    ResponseResult invest(String orderID, long productID, String productName, long borrowUserID, long userID, double amount) throws BusinessException;

    /**
     * 放款
     *
     * @param orderID 订单编号（唯一不允许重复）
     * @param productID 产品ID
     * @param productName 产品名称
     * @param borrowUserID 融资方用户ID
     * @param amount 金额
     * @param fee 手续费（平台收取募集方费用）
     * @return
     * @throws BusinessException
     */
    ResponseResult paymentEx(String orderID, long productID, String productName, long borrowUserID, long userId, double amount, double fee) throws BusinessException;

    /**
     * 放款
     *
     * @param orderID 订单编号（唯一不允许重复）
     * @param productID 产品ID
     * @param productName 产品名称
     * @param borrowUserID 融资方用户ID
     * @param amount 金额
     * @param fee 手续费（平台收取募集方费用）
     * @return
     * @throws BusinessException
     */
    ResponseResult payment(String orderID, long productID, String productName, long borrowUserID, double amount, double fee) throws BusinessException;

    /**
     * 退款
     *
     * @param orderID 订单编号（唯一不允许重复）
     * @param productID 产品ID
     * @param productName 产品名称
     * @param borrowUserID 融资方用户ID
     * @param userID 投资方用户ID
     * @param amount 金额
     * @return
     * @throws BusinessException
     */
    ResponseResult refund(String orderID, long productID, String productName, long borrowUserID, long userID, double amount) throws BusinessException;

    /**
     * 还款
     * 一次请求中如果一个收款人收款失败，整个请求的所有收款人都失败
     * @param orderID 订单编号（唯一不允许重复）
     * @param productID 产品ID
     * @param productName 产品名称
     * @param borrowUserID 融资方用户ID
     * @param payees 收款人列表
     * @return
     * @throws BusinessException
     */
    ResponseResult repay(String orderID, long productID, String productName, long borrowUserID, List<Payee> payees) throws BusinessException;

    /**
     * 提现
     *
     * @param orderID 提现订单号（唯一）
     * @param userID 用户编号(唯一)
     * @param amount 金额，单位：元
     * @param fee 平台收取的手续费, 元
     * @param feeTokenOn 宝付手续费收取方（1：平台 2：个人）
     * @param bankNo 银行卡号
     * @return
     */
    ResponseResult withdraw(String orderID, long userID, double amount, double fee, int feeTokenOn, String bankNo) throws BusinessException;

    /**
     * 用户之间转账
     *
     * @param orderID 订单号
     * @param payerUserID 付款方用户号
     * @param payeeUserID 收款方用户号
     * @param amount 转账金额
     * @return
     * @throws BusinessException
     */
    ResponseResult transferC2C(String orderID, long payerUserID, long payeeUserID, double amount) throws BusinessException;

    /**
     * 平台向用户转账
     *
     * @param orderID 订单号
     * @param userID 用户号
     * @param amount 转账金额
     * @return
     * @throws BusinessException
     */
    ResponseResult transferP2C(String orderID, long userID, double amount) throws BusinessException;

    /**
     * 根据时间查询
     *
     * @param type
     * @param startTime
     * @param endTime
     * @return
     */
    ResponseResult query(int type, Date startTime, Date endTime) throws BusinessException;

    /**
     *
     * @param startTime
     * @param endTime
     * @return
     * @throws BusinessException
     */
    ResponseResult queryTranscationExcel(Date startTime, Date endTime) throws BusinessException;

    /**
     * 根据单据编号查询
     *
     * @param type 类型
     * @param orderBillCode 单据编号
     * @return
     * @throws BusinessException
     */
    ResponseResult query(int type, String orderBillCode) throws BusinessException;

    /**
     * 查询账户余额
     *
     * @param userID 商户会员ID
     * @return
     * @throws BusinessException
     */
    ResponseResult getAccountBalance(long userID) throws BusinessException;

    /**
     * 获取支付接口成功的指令号
     *
     * @param orderBillCode
     * @return
     * @throws BusinessException
     */
    String getSuccessfulOrderId(String orderBillCode) throws BusinessException;


    BaofooPayParamVO getRechargeParam(RechargeSdkVo rechargeSdkVo) throws BusinessException;


    /**
     * 充值中
     *
     * @param billCode
     * @param request
     * @param orderStatus
     * @return
     * @throws BusinessException
     */
    int updateRecharge(String billCode, String request, Integer orderStatus) throws BusinessException;

    /**
     * 充值成功
     *
     * @param billCode
     * @param response
     * @return
     * @throws BusinessException
     */
    String notifyRecharge(String billCode, String response) throws BusinessException;

    /**
     * 检查超时
     *
     * @param payOrderId
     * @return
     * @throws BusinessException
     */
    ResponseResult queryTimeoutStatus(String payOrderId) throws BusinessException;

    /**
     * 客户端充值，获取宝付orderId
     *
     * @return
     * @throws BusinessException
     */
    ResponseResult getBaofooOrderId(long userId, String orderId, double amount, String returnUrl) throws BusinessException;

    /**
     * 检查充值状态
     *
     * @param rechargeNotify
     * @return
     * @throws BusinessException
     */
    boolean checkRecharge(RechargeNotify rechargeNotify) throws BusinessException;

    /**
     * 更新支付日志
     *
     * @param orderId
     * @param status
     * @param response
     * @return
     * @throws BusinessException
     */
    boolean updatePayLog(String orderId, int status, String response) throws BusinessException;

    /**
     * 检查提现
     *
     * @param payOrderId
     * @return
     * @throws BusinessException
     */
    boolean checkWithdraw(String payOrderId) throws BusinessException;


}