package cn.zjhf.kingold.trade.persistence.mq.message;

import cn.zjhf.kingold.rocketmq.base.MQMessage;

/**
 * 用户注册成功消息
 *
 * Created by lutiehua on 2017/7/14.
 */
public class UserRegisterMessage implements MQMessage {

    @Override
    public String getKey() {
        return null;
    }
}
