package cn.zjhf.kingold.trade.persistence.dao;

import cn.zjhf.kingold.trade.dto.RewardSearchDto;
import cn.zjhf.kingold.trade.dto.RewardSummarySearchDto;
import cn.zjhf.kingold.trade.entity.RewardServiceAllowance;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface RewardServiceAllowanceMapper {
    int deleteByPrimaryKey(String rewardAllowanceBillCode);

    int insert(RewardServiceAllowance record);

    RewardServiceAllowance selectByPrimaryKey(String rewardAllowanceBillCode);

    int updateByPrimaryKey(RewardServiceAllowance record);

    List<RewardServiceAllowance> getRewardAllowanceList(RewardSummarySearchDto rewardSummarySearchDto);

    List<RewardServiceAllowance> search(RewardSearchDto rewardSearchDto);

    int searchCount(RewardSearchDto rewardSearchDto);

    /**
     * 更新审核状态
     *
     * @param param
     * @return
     */
    int updateCheckStatus(Map<String, Object> param);

    /**
     * 更新发放状态
     *
     * @param param
     * @return
     */
    int updateClearStatus(Map<String, Object> param);
}