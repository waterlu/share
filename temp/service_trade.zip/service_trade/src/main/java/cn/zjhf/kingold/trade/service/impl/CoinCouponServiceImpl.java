package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.constant.BizDefine;
import cn.zjhf.kingold.trade.constant.MarketCampaignCodeEnum;
import cn.zjhf.kingold.trade.constant.TradeStatusMsg;
import cn.zjhf.kingold.trade.entity.CashCoupon;
import cn.zjhf.kingold.trade.entity.CouponExtendRecord;
import cn.zjhf.kingold.trade.entity.UserInfo;
import cn.zjhf.kingold.trade.persistence.dao.CouponExtendRecordMapper;
import cn.zjhf.kingold.trade.persistence.mq.message.CouponMessage;
import cn.zjhf.kingold.trade.persistence.mq.producer.CouponSendProducer;
import cn.zjhf.kingold.trade.service.ICashCouponService;
import cn.zjhf.kingold.trade.service.ICoinCouponService;
import cn.zjhf.kingold.trade.service.ICouponExtendRecordService;
import cn.zjhf.kingold.trade.utils.StringOrDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by zhangyijie on 2018/1/31.
 */
@Service
public class CoinCouponServiceImpl extends ProductClearBase implements ICoinCouponService {
    protected static final Logger logger = LoggerFactory.getLogger(CouponExtendRecordServiceImpl.class);

    @Autowired
    private ICashCouponService cashCouponService;

    @Autowired
    private ICouponExtendRecordService couponExtendRecordService;

    @Autowired
    protected CouponExtendRecordMapper couponExtendRecordMapper;

    @Autowired
    private CouponSendProducer couponSendProducer;

    //代金券状态：1已发放
    public static final int STATUS_EXTEND = 1;

    /**
     * 给指定用户发放指定批次的礼券
     * @param userUuid
     * @param cashCouponCode
     * @param applyScene
     * @return 发放的礼券号码
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = BusinessException.class, propagation = Propagation.REQUIRES_NEW)
    public String establishCoinExtendRecord(String userUuid, String cashCouponCode, Byte applyScene) throws BusinessException {
        UserInfo userInfo = getUserInfo(userUuid);
        if (userInfo == null) {
            throw new BusinessException(TradeStatusMsg.CASHCOUPON_SPECDIST_NOEXIST_ERR,
                    TradeStatusMsg.CASHCOUPON_SPECDIST_NOEXIST_ERR_MSG, false);
        }

        String couponExtendRecordNo = null;
        Set<Integer> couponTypeSet = new HashSet<>();

        //检查该批次礼券是否已经被领完
        if(applyScene.intValue() != MarketCampaignCodeEnum.FIXED_PRODUCT_END.getCode().intValue()) {
            cashCouponService.checkCashCouponExhausted(cashCouponCode);
        }

        CashCoupon cashCoupon = cashCouponService.lstValidCashCoupon(cashCouponCode);
        if (cashCoupon != null) {
            CouponExtendRecord couponExtendRecord = new CouponExtendRecord();
            couponExtendRecord.setApplyScene(applyScene);
            couponExtendRecordNo = couponExtendRecordService.getCouponExtendCode();
            couponExtendRecord.setCouponExtendCode(couponExtendRecordNo);
            couponExtendRecord.setCouponCode(cashCoupon.getCcCode());
            couponExtendRecord.setCouponType(cashCoupon.getCcType());
            couponExtendRecord.setCouponFaceValue(cashCoupon.getFaceValue());
            couponExtendRecord.setCouponInterestYieldRate(cashCoupon.getInterestYieldRate());
            couponExtendRecord.setCouponInterestYieldPeriod(cashCoupon.getInterestYieldPeriod());
            couponExtendRecord.setCouponInterestYieldType(cashCoupon.getInterestYieldType());
            //有效时间处理
            if (cashCoupon.getValidTermType() == CashCouponServiceImpl.VALID_TIME_TYPE_TERM) {
                couponExtendRecord.setValidStartTime(cashCoupon.getValidStartTime());
                couponExtendRecord.setValidEndTime(cashCoupon.getValidEndTime());
            } else if (cashCoupon.getValidTermType() == CashCouponServiceImpl.VALID_TERM_TYPE_LENGTH) {
                Date curDate = new Date();
                couponExtendRecord.setValidStartTime(curDate);
                if (cashCoupon.getValidTermUnit() == CashCouponServiceImpl.TIME_UNIT_DAY) {
                    couponExtendRecord.setValidEndTime(StringOrDate.dateOffsetDay(curDate, cashCoupon.getValidTermQuantity()));
                } else if (cashCoupon.getValidTermUnit() == CashCouponServiceImpl.TIME_UNIT_MONTH) {
                    couponExtendRecord.setValidEndTime(StringOrDate.addMonth(curDate, cashCoupon.getValidTermQuantity()));
                } else if (cashCoupon.getValidTermUnit() == CashCouponServiceImpl.TIME_UNIT_YEAR) {
                    couponExtendRecord.setValidEndTime(StringOrDate.addYear(curDate, cashCoupon.getValidTermQuantity()));
                }
            }
            couponExtendRecord.setCouponStatus(new Integer(STATUS_EXTEND).byteValue());
            couponExtendRecord.setUserUuid(userInfo.getUserUuid());
            couponExtendRecord.setUserPhoneNumber(userInfo.getInvestorMobile());
            couponExtendRecord.setUserName(userInfo.getInvestorRealName());
            couponExtendRecord.setCreateTime(new Date());
            couponExtendRecord.setUpdateTime(new Date());
            couponExtendRecord.setDeleteFlag(new Byte("0"));
            couponExtendRecord.setUpdateUserId(BizDefine.DEFAULT_OPERATOR);

            couponTypeSet.add(Integer.valueOf(cashCoupon.getCcType()));
            if(couponExtendRecordMapper.insert(couponExtendRecord)> 0) {
                logger.info("Send coupon mess");
                CouponMessage couponMessage = new CouponMessage();
                couponMessage.setInvestorMobile(userInfo.getInvestorMobile());
                couponMessage.setOrderBillCode("");
                couponMessage.setApplyScene(new Integer(applyScene));
                couponMessage.setUserUuid(userInfo.getUserUuid());
                couponMessage.setCouponFaceValue(cashCoupon.getFaceValue());
                couponMessage.setCouponTypeSet(couponTypeSet);
                couponMessage.setValidEndTime(couponExtendRecord.getValidEndTime());
                couponMessage.setValidStartTime(new Date());
                couponMessage.setNewFlag(true);
                couponSendProducer.send(couponMessage);
            }else {
                couponExtendRecordNo = null;
            }
        }else {
            couponExtendRecordNo = null;
            logger.error("礼券批次{}无效", cashCouponCode);
        }

        return couponExtendRecordNo;
    }
}
