package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.service_consumer.service.UserServiceConsumer;
import cn.zjhf.kingold.trade.dto.AccountTransactionDto;
import cn.zjhf.kingold.trade.persistence.dao.AccountBaofooCustodyMapper;
import cn.zjhf.kingold.trade.persistence.dao.AccountTransactionMapper;
import cn.zjhf.kingold.trade.service.IAccountTransactionService;
import cn.zjhf.kingold.trade.utils.*;
import cn.zjhf.kingold.trade.vo.AccountTransactionVO;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Created by wangxun on 2016/11/04.
 * Copyright by zjinv
 */
@Service
public class AccountTransactionServiceImpl implements IAccountTransactionService {
    private static final Logger LOGGER = LoggerFactory.getLogger(AccountTransactionServiceImpl.class);


    @Autowired
    private AccountTransactionMapper accountTransactionMapper;

    @Autowired
    private AccountBaofooCustodyMapper accountBaofooMapper;

    @Autowired
    private UserServiceConsumer userServiceConsumer;

    @Value("${system.run.model}")
    public String runModel;

    @Value("${app.admin.verify.code}")
    public String adminVerifyCode;



    public AccountTransactionServiceImpl() {
    }


    /**
     * 获取资金流水记录
     *
     * @param params 必填参数 accountTransactionUuid
     * @return
     * @throws BusinessException
     */
    @Override
    public Map get(Map params) throws BusinessException {

        Map ui = accountTransactionMapper.get(params);

        if (ui == null || ui.isEmpty()) {
            return new HashMap();
        }

        Map resultMap = PropertyDescriptionUtils.convertProperty(ui, (String) params.get("properties"), (String) params.get("desc"), PropertyDescriptionUtils.ACCOUNT_TRANSACTION_DIC);
        return resultMap;
    }


    /**
     * 插入资金流水
     *
     * @param params 必填项如下：accountUuid，tradeType 选填项：account_transaction表含有的字段（驼峰格式）
     * @return
     * @throws BusinessException
     */
    @Override
    public Map insert(Map params) throws BusinessException {
        //根据accountUuid获取其他冗余信息。
        if(!params.containsKey("userUuid")) {
            Map accountParams = new HashMap();
            accountParams.put("accountUuid", MapParamUtils.getStringInMap(params, "accountUuid"));
            Map accountMap = accountBaofooMapper.getBaofooAndAccount(accountParams);
            LOGGER.info("current account:"+ accountMap);
            String userUuid = MapParamUtils.getStringInMap(accountMap, "userUuid");
            String accountType = MapParamUtils.getStringInMap(accountMap,"accountType");
            params.put("accountType",accountType );
            params.put("userUuid", userUuid);
        }

        params.put("accountTransactionUuid", UUID.randomUUID().toString().replace("-", ""));
        params.put("transactionBillCode", ZJBuzzUtils.generateOrderBillCode(MapParamUtils.getStringInMap(params, "tradeType")));
        accountTransactionMapper.insert(params);
        //记录流水信息和 账户状态
        LOGGER.info("insert account_transaction:"+ params);

        return params;
    }

    /**
     * 更新资金流水
     *
     * @param params 参数必填：accountTransactionUuid ,参数选填：见账户流水表
     * @return
     * @throws BusinessException
     */
    @Override
    public int update(Map params) throws BusinessException {
        return accountTransactionMapper.update(params);
    }

    /**
     * 删除资金流水
     *
     * @param params 参数必填：accountTransactionUuid
     * @return
     * @throws BusinessException
     */
    @Override
    public Integer delete(Map params) throws BusinessException {
        int num = accountTransactionMapper.delete(params);
        return num;
    }

    /**
     * 获取资金流水列表
     *
     * @param userMap 参数选填： accountTransactionUuid,accountUuidList,tradeTypeList,userUuidList,accountType,transactionTimeFrom,transactionTimeTo,accountNo,transactionChannel
     * @return
     * @throws BusinessException
     */
    @Override
    public List<Map> getList(Map userMap) throws BusinessException {

        List<Map> userList = accountTransactionMapper.getList(userMap);


        return userList;
    }

    /**
     * 获取资金流水总数
     *
     * @param userMap 参数选填： accountTransactionUuid,accountUuidList,tradeTypeList,userUuidList,accountType,transactionTimeFrom,transactionTimeTo,accountNo,transactionChannel
     * @return
     * @throws BusinessException
     */
    @Override
    public Integer getCount(Map userMap) throws BusinessException {
        Integer result = accountTransactionMapper.getCount(userMap);
        return result;
    }

    /**
     * 获取资金流水列表（通过账户uuid和对手账户uuid账户筛选account_type）
     *
     * @param userMap 参数选填： accountTransactionUuid,accountUuidList,tradeTypeList,userUuidList,accountType,transactionTimeFrom,transactionTimeTo,accountNo,transactionChannel
     * @return
     * @throws BusinessException
     */
    @Override
    public List<Map> getTransactionList(Map userMap) throws BusinessException{
        List<Map> userList = accountTransactionMapper.getTransactionList(userMap);
        return userList;
    }

    /**
     * 获取资金流水总数（通过账户uuid和对手账户uuid账户筛选account_type）
     *
     * @param userMap 参数选填： accountTransactionUuid,accountUuidList,tradeTypeList,userUuidList,accountType,transactionTimeFrom,transactionTimeTo,accountNo,transactionChannel
     * @return
     * @throws BusinessException
     */
    @Override
    public Integer getTransactionCount(Map userMap) throws BusinessException {
        Integer result = accountTransactionMapper.getTransactionCount(userMap);
        return result;
    }

    @Override
    public List<AccountTransactionVO> getInvestorTransactionList(AccountTransactionDto dto) throws BusinessException{
        WhereCondition where = new WhereCondition();
        where.setCondiEx(" a.account_uuid = b.account_uuid AND a.user_uuid = i.user_uuid AND a.delete_flag != 1 ");
        where.setCondi("b.account_type", dto.getAccountType(), true);
        where.setCondi("i.investor_mobile", dto.getInvestorMobile(), true);
        if (DataUtils.isNotEmpty(dto.getTradeOrderBillCode())) {
            where.setCondiEx(" and (a.trade_order_bill_code = '" + dto.getTradeOrderBillCode() + "' or a.trade_order_bill_code_extend = '" + dto.getTradeOrderBillCode() + "' ) ");
        }
        if(DataUtils.isNotEmpty(dto.getTransactionTimeFrom())){
            where.setCondiEx(" and  a.transaction_time >= '"+dto.getTransactionTimeFrom()+"'");
        }
        if(DataUtils.isNotEmpty(dto.getTransactionTimeTo())){
            where.setCondiEx(" and  a.transaction_time <= '"+dto.getTransactionTimeTo()+"'");
        }
        String tradeType = dto.getTradeTypes();
        if (DataUtils.isNotEmpty(tradeType)) {
            List<String> tradeTypeList = Arrays.asList(tradeType.split("\\$\\$"));
            where.setInString("a.trade_type",tradeTypeList);
        }
        where.setPage(dto.getPageNo(),dto.getPageSize(),"a.transaction_time");
        return accountTransactionMapper.getInvestorTransactionList(where);
    }

}