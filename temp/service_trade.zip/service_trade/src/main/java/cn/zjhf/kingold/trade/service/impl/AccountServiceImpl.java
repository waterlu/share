package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.common.utils.MapUtils;
import cn.zjhf.kingold.trade.baofoo.BaofooAccountEnum;
import cn.zjhf.kingold.trade.client.ProductClient;
import cn.zjhf.kingold.trade.constant.*;
import cn.zjhf.kingold.trade.dto.BillDto;
import cn.zjhf.kingold.trade.dto.InvestAssetDto;
import cn.zjhf.kingold.trade.dto.TradeOrderProfitEverydayDto;
import cn.zjhf.kingold.trade.entity.*;
import cn.zjhf.kingold.trade.persistence.dao.*;
import cn.zjhf.kingold.trade.entity.ProfitEverydayRecord;
import cn.zjhf.kingold.trade.entity.AccountDO;
import cn.zjhf.kingold.trade.entity.TradeOrder;
import cn.zjhf.kingold.trade.entity.TradeRecharge;
import cn.zjhf.kingold.trade.exception.AccountBalanceException;
import cn.zjhf.kingold.trade.exception.AccountUnavailableException;
import cn.zjhf.kingold.trade.persistence.dao.AccountBaofooCustodyMapper;
import cn.zjhf.kingold.trade.persistence.dao.AccountMapper;
import cn.zjhf.kingold.trade.persistence.dao.AccountTransactionMapper;
import cn.zjhf.kingold.trade.persistence.dao.TradeRechargeMapper;
import cn.zjhf.kingold.trade.persistence.dao.*;
import cn.zjhf.kingold.trade.service.IAccountService;
import cn.zjhf.kingold.trade.service.IAccountTransactionService;
import cn.zjhf.kingold.trade.service.IPayService;
import cn.zjhf.kingold.trade.utils.DataUtils;
import cn.zjhf.kingold.trade.utils.DateUtil;
import cn.zjhf.kingold.trade.utils.MapParamUtils;
import cn.zjhf.kingold.trade.utils.ZJBuzzUtils;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.collections.map.HashedMap;
import com.google.common.collect.ImmutableList;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by wangxun on 2016/11/04.
 * Copyright by zjinv
 */
@Service
public class AccountServiceImpl implements IAccountService, InitializingBean {
    private static final Logger LOGGER = LoggerFactory.getLogger(AccountServiceImpl.class);

    @Autowired
    private IAccountTransactionService accountTransactionService;

    @Autowired
    private AccountBaofooCustodyMapper accountBaofooMapper;

    @Autowired
    private AccountMapper accountMapper;

    @Autowired
    private AccountTransactionMapper accountTransactionMapper;

    @Autowired
    private TradeRechargeMapper tradeRechargeMapper;

    @Autowired
    private TradeOrderMapper tradeOrderMapper;

    @Autowired
    private ProfitEverydayRecordMapper profitEverydayRecordMapper;

    @Autowired
    private IPayService payService;

    @Autowired
    private RedisTemplate redisTemplate;

    @Autowired
    private ProductClient productClient;

    @Autowired
    private TradePaymentSummaryMapper tradePaymentSummaryMapper;


    @Value("${system.run.model}")
    public String runModel;

    @Value("${app.admin.verify.code}")
    public String adminVerifyCode;


    /**
     * 平台托管资金账户
     */
    protected AccountDO platformRaiseAccount;

    private final static String YESTERDAY_PROFIT_KEY="trade_account_yesterday_profit";

    private final static Integer START_DATE = 20180330;



    public AccountServiceImpl() {
    }

    /**
     * 根据过滤条件查找账户信息
     *
     * @param params 参数选填：userUuid，accountType，accountUuid
     * @return
     * @throws BusinessException
     */
    @Override
    public Map getWithFilter(Map params) throws BusinessException {

        Map ui = accountMapper.get(params);
        if (ui == null || ui.isEmpty()) {
            throw new BusinessException(AccountStatusMsg.ACCOUNT_NOT_EXIST_CODE, AccountStatusMsg.ACCOUNT_NOT_EXIST, true);
        }

        return ui;
    }


    private Map get(Map params) throws BusinessException {

        Map ui = accountMapper.get(params);
        return ui;
    }

    /**
     * 插入账户表记录
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @Override
    public Map insert(Map params) throws BusinessException {
        String userPhone = MapParamUtils.getStringInMap( params,"userPhone");
        if (StringUtils.isNotBlank(userPhone)) {
            Map paramTemp = new HashMap();
            paramTemp.put("userPhone", userPhone);
            if (null != get(paramTemp)) {
//                throw new BusinessException(AccountStatusMsg.REGISTER_PHONE_IS_EXIST_CODE, AccountStatusMsg.REGISTER_PHONE_IS_EXIST,true);
            }
        }
        params.put("userUuid", UUID.randomUUID().toString().replace("-", ""));
        accountMapper.insert(params);

        return params;
    }

    /**
     * 更新账户表记录
     *
     * @param params 参数必填：accountUuid
     * @return
     * @throws BusinessException
     */
    @Override
    public int update(Map params) throws BusinessException {
        return accountMapper.update(params);
    }

    /**
     * 删除账户表记录
     *
     * @param params 参数必填：accountUuid
     * @return
     * @throws BusinessException
     */
    @Override
    public Integer delete(Map params) throws BusinessException {
        int num = accountMapper.delete(params);
        return num;
    }

    /**
     * 获取账户表列表
     *
     * @param userMap 参数必填：accountUuid，userUuid，accountType，accountStatus
     * @return
     * @throws BusinessException
     */
    @Override
    public List<Map> getList(Map userMap) throws BusinessException {

        List<Map> userList = accountMapper.getList(userMap);

        return userList;
    }

    /**
     * 获取账户表总数
     *
     * @param userMap 参数必填：accountUuid，userUuid，accountType，accountStatus
     * @return
     * @throws BusinessException
     */
    @Override
    public Integer getCount(Map userMap) throws BusinessException {
        Integer result = accountMapper.getCount(userMap);
        return result;
    }

    /**
     * 投资 认购
     *
     * 认购成功后，投资人钱转入平台托管户。
     *
     * @param userMap 必填项如下：orderCode,accountUuid，transactionAmount（负数）
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = {BusinessException.class, RuntimeException.class}, propagation = Propagation.REQUIRED)
    public int invest(Map userMap) throws BusinessException {
        //输入的金额必须小于0
        if(0 <= Double.parseDouble(userMap.get("transactionAmount").toString())){
            throw new BusinessException(AccountStatusMsg.TRANSACTION_AMOUNT_MUST_LESS_ZERO_CODE, AccountStatusMsg.TRANSACTION_AMOUNT_MUST_LESS_ZERO, true);
        }
        Map accountFullParams = new HashMap();
        String accountUuid = MapParamUtils.getStringInMap(userMap,"accountUuid");
        accountFullParams.put("accountUuid",accountUuid);
        Map investAccount = accountBaofooMapper.getBaofooAndAccount(accountFullParams);
        if(MapUtils.isEmpty(investAccount)){
            throw new BusinessException(AccountStatusMsg.ACCOUNT_NOT_EXIST_CODE, AccountStatusMsg.ACCOUNT_NOT_EXIST, true);
        }
        Map accountMap = new HashMap();
        accountMap.put("accountUuid", userMap.get("accountUuid"));
        Map accountResult = get(accountMap);
        if (accountResult == null || accountResult.get("accountCashAmount") == null) {
            throw new BusinessException(AccountStatusMsg.ACCOUNT_NOT_EXIST_CODE, AccountStatusMsg.ACCOUNT_NOT_EXIST, true);
        }
        LOGGER.info("获取平台托管账户");
        Map platformTGMap = getSysAccountByType(AccountType.ACCOUNT_TYPE_PLATFORM_TRUST);//获取平台
        if (Double.parseDouble(String.valueOf(accountResult.get("accountCashAmount"))) >= -Double.parseDouble(String.valueOf(userMap.get("transactionAmount")))) {
            LOGGER.info("投资金额小于等于可用余额");
            String orderCode =MapParamUtils.getStringInMap(userMap,"orderCode");
            Long fromAccountNo =MapParamUtils.getLongInMap(investAccount,"accountNo");
            Long toAccountNo = MapParamUtils.getLongInMap(platformTGMap,"accountNo");//转入平台托管户
            BigDecimal transactionAmount = MapParamUtils.getBigDecimalInMap(userMap,"transactionAmount");
            transactionAmount = transactionAmount.multiply(new BigDecimal(-1));//因为入参是负数，这里需要正数，所以进行处理
            String tradeType =TradeType.TRADE_INVEST;

//            BillDto billDto = new BillDto(orderCode,tradeType,transactionAmount,accountUuid);
            payment2Plant(orderCode, fromAccountNo, toAccountNo, transactionAmount, tradeType,MapParamUtils.getStringInMap(userMap,"orderBillCodeExtend"));

            return 1;//操作成功一条

        } else {
            throw new BusinessException(AccountStatusMsg.ACCOUNT_MONEY_NOT_ENOUGH_CODE, AccountStatusMsg.ACCOUNT_MONEY_NOT_ENOUGH, true);
        }

    }

    /**
     * 充值
     *
     * @param tradeRecharge
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = {BusinessException.class, RuntimeException.class})
    public int recharge(TradeRecharge tradeRecharge) throws BusinessException {
        LOGGER.info("更新账户余额和流水：" + tradeRecharge.getRechargeBillCode());
        //输入的金额必须大于0
        if(new BigDecimal(0).compareTo(tradeRecharge.getRechargeAmount()) >= 0){
            throw new BusinessException(AccountStatusMsg.TRANSACTION_AMOUNT_MUST_GREATER_ZERO_CODE, AccountStatusMsg.TRANSACTION_AMOUNT_MUST_GREATER_ZERO, true);
        }

        LOGGER.info("充值账户增加金额");
        Map rechargeAccountParams = new HashMap();
        rechargeAccountParams.put("accountUuid",tradeRecharge.getAccountUuid());
        rechargeAccountParams.put("transactionAmount",tradeRecharge.getRechargeAmount());
        accountMapper.recharge(rechargeAccountParams);

        Map accountParams = new HashMap();
        accountParams.put("accountUuid",tradeRecharge.getAccountUuid());
        Map accountTemp = accountMapper.get(accountParams);

        String personAccountNo =  MapParamUtils.getStringInMap(accountTemp,"accountNo");
        String personAccountUuid = tradeRecharge.getAccountUuid();
        Map rechargeAccountTransactionParams = new HashMap();
        rechargeAccountTransactionParams.put("accountUuid", personAccountUuid);
        rechargeAccountTransactionParams.put("accountNo", personAccountNo );
        BigDecimal transactionAmount = RechargeType.PLANTFORM_PAY == tradeRecharge.getRechargeFeeType() ?
                tradeRecharge.getRechargeAmount() : tradeRecharge.getRechargeAmount().add(tradeRecharge.getRechargeFee());
        rechargeAccountTransactionParams.put("transactionAmount", transactionAmount);
        rechargeAccountTransactionParams.put("tradeOrderBillCode", tradeRecharge.getRechargeBillCode());
        rechargeAccountTransactionParams.put("tradeOrderBillCodeExtend", tradeRecharge.getTradeOrderBillCodeExtend());
        rechargeAccountTransactionParams.put("tradeType", TradeType.TRADE_RE_CHARGE);
        LOGGER.info("插入 资金流水："+JSONObject.toJSONString(rechargeAccountTransactionParams));
        accountTransactionService.insert(rechargeAccountTransactionParams);


        if(RechargeType.PLANTFORM_PAY == tradeRecharge.getRechargeFeeType()){
            Map platformTGMap = getSysAccountByType(AccountType.ACCOUNT_TYPE_PLATFORM_SETTLEMENT);//获取平台

            LOGGER.info("托管账户扣除手续费");
            Map paymentParams = new HashMap();
            paymentParams.put("accountUuid",  MapParamUtils.getStringInMap(platformTGMap,"accountUuid"));
            paymentParams.put("amount",tradeRecharge.getRechargeFee());
            LOGGER.info("payment："+JSONObject.toJSONString(paymentParams));
            accountMapper.payment(paymentParams);

            LOGGER.info("托管账户扣除手续费流水");

            if (platformTGMap == null || platformTGMap.get("accountCashAmount") == null) {
                throw new BusinessException(AccountStatusMsg.REQUEST_PARAM_ERROR_CODE, AccountStatusMsg.REQUEST_PINGTAITUOGUAN_FAIL, true);
            }
            Map platformTGParams = new HashMap();
            platformTGParams.put("accountUuid", MapParamUtils.getStringInMap(platformTGMap,"accountUuid"));
            platformTGParams.put("accountNo",MapParamUtils.getStringInMap(accountTemp,"accountNo") );
            platformTGParams.put("transactionAmount", tradeRecharge.getRechargeFee().multiply(new BigDecimal(-1)));
            platformTGParams.put("tradeOrderBillCode", tradeRecharge.getRechargeBillCode());
            platformTGParams.put("tradeOrderBillCodeExtend", tradeRecharge.getTradeOrderBillCodeExtend());
            platformTGParams.put("tradeType", TradeType.TRADE_WITHDRAW_FACTORAGE);
            accountTransactionService.insert(platformTGParams);
        }
        if(RechargeType.PERSON_PAY == tradeRecharge.getRechargeFeeType()){
            LOGGER.info("个人账户模拟银行扣除手续费流水");
            Map personParams = new HashMap();
            personParams.put("accountUuid", personAccountUuid);
            personParams.put("accountNo",personAccountNo );
            personParams.put("transactionAmount", tradeRecharge.getRechargeFee().multiply(new BigDecimal(-1)));
            personParams.put("tradeOrderBillCode", tradeRecharge.getRechargeBillCode());
            personParams.put("tradeOrderBillCodeExtend", tradeRecharge.getTradeOrderBillCodeExtend());
            personParams.put("tradeType", TradeType.TRADE_WITHDRAW_FACTORAGE);
            accountTransactionService.insert(personParams);
        }
        return 1;

    }


    /**
     * 执行凭证操作（扣除冻结余额）
     *
     * @param tr 交易单据
     * @param tradeStatus 1: 成功， 2：失败
     * @param remark  描述
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = {BusinessException.class, RuntimeException.class})
    public int executeBill(TradeRecharge tr, byte tradeStatus,String remark) throws BusinessException {

        LOGGER.info(tr.getAccountUuid() + "执行凭证操作（扣除冻结余额）,结果：" + tradeStatus);
        int changeNum = 0;
        Map platformMap = getSysAccountByType(AccountType.ACCOUNT_TYPE_PLATFORM_SETTLEMENT);
        String platformAccountUuid = MapParamUtils.getStringInMap(platformMap, "accountUuid");
        String accountUuid = tr.getAccountUuid();
        BigDecimal amount = tr.getRechargeAmount();
        BigDecimal feeAmount = tr.getRechargeFee();

        if (TradeStatus.SUCCESS == tradeStatus) {
            LOGGER.info("执行 扣除提现金额");
            //扣除提现金额
            Map accountParams = new HashMap();
            accountParams.put("accountUuid", tr.getAccountUuid());
            accountParams.put("amount", amount);
            LOGGER.info("扣除提现金额:"+JSONObject.toJSONString(accountParams));
            changeNum = accountMapper.executeBill(accountParams);
            //扣除手续费金额
            if (PayMsg.FEE_TOKEN_ON_PERSON == Integer.parseInt(tr.getRechargeFeeType().toString())) { //个人支付
                accountParams.put("accountUuid", accountUuid);
                accountParams.put("amount", feeAmount);
                LOGGER.info("扣除个人手续费金额:"+JSONObject.toJSONString(accountParams));
                changeNum = accountMapper.executeBill(accountParams);
            } else if (PayMsg.FEE_TOKEN_ON_PLATFORM == Integer.parseInt(tr.getRechargeFeeType().toString())) {//平台支付
                accountParams.put("accountUuid", platformAccountUuid);
                accountParams.put("amount", feeAmount);
                LOGGER.info("扣除平台手续费金额:"+JSONObject.toJSONString(accountParams));
                changeNum = accountMapper.executeBill(accountParams);
            }
        } else if (TradeStatus.FAILURE == tradeStatus) {

            //记录失败凭证
            LOGGER.info("执行凭证失败,accountUuid:"+tr.getAccountUuid() );

            Map baofooParams = new HashMap();
            baofooParams.put("accountUuid", tr.getAccountUuid());
            Map accountBaofooMap = accountBaofooMapper.getBaofooAndAccount(baofooParams);

            //退回冻结资金
            Map accountParams = new HashMap();
            accountParams.put("accountUuid", accountUuid);
            accountParams.put("amount", amount);
            LOGGER.info("账户中退回冻结资金:"+JSONObject.toJSONString(accountParams));
            changeNum = accountMapper.cancelFreezeCash(accountParams);

            Map withdrawMap = new HashMap();
            withdrawMap.put("accountUuid", tr.getAccountUuid());
            withdrawMap.put("accountNo", MapParamUtils.getStringInMap(accountBaofooMap, "accountNo"));
            withdrawMap.put("transactionAmount", amount);
            withdrawMap.put("tradeType", TradeType.TRADE_EXECUTE_ERROR);
            withdrawMap.put("tradeOrderBillCode", tr.getRechargeBillCode());
            withdrawMap.put("tradeOrderUuid", tr.getTradeRechargeUuid());
            withdrawMap.put("remark", remark);
            LOGGER.info("记录退回冻结资金流水:"+JSONObject.toJSONString(withdrawMap));
            accountTransactionService.insert(withdrawMap);
            Map accountFeeParams = new HashMap();
            //退回手续费
            if (PayMsg.FEE_TOKEN_ON_PERSON == Integer.parseInt(tr.getRechargeFeeType().toString())) { //个人支付
                //记录失败凭证
                LOGGER.info("执行凭证失败（个人支付），accountUuid:" + tr.getAccountUuid());

                accountFeeParams.put("accountUuid", accountUuid);
                accountFeeParams.put("amount", feeAmount);
                LOGGER.info("退回手续费(个人支付):"+JSONObject.toJSONString(accountFeeParams));
                changeNum = accountMapper.cancelFreezeCash(accountFeeParams);

                Map feeMap = new HashMap();
                feeMap.put("accountUuid", accountUuid);
                feeMap.put("accountNo", MapParamUtils.getStringInMap(accountBaofooMap, "accountNo"));
                feeMap.put("transactionAmount", feeAmount);
                feeMap.put("tradeType", TradeType.TRADE_EXECUTE_ERROR);
                feeMap.put("tradeOrderBillCode", tr.getRechargeBillCode());
                feeMap.put("tradeOrderUuid", tr.getTradeRechargeUuid());
                feeMap.put("remark", remark);
                LOGGER.info("记录流水， 退回手续费(个人支付):"+JSONObject.toJSONString(feeMap));
                accountTransactionService.insert(feeMap);

            } else if (PayMsg.FEE_TOKEN_ON_PLATFORM == Integer.parseInt(tr.getRechargeFeeType().toString())) {//平台支付

                //记录失败凭证
                LOGGER.info("执行凭证失败(平台支付),accountUuid:"+tr.getAccountUuid());

                accountFeeParams.put("accountUuid", platformAccountUuid);
                accountFeeParams.put("amount", feeAmount);
                LOGGER.info("退回手续费(平台支付):"+JSONObject.toJSONString(accountFeeParams));
                changeNum = accountMapper.cancelFreezeCash(accountFeeParams);

                Map feeMap = new HashMap();
                feeMap.put("accountUuid", platformAccountUuid);
                feeMap.put("accountNo", MapParamUtils.getStringInMap(accountBaofooMap, "accountNo"));
                feeMap.put("transactionAmount", feeAmount);
                feeMap.put("tradeType", TradeType.TRADE_EXECUTE_ERROR);
                feeMap.put("tradeOrderBillCode", tr.getRechargeBillCode());
                feeMap.put("tradeOrderUuid", tr.getTradeRechargeUuid());
                feeMap.put("remark", remark);
                LOGGER.info("记录流水， 退回手续费(平台支付):"+JSONObject.toJSONString(feeMap));
                accountTransactionService.insert(feeMap);
            }

        } else {
            throw new BusinessException(AccountStatusMsg.REQUEST_PARAM_ERROR_CODE, "tradeStatus must TradeStatus.SUCCESS or TradeStatus.FAILURE", true);
        }
        //更新凭证状态
        tr.setRechargeStatus(tradeStatus);
        tr.setRechargeTime(new Date());
        LOGGER.info("更新凭证状态:"+JSONObject.toJSONString(tr));
        tradeRechargeMapper.update(tr);
        return changeNum;

    }

    /**
     * 执行冻结操作（取款金额放入冻结余额）
     * <p>
     * 记录取现流水 和 冻结资金
     *
     * @param params 单据
     * @return
     */
    @Override
    @Transactional(rollbackFor = {BusinessException.class, RuntimeException.class})
    public int freezeCashEntity(BillDto params) throws BusinessException {
        LOGGER.info(params.getAccountUuid() + "执行冻结操作（金额放入冻结余额）！");
        if(StringUtils.isBlank(params.getOrderBillCodeExtend())){
            params.setOrderBillCodeExtend(params.getBillCode());
        }
        //获取用户冗余信息，方便查询
        Map baofooParams = new HashMap();
        baofooParams.put("accountUuid", params.getAccountUuid());
        LOGGER.info("获取宝付账户信息："+ JSONObject.toJSONString(baofooParams));
        Map accountBaofooMap = accountBaofooMapper.getBaofooAndAccount(baofooParams);
//        Map userMap = investorRemoteService.getInvestorInfo(MapParamUtils.getStringInMap(accountBaofooMap,"userUuid"));

        Map withdrawMap = new HashMap();
        withdrawMap.put("accountUuid", params.getAccountUuid());
        withdrawMap.put("accountNo", MapParamUtils.getStringInMap(accountBaofooMap, "accountNo"));
        withdrawMap.put("transactionAmount", params.getAmount().multiply(new BigDecimal(-1)));
        withdrawMap.put("tradeType", params.getTradeType());
        withdrawMap.put("tradeOrderBillCode", params.getBillCode());
        if(DataUtils.isNotEmpty(params.getTransactionChannel())) {
            withdrawMap.put("transactionChannel", params.getTransactionChannel());
        }
//        withdrawMap.put("tradeOrderUuid", params.getBillUuid());
        LOGGER.info("插入 冻结金额 流水："+ JSONObject.toJSONString(withdrawMap));
        accountTransactionService.insert(withdrawMap);
        LOGGER.info("修改 冻结金额："+ JSONObject.toJSONString(withdrawMap));
        return accountMapper.freezeCash(params);
    }



    /**
     * 给托管账户转账
     *
     * @param orderCode 交易编码
     * @param fromAccountNo 宝付账户id（出钱方）
     * @param toAccountNo   宝付账户id（入钱方）
     * @param amount        转账金额
     * @param tradeType        交易类型（详见TradeType）
     * @param orderBillCodeExtend        宝付交易流水号,如果两条记录具有相同的orderBillCodeExtend，则表示是同一个宝付请求。
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = {BusinessException.class, RuntimeException.class})
    public void payment2Plant(String orderCode, long fromAccountNo, long toAccountNo, BigDecimal amount, String tradeType, String orderBillCodeExtend) throws BusinessException{
        LOGGER.info("给托管账户转账");
        if(StringUtils.isBlank(orderBillCodeExtend)){
            LOGGER.info("orderBillCodeExtend = orderCode");
            orderBillCodeExtend = orderCode;
        }

        Map baofooParams = new HashMap();
        baofooParams.put("accountNo", fromAccountNo);
        LOGGER.info("获取宝付和账户信息");
        Map accountBaofooMap = accountBaofooMapper.getBaofooAndAccount(baofooParams);
        //付款方扣钱
        String accountUuid = MapParamUtils.getStringInMap(accountBaofooMap,"accountUuid");
        BillDto params = new BillDto(orderCode, tradeType, amount, accountUuid,orderBillCodeExtend);

        // 判断扣减账户余额是否成功
        if(freezeCashEntity(params) <= 0) {
            throw new AccountUnavailableException();
        }

        //收款方加钱
        payment(orderCode,toAccountNo,amount.multiply(new BigDecimal(-1)),tradeType,orderBillCodeExtend);
    }


    /**
     * 转账
     * @param orderCode 交易编码
     * @param fromAccountNo 宝付账户id（出钱方）
     * @param toAccountNo   宝付账户id（入钱方）
     * @param amount        转账金额
     * @param tradeType        交易类型（详见TradeType）
     * @param orderBillCodeExtend 交易编码扩展
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = {BusinessException.class, RuntimeException.class})
    public void payment(String orderCode, long fromAccountNo, long toAccountNo, BigDecimal amount, String tradeType,String orderBillCodeExtend) throws BusinessException{
        //付款方扣钱
        LOGGER.info("付款方扣钱");
        payment(orderCode,fromAccountNo,amount  ,tradeType,orderBillCodeExtend);
        //收款方加钱
        LOGGER.info("收款方加钱");
        payment(orderCode,toAccountNo,amount.multiply(new BigDecimal(-1)),tradeType,orderBillCodeExtend);
    }

    /**
     * 批量转账（回款）
     *
     * @param orderCode 交易编码
     * @param fromAccountNo 宝付账户id（出钱方）
     * @param toAccountNoList   宝付账户id（入钱方）（多个）
     * @param amount        转账金额
     * @param tradeType        交易类型（详见TradeType）
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = {BusinessException.class, RuntimeException.class})
    public void paymentBatch(String orderCode, long fromAccountNo, List<Long> toAccountNoList, BigDecimal amount, String tradeType,String tradeOrderBillCodeExtend) throws BusinessException {
        if(StringUtils.isBlank(tradeOrderBillCodeExtend)){
            tradeOrderBillCodeExtend = orderCode;
        }
        for(Long toAccountNo : toAccountNoList){
            //付款方扣钱
            payment(orderCode,fromAccountNo,amount ,tradeType,tradeOrderBillCodeExtend);
            //收款方加钱
            payment(orderCode,toAccountNo,amount.multiply(new BigDecimal(-1)),tradeType,tradeOrderBillCodeExtend);
        }
    }

    /**
     * 付款、收款（资金转移）
     *
     * @param orderCode 订单编号
     * @param accountNo 用户
     * @param amount 资金数（正数）
     * @param tradeType 交易类型
     * @throws BusinessException
     */
    private void payment(String orderCode, long accountNo, BigDecimal amount, String tradeType,
                         String tradeOrderBillCodeExtend) throws BusinessException{

        if(StringUtils.isBlank(tradeOrderBillCodeExtend)){
            tradeOrderBillCodeExtend = orderCode;
        }
        Map baofooParams = new HashMap();
        baofooParams.put("accountNo", accountNo);
        Map accountBaofooMap = accountBaofooMapper.getBaofooAndAccount(baofooParams);

        String accountUuid = MapParamUtils.getStringInMap(accountBaofooMap,"accountUuid");
        Map withdrawMap = new HashMap();
        withdrawMap.put("accountUuid", accountUuid);
        withdrawMap.put("accountNo", accountNo);
        withdrawMap.put("transactionAmount", amount.multiply(new BigDecimal(-1)));
        withdrawMap.put("tradeType", tradeType);
        withdrawMap.put("tradeOrderBillCode", orderCode);
        withdrawMap.put("tradeOrderBillCodeExtend", tradeOrderBillCodeExtend);
        LOGGER.info("插入 资金流水："+JSONObject.toJSONString(withdrawMap));
        accountTransactionService.insert(withdrawMap);

        Map paymentParams = new HashMap();
        paymentParams.put("accountUuid", accountUuid);
        paymentParams.put("amount",amount);
        LOGGER.info("payment："+JSONObject.toJSONString(paymentParams));
        accountMapper.payment(paymentParams);
    }

    /**
     * 根据userId获取账户信息
     *
     * @param paramMap 参数必填：userId
     * @return
     * @throws BusinessException
     */
    @Override
    public Map getByUserId(Map paramMap) throws BusinessException {
        Map ui = accountMapper.getByUserId(paramMap);
        if (ui == null || ui.isEmpty()) {
            throw new BusinessException(AccountStatusMsg.ACCOUNT_NOT_EXIST_CODE, AccountStatusMsg.ACCOUNT_NOT_EXIST, true);
        }
        return ui;
    }

    /**
     * 获取用户特定账户
     *
     * @param accountType 11平台托管账户；12平台结算账户；41宝付清算账户',
     * @return
     */
    @Override
    public Map getSysAccountByType(String accountType) throws BusinessException {
        LOGGER.info("获取用户特定账户，accountType："+accountType);
        Map accountParams = new HashMap();
        accountParams.put("accountType", accountType);
        Map result = accountBaofooMapper.getBaofooAndAccount(accountParams);
        if (MapUtils.isEmpty(result)) {
            throw new BusinessException(AccountStatusMsg.REQUEST_PARAM_ERROR_CODE, AccountStatusMsg.REQUEST_PARAM_ERROR, true);
        }
        LOGGER.info("获取用户特定账户："+JSONObject.toJSONString(result));
        return result;
    }

    @Override
    public BigDecimal getPlatformAccountBalance() throws BusinessException {
        // 生产环境下，通过宝付接口读取结算账户余额
        if ("prod".equals(runModel)) {
            ResponseResult responseResult = payService.platformAccountQuery(BaofooAccountEnum.BASE_ACCOUNT);
            if(responseResult.isSuccessful()) {
                return (responseResult.getData() == null ? BigDecimal.ZERO : (BigDecimal)responseResult.getData());
            } else {
                LOGGER.error("payService query platform failed. code={}, msg={}", responseResult.getCode(), responseResult.getMsg());
                return BigDecimal.ZERO;
            }
        }

        // 测试环境下，直接读取账户余额
        Map platformMap = getSysAccountByType(AccountType.ACCOUNT_TYPE_PLATFORM_SETTLEMENT);
        BigDecimal accountCashAmount = MapParamUtils.getBigDecimalInMap(platformMap, "accountCashAmount");
        return accountCashAmount;
    }


    /**
     * 获取用户账户总资产结构
     * 总资产：定期理财+可用余额+冻结金额+持有中基金的总市值
     * 可用余额：用户虚拟账户中的余额
     * 冻结金额：定期产品交易确认中（未计息已付款）的金额（营销+投资）+提现中的金额
     * 投资金额：已经放款但是没有兑付的金额
     *
     * @param paramMap 参数选填：accountUuid，accountNo，userUuid，accountType，accountStatus
     * @return
     * @throws BusinessException
     */
    @Override
    public Map getAccountAssets(Map paramMap) throws BusinessException {
        LOGGER.info("getAccountAssets");
        //获取数据库账户资产信息
        Map accountBaofoo = accountBaofooMapper.getBaofooAndAccount(paramMap);
        if(MapUtils.isEmpty(accountBaofoo)){
            throw new BusinessException(AccountStatusMsg.ACCOUNT_NOT_EXIST_CODE,AccountStatusMsg.ACCOUNT_NOT_EXIST,true);
        }
        accountBaofoo.put("accountTotalInterests",accountBaofoo.get("accountAccumProfit"));
        accountBaofoo.put("accountTotalManage",0.0);

        //获取用户订单金额及信息，订单状态为（付款、计息、到期）的订单
        paramMap.put("orderStatusList", ImmutableList.of(BizDefine.ORDER_STATUS_CONFIRM, BizDefine.ORDER_STATUS_PRODUCT_INTEREST
                ,BizDefine.ORDER_STATUS_PRODUCT_END));
        List<InvestAssetDto> investAssetDtos = tradeOrderMapper.getInvestAsset(paramMap);

        BigDecimal accountFreezeAmount = MapParamUtils.getBigDecimalInMap(accountBaofoo, "accountFreezeAmount");
        BigDecimal interestTotal = new BigDecimal(0);
        BigDecimal accountTotalAssets = MapParamUtils.getBigDecimalInMap(accountBaofoo, "accountTotalAssets");

        //获取成立但是没有计息的产品uuid List
        Set<String> productUuidList = getProductUuidList();
        for (InvestAssetDto investAssetDto : investAssetDtos) {
            //冻结金额计算（账户冻结金额【提现+投资已付款但未放款】 + 红包冻结金额（投资现金券））
            Integer orderStatus = investAssetDto.getOrderStatus();
            if (orderStatus == BizDefine.ORDER_STATUS_CONFIRM && !productUuidList.contains(investAssetDto.getProductUuid())) {
                accountFreezeAmount = accountFreezeAmount.add(investAssetDto.getMarketingAmount());
                accountTotalAssets = accountTotalAssets.add(investAssetDto.getMarketingAmount());
            }
            //投资金额：1.订单计息和到期，2:订单状态为2&&该产品已经成立
            if (orderStatus == BizDefine.ORDER_STATUS_PRODUCT_INTEREST || orderStatus == BizDefine.ORDER_STATUS_PRODUCT_END ||
                    (orderStatus == BizDefine.ORDER_STATUS_CONFIRM && productUuidList.contains(investAssetDto.getProductUuid()))) {
                interestTotal = interestTotal.add(investAssetDto.getOrderAmount());
            }
        }
        //处理产品已经放款但是没有计息的订单，将投资额和红包金额转为投资资产
        accountBaofoo.put("accountFreezeAmount", accountFreezeAmount);
        accountBaofoo.put("accountTotalAssets", accountTotalAssets);
        accountBaofoo.put("accountInvestAssets", interestTotal);
        return accountBaofoo;
    }

    @Override
    public List<ProfitEverydayRecord> profitCollection(String userUuid, Integer startRow, Integer pageSize) throws BusinessException {
        Date now = new Date();
        Integer startDate = DateUtil.date2Int(now, -1 + (-startRow) + (-pageSize));
        Integer endDate = DateUtil.date2Int(now, -1 + (-startRow));
        if (endDate < START_DATE) {
            return Collections.EMPTY_LIST;
        }
        if (startDate < START_DATE) {
            startDate = START_DATE;
        }
        List<ProfitEverydayRecord> result = profitEverydayRecordMapper.getList(userUuid, startDate, endDate);
        //补充没有记录的数据
        Set<Integer> existDate = new HashSet<>();
        for (ProfitEverydayRecord profitEverydayRecord : result) {
            existDate.add(profitEverydayRecord.getProfitDate());
            profitEverydayRecord.setProfitAmount(profitEverydayRecord.getProfitAmount().setScale(2, BigDecimal.ROUND_DOWN));
        }
        for (int i = startRow; i < startRow + pageSize; i++) {
            Integer date = DateUtil.date2Int(now, -1 + (-i));
            if (date < START_DATE) {
                continue;
            }
            if (!existDate.contains(date)) {
                ProfitEverydayRecord profitEverydayRecord = initRecord(date, userUuid);
                result.add(profitEverydayRecord);
            }
        }
        Collections.sort(result);
        return result;
    }

    @Override
    public long profitCollectionCount(String userUuid) throws BusinessException {
        SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMdd");
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        long end = cal.getTimeInMillis();
        try {
            cal.setTime(sdf.parse(START_DATE.toString()));
        } catch (ParseException e) {
            LOGGER.error("parse time error.");
        }
        long start = cal.getTimeInMillis();
        return (end-start)/(1000*3600*24);
    }

    @Override
    public List<ProfitEverydayRecord> profitPaidList(String userUuid, Integer startRow, Integer pageSize) throws BusinessException {

        List<ProfitEverydayRecord> result = profitEverydayRecordMapper.getPaidProfitList(userUuid, startRow, pageSize);
        for (ProfitEverydayRecord profitEverydayRecord : result) {
            profitEverydayRecord.setProfitPaidAmount(profitEverydayRecord.getProfitPaidAmount().setScale(2, BigDecimal.ROUND_DOWN));
        }
        return result;
    }


    @Override
    public void yesterdayProfit() throws BusinessException {
        //全局单线程控制
        try {
            boolean notLock = redisTemplate.opsForValue().setIfAbsent(YESTERDAY_PROFIT_KEY, "");
            if (!notLock) {
                LOGGER.error("yesterdayProfit is running already.");
                return;
            }
            LOGGER.info("calculateEstimateProfit start.");
            calculateEstimateProfit();
            LOGGER.info("calculatePaidProfit start.");
            calculatePaidProfit();
        } catch (Exception e) {
            LOGGER.error("yesterdayProfit unknown error", e);
            throw e;
        } finally {
            redisTemplate.delete(YESTERDAY_PROFIT_KEY);
        }
    }

    private void calculateEstimateProfit() throws BusinessException {
        int count = accountMapper.clearYesterdayProfit();
        LOGGER.info("clear yesterday profit count. count={}", count);
        Integer yesterday = DateUtil.date2Int(new Date(), -1);
        List<TradeOrderProfitEverydayDto> result;
        int startRow = 0;
        int pageSize = 20;
        do {
            result = tradeOrderMapper.calculateYesterdayProfit(yesterday, startRow, pageSize);
            if (result == null || result.size() <= 0) {
                break;
            }
            try {

                List<ProfitEverydayRecord> profitEverydayRecords = buildProfitRecord(result, yesterday);
                for (ProfitEverydayRecord profitEverydayRecord : profitEverydayRecords) {
                    profitEverydayRecordMapper.insertOnDuplicateUpdateAmount(profitEverydayRecord);
                }
            } catch (Exception e) {
                LOGGER.error("profitEverydayRecordMapper batchInsert error , continue update account yesterdayProfit.", e);
            }
            for (TradeOrderProfitEverydayDto tradeOrderProfitEverydayDto : result) {
                Map<String, Object> accountParam = new HashMap<>();
                accountParam.put("userUuid", tradeOrderProfitEverydayDto.getUserUuid());
                accountParam.put("accountYesterdayProfit", tradeOrderProfitEverydayDto.getProfit().
                        setScale(4, BigDecimal.ROUND_DOWN));
                accountMapper.updateByUserUuid(accountParam);
            }
            startRow += pageSize;
        } while (result != null);


    }

    private void calculatePaidProfit() throws BusinessException {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.DATE, -1);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        Date startTime = calendar.getTime();
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        Date endTime = calendar.getTime();
        int startRow = 0;
        int pageSize = 20;
        List<String> paidProductUuids = tradePaymentSummaryMapper.
                calculateYesterdayPaidProfit(startTime, endTime);
        if (CollectionUtils.isEmpty(paidProductUuids)) {
            return;
        }
        List<TradeOrderProfitEverydayDto> everydayDtos;
        do {
            everydayDtos = tradeOrderMapper.calculateYesterdayPaidProfit(paidProductUuids, startRow, pageSize);
            for (TradeOrderProfitEverydayDto record : everydayDtos) {
                profitEverydayRecordMapper.insertOnDuplicateUpdatePaidAmount(buildPaidProfitRecord(record, DateUtil.date2Int(new Date(),-1)));
            }
            startRow += pageSize;
        }while (!CollectionUtils.isEmpty(everydayDtos));

    }

    private List<ProfitEverydayRecord> buildProfitRecord(List<TradeOrderProfitEverydayDto> tradeOrderProfitEverydayDtos, Integer date) {
        List<ProfitEverydayRecord> profitEverydayRecords = new ArrayList<>();
        for (TradeOrderProfitEverydayDto tradeOrderProfitEverydayDto : tradeOrderProfitEverydayDtos) {
            ProfitEverydayRecord profitEverydayRecord = new ProfitEverydayRecord();
            profitEverydayRecord.setUserUuid(tradeOrderProfitEverydayDto.getUserUuid());
            profitEverydayRecord.setProfitPaidAmount(new BigDecimal(0));
            profitEverydayRecord.setProfitAmount(tradeOrderProfitEverydayDto.getProfit().setScale(4, BigDecimal.ROUND_DOWN));
            profitEverydayRecord.setProfitDate(date);
            profitEverydayRecord.setProfitType(1);
            profitEverydayRecord.setCreateTime(new Date());
            profitEverydayRecord.setUpdateTime(new Date());
            profitEverydayRecords.add(profitEverydayRecord);
        }
        return profitEverydayRecords;
    }

    private ProfitEverydayRecord buildPaidProfitRecord(TradeOrderProfitEverydayDto tradeOrderProfitEverydayDto, Integer date) {
        ProfitEverydayRecord profitEverydayRecord = new ProfitEverydayRecord();
        profitEverydayRecord.setUserUuid(tradeOrderProfitEverydayDto.getUserUuid());
        profitEverydayRecord.setProfitPaidAmount(tradeOrderProfitEverydayDto.getProfit().setScale(4, BigDecimal.ROUND_DOWN));
        profitEverydayRecord.setProfitAmount(new BigDecimal(0));
        profitEverydayRecord.setProfitDate(date);
        profitEverydayRecord.setProfitType(1);
        profitEverydayRecord.setCreateTime(new Date());
        profitEverydayRecord.setUpdateTime(new Date());
        return profitEverydayRecord;
    }

    private ProfitEverydayRecord initRecord(Integer date, String userUuid) {
        ProfitEverydayRecord profitEverydayRecord = new ProfitEverydayRecord();
        profitEverydayRecord.setUserUuid(userUuid);
        profitEverydayRecord.setProfitAmount(new BigDecimal(0.00).setScale(2, BigDecimal.ROUND_DOWN));
        profitEverydayRecord.setProfitDate(date);
        profitEverydayRecord.setProfitType(1);
        return profitEverydayRecord;
    }


    /**
     * 投资扣款接口
     *
     * @param tradeOrder
     * @return
     * @throws BusinessException
     */
    @Override
//    @Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRES_NEW)
    public int invest(TradeOrder tradeOrder) throws BusinessException {
        String orderCode = tradeOrder.getOrderBillCode();
        String tradeType =TradeType.TRADE_INVEST;
        BigDecimal amount = tradeOrder.getPaidAmount();
        String accountUuid = tradeOrder.getAccountUuid();
        String orderBillCodeExtend = tradeOrder.getOrderBillCode();
        String userUuid = tradeOrder.getUserUuid();
        String accountType = tradeOrder.getAccountType();

        LOGGER.info("account[{}] invest [{}]", accountUuid, amount);

        // 扣减现金余额
        BillDto params = new BillDto(orderCode, tradeType, amount, accountUuid, orderBillCodeExtend);
        int row = accountMapper.freezeCash(params);
        if(row <= 0) {
            // 判断扣减账户余额是否成功
            LOGGER.error("冻结余额失败");
            throw new BusinessException(TradeStatusMsg.FREEZE_ACCOUNT_CASH_FAILED, TradeStatusMsg.FREEZE_ACCOUNT_CASH_FAILED_TXT);
        }

        // 记录流水
        Map transactionMap = new HashMap(16);
        transactionMap.put("accountUuid", accountUuid);
        transactionMap.put("accountNo", tradeOrder.getAccountNo());
        transactionMap.put("transactionAmount", BigDecimal.ZERO.subtract(amount));
        transactionMap.put("tradeType", tradeType);
        transactionMap.put("tradeOrderBillCode", orderCode);
        transactionMap.put("transactionChannel", tradeOrder.getTransactionChannel());
        transactionMap.put("transactionBillCode", ZJBuzzUtils.generateOrderBillCode(tradeType));
        transactionMap.put("accountTransactionUuid", UUID.randomUUID().toString().replace("-", ""));
        transactionMap.put("accountType",accountType );
        transactionMap.put("userUuid", userUuid);
        accountTransactionMapper.insert(transactionMap);

        return row;
    }

    /**
     * 投资募集接口
     *
     * @param tradeOrder
     * @return
     * @throws BusinessException
     */
    @Override
    public int raise(TradeOrder tradeOrder, String orderBillCodeExtend) throws BusinessException {
        String orderCode = tradeOrder.getOrderBillCode();
        BigDecimal amount = tradeOrder.getOrderAmount();
        String tradeType = TradeType.TRADE_INVEST;

        if (StringUtils.isBlank(orderBillCodeExtend)) {
            orderBillCodeExtend = orderCode;
        }

        // 固定放入平台募集资金账户
        String accountType = platformRaiseAccount.getAccountType();
        Long toAccountNo = platformRaiseAccount.getAccountNo();
        String accountUuid = platformRaiseAccount.getAccountUuid();
        String userUuid = platformRaiseAccount.getUserUuid();

        LOGGER.info("account[{}] raise [{}]", accountUuid, amount);

        // 增加募集资金
        Map paymentParams = new HashMap(8);
        paymentParams.put("accountUuid", accountUuid);
        paymentParams.put("amount",amount);
        int row = accountMapper.raiseCash(paymentParams);

        // 写募集流水
        Map params = new HashMap(16);
        params.put("accountUuid", accountUuid);
        params.put("accountNo", toAccountNo);
        params.put("transactionAmount", amount);
        params.put("tradeType", tradeType);
        params.put("tradeOrderBillCode", orderCode);
        params.put("tradeOrderBillCodeExtend", orderBillCodeExtend);
        params.put("accountType", accountType);
        params.put("userUuid", userUuid);
        params.put("accountTransactionUuid", UUID.randomUUID().toString().replace("-", ""));
        params.put("transactionBillCode", ZJBuzzUtils.generateOrderBillCode(tradeType));
        accountTransactionMapper.insert(params);

        return row;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        LOGGER.info("获取平台资金托管账户");
        Map platformTGMap = getSysAccountByType(AccountType.ACCOUNT_TYPE_PLATFORM_TRUST);
        String accountType = AccountType.ACCOUNT_TYPE_PLATFORM_TRUST;
        Long accountNo = MapParamUtils.getLongInMap(platformTGMap, "accountNo");
        String accountUuid = MapParamUtils.getStringInMap(platformTGMap, "accountUuid");
        String userUuid = MapParamUtils.getStringInMap(platformTGMap, "userUuid");

        // 缓存平台资金托管账户信息
        platformRaiseAccount = new AccountDO();
        platformRaiseAccount.setAccountNo(accountNo);
        platformRaiseAccount.setAccountType(accountType);
        platformRaiseAccount.setAccountUuid(accountUuid);
        platformRaiseAccount.setUserUuid(userUuid);

        LOGGER.info("平台资金托管账户:[{}]", platformRaiseAccount);
    }

    private Set<String> getProductUuidList() throws BusinessException {
        Map<String, Object> param = new HashMap<>();
        param.put("productType", ProductType.PRODUCT_FT);
        param.put("productStatus", ImmutableList.of(5));
        param.put("properties", "productUuid");
        ResponseResult responseResult = productClient.getList(param);
        if (!responseResult.isSuccessful()) {
            return Collections.EMPTY_SET;
        }
        List<Map> productList = (List<Map>)responseResult.getData();
        Set<String> uuids = new HashSet<>();
        for (Map one : productList) {
            uuids.add(MapParamUtils.getStringInMap(one, "productUuid"));
        }
        return uuids;
    }
}