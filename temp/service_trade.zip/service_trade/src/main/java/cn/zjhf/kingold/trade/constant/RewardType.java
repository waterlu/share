package cn.zjhf.kingold.trade.constant;

/**
 * Created by lutiehua on 2017/5/27.
 */
public interface RewardType {
    /**
     * 奖励类别：1邀请奖励
     */
    int CATEGORY_REWARD = 1;

    /**
     * 奖励类别：2达人奖励
     */
    int CATEGORY_MASTER_REWARD = 2;

    /**
     * 奖励类别：9其他奖励
     */
    int CATEGORY_OTHER = 9;

    /**
     * 邀请奖励
     */
    int REWARD_SALE = 1;

    /**
     * 一度邀请津贴
      */
    int REWARD_INVITER_LEVEL_ONE = 2;

    /**
     * 二度邀请津贴
     */
    int REWARD_INVITER_LEVEL_TWO = 3;

    /**
     * 达人一度奖励
     */
    int REWARD_MASTER_INVITER_LEVEL_ONE = 11;

    /**
     * 达人二度奖励
     */
    int REWARD_MASTER_INVITER_LEVEL_TWO = 12;

    /**
     * 达人三度奖励
     */
    int REWARD_MASTER_INVITER_LEVEL_THREE = 13;

    /**
     * 服务津贴
     */
    int REWARD_SERVICE = 9;
}
