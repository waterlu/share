package cn.zjhf.kingold.trade.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author 
 */
public class ChannelCommisionDetail implements Serializable {
    /**
     * channel_commision_detail_id 自增长的20位数字
     */
    private Long channelCommisionDetailId;

    /**
     * UUID主键
     */
    private String productUuid;

    /**
     * 产品简称
     */
    private String productAbbrName;

    /**
     * 商户号，5位数字 （如：10001）
     */
    private String merchantNum;

    /**
     * APP名称/渠道名称
     */
    private String channelAppName;

    /**
     * 成交笔数
     */
    private Integer orderCount;

    /**
     * 有效成交笔数
     */
    private Integer validOrderCount;

    /**
     * 有效成交不结算笔数
     */
    private Integer validOrderUnsettleCount;

    /**
     * 募集金额
     */
    private BigDecimal raiseAmount;

    /**
     * 有效募集金额
     */
    private BigDecimal validRaiseAmount;

    /**
     * 有效成交不结算募集金额
     */
    private BigDecimal validRaiseUnsettleAmount;

    /**
     * 佣金
     */
    private BigDecimal commisionAmount;

    /**
     * 放款时间
     */
    private Date loanTime;

    /**
     * 结算状态：1未结算，2结算请求中，3已结算
     */
    private Byte settleStatus;

    /**
     * 删除标记 0未删除，1已删除
     */
    private Byte deleteFlag;

    private Date createTime;

    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public Long getChannelCommisionDetailId() {
        return channelCommisionDetailId;
    }

    public void setChannelCommisionDetailId(Long channelCommisionDetailId) {
        this.channelCommisionDetailId = channelCommisionDetailId;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductAbbrName() {
        return productAbbrName;
    }

    public void setProductAbbrName(String productAbbrName) {
        this.productAbbrName = productAbbrName;
    }

    public String getMerchantNum() {
        return merchantNum;
    }

    public void setMerchantNum(String merchantNum) {
        this.merchantNum = merchantNum;
    }

    public String getChannelAppName() {
        return channelAppName;
    }

    public void setChannelAppName(String channelAppName) {
        this.channelAppName = channelAppName;
    }

    public Integer getOrderCount() {
        return orderCount;
    }

    public void setOrderCount(Integer orderCount) {
        this.orderCount = orderCount;
    }

    public Integer getValidOrderCount() {
        return validOrderCount;
    }

    public void setValidOrderCount(Integer validOrderCount) {
        this.validOrderCount = validOrderCount;
    }

    public Integer getValidOrderUnsettleCount() {
        return validOrderUnsettleCount;
    }

    public void setValidOrderUnsettleCount(Integer validOrderUnsettleCount) {
        this.validOrderUnsettleCount = validOrderUnsettleCount;
    }

    public BigDecimal getRaiseAmount() {
        return raiseAmount;
    }

    public void setRaiseAmount(BigDecimal raiseAmount) {
        this.raiseAmount = raiseAmount;
    }

    public BigDecimal getValidRaiseAmount() {
        return validRaiseAmount;
    }

    public void setValidRaiseAmount(BigDecimal validRaiseAmount) {
        this.validRaiseAmount = validRaiseAmount;
    }

    public BigDecimal getValidRaiseUnsettleAmount() {
        return validRaiseUnsettleAmount;
    }

    public void setValidRaiseUnsettleAmount(BigDecimal validRaiseUnsettleAmount) {
        this.validRaiseUnsettleAmount = validRaiseUnsettleAmount;
    }

    public BigDecimal getCommisionAmount() {
        return commisionAmount;
    }

    public void setCommisionAmount(BigDecimal commisionAmount) {
        this.commisionAmount = commisionAmount;
    }

    public Date getLoanTime() {
        return loanTime;
    }

    public void setLoanTime(Date loanTime) {
        this.loanTime = loanTime;
    }

    public Byte getSettleStatus() {
        return settleStatus;
    }

    public void setSettleStatus(Byte settleStatus) {
        this.settleStatus = settleStatus;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}