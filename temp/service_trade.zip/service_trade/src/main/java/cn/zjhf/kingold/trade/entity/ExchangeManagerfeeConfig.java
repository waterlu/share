package cn.zjhf.kingold.trade.entity;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author 
 */
public class ExchangeManagerfeeConfig implements Serializable {
    /**
     * 交易所管理费用配置ID
     */
    private Long exchangeManagerfeeId;

    /**
     * 交易所管理费配置类型，1按照产品，2通用配置
     */
    private Byte exchangeManagerfeeType;

    /**
     * 产品UUID
     */
    private String productUuid;

    /**
     * 产品编码
     */
    private String productCode;

    /**
     * 产品类型
     */
    private String productType;

    /**
     * 产品简称
     */
    private String productAbbrName;

    /**
     * 指定产品类型, 如果已经指定了具体产品，则不再判断产品类型
     */
    private String appointProductType;

    /**
     * 费率
     */
    private BigDecimal feeRate;

    private static final long serialVersionUID = 1L;

    public Long getExchangeManagerfeeId() {
        return exchangeManagerfeeId;
    }

    public void setExchangeManagerfeeId(Long exchangeManagerfeeId) {
        this.exchangeManagerfeeId = exchangeManagerfeeId;
    }

    public Byte getExchangeManagerfeeType() {
        return exchangeManagerfeeType;
    }

    public void setExchangeManagerfeeType(Byte exchangeManagerfeeType) {
        this.exchangeManagerfeeType = exchangeManagerfeeType;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getProductAbbrName() {
        return productAbbrName;
    }

    public void setProductAbbrName(String productAbbrName) {
        this.productAbbrName = productAbbrName;
    }

    public String getAppointProductType() {
        return appointProductType;
    }

    public void setAppointProductType(String appointProductType) {
        this.appointProductType = appointProductType;
    }

    public BigDecimal getFeeRate() {
        return feeRate;
    }

    public void setFeeRate(BigDecimal feeRate) {
        this.feeRate = feeRate;
    }
}