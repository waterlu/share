package cn.zjhf.kingold.trade.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.dto.BillDto;
import cn.zjhf.kingold.trade.entity.ProfitEverydayRecord;
import cn.zjhf.kingold.trade.entity.TradeOrder;
import cn.zjhf.kingold.trade.entity.TradeRecharge;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by wangxun on 2016/11/04.
 * Copyright by zjinv
 */
public interface IAccountService {
    public Map getWithFilter(Map params) throws BusinessException;

    public Map insert(Map userInfo) throws BusinessException;

    public int update(Map userInfo) throws BusinessException;

    public Integer delete(Map params) throws BusinessException;

    List<Map> getList(Map userMap) throws BusinessException;

    Integer getCount(Map userMap) throws BusinessException;

    int freezeCashEntity(BillDto params) throws BusinessException;

    /**
     * 给托管账户转账
     *
     * @param orderCode 交易编码
     * @param fromAccountNo 宝付账户id（出钱方）
     * @param toAccountNo   宝付账户id（入钱方）
     * @param amount        转账金额
     * @param tradeType        交易类型（详见TradeType）
     * @param orderBillCodeExtend        宝付交易流水号,如果两条记录具有相同的orderBillCodeExtend，则表示是同一个宝付请求。
     * @throws BusinessException
     */
    void payment2Plant(String orderCode, long fromAccountNo, long toAccountNo, BigDecimal amount, String tradeType, String orderBillCodeExtend) throws BusinessException;

    /**
     * 转账
     *
     * @param orderCode 交易编码
     * @param fromAccountNo 宝付账户id（出钱方）
     * @param toAccountNo   宝付账户id（入钱方）
     * @param amount        转账金额
     * @param orderBillCodeExtend 宝付交易流水号,如果两条记录具有相同的orderBillCodeExtend，则表示是同一个宝付请求。
     * @throws BusinessException
     */
    void payment(String orderCode, long fromAccountNo, long toAccountNo, BigDecimal amount, String tradeType, String orderBillCodeExtend) throws BusinessException;

    /**
     * 批量转账（回款）
     *
     * @param orderCode 交易编码
     * @param fromAccountNo 宝付账户id（出钱方）
     * @param toAccountNoList   宝付账户id（入钱方）（多个）
     * @param amount            转账金额
     * @param tradeType         交易类型
     * @param tradeOrderBillCodeExtend 宝付交易流水号,如果两条记录具有相同的orderBillCodeExtend，则表示是同一个宝付请求。
     * @throws BusinessException
     */
    void paymentBatch(String orderCode, long fromAccountNo, List<Long> toAccountNoList, BigDecimal amount, String tradeType, String tradeOrderBillCodeExtend) throws BusinessException;

    Map getByUserId(Map paramMap) throws BusinessException;

    int invest(Map userMap) throws BusinessException;


    @Transactional(rollbackFor = {BusinessException.class, RuntimeException.class})
    int recharge(TradeRecharge tradeRecharge) throws BusinessException;

    /**
     * 执行或取消 提现操作。
     * TradeStatus.SUCCESS 成功
     * TradeStatus.FAILURE 失败
     *
     * @param tr
     * @param tradeStatus
     * @param remark
     *
     * @return
     * @throws BusinessException
     */
    int executeBill(TradeRecharge tr, byte tradeStatus, String remark) throws BusinessException;
    Map getSysAccountByType(String accountType) throws BusinessException;

    /**
     * 获取平台结算账户余额
     *
     * @return
     * @throws BusinessException
     */
    BigDecimal getPlatformAccountBalance() throws BusinessException;

    Map getAccountAssets(Map paramMap) throws BusinessException;

    void yesterdayProfit() throws BusinessException;

    List<ProfitEverydayRecord> profitCollection(String userUuid, Integer startRow, Integer pageSize) throws BusinessException;

    List<ProfitEverydayRecord> profitPaidList(String userUuid, Integer startRow, Integer pageSize) throws BusinessException;

    long profitCollectionCount(String userUuid) throws BusinessException;

    /**
     * 投资扣款接口
     *
     * @param tradeOrder
     * @return
     * @throws BusinessException
     */
    int invest(TradeOrder tradeOrder) throws BusinessException;

    /**
     * 平台募集账户加钱接口
     *
     * @param tradeOrder
     * @param orderBillCodeExtend
     * @return
     * @throws BusinessException
     */
    int raise(TradeOrder tradeOrder, String orderBillCodeExtend) throws BusinessException;
}