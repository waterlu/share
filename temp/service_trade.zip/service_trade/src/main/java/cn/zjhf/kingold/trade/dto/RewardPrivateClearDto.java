package cn.zjhf.kingold.trade.dto;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lutiehua on 2017/6/3.
 */
public class RewardPrivateClearDto {

    private int pass = 0;

    private String operator = null;

    private String remark = null;

    private double paymentAmount = 0;

    private List<String> rewardCodeList = new ArrayList<>();

    public void addRewardCode(String rewordCode) {
        rewardCodeList.add(rewordCode);
    }

    public int getPass() {
        return pass;
    }

    public void setPass(int pass) {
        this.pass = pass;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public double getPaymentAmount() {
        return paymentAmount;
    }

    public void setPaymentAmount(double paymentAmount) {
        this.paymentAmount = paymentAmount;
    }

    public List<String> getRewardCodeList() {
        return rewardCodeList;
    }
}
