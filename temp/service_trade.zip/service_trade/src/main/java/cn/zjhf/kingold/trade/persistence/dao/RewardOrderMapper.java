package cn.zjhf.kingold.trade.persistence.dao;

import cn.zjhf.kingold.trade.entity.RewardOrder;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author lutiehua
 * @date 2018/3/21
 */
@Repository
public interface RewardOrderMapper {

    /**
     * 写入订单奖励记录
     *
     * @param rewardOrder
     * @return
     */
    int insert(RewardOrder rewardOrder);

    /**
     * 查询用户的订单奖励记录，按时间排序
     *
     * @param userUuid
     * @return
     */
    List<RewardOrder> query(String userUuid);

}
