package cn.zjhf.kingold.trade.entity.OutVO;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Size;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by DELL on 2017/5/18.
 */
@ApiModel(value = "TradeInvestSummaryListVO", description = "募集资金汇总列表")
public class TradeInvestSummaryListVO extends ParamVO {
    @ApiModelProperty(required = true, value = "总记录数")
    private int totalCount;

    @ApiModelProperty(required = true, value = "返回列表")
    private List<TradeInvestSummaryVO> items;

    public TradeInvestSummaryListVO() {
        totalCount = 0;
        items = new ArrayList<TradeInvestSummaryVO>();
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public List<TradeInvestSummaryVO> getItems() {
        return items;
    }

    public void setItems(List<TradeInvestSummaryVO> items) {
        this.items = items;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("totalCount:" + DataUtils.toString(totalCount) + ", ");
        sb.append("items:" + DataUtils.toString(items));
        return sb.toString();
    }
}
