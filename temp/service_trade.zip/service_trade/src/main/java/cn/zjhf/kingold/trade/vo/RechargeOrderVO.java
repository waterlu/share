package cn.zjhf.kingold.trade.vo;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.trade.utils.DataUtils;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Size;

/**
 * Created by lutiehua on 2017/5/11.
 */
public class RechargeOrderVO extends ParamVO {
    @NotEmpty
    @Size(min = 32, max = 32)
    private String userUUID;

    @NotEmpty
    @Size(min = 11, max = 16)
    private String userPhone;

    @NotEmpty
    @Size(min = 32, max = 32)
    private String accountUUID;

    @NotEmpty
    private String agencyAccountNo;

    private String transactionChannel;

    private String tradeOrderBillCodeExtend;

    private String accountType;

    private Integer payMethod;


    @DecimalMin(value = "0")
    @DecimalMax(value = "1000000000000")
    private double amount;

    private String belongTopUserUuid;
    private String belongTopOrgPath;

    private String belongMerchantNum;

    public String getBelongTopUserUuid() {
        return belongTopUserUuid;
    }

    public void setBelongTopUserUuid(String belongTopUserUuid) {
        this.belongTopUserUuid = belongTopUserUuid;
    }

    public String getBelongTopOrgPath() {
        return belongTopOrgPath;
    }

    public void setBelongTopOrgPath(String belongTopOrgPath) {
        this.belongTopOrgPath = belongTopOrgPath;
    }

    public String getUserUUID() {
        return userUUID;
    }

    public void setUserUUID(String userUUID) {
        this.userUUID = userUUID;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    public String getAccountUUID() {
        return accountUUID;
    }

    public void setAccountUUID(String accountUUID) {
        this.accountUUID = accountUUID;
    }

    public String getAgencyAccountNo() {
        return agencyAccountNo;
    }

    public void setAgencyAccountNo(String agencyAccountNo) {
        this.agencyAccountNo = agencyAccountNo;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getTradeOrderBillCodeExtend() {
        return tradeOrderBillCodeExtend;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public void setTradeOrderBillCodeExtend(String tradeOrderBillCodeExtend) {
        this.tradeOrderBillCodeExtend = tradeOrderBillCodeExtend;
    }

    public String getTransactionChannel() {
        return transactionChannel;
    }

    public void setTransactionChannel(String transactionChannel) {
        this.transactionChannel = transactionChannel;
    }

    public String getBelongMerchantNum() {
        return belongMerchantNum;
    }

    public void setBelongMerchantNum(String belongMerchantNum) {
        this.belongMerchantNum = belongMerchantNum;
    }

    public Integer getPayMethod() {
        return payMethod;
    }

    public void setPayMethod(Integer payMethod) {
        this.payMethod = payMethod;
    }

    @Override
    public String toString() {
        return "RechargeOrderVO{" +
                "userUUID='" + userUUID + '\'' +
                ", userPhone='" + userPhone + '\'' +
                ", accountUUID='" + accountUUID + '\'' +
                ", agencyAccountNo='" + agencyAccountNo + '\'' +
                ", transactionChannel='" + transactionChannel + '\'' +
                ", tradeOrderBillCodeExtend='" + tradeOrderBillCodeExtend + '\'' +
                ", accountType='" + accountType + '\'' +
                ", amount=" + amount +
                ", belongTopUserUuid='" + belongTopUserUuid + '\'' +
                ", belongTopOrgPath='" + belongTopOrgPath + '\'' +
                ", belongMerchantNum='" + belongMerchantNum + '\'' +
                '}';
    }
}
