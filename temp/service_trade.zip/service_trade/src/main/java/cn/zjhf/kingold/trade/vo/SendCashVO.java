package cn.zjhf.kingold.trade.vo;

import java.math.BigDecimal;

/**
 * @author xiexiaojie
 *         2018/4/26.
 */
public class SendCashVO {
    /**
     * 提现金额
     */
    private BigDecimal sendCashAmount;
    /**
     * 1.提现;2.全部提现
     */
    private Integer sendType;
    /**
     * 提现条数
     */
    private Integer sendCount;
    /**
     * 用户UUID
     */
    private String userUuid;

    public BigDecimal getSendCashAmount() {
        return sendCashAmount;
    }

    public void setSendCashAmount(BigDecimal sendCashAmount) {
        this.sendCashAmount = sendCashAmount;
    }

    public Integer getSendType() {
        return sendType;
    }

    public void setSendType(Integer sendType) {
        this.sendType = sendType;
    }

    public Integer getSendCount() {
        return sendCount;
    }

    public void setSendCount(Integer sendCount) {
        this.sendCount = sendCount;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    @Override
    public String toString() {
        return "SendCashVO{" +
                "sendCashAmount=" + sendCashAmount +
                ", sendType=" + sendType +
                ", sendCount=" + sendCount +
                ", userUuid='" + userUuid + '\'' +
                '}';
    }
}
