package cn.zjhf.kingold.trade.utils;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by wangxun on 2016/11/16 0016.
 */
public class MybatisParamUtils {
    private static final Logger LOGGER = LoggerFactory.getLogger(MybatisParamUtils.class);
    public  static  void disposeInsertRequestMap(Map<String,String> requestMap){
        if(requestMap != null){
            List<String> removeKey = new ArrayList();
            for(String key : requestMap.keySet()){

                if(requestMap.get(key) == null || !(requestMap.get(key) instanceof String)  || requestMap.get(key).trim().equals("")){
                    removeKey.add(key);
                }
            }

            for(String key : removeKey){
                requestMap.remove(key);
            }
        }

    }

    /**
     * 清空 字段是int/timestamp类型，但是传入数据是“”的字段。
     * @param requestMap
     * @param requestClazzType
     */
    public  static  void disposeUpdateRequestMap(Map requestMap,Map<String,String> requestClazzType){
        if(requestMap != null && requestClazzType != null ){
            List<String> intColumeKey = new ArrayList();
            List<String> timestampColumeKey = new ArrayList();
            for(Object keyTemp : requestMap.keySet()){

                if(! (requestMap.get(keyTemp) instanceof String)){
                    continue;
                }
                String key = (String)keyTemp;

                String clazzType = requestClazzType.get(key);
                String value = (String)requestMap.get(key);

                if(StringUtils.isNotBlank(clazzType) && StringUtils.isBlank(value)){
                    if(clazzType.equals("int")){
                        intColumeKey.add(key);
                    }
                    else if (clazzType.equals("timestamp") && ( StringUtils.isBlank(value)) || value.length()<10){
                        LOGGER.error(requestMap.toString());
                        LOGGER.error("value:"+value+",is null or length < 10,so  set value=1970-01-01 !");
                        timestampColumeKey.add(key);
                    }
                }
            }

            for(String key : intColumeKey){
                requestMap.put(key, "null");
            }
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            for(String key : timestampColumeKey){
                requestMap.put(key, "null");
            }
        }

    }

}
