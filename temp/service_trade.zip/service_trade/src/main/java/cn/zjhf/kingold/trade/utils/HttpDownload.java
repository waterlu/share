package cn.zjhf.kingold.trade.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import cn.zjhf.kingold.trade.service.impl.PayServiceImpl;
import com.google.common.collect.Lists;
import org.apache.http.*;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @Author liuyao
 * @Description
 * @Date Created in 18:59 2017/6/7
 */

public class HttpDownload {
    public static final int cache = 10 * 1024;
    private static final Logger LOGGER = LoggerFactory.getLogger(PayServiceImpl.class);

    /**
     * 根据url下载文件，保存到filepath中
     *
     * @param url
     * @return
     */
    public static String download(String fileName, String url, String merchantId, String terminalId, String requestParam, String sign) {
        String filepath;
        String os = System.getProperty("os.name");
        LOGGER.info("baofoo download excel.fileName={}, url={}, merchantId={}, terminalId={}, requestParam={}, sign={}",fileName,
                url, merchantId,terminalId,requestParam,sign);
        if (os.toLowerCase().startsWith("win")) {
            filepath = "F:\\tmp\\" + fileName;
        } else {
            filepath = "/tmp/" + fileName;
        }
        CloseableHttpClient closeHttpClient = HttpClients.createDefault();
        HttpPost httpPost = new HttpPost(url);
        List<NameValuePair> params = Lists.newArrayList();
        params.add(new BasicNameValuePair("merchant_id", merchantId));
        params.add(new BasicNameValuePair("terminal_id", terminalId));
        params.add(new BasicNameValuePair("requestParams", requestParam));
        params.add(new BasicNameValuePair("sign", sign));
        httpPost.setEntity(new UrlEncodedFormEntity(params, Consts.UTF_8));
        try {
            HttpResponse response = closeHttpClient.execute(httpPost);
            int stateCode = response.getStatusLine().getStatusCode();
            if (stateCode != 200) {
                return null;
            }
            HttpEntity entity = response.getEntity();
            InputStream is = entity.getContent();
            File file = new File(filepath);
            if (!file.exists()) {
                try {
                    file.createNewFile();
                } catch (IOException e) {
                    LOGGER.error("create file error.filepath={}", filepath, e);
                    return null;
                }
            }
            FileOutputStream fileout = new FileOutputStream(file);
            /**
             * 根据实际运行效果 设置缓冲区大小
             */
            byte[] buffer = new byte[cache];
            int ch = 0;
            while ((ch = is.read(buffer)) != -1) {
                fileout.write(buffer, 0, ch);
            }
            is.close();
            fileout.flush();
            fileout.close();
        } catch (Exception e) {
            LOGGER.error("unknown error. requestParams={}, sign={}", requestParam, sign, e);
            return null;
        }
        return filepath;
    }

}
