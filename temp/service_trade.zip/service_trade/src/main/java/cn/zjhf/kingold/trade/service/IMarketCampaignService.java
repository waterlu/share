package cn.zjhf.kingold.trade.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.dto.CoinSendConditionDto;
import cn.zjhf.kingold.trade.dto.CouponSendConditionDto;
import cn.zjhf.kingold.trade.dto.MarketCampaignDto;
import cn.zjhf.kingold.trade.entity.InVO.LstMarketCampaignConditionVO;
import cn.zjhf.kingold.trade.entity.InVO.MarketCampaignTriggerVO;
import cn.zjhf.kingold.trade.entity.InVO.MarketCampaignVO;
import cn.zjhf.kingold.trade.entity.OutVO.MarketCampaignItemListVO;
import cn.zjhf.kingold.trade.entity.TradeOrder;
import cn.zjhf.kingold.trade.utils.Tuple.TwoTuple;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

/**
 * Created by zhangyijie on 2017/7/5.
 */
public interface IMarketCampaignService {

    /**
     * 创建活动
     * @param marketCampaignVO
     * @return
     * @throws BusinessException
     */
    String establishMarketCampaign(MarketCampaignVO marketCampaignVO) throws BusinessException;

    /**
     * 自动状态刷新
     */
    void autoRefreshStatus();

    /**
     * 更新活动
     * @param marketCampaignVO
     * @return
     * @throws BusinessException
     */
    Boolean updateMarketCampaign(MarketCampaignVO marketCampaignVO) throws BusinessException;

    /**
     * 查询活动
     * @param lstCondition
     * @return
     * @throws BusinessException
     */
    MarketCampaignItemListVO lstMarketCampaign(LstMarketCampaignConditionVO lstCondition) throws BusinessException;

    /**
     * 查询单条活动
     * @param mcCode
     * @return
     * @throws BusinessException
     */
    MarketCampaignVO lstMarketCampaign(int mcCode) throws BusinessException;

    MarketCampaignVO getVaildMarketCampaign(Integer mcCode)throws BusinessException;

    /**
     * 触发活动
     * @param mcCode 场景编号
     * @param orderList 订单列表
     * @return 发送成功的用户手机列表
     * @throws BusinessException
     */
    List<String> marketCampaignTrigger(Integer mcCode, List<TradeOrder> orderList, Map<String, String> uuidPhoneNumMap) throws BusinessException;

    /**
     * 触发活动
     * @param conditionDto
     * @return
     * Integer 1成功；-1失败
     * String message
     * @throws BusinessException
     */
    TwoTuple<Integer, String> marketCampaignTrigger(CouponSendConditionDto conditionDto) throws BusinessException;

    /**
     * 礼券发放校验
     * @param conditionDto
     * @return
     * @throws BusinessException
     */
    Boolean checkCouponSend(CouponSendConditionDto conditionDto) throws BusinessException;

    /**
     * 活动兑换礼券校验
     * @param marketCampaignTriggerVO
     * @return
     * @throws BusinessException
     */
    void campaignExchangeCoupon(MarketCampaignTriggerVO marketCampaignTriggerVO)throws BusinessException;


    @Transactional(rollbackFor = {BusinessException.class, RuntimeException.class})
    void campaignCoin(int mcCode, String userUuid) throws BusinessException;

    /**
     * 金币发放校验
     * @param conditionDto
     * @return
     * @throws BusinessException
     */
    Boolean checkCoinSend(CoinSendConditionDto conditionDto) throws BusinessException;

    /**
     * 查询金币相关场景列表
     * @param marketCampaignDto
     * @return
     * @throws BusinessException
     */
    MarketCampaignItemListVO getMarketCampaignList(MarketCampaignDto marketCampaignDto) throws BusinessException;
}
