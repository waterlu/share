package cn.zjhf.kingold.trade.constant;


import cn.zjhf.kingold.common.exception.BusinessException;

/**
 * Created by liuyao on 2017/7/11.
 */
public enum MarketCampaignStatusEnum {
    PREPARE(1, "未开始"), RUNNING(2, "进行中"), END(3, "已结束");
    private Integer code;
    private String msg;

    MarketCampaignStatusEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public static MarketCampaignStatusEnum getCampaignCodeEnum(Integer code) throws BusinessException {
        for (MarketCampaignStatusEnum paramEnum: MarketCampaignStatusEnum.values()) {
            if(paramEnum.getCode().equals(code)) {
                return paramEnum;
            }
        }
        throw new BusinessException(-1, "no enum match");
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
