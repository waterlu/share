package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.service_consumer.service.UserServiceConsumer;
import cn.zjhf.kingold.trade.constant.URL;
import cn.zjhf.kingold.trade.service.IUserService;
import org.apache.xmlbeans.impl.xb.xsdschema.Public;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * 用户实现类
 * <p>
 * Created by xiexiaojie on 2017/12/25.
 */
@Service
public class UserServiceImpl implements IUserService{

    private final Logger LOGGER = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    private UserServiceConsumer userServiceConsumer;

    @Override
    public String getInviterUuid(String userUuid) throws BusinessException {
        Map params = new HashMap();
        params.put("userUuid", userUuid);
        ResponseResult result = userServiceConsumer.get(String.format(URL.URL_GET_USER, userUuid), params);
        if (result.isSuccessful()) {
            Map<String, Object> userInfo = (Map)result.getData();
            return userInfo.get("inviterUuid") == null ? null : userInfo.get("inviterUuid").toString();
        } else if (result.getCode() == 1109) {//用户被冻结
            LOGGER.error("sendCoupon first invest user freezing. userUuid={}", userUuid);
            return null;
        } else {
            LOGGER.error("getInviterUuid get user info error.resultCode={}, msg={}", result.getCode(), result.getMsg());
            throw new BusinessException(result.getCode(), result.getMsg(), true);
        }
    }
}
