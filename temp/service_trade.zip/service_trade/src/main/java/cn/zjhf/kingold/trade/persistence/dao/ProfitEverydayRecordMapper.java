package cn.zjhf.kingold.trade.persistence.dao;

import cn.zjhf.kingold.trade.entity.ProfitEverydayRecord;
import io.swagger.models.auth.In;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ProfitEverydayRecordMapper {
    int insert(ProfitEverydayRecord record);

    int insertOnDuplicateUpdateAmount(ProfitEverydayRecord record);

    int insertOnDuplicateUpdatePaidAmount(ProfitEverydayRecord record);

    int insertSelective(ProfitEverydayRecord record);

    List<ProfitEverydayRecord> getList(@Param("userUuid") String userUuid, @Param("startDate") Integer startDate,
                                       @Param("endDate") Integer endDate);

    List<ProfitEverydayRecord> getPaidProfitList(@Param("userUuid") String userUuid, @Param("startRow") Integer startRow,
                                       @Param("pageSize") Integer pageSize);
}