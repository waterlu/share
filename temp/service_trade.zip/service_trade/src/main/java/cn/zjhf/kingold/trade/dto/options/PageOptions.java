package cn.zjhf.kingold.trade.dto.options;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.trade.utils.DataUtils;

/**
 * PageableOptions.
 */
public class PageOptions extends ParamVO{
    private static final Integer DEFAULT_PAGING_SIZE = 20;
    private static final Integer DEFAULT_PAGING_START = 1;
    private static final String DEFAULT_ORDER_BY = "create_time";

    //默认排序规则
    public static final String DEFAULT_ORDERBY = "DEFAULT_ORDERBY";

    /**
     * 分页的页数
     */
    private Integer pageNo;
    /**
     * 每页显示数量
     */
    private Integer pageSize;
    /**
     * 排序字段
     */
    private String orderBy;
    /**
     * 升序/降序
     * ASC/DESC
     */
    private String sort;

    public Integer getPageNo() {
        return pageNo;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public String getOrderBy() {
        return orderBy;
    }

    public void setOrderBy(String orderBy) {
        this.orderBy = orderBy;
    }

    public String getSort() {
        return sort;
    }

    public void setSort(String sort) {
        this.sort = sort;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("pageNo:" + DataUtils.toString(pageNo) + ", ");
        sb.append("pageSize:" + DataUtils.toString(pageSize) + ", ");
        sb.append("orderBy:" + DataUtils.toString(orderBy) + ", ");
        sb.append("sort:" + DataUtils.toString(sort));
        return sb.toString();
    }
}
