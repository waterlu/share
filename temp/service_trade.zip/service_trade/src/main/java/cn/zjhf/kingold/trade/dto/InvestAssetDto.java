package cn.zjhf.kingold.trade.dto;

import java.math.BigDecimal;

/**
 * @author liuyao
 * @date 2018/3/19
 */
public class InvestAssetDto {
    private String userUuid;
    private BigDecimal orderAmount;
    private BigDecimal marketingAmount;
    private String productUuid;
    private Integer orderStatus;


    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public BigDecimal getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(BigDecimal orderAmount) {
        this.orderAmount = orderAmount;
    }

    public BigDecimal getMarketingAmount() {
        return marketingAmount;
    }

    public void setMarketingAmount(BigDecimal marketingAmount) {
        this.marketingAmount = marketingAmount;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public Integer getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(Integer orderStatus) {
        this.orderStatus = orderStatus;
    }
}
