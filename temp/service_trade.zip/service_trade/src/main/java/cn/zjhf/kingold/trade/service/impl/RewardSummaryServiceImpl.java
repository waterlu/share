package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.baofoo.BaofooAccountEnum;
import cn.zjhf.kingold.trade.constant.*;
import cn.zjhf.kingold.trade.dto.*;
import cn.zjhf.kingold.trade.entity.Reward;
import cn.zjhf.kingold.trade.entity.RewardFixedTerm;
import cn.zjhf.kingold.trade.persistence.dao.AccountMapper;
import cn.zjhf.kingold.trade.persistence.dao.RewardFixedTermMapper;
import cn.zjhf.kingold.trade.persistence.dao.RewardMapper;
import cn.zjhf.kingold.trade.service.IAccountService;
import cn.zjhf.kingold.trade.service.IPayService;
import cn.zjhf.kingold.trade.service.IRewardSummaryService;
import cn.zjhf.kingold.trade.service.*;
import cn.zjhf.kingold.trade.utils.MapParamUtils;
import cn.zjhf.kingold.trade.utils.ZJBuzzUtils;
import cn.zjhf.kingold.trade.vo.RewardBatchInfoVO;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;

/**
 * @author lutiehua
 * @date 2017/6/2
 */
@Service
public class RewardSummaryServiceImpl implements IRewardSummaryService {

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private RewardFixedTermMapper rewardFixedTermMapper;

    @Autowired
    private RewardMapper rewardMapper;

    @Autowired
    private AccountMapper accountMapper;

    @Autowired
    private IAccountService accountService;

    @Autowired
    private IPayService payService;

    @Autowired
    private IRewardSummaryExecService rewardSummaryExecService;

    @Value("${system.run.model}")
    public String runModel;

    /**
     * 申请生成定期产品奖励的结算列表（按照用户+时间段汇总）
     *
     * @param rewardApplyDto
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = BusinessException.class)
    public ResponseResult applyFixedAward(RewardApplyDto rewardApplyDto) throws BusinessException {
        LOGGER.info("======== Generating reward summary for fixed term product is started ========");
        LOGGER.info("开始日期:{}", rewardApplyDto.getStartDate());
        LOGGER.info("截止日期:{}", rewardApplyDto.getEndDate());
        ResponseResult responseResult = new ResponseResult();

        // 传过来的是[]，查询的时候是[)，所以加一天
        // 存储的时候还是[]
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(rewardApplyDto.getEndDate());
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        Date endDate = calendar.getTime();
        LOGGER.info("查询截止日期:{}", endDate);

        // 加载奖励数据
        LOGGER.info("加载时间段内的所有奖励记录数据");
        RewardSearchDto searchCondition = new RewardSearchDto();
        // 必须是定期产品产生的奖励
        searchCondition.setProductType(ProductType.PRODUCT_FT);
        // 开始时间
        searchCondition.setFromCreateTime(rewardApplyDto.getStartDate());
        // 结束时间
        searchCondition.setToCreateTime(endDate);
        // 必须是有效的、状态不能是已结算
        // 状态 !=2 的目的是显示错误信息

        //来自渠道方的订单不做奖励结算
        //List<Reward> rewardList = rewardMapper.searchEnableReward(searchCondition);
        List<Reward> rewardList = rewardMapper.searchEnableFixedReward(searchCondition.getFromCreateTime(), searchCondition.getToCreateTime());

        if (rewardList.size() == 0) {
            // 没有数据，不用汇总
            LOGGER.error("没有有效的奖励记录");
            responseResult.setCode(RewardError.EMPTY_DATA);
            responseResult.setMsg(RewardError.EMPTY_DATA_TXT);
            return responseResult;
        }

        // 检查时间段内所有奖励是否都是待结算状态
        LOGGER.info("检查时间段内所有奖励是否都是待结算状态");
        List<Reward> errorRewardList = new ArrayList<>();
        for (Reward reward : rewardList) {
            if (reward.getRewardStatus() != RewardStatus.UNPAID) {
                errorRewardList.add(reward);
            }
        }

        if (errorRewardList.size() > 0) {
            StringBuffer buffer = new StringBuffer(RewardError.FOUND_INIT_REWARD_TXT);
            for(Reward reward : errorRewardList) {
                buffer.append("<br/>");
                buffer.append(reward.getRewardBillCode());
            }
            String errorMessage = buffer.toString();
            LOGGER.error(errorMessage);
            responseResult.setCode(RewardError.FOUND_INIT_REWARD);
            responseResult.setMsg(errorMessage);
            return responseResult;
        }

        // 加载数据定期奖励结算数据
        LOGGER.info("加载时间段内的所有定期奖励结算数据");
        RewardFixedSearchDto rewardFixedSearchDto = new RewardFixedSearchDto();
        rewardFixedSearchDto.setStartDate(rewardApplyDto.getStartDate());
        rewardFixedSearchDto.setEndDate(rewardApplyDto.getEndDate());
        List<RewardFixedTerm> rewardFixedTermList = rewardFixedTermMapper.getRewardFixedList(rewardFixedSearchDto);

        // 检查奖励明细是否已经被汇总过
        List<Reward> collidedRewardList = new ArrayList<>();
        for (Reward reward : rewardList) {
            if (StringUtils.isNotEmpty(reward.getSummaryBillCode())) {
                String rewardFixedBillCode = reward.getSummaryBillCode();
                RewardFixedTerm rewardFixedTermHit = null;
                for (RewardFixedTerm rewardFixedTerm : rewardFixedTermList) {
                    if (rewardFixedBillCode.equalsIgnoreCase(rewardFixedTerm.getRewardFixedBillCode())) {
                        rewardFixedTermHit = rewardFixedTerm;
                        break;
                    }
                }
                if (null != rewardFixedTermHit) {
                    // 已经汇总过，而且状态不是已作废，不能再次汇总
                    if (rewardFixedTermHit.getRewardFixedStatus() != RewardSummaryStatus.DELETE) {
                        collidedRewardList.add(reward);
                    }
                }
            }
        }

        if (collidedRewardList.size() > 0) {
            responseResult.setCode(RewardError.COLLIDED_REWARD);
            StringBuffer buffer = new StringBuffer(RewardError.COLLIDED_REWARD_TXT);
            buffer.append("<br/>");
            for(Reward reward : collidedRewardList) {
                LOGGER.error("存在奖励记录重复申请结算的情况：{},{}", reward.getRewardBillCode(), reward.getSummaryBillCode());
                buffer.append("奖励单：");
                buffer.append(reward.getRewardBillCode());
                buffer.append("|");
                buffer.append("汇总单：");
                buffer.append(reward.getSummaryBillCode());
                buffer.append("<br/>");
            }
            responseResult.setMsg(buffer.toString());
            return responseResult;
        }

        // 检查是否有用户已经生成过此时间的定期奖励汇总
        if (rewardFixedTermList.size() > 0) {
            LOGGER.info("检查是否有用户已经生成过此时间的定期奖励汇总");
            // 汇总这个时间段内所有包含有效奖励的用户
            Map<String, String> userMap = new HashMap<>();
            for (Reward reward : rewardList) {
                String userUuid = reward.getUserUuid();
                if (!userMap.containsKey(userUuid)) {
                    userMap.put(userUuid, userUuid);
                }
            }

            // 检查这些用户是否有结算时间段交叉的情况
            List<RewardSummaryCollideDto> collidedPeriodList = new ArrayList<>();
            for (RewardFixedTerm rewardFixedTerm : rewardFixedTermList) {
                String userUuid = rewardFixedTerm.getUserUuid();
                if (!userMap.containsKey(userUuid)) {
                    continue;
                }

                RewardSummaryCollideDto rewardFixedCollideDto = new RewardSummaryCollideDto(rewardFixedTerm);
                collidedPeriodList.add(rewardFixedCollideDto);
            }

            if (collidedPeriodList.size() > 0) {
                responseResult.setCode(RewardError.COLLIDED_PERIOD);
                StringBuffer buffer = new StringBuffer(RewardError.COLLIDED_PERIOD_TXT);
                buffer.append("<br/>");
                for(RewardSummaryCollideDto collideDto : collidedPeriodList) {
                    LOGGER.error("存在用户结算周期重叠的情况：{}", collideDto.getRewardBillCode());
                    buffer.append(collideDto.getUserMobile());
                    buffer.append("|");
                    buffer.append(collideDto.getRewardStartDate());
                    buffer.append("至");
                    buffer.append(collideDto.getRewardEndDate());
                    buffer.append("<br/>");
                }
                responseResult.setMsg(buffer.toString());
                return responseResult;
            }
        }

        // 生成批次号
        String batchCode = ZJBuzzUtils.generateOrderBillCode(TradeType.TRADE_REWARD_FIXED_SUMMARY_BATCH);
        LOGGER.info("批次号={}", batchCode);

        // 汇总定期奖励结算记录
        LOGGER.info("汇总定期奖励结算记录");
        Map<String, RewardFixedTerm> rewardMap = new HashMap<>();
        for (Reward reward : rewardList) {
            String userUuid = reward.getUserUuid();
            RewardFixedTerm rewardFixedTerm = null;
            if (rewardMap.containsKey(userUuid)) {
                rewardFixedTerm = rewardMap.get(userUuid);
            }
            if (null == rewardFixedTerm) {
                rewardFixedTerm = createRewardFixedTerm(reward, rewardApplyDto, batchCode);
                rewardMap.put(userUuid, rewardFixedTerm);
            }

            // 记录RewardBillCode
            rewardFixedTerm.addReward(reward);

            // 定期产品奖励没有服务津贴
            if (reward.getRewardType() == RewardType.REWARD_SALE) {
                BigDecimal saleAmount = rewardFixedTerm.getSaleAmount();
                saleAmount = saleAmount.add(reward.getRewardAmount());
                rewardFixedTerm.setSaleAmount(saleAmount);
            } else if (reward.getRewardType() == RewardType.REWARD_INVITER_LEVEL_ONE) {
                BigDecimal levelOneAmount = rewardFixedTerm.getLevelOneAmount();
                levelOneAmount = levelOneAmount.add(reward.getRewardAmount());
                rewardFixedTerm.setLevelOneAmount(levelOneAmount);
            } else if (reward.getRewardType() == RewardType.REWARD_INVITER_LEVEL_TWO) {
                BigDecimal levelTwoAmount = rewardFixedTerm.getLevelTwoAmount();
                levelTwoAmount = levelTwoAmount.add(reward.getRewardAmount());
                rewardFixedTerm.setLevelTwoAmount(levelTwoAmount);
            } else if (reward.getRewardType() == RewardType.REWARD_MASTER_INVITER_LEVEL_ONE) {
                BigDecimal masterOneAmount = rewardFixedTerm.getLevelTwoAmount();
                masterOneAmount = masterOneAmount.add(reward.getRewardAmount());
                rewardFixedTerm.setMasterOneAmount(masterOneAmount);
            } else if (reward.getRewardType() == RewardType.REWARD_MASTER_INVITER_LEVEL_TWO) {
                BigDecimal masterTwoAmount = rewardFixedTerm.getLevelTwoAmount();
                masterTwoAmount = masterTwoAmount.add(reward.getRewardAmount());
                rewardFixedTerm.setMasterTwoAmount(masterTwoAmount);
            } else if (reward.getRewardType() == RewardType.REWARD_MASTER_INVITER_LEVEL_THREE) {
                BigDecimal masterThreeAmount = rewardFixedTerm.getLevelTwoAmount();
                masterThreeAmount = masterThreeAmount.add(reward.getRewardAmount());
                rewardFixedTerm.setMasterThreeAmount(masterThreeAmount);
            }

            rewardFixedTerm.setRewardCount(rewardFixedTerm.getRewardCount() + 1);
            BigDecimal totalAmount = rewardFixedTerm.getTotalAmount();
            totalAmount = totalAmount.add(reward.getRewardAmount());
            rewardFixedTerm.setTotalAmount(totalAmount);
        }

        // 计算所得税
        LOGGER.info("计算所得税");
        for(RewardFixedTerm rewardFixedTerm : rewardMap.values()) {
            BigDecimal saleAmount = rewardFixedTerm.getSaleAmount();
            BigDecimal levelOneAmount = rewardFixedTerm.getLevelOneAmount();
            BigDecimal levelTwoAmount = rewardFixedTerm.getLevelTwoAmount();
            BigDecimal masterOneAmount = rewardFixedTerm.getMasterOneAmount();
            BigDecimal masterTwoAmount = rewardFixedTerm.getMasterTwoAmount();
            BigDecimal masterThreeAmount = rewardFixedTerm.getMasterThreeAmount();
            BigDecimal total = rewardFixedTerm.getTotalAmount();


            if(saleAmount != null) {
                saleAmount = saleAmount.setScale(BizConstant.CASH_FRACTION_COUNT, BigDecimal.ROUND_DOWN);
            }

            if(levelOneAmount != null) {
                levelOneAmount = levelOneAmount.setScale(BizConstant.CASH_FRACTION_COUNT, BigDecimal.ROUND_DOWN);
            }

            if(levelTwoAmount != null) {
                levelTwoAmount = levelTwoAmount.setScale(BizConstant.CASH_FRACTION_COUNT, BigDecimal.ROUND_DOWN);
            }

            if(masterOneAmount != null) {
                masterOneAmount = masterOneAmount.setScale(BizConstant.CASH_FRACTION_COUNT, BigDecimal.ROUND_DOWN);
            }

            if(masterTwoAmount != null) {
                masterTwoAmount = masterTwoAmount.setScale(BizConstant.CASH_FRACTION_COUNT, BigDecimal.ROUND_DOWN);
            }

            if(masterThreeAmount != null) {
                masterThreeAmount = masterThreeAmount.setScale(BizConstant.CASH_FRACTION_COUNT, BigDecimal.ROUND_DOWN);
            }

            total = total.setScale(BizConstant.CASH_FRACTION_COUNT, BigDecimal.ROUND_DOWN);

            rewardFixedTerm.setTotalAmount(total);
            rewardFixedTerm.setSaleAmount(saleAmount);
            rewardFixedTerm.setLevelOneAmount(levelOneAmount);
            rewardFixedTerm.setLevelTwoAmount(levelTwoAmount);
            rewardFixedTerm.setMasterOneAmount(masterOneAmount);
            rewardFixedTerm.setMasterTwoAmount(masterTwoAmount);
            rewardFixedTerm.setMasterThreeAmount(masterThreeAmount);

            BigDecimal tax = calculateTax(total);
            tax = tax.setScale(BizConstant.CASH_FRACTION_COUNT, BigDecimal.ROUND_DOWN);
            BigDecimal payment = total.subtract(tax);

            rewardFixedTerm.setTaxAmount(tax);
            rewardFixedTerm.setPayAmount(payment);

            LOGGER.info("total={}", total.doubleValue());
            LOGGER.info("tax={}", tax.doubleValue());
            LOGGER.info("payment={}", payment.doubleValue());
        }

        // 持久化到数据库
        LOGGER.info("持久化到数据库");
        for (RewardFixedTerm rewardFixedTerm : rewardMap.values()) {
            // 写入定期奖励汇总记录
            String summaryBillCode = rewardFixedTerm.getRewardFixedBillCode();
            rewardFixedTermMapper.insert(rewardFixedTerm);

            // 更新奖励明细状态
            for (Reward reward : rewardFixedTerm.getRewardList()) {
                String rewardBillCode = reward.getRewardBillCode();
                Map<String, Object> param = new HashMap<>();
                param.put("rewardBillCode", rewardBillCode);
                param.put("summaryBillCode", summaryBillCode);
                rewardMapper.updateSummaryBillCode(param);
            }
        }

        LOGGER.info("======== Generating reward summary for fixed term product is finish ========");
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        return responseResult;
    }

    /**
     * 查询定期奖励结算记录
     *
     * @param rewardFixedSearchDto
     * @return
     * @throws BusinessException
     */
    @Override
    public List<RewardFixedTerm> searchRewardFixed(RewardFixedSearchDto rewardFixedSearchDto) throws BusinessException {
        return rewardFixedTermMapper.searchRewardFixed(rewardFixedSearchDto);
    }

    /**
     * 查询定期奖励结算记录的总条数
     *
     * @param rewardFixedSearchDto
     * @return
     * @throws BusinessException
     */
    @Override
    public int searchRewardFixedCount(RewardFixedSearchDto rewardFixedSearchDto) throws BusinessException {
        return rewardFixedTermMapper.searchRewardFixedCount(rewardFixedSearchDto);
    }

    @Override
    public RewardFixedTerm getFixedAward(String rewardFixedBillCode) throws BusinessException{
        BigDecimal balance = getPlatformAccountBalance();
        RewardFixedTerm rewardFixedTerm = rewardFixedTermMapper.selectByPrimaryKey(rewardFixedBillCode);
        rewardFixedTerm.setPlatformAmount(balance);
        return rewardFixedTerm;
    }

    /**
     * 审核
     *
     * @param param
     * @return
     */
    @Override
    @Transactional(rollbackFor = BusinessException.class)
    public ResponseResult updateCheckStatus(Map<String, Object> param) throws BusinessException {
        List<String> finishList = new ArrayList<>();
        List<String> failedList = new ArrayList<>();

        String rewardFixedBillCode = param.get("rewardFixedBillCode").toString();
        String [] billCodeList = rewardFixedBillCode.split(Separator.DATA_SEPARATOR);
        for (String billCode : billCodeList) {
            LOGGER.info("审核定期产品佣金：{}", billCode);

            RewardFixedTerm rewardFixedTerm = rewardFixedTermMapper.selectByPrimaryKey(billCode);
            int status = rewardFixedTerm.getRewardFixedStatus();
            LOGGER.info("status={}", status);
            if (status != RewardSummaryStatus.INIT && status!= RewardSummaryStatus.REJECT) {
                LOGGER.info("定期产品佣金状态错误：{}", status);
                failedList.add(billCode);
            } else {
                // 更新定期产品佣金状态
                LOGGER.info("更新定期产品佣金状态");
                param.put("rewardFixedBillCode", billCode);
                rewardFixedTermMapper.updateCheckStatus(param);

                // 更新奖励记录状态
                LOGGER.info("更新奖励记录状态");
                Map<String, Object> paramReward = new HashMap<>();
                paramReward.put("summaryBillCode", billCode);
                paramReward.put("checkTime", new Date());
                rewardMapper.updateCheckTime(paramReward);

                finishList.add(billCode);
            }
        }

        StringBuffer buffer = new StringBuffer();
        if (finishList.size() > 0) {
            buffer.append(RewardError.CHECK_FINISH_TXT);
            buffer.append("\n");
            for(String billCode : finishList) {
                buffer.append(billCode);
                buffer.append("\n");
            }

            buffer.append("\n");
            buffer.append("\n");
        }

        if (failedList.size() > 0) {
            buffer.append(RewardError.CHECK_FAILED_TXT);
            buffer.append("\n");
            for(String billCode : failedList) {
                buffer.append(billCode);
                buffer.append("\n");
            }
        }

        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(buffer.toString());
        return responseResult;
    }

    /**
     * 结算
     *
     * @param clearDto
     * @return
     */
    @Override
    @Transactional(rollbackFor = BusinessException.class, propagation = Propagation.REQUIRED)
    public ResponseResult updateClearStatus(RewardFixedClearDto clearDto) throws BusinessException {
        ResponseResult responseResult = new ResponseResult();
        if (clearDto.getPass() == 1) {
            // 通过
            LOGGER.info("开始定期奖励结算");

            // 检查平台结算账户余额
            LOGGER.info("检查平台结算账户余额");
            LOGGER.info("paymentAmount={}", clearDto.getPaymentAmount());

            BigDecimal accountCashAmount = getPlatformAccountBalance();
            LOGGER.info("accountCashAmount={}", accountCashAmount);

            if (accountCashAmount.compareTo(clearDto.getPaymentAmount()) < 0) {
                LOGGER.error("平台结算账户余额不足");
                StringBuffer errorMessage = new StringBuffer();
                for(String rewardFixedBillCode : clearDto.getRewardCodeList()) {
                    RewardFixedTerm rewardFixedTerm = rewardFixedTermMapper.selectByPrimaryKey(rewardFixedBillCode);
                    rewardFixedTerm.setRemark(RewardError.ACCOUNT_BALANCE_TXT);
                    rewardFixedTerm.setRewardFixedStatus(RewardSummaryStatus.FAILED);
                    rewardFixedTerm.setClearTime(new Date());
                    // 更新数据库状态
                    rewardFixedTermMapper.updateByPrimaryKey(rewardFixedTerm);
                    // 错误信息
                    errorMessage.append(rewardFixedBillCode);
                    errorMessage.append("|");
                    errorMessage.append(RewardError.ACCOUNT_BALANCE_TXT);
                    errorMessage.append("<br/>");
                }

                // 返回错误信息
                responseResult.setCode(RewardError.ACCOUNT_BALANCE);
                responseResult.setMsg(errorMessage.toString());
                return responseResult;
            }

            // 成功列表
            List<RewardFixedTerm> finishList = new ArrayList<>();

            // 失败列表
            List<RewardFixedTerm> failedList = new ArrayList<>();

            // 每一个分别执行
            for(String rewardFixedBillCode : clearDto.getRewardCodeList()) {
                LOGGER.info("定期奖励结算：{}", rewardFixedBillCode);
                RewardFixedTerm rewardFixedTerm = rewardFixedTermMapper.selectByPrimaryKey(rewardFixedBillCode);

                // 检查结算状态，检查奖励明细是否已经是已结算状态
                LOGGER.info("检查奖励汇总记录结算状态");
                if (rewardFixedTerm.getRewardFixedStatus() == RewardSummaryStatus.FINISH) {
                    rewardFixedTerm.setRewardFixedStatus(RewardSummaryStatus.FAILED);
                    String message = "已经结算过";
                    rewardFixedTerm.setRemark(message);
                    failedList.add(rewardFixedTerm);
                    LOGGER.error(message);
                    continue;
                }

                LOGGER.info("检查奖励明细记录结算状态");
                boolean failed = false;
                List<Reward> rewardList = rewardMapper.queryBySummaryBillCode(rewardFixedBillCode);
                if (rewardList.size() > 0) {
                    for (Reward reward : rewardList) {
                        if (reward.getRewardStatus() == RewardStatus.PAID) {
                            rewardFixedTerm.setRewardFixedStatus(RewardSummaryStatus.FAILED);
                            String message = String.format("奖励单%s已经结算过", reward.getRewardBillCode());
                            rewardFixedTerm.setRemark(message);
                            failedList.add(rewardFixedTerm);
                            failed = true;
                            LOGGER.error(message);
                            break;
                        }
                    }
                } else {
                    LOGGER.error("定期奖励没有明细：{}", rewardFixedBillCode);
                    rewardFixedTerm.setRewardFixedStatus(RewardSummaryStatus.FAILED);
                    String message = String.format("结算单没有奖励明细", rewardFixedBillCode);
                    rewardFixedTerm.setRemark(message);
                    failedList.add(rewardFixedTerm);
                    failed = true;
                }

                if (failed) {
                    continue;
                }

                // 检查账户情况
                LOGGER.info("检查账户情况");
                String userUuid = rewardFixedTerm.getUserUuid();
                String accountUuid = null;
                Map<String, Object> paramMap = new HashMap();
                paramMap.put("userUuid", userUuid);
                Map<String, Object> userInfo = accountMapper.get(paramMap);
                if (null != userInfo && null != userInfo.get("accountUuid")) {
                    accountUuid = userInfo.get("accountUuid").toString();
                    LOGGER.info("accountUuid={}", accountUuid);
                }

                if (StringUtils.isEmpty(accountUuid)) {
                    // 未绑卡，加入到失败列表
                    rewardFixedTerm.setRewardFixedStatus(RewardSummaryStatus.FAILED);
                    String message = "用户还没有绑卡开户";
                    rewardFixedTerm.setRemark(message);
                    failedList.add(rewardFixedTerm);
                    LOGGER.error(message);
                    continue;
                }

                // 立即执行
                rewardFixedTerm.setAccountUuid(accountUuid);
                try {
                    // 新开事务中执行结算操作
                    rewardSummaryExecService.executeClearOperation(rewardFixedTerm);
                    finishList.add(rewardFixedTerm);
                } catch (BusinessException exception) {
                    LOGGER.error("rewardSummaryExecService.executeClearOperation fail:", exception);
                    rewardFixedTerm.setRewardFixedStatus(RewardSummaryStatus.FAILED);
                    rewardFixedTerm.setRemark(exception.getMessage());
                    failedList.add(rewardFixedTerm);
                }
            }

            // 刷新失败记录
            for(RewardFixedTerm rewardFixedTerm : failedList) {
                Map<String, Object>  clearMap = new HashMap<>();
                clearMap.put("rewardFixedBillCode", rewardFixedTerm.getRewardFixedBillCode());
                clearMap.put("rewardFixedStatus", RewardSummaryStatus.FAILED);
                clearMap.put("remark", rewardFixedTerm.getRemark());
                rewardFixedTermMapper.updateClearStatus(clearMap);
            }

            // 返回结算结果
            StringBuffer buffer = new StringBuffer();
            if (finishList.size() > 0) {
                buffer.append(RewardError.CLEAR_FINISH_TXT);
                buffer.append("\n");
                for(RewardFixedTerm rewardFixedTerm : finishList) {
                    buffer.append(rewardFixedTerm.getRewardFixedBillCode());
                    buffer.append("\n");
                }

                buffer.append("\n");
                buffer.append("\n");
            }

            if (failedList.size() > 0) {
                buffer.append(RewardError.CLEAR_FAILED_TXT);
                buffer.append("\n");
                for(RewardFixedTerm rewardFixedTerm : failedList) {
                    buffer.append(rewardFixedTerm.getRewardFixedBillCode());
                    buffer.append("\n");
                }
            }

            responseResult.setCode(ResponseCode.OK);
            responseResult.setMsg(buffer.toString());
            return responseResult;
        } else {
            // 不通过
            // 更新数据库状态
            LOGGER.info("结算驳回");
            StringBuffer buffer = new StringBuffer();
            buffer.append(RewardError.CLEAR_REJECT_TXT);
            buffer.append("\n");
            for(String rewardCode : clearDto.getRewardCodeList()) {
                Map<String, Object>  clearMap = new HashMap<>();
                clearMap.put("rewardFixedBillCode", rewardCode);
                clearMap.put("rewardFixedStatus", RewardSummaryStatus.REJECT);
                clearMap.put("clearTime", null);
                clearMap.put("remark", clearDto.getRemark());
                rewardFixedTermMapper.updateClearStatus(clearMap);

                buffer.append(rewardCode);
                buffer.append("\n");
            }

            LOGGER.info(buffer.toString());
            responseResult.setCode(ResponseCode.OK);
            responseResult.setMsg(buffer.toString());
            return responseResult;
        }
    }

    /**
     * 读取一个批次的汇总信息
     *
     * @param batchCode
     * @return
     * @throws BusinessException
     */
    @Override
    public List<RewardBatchInfoVO> getOneBatchInfo(String batchCode) throws BusinessException {
        return rewardFixedTermMapper.getOneBatchInfo(batchCode);
    }

    /**
     * 按批次更新审核状态
     *
     * @param param
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = BusinessException.class)
    public ResponseResult updateCheckBatchStatus(Map<String, Object> param) throws BusinessException {
        List<String> finishList = new ArrayList<>();
        List<String> failedList = new ArrayList<>();

        int rewardFixedStatus = Integer.parseInt(param.get("rewardFixedStatus").toString());

        String batchCode = param.get("batchCode").toString();

        List<RewardFixedTerm> rewardFixedTermList = rewardFixedTermMapper.selectToCheckByBatchCode(batchCode);
        for (RewardFixedTerm rewardFixedTerm : rewardFixedTermList) {
            String billCode = rewardFixedTerm.getRewardFixedBillCode();
            LOGGER.info("审核定期产品佣金：{}", billCode);
            int status = rewardFixedTerm.getRewardFixedStatus();
            LOGGER.info("status={}", status);

            // 更新定期产品佣金状态
            LOGGER.info("更新定期产品佣金状态");
            param.put("rewardFixedBillCode", billCode);
            rewardFixedTermMapper.updateCheckStatus(param);

            // 审核通过才需要更新奖励记录状态，审核驳回不用更新奖励明细审核时间
            if (rewardFixedStatus == RewardSummaryStatus.CHECKED) {
                LOGGER.info("更新奖励记录状态");
                Map<String, Object> paramReward = new HashMap<>();
                paramReward.put("summaryBillCode", billCode);
                paramReward.put("checkTime", new Date());
                rewardMapper.updateCheckTime(paramReward);
            }

            finishList.add(billCode);
        }

        StringBuffer buffer = new StringBuffer();
        if (finishList.size() > 0) {
            buffer.append(RewardError.CHECK_FINISH_TXT);
            buffer.append("\n");
            for(String billCode : finishList) {
                buffer.append(billCode);
                buffer.append("\n");
            }

            buffer.append("\n");
            buffer.append("\n");
        }

        if (failedList.size() > 0) {
            buffer.append(RewardError.CHECK_FAILED_TXT);
            buffer.append("\n");
            for(String billCode : failedList) {
                buffer.append(billCode);
                buffer.append("\n");
            }
        }

        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(buffer.toString());
        return responseResult;
    }

    /**
     * 按批次更新结算状态
     *
     * @param clearDto
     * @return
     * @throws BusinessException
     */
    @Override
    public ResponseResult updateClearBatchStatus(RewardFixedClearDto clearDto) throws BusinessException {
        ResponseResult responseResult = new ResponseResult();
        if (clearDto.getPass() == 1) {
            // 通过
            LOGGER.info("开始定期奖励结算");

            // 检查平台结算账户余额
            LOGGER.info("检查平台结算账户余额");
            LOGGER.info("paymentAmount={}", clearDto.getPaymentAmount());

            BigDecimal accountCashAmount = getPlatformAccountBalance();
            LOGGER.info("accountCashAmount={}", accountCashAmount);

            // 根据批次单号读取奖励结算单（待结算和结算失败的）
            String batchCode = clearDto.getBatchCode();
            List<RewardFixedTerm> rewardFixedTermList = rewardFixedTermMapper.selectToClearByBatchCode(batchCode);

            if (accountCashAmount.compareTo(clearDto.getPaymentAmount()) < 0) {
                LOGGER.error("平台结算账户余额不足");
                StringBuffer errorMessage = new StringBuffer();

                for (RewardFixedTerm rewardFixedTerm : rewardFixedTermList) {
                    String rewardFixedBillCode = rewardFixedTerm.getRewardFixedBillCode();
                    rewardFixedTerm.setRemark(RewardError.ACCOUNT_BALANCE_TXT);
                    rewardFixedTerm.setRewardFixedStatus(RewardSummaryStatus.FAILED);
                    rewardFixedTerm.setClearTime(new Date());
                    // 更新数据库状态
                    rewardFixedTermMapper.updateByPrimaryKey(rewardFixedTerm);
                    // 错误信息
                    errorMessage.append(rewardFixedBillCode);
                    errorMessage.append("|");
                    errorMessage.append(RewardError.ACCOUNT_BALANCE_TXT);
                    errorMessage.append("<br/>");
                }

                // 返回错误信息
                responseResult.setCode(RewardError.ACCOUNT_BALANCE);
                responseResult.setMsg(errorMessage.toString());
                return responseResult;
            }

            // 成功列表
            List<RewardFixedTerm> finishList = new ArrayList<>();

            // 失败列表
            List<RewardFixedTerm> failedList = new ArrayList<>();

            // 每一个分别执行
            for(RewardFixedTerm rewardFixedTerm : rewardFixedTermList) {
                String rewardFixedBillCode = rewardFixedTerm.getRewardFixedBillCode();
                LOGGER.info("定期奖励结算：{}", rewardFixedBillCode);

                LOGGER.info("检查奖励明细记录结算状态");
                boolean failed = false;
                List<Reward> rewardList = rewardMapper.queryBySummaryBillCode(rewardFixedBillCode);
                if (rewardList.size() > 0) {
                    for (Reward reward : rewardList) {
                        if (reward.getRewardStatus() == RewardStatus.PAID) {
                            rewardFixedTerm.setRewardFixedStatus(RewardSummaryStatus.FAILED);
                            String message = String.format("奖励单%s已经结算过", reward.getRewardBillCode());
                            rewardFixedTerm.setRemark(message);
                            failedList.add(rewardFixedTerm);
                            failed = true;
                            LOGGER.error(message);
                            break;
                        }
                    }
                } else {
                    LOGGER.error("定期奖励没有明细：{}", rewardFixedBillCode);
                    rewardFixedTerm.setRewardFixedStatus(RewardSummaryStatus.FAILED);
                    String message = String.format("结算单没有奖励明细", rewardFixedBillCode);
                    rewardFixedTerm.setRemark(message);
                    failedList.add(rewardFixedTerm);
                    failed = true;
                }

                if (failed) {
                    continue;
                }

                // 检查账户情况
                LOGGER.info("检查账户情况");
                String userUuid = rewardFixedTerm.getUserUuid();
                String accountUuid = null;
                Map<String, Object> paramMap = new HashMap();
                paramMap.put("userUuid", userUuid);
                Map<String, Object> userInfo = accountMapper.get(paramMap);
                if (null != userInfo && null != userInfo.get("accountUuid")) {
                    accountUuid = userInfo.get("accountUuid").toString();
                    LOGGER.info("accountUuid={}", accountUuid);
                }

                if (StringUtils.isEmpty(accountUuid)) {
                    // 未绑卡，加入到失败列表
                    rewardFixedTerm.setRewardFixedStatus(RewardSummaryStatus.FAILED);
                    String message = "用户还没有绑卡开户";
                    rewardFixedTerm.setRemark(message);
                    failedList.add(rewardFixedTerm);
                    LOGGER.error(message);
                    continue;
                }

                // 立即执行
                rewardFixedTerm.setAccountUuid(accountUuid);
                try {
                    // 新开事务中执行结算操作
                    rewardSummaryExecService.executeClearOperation(rewardFixedTerm);
                    finishList.add(rewardFixedTerm);
                } catch (BusinessException exception) {
                    LOGGER.error("rewardSummaryExecService.executeClearOperation fail:", exception);
                    rewardFixedTerm.setRewardFixedStatus(RewardSummaryStatus.FAILED);
                    rewardFixedTerm.setRemark(exception.getMessage());
                    failedList.add(rewardFixedTerm);
                }
            }

            // 刷新失败记录
            for(RewardFixedTerm rewardFixedTerm : failedList) {
                Map<String, Object>  clearMap = new HashMap<>();
                clearMap.put("rewardFixedBillCode", rewardFixedTerm.getRewardFixedBillCode());
                clearMap.put("rewardFixedStatus", RewardSummaryStatus.FAILED);
                clearMap.put("remark", rewardFixedTerm.getRemark());
                rewardFixedTermMapper.updateClearStatus(clearMap);
            }

            // 返回结算结果
            StringBuffer buffer = new StringBuffer();
            if (finishList.size() > 0) {
                buffer.append(RewardError.CLEAR_FINISH_TXT);
                buffer.append("\n");
                for(RewardFixedTerm rewardFixedTerm : finishList) {
                    buffer.append(rewardFixedTerm.getRewardFixedBillCode());
                    buffer.append("\n");
                }

                buffer.append("\n");
                buffer.append("\n");
            }

            if (failedList.size() > 0) {
                buffer.append(RewardError.CLEAR_FAILED_TXT);
                buffer.append("\n");
                for(RewardFixedTerm rewardFixedTerm : failedList) {
                    buffer.append(rewardFixedTerm.getRewardFixedBillCode());
                    buffer.append("\n");
                }
            }

            responseResult.setCode(ResponseCode.OK);
            responseResult.setMsg(buffer.toString());
            return responseResult;
        } else {
            // 不通过
            // 更新数据库状态
            LOGGER.info("结算驳回");
            StringBuffer buffer = new StringBuffer();
            buffer.append(RewardError.CLEAR_REJECT_TXT);
            buffer.append("\n");

            // 根据批次单号读取奖励结算单（待结算和结算失败的）
            String batchCode = clearDto.getBatchCode();
            List<RewardFixedTerm> rewardFixedTermList = rewardFixedTermMapper.selectToClearByBatchCode(batchCode);


            for(RewardFixedTerm rewardFixedTerm : rewardFixedTermList) {
                String rewardCode = rewardFixedTerm.getRewardFixedBillCode();
                Map<String, Object>  clearMap = new HashMap<>(16);
                clearMap.put("rewardFixedBillCode", rewardCode);
                clearMap.put("rewardFixedStatus", RewardSummaryStatus.REJECT);
                clearMap.put("clearTime", null);
                clearMap.put("remark", clearDto.getRemark());
                rewardFixedTermMapper.updateClearStatus(clearMap);

                buffer.append(rewardCode);
                buffer.append("\n");
            }

            LOGGER.info(buffer.toString());
            responseResult.setCode(ResponseCode.OK);
            responseResult.setMsg(buffer.toString());
            return responseResult;
        }
    }

    /**
     * 创建定期奖励汇总对象
     *
     * @param reward
     * @return
     */
    private RewardFixedTerm createRewardFixedTerm(Reward reward, RewardApplyDto rewardApplyDto, String batchCode) {
        RewardFixedTerm rewardFixedTerm = new RewardFixedTerm();
        rewardFixedTerm.setUserUuid(reward.getUserUuid());
        rewardFixedTerm.setUserMobile(reward.getUserMobile());
        rewardFixedTerm.setUserIdCardNo(reward.getUserIdCardNo());
        rewardFixedTerm.setUserName(reward.getUserRealName());
        rewardFixedTerm.setBelongTopOrgPath(reward.getBelongTopOrgPath());
        rewardFixedTerm.setBelongTopUserUuid(reward.getBelongTopUserUuid());
        rewardFixedTerm.setRewardFixedBillCode(ZJBuzzUtils.generateOrderBillCode(TradeType.TRADE_REWARD_FIXED_SUMMARY));
        rewardFixedTerm.setRewardFixedEndDate(rewardApplyDto.getEndDate());
        rewardFixedTerm.setRewardFixedStartDate(rewardApplyDto.getStartDate());
        rewardFixedTerm.setRewardFixedBatchCode(batchCode);
        rewardFixedTerm.setRewardFixedStatus(RewardSummaryStatus.INIT);
        rewardFixedTerm.setLevelOneAmount(new BigDecimal(0));
        rewardFixedTerm.setLevelTwoAmount(new BigDecimal(0));
        rewardFixedTerm.setPayAmount(new BigDecimal(0));
        rewardFixedTerm.setRewardCount(0);
        rewardFixedTerm.setSaleAmount(new BigDecimal(0));
        rewardFixedTerm.setTaxAmount(new BigDecimal(0));
        rewardFixedTerm.setTotalAmount(new BigDecimal(0));
        rewardFixedTerm.setCreateTime(new Date());
        return rewardFixedTerm;
    }

    /**
     * 计算劳务费的个人所得税
     *
     * @param amount
     * @return
     */
    private BigDecimal calculateTax(BigDecimal amount) {
        double base = amount.doubleValue();
        BigDecimal tax;
        if (base <= 800) {
            tax = new BigDecimal(0);
        } else if (base <= 4000) {
            tax = amount.subtract(new BigDecimal(800)).multiply(new BigDecimal(0.2));
        } else if (base <= 20000) {
            tax = amount.multiply(new BigDecimal(0.8)).multiply(new BigDecimal(0.2));
        } else if (base <= 50000) {
            tax = amount.multiply(new BigDecimal(0.8)).multiply(new BigDecimal(0.3)).subtract(new BigDecimal(2000));
        } else {
            tax = amount.multiply(new BigDecimal(0.8)).multiply(new BigDecimal(0.4)).subtract(new BigDecimal(7000));
        }

        return tax;
    }

    /**
     * 获取平台结算账户余额
     *
     * @return
     */
    private BigDecimal getPlatformAccountBalance() throws BusinessException {
        return accountService.getPlatformAccountBalance();
    }
}