package cn.zjhf.kingold.trade.persistence.mq.message;

import cn.zjhf.kingold.rocketmq.base.MQMessage;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Set;

/**
 * Created by liuyao on 17/9/17.
 */
public class CouponMessage implements MQMessage {

    private String userUuid;

    private  String investorMobile;

    private String orderBillCode;

    private Set<Integer> couponTypeSet;

    /**
     * 邀友注册被邀请人手机号
     */
    private String beInviteMobile;

    /**
     * 礼券面值
     */
    private BigDecimal couponFaceValue;

    /**
     * 有效期开始时间
     */
    private Date validStartTime;

    /**
     * 有效期结束时间
     */
    private Date validEndTime;

    private Integer applyScene;

    private boolean newFlag;

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public BigDecimal getCouponFaceValue() {
        return couponFaceValue;
    }

    public void setCouponFaceValue(BigDecimal couponFaceValue) {
        this.couponFaceValue = couponFaceValue;
    }

    public Date getValidStartTime() {
        return validStartTime;
    }

    public void setValidStartTime(Date validStartTime) {
        this.validStartTime = validStartTime;
    }

    public Date getValidEndTime() {
        return validEndTime;
    }

    public void setValidEndTime(Date validEndTime) {
        this.validEndTime = validEndTime;
    }

    public Integer getApplyScene() {
        return applyScene;
    }

    public void setApplyScene(Integer applyScene) {
        this.applyScene = applyScene;
    }

    public String getInvestorMobile() {
        return investorMobile;
    }

    public void setInvestorMobile(String investorMobile) {
        this.investorMobile = investorMobile;
    }

    public String getOrderBillCode() {
        return orderBillCode;
    }

    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    public Set<Integer> getCouponTypeSet() {
        return couponTypeSet;
    }

    public void setCouponTypeSet(Set<Integer> couponTypeSet) {
        this.couponTypeSet = couponTypeSet;
    }

    public String getBeInviteMobile() {
        return beInviteMobile;
    }

    public void setBeInviteMobile(String beInviteMobile) {
        this.beInviteMobile = beInviteMobile;
    }

    public boolean isNewFlag() {
        return newFlag;
    }

    public void setNewFlag(boolean newFlag) {
        this.newFlag = newFlag;
    }

    @Override
    public String getKey() {
        return this.userUuid;
    }
}
