package cn.zjhf.kingold.trade.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author 
 */
public class CashCoupon implements Serializable {
    /**
     * 现金券批次号
     */
    private String ccCode;

    /**
     * 现金券名称
     */
    private String ccName;

    /**
     * 现金券状态(1待激活，2已激活，3已停用)
     */
    private Byte ccStatus;

    /**
     * 现金券类型(1现金券，2加息券)
     */
    private Byte ccType;

    /**
     * 现金券面值
     */
    private BigDecimal faceValue;

    /**
     * 加息券加息率
     */
    private BigDecimal interestYieldRate;

    /**
     * 加息券加息类型：0全产品期限加息；1指定加息天数
     */
    private Integer interestYieldType;

    /**
     * 加息券加息天数，interest_yield_type=1时有效
     */
    private Integer interestYieldPeriod;

    /**
     * 有效期类型(1指定有效时间区间，2指定有效时间长度) 
     */
    private Byte validTermType;

    /**
     * 有效期开始时间
     */
    private Date validStartTime;

    /**
     * 有效期结束时间
     */
    private Date validEndTime;

    /**
     * 有效时间单位(1年，2月，3日)
     */
    private Byte validTermUnit;

    /**
     * 和有效时间单位配合使用，有效期长度为 * 年/月/日
     */
    private Integer validTermQuantity;

    /**
     * 发行总数上限
     */
    private Integer extendMaxNum;

    /**
     * 单日发行总数上限
     */
    private Integer extendDayMaxNum;

    /**
     * 发布渠道（PC/APP/H5，多个同时存在用$$分隔）
     */
    private String extendChannel;

    /**
     * 适用产品类型，FIXI固收产品，PRIF私募产品
     */
    private String applyProductType;

    /**
     * 使用渠道（PC/APP/H5，多个同时存在用$$分隔）
     */
    private String applyChannel;

    /**
     * 要求的单笔投资下限
     */
    private BigDecimal applyTradeAmount;

    /**
     * 是否限制产品期限(1否，2是)
     */
    private Byte isApplyProductTerm;

    /**
     * 适用产品期限集合,单位(天), 格式x1-y1,x2-y2
     */
    private String applyProductTerms;

    /**
     * 是否限制子产品(1否，2是)
     */
    private Byte isApplyProductuuids;

    /**
     * 限制子产品集合(多个同时存在用$$分隔)
     */
    private String applyProductuuids;

    /**
     * 前台规则概要1
     */
    private String ccRemark1;

    /**
     * 前台规则概要2
     */
    private String ccRemark2;

    /**
     * 前台规则概要3
     */
    private String ccRemark3;

    /**
     * 删除标记 0未删除，1已删除
     */
    private Byte deleteFlag;

    /**
     * 删除时间
     */
    private Date deleteTime;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 更新用户id
     */
    private String updateUserId;

    /**
     * 激活时间
     */
    private Date activateTime;

    /**
     * 停用时间
     */
    private Date disableTime;

    private static final long serialVersionUID = 1L;

    public String getCcCode() {
        return ccCode;
    }

    public void setCcCode(String ccCode) {
        this.ccCode = ccCode;
    }

    public String getCcName() {
        return ccName;
    }

    public void setCcName(String ccName) {
        this.ccName = ccName;
    }

    public Byte getCcStatus() {
        return ccStatus;
    }

    public void setCcStatus(Byte ccStatus) {
        this.ccStatus = ccStatus;
    }

    public Byte getCcType() {
        return ccType;
    }

    public void setCcType(Byte ccType) {
        this.ccType = ccType;
    }

    public BigDecimal getFaceValue() {
        return faceValue;
    }

    public void setFaceValue(BigDecimal faceValue) {
        this.faceValue = faceValue;
    }

    public BigDecimal getInterestYieldRate() {
        return interestYieldRate;
    }

    public void setInterestYieldRate(BigDecimal interestYieldRate) {
        this.interestYieldRate = interestYieldRate;
    }

    public Integer getInterestYieldType() {
        return interestYieldType;
    }

    public void setInterestYieldType(Integer interestYieldType) {
        this.interestYieldType = interestYieldType;
    }

    public Integer getInterestYieldPeriod() {
        return interestYieldPeriod;
    }

    public void setInterestYieldPeriod(Integer interestYieldPeriod) {
        this.interestYieldPeriod = interestYieldPeriod;
    }

    public Byte getValidTermType() {
        return validTermType;
    }

    public void setValidTermType(Byte validTermType) {
        this.validTermType = validTermType;
    }

    public Date getValidStartTime() {
        return validStartTime;
    }

    public void setValidStartTime(Date validStartTime) {
        this.validStartTime = validStartTime;
    }

    public Date getValidEndTime() {
        return validEndTime;
    }

    public void setValidEndTime(Date validEndTime) {
        this.validEndTime = validEndTime;
    }

    public Byte getValidTermUnit() {
        return validTermUnit;
    }

    public void setValidTermUnit(Byte validTermUnit) {
        this.validTermUnit = validTermUnit;
    }

    public Integer getValidTermQuantity() {
        return validTermQuantity;
    }

    public void setValidTermQuantity(Integer validTermQuantity) {
        this.validTermQuantity = validTermQuantity;
    }

    public Integer getExtendMaxNum() {
        return extendMaxNum;
    }

    public void setExtendMaxNum(Integer extendMaxNum) {
        this.extendMaxNum = extendMaxNum;
    }

    public Integer getExtendDayMaxNum() {
        return extendDayMaxNum;
    }

    public void setExtendDayMaxNum(Integer extendDayMaxNum) {
        this.extendDayMaxNum = extendDayMaxNum;
    }

    public String getExtendChannel() {
        return extendChannel;
    }

    public void setExtendChannel(String extendChannel) {
        this.extendChannel = extendChannel;
    }

    public String getApplyProductType() {
        return applyProductType;
    }

    public void setApplyProductType(String applyProductType) {
        this.applyProductType = applyProductType;
    }

    public String getApplyChannel() {
        return applyChannel;
    }

    public void setApplyChannel(String applyChannel) {
        this.applyChannel = applyChannel;
    }

    public BigDecimal getApplyTradeAmount() {
        return applyTradeAmount;
    }

    public void setApplyTradeAmount(BigDecimal applyTradeAmount) {
        this.applyTradeAmount = applyTradeAmount;
    }

    public Byte getIsApplyProductTerm() {
        return isApplyProductTerm;
    }

    public void setIsApplyProductTerm(Byte isApplyProductTerm) {
        this.isApplyProductTerm = isApplyProductTerm;
    }

    public String getApplyProductTerms() {
        return applyProductTerms;
    }

    public void setApplyProductTerms(String applyProductTerms) {
        this.applyProductTerms = applyProductTerms;
    }

    public Byte getIsApplyProductuuids() {
        return isApplyProductuuids;
    }

    public void setIsApplyProductuuids(Byte isApplyProductuuids) {
        this.isApplyProductuuids = isApplyProductuuids;
    }

    public String getApplyProductuuids() {
        return applyProductuuids;
    }

    public void setApplyProductuuids(String applyProductuuids) {
        this.applyProductuuids = applyProductuuids;
    }

    public String getCcRemark1() {
        return ccRemark1;
    }

    public void setCcRemark1(String ccRemark1) {
        this.ccRemark1 = ccRemark1;
    }

    public String getCcRemark2() {
        return ccRemark2;
    }

    public void setCcRemark2(String ccRemark2) {
        this.ccRemark2 = ccRemark2;
    }

    public String getCcRemark3() {
        return ccRemark3;
    }

    public void setCcRemark3(String ccRemark3) {
        this.ccRemark3 = ccRemark3;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getDeleteTime() {
        return deleteTime;
    }

    public void setDeleteTime(Date deleteTime) {
        this.deleteTime = deleteTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(String updateUserId) {
        this.updateUserId = updateUserId;
    }

    public Date getActivateTime() {
        return activateTime;
    }

    public void setActivateTime(Date activateTime) {
        this.activateTime = activateTime;
    }

    public Date getDisableTime() {
        return disableTime;
    }

    public void setDisableTime(Date disableTime) {
        this.disableTime = disableTime;
    }
}