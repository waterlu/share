package cn.zjhf.kingold.trade.exception;

import cn.zjhf.kingold.common.exception.BusinessException;

/**
 * 订单支付的通用异常
 *
 * @author lutiehua
 * @date 2018/3/12
 */
public class PayOrderException extends BusinessException {

    public PayOrderException() {
        super(6075, "更新订单处理中状态失败");
    }
}
