package cn.zjhf.kingold.trade.entity.OutVO;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.trade.entity.RedPacketRecord;
import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.Date;

@ApiModel(value = "RedPacketRecordVO", description = "")
public class RedPacketRecordVO extends ParamVO {

    @ApiModelProperty(required = true, value = "序号")
    @NotEmpty
    private Long id;

    @ApiModelProperty(required = true, value = "审核编号/审核批次号")
    @NotEmpty
    private Long auditId;

    @ApiModelProperty(required = true, value = "用户UUID")
    @NotEmpty
    @Size(min = 1, max = 32)
    private String userUuid;

    @ApiModelProperty(required = true, value = "用户名/用户手机号")
    @NotEmpty
    @Size(min = 1, max = 15)
    private String phoneNumber;

    @ApiModelProperty(required = true, value = "用户姓名")
    @NotEmpty
    @Size(min = 1, max = 80)
    private String phoneName;

    @ApiModelProperty(required = true, value = "红包金额/发放金额")
    @NotEmpty
    private double redPacketAmount;

    @ApiModelProperty(required = true, value = "领取状态: 1已发放(待领取)；2已领取")
    @NotEmpty
    private int receiveStatus;

    @ApiModelProperty(required = true, value = "领取的结果消息，主要存放领取失败的消息")
    @NotEmpty
    private String receiveMess;

    @ApiModelProperty(required = false, value = "领取时间")
    private Date receiveTime;

    @ApiModelProperty(required = true, value = "红包备注")
    private String remarks;

    @ApiModelProperty(required = false, value = "创建时间/发放时间")
    private Date createTime;

    @ApiModelProperty(required = false, value = "更新时间")
    private Date updateTime;

    @ApiModelProperty(required = true, value = "删除标记 0未删除，1已删除")
    @NotEmpty
    private int deleteFlag;

    public RedPacketRecordVO() {
    }

    public RedPacketRecordVO(RedPacketRecord redPacketRecord) {
        this.id = redPacketRecord.getId();
        this.auditId = redPacketRecord.getAuditId();
        this.userUuid = redPacketRecord.getUserUuid();
        this.phoneNumber = redPacketRecord.getPhoneNumber();
        this.phoneName = redPacketRecord.getPhoneName();
        this.redPacketAmount = redPacketRecord.getRedPacketAmount().doubleValue();
        this.receiveStatus = redPacketRecord.getReceiveStatus();
        this.receiveMess = redPacketRecord.getReceiveMess();
        this.receiveTime = redPacketRecord.getReceiveTime();
        this.remarks = redPacketRecord.getRemarks();
        this.createTime = redPacketRecord.getCreateTime();
        this.updateTime = redPacketRecord.getUpdateTime();
        this.deleteFlag = redPacketRecord.getDeleteFlag();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getAuditId() {
        return auditId;
    }

    public void setAuditId(Long auditId) {
        this.auditId = auditId;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getPhoneName() {
        return phoneName;
    }

    public void setPhoneName(String phoneName) {
        this.phoneName = phoneName;
    }

    public double getRedPacketAmount() {
        return redPacketAmount;
    }

    public void setRedPacketAmount(double redPacketAmount) {
        this.redPacketAmount = redPacketAmount;
    }

    public int getReceiveStatus() {
        return receiveStatus;
    }

    public void setReceiveStatus(int receiveStatus) {
        this.receiveStatus = receiveStatus;
    }

    public Date getReceiveTime() {
        return receiveTime;
    }

    public void setReceiveTime(Date receiveTime) {
        this.receiveTime = receiveTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public int getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(int deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public RedPacketRecord get() {
        RedPacketRecord redPacketRecord = new RedPacketRecord();
        redPacketRecord.setId(id);
        redPacketRecord.setAuditId(auditId);
        redPacketRecord.setUserUuid(userUuid);
        redPacketRecord.setPhoneNumber(phoneNumber);
        redPacketRecord.setPhoneName(phoneName);
        redPacketRecord.setRedPacketAmount(new BigDecimal(redPacketAmount));
        redPacketRecord.setReceiveStatus(new Integer(receiveStatus).byteValue());
        redPacketRecord.setReceiveMess(receiveMess);
        redPacketRecord.setReceiveTime(receiveTime);
        redPacketRecord.setRemarks(remarks);
        redPacketRecord.setCreateTime(createTime);
        redPacketRecord.setUpdateTime(updateTime);
        redPacketRecord.setDeleteFlag(new Integer(deleteFlag).byteValue());
        return redPacketRecord;
    }

    public String getReceiveMess() {
        return receiveMess;
    }

    public void setReceiveMess(String receiveMess) {
        this.receiveMess = receiveMess;
    }

    @Override
    public String toString() {
        return "RedPacketRecordVO{" +
                "id=" + id +
                ", auditId=" + auditId +
                ", userUuid='" + userUuid + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", phoneName='" + phoneName + '\'' +
                ", redPacketAmount=" + redPacketAmount +
                ", receiveStatus=" + receiveStatus +
                ", receiveMess='" + receiveMess + '\'' +
                ", receiveTime=" + receiveTime +
                ", remarks=" + remarks +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                ", deleteFlag=" + deleteFlag +
                '}';
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}
