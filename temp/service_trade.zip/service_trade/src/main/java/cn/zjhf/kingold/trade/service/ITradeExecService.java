package cn.zjhf.kingold.trade.service;

import cn.zjhf.kingold.common.exception.BusinessException;

/**
 * Created by zhangyijie on 2017/6/27.
 */
public interface ITradeExecService {

    /**
     * 提现
     * @param userUuid
     * @param amt
     * @param transactionChannel
     * @throws BusinessException
     */
    void freezeWithdraw(String userUuid, double amt, String transactionChannel) throws BusinessException;
}
