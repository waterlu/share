package cn.zjhf.kingold.trade.entity.OutVO;

import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Size;

/**
 * Created by zhangyijie on 2017/5/26.
 */
@ApiModel(value = "ProductRaiseProgressVO", description = "产品募集进度")
public class ProductRaiseProgressVO {
    @ApiModelProperty(required = true, value = "产品UUID")
    @NotEmpty
    @Size(min = 1, max = 32)
    private String productUuid;

    @ApiModelProperty(required = true, value = "产品规模")
    private double productScale;

    @ApiModelProperty(required = true, value = "产品实际募集金额")
    private double productAccumulation;

    @ApiModelProperty(required = true, value = "产品募集(人工)调整金额")
    private double productManual;

    @ApiModelProperty(required = true, value = "产品募集(人工)调整金额_最小金额")
    private double minProductManual;

    @ApiModelProperty(required = true, value = "产品募集(人工)调整金额_最大金额")
    private double maxProductManual;

    @ApiModelProperty(required = true, value = "产品募集进度  ((实际募集金额 + 募集(人工)调整金额) / 产品规模) 保存两位小数")
    private double productProgressRate;

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public double getProductScale() {
        return productScale;
    }

    public void setProductScale(double productScale) {
        this.productScale = productScale;
    }

    public double getProductAccumulation() {
        return productAccumulation;
    }

    public void setProductAccumulation(double productAccumulation) {
        this.productAccumulation = productAccumulation;
    }

    public double getProductManual() {
        return productManual;
    }

    public void setProductManual(double productManual) {
        this.productManual = productManual;
    }

    public double getMinProductManual() {
        return minProductManual;
    }

    public void setMinProductManual(double minProductManual) {
        this.minProductManual = minProductManual;
    }

    public double getMaxProductManual() {
        return maxProductManual;
    }

    public void setMaxProductManual(double maxProductManual) {
        this.maxProductManual = maxProductManual;
    }

    public double getProductProgressRate() {
        return productProgressRate;
    }

    public void setProductProgressRate(double productProgressRate) {
        this.productProgressRate = productProgressRate;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("productUuid:" + DataUtils.toString(productUuid) + ", ");
        sb.append("productScale:" + DataUtils.toString(productScale) + ", ");
        sb.append("productAccumulation:" + DataUtils.toString(productAccumulation) + ", ");
        sb.append("productManual:" + DataUtils.toString(productManual) + ", ");
        sb.append("minProductManual:" + DataUtils.toString(minProductManual) + ", ");
        sb.append("maxProductManual:" + DataUtils.toString(maxProductManual) + ", ");
        sb.append("productProgressRate:" + DataUtils.toString(productProgressRate));
        return sb.toString();
    }
}
