package cn.zjhf.kingold.trade.constant;

/**
 * Created by DELL on 2017/8/7.
 */
public interface ReportNo {
    /**
     * 定期产品报表序号
     */
    String  REPORT_NO_PRODUCT_FIXED= "B01";
    /**
     * 定期产品报表详情序号
     */
    String  REPORT_NO_PRODUCT_FIXED_DETAIL= "B0101";
    /**
     * 定期产品募集报表序号
     */
    String  REPORT_NO_PRODUCT_FIXED_RAISE= "B02";
    /**
     * 定期产品计息表_列表序号
     */
    String  REPORT_NO_PRODUCT_FIXED_INTEREST= "B03";
    /**
     * 定期产品计息表_详情序号
     */
    String  REPORT_NO_PRODUCT_FIXED_INTEREST_DETAIL= "B0301";
    /**
     * 定期产品到期兑付表_列表序号
     */
    String  REPORT_NO_PRODUCT_FIXED_EXPIRE_CASH= "B04";
    /**
     * 定期产品到期兑付表_详情序号
     */
    String  REPORT_NO_PRODUCT_FIXED_EXPIRE_CASH_DETAIL= "B0401";
    /**
     * 产品销售明细表_列表序号
     */
    String  REPORT_NO_PRODUCT_SALE_DETAIL_REPORT= "B05";
}
