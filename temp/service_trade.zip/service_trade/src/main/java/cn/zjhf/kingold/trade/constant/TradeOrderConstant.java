package cn.zjhf.kingold.trade.constant;

/**
 * @author lutiehua
 * @date 2018/3/12
 */
public interface TradeOrderConstant {

    /**
     * 订单支付状态 未支付
     */
    int ORDER_PAY_STATUS_UNPAID = 0;

    /**
     * 订单支付状态 支付处理中
     */
    int ORDER_PAY_STATUS_PENDING = 1;

    /**
     * 订单支付状态 已支付
     */
    int ORDER_PAY_STATUS_PAID = 2;

    /**
     * 订单支付状态 支付失败
     */
    int ORDER_PAY_STATUS_FAILED = 3;


    /**
     * 订单状态 1交易创建
     */
    int ORDER_STATUS_APPLY  = 1;

    /**
     * 订单状态 2交易已付款
     */
    int ORDER_STATUS_CONFIRM  = 2;

    /**
     * 订单状态 3产品计息中
     */
    int ORDER_STATUS_PRODUCT_INTEREST  = 3;

    /**
     * 订单状态 4产品到期
     */
    int ORDER_STATUS_PRODUCT_END  = 4;

    /**
     * 订单状态 5产品清算
     */
    int ORDER_STATUS_CLEAR  = 5;

    /**
     * 订单状态 9交易撤销
     */
    int ORDER_STATUS_CANCEL  = 9;
}
