package cn.zjhf.kingold.trade.persistence.mq.producer;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.rocketmq.annotation.RocketMQTransactionProducer;
import cn.zjhf.kingold.rocketmq.base.AbstractTransactionMQProducer;
import cn.zjhf.kingold.trade.persistence.mq.message.PayRechargeMessage;
import cn.zjhf.kingold.trade.service.IPayService;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 生产充值成功消息（事务型）
 *
 * Created by lutiehua on 2017/7/13.
 */
@RocketMQTransactionProducer(topic = "pay", tag = "recharge")
public class PayRechargeTransactionProducer extends AbstractTransactionMQProducer<PayRechargeMessage> {

    @Autowired
    private IPayService payService;

    @Override
    public boolean checkState(PayRechargeMessage payRechargeMessage) throws BusinessException {
        return payService.checkRecharge(payRechargeMessage.getData());
    }
}