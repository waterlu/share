package cn.zjhf.kingold.trade.baofoo;

/**
 * Created by lutiehua on 2017/4/27.
 */
public class AuthVO {


    private String result;

    private String sign;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }
}
