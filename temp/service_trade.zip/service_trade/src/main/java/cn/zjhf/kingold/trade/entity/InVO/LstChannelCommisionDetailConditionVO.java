package cn.zjhf.kingold.trade.entity.InVO;

import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Size;
import java.util.Date;

/**
 * Created by zhangyijie on 2017/10/12.
 */
public class LstChannelCommisionDetailConditionVO extends InVOBase {
    @ApiModelProperty(required = true, value = "产品简称")
    @NotEmpty
    @Size(min = 1, max = 40)
    private String productAbbrName;

    @ApiModelProperty(required = false, value = "APP名称/渠道名称")
    @Size(min = 1, max = 30)
    private String channelAppName;

    @ApiModelProperty(required = true, value = "结算状态：1未结算，2结算请求中，3已结算")
    @NotEmpty
    private int settleStatus;

    @ApiModelProperty(required = false, value = "放款起始日期")
    private Date beginLoanDate;

    @ApiModelProperty(required = false, value = "放款截止日期")
    private Date endLoanDate;

    @ApiModelProperty(required = true, value = "起始序号")
    private int beginSN;

    @ApiModelProperty(required = true, value = "结束序号")
    private int endSN;

    public String getProductAbbrName() {
        return productAbbrName;
    }

    public void setProductAbbrName(String productAbbrName) {
        this.productAbbrName = productAbbrName;
    }

    public String getChannelAppName() {
        return channelAppName;
    }

    public void setChannelAppName(String channelAppName) {
        this.channelAppName = channelAppName;
    }

    public int getSettleStatus() {
        return settleStatus;
    }

    public void setSettleStatus(int settleStatus) {
        this.settleStatus = settleStatus;
    }

    public Date getBeginLoanDate() {
        return beginLoanDate;
    }

    public void setBeginLoanDate(Date beginLoanDate) {
        this.beginLoanDate = beginLoanDate;
    }

    public Date getEndLoanDate() {
        return convertEndDate(endLoanDate);
    }

    public void setEndLoanDate(Date endLoanDate) {
        this.endLoanDate = endLoanDate;
    }

    public int getBeginSN() {
        return beginSN;
    }

    public void setBeginSN(int beginSN) {
        this.beginSN = beginSN;
    }

    public int getEndSN() {
        return endSN;
    }

    public void setEndSN(int endSN) {
        this.endSN = endSN;
    }

    @Override
    public String toString() {
        return "LstChannelCommisionDetailConditionVO{" +
                "traceID=" + DataUtils.toString(getTraceID()) + ", " +
                ", productAbbrName='" + productAbbrName + '\'' +
                ", channelAppName='" + channelAppName + '\'' +
                ", settleStatus=" + settleStatus +
                ", beginLoanDate=" + beginLoanDate +
                ", endLoanDate=" + endLoanDate +
                ", beginSN=" + beginSN +
                ", endSN=" + endSN +
                '}';
    }
}
