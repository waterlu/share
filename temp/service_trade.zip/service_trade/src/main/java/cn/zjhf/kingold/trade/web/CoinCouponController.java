package cn.zjhf.kingold.trade.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.constant.TradeStatusMsg;
import cn.zjhf.kingold.trade.entity.InVO.CashCouponVO;
import cn.zjhf.kingold.trade.entity.InVO.CoinExchangeVO;
import cn.zjhf.kingold.trade.entity.InVO.ProductClearParamVO;
import cn.zjhf.kingold.trade.service.ICoinCouponService;
import cn.zjhf.kingold.trade.utils.DataUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

/**
 * Created by zhangyijie on 2018/1/31.
 */
@RestController
@RequestMapping(value = "/coincoupon")
public class CoinCouponController {
    private static final Logger logger = LoggerFactory.getLogger(CoinCouponController.class);

    @Autowired
    ICoinCouponService coinCouponService;

    private ResponseResult creatOKRespResult(String traceID) {
        ResponseResult respResult = new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS,"成功");
        return respResult;
    }

    private ResponseResult creatOKRespResult(String traceID, Object data) {
        ResponseResult respResult = new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS,"成功", data);
        return respResult;
    }

    /**
     *
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/coinExchange", method = RequestMethod.POST)
    public ResponseResult coinExchange(@RequestBody CoinExchangeVO coinExchangeVO) throws BusinessException {
        logger.info("coinExchange start: " + DataUtils.toString(coinExchangeVO));
        DataUtils.checkParam(coinExchangeVO.getUserUuid());
        DataUtils.checkParam(coinExchangeVO.getCashCouponCode());

        String couponExtendRecordNo = coinCouponService.establishCoinExtendRecord(coinExchangeVO.getUserUuid(), coinExchangeVO.getCashCouponCode(), coinExchangeVO.getApplyScene());
        if(DataUtils.isEmpty(couponExtendRecordNo)) {
            throw new BusinessException(TradeStatusMsg.CASHCOUPON_BATCH_NOEXIST,
                    TradeStatusMsg.CASHCOUPON_BATCH_NOEXIST_MSG, false);
        }

        logger.info("coinExchange end: " + DataUtils.toString(coinExchangeVO.getTraceID(), couponExtendRecordNo));
        return creatOKRespResult(coinExchangeVO.getTraceID(), couponExtendRecordNo);
    }
}
