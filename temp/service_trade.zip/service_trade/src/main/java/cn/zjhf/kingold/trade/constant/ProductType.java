package cn.zjhf.kingold.trade.constant;

/**
 * Created by lutiehua on 2017/5/26.
 */
public interface ProductType {

    String PRODUCT_FT = "FIXI";

    String PRODUCT_PF = "PRIF";

}
