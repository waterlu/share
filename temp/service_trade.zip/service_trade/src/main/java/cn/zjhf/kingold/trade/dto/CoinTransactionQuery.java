package cn.zjhf.kingold.trade.dto;

import cn.zjhf.kingold.common.param.ParamVO;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.Size;
import java.util.Date;

/**
 * 积分流水查询参数对象
 *
 * @author shengkao
 * @date 2017-12-11
 */
public class CoinTransactionQuery extends ParamVO{

    /**
     * UUID
     *
     */
    @Size(max = 32)
    @ApiModelProperty(value = "UUID", required = false)
    private String ctUuid;

    /**
     * 用户UUID
     *
     */
    @Size(max = 32)
    @ApiModelProperty(value = "用户UUID", required = false)
    private String userUuid;

    /**
     * 投资人手机号码
     *
     */
    @Size(max = 16)
    @ApiModelProperty(value = "投资人手机号码", required = false)
    private String investorMobile;

    /**
     * 用户真实姓名
     *
     */
    @Size(max = 32)
    @ApiModelProperty(value = "用户真实姓名", required = false)
    private String investorRealName;

    /**
     * 账户UUID
     *
     */
    @Size(max = 32)
    @ApiModelProperty(value = "账户UUID", required = false)
    private String coinUuid;

    /**
     * 交易类型 （0：收入，1：支出，2 扣除，3 补偿）
     *
     */
    @Size(max = 10)
    @ApiModelProperty(value = "交易类型 （0：收入，1：支出，2 扣除，3 补偿）", required = false)
    private String ctType;

    /**
     * 交易流水uuid
     *
     */
    @Size(max = 32)
    @ApiModelProperty(value = "交易流水uuid", required = false)
    private String ctExchangeUuid;

    /**
     * 场景编码(1注册,2实名,3首次绑卡,4首次充值,5首次投资,6邀请好友首次投资,7复投,8邀请好友注册)
     *
     */
    @ApiModelProperty(value = "场景编码(1注册,2实名,3首次绑卡,4首次充值,5首次投资,6邀请好友首次投资,7复投,8邀请好友注册)", required = false)
    private Integer ctApplyScene;

    /**
     * 交易时间
     *
     */
    @ApiModelProperty(value = "交易时间", required = false)
    private Date ctTime;

    /**
     * 
     *
     */
    @ApiModelProperty(value = "", required = false)
    private Integer deleteFlag;

    /**
     * 
     *
     */
    @ApiModelProperty(value = "", required = false)
    private Date createTime;

    /**
     * 流水日期参数：查询开始日期
     *
     */
    @ApiModelProperty(value = "流水日期参数：查询开始日期", required = false)
    private Date startDate;

    /**
     * 流水日期参数：查询结束日期
     *
     */
    @ApiModelProperty(value = "流水日期参数：查询结束日期", required = false)
    private Date endDate;

    /**
     * 流水日期参数：查询结束日期的后一天
     *
     */
    @ApiModelProperty(value = "流水日期参数：查询结束日期的后一天", required = false)
    private Date endNextDate;

    /**
     * 排序规则
     *
     */
    @ApiModelProperty(value = "排序规则", required = false)
    private String orderBy;


    public String getCtUuid() {
        return ctUuid;
    }

    public void setCtUuid(String ctUuid) {
        this.ctUuid = ctUuid;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getInvestorMobile() {
        return investorMobile;
    }

    public void setInvestorMobile(String investorMobile) {
        this.investorMobile = investorMobile;
    }

    public String getInvestorRealName() {
        return investorRealName;
    }

    public void setInvestorRealName(String investorRealName) {
        this.investorRealName = investorRealName;
    }

    public String getCoinUuid() {
        return coinUuid;
    }

    public void setCoinUuid(String coinUuid) {
        this.coinUuid = coinUuid;
    }

    public String getCtType() {
        return ctType;
    }

    public void setCtType(String ctType) {
        this.ctType = ctType;
    }

    public String getCtExchangeUuid() {
        return ctExchangeUuid;
    }

    public void setCtExchangeUuid(String ctExchangeUuid) {
        this.ctExchangeUuid = ctExchangeUuid;
    }

    public Integer getCtApplyScene() {
        return ctApplyScene;
    }

    public void setCtApplyScene(Integer ctApplyScene) {
        this.ctApplyScene = ctApplyScene;
    }

    public Date getCtTime() {
        return ctTime;
    }

    public void setCtTime(Date ctTime) {
        this.ctTime = ctTime;
    }

    public Integer getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Integer deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getEndNextDate() {
        return endNextDate;
    }

    public void setEndNextDate(Date endNextDate) {
        this.endNextDate = endNextDate;
    }

    public String getOrderBy() {
        return orderBy;
    }

    public void setOrderBy(String orderBy) {
        this.orderBy = orderBy;
    }
}