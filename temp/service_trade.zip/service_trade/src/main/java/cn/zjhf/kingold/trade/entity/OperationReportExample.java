package cn.zjhf.kingold.trade.entity;

import java.util.ArrayList;
import java.util.List;

public class OperationReportExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private Integer limit;

    private Integer offset;

    public OperationReportExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andReportNoIsNull() {
            addCriterion("report_no is null");
            return (Criteria) this;
        }

        public Criteria andReportNoIsNotNull() {
            addCriterion("report_no is not null");
            return (Criteria) this;
        }

        public Criteria andReportNoEqualTo(String value) {
            addCriterion("report_no =", value, "reportNo");
            return (Criteria) this;
        }

        public Criteria andReportNoNotEqualTo(String value) {
            addCriterion("report_no <>", value, "reportNo");
            return (Criteria) this;
        }

        public Criteria andReportNoGreaterThan(String value) {
            addCriterion("report_no >", value, "reportNo");
            return (Criteria) this;
        }

        public Criteria andReportNoGreaterThanOrEqualTo(String value) {
            addCriterion("report_no >=", value, "reportNo");
            return (Criteria) this;
        }

        public Criteria andReportNoLessThan(String value) {
            addCriterion("report_no <", value, "reportNo");
            return (Criteria) this;
        }

        public Criteria andReportNoLessThanOrEqualTo(String value) {
            addCriterion("report_no <=", value, "reportNo");
            return (Criteria) this;
        }

        public Criteria andReportNoLike(String value) {
            addCriterion("report_no like", value, "reportNo");
            return (Criteria) this;
        }

        public Criteria andReportNoNotLike(String value) {
            addCriterion("report_no not like", value, "reportNo");
            return (Criteria) this;
        }

        public Criteria andReportNoIn(List<String> values) {
            addCriterion("report_no in", values, "reportNo");
            return (Criteria) this;
        }

        public Criteria andReportNoNotIn(List<String> values) {
            addCriterion("report_no not in", values, "reportNo");
            return (Criteria) this;
        }

        public Criteria andReportNoBetween(String value1, String value2) {
            addCriterion("report_no between", value1, value2, "reportNo");
            return (Criteria) this;
        }

        public Criteria andReportNoNotBetween(String value1, String value2) {
            addCriterion("report_no not between", value1, value2, "reportNo");
            return (Criteria) this;
        }

        public Criteria andBatchNoIsNull() {
            addCriterion("batch_no is null");
            return (Criteria) this;
        }

        public Criteria andBatchNoIsNotNull() {
            addCriterion("batch_no is not null");
            return (Criteria) this;
        }

        public Criteria andBatchNoEqualTo(Byte value) {
            addCriterion("batch_no =", value, "batchNo");
            return (Criteria) this;
        }

        public Criteria andBatchNoNotEqualTo(Byte value) {
            addCriterion("batch_no <>", value, "batchNo");
            return (Criteria) this;
        }

        public Criteria andBatchNoGreaterThan(Byte value) {
            addCriterion("batch_no >", value, "batchNo");
            return (Criteria) this;
        }

        public Criteria andBatchNoGreaterThanOrEqualTo(Byte value) {
            addCriterion("batch_no >=", value, "batchNo");
            return (Criteria) this;
        }

        public Criteria andBatchNoLessThan(Byte value) {
            addCriterion("batch_no <", value, "batchNo");
            return (Criteria) this;
        }

        public Criteria andBatchNoLessThanOrEqualTo(Byte value) {
            addCriterion("batch_no <=", value, "batchNo");
            return (Criteria) this;
        }

        public Criteria andBatchNoIn(List<Byte> values) {
            addCriterion("batch_no in", values, "batchNo");
            return (Criteria) this;
        }

        public Criteria andBatchNoNotIn(List<Byte> values) {
            addCriterion("batch_no not in", values, "batchNo");
            return (Criteria) this;
        }

        public Criteria andBatchNoBetween(Byte value1, Byte value2) {
            addCriterion("batch_no between", value1, value2, "batchNo");
            return (Criteria) this;
        }

        public Criteria andBatchNoNotBetween(Byte value1, Byte value2) {
            addCriterion("batch_no not between", value1, value2, "batchNo");
            return (Criteria) this;
        }

        public Criteria andReportRuleIsNull() {
            addCriterion("report_rule is null");
            return (Criteria) this;
        }

        public Criteria andReportRuleIsNotNull() {
            addCriterion("report_rule is not null");
            return (Criteria) this;
        }

        public Criteria andReportRuleEqualTo(String value) {
            addCriterion("report_rule =", value, "reportRule");
            return (Criteria) this;
        }

        public Criteria andReportRuleNotEqualTo(String value) {
            addCriterion("report_rule <>", value, "reportRule");
            return (Criteria) this;
        }

        public Criteria andReportRuleGreaterThan(String value) {
            addCriterion("report_rule >", value, "reportRule");
            return (Criteria) this;
        }

        public Criteria andReportRuleGreaterThanOrEqualTo(String value) {
            addCriterion("report_rule >=", value, "reportRule");
            return (Criteria) this;
        }

        public Criteria andReportRuleLessThan(String value) {
            addCriterion("report_rule <", value, "reportRule");
            return (Criteria) this;
        }

        public Criteria andReportRuleLessThanOrEqualTo(String value) {
            addCriterion("report_rule <=", value, "reportRule");
            return (Criteria) this;
        }

        public Criteria andReportRuleLike(String value) {
            addCriterion("report_rule like", value, "reportRule");
            return (Criteria) this;
        }

        public Criteria andReportRuleNotLike(String value) {
            addCriterion("report_rule not like", value, "reportRule");
            return (Criteria) this;
        }

        public Criteria andReportRuleIn(List<String> values) {
            addCriterion("report_rule in", values, "reportRule");
            return (Criteria) this;
        }

        public Criteria andReportRuleNotIn(List<String> values) {
            addCriterion("report_rule not in", values, "reportRule");
            return (Criteria) this;
        }

        public Criteria andReportRuleBetween(String value1, String value2) {
            addCriterion("report_rule between", value1, value2, "reportRule");
            return (Criteria) this;
        }

        public Criteria andReportRuleNotBetween(String value1, String value2) {
            addCriterion("report_rule not between", value1, value2, "reportRule");
            return (Criteria) this;
        }

        public Criteria andBatchDescIsNull() {
            addCriterion("batch_desc is null");
            return (Criteria) this;
        }

        public Criteria andBatchDescIsNotNull() {
            addCriterion("batch_desc is not null");
            return (Criteria) this;
        }

        public Criteria andBatchDescEqualTo(String value) {
            addCriterion("batch_desc =", value, "batchDesc");
            return (Criteria) this;
        }

        public Criteria andBatchDescNotEqualTo(String value) {
            addCriterion("batch_desc <>", value, "batchDesc");
            return (Criteria) this;
        }

        public Criteria andBatchDescGreaterThan(String value) {
            addCriterion("batch_desc >", value, "batchDesc");
            return (Criteria) this;
        }

        public Criteria andBatchDescGreaterThanOrEqualTo(String value) {
            addCriterion("batch_desc >=", value, "batchDesc");
            return (Criteria) this;
        }

        public Criteria andBatchDescLessThan(String value) {
            addCriterion("batch_desc <", value, "batchDesc");
            return (Criteria) this;
        }

        public Criteria andBatchDescLessThanOrEqualTo(String value) {
            addCriterion("batch_desc <=", value, "batchDesc");
            return (Criteria) this;
        }

        public Criteria andBatchDescLike(String value) {
            addCriterion("batch_desc like", value, "batchDesc");
            return (Criteria) this;
        }

        public Criteria andBatchDescNotLike(String value) {
            addCriterion("batch_desc not like", value, "batchDesc");
            return (Criteria) this;
        }

        public Criteria andBatchDescIn(List<String> values) {
            addCriterion("batch_desc in", values, "batchDesc");
            return (Criteria) this;
        }

        public Criteria andBatchDescNotIn(List<String> values) {
            addCriterion("batch_desc not in", values, "batchDesc");
            return (Criteria) this;
        }

        public Criteria andBatchDescBetween(String value1, String value2) {
            addCriterion("batch_desc between", value1, value2, "batchDesc");
            return (Criteria) this;
        }

        public Criteria andBatchDescNotBetween(String value1, String value2) {
            addCriterion("batch_desc not between", value1, value2, "batchDesc");
            return (Criteria) this;
        }

        public Criteria andReportDescIsNull() {
            addCriterion("report_desc is null");
            return (Criteria) this;
        }

        public Criteria andReportDescIsNotNull() {
            addCriterion("report_desc is not null");
            return (Criteria) this;
        }

        public Criteria andReportDescEqualTo(String value) {
            addCriterion("report_desc =", value, "reportDesc");
            return (Criteria) this;
        }

        public Criteria andReportDescNotEqualTo(String value) {
            addCriterion("report_desc <>", value, "reportDesc");
            return (Criteria) this;
        }

        public Criteria andReportDescGreaterThan(String value) {
            addCriterion("report_desc >", value, "reportDesc");
            return (Criteria) this;
        }

        public Criteria andReportDescGreaterThanOrEqualTo(String value) {
            addCriterion("report_desc >=", value, "reportDesc");
            return (Criteria) this;
        }

        public Criteria andReportDescLessThan(String value) {
            addCriterion("report_desc <", value, "reportDesc");
            return (Criteria) this;
        }

        public Criteria andReportDescLessThanOrEqualTo(String value) {
            addCriterion("report_desc <=", value, "reportDesc");
            return (Criteria) this;
        }

        public Criteria andReportDescLike(String value) {
            addCriterion("report_desc like", value, "reportDesc");
            return (Criteria) this;
        }

        public Criteria andReportDescNotLike(String value) {
            addCriterion("report_desc not like", value, "reportDesc");
            return (Criteria) this;
        }

        public Criteria andReportDescIn(List<String> values) {
            addCriterion("report_desc in", values, "reportDesc");
            return (Criteria) this;
        }

        public Criteria andReportDescNotIn(List<String> values) {
            addCriterion("report_desc not in", values, "reportDesc");
            return (Criteria) this;
        }

        public Criteria andReportDescBetween(String value1, String value2) {
            addCriterion("report_desc between", value1, value2, "reportDesc");
            return (Criteria) this;
        }

        public Criteria andReportDescNotBetween(String value1, String value2) {
            addCriterion("report_desc not between", value1, value2, "reportDesc");
            return (Criteria) this;
        }
    }

    /**
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}