package cn.zjhf.kingold.trade.entity.InVO;

import cn.zjhf.kingold.trade.utils.DataUtils;
import cn.zjhf.kingold.trade.utils.WhereCondition;
import io.swagger.annotations.ApiModelProperty;

import java.util.Date;

/**
 * Created by zhangyijie on 2017/7/21.
 */
public class ReconcConditionVO extends InVOBase {
    @ApiModelProperty(required = true, value = "用户名")
    private String userPhone;

    @ApiModelProperty(required = true, value = "对账类型(1投资, 2放款, 3退款, 4还款, 5充值, 6提现, 7转账, 11账户余额)")
    private int reconcType;

    @ApiModelProperty(required = true, value = "账户类型：1个人，2机构，  仅账户余额对账时使用")
    private int acctType;

    @ApiModelProperty(required = false, value = "开始时间")
    private Date startTime;

    @ApiModelProperty(required = false, value = "结束时间")
    private Date endTime;

    @ApiModelProperty(required = true, value = "起始序号")
    private int beginSN;

    @ApiModelProperty(required = true, value = "结束序号")
    private int endSN;

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    public int getReconcType() {
        return reconcType;
    }

    public void setReconcType(int reconcType) {
        this.reconcType = reconcType;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
        //return convertEndDate(endTime);
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public int getBeginSN() {
        return beginSN;
    }

    public void setBeginSN(int beginSN) {
        this.beginSN = beginSN;
    }

    public int getEndSN() {
        return endSN;
    }

    public void setEndSN(int endSN) {
        this.endSN = endSN;
    }

    public String getPageCondi(String... args) {
        return WhereCondition.getPageCondi(beginSN, endSN, args);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(getTraceID()) + ", ");
        sb.append("userPhone:" + DataUtils.toString(userPhone) + ", ");
        sb.append("reconcType:" + DataUtils.toString(reconcType) + ", ");
        sb.append("acctType:" + DataUtils.toString(acctType) + ", ");

        sb.append("startTime:" + DataUtils.toString(startTime) + ", ");
        sb.append("endTime:" + DataUtils.toString(endTime) + ", ");
        sb.append("beginSN:" + DataUtils.toString(beginSN) +", ");
        sb.append("endSN:" + DataUtils.toString(endSN));
        return sb.toString();
    }

    public int getAcctType() {
        return acctType;
    }

    public void setAcctType(int acctType) {
        this.acctType = acctType;
    }
}
