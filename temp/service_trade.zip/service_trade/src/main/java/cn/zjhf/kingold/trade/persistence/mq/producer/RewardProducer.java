package cn.zjhf.kingold.trade.persistence.mq.producer;

import cn.zjhf.kingold.rocketmq.annotation.RocketMQProducer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQProducer;
import cn.zjhf.kingold.trade.persistence.mq.message.RewardMessage;
import cn.zjhf.kingold.trade.persistence.mq.message.RewardPrivateFundMessage;

/**
 * Created by Xiaody on 17/7/27.
 * 生成奖励
 *
 */
@RocketMQProducer(topic = "reward",tag = "reward")
public class RewardProducer extends AbstractMQProducer<RewardMessage>{

}
