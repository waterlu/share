package cn.zjhf.kingold.trade.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author 
 */
public class ChannelCommisionSummary implements Serializable {
    /**
     * 请求结算单号
     */
    private String channelCommisionSummaryId;

    /**
     * 请求周期，格式: YYYY.MM
     */
    private String requestCycle;

    /**
     * 商户号，5位数字 （如：10001）
     */
    private String merchantNum;

    /**
     * APP名称/渠道名称
     */
    private String channelAppName;

    /**
     * 佣金
     */
    private BigDecimal commisionAmount;

    /**
     * 结算状态: -1审核失败；1待审核；2已结算
     */
    private Byte settleStatus;

    /**
     * 审核结算操作人
     */
    private String settleOperator;

    /**
     * 结算时间
     */
    private Date settleTime;

    /**
     * 审核意见/备注
     */
    private String auditOpinion;

    /**
     * 删除标记 0未删除，1已删除
     */
    private Byte deleteFlag;

    private Date createTime;

    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public String getChannelCommisionSummaryId() {
        return channelCommisionSummaryId;
    }

    public void setChannelCommisionSummaryId(String channelCommisionSummaryId) {
        this.channelCommisionSummaryId = channelCommisionSummaryId;
    }

    public String getRequestCycle() {
        return requestCycle;
    }

    public void setRequestCycle(String requestCycle) {
        this.requestCycle = requestCycle;
    }

    public String getMerchantNum() {
        return merchantNum;
    }

    public void setMerchantNum(String merchantNum) {
        this.merchantNum = merchantNum;
    }

    public String getChannelAppName() {
        return channelAppName;
    }

    public void setChannelAppName(String channelAppName) {
        this.channelAppName = channelAppName;
    }

    public BigDecimal getCommisionAmount() {
        return commisionAmount;
    }

    public void setCommisionAmount(BigDecimal commisionAmount) {
        this.commisionAmount = commisionAmount;
    }

    public Byte getSettleStatus() {
        return settleStatus;
    }

    public void setSettleStatus(Byte settleStatus) {
        this.settleStatus = settleStatus;
    }

    public String getSettleOperator() {
        return settleOperator;
    }

    public void setSettleOperator(String settleOperator) {
        this.settleOperator = settleOperator;
    }

    public Date getSettleTime() {
        return settleTime;
    }

    public void setSettleTime(Date settleTime) {
        this.settleTime = settleTime;
    }

    public String getAuditOpinion() {
        return auditOpinion;
    }

    public void setAuditOpinion(String auditOpinion) {
        this.auditOpinion = auditOpinion;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}