package cn.zjhf.kingold.trade.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class UserUnbindBankCardChangeLog implements Serializable {
    /**
     * 自增主键
     */
    private Integer id;

    /**
     * 用户UUID
     */
    private String userUuid;

    /**
     * 解绑绑定的银行卡/账户信息（JSON）
     */
    private String beforeUserBankCardInfo;

    /**
     * 变更原因
     */
    private String changeReason;

    /**
     * 操作人
     */
    private String operator;

    /**
     * 删除标记 0未删除，1已删除
     */
    private Byte deleteFlag;

    /**
     * 创建时间
     */
    private Date createTime;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getBeforeUserBankCardInfo() {
        return beforeUserBankCardInfo;
    }

    public void setBeforeUserBankCardInfo(String beforeUserBankCardInfo) {
        this.beforeUserBankCardInfo = beforeUserBankCardInfo;
    }

    public String getChangeReason() {
        return changeReason;
    }

    public void setChangeReason(String changeReason) {
        this.changeReason = changeReason;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public UserUnbindBankCardChangeLog() {
    }
    public UserUnbindBankCardChangeLog(String userUuid,String beforeUserBankCardInfo,String changeReason ,String operator) {
        this.userUuid = userUuid;
        this.beforeUserBankCardInfo = beforeUserBankCardInfo;
        this.changeReason = changeReason;
        this.operator = operator;
    }
}