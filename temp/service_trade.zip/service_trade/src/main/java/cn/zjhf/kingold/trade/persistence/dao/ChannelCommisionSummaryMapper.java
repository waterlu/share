package cn.zjhf.kingold.trade.persistence.dao;

import cn.zjhf.kingold.trade.entity.ChannelCommisionDetail;
import cn.zjhf.kingold.trade.entity.ChannelCommisionSummary;
import cn.zjhf.kingold.trade.entity.ChannelCommisionSummaryExample;
import java.util.List;

import cn.zjhf.kingold.trade.utils.QueryUtils;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface ChannelCommisionSummaryMapper {
    long countByExample(ChannelCommisionSummaryExample example);

    int deleteByExample(ChannelCommisionSummaryExample example);

    int deleteByPrimaryKey(String channelCommisionSummaryId);

    int insert(ChannelCommisionSummary record);

    int insertSelective(ChannelCommisionSummary record);

    @Select("${condition}")
    @ResultMap("BaseResultMap")
    List<ChannelCommisionSummary> lstItemDatas(QueryUtils condition);

    @Select("SELECT channel_commision_summary_id FROM channel_commision_summary WHERE request_cycle=#{requestCycle} AND settle_status!=-1 AND delete_flag=0")
    List<String> lstAuditFailRequestID(@Param("requestCycle") String requestCycle);

    @Select("SELECT channel_commision_summary_id FROM channel_commision_summary WHERE " +
            "request_cycle=#{requestCycle} AND merchant_num=#{merchantNum} AND settle_status!=-1 " +
            "AND delete_flag=0 ORDER BY create_time DESC LIMIT 0,1")
    String lstRequestID(@Param("requestCycle") String requestCycle, @Param("merchantNum") String merchantNum);

    @Update("${condition}")
    int updateSummary(QueryUtils condition);

    List<ChannelCommisionSummary> selectByExample(ChannelCommisionSummaryExample example);

    ChannelCommisionSummary selectByPrimaryKey(String channelCommisionSummaryId);

    int updateByExampleSelective(@Param("record") ChannelCommisionSummary record, @Param("example") ChannelCommisionSummaryExample example);

    int updateByExample(@Param("record") ChannelCommisionSummary record, @Param("example") ChannelCommisionSummaryExample example);

    int updateByPrimaryKeySelective(ChannelCommisionSummary record);

    int updateByPrimaryKey(ChannelCommisionSummary record);
}