package cn.zjhf.kingold.trade.dto;

import cn.zjhf.kingold.common.param.ParamVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotBlank;

/**
 * 
 * 
 * Created by null on 2017/06/14.
 * 
 */
@ApiModel(description = "")
public class RewardServiceAllowanceDto extends ParamVO implements Serializable {
    @NotBlank(message = "rewardAllowanceBillCode不能为空")
    @Size(min = 24, max = 24)
    @ApiModelProperty(value = "发放单号", required = true)
    private String rewardAllowanceBillCode;

    @ApiModelProperty(value = "结算周期起始日", required = true)
    private Date rewardAllowanceStartDate;

    @ApiModelProperty(value = "结算周期截止日", required = true)
    private Date rewardAllowanceEndDate;

    @NotNull(message = "rewardAllowanceStatus不能为空")
    @Min(value = -128)
    @Max(value = 127)
    @ApiModelProperty(value = "发放状态", allowableValues = "1=状态1 2=状态2 3=状态3")
    private Integer rewardAllowanceStatus;

    @Size(max = 64)
    @ApiModelProperty(value = "所属机构ID")
    private String orgUuid;

    @Size(max = 512)
    @ApiModelProperty(value = "所属机构树形关系")
    private String orgPath;

    @NotBlank(message = "userUuid不能为空")
    @Size(min = 32, max = 32)
    @ApiModelProperty(value = "用户UUID", required = true)
    private String userUuid;

    @Size(max = 16)
    @ApiModelProperty(value = "用户手机号码")
    private String userMobile;

    @Size(max = 32)
    @ApiModelProperty(value = "用户姓名")
    private String userRealName;

    @Size(max = 32)
    @ApiModelProperty(value = "用户身份证号码")
    private String userIdCardNo;

    @NotNull(message = "rewardCount不能为空")
    @ApiModelProperty(value = "奖励单数", required = true)
    private Integer rewardCount;

    @NotNull(message = "rewardAmount不能为空")
    @ApiModelProperty(value = "奖励金额（税前服务津贴）", required = true)
    private BigDecimal rewardAmount;

    @ApiModelProperty(value = "记录创建时间")
    private Date createTime;

    @ApiModelProperty(value = "审核时间")
    private Date checkTime;

    @ApiModelProperty(value = "结算时间")
    private Date clearTime;

    @Size(max = 32)
    @ApiModelProperty(value = "创建人")
    private String createUser;

    @Size(max = 32)
    @ApiModelProperty(value = "审核人")
    private String checkUser;

    @Size(max = 32)
    @ApiModelProperty(value = "结算人")
    private String clearUser;

    @Size(max = 255)
    @ApiModelProperty(value = "备注")
    private String remark;

    private static final long serialVersionUID = 1L;

    public String getRewardAllowanceBillCode() {
        return rewardAllowanceBillCode;
    }

    public void setRewardAllowanceBillCode(String rewardAllowanceBillCode) {
        this.rewardAllowanceBillCode = rewardAllowanceBillCode;
    }

    public Date getRewardAllowanceStartDate() {
        return rewardAllowanceStartDate;
    }

    public void setRewardAllowanceStartDate(Date rewardAllowanceStartDate) {
        this.rewardAllowanceStartDate = rewardAllowanceStartDate;
    }

    public Date getRewardAllowanceEndDate() {
        return rewardAllowanceEndDate;
    }

    public void setRewardAllowanceEndDate(Date rewardAllowanceEndDate) {
        this.rewardAllowanceEndDate = rewardAllowanceEndDate;
    }

    public Integer getRewardAllowanceStatus() {
        return rewardAllowanceStatus;
    }

    public void setRewardAllowanceStatus(Integer rewardAllowanceStatus) {
        this.rewardAllowanceStatus = rewardAllowanceStatus;
    }

    public String getOrgUuid() {
        return orgUuid;
    }

    public void setOrgUuid(String orgUuid) {
        this.orgUuid = orgUuid;
    }

    public String getOrgPath() {
        return orgPath;
    }

    public void setOrgPath(String orgPath) {
        this.orgPath = orgPath;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getUserMobile() {
        return userMobile;
    }

    public void setUserMobile(String userMobile) {
        this.userMobile = userMobile;
    }

    public String getUserRealName() {
        return userRealName;
    }

    public void setUserRealName(String userRealName) {
        this.userRealName = userRealName;
    }

    public String getUserIdCardNo() {
        return userIdCardNo;
    }

    public void setUserIdCardNo(String userIdCardNo) {
        this.userIdCardNo = userIdCardNo;
    }

    public Integer getRewardCount() {
        return rewardCount;
    }

    public void setRewardCount(Integer rewardCount) {
        this.rewardCount = rewardCount;
    }

    public BigDecimal getRewardAmount() {
        return rewardAmount;
    }

    public void setRewardAmount(BigDecimal rewardAmount) {
        this.rewardAmount = rewardAmount;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getCheckTime() {
        return checkTime;
    }

    public void setCheckTime(Date checkTime) {
        this.checkTime = checkTime;
    }

    public Date getClearTime() {
        return clearTime;
    }

    public void setClearTime(Date clearTime) {
        this.clearTime = clearTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public String getCheckUser() {
        return checkUser;
    }

    public void setCheckUser(String checkUser) {
        this.checkUser = checkUser;
    }

    public String getClearUser() {
        return clearUser;
    }

    public void setClearUser(String clearUser) {
        this.clearUser = clearUser;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}