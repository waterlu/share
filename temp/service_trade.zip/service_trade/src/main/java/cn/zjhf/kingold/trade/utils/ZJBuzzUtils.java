package cn.zjhf.kingold.trade.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

/**
 * Created by DELL on 2017/5/16.
 */
public class ZJBuzzUtils {

    /**
     * 产生单据编号
     *
     * @param prefix
     * @return
     */
    public static String generateOrderBillCode(String prefix) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        Date now = new Date();
        String timeString = dateFormat.format(now);
        int randomNumber = RandUtil.getRandomNumbers(10000);
        String postfix = String.format("%04d", randomNumber);
        String billCode = prefix + timeString + postfix;
        return billCode;
    }

    /**
     * 产生UUID
     *
     * @return
     */
    public static String generateUUID() {
        return UUID.randomUUID().toString().replaceAll("-", "");
    }

}
