package cn.zjhf.kingold.trade.constant;

/**
 * Created by lutiehua on 2017/4/28.
 */
public interface PayMethod {
    /**
     * 快捷支付
     */
    byte SWIFT = 1;

    /**
     * 网银支付
     */
    byte PC = 2;

    /**
     * 支票转账
     */
    byte CHEQUE = 3;

}
