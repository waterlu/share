package cn.zjhf.kingold.trade.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.dto.RewardSearchDto;
import cn.zjhf.kingold.trade.entity.Reward;
import cn.zjhf.kingold.trade.entity.TradeOrder;
import cn.zjhf.kingold.trade.entity.TradePrivateFundOrder;
import cn.zjhf.kingold.trade.vo.RewardConfigVO;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * Created by lutiehua on 2017/5/26.
 */
public interface IRewardService {

    /**
     * 生成定期产品奖励记录
     *
     * @return
     * @throws BusinessException
     */
    boolean generateFTAwardRecord(TradeOrder tradeOrder) throws BusinessException;

    /**
     * 生成定期产品达人产品奖励记录
     * @return
     * @throws BusinessException
     */
    boolean generateMasterFTAwardRecord(TradeOrder tradeOrder, String masterAward) throws BusinessException;

    /**
     * 生成私募产品奖励记录
     *
     * @return
     * @throws BusinessException
     */
    boolean generatePFAwardRecord(TradePrivateFundOrder tradeOrder) throws BusinessException;

    /**
     * 产品成立时更新奖励状态
     *
     * @return
     * @throws BusinessException
     */
    boolean updateProductRewardRecord(String productUuid) throws BusinessException;

    /**
     * 产品成立时更新私募产品奖励状态
     *
     * @return
     * @throws BusinessException
     */
    boolean updatePrivateProductRewardRecord(String productUuid) throws BusinessException;

    /**
     * 根据条件查询奖励记录（分页查询）
     *
     * @param searchCondition
     * @return
     * @throws BusinessException
     */
    List<Reward> searchReward(RewardSearchDto searchCondition) throws BusinessException;

    /**
     * 根据条件查询奖励记录总数
     *
     * @param searchCondition
     * @return
     * @throws BusinessException
     */
    int searchRewardCount(RewardSearchDto searchCondition) throws BusinessException;

    /**
     *
     * @param summaryBillCode
     * @return
     * @throws BusinessException
     */
    List<Reward> searchSummaryReward(String summaryBillCode, int pageNo, int pageSize) throws BusinessException;

    /**
     *
     * @param summaryBillCode
     * @return
     * @throws BusinessException
     */
    int searchSummaryRewardCount(String summaryBillCode) throws BusinessException;

    /**
     * 申请批量审批的准备工作
     *
     * @param searchCondition
     * @return
     * @throws BusinessException
     */
    List<Reward> preApply(RewardSearchDto searchCondition) throws BusinessException;

    /**
     * 申请服务津贴批量审批的准备工作
     *
     * @param searchCondition
     * @return
     * @throws BusinessException
     */
    List<Reward> preApplyService(RewardSearchDto searchCondition) throws BusinessException;

    List<Reward> getRewardList(String userUUid , Integer rewardStatus, Integer rewardType, Integer offset, Integer limit);

    List<Map<String, BigDecimal>> listOrderBySum(String userUUid , Integer isInvest, Integer offset, Integer limit);

    Map<String, BigDecimal> getRewardSumListByUuids(List<String> invitedUuidList, String userUuid, String productType) ;

    Integer getRewardCount(String userUUid , Integer rewardStatus, Integer rewardType);

    Reward getRewardDetail(String rewardBillCode);

    Map<String, String> getRewardSum(String userUUid , Integer rewardType);

    /**
     * 获取平台总共奖励额
     * @return
     */
    BigDecimal getTotalAmount();

    /**
     * 获取配置信息
     *
     * @return
     */
    RewardConfigVO getConfig();

    /**
     * 设置配置信息
     *
     * @param configVO
     * @return
     */
    RewardConfigVO setConfig(RewardConfigVO configVO) throws BusinessException;
}
