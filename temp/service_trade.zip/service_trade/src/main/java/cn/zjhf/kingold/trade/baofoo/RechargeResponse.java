package cn.zjhf.kingold.trade.baofoo;

/**
 * Created by lutiehua on 2017/4/27.
 */
public class RechargeResponse {

    private String code;

    private String order_id;

    private double incash_money;

    private double fee;

    private double mer_fee;

    private int fee_taken_on;

    private String additional_info;

    private String succ_time;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public double getIncash_money() {
        return incash_money;
    }

    public void setIncash_money(double incash_money) {
        this.incash_money = incash_money;
    }

    public double getFee() {
        return fee;
    }

    public void setFee(double fee) {
        this.fee = fee;
    }

    public double getMer_fee() {
        return mer_fee;
    }

    public void setMer_fee(double mer_fee) {
        this.mer_fee = mer_fee;
    }

    public int getFee_taken_on() {
        return fee_taken_on;
    }

    public void setFee_taken_on(int fee_taken_on) {
        this.fee_taken_on = fee_taken_on;
    }

    public String getSucc_time() {
        return succ_time;
    }

    public void setSucc_time(String succ_time) {
        this.succ_time = succ_time;
    }

    public String getAdditional_info() {
        return additional_info;
    }

    public void setAdditional_info(String additional_info) {
        this.additional_info = additional_info;
    }
}
