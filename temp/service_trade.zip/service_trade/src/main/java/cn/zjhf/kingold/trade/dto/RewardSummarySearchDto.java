package cn.zjhf.kingold.trade.dto;

import cn.zjhf.kingold.common.param.ParamVO;

import java.util.Date;

/**
 * 定期奖励结算查询条件
 *
 * Created by lutiehua on 2017/6/1.
 */
public class RewardSummarySearchDto extends ParamVO {

    /**
     * offset
     */
    private Integer pageNo;

    /**
     * limit
     */
    private Integer pageSize;

    /**
     * 结算单号
     */
    private String orderBillCode;

    /**
     * 手机
     */
    private String userMobile;

    /**
     * 姓名
     */
    private String userName;

    /**
     * 定期奖励结算状态
     */
    private Integer rewardStatus;

    /**
     * 结算日期-开始（查询时使用）
     */
    private Date clearStartDate;

    /**
     * 结算日期-结束（查询时使用）
     */
    private Date clearEndDate;

    /**
     * 结算周期-开始（汇总时使用）
     */
    private Date startDate;

    /**
     * 结算周期-结束（汇总时使用）
     */
    private Date endDate;

    /**
     * 批次号
     */
    private String batchCode;

    /**
     * 所属专职理财师uuid
     */
    private String belongTopUserUuid;

    /**
     * 所属专职理财师组织机构Path
     */
    private String belongTopOrgPath;

    public String getBelongTopUserUuid() {
        return belongTopUserUuid;
    }

    public void setBelongTopUserUuid(String belongTopUserUuid) {
        this.belongTopUserUuid = belongTopUserUuid;
    }

    public String getBelongTopOrgPath() {
        return belongTopOrgPath;
    }

    public void setBelongTopOrgPath(String belongTopOrgPath) {
        this.belongTopOrgPath = belongTopOrgPath;
    }

    public Integer getPageNo() {
        return pageNo;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getUserMobile() {
        return userMobile;
    }

    public void setUserMobile(String userMobile) {
        this.userMobile = userMobile;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getOrderBillCode() {
        return orderBillCode;
    }

    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    public Date getClearStartDate() {
        return clearStartDate;
    }

    public void setClearStartDate(Date clearStartDate) {
        this.clearStartDate = clearStartDate;
    }

    public Date getClearEndDate() {
        return clearEndDate;
    }

    public void setClearEndDate(Date clearEndDate) {
        this.clearEndDate = clearEndDate;
    }


    public Integer getRewardStatus() {
        return rewardStatus;
    }

    public void setRewardStatus(Integer rewardStatus) {
        this.rewardStatus = rewardStatus;
    }

    public String getBatchCode() {
        return batchCode;
    }

    public void setBatchCode(String batchCode) {
        this.batchCode = batchCode;
    }
}
