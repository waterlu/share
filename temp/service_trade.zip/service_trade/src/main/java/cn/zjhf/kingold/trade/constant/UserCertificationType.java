package cn.zjhf.kingold.trade.constant;

/**
 * Created by lutiehua on 2017/6/5.
 */
public interface UserCertificationType {

    /**
     * 理财师认证
     */
    int FINANCIAL_PLANNER = 1;

    /**
     * 合格投资者认证
     */
    int PRIVATE_INVESTOR = 2;
}
