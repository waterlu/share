package cn.zjhf.kingold.trade.service;

import cn.zjhf.kingold.trade.persistence.dao.CouponExtendRecordMapper;
import cn.zjhf.kingold.trade.persistence.dao.TradeOrderMapper;
import cn.zjhf.kingold.trade.service.impl.CashCouponServiceImpl;

/**
 * Created by zhangyijie on 2017/8/28.
 */
public interface ISequenceService {

    String getCashCouponCode(CashCouponServiceImpl cashCouponService);

    String getSubContractNo(TradeOrderMapper tradeOrderMapper);

    String getCouponExtendRecordNo(CouponExtendRecordMapper couponExtendRecordMapper);
}
