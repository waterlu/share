package cn.zjhf.kingold.trade.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.utils.Tuple.TwoTuple;

/**
 * Created by zhangyijie on 2018/2/1.
 */
public interface IDrawRedPacketService {

    void drawRedPacketFail(Long redPacketId, String errMess) throws BusinessException;

    /**
     * 领取红包
     * @param
     * @return 1领取成功，2领取失败
     * @throws BusinessException
     */
    TwoTuple<Integer, String> drawRedPacket(String userUuid, Long redPacketId) throws BusinessException;
}
