package cn.zjhf.kingold.trade.persistence.mq.consumer;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.rocketmq.annotation.RocketMQConsumer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQConsumer;
import cn.zjhf.kingold.rocketmq.base.SimpleMessage;
import cn.zjhf.kingold.trade.baofoo.BaoFooCode;
import cn.zjhf.kingold.trade.constant.PayStatus;
import cn.zjhf.kingold.trade.constant.RechargeStatusParamEnum;
import cn.zjhf.kingold.trade.entity.TradeRecharge;
import cn.zjhf.kingold.trade.service.IPayService;
import cn.zjhf.kingold.trade.service.ITradeService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;
import java.util.Map;

/**
 * 申请提现，查询提现状态，处理中再次消费。
 *
 * Created by lutiehua on 2017/7/13.
 */
@RocketMQConsumer(topic = "pay", tag = "withdraw")
public class PayWithdrawConsumer extends AbstractMQConsumer<SimpleMessage> {

    @Autowired
    private IPayService payService;

    @Autowired
    private ITradeService tradeService;
    private final static long ONE_HOUR_MILLIS = 60 * 60 * 1000;

    @Override
    public ResponseResult process(SimpleMessage simpleMessage) throws BusinessException {
        ResponseResult responseResult = new ResponseResult();
        String orderBillCode = simpleMessage.getData();
        logger.info("query withdraw. orderBillCode={}", orderBillCode);

        ResponseResult result = payService.query(IPayService.TYPE_WITHDRAW, orderBillCode);
        if (!result.isSuccessful()) {
            responseResult.setCode(result.getCode());
            responseResult.setMsg(result.getMsg());
            return responseResult;
        }

        Map<String, Object> data = (Map<String, Object>) result.getData();
        if (null == data) {
            responseResult.setCode(ResponseCode.EXCEPTION);
            responseResult.setMsg("data is null.");
            return responseResult;
        }

        String state = data.get("state").toString();
        String queryResult = data.get("result").toString();
        if (BaoFooCode.WITHDRAW_SUCCESS.equals(state)) {
            logger.info("withdraw success. orderBillCode={}", orderBillCode);
            payService.updatePayLog(orderBillCode, PayStatus.SUCCESSFUL, queryResult);
            tradeService.executeBill(orderBillCode);
        } else if (BaoFooCode.WITHDRAW_ERROR.equals(state)) {
            payService.updatePayLog(orderBillCode, PayStatus.FAILED, queryResult);
            tradeService.cancelExecuteBill(orderBillCode,responseResult.getMsg());
            logger.warn("withdraw failed. orderBillCode={}, response={}", orderBillCode, responseResult);
        } else {
            logger.info("withdraw state. state={}", state);
            responseResult.setCode(ResponseCode.EXCEPTION);
            responseResult.setMsg(state);
            return responseResult;
        }

        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        return responseResult;
    }
}
