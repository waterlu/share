package cn.zjhf.kingold.trade.constant;

/**
 * Created by lutiehua on 2017/4/28.
 */
public interface TradeStatus {

    /**
     * 新建
     */
    byte NEW = 0;

    /**
     * 成功
     */
    byte SUCCESS = 1;

    /**
     * 失败
     */
    byte FAILURE = 2;

    /**
     * 取消
     */
    byte CANCEL = 3;

    int ORDER_STATUS_NEW = 1;

    int ORDER_STATUS_INVEST = 2;

    int ORDER_STATUS_REFUND = 3;

    int ORDER_STATUS_LOAN = 4;

    int ORDER_STATUS_RETURN = 5;

    int ORDER_STATUS_CLOSED = 6;
}
