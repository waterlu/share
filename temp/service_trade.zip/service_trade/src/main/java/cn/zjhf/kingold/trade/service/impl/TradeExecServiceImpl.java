package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.constant.*;
import cn.zjhf.kingold.trade.entity.FeeTypeResult;
import cn.zjhf.kingold.trade.entity.TradeRecharge;
import cn.zjhf.kingold.trade.service.ITradeExecService;
import cn.zjhf.kingold.trade.service.ITradeService;
import cn.zjhf.kingold.trade.service.ITradeTransactionService;
import cn.zjhf.kingold.trade.utils.DataUtils;
import com.alibaba.fastjson.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by zhangyijie on 2017/6/27.
 */
@Service
public class TradeExecServiceImpl  implements ITradeExecService {
    private static final Logger logger = LoggerFactory.getLogger(TradeExecServiceImpl.class);

    @Autowired
    private ITradeService tradeService;

    @Autowired
    private ITradeTransactionService tradeTransactionService;

    /**
     * 提现
     * @param userUuid
     * @param amt
     * @param transactionChannel
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = BusinessException.class)
    public void freezeWithdraw(String userUuid, double amt, String transactionChannel) throws BusinessException {
        logger.info("TradeExecServiceImpl.freezeWithdraw " + DataUtils.toString(userUuid, amt));
        //Step1 根据手续费修正提现金额
        FeeTypeResult feeType = tradeService.getFeeType(userUuid);
        if(feeType.getFeeType() == PayMsg.FEE_TOKEN_ON_PERSON) {
            amt = amt - feeType.getAmount();
            if(amt <= 0) {
                logger.error("提现失败，还款金额小于等于手续费");
                return;
            }
        }

        logger.info("TradeExecServiceImpl.freezeWithdraw " + DataUtils.toString(userUuid, amt));

        Map params = new HashMap();
        params.put("rechargeAmount", amt);
        params.put("userPayPassword", null);
        params.put("accountType", AccountType.ACCOUNT_TYPE_INVESTOR);
        params.put("userUuid", userUuid);
        params.put("transactionChannel", transactionChannel);

        String billCode = "";
        logger.info("创建提现订单;params:{}", JSONObject.toJSONString(params));
        TradeRecharge tradeRecharge = tradeService.createRechargeOrder(params);
        logger.info("宝付 提现;params:{}",JSONObject.toJSONString(tradeRecharge));
        ResponseResult rr = tradeService.baofooWithDraw(tradeRecharge);

        if(rr.getCode() != AccountStatusMsg.SUCCESS_CODE){
            logger.error("宝付 提现 失败;params:{}",JSONObject.toJSONString(rr));
            throw new BusinessException(TradeStatusMsg.PRODUCT_UPDATE_PRODUCT_RAISEPROGRESS_ERR, TradeStatusMsg.PRODUCT_UPDATE_PRODUCT_RAISEPROGRESS_ERR_MSG, false);
        }

        // tradeService.baofooWithDraw()中已完成全部操作，不用再做了
//        logger.info("宝付提现成功后，设置账户系统冻结账户金额;params:{}",JSONObject.toJSONString(tradeRecharge));
//        try {
//            tradeTransactionService.successWithDraw(tradeRecharge);
//        } catch(BusinessException e){
//            if (e.getErrorCode() == PayResponseCode.PENDING_OPERATION) {
//                logger.error("重复执行提现操作，且之前的操作还没有完成。");
//            } else {
//                logger.error("宝付提现成功后，设置账户系统冻结账户金额失败。", e);
//                throw new BusinessException(TradeStatusMsg.PRODUCT_UPDATE_PRODUCT_RAISEPROGRESS_ERR, TradeStatusMsg.PRODUCT_UPDATE_PRODUCT_RAISEPROGRESS_ERR_MSG, false);
//            }
//        }
    }
}
