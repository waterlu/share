package cn.zjhf.kingold.trade.dto;

import javax.validation.constraints.NotNull;
import java.util.Date;

/**
 * Created by lutiehua on 2017/6/2.
 */
public class RewardApplyDto {

    @NotNull
    private Date startDate;

    @NotNull
    private Date endDate;

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

}
