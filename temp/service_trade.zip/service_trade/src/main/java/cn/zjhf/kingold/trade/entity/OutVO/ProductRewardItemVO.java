package cn.zjhf.kingold.trade.entity.OutVO;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Size;

/**
 * Created by zhangyijie on 2017/6/5.
 */
@ApiModel(value = "ProductRewardItemVO", description = "报表 -> 产品奖励记录 -> 奖励详情 -> 用户奖励明细记录")
public class ProductRewardItemVO extends ParamVO {
    @ApiModelProperty(required = true, value = "用户名")
    private String userMobile;

    @ApiModelProperty(required = true, value = "用户姓名")
    private String userRealName;

    @ApiModelProperty(required = true, value = "税前佣金")
    private double rewardAmount;

    @ApiModelProperty(required = true, value = "佣金笔数")
    private double rewardCount;

    public String getUserMobile() {
        return userMobile;
    }

    public void setUserMobile(String userMobile) {
        this.userMobile = userMobile;
    }

    public String getUserRealName() {
        return userRealName;
    }

    public void setUserRealName(String userRealName) {
        this.userRealName = userRealName;
    }

    public double getRewardAmount() {
        return rewardAmount;
    }

    public void setRewardAmount(double rewardAmount) {
        this.rewardAmount = rewardAmount;
    }

    public double getRewardCount() {
        return rewardCount;
    }

    public void setRewardCount(double rewardCount) {
        this.rewardCount = rewardCount;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("userMobile:" + DataUtils.toString(userMobile) + ", ");
        sb.append("userRealName:" + DataUtils.toString(userRealName) + ", ");
        sb.append("rewardAmount:" + DataUtils.toString(rewardAmount) + ", ");
        sb.append("rewardCount:" + DataUtils.toString(rewardCount));
        return sb.toString();
    }
}
