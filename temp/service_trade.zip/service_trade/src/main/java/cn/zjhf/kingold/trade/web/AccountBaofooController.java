package cn.zjhf.kingold.trade.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.constant.AccountStatusMsg;
import cn.zjhf.kingold.trade.dto.AccountDTO;
import cn.zjhf.kingold.trade.dto.SendCashDTO;
import cn.zjhf.kingold.trade.entity.OutVO.CommItemListVO;
import cn.zjhf.kingold.trade.entity.TradeRecharge;
import cn.zjhf.kingold.trade.persistence.dao.AccountBaofooCustodyMapper;
import cn.zjhf.kingold.trade.service.IAccountBaofooService;
import cn.zjhf.kingold.trade.service.IAccountService;
import cn.zjhf.kingold.trade.service.ITradeService;
import cn.zjhf.kingold.trade.utils.DataUtils;
import cn.zjhf.kingold.trade.utils.MapParamUtils;
import cn.zjhf.kingold.trade.utils.PropertyDescriptionUtils;
import cn.zjhf.kingold.trade.utils.RequestMapperConvert;
import cn.zjhf.kingold.trade.vo.AccountVO;
import cn.zjhf.kingold.trade.vo.SendCashVO;
import com.alibaba.fastjson.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by lu on 2017/3/13.
 */
@RestController
@RequestMapping(value = "/accountbaofoo")
public class AccountBaofooController {

    protected static final Logger logger = LoggerFactory.getLogger(AccountBaofooController.class);

    @Autowired
    private IAccountService accountService;

    @Autowired
    private IAccountBaofooService accountBaofooService;

    @Autowired
    private AccountBaofooCustodyMapper accountBaofooMapper;

    @Autowired
    private ITradeService tradeService;

    /**
     * 自动授权开户
     * @param paramMap 参数必填：userId,userName,userPhone,bankUserCardNo,userIdCardNumber,openChanne
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/openAccountWithAuth", method = RequestMethod.POST)
    public ResponseResult openAccountWithAuth(@RequestBody Map paramMap) throws BusinessException {
        logger.info("openAccount start: " + DataUtils.toString(paramMap));
        RequestMapperConvert.initParam(paramMap);

        String uuid = accountBaofooService.openAccountWithAuth(paramMap);
        logger.info("openAccount end: " + DataUtils.toString(paramMap.get("traceID"), uuid));
        return new ResponseResult( MapParamUtils.getStringInMap( paramMap,"traceID"),ResponseCode.REQUEST_SUCCESS,"成功",uuid);
    }

    /**
     * 开户
     * @param paramMap 参数必填：userId,userName,userPhone,bankUserCardNo,userIdCardNumber,openChanne
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/openAccount", method = RequestMethod.POST)
    public ResponseResult openAccount(@RequestBody Map paramMap) throws BusinessException {
        logger.info("openAccount start: " + DataUtils.toString(paramMap));
        RequestMapperConvert.initParam(paramMap);

        String uuid = accountBaofooService.openAccount(paramMap);
        logger.info("openAccount end: " + DataUtils.toString(paramMap.get("traceID"), uuid));
        return new ResponseResult( MapParamUtils.getStringInMap( paramMap,"traceID"),ResponseCode.REQUEST_SUCCESS,"成功",uuid);
    }

    /**
     * 企业开户
     * @param paramMap 参数必填：userId,userName,userPhone,bankUserCardNo,userIdCardNumber,openChanne
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/enterpriseOpenAccount", method = RequestMethod.POST)
    public ResponseResult enterpriseOpenAccount(@RequestBody Map paramMap) throws BusinessException {
        RequestMapperConvert.initParam(paramMap);

        String uuid = accountBaofooService.enterpriseOpenAccount(paramMap);
        return new ResponseResult( MapParamUtils.getStringInMap( paramMap,"traceID"),ResponseCode.REQUEST_SUCCESS,"成功",uuid);
    }

    /**
     * 绑卡
     * @param paramMap 参数必填 userId,verifyCode,userUuid,bankUserPhone,bankUserCardNo,bankUserIDCardNo,userName
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/bindBankCard", method = RequestMethod.POST)
    public ResponseResult bindBankCard(@RequestBody Map paramMap) throws BusinessException {
        logger.info("bindBankCard start: " + DataUtils.toString(paramMap));
        RequestMapperConvert.initParam(paramMap);

        if (paramMap.get("userId") == null ||paramMap.get("accountUuid") == null ||paramMap.get("userUuid") == null   ) {
            paramMap.put("accountNo", paramMap.get("userId"));
            Map accountParamMap = new HashMap();
            accountParamMap.put("accountNo", paramMap.get("accountNo"));
            accountParamMap.put("accountUuid", paramMap.get("accountUuid"));
            accountParamMap.put("userUuid", paramMap.get("userUuid"));

            Map accountMap = accountBaofooMapper.getBaofooAndAccount(accountParamMap);
            paramMap.put("accountNo", accountMap.get("accountNo"));
            paramMap.put("accountUuid", accountMap.get("accountUuid"));
            paramMap.put("userUuid", accountMap.get("userUuid"));
        }
        accountBaofooService.bindBankCard(paramMap);

        logger.info("bindBankCard end: " + DataUtils.toString(paramMap.get("traceID")));
        return new ResponseResult( MapParamUtils.getStringInMap( paramMap,"traceID"),ResponseCode.REQUEST_SUCCESS,"成功",paramMap.get("uuid"));
    }

    /**
     * 解绑卡
     * @param paramMap 参数必填 userUuid
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/unBindBankCard/{userUuid}", method = RequestMethod.POST)
    public ResponseResult nuBindBankCard(@PathVariable("userUuid") String userUuid,@RequestBody Map paramMap) throws BusinessException {
        logger.info("nuBindBankCard start: " + DataUtils.toString(paramMap));
        RequestMapperConvert.initParam(paramMap);

        accountBaofooService.unBindBankCard(userUuid,paramMap);

        logger.info("bindBankCard end: " + DataUtils.toString(paramMap.get("traceID")));
        return new ResponseResult( MapParamUtils.getStringInMap( paramMap,"traceID"),ResponseCode.REQUEST_SUCCESS,"成功",paramMap.get("uuid"));
    }

    /**
     * 获取绑定卡
     * @param paramMap 参数选填 userUuid,accountUuid,accountNo,accountType,accountStatus
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/getBankCardInfo", method = RequestMethod.GET)
    public ResponseResult getBankCardList(@RequestParam Map paramMap) throws BusinessException {
        logger.info("getBankCardList start: " + DataUtils.toString(paramMap));
        RequestMapperConvert.initParam(paramMap);
        List bankList= accountBaofooService.getBankCardList(paramMap);
        if(bankList != null && bankList.size() > 0) {
            logger.info("getBankCardList end: " + DataUtils.toString(paramMap.get("traceID"), bankList.get(0)));
            return new ResponseResult((String) paramMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功", bankList.get(0));
        }else{
            logger.info("getBankCardList end: " + DataUtils.toString(paramMap.get("traceID")));
            return new ResponseResult((String) paramMap.get("traceID"), ResponseCode.REQUEST_SUCCESS, "成功");
        }
    }


    /**
     * 查找
     * @param uuid
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/{uuid}", method = RequestMethod.GET)
    public ResponseResult get(@PathVariable("uuid") String uuid,@RequestParam Map paramMap) throws BusinessException {
        logger.info("get start: " + DataUtils.toString(uuid, paramMap));
        RequestMapperConvert.initParam(paramMap);

        paramMap.put("accountUuid",uuid);
        Map ui = accountBaofooService.get(paramMap);
        logger.info("get end: " + DataUtils.toString(paramMap.get("traceID"), ui));
        return new ResponseResult( MapParamUtils.getStringInMap( paramMap,"traceID"),ResponseCode.REQUEST_SUCCESS,"成功",ui);
    }

    /**
     * 联合查找 account 和account_baofoo
     * @param paramMap 参数选填 userUuid,accountUuid,accountNo,accountType,accountStatus
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "", method = RequestMethod.GET)
    public ResponseResult getBaofooAndAccount(@RequestParam Map paramMap) throws BusinessException {
        logger.info("getBaofooAndAccount start: " + DataUtils.toString(paramMap));
        RequestMapperConvert.initParam(paramMap);

        Map ui = accountBaofooService.getBaofooAndAccount(paramMap);

        if(ui == null || ui.isEmpty()){
            throw new BusinessException(AccountStatusMsg.REQUEST_PARAM_ERROR_CODE, AccountStatusMsg.REQUEST_PARAM_ERROR,true);
        }

        Map resultMap = PropertyDescriptionUtils.convertProperty(ui, MapParamUtils.getStringInMap( paramMap,"properties"), MapParamUtils.getStringInMap( paramMap,"desc"),PropertyDescriptionUtils.ACCOUNT_AND_BAOFOO_DIC);
        logger.info("getBaofooAndAccount end: " + DataUtils.toString(paramMap.get("traceID"), resultMap));
        return new ResponseResult( MapParamUtils.getStringInMap( paramMap,"traceID"),ResponseCode.REQUEST_SUCCESS,"成功",resultMap);
    }


    /**
     * 根据uuid 更新
     *
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/{uuid}", method = RequestMethod.PUT)
    public ResponseResult update(@PathVariable("uuid") String uuid, @RequestBody Map userMap) throws BusinessException {
        logger.info("update start: " + DataUtils.toString(uuid, userMap));
        RequestMapperConvert.initParam(userMap);
        userMap.put("accountUuid",uuid);
        int accountBaofooNum = accountBaofooService.update(userMap);
        int accountNum = accountService.update(userMap);
        if(accountBaofooNum == 0 || accountNum == 0){
            throw new BusinessException(AccountStatusMsg.ACCOUNT_NOT_EXIST_CODE, AccountStatusMsg.ACCOUNT_NOT_EXIST,true);
        }else{
            logger.info("update end: " + DataUtils.toString(userMap.get("traceID")));
            return  new ResponseResult( MapParamUtils.getStringInMap( userMap,"traceID"),ResponseCode.REQUEST_SUCCESS,"成功");
        }
    }

    /**
     * 获取宝付列表
     *
     * @param paramMap 参数选填 ： userUuid(多个),accountUuid，accountType，accountStatus，accountNo，createTimeFrom，createTimeTo
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public ResponseResult getList(@RequestParam Map paramMap) throws BusinessException {
        logger.info("getList start: " + DataUtils.toString(paramMap));
        RequestMapperConvert.initParam(paramMap);
        RequestMapperConvert.initAccountParam(paramMap);
        List<Map> result = new ArrayList<>();
        List<Map> userList = accountBaofooService.getList(paramMap);
        for(Map map : userList) {
            result.add(PropertyDescriptionUtils.convertProperty(map, MapParamUtils.getStringInMap( paramMap,"properties"), MapParamUtils.getStringInMap( paramMap,"desc"),PropertyDescriptionUtils.ACCOUNT_DIC));
        }
        logger.info("getList end: " + DataUtils.toString(paramMap.get("traceID"), result));
        return new ResponseResult( MapParamUtils.getStringInMap( paramMap,"traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", result);
    }

    /**
     * 获取账户资产查询列表
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/accountList", method = RequestMethod.GET)
    public ResponseResult getAccountList(AccountDTO dto) throws BusinessException {
        logger.info("getAccountList start{} " , DataUtils.toString(dto));
        CommItemListVO<AccountVO> accountList = accountBaofooService.getAccountList(dto);
        logger.info("getAccountList end {}" , DataUtils.toString(accountList));
        return new ResponseResult(dto.getTraceID(), ResponseCode.REQUEST_SUCCESS, "正常调用", accountList);
    }

    /**
     * 获取提现数据
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/sendCashInfo", method = RequestMethod.GET)
    public ResponseResult getSendCashInfo(SendCashDTO dto) throws BusinessException {
        logger.info("sendCashInfo start{} " , DataUtils.toString(dto));
        SendCashVO vo = accountBaofooService.getSendCashInfo(dto);
        logger.info("sendCashInfo end {}" , DataUtils.toString(vo));
        return new ResponseResult(dto.getTraceID(), ResponseCode.REQUEST_SUCCESS, "正常调用", vo);
    }

    /**
     * 运营后台提现
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/sendCash", method = RequestMethod.POST)
    public ResponseResult sendcCash(@RequestBody SendCashDTO dto) throws BusinessException {
        logger.info("sendcCash start: " + DataUtils.toString(dto));
        Integer count=accountBaofooService.sendcCash(dto);
        logger.info("sendcCash end: " + DataUtils.toString(dto.getTraceID(), count));
        return new ResponseResult(dto.getTraceID(), ResponseCode.REQUEST_SUCCESS, "正常调用", count);
    }

    /**
     * 查找交易流水
     * @param paramMap 参数选填 ：  userUuid(多个),accountUuid，accountType，accountStatus，accountNo，createTimeFrom，createTimeTo
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/count", method = RequestMethod.GET)
    public ResponseResult getCount(@RequestParam Map paramMap) throws BusinessException {
        logger.info("getCount start: " + DataUtils.toString(paramMap));

        RequestMapperConvert.initParam(paramMap);
        RequestMapperConvert.initAccountParam(paramMap);
        Integer count  = accountBaofooService.getCount(paramMap);

        logger.info("getCount end: " + DataUtils.toString(paramMap.get("traceID"), count));
        return new ResponseResult( MapParamUtils.getStringInMap( paramMap,"traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", count);
    }
}
