package cn.zjhf.kingold.trade.persistence.dao;

import cn.zjhf.kingold.trade.entity.TradeInvestSummary;
import cn.zjhf.kingold.trade.entity.TradeInvestSummaryExample;
import java.util.List;
import java.util.Map;

import cn.zjhf.kingold.trade.utils.WhereCondition;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface TradeInvestSummaryMapper {

//    @Select("select * from trade where #{condition}")
//    List<TradeInvestSummary> selectAll(Map<String, Object> condition);

    long countByExample(TradeInvestSummaryExample example);

    int deleteByExample(TradeInvestSummaryExample example);

    int deleteByPrimaryKey(String productUuid);

    int insert(TradeInvestSummary record);

    int insertSelective(TradeInvestSummary record);

    List<TradeInvestSummary> selectByExample(TradeInvestSummaryExample example);

//    @Select("SELECT * FROM trade_invest_summary ${condition}")
//    List<TradeInvestSummary> lstByCondition(WhereCondition condition);

//    @Select("SELECT trade_invest_summary_uuid, product_uuid, product_code, product_type, product_abbr_name, raise_count, raise_amount, raise_investor_amount, raise_platform_amount, out_user_uuid, out_account_uuid, out_account_no, in_user_uuid, in_account_uuid, in_account_no, transaction_status, audit_operator, audit_time, audit_opinion, payed_operator, payed_time, signature, delete_flag, create_time, update_time FROM trade_invest_summary ${condition}")
    List<TradeInvestSummary> lstByCondition(WhereCondition condition);

    @Select("SELECT Count(*) FROM trade_invest_summary ${condition}")
    int lstCountByCondition(WhereCondition condition);

    @Select("SELECT * FROM trade_invest_summary WHERE product_uuid = #{productUuid} AND delete_flag=0 ORDER BY create_time DESC LIMIT 0,1")
    @ResultMap("BaseResultMap")
    TradeInvestSummary lstByProductUuid(@Param("productUuid") String productUuid);

    @Update("UPDATE trade_invest_summary SET batch_no = #{batchNo} WHERE batch_no = #{oldBatchNo}")
    void updateBatchNo(@Param("batchNo") String batchNo, @Param("oldBatchNo") String oldBatchNo);

    @Update("UPDATE trade_invest_summary SET transaction_status = #{lockStatus} WHERE transaction_status = #{auditPass} AND product_uuid = #{productUuid}")
    void lockTradePayment(@Param("productUuid") String productUuid, @Param("lockStatus") Byte lockStatus, @Param("auditPass") Byte auditPass);

    @Update("UPDATE trade_invest_summary SET transaction_status = #{auditPass} WHERE transaction_status = #{lockStatus} AND product_uuid = #{productUuid}")
    void unLockTradePayment(@Param("productUuid") String productUuid, @Param("lockStatus") Byte lockStatus, @Param("auditPass") Byte auditPass);

    TradeInvestSummary selectByPrimaryKey(Long tradeInvestSummaryUuid);

    int updateByExampleSelective(@Param("record") TradeInvestSummary record, @Param("example") TradeInvestSummaryExample example);

    int updateByExample(@Param("record") TradeInvestSummary record, @Param("example") TradeInvestSummaryExample example);

    int updateByPrimaryKeySelective(TradeInvestSummary record);

    int updateByPrimaryKey(TradeInvestSummary record);
}