package cn.zjhf.kingold.trade.entity.InVO;

/**
 * Created by liuyao on 2017/9/14.
 */
public class ProductVO {
    private Integer productPeriod;

    private double annualInterestRate;

    private String productUuid;

    public Integer getProductPeriod() {
        return productPeriod;
    }

    public void setProductPeriod(Integer productPeriod) {
        this.productPeriod = productPeriod;
    }

    public double getAnnualInterestRate() {
        return annualInterestRate;
    }

    public void setAnnualInterestRate(double annualInterestRate) {
        this.annualInterestRate = annualInterestRate;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }
}
