package cn.zjhf.kingold.trade.entity;

import cn.zjhf.kingold.trade.utils.BizParam;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author
 */
public class AccountTransaction implements Serializable {
    /**
     * UUID
     */
    private String accountTransactionUuid;

    /**
     * 交易流水单编号
     */
    private String transactionBillCode;

    /**
     * 用户UUID
     */
    private String userUuid;

    /**
     * 账户UUID
     */
    private String accountUuid;

    /**
     * 托管机构用户账号
     */
    private String accountNo;

    /**
     * 交易渠道
     */
    private String transactionChannel;

    /**
     * 交易时间
     */
    private Date transactionTime;

    /**
     * 对手方用户UUID
     */
    private String oppoUserUuid;

    /**
     * 对手方账户UUID
     */
    private String oppoAccountUuid;

    /**
     * 对手方托管机构用户账号
     */
    private String oppoAccountNo;

    /**
     * 金额
     */
    private BigDecimal transactionAmount;

    /**
     * 交易类型 1宝付充值；2宝付投标；3宝付满标；4宝付流标；5宝付还款；6宝付提现；11融资方佣金；12理财顾问佣金
     */
    private String tradeType;

    /**
     * 会计科目
     */
    private String subjectCode;

    /**
     * 资金凭证单号，如宝付的资金流水号
     */
    private String tradeOrderBillCode;

    /**
     * 产品相关涉及，交易单号
     */
    private String tradeOrderUuid;

    /**
     * 产品相关涉及，如是购买/撤销/赎回/到期产品，则填写购买的产品名称、数量、金额等
     */
    private String remark;

    /**
     * 对账标志
     */
    private Byte isTransactionCheck;

    public String getTradeOrderBillCodeExtend() {
        return tradeOrderBillCodeExtend;
    }

    public void setTradeOrderBillCodeExtend(String tradeOrderBillCodeExtend) {
        this.tradeOrderBillCodeExtend = tradeOrderBillCodeExtend;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    /**
     * 订单编号扩展（宝付交易流水编号）
     */
    private String tradeOrderBillCodeExtend;

    /**
     * 签名
     */
    private String signature;

    private Byte deleteFlag;

    private Date createTime;

    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public AccountTransaction() {
    }

    public AccountTransaction(BizParam bizData) {
        accountTransactionUuid = bizData.getString("accountTransactionUuid");
        transactionBillCode = bizData.getString("transactionBillCode");
        userUuid = bizData.getString("userUuid");
        accountUuid = bizData.getString("accountUuid");
        accountNo = bizData.getString("accountNo");
        transactionChannel = bizData.getString("transactionChannel");
        transactionTime = bizData.getDate("transactionTime");
        oppoUserUuid = bizData.getString("oppoUserUuid");
        oppoAccountUuid = bizData.getString("oppoAccountUuid");
        oppoAccountNo = bizData.getString("oppoAccountNo");
        transactionAmount = bizData.getBigDecimal("transactionAmount");
        tradeType = bizData.getString("tradeType");
        subjectCode = bizData.getString("subjectCode");
        tradeOrderBillCode = bizData.getString("tradeOrderBillCode");
        tradeOrderUuid = bizData.getString("tradeOrderUuid");
        remark = bizData.getString("remark");
        isTransactionCheck = bizData.getByte("isTransactionCheck");
        signature = bizData.getString("signature");
        deleteFlag = bizData.getByte("deleteFlag");
        createTime = bizData.getDate("createTime");
        updateTime = bizData.getDate("updateTime");

        tradeOrderBillCodeExtend = bizData.get("tradeOrderBillCodeExtend");
    }

    public String getAccountTransactionUuid() {
        return accountTransactionUuid;
    }

    public void setAccountTransactionUuid(String accountTransactionUuid) {
        this.accountTransactionUuid = accountTransactionUuid;
    }

    public String getTransactionBillCode() {
        return transactionBillCode;
    }

    public void setTransactionBillCode(String transactionBillCode) {
        this.transactionBillCode = transactionBillCode;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getAccountUuid() {
        return accountUuid;
    }

    public void setAccountUuid(String accountUuid) {
        this.accountUuid = accountUuid;
    }

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    public String getTransactionChannel() {
        return transactionChannel;
    }

    public void setTransactionChannel(String transactionChannel) {
        this.transactionChannel = transactionChannel;
    }

    public Date getTransactionTime() {
        return transactionTime;
    }

    public void setTransactionTime(Date transactionTime) {
        this.transactionTime = transactionTime;
    }

    public String getOppoUserUuid() {
        return oppoUserUuid;
    }

    public void setOppoUserUuid(String oppoUserUuid) {
        this.oppoUserUuid = oppoUserUuid;
    }

    public String getOppoAccountUuid() {
        return oppoAccountUuid;
    }

    public void setOppoAccountUuid(String oppoAccountUuid) {
        this.oppoAccountUuid = oppoAccountUuid;
    }

    public String getOppoAccountNo() {
        return oppoAccountNo;
    }

    public void setOppoAccountNo(String oppoAccountNo) {
        this.oppoAccountNo = oppoAccountNo;
    }

    public BigDecimal getTransactionAmount() {
        return transactionAmount;
    }

    public void setTransactionAmount(BigDecimal transactionAmount) {
        this.transactionAmount = transactionAmount;
    }

    public String getTradeType() {
        return tradeType;
    }

    public void setTradeType(String tradeType) {
        this.tradeType = tradeType;
    }

    public String getSubjectCode() {
        return subjectCode;
    }

    public void setSubjectCode(String subjectCode) {
        this.subjectCode = subjectCode;
    }

    public String getTradeOrderBillCode() {
        return tradeOrderBillCode;
    }

    public void setTradeOrderBillCode(String tradeOrderBillCode) {
        this.tradeOrderBillCode = tradeOrderBillCode;
    }

    public String getTradeOrderUuid() {
        return tradeOrderUuid;
    }

    public void setTradeOrderUuid(String tradeOrderUuid) {
        this.tradeOrderUuid = tradeOrderUuid;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Byte getIsTransactionCheck() {
        return isTransactionCheck;
    }

    public void setIsTransactionCheck(Byte isTransactionCheck) {
        this.isTransactionCheck = isTransactionCheck;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Map getMap() {
        Map map = new HashMap<String, Object>();
        map.put("tradeOrderBillCodeExtend", tradeOrderBillCodeExtend);
        map.put("accountTransactionUuid", accountTransactionUuid);
        map.put("transactionBillCode", transactionBillCode);
        map.put("userUuid", userUuid);
        map.put("accountUuid", accountUuid);
        map.put("accountNo", accountNo);
        map.put("transactionChannel", transactionChannel);
        map.put("transactionTime", transactionTime);
        map.put("oppoUserUuid", oppoUserUuid);
        map.put("oppoAccountUuid", oppoAccountUuid);
        map.put("oppoAccountNo", oppoAccountNo);
        map.put("transactionAmount", transactionAmount);
        map.put("tradeType", tradeType);
        map.put("subjectCode", subjectCode);
        map.put("tradeOrderBillCode", tradeOrderBillCode);
        map.put("tradeOrderUuid", tradeOrderUuid);
        map.put("remark", remark);
        map.put("isTransactionCheck", isTransactionCheck);
        map.put("signature", signature);
        map.put("deleteFlag", deleteFlag);
        map.put("createTime", createTime);
        map.put("updateTime", updateTime);
        return map;
    }
}