package cn.zjhf.kingold.trade.service;

import cn.zjhf.kingold.common.exception.BusinessException;

import java.util.Date;

/**
 * Created by DELL on 2017/5/18.
 */
public interface IBaseService {

    /**
     * 日期检查，将指定日期和当前系统日相对比
     * @return
     * @throws BusinessException
     */
    public boolean dateCheck(Date date);
}
