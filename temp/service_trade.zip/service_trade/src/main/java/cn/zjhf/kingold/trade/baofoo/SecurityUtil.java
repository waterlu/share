package cn.zjhf.kingold.trade.baofoo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.util.Map;

/**
 * Created by lutiehua on 2017/4/26.
 */
@Component
public class SecurityUtil {

    @Value("${baofoo.aes.key}")
    private String password;

    public String encryptMD5(String content) {
        return md5(content + "~|~" + password);
    }

    public String baofooPlatformQueryMd5(Map<String, String> postParams) {
        String mak = "&";//分隔符
        String keyString = password;
        String md5AddString = "member_id=" + postParams.get("member_id") + mak + "terminal_id=" +
                postParams.get("terminal_id") + mak + "return_type=" + postParams.get("return_type") +
                mak + "trans_code=" + postParams.get("trans_code") + mak + "version=" + postParams.get("version") +
                mak + "account_type=" + postParams.get("account_type") + mak + "key=" + keyString;
        return md5(md5AddString).toUpperCase();
    }

    /***
     * MD5 加密
     */
    private String md5(String content) {
        if (content == null) {
            return null;
        }

        try {
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            md5.update(content.getBytes("UTF-8"));
            byte[] digest = md5.digest();
            StringBuffer hexString = new StringBuffer();
            String strTemp;
            for (int i = 0; i < digest.length; i++) {
                strTemp = Integer.toHexString((digest[i] & 0x000000FF) | 0xFFFFFF00).substring(6);
                hexString.append(strTemp);
            }
            return hexString.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return content;
        }
    }

    /**
     * AES加密算法
     * @return
     */
    public String encryptAES(String content){
        if (StringUtils.isEmpty(password) || password.length() != 16) {
            throw new RuntimeException("密钥长度为16位");
        }
        try {
            String iv = password;
            Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
            int blockSize = cipher.getBlockSize();
            byte[] dataBytes = content.trim().getBytes("utf-8");
            int plaintextLength = dataBytes.length;
            if (plaintextLength % blockSize != 0) {
                plaintextLength = plaintextLength + (blockSize - (plaintextLength % blockSize));
            }
            byte[] plaintext = new byte[plaintextLength];
            System.arraycopy(dataBytes, 0, plaintext, 0, dataBytes.length);
            SecretKeySpec keyspec = new SecretKeySpec(password.getBytes(), "AES");
            IvParameterSpec ivspec = new IvParameterSpec(iv.getBytes());
            cipher.init(Cipher.ENCRYPT_MODE, keyspec, ivspec);
            byte[] encrypted = cipher.doFinal(plaintext);
            return byte2Hex(encrypted);

        } catch (Exception e) {
            throw new RuntimeException("aes加密发生错误", e);
        }
    }

    /**
     * Base64加密
     */
    private String base64Encode(String str) throws UnsupportedEncodingException {
        return new BASE64Encoder().encode(str.getBytes("UTF-8"));
    }

    /**
     * 解密
     */
    private String base64Decode(String str) throws UnsupportedEncodingException, IOException {
//		str = str.replaceAll(" ", "+");
        return new String(new BASE64Decoder().decodeBuffer(str), "UTF-8");
    }

    // ==Aes加解密==================================================================

    /**
     * AES解密-128位 key长度为16 AES/CBC/NoPadding
     * @param encryptContent  (16进制) 密文
     * @param password  密钥
     * @return 原文
     */
    public String aesDecrypt(String encryptContent, String password) {
        if (StringUtils.isEmpty(password) || password.length() != 16) {
            throw new RuntimeException("密钥长度为16位");
        }
        try {
            String key = password;
            String iv = password;
            byte[] encrypted1 = hex2Bytes(encryptContent);
            Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
            SecretKeySpec keyspec = new SecretKeySpec(key.getBytes(), "AES");
            IvParameterSpec ivspec = new IvParameterSpec(iv.getBytes());
            cipher.init(Cipher.DECRYPT_MODE, keyspec, ivspec);
            byte[] original = cipher.doFinal(encrypted1);
            return new String(original,"utf-8").trim();
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("aes解密发生错误", e);
        }
    }

    /**
     * 将byte[] 转换成字符串
     */
    public String byte2Hex(byte[] srcBytes) {
        StringBuilder hexRetSB = new StringBuilder();
        for (byte b : srcBytes) {
            String hexString = Integer.toHexString(0x00ff & b);
            hexRetSB.append(hexString.length() == 1 ? 0 : "").append(hexString);
        }
        return hexRetSB.toString();
    }

    /**
     * 将16进制字符串转为转换成字符串
     */
    public byte[] hex2Bytes(String source) {
        byte[] sourceBytes = new byte[source.length() / 2];
        for (int i = 0; i < sourceBytes.length; i++) {
            sourceBytes[i] = (byte) Integer.parseInt(source.substring(i * 2, i * 2 + 2), 16);
        }
        return sourceBytes;
    }

}
