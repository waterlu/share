package cn.zjhf.kingold.trade.entity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class ProductRewardSummaryExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private Integer limit;

    private Integer offset;

    public ProductRewardSummaryExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andProductRewardSummaryUuidIsNull() {
            addCriterion("product_reward_summary_uuid is null");
            return (Criteria) this;
        }

        public Criteria andProductRewardSummaryUuidIsNotNull() {
            addCriterion("product_reward_summary_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andProductRewardSummaryUuidEqualTo(Long value) {
            addCriterion("product_reward_summary_uuid =", value, "productRewardSummaryUuid");
            return (Criteria) this;
        }

        public Criteria andProductRewardSummaryUuidNotEqualTo(Long value) {
            addCriterion("product_reward_summary_uuid <>", value, "productRewardSummaryUuid");
            return (Criteria) this;
        }

        public Criteria andProductRewardSummaryUuidGreaterThan(Long value) {
            addCriterion("product_reward_summary_uuid >", value, "productRewardSummaryUuid");
            return (Criteria) this;
        }

        public Criteria andProductRewardSummaryUuidGreaterThanOrEqualTo(Long value) {
            addCriterion("product_reward_summary_uuid >=", value, "productRewardSummaryUuid");
            return (Criteria) this;
        }

        public Criteria andProductRewardSummaryUuidLessThan(Long value) {
            addCriterion("product_reward_summary_uuid <", value, "productRewardSummaryUuid");
            return (Criteria) this;
        }

        public Criteria andProductRewardSummaryUuidLessThanOrEqualTo(Long value) {
            addCriterion("product_reward_summary_uuid <=", value, "productRewardSummaryUuid");
            return (Criteria) this;
        }

        public Criteria andProductRewardSummaryUuidIn(List<Long> values) {
            addCriterion("product_reward_summary_uuid in", values, "productRewardSummaryUuid");
            return (Criteria) this;
        }

        public Criteria andProductRewardSummaryUuidNotIn(List<Long> values) {
            addCriterion("product_reward_summary_uuid not in", values, "productRewardSummaryUuid");
            return (Criteria) this;
        }

        public Criteria andProductRewardSummaryUuidBetween(Long value1, Long value2) {
            addCriterion("product_reward_summary_uuid between", value1, value2, "productRewardSummaryUuid");
            return (Criteria) this;
        }

        public Criteria andProductRewardSummaryUuidNotBetween(Long value1, Long value2) {
            addCriterion("product_reward_summary_uuid not between", value1, value2, "productRewardSummaryUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidIsNull() {
            addCriterion("product_uuid is null");
            return (Criteria) this;
        }

        public Criteria andProductUuidIsNotNull() {
            addCriterion("product_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andProductUuidEqualTo(String value) {
            addCriterion("product_uuid =", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotEqualTo(String value) {
            addCriterion("product_uuid <>", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidGreaterThan(String value) {
            addCriterion("product_uuid >", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidGreaterThanOrEqualTo(String value) {
            addCriterion("product_uuid >=", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidLessThan(String value) {
            addCriterion("product_uuid <", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidLessThanOrEqualTo(String value) {
            addCriterion("product_uuid <=", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidLike(String value) {
            addCriterion("product_uuid like", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotLike(String value) {
            addCriterion("product_uuid not like", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidIn(List<String> values) {
            addCriterion("product_uuid in", values, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotIn(List<String> values) {
            addCriterion("product_uuid not in", values, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidBetween(String value1, String value2) {
            addCriterion("product_uuid between", value1, value2, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotBetween(String value1, String value2) {
            addCriterion("product_uuid not between", value1, value2, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductCodeIsNull() {
            addCriterion("product_code is null");
            return (Criteria) this;
        }

        public Criteria andProductCodeIsNotNull() {
            addCriterion("product_code is not null");
            return (Criteria) this;
        }

        public Criteria andProductCodeEqualTo(String value) {
            addCriterion("product_code =", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotEqualTo(String value) {
            addCriterion("product_code <>", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeGreaterThan(String value) {
            addCriterion("product_code >", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeGreaterThanOrEqualTo(String value) {
            addCriterion("product_code >=", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLessThan(String value) {
            addCriterion("product_code <", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLessThanOrEqualTo(String value) {
            addCriterion("product_code <=", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLike(String value) {
            addCriterion("product_code like", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotLike(String value) {
            addCriterion("product_code not like", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeIn(List<String> values) {
            addCriterion("product_code in", values, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotIn(List<String> values) {
            addCriterion("product_code not in", values, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeBetween(String value1, String value2) {
            addCriterion("product_code between", value1, value2, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotBetween(String value1, String value2) {
            addCriterion("product_code not between", value1, value2, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameIsNull() {
            addCriterion("product_abbr_name is null");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameIsNotNull() {
            addCriterion("product_abbr_name is not null");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameEqualTo(String value) {
            addCriterion("product_abbr_name =", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameNotEqualTo(String value) {
            addCriterion("product_abbr_name <>", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameGreaterThan(String value) {
            addCriterion("product_abbr_name >", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameGreaterThanOrEqualTo(String value) {
            addCriterion("product_abbr_name >=", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameLessThan(String value) {
            addCriterion("product_abbr_name <", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameLessThanOrEqualTo(String value) {
            addCriterion("product_abbr_name <=", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameLike(String value) {
            addCriterion("product_abbr_name like", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameNotLike(String value) {
            addCriterion("product_abbr_name not like", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameIn(List<String> values) {
            addCriterion("product_abbr_name in", values, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameNotIn(List<String> values) {
            addCriterion("product_abbr_name not in", values, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameBetween(String value1, String value2) {
            addCriterion("product_abbr_name between", value1, value2, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameNotBetween(String value1, String value2) {
            addCriterion("product_abbr_name not between", value1, value2, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductTypeIsNull() {
            addCriterion("product_type is null");
            return (Criteria) this;
        }

        public Criteria andProductTypeIsNotNull() {
            addCriterion("product_type is not null");
            return (Criteria) this;
        }

        public Criteria andProductTypeEqualTo(String value) {
            addCriterion("product_type =", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeNotEqualTo(String value) {
            addCriterion("product_type <>", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeGreaterThan(String value) {
            addCriterion("product_type >", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeGreaterThanOrEqualTo(String value) {
            addCriterion("product_type >=", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeLessThan(String value) {
            addCriterion("product_type <", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeLessThanOrEqualTo(String value) {
            addCriterion("product_type <=", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeLike(String value) {
            addCriterion("product_type like", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeNotLike(String value) {
            addCriterion("product_type not like", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeIn(List<String> values) {
            addCriterion("product_type in", values, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeNotIn(List<String> values) {
            addCriterion("product_type not in", values, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeBetween(String value1, String value2) {
            addCriterion("product_type between", value1, value2, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeNotBetween(String value1, String value2) {
            addCriterion("product_type not between", value1, value2, "productType");
            return (Criteria) this;
        }

        public Criteria andProductEstablishmentDateIsNull() {
            addCriterion("product_establishment_date is null");
            return (Criteria) this;
        }

        public Criteria andProductEstablishmentDateIsNotNull() {
            addCriterion("product_establishment_date is not null");
            return (Criteria) this;
        }

        public Criteria andProductEstablishmentDateEqualTo(Date value) {
            addCriterionForJDBCDate("product_establishment_date =", value, "productEstablishmentDate");
            return (Criteria) this;
        }

        public Criteria andProductEstablishmentDateNotEqualTo(Date value) {
            addCriterionForJDBCDate("product_establishment_date <>", value, "productEstablishmentDate");
            return (Criteria) this;
        }

        public Criteria andProductEstablishmentDateGreaterThan(Date value) {
            addCriterionForJDBCDate("product_establishment_date >", value, "productEstablishmentDate");
            return (Criteria) this;
        }

        public Criteria andProductEstablishmentDateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("product_establishment_date >=", value, "productEstablishmentDate");
            return (Criteria) this;
        }

        public Criteria andProductEstablishmentDateLessThan(Date value) {
            addCriterionForJDBCDate("product_establishment_date <", value, "productEstablishmentDate");
            return (Criteria) this;
        }

        public Criteria andProductEstablishmentDateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("product_establishment_date <=", value, "productEstablishmentDate");
            return (Criteria) this;
        }

        public Criteria andProductEstablishmentDateIn(List<Date> values) {
            addCriterionForJDBCDate("product_establishment_date in", values, "productEstablishmentDate");
            return (Criteria) this;
        }

        public Criteria andProductEstablishmentDateNotIn(List<Date> values) {
            addCriterionForJDBCDate("product_establishment_date not in", values, "productEstablishmentDate");
            return (Criteria) this;
        }

        public Criteria andProductEstablishmentDateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("product_establishment_date between", value1, value2, "productEstablishmentDate");
            return (Criteria) this;
        }

        public Criteria andProductEstablishmentDateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("product_establishment_date not between", value1, value2, "productEstablishmentDate");
            return (Criteria) this;
        }

        public Criteria andRewardCountIsNull() {
            addCriterion("reward_count is null");
            return (Criteria) this;
        }

        public Criteria andRewardCountIsNotNull() {
            addCriterion("reward_count is not null");
            return (Criteria) this;
        }

        public Criteria andRewardCountEqualTo(Integer value) {
            addCriterion("reward_count =", value, "rewardCount");
            return (Criteria) this;
        }

        public Criteria andRewardCountNotEqualTo(Integer value) {
            addCriterion("reward_count <>", value, "rewardCount");
            return (Criteria) this;
        }

        public Criteria andRewardCountGreaterThan(Integer value) {
            addCriterion("reward_count >", value, "rewardCount");
            return (Criteria) this;
        }

        public Criteria andRewardCountGreaterThanOrEqualTo(Integer value) {
            addCriterion("reward_count >=", value, "rewardCount");
            return (Criteria) this;
        }

        public Criteria andRewardCountLessThan(Integer value) {
            addCriterion("reward_count <", value, "rewardCount");
            return (Criteria) this;
        }

        public Criteria andRewardCountLessThanOrEqualTo(Integer value) {
            addCriterion("reward_count <=", value, "rewardCount");
            return (Criteria) this;
        }

        public Criteria andRewardCountIn(List<Integer> values) {
            addCriterion("reward_count in", values, "rewardCount");
            return (Criteria) this;
        }

        public Criteria andRewardCountNotIn(List<Integer> values) {
            addCriterion("reward_count not in", values, "rewardCount");
            return (Criteria) this;
        }

        public Criteria andRewardCountBetween(Integer value1, Integer value2) {
            addCriterion("reward_count between", value1, value2, "rewardCount");
            return (Criteria) this;
        }

        public Criteria andRewardCountNotBetween(Integer value1, Integer value2) {
            addCriterion("reward_count not between", value1, value2, "rewardCount");
            return (Criteria) this;
        }

        public Criteria andRewardClearCountIsNull() {
            addCriterion("reward_clear_count is null");
            return (Criteria) this;
        }

        public Criteria andRewardClearCountIsNotNull() {
            addCriterion("reward_clear_count is not null");
            return (Criteria) this;
        }

        public Criteria andRewardClearCountEqualTo(Integer value) {
            addCriterion("reward_clear_count =", value, "rewardClearCount");
            return (Criteria) this;
        }

        public Criteria andRewardClearCountNotEqualTo(Integer value) {
            addCriterion("reward_clear_count <>", value, "rewardClearCount");
            return (Criteria) this;
        }

        public Criteria andRewardClearCountGreaterThan(Integer value) {
            addCriterion("reward_clear_count >", value, "rewardClearCount");
            return (Criteria) this;
        }

        public Criteria andRewardClearCountGreaterThanOrEqualTo(Integer value) {
            addCriterion("reward_clear_count >=", value, "rewardClearCount");
            return (Criteria) this;
        }

        public Criteria andRewardClearCountLessThan(Integer value) {
            addCriterion("reward_clear_count <", value, "rewardClearCount");
            return (Criteria) this;
        }

        public Criteria andRewardClearCountLessThanOrEqualTo(Integer value) {
            addCriterion("reward_clear_count <=", value, "rewardClearCount");
            return (Criteria) this;
        }

        public Criteria andRewardClearCountIn(List<Integer> values) {
            addCriterion("reward_clear_count in", values, "rewardClearCount");
            return (Criteria) this;
        }

        public Criteria andRewardClearCountNotIn(List<Integer> values) {
            addCriterion("reward_clear_count not in", values, "rewardClearCount");
            return (Criteria) this;
        }

        public Criteria andRewardClearCountBetween(Integer value1, Integer value2) {
            addCriterion("reward_clear_count between", value1, value2, "rewardClearCount");
            return (Criteria) this;
        }

        public Criteria andRewardClearCountNotBetween(Integer value1, Integer value2) {
            addCriterion("reward_clear_count not between", value1, value2, "rewardClearCount");
            return (Criteria) this;
        }

        public Criteria andFinancialAdvisorCountIsNull() {
            addCriterion("financial_advisor_count is null");
            return (Criteria) this;
        }

        public Criteria andFinancialAdvisorCountIsNotNull() {
            addCriterion("financial_advisor_count is not null");
            return (Criteria) this;
        }

        public Criteria andFinancialAdvisorCountEqualTo(Integer value) {
            addCriterion("financial_advisor_count =", value, "financialAdvisorCount");
            return (Criteria) this;
        }

        public Criteria andFinancialAdvisorCountNotEqualTo(Integer value) {
            addCriterion("financial_advisor_count <>", value, "financialAdvisorCount");
            return (Criteria) this;
        }

        public Criteria andFinancialAdvisorCountGreaterThan(Integer value) {
            addCriterion("financial_advisor_count >", value, "financialAdvisorCount");
            return (Criteria) this;
        }

        public Criteria andFinancialAdvisorCountGreaterThanOrEqualTo(Integer value) {
            addCriterion("financial_advisor_count >=", value, "financialAdvisorCount");
            return (Criteria) this;
        }

        public Criteria andFinancialAdvisorCountLessThan(Integer value) {
            addCriterion("financial_advisor_count <", value, "financialAdvisorCount");
            return (Criteria) this;
        }

        public Criteria andFinancialAdvisorCountLessThanOrEqualTo(Integer value) {
            addCriterion("financial_advisor_count <=", value, "financialAdvisorCount");
            return (Criteria) this;
        }

        public Criteria andFinancialAdvisorCountIn(List<Integer> values) {
            addCriterion("financial_advisor_count in", values, "financialAdvisorCount");
            return (Criteria) this;
        }

        public Criteria andFinancialAdvisorCountNotIn(List<Integer> values) {
            addCriterion("financial_advisor_count not in", values, "financialAdvisorCount");
            return (Criteria) this;
        }

        public Criteria andFinancialAdvisorCountBetween(Integer value1, Integer value2) {
            addCriterion("financial_advisor_count between", value1, value2, "financialAdvisorCount");
            return (Criteria) this;
        }

        public Criteria andFinancialAdvisorCountNotBetween(Integer value1, Integer value2) {
            addCriterion("financial_advisor_count not between", value1, value2, "financialAdvisorCount");
            return (Criteria) this;
        }

        public Criteria andPretaxRewardAmountIsNull() {
            addCriterion("pretax_reward_amount is null");
            return (Criteria) this;
        }

        public Criteria andPretaxRewardAmountIsNotNull() {
            addCriterion("pretax_reward_amount is not null");
            return (Criteria) this;
        }

        public Criteria andPretaxRewardAmountEqualTo(BigDecimal value) {
            addCriterion("pretax_reward_amount =", value, "pretaxRewardAmount");
            return (Criteria) this;
        }

        public Criteria andPretaxRewardAmountNotEqualTo(BigDecimal value) {
            addCriterion("pretax_reward_amount <>", value, "pretaxRewardAmount");
            return (Criteria) this;
        }

        public Criteria andPretaxRewardAmountGreaterThan(BigDecimal value) {
            addCriterion("pretax_reward_amount >", value, "pretaxRewardAmount");
            return (Criteria) this;
        }

        public Criteria andPretaxRewardAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("pretax_reward_amount >=", value, "pretaxRewardAmount");
            return (Criteria) this;
        }

        public Criteria andPretaxRewardAmountLessThan(BigDecimal value) {
            addCriterion("pretax_reward_amount <", value, "pretaxRewardAmount");
            return (Criteria) this;
        }

        public Criteria andPretaxRewardAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("pretax_reward_amount <=", value, "pretaxRewardAmount");
            return (Criteria) this;
        }

        public Criteria andPretaxRewardAmountIn(List<BigDecimal> values) {
            addCriterion("pretax_reward_amount in", values, "pretaxRewardAmount");
            return (Criteria) this;
        }

        public Criteria andPretaxRewardAmountNotIn(List<BigDecimal> values) {
            addCriterion("pretax_reward_amount not in", values, "pretaxRewardAmount");
            return (Criteria) this;
        }

        public Criteria andPretaxRewardAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("pretax_reward_amount between", value1, value2, "pretaxRewardAmount");
            return (Criteria) this;
        }

        public Criteria andPretaxRewardAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("pretax_reward_amount not between", value1, value2, "pretaxRewardAmount");
            return (Criteria) this;
        }

        public Criteria andPretaxPlatformServicefeeIsNull() {
            addCriterion("pretax_platform_servicefee is null");
            return (Criteria) this;
        }

        public Criteria andPretaxPlatformServicefeeIsNotNull() {
            addCriterion("pretax_platform_servicefee is not null");
            return (Criteria) this;
        }

        public Criteria andPretaxPlatformServicefeeEqualTo(BigDecimal value) {
            addCriterion("pretax_platform_servicefee =", value, "pretaxPlatformServicefee");
            return (Criteria) this;
        }

        public Criteria andPretaxPlatformServicefeeNotEqualTo(BigDecimal value) {
            addCriterion("pretax_platform_servicefee <>", value, "pretaxPlatformServicefee");
            return (Criteria) this;
        }

        public Criteria andPretaxPlatformServicefeeGreaterThan(BigDecimal value) {
            addCriterion("pretax_platform_servicefee >", value, "pretaxPlatformServicefee");
            return (Criteria) this;
        }

        public Criteria andPretaxPlatformServicefeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("pretax_platform_servicefee >=", value, "pretaxPlatformServicefee");
            return (Criteria) this;
        }

        public Criteria andPretaxPlatformServicefeeLessThan(BigDecimal value) {
            addCriterion("pretax_platform_servicefee <", value, "pretaxPlatformServicefee");
            return (Criteria) this;
        }

        public Criteria andPretaxPlatformServicefeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("pretax_platform_servicefee <=", value, "pretaxPlatformServicefee");
            return (Criteria) this;
        }

        public Criteria andPretaxPlatformServicefeeIn(List<BigDecimal> values) {
            addCriterion("pretax_platform_servicefee in", values, "pretaxPlatformServicefee");
            return (Criteria) this;
        }

        public Criteria andPretaxPlatformServicefeeNotIn(List<BigDecimal> values) {
            addCriterion("pretax_platform_servicefee not in", values, "pretaxPlatformServicefee");
            return (Criteria) this;
        }

        public Criteria andPretaxPlatformServicefeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("pretax_platform_servicefee between", value1, value2, "pretaxPlatformServicefee");
            return (Criteria) this;
        }

        public Criteria andPretaxPlatformServicefeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("pretax_platform_servicefee not between", value1, value2, "pretaxPlatformServicefee");
            return (Criteria) this;
        }

        public Criteria andPlatformServicefeeTaxIsNull() {
            addCriterion("platform_servicefee_tax is null");
            return (Criteria) this;
        }

        public Criteria andPlatformServicefeeTaxIsNotNull() {
            addCriterion("platform_servicefee_tax is not null");
            return (Criteria) this;
        }

        public Criteria andPlatformServicefeeTaxEqualTo(BigDecimal value) {
            addCriterion("platform_servicefee_tax =", value, "platformServicefeeTax");
            return (Criteria) this;
        }

        public Criteria andPlatformServicefeeTaxNotEqualTo(BigDecimal value) {
            addCriterion("platform_servicefee_tax <>", value, "platformServicefeeTax");
            return (Criteria) this;
        }

        public Criteria andPlatformServicefeeTaxGreaterThan(BigDecimal value) {
            addCriterion("platform_servicefee_tax >", value, "platformServicefeeTax");
            return (Criteria) this;
        }

        public Criteria andPlatformServicefeeTaxGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("platform_servicefee_tax >=", value, "platformServicefeeTax");
            return (Criteria) this;
        }

        public Criteria andPlatformServicefeeTaxLessThan(BigDecimal value) {
            addCriterion("platform_servicefee_tax <", value, "platformServicefeeTax");
            return (Criteria) this;
        }

        public Criteria andPlatformServicefeeTaxLessThanOrEqualTo(BigDecimal value) {
            addCriterion("platform_servicefee_tax <=", value, "platformServicefeeTax");
            return (Criteria) this;
        }

        public Criteria andPlatformServicefeeTaxIn(List<BigDecimal> values) {
            addCriterion("platform_servicefee_tax in", values, "platformServicefeeTax");
            return (Criteria) this;
        }

        public Criteria andPlatformServicefeeTaxNotIn(List<BigDecimal> values) {
            addCriterion("platform_servicefee_tax not in", values, "platformServicefeeTax");
            return (Criteria) this;
        }

        public Criteria andPlatformServicefeeTaxBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("platform_servicefee_tax between", value1, value2, "platformServicefeeTax");
            return (Criteria) this;
        }

        public Criteria andPlatformServicefeeTaxNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("platform_servicefee_tax not between", value1, value2, "platformServicefeeTax");
            return (Criteria) this;
        }

        public Criteria andAftertaxPlatformServicefeeIsNull() {
            addCriterion("aftertax_platform_servicefee is null");
            return (Criteria) this;
        }

        public Criteria andAftertaxPlatformServicefeeIsNotNull() {
            addCriterion("aftertax_platform_servicefee is not null");
            return (Criteria) this;
        }

        public Criteria andAftertaxPlatformServicefeeEqualTo(BigDecimal value) {
            addCriterion("aftertax_platform_servicefee =", value, "aftertaxPlatformServicefee");
            return (Criteria) this;
        }

        public Criteria andAftertaxPlatformServicefeeNotEqualTo(BigDecimal value) {
            addCriterion("aftertax_platform_servicefee <>", value, "aftertaxPlatformServicefee");
            return (Criteria) this;
        }

        public Criteria andAftertaxPlatformServicefeeGreaterThan(BigDecimal value) {
            addCriterion("aftertax_platform_servicefee >", value, "aftertaxPlatformServicefee");
            return (Criteria) this;
        }

        public Criteria andAftertaxPlatformServicefeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("aftertax_platform_servicefee >=", value, "aftertaxPlatformServicefee");
            return (Criteria) this;
        }

        public Criteria andAftertaxPlatformServicefeeLessThan(BigDecimal value) {
            addCriterion("aftertax_platform_servicefee <", value, "aftertaxPlatformServicefee");
            return (Criteria) this;
        }

        public Criteria andAftertaxPlatformServicefeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("aftertax_platform_servicefee <=", value, "aftertaxPlatformServicefee");
            return (Criteria) this;
        }

        public Criteria andAftertaxPlatformServicefeeIn(List<BigDecimal> values) {
            addCriterion("aftertax_platform_servicefee in", values, "aftertaxPlatformServicefee");
            return (Criteria) this;
        }

        public Criteria andAftertaxPlatformServicefeeNotIn(List<BigDecimal> values) {
            addCriterion("aftertax_platform_servicefee not in", values, "aftertaxPlatformServicefee");
            return (Criteria) this;
        }

        public Criteria andAftertaxPlatformServicefeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("aftertax_platform_servicefee between", value1, value2, "aftertaxPlatformServicefee");
            return (Criteria) this;
        }

        public Criteria andAftertaxPlatformServicefeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("aftertax_platform_servicefee not between", value1, value2, "aftertaxPlatformServicefee");
            return (Criteria) this;
        }

        public Criteria andExchangeManageFeeIsNull() {
            addCriterion("exchange_manage_fee is null");
            return (Criteria) this;
        }

        public Criteria andExchangeManageFeeIsNotNull() {
            addCriterion("exchange_manage_fee is not null");
            return (Criteria) this;
        }

        public Criteria andExchangeManageFeeEqualTo(BigDecimal value) {
            addCriterion("exchange_manage_fee =", value, "exchangeManageFee");
            return (Criteria) this;
        }

        public Criteria andExchangeManageFeeNotEqualTo(BigDecimal value) {
            addCriterion("exchange_manage_fee <>", value, "exchangeManageFee");
            return (Criteria) this;
        }

        public Criteria andExchangeManageFeeGreaterThan(BigDecimal value) {
            addCriterion("exchange_manage_fee >", value, "exchangeManageFee");
            return (Criteria) this;
        }

        public Criteria andExchangeManageFeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("exchange_manage_fee >=", value, "exchangeManageFee");
            return (Criteria) this;
        }

        public Criteria andExchangeManageFeeLessThan(BigDecimal value) {
            addCriterion("exchange_manage_fee <", value, "exchangeManageFee");
            return (Criteria) this;
        }

        public Criteria andExchangeManageFeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("exchange_manage_fee <=", value, "exchangeManageFee");
            return (Criteria) this;
        }

        public Criteria andExchangeManageFeeIn(List<BigDecimal> values) {
            addCriterion("exchange_manage_fee in", values, "exchangeManageFee");
            return (Criteria) this;
        }

        public Criteria andExchangeManageFeeNotIn(List<BigDecimal> values) {
            addCriterion("exchange_manage_fee not in", values, "exchangeManageFee");
            return (Criteria) this;
        }

        public Criteria andExchangeManageFeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("exchange_manage_fee between", value1, value2, "exchangeManageFee");
            return (Criteria) this;
        }

        public Criteria andExchangeManageFeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("exchange_manage_fee not between", value1, value2, "exchangeManageFee");
            return (Criteria) this;
        }

        public Criteria andPlatformIncomeIsNull() {
            addCriterion("platform_income is null");
            return (Criteria) this;
        }

        public Criteria andPlatformIncomeIsNotNull() {
            addCriterion("platform_income is not null");
            return (Criteria) this;
        }

        public Criteria andPlatformIncomeEqualTo(BigDecimal value) {
            addCriterion("platform_income =", value, "platformIncome");
            return (Criteria) this;
        }

        public Criteria andPlatformIncomeNotEqualTo(BigDecimal value) {
            addCriterion("platform_income <>", value, "platformIncome");
            return (Criteria) this;
        }

        public Criteria andPlatformIncomeGreaterThan(BigDecimal value) {
            addCriterion("platform_income >", value, "platformIncome");
            return (Criteria) this;
        }

        public Criteria andPlatformIncomeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("platform_income >=", value, "platformIncome");
            return (Criteria) this;
        }

        public Criteria andPlatformIncomeLessThan(BigDecimal value) {
            addCriterion("platform_income <", value, "platformIncome");
            return (Criteria) this;
        }

        public Criteria andPlatformIncomeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("platform_income <=", value, "platformIncome");
            return (Criteria) this;
        }

        public Criteria andPlatformIncomeIn(List<BigDecimal> values) {
            addCriterion("platform_income in", values, "platformIncome");
            return (Criteria) this;
        }

        public Criteria andPlatformIncomeNotIn(List<BigDecimal> values) {
            addCriterion("platform_income not in", values, "platformIncome");
            return (Criteria) this;
        }

        public Criteria andPlatformIncomeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("platform_income between", value1, value2, "platformIncome");
            return (Criteria) this;
        }

        public Criteria andPlatformIncomeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("platform_income not between", value1, value2, "platformIncome");
            return (Criteria) this;
        }

        public Criteria andLoanTimeIsNull() {
            addCriterion("loan_time is null");
            return (Criteria) this;
        }

        public Criteria andLoanTimeIsNotNull() {
            addCriterion("loan_time is not null");
            return (Criteria) this;
        }

        public Criteria andLoanTimeEqualTo(Date value) {
            addCriterion("loan_time =", value, "loanTime");
            return (Criteria) this;
        }

        public Criteria andLoanTimeNotEqualTo(Date value) {
            addCriterion("loan_time <>", value, "loanTime");
            return (Criteria) this;
        }

        public Criteria andLoanTimeGreaterThan(Date value) {
            addCriterion("loan_time >", value, "loanTime");
            return (Criteria) this;
        }

        public Criteria andLoanTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("loan_time >=", value, "loanTime");
            return (Criteria) this;
        }

        public Criteria andLoanTimeLessThan(Date value) {
            addCriterion("loan_time <", value, "loanTime");
            return (Criteria) this;
        }

        public Criteria andLoanTimeLessThanOrEqualTo(Date value) {
            addCriterion("loan_time <=", value, "loanTime");
            return (Criteria) this;
        }

        public Criteria andLoanTimeIn(List<Date> values) {
            addCriterion("loan_time in", values, "loanTime");
            return (Criteria) this;
        }

        public Criteria andLoanTimeNotIn(List<Date> values) {
            addCriterion("loan_time not in", values, "loanTime");
            return (Criteria) this;
        }

        public Criteria andLoanTimeBetween(Date value1, Date value2) {
            addCriterion("loan_time between", value1, value2, "loanTime");
            return (Criteria) this;
        }

        public Criteria andLoanTimeNotBetween(Date value1, Date value2) {
            addCriterion("loan_time not between", value1, value2, "loanTime");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditOperatorIsNull() {
            addCriterion("income_tax_audit_operator is null");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditOperatorIsNotNull() {
            addCriterion("income_tax_audit_operator is not null");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditOperatorEqualTo(String value) {
            addCriterion("income_tax_audit_operator =", value, "incomeTaxAuditOperator");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditOperatorNotEqualTo(String value) {
            addCriterion("income_tax_audit_operator <>", value, "incomeTaxAuditOperator");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditOperatorGreaterThan(String value) {
            addCriterion("income_tax_audit_operator >", value, "incomeTaxAuditOperator");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditOperatorGreaterThanOrEqualTo(String value) {
            addCriterion("income_tax_audit_operator >=", value, "incomeTaxAuditOperator");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditOperatorLessThan(String value) {
            addCriterion("income_tax_audit_operator <", value, "incomeTaxAuditOperator");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditOperatorLessThanOrEqualTo(String value) {
            addCriterion("income_tax_audit_operator <=", value, "incomeTaxAuditOperator");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditOperatorLike(String value) {
            addCriterion("income_tax_audit_operator like", value, "incomeTaxAuditOperator");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditOperatorNotLike(String value) {
            addCriterion("income_tax_audit_operator not like", value, "incomeTaxAuditOperator");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditOperatorIn(List<String> values) {
            addCriterion("income_tax_audit_operator in", values, "incomeTaxAuditOperator");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditOperatorNotIn(List<String> values) {
            addCriterion("income_tax_audit_operator not in", values, "incomeTaxAuditOperator");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditOperatorBetween(String value1, String value2) {
            addCriterion("income_tax_audit_operator between", value1, value2, "incomeTaxAuditOperator");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditOperatorNotBetween(String value1, String value2) {
            addCriterion("income_tax_audit_operator not between", value1, value2, "incomeTaxAuditOperator");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditTimeIsNull() {
            addCriterion("income_tax_audit_time is null");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditTimeIsNotNull() {
            addCriterion("income_tax_audit_time is not null");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditTimeEqualTo(Date value) {
            addCriterion("income_tax_audit_time =", value, "incomeTaxAuditTime");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditTimeNotEqualTo(Date value) {
            addCriterion("income_tax_audit_time <>", value, "incomeTaxAuditTime");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditTimeGreaterThan(Date value) {
            addCriterion("income_tax_audit_time >", value, "incomeTaxAuditTime");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("income_tax_audit_time >=", value, "incomeTaxAuditTime");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditTimeLessThan(Date value) {
            addCriterion("income_tax_audit_time <", value, "incomeTaxAuditTime");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditTimeLessThanOrEqualTo(Date value) {
            addCriterion("income_tax_audit_time <=", value, "incomeTaxAuditTime");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditTimeIn(List<Date> values) {
            addCriterion("income_tax_audit_time in", values, "incomeTaxAuditTime");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditTimeNotIn(List<Date> values) {
            addCriterion("income_tax_audit_time not in", values, "incomeTaxAuditTime");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditTimeBetween(Date value1, Date value2) {
            addCriterion("income_tax_audit_time between", value1, value2, "incomeTaxAuditTime");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditTimeNotBetween(Date value1, Date value2) {
            addCriterion("income_tax_audit_time not between", value1, value2, "incomeTaxAuditTime");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditOpinionIsNull() {
            addCriterion("income_tax_audit_opinion is null");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditOpinionIsNotNull() {
            addCriterion("income_tax_audit_opinion is not null");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditOpinionEqualTo(String value) {
            addCriterion("income_tax_audit_opinion =", value, "incomeTaxAuditOpinion");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditOpinionNotEqualTo(String value) {
            addCriterion("income_tax_audit_opinion <>", value, "incomeTaxAuditOpinion");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditOpinionGreaterThan(String value) {
            addCriterion("income_tax_audit_opinion >", value, "incomeTaxAuditOpinion");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditOpinionGreaterThanOrEqualTo(String value) {
            addCriterion("income_tax_audit_opinion >=", value, "incomeTaxAuditOpinion");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditOpinionLessThan(String value) {
            addCriterion("income_tax_audit_opinion <", value, "incomeTaxAuditOpinion");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditOpinionLessThanOrEqualTo(String value) {
            addCriterion("income_tax_audit_opinion <=", value, "incomeTaxAuditOpinion");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditOpinionLike(String value) {
            addCriterion("income_tax_audit_opinion like", value, "incomeTaxAuditOpinion");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditOpinionNotLike(String value) {
            addCriterion("income_tax_audit_opinion not like", value, "incomeTaxAuditOpinion");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditOpinionIn(List<String> values) {
            addCriterion("income_tax_audit_opinion in", values, "incomeTaxAuditOpinion");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditOpinionNotIn(List<String> values) {
            addCriterion("income_tax_audit_opinion not in", values, "incomeTaxAuditOpinion");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditOpinionBetween(String value1, String value2) {
            addCriterion("income_tax_audit_opinion between", value1, value2, "incomeTaxAuditOpinion");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxAuditOpinionNotBetween(String value1, String value2) {
            addCriterion("income_tax_audit_opinion not between", value1, value2, "incomeTaxAuditOpinion");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearOperatorIsNull() {
            addCriterion("income_tax_clear_operator is null");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearOperatorIsNotNull() {
            addCriterion("income_tax_clear_operator is not null");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearOperatorEqualTo(String value) {
            addCriterion("income_tax_clear_operator =", value, "incomeTaxClearOperator");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearOperatorNotEqualTo(String value) {
            addCriterion("income_tax_clear_operator <>", value, "incomeTaxClearOperator");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearOperatorGreaterThan(String value) {
            addCriterion("income_tax_clear_operator >", value, "incomeTaxClearOperator");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearOperatorGreaterThanOrEqualTo(String value) {
            addCriterion("income_tax_clear_operator >=", value, "incomeTaxClearOperator");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearOperatorLessThan(String value) {
            addCriterion("income_tax_clear_operator <", value, "incomeTaxClearOperator");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearOperatorLessThanOrEqualTo(String value) {
            addCriterion("income_tax_clear_operator <=", value, "incomeTaxClearOperator");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearOperatorLike(String value) {
            addCriterion("income_tax_clear_operator like", value, "incomeTaxClearOperator");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearOperatorNotLike(String value) {
            addCriterion("income_tax_clear_operator not like", value, "incomeTaxClearOperator");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearOperatorIn(List<String> values) {
            addCriterion("income_tax_clear_operator in", values, "incomeTaxClearOperator");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearOperatorNotIn(List<String> values) {
            addCriterion("income_tax_clear_operator not in", values, "incomeTaxClearOperator");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearOperatorBetween(String value1, String value2) {
            addCriterion("income_tax_clear_operator between", value1, value2, "incomeTaxClearOperator");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearOperatorNotBetween(String value1, String value2) {
            addCriterion("income_tax_clear_operator not between", value1, value2, "incomeTaxClearOperator");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearTimeIsNull() {
            addCriterion("income_tax_clear_time is null");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearTimeIsNotNull() {
            addCriterion("income_tax_clear_time is not null");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearTimeEqualTo(Date value) {
            addCriterion("income_tax_clear_time =", value, "incomeTaxClearTime");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearTimeNotEqualTo(Date value) {
            addCriterion("income_tax_clear_time <>", value, "incomeTaxClearTime");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearTimeGreaterThan(Date value) {
            addCriterion("income_tax_clear_time >", value, "incomeTaxClearTime");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("income_tax_clear_time >=", value, "incomeTaxClearTime");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearTimeLessThan(Date value) {
            addCriterion("income_tax_clear_time <", value, "incomeTaxClearTime");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearTimeLessThanOrEqualTo(Date value) {
            addCriterion("income_tax_clear_time <=", value, "incomeTaxClearTime");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearTimeIn(List<Date> values) {
            addCriterion("income_tax_clear_time in", values, "incomeTaxClearTime");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearTimeNotIn(List<Date> values) {
            addCriterion("income_tax_clear_time not in", values, "incomeTaxClearTime");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearTimeBetween(Date value1, Date value2) {
            addCriterion("income_tax_clear_time between", value1, value2, "incomeTaxClearTime");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearTimeNotBetween(Date value1, Date value2) {
            addCriterion("income_tax_clear_time not between", value1, value2, "incomeTaxClearTime");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearStatusIsNull() {
            addCriterion("income_tax_clear_status is null");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearStatusIsNotNull() {
            addCriterion("income_tax_clear_status is not null");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearStatusEqualTo(Byte value) {
            addCriterion("income_tax_clear_status =", value, "incomeTaxClearStatus");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearStatusNotEqualTo(Byte value) {
            addCriterion("income_tax_clear_status <>", value, "incomeTaxClearStatus");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearStatusGreaterThan(Byte value) {
            addCriterion("income_tax_clear_status >", value, "incomeTaxClearStatus");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearStatusGreaterThanOrEqualTo(Byte value) {
            addCriterion("income_tax_clear_status >=", value, "incomeTaxClearStatus");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearStatusLessThan(Byte value) {
            addCriterion("income_tax_clear_status <", value, "incomeTaxClearStatus");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearStatusLessThanOrEqualTo(Byte value) {
            addCriterion("income_tax_clear_status <=", value, "incomeTaxClearStatus");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearStatusIn(List<Byte> values) {
            addCriterion("income_tax_clear_status in", values, "incomeTaxClearStatus");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearStatusNotIn(List<Byte> values) {
            addCriterion("income_tax_clear_status not in", values, "incomeTaxClearStatus");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearStatusBetween(Byte value1, Byte value2) {
            addCriterion("income_tax_clear_status between", value1, value2, "incomeTaxClearStatus");
            return (Criteria) this;
        }

        public Criteria andIncomeTaxClearStatusNotBetween(Byte value1, Byte value2) {
            addCriterion("income_tax_clear_status not between", value1, value2, "incomeTaxClearStatus");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditOperatorIsNull() {
            addCriterion("exchange_managefee_audit_operator is null");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditOperatorIsNotNull() {
            addCriterion("exchange_managefee_audit_operator is not null");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditOperatorEqualTo(String value) {
            addCriterion("exchange_managefee_audit_operator =", value, "exchangeManagefeeAuditOperator");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditOperatorNotEqualTo(String value) {
            addCriterion("exchange_managefee_audit_operator <>", value, "exchangeManagefeeAuditOperator");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditOperatorGreaterThan(String value) {
            addCriterion("exchange_managefee_audit_operator >", value, "exchangeManagefeeAuditOperator");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditOperatorGreaterThanOrEqualTo(String value) {
            addCriterion("exchange_managefee_audit_operator >=", value, "exchangeManagefeeAuditOperator");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditOperatorLessThan(String value) {
            addCriterion("exchange_managefee_audit_operator <", value, "exchangeManagefeeAuditOperator");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditOperatorLessThanOrEqualTo(String value) {
            addCriterion("exchange_managefee_audit_operator <=", value, "exchangeManagefeeAuditOperator");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditOperatorLike(String value) {
            addCriterion("exchange_managefee_audit_operator like", value, "exchangeManagefeeAuditOperator");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditOperatorNotLike(String value) {
            addCriterion("exchange_managefee_audit_operator not like", value, "exchangeManagefeeAuditOperator");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditOperatorIn(List<String> values) {
            addCriterion("exchange_managefee_audit_operator in", values, "exchangeManagefeeAuditOperator");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditOperatorNotIn(List<String> values) {
            addCriterion("exchange_managefee_audit_operator not in", values, "exchangeManagefeeAuditOperator");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditOperatorBetween(String value1, String value2) {
            addCriterion("exchange_managefee_audit_operator between", value1, value2, "exchangeManagefeeAuditOperator");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditOperatorNotBetween(String value1, String value2) {
            addCriterion("exchange_managefee_audit_operator not between", value1, value2, "exchangeManagefeeAuditOperator");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditTimeIsNull() {
            addCriterion("exchange_managefee_audit_time is null");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditTimeIsNotNull() {
            addCriterion("exchange_managefee_audit_time is not null");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditTimeEqualTo(Date value) {
            addCriterion("exchange_managefee_audit_time =", value, "exchangeManagefeeAuditTime");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditTimeNotEqualTo(Date value) {
            addCriterion("exchange_managefee_audit_time <>", value, "exchangeManagefeeAuditTime");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditTimeGreaterThan(Date value) {
            addCriterion("exchange_managefee_audit_time >", value, "exchangeManagefeeAuditTime");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("exchange_managefee_audit_time >=", value, "exchangeManagefeeAuditTime");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditTimeLessThan(Date value) {
            addCriterion("exchange_managefee_audit_time <", value, "exchangeManagefeeAuditTime");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditTimeLessThanOrEqualTo(Date value) {
            addCriterion("exchange_managefee_audit_time <=", value, "exchangeManagefeeAuditTime");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditTimeIn(List<Date> values) {
            addCriterion("exchange_managefee_audit_time in", values, "exchangeManagefeeAuditTime");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditTimeNotIn(List<Date> values) {
            addCriterion("exchange_managefee_audit_time not in", values, "exchangeManagefeeAuditTime");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditTimeBetween(Date value1, Date value2) {
            addCriterion("exchange_managefee_audit_time between", value1, value2, "exchangeManagefeeAuditTime");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditTimeNotBetween(Date value1, Date value2) {
            addCriterion("exchange_managefee_audit_time not between", value1, value2, "exchangeManagefeeAuditTime");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditOpinionIsNull() {
            addCriterion("exchange_managefee_audit_opinion is null");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditOpinionIsNotNull() {
            addCriterion("exchange_managefee_audit_opinion is not null");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditOpinionEqualTo(String value) {
            addCriterion("exchange_managefee_audit_opinion =", value, "exchangeManagefeeAuditOpinion");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditOpinionNotEqualTo(String value) {
            addCriterion("exchange_managefee_audit_opinion <>", value, "exchangeManagefeeAuditOpinion");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditOpinionGreaterThan(String value) {
            addCriterion("exchange_managefee_audit_opinion >", value, "exchangeManagefeeAuditOpinion");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditOpinionGreaterThanOrEqualTo(String value) {
            addCriterion("exchange_managefee_audit_opinion >=", value, "exchangeManagefeeAuditOpinion");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditOpinionLessThan(String value) {
            addCriterion("exchange_managefee_audit_opinion <", value, "exchangeManagefeeAuditOpinion");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditOpinionLessThanOrEqualTo(String value) {
            addCriterion("exchange_managefee_audit_opinion <=", value, "exchangeManagefeeAuditOpinion");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditOpinionLike(String value) {
            addCriterion("exchange_managefee_audit_opinion like", value, "exchangeManagefeeAuditOpinion");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditOpinionNotLike(String value) {
            addCriterion("exchange_managefee_audit_opinion not like", value, "exchangeManagefeeAuditOpinion");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditOpinionIn(List<String> values) {
            addCriterion("exchange_managefee_audit_opinion in", values, "exchangeManagefeeAuditOpinion");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditOpinionNotIn(List<String> values) {
            addCriterion("exchange_managefee_audit_opinion not in", values, "exchangeManagefeeAuditOpinion");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditOpinionBetween(String value1, String value2) {
            addCriterion("exchange_managefee_audit_opinion between", value1, value2, "exchangeManagefeeAuditOpinion");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeAuditOpinionNotBetween(String value1, String value2) {
            addCriterion("exchange_managefee_audit_opinion not between", value1, value2, "exchangeManagefeeAuditOpinion");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearOperatorIsNull() {
            addCriterion("exchange_managefee_clear_operator is null");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearOperatorIsNotNull() {
            addCriterion("exchange_managefee_clear_operator is not null");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearOperatorEqualTo(String value) {
            addCriterion("exchange_managefee_clear_operator =", value, "exchangeManagefeeClearOperator");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearOperatorNotEqualTo(String value) {
            addCriterion("exchange_managefee_clear_operator <>", value, "exchangeManagefeeClearOperator");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearOperatorGreaterThan(String value) {
            addCriterion("exchange_managefee_clear_operator >", value, "exchangeManagefeeClearOperator");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearOperatorGreaterThanOrEqualTo(String value) {
            addCriterion("exchange_managefee_clear_operator >=", value, "exchangeManagefeeClearOperator");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearOperatorLessThan(String value) {
            addCriterion("exchange_managefee_clear_operator <", value, "exchangeManagefeeClearOperator");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearOperatorLessThanOrEqualTo(String value) {
            addCriterion("exchange_managefee_clear_operator <=", value, "exchangeManagefeeClearOperator");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearOperatorLike(String value) {
            addCriterion("exchange_managefee_clear_operator like", value, "exchangeManagefeeClearOperator");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearOperatorNotLike(String value) {
            addCriterion("exchange_managefee_clear_operator not like", value, "exchangeManagefeeClearOperator");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearOperatorIn(List<String> values) {
            addCriterion("exchange_managefee_clear_operator in", values, "exchangeManagefeeClearOperator");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearOperatorNotIn(List<String> values) {
            addCriterion("exchange_managefee_clear_operator not in", values, "exchangeManagefeeClearOperator");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearOperatorBetween(String value1, String value2) {
            addCriterion("exchange_managefee_clear_operator between", value1, value2, "exchangeManagefeeClearOperator");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearOperatorNotBetween(String value1, String value2) {
            addCriterion("exchange_managefee_clear_operator not between", value1, value2, "exchangeManagefeeClearOperator");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearTimeIsNull() {
            addCriterion("exchange_managefee_clear_time is null");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearTimeIsNotNull() {
            addCriterion("exchange_managefee_clear_time is not null");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearTimeEqualTo(Date value) {
            addCriterion("exchange_managefee_clear_time =", value, "exchangeManagefeeClearTime");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearTimeNotEqualTo(Date value) {
            addCriterion("exchange_managefee_clear_time <>", value, "exchangeManagefeeClearTime");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearTimeGreaterThan(Date value) {
            addCriterion("exchange_managefee_clear_time >", value, "exchangeManagefeeClearTime");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("exchange_managefee_clear_time >=", value, "exchangeManagefeeClearTime");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearTimeLessThan(Date value) {
            addCriterion("exchange_managefee_clear_time <", value, "exchangeManagefeeClearTime");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearTimeLessThanOrEqualTo(Date value) {
            addCriterion("exchange_managefee_clear_time <=", value, "exchangeManagefeeClearTime");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearTimeIn(List<Date> values) {
            addCriterion("exchange_managefee_clear_time in", values, "exchangeManagefeeClearTime");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearTimeNotIn(List<Date> values) {
            addCriterion("exchange_managefee_clear_time not in", values, "exchangeManagefeeClearTime");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearTimeBetween(Date value1, Date value2) {
            addCriterion("exchange_managefee_clear_time between", value1, value2, "exchangeManagefeeClearTime");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearTimeNotBetween(Date value1, Date value2) {
            addCriterion("exchange_managefee_clear_time not between", value1, value2, "exchangeManagefeeClearTime");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearStatusIsNull() {
            addCriterion("exchange_managefee_clear_status is null");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearStatusIsNotNull() {
            addCriterion("exchange_managefee_clear_status is not null");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearStatusEqualTo(Byte value) {
            addCriterion("exchange_managefee_clear_status =", value, "exchangeManagefeeClearStatus");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearStatusNotEqualTo(Byte value) {
            addCriterion("exchange_managefee_clear_status <>", value, "exchangeManagefeeClearStatus");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearStatusGreaterThan(Byte value) {
            addCriterion("exchange_managefee_clear_status >", value, "exchangeManagefeeClearStatus");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearStatusGreaterThanOrEqualTo(Byte value) {
            addCriterion("exchange_managefee_clear_status >=", value, "exchangeManagefeeClearStatus");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearStatusLessThan(Byte value) {
            addCriterion("exchange_managefee_clear_status <", value, "exchangeManagefeeClearStatus");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearStatusLessThanOrEqualTo(Byte value) {
            addCriterion("exchange_managefee_clear_status <=", value, "exchangeManagefeeClearStatus");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearStatusIn(List<Byte> values) {
            addCriterion("exchange_managefee_clear_status in", values, "exchangeManagefeeClearStatus");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearStatusNotIn(List<Byte> values) {
            addCriterion("exchange_managefee_clear_status not in", values, "exchangeManagefeeClearStatus");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearStatusBetween(Byte value1, Byte value2) {
            addCriterion("exchange_managefee_clear_status between", value1, value2, "exchangeManagefeeClearStatus");
            return (Criteria) this;
        }

        public Criteria andExchangeManagefeeClearStatusNotBetween(Byte value1, Byte value2) {
            addCriterion("exchange_managefee_clear_status not between", value1, value2, "exchangeManagefeeClearStatus");
            return (Criteria) this;
        }

        public Criteria andSignatureIsNull() {
            addCriterion("signature is null");
            return (Criteria) this;
        }

        public Criteria andSignatureIsNotNull() {
            addCriterion("signature is not null");
            return (Criteria) this;
        }

        public Criteria andSignatureEqualTo(String value) {
            addCriterion("signature =", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureNotEqualTo(String value) {
            addCriterion("signature <>", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureGreaterThan(String value) {
            addCriterion("signature >", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureGreaterThanOrEqualTo(String value) {
            addCriterion("signature >=", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureLessThan(String value) {
            addCriterion("signature <", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureLessThanOrEqualTo(String value) {
            addCriterion("signature <=", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureLike(String value) {
            addCriterion("signature like", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureNotLike(String value) {
            addCriterion("signature not like", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureIn(List<String> values) {
            addCriterion("signature in", values, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureNotIn(List<String> values) {
            addCriterion("signature not in", values, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureBetween(String value1, String value2) {
            addCriterion("signature between", value1, value2, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureNotBetween(String value1, String value2) {
            addCriterion("signature not between", value1, value2, "signature");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNull() {
            addCriterion("delete_flag is null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNotNull() {
            addCriterion("delete_flag is not null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagEqualTo(Byte value) {
            addCriterion("delete_flag =", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotEqualTo(Byte value) {
            addCriterion("delete_flag <>", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThan(Byte value) {
            addCriterion("delete_flag >", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThanOrEqualTo(Byte value) {
            addCriterion("delete_flag >=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThan(Byte value) {
            addCriterion("delete_flag <", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThanOrEqualTo(Byte value) {
            addCriterion("delete_flag <=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIn(List<Byte> values) {
            addCriterion("delete_flag in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotIn(List<Byte> values) {
            addCriterion("delete_flag not in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagBetween(Byte value1, Byte value2) {
            addCriterion("delete_flag between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotBetween(Byte value1, Byte value2) {
            addCriterion("delete_flag not between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andProductPeriodIsNull() {
            addCriterion("product_period is null");
            return (Criteria) this;
        }

        public Criteria andProductPeriodIsNotNull() {
            addCriterion("product_period is not null");
            return (Criteria) this;
        }

        public Criteria andProductPeriodEqualTo(Integer value) {
            addCriterion("product_period =", value, "productPeriod");
            return (Criteria) this;
        }

        public Criteria andProductPeriodNotEqualTo(Integer value) {
            addCriterion("product_period <>", value, "productPeriod");
            return (Criteria) this;
        }

        public Criteria andProductPeriodGreaterThan(Integer value) {
            addCriterion("product_period >", value, "productPeriod");
            return (Criteria) this;
        }

        public Criteria andProductPeriodGreaterThanOrEqualTo(Integer value) {
            addCriterion("product_period >=", value, "productPeriod");
            return (Criteria) this;
        }

        public Criteria andProductPeriodLessThan(Integer value) {
            addCriterion("product_period <", value, "productPeriod");
            return (Criteria) this;
        }

        public Criteria andProductPeriodLessThanOrEqualTo(Integer value) {
            addCriterion("product_period <=", value, "productPeriod");
            return (Criteria) this;
        }

        public Criteria andProductPeriodIn(List<Integer> values) {
            addCriterion("product_period in", values, "productPeriod");
            return (Criteria) this;
        }

        public Criteria andProductPeriodNotIn(List<Integer> values) {
            addCriterion("product_period not in", values, "productPeriod");
            return (Criteria) this;
        }

        public Criteria andProductPeriodBetween(Integer value1, Integer value2) {
            addCriterion("product_period between", value1, value2, "productPeriod");
            return (Criteria) this;
        }

        public Criteria andProductPeriodNotBetween(Integer value1, Integer value2) {
            addCriterion("product_period not between", value1, value2, "productPeriod");
            return (Criteria) this;
        }

        public Criteria andProductScaleIsNull() {
            addCriterion("product_scale is null");
            return (Criteria) this;
        }

        public Criteria andProductScaleIsNotNull() {
            addCriterion("product_scale is not null");
            return (Criteria) this;
        }

        public Criteria andProductScaleEqualTo(BigDecimal value) {
            addCriterion("product_scale =", value, "productScale");
            return (Criteria) this;
        }

        public Criteria andProductScaleNotEqualTo(BigDecimal value) {
            addCriterion("product_scale <>", value, "productScale");
            return (Criteria) this;
        }

        public Criteria andProductScaleGreaterThan(BigDecimal value) {
            addCriterion("product_scale >", value, "productScale");
            return (Criteria) this;
        }

        public Criteria andProductScaleGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("product_scale >=", value, "productScale");
            return (Criteria) this;
        }

        public Criteria andProductScaleLessThan(BigDecimal value) {
            addCriterion("product_scale <", value, "productScale");
            return (Criteria) this;
        }

        public Criteria andProductScaleLessThanOrEqualTo(BigDecimal value) {
            addCriterion("product_scale <=", value, "productScale");
            return (Criteria) this;
        }

        public Criteria andProductScaleIn(List<BigDecimal> values) {
            addCriterion("product_scale in", values, "productScale");
            return (Criteria) this;
        }

        public Criteria andProductScaleNotIn(List<BigDecimal> values) {
            addCriterion("product_scale not in", values, "productScale");
            return (Criteria) this;
        }

        public Criteria andProductScaleBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("product_scale between", value1, value2, "productScale");
            return (Criteria) this;
        }

        public Criteria andProductScaleNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("product_scale not between", value1, value2, "productScale");
            return (Criteria) this;
        }

        public Criteria andManagementFeeIsNull() {
            addCriterion("management_fee is null");
            return (Criteria) this;
        }

        public Criteria andManagementFeeIsNotNull() {
            addCriterion("management_fee is not null");
            return (Criteria) this;
        }

        public Criteria andManagementFeeEqualTo(BigDecimal value) {
            addCriterion("management_fee =", value, "managementFee");
            return (Criteria) this;
        }

        public Criteria andManagementFeeNotEqualTo(BigDecimal value) {
            addCriterion("management_fee <>", value, "managementFee");
            return (Criteria) this;
        }

        public Criteria andManagementFeeGreaterThan(BigDecimal value) {
            addCriterion("management_fee >", value, "managementFee");
            return (Criteria) this;
        }

        public Criteria andManagementFeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("management_fee >=", value, "managementFee");
            return (Criteria) this;
        }

        public Criteria andManagementFeeLessThan(BigDecimal value) {
            addCriterion("management_fee <", value, "managementFee");
            return (Criteria) this;
        }

        public Criteria andManagementFeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("management_fee <=", value, "managementFee");
            return (Criteria) this;
        }

        public Criteria andManagementFeeIn(List<BigDecimal> values) {
            addCriterion("management_fee in", values, "managementFee");
            return (Criteria) this;
        }

        public Criteria andManagementFeeNotIn(List<BigDecimal> values) {
            addCriterion("management_fee not in", values, "managementFee");
            return (Criteria) this;
        }

        public Criteria andManagementFeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("management_fee between", value1, value2, "managementFee");
            return (Criteria) this;
        }

        public Criteria andManagementFeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("management_fee not between", value1, value2, "managementFee");
            return (Criteria) this;
        }

        public Criteria andProductAccumulationIsNull() {
            addCriterion("product_accumulation is null");
            return (Criteria) this;
        }

        public Criteria andProductAccumulationIsNotNull() {
            addCriterion("product_accumulation is not null");
            return (Criteria) this;
        }

        public Criteria andProductAccumulationEqualTo(BigDecimal value) {
            addCriterion("product_accumulation =", value, "productAccumulation");
            return (Criteria) this;
        }

        public Criteria andProductAccumulationNotEqualTo(BigDecimal value) {
            addCriterion("product_accumulation <>", value, "productAccumulation");
            return (Criteria) this;
        }

        public Criteria andProductAccumulationGreaterThan(BigDecimal value) {
            addCriterion("product_accumulation >", value, "productAccumulation");
            return (Criteria) this;
        }

        public Criteria andProductAccumulationGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("product_accumulation >=", value, "productAccumulation");
            return (Criteria) this;
        }

        public Criteria andProductAccumulationLessThan(BigDecimal value) {
            addCriterion("product_accumulation <", value, "productAccumulation");
            return (Criteria) this;
        }

        public Criteria andProductAccumulationLessThanOrEqualTo(BigDecimal value) {
            addCriterion("product_accumulation <=", value, "productAccumulation");
            return (Criteria) this;
        }

        public Criteria andProductAccumulationIn(List<BigDecimal> values) {
            addCriterion("product_accumulation in", values, "productAccumulation");
            return (Criteria) this;
        }

        public Criteria andProductAccumulationNotIn(List<BigDecimal> values) {
            addCriterion("product_accumulation not in", values, "productAccumulation");
            return (Criteria) this;
        }

        public Criteria andProductAccumulationBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("product_accumulation between", value1, value2, "productAccumulation");
            return (Criteria) this;
        }

        public Criteria andProductAccumulationNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("product_accumulation not between", value1, value2, "productAccumulation");
            return (Criteria) this;
        }

        public Criteria andPlatformCommissionIsNull() {
            addCriterion("platform_commission is null");
            return (Criteria) this;
        }

        public Criteria andPlatformCommissionIsNotNull() {
            addCriterion("platform_commission is not null");
            return (Criteria) this;
        }

        public Criteria andPlatformCommissionEqualTo(BigDecimal value) {
            addCriterion("platform_commission =", value, "platformCommission");
            return (Criteria) this;
        }

        public Criteria andPlatformCommissionNotEqualTo(BigDecimal value) {
            addCriterion("platform_commission <>", value, "platformCommission");
            return (Criteria) this;
        }

        public Criteria andPlatformCommissionGreaterThan(BigDecimal value) {
            addCriterion("platform_commission >", value, "platformCommission");
            return (Criteria) this;
        }

        public Criteria andPlatformCommissionGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("platform_commission >=", value, "platformCommission");
            return (Criteria) this;
        }

        public Criteria andPlatformCommissionLessThan(BigDecimal value) {
            addCriterion("platform_commission <", value, "platformCommission");
            return (Criteria) this;
        }

        public Criteria andPlatformCommissionLessThanOrEqualTo(BigDecimal value) {
            addCriterion("platform_commission <=", value, "platformCommission");
            return (Criteria) this;
        }

        public Criteria andPlatformCommissionIn(List<BigDecimal> values) {
            addCriterion("platform_commission in", values, "platformCommission");
            return (Criteria) this;
        }

        public Criteria andPlatformCommissionNotIn(List<BigDecimal> values) {
            addCriterion("platform_commission not in", values, "platformCommission");
            return (Criteria) this;
        }

        public Criteria andPlatformCommissionBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("platform_commission between", value1, value2, "platformCommission");
            return (Criteria) this;
        }

        public Criteria andPlatformCommissionNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("platform_commission not between", value1, value2, "platformCommission");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("update_time is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("update_time is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("update_time =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("update_time <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("update_time >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("update_time >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("update_time <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("update_time <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("update_time in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("update_time not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("update_time between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("update_time not between", value1, value2, "updateTime");
            return (Criteria) this;
        }
    }

    /**
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}