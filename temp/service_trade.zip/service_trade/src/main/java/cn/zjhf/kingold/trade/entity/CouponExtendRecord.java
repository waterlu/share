package cn.zjhf.kingold.trade.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author 
 */
public class CouponExtendRecord implements Serializable {
    /**
     * 礼券编码
     */
    private String couponExtendCode;

    /**
     * 礼券批次号
     */
    private String couponCode;

    /**
     * 现金券类型(1现金券，2加息券)
     */
    private Byte couponType;

    /**
     * 现金券面值
     */
    private BigDecimal couponFaceValue;

    /**
     * 加息券加息率
     */
    private BigDecimal couponInterestYieldRate;

    /**
     * 加息券加息类型：0全产品期限加息；1指定加息天数
     */
    private Integer couponInterestYieldType;

    /**
     * 加息券加息天数，interest_yield_type=1时有效
     */
    private Integer couponInterestYieldPeriod;

    /**
     * 有效期开始时间
     */
    private Date validStartTime;

    /**
     * 有效期结束时间
     */
    private Date validEndTime;

    /**
     * 礼券状态(1已发放,2已使用,3已过期,4已作废)
     */
    private Byte couponStatus;

    /**
     * 用户UUID
     */
    private String userUuid;

    /**
     * 用户名
     */
    private String userPhoneNumber;

    /**
     * 用户姓名
     */
    private String userName;

    /**
     * 场景编码(1注册,2实名,3首次绑卡,4首次充值,4首次投资,5邀请好友首次投资)
     */
    private Byte applyScene;

    /**
     * 作废时间
     */
    private Date cancelTime;

    /**
     * 作废说明
     */
    private String cancelRemark;

    /**
     * 删除标记 0未删除，1已删除
     */
    private Byte deleteFlag;

    /**
     * 创建/发放/导入发放时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 更新用户id
     */
    private String updateUserId;

    /**
     * 流水号，仅用于和market_campaign的frequency_limit=2配合使用
     */
    private String orderBillCode;

    /**
     * 被邀请用户UUID
     */
    private String invitedUserUuid;

    /**
     * 已复投奖励次数
     */
    private Integer alreadyRecastCount;

    private static final long serialVersionUID = 1L;

    public String getCouponExtendCode() {
        return couponExtendCode;
    }

    public void setCouponExtendCode(String couponExtendCode) {
        this.couponExtendCode = couponExtendCode;
    }

    public String getCouponCode() {
        return couponCode;
    }

    public void setCouponCode(String couponCode) {
        this.couponCode = couponCode;
    }

    public Byte getCouponType() {
        return couponType;
    }

    public void setCouponType(Byte couponType) {
        this.couponType = couponType;
    }

    public BigDecimal getCouponFaceValue() {
        return couponFaceValue;
    }

    public void setCouponFaceValue(BigDecimal couponFaceValue) {
        this.couponFaceValue = couponFaceValue;
    }

    public BigDecimal getCouponInterestYieldRate() {
        return couponInterestYieldRate;
    }

    public void setCouponInterestYieldRate(BigDecimal couponInterestYieldRate) {
        this.couponInterestYieldRate = couponInterestYieldRate;
    }

    public Integer getCouponInterestYieldType() {
        return couponInterestYieldType;
    }

    public void setCouponInterestYieldType(Integer couponInterestYieldType) {
        this.couponInterestYieldType = couponInterestYieldType;
    }

    public Integer getCouponInterestYieldPeriod() {
        return couponInterestYieldPeriod;
    }

    public void setCouponInterestYieldPeriod(Integer couponInterestYieldPeriod) {
        this.couponInterestYieldPeriod = couponInterestYieldPeriod;
    }

    public Date getValidStartTime() {
        return validStartTime;
    }

    public void setValidStartTime(Date validStartTime) {
        this.validStartTime = validStartTime;
    }

    public Date getValidEndTime() {
        return validEndTime;
    }

    public void setValidEndTime(Date validEndTime) {
        this.validEndTime = validEndTime;
    }

    public Byte getCouponStatus() {
        return couponStatus;
    }

    public void setCouponStatus(Byte couponStatus) {
        this.couponStatus = couponStatus;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getUserPhoneNumber() {
        return userPhoneNumber;
    }

    public void setUserPhoneNumber(String userPhoneNumber) {
        this.userPhoneNumber = userPhoneNumber;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Byte getApplyScene() {
        return applyScene;
    }

    public void setApplyScene(Byte applyScene) {
        this.applyScene = applyScene;
    }

    public Date getCancelTime() {
        return cancelTime;
    }

    public void setCancelTime(Date cancelTime) {
        this.cancelTime = cancelTime;
    }

    public String getCancelRemark() {
        return cancelRemark;
    }

    public void setCancelRemark(String cancelRemark) {
        this.cancelRemark = cancelRemark;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(String updateUserId) {
        this.updateUserId = updateUserId;
    }

    public String getOrderBillCode() {
        return orderBillCode;
    }

    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    public String getInvitedUserUuid() {
        return invitedUserUuid;
    }

    public void setInvitedUserUuid(String invitedUserUuid) {
        this.invitedUserUuid = invitedUserUuid;
    }

    public Integer getAlreadyRecastCount() {
        return alreadyRecastCount;
    }

    public void setAlreadyRecastCount(Integer alreadyRecastCount) {
        this.alreadyRecastCount = alreadyRecastCount;
    }
}