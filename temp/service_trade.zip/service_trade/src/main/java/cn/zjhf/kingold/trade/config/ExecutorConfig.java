package cn.zjhf.kingold.trade.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

/**
 * Created by liuyao on 2017/5/26.
 */

@Configuration
@EnableAsync
public class ExecutorConfig {
    private int ioBusyCorePoolSize = 2;
    private int ioBusyMaxPoolSize = 2;
    private int ioBusyQueueCapacity = 100;

    @Bean
    public Executor IoBusyExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(ioBusyCorePoolSize);
        executor.setMaxPoolSize(ioBusyMaxPoolSize);
        executor.setQueueCapacity(ioBusyQueueCapacity);
        executor.setThreadNamePrefix("IoBusyExecutor-");
        executor.initialize();
        return executor;
    }
}
