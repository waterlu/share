package cn.zjhf.kingold.trade.baofoo;

/**
 * Created by lutiehua on 2017/4/27.
 */
public class QueryResponse extends BaoFooResponse{

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    private String result;

}
