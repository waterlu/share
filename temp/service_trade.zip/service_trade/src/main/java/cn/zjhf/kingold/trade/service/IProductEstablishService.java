package cn.zjhf.kingold.trade.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.entity.InVO.LstProductEstablishLoanItemsVO;
import cn.zjhf.kingold.trade.entity.InVO.LstProductEstablishLoanVO;
import cn.zjhf.kingold.trade.entity.OutVO.CommItemListVO;
import cn.zjhf.kingold.trade.entity.OutVO.TradeInvestSummaryExVO;
import cn.zjhf.kingold.trade.entity.OutVO.TradeInvestSummaryListVO;
import cn.zjhf.kingold.trade.entity.OutVO.TradeOrderListVO;
import cn.zjhf.kingold.trade.entity.ProductFixedIncome;
import cn.zjhf.kingold.trade.vo.LoanCashedDetailVO;

import java.util.List;

/**
 * Created by zhangyijie on 2017/5/19.
 */
public interface IProductEstablishService {

    /**
     * 产品成立
     * @param product_uuid 产品ID
     * @param productType
     * @param createBy
     * @return
     * @throws BusinessException
     */
    public void productEstablish(String product_uuid, String productType, String createBy) throws BusinessException;

    /**
     * Step2 产品成立_放款查询(维度:产品，列表)
     * @return
     * @throws BusinessException
     */
    public TradeInvestSummaryListVO lstProductEstablishLoan(LstProductEstablishLoanVO lstProductEstablishLoanVO) throws BusinessException;

    /**
     * Step3 产品成立_放款详情(维度:产品，单记录)
     * @return
     * @throws BusinessException
     */
    public TradeInvestSummaryExVO getProductEstablishLoanDetail(String productUuid) throws BusinessException;

    /**
     * Step4 产品成立_放款明细(维度:产品-交易，列表)
     * @return
     * @throws BusinessException
     */
    public CommItemListVO<LoanCashedDetailVO> lstProductEstablishLoanItems(LstProductEstablishLoanItemsVO lstProductEstablishLoanItemsVO) throws BusinessException;

    /**
     * Step5 产品成立_放款_审核
     * isAudited 1审核通过  0审核未通过
     * @return
     * @throws BusinessException
     */
    public boolean productEstablishLoanAudit(String userPhone, String productUUId, int isAudited, String message) throws BusinessException;

    /**
     * 锁住放款记录
     * @param productUUId
     * @throws BusinessException
     */
    public void lockTradePayment(String productUUId) throws BusinessException;

    /**
     * 解锁放款记录
     * @param productUUId
     * @throws BusinessException
     */
    public void unLockTradePayment(String productUUId) throws BusinessException;

    /**
     * Step6 产品成立_放款_结算
     * @return
     * @throws BusinessException
     */
    public TradeInvestSummaryExVO productEstablishLoanClear(String userPhone, String productUUIds, String createBy) throws BusinessException;

    public double getPlatformServiceFee(String productUuid, int productPeriod, int rateFormulaParam, double raiseAmount) throws BusinessException;
}

