package cn.zjhf.kingold.trade.constant;

/**
 * Created by liuyao on 2017/11/20.
 */
public class CouponTypeConstant {
    /**
     * 礼券类型，现金券
     */
    public final static int CASH_COUPON_TYPE = 1;

    /**
     * 礼券类型，加息券
     */
    public final static int INTEREST_COUPON_TYPE = 2;


    /**
     * 礼券类型，现金券 or 加息券
     */
    public final static int CASH_INTEREST_TYPE = 6;

    /**
     * 礼券类型，金币任务
     */
    public final static int COIN_TASK_TYPE = 7;

    /**
     * 礼券类型，现金红包
     */
    public final static int RED_PACKET_TYPE = 8;
}
