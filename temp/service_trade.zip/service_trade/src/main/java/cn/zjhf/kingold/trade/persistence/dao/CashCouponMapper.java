package cn.zjhf.kingold.trade.persistence.dao;

import cn.zjhf.kingold.trade.entity.CashCoupon;
import cn.zjhf.kingold.trade.entity.CashCouponExample;
import java.util.List;
import java.util.Map;

import cn.zjhf.kingold.trade.entity.InVO.CashCouponVO;
import cn.zjhf.kingold.trade.utils.WhereCondition;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface CashCouponMapper {
    long countByExample(CashCouponExample example);

    int deleteByExample(CashCouponExample example);

    int deleteByPrimaryKey(String ccCode);

    int insert(CashCoupon record);

    int insertSelective(CashCoupon record);

    List<CashCoupon> selectByExample(CashCouponExample example);

    CashCoupon selectByPrimaryKey(String ccCode);

    @Select("SELECT Max(cc_code) FROM cash_coupon WHERE cc_code LIKE #{IdMode}")
    String lstLastSequence(@Param("IdMode") String IdMode);

    @Select("SELECT Count(*) FROM cash_coupon WHERE cc_code = #{ccCode}")
    int isExists(@Param("ccCode") String ccCode);

    @Update("UPDATE cash_coupon SET cc_status = #{status}, activate_time = now(), update_user_id = #{userId} WHERE cc_code = #{ccCode}")
    void activate(@Param("ccCode") String ccCode, @Param("status") int status,  @Param("userId") String userId);

    @Update("UPDATE cash_coupon SET cc_status = #{status}, disable_time = now(), update_user_id = #{userId} WHERE cc_code = #{ccCode}")
    void disable(@Param("ccCode") String ccCode, @Param("status") int status,  @Param("userId") String userId);

    @Update("UPDATE cash_coupon SET delete_flag = 1, delete_time = now(), update_user_id = #{userId} WHERE cc_code = #{ccCode}")
    void delete(@Param("ccCode") String ccCode, @Param("userId") String userId);

    @Update("UPDATE cash_coupon SET cc_status=#{stopStatus}, disable_time=now() " +
            "WHERE valid_term_type=#{validTimeType} " +
            "AND cc_status<>#{stopStatus} " +
            "AND valid_end_time IS NOT NULL AND valid_end_time<now() " +
            "ORDER BY create_time DESC LIMIT #{limitCount}")
    int autoUpdateStatus(@Param("stopStatus") int stopStatus, @Param("validTimeType") int validTimeType, @Param("limitCount") int limitCount);

    @Select("SELECT Count(*) FROM cash_coupon ${condition}")
    int lstCountByCondition(WhereCondition condition);

    List<CashCoupon> lstByCondition(WhereCondition condition);

    int updateByExampleSelective(@Param("record") CashCoupon record, @Param("example") CashCouponExample example);

    int updateByExample(@Param("record") CashCoupon record, @Param("example") CashCouponExample example);

    int updateByPrimaryKeySelective(CashCoupon record);

    int updateByPrimaryKey(CashCoupon record);

    List<CashCouponVO> getAllCoupon();

    List<CashCouponVO> getCouponList(Map params);
}