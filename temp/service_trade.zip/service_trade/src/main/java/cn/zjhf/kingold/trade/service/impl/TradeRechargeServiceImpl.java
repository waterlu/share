package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.entity.TradeRecharge;
import cn.zjhf.kingold.trade.persistence.dao.TradeRechargeMapper;
import cn.zjhf.kingold.trade.service.ITradeRechargeService;
import com.alibaba.fastjson.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Created by wangxun on 2017/05/04.
 * Copyright by zjinv
 */
@Service
public class TradeRechargeServiceImpl implements ITradeRechargeService {
    private static final Logger LOGGER = LoggerFactory.getLogger(TradeRechargeServiceImpl.class);



    @Autowired
    private TradeRechargeMapper tradeRechargeMapper;

    @Value("${system.run.model}")
    public String runModel;

    @Value("${app.admin.verify.code}")
    public String adminVerifyCode;



    public TradeRechargeServiceImpl() {
    }


    /**
     * 获取账户表列表
     *
     * @param userMap 参数选填： tradeRechargeUuid，accountType，rechargeBillCodeList， rechargeBillTypeList,rechargeStatusList,rechargeTimeBegin，rechargeTimeTo，userPhone，userUuid
     * @return
     * @throws BusinessException
     */
    @Override
    public List<Map> getList(Map userMap) throws BusinessException {
        LOGGER.info("获取账户表列表,param:"+ JSONObject.toJSONString(userMap));
        List<Map> userList = tradeRechargeMapper.getList(userMap);
        return userList;
    }

    /**
     * 获取账户表总数
     *
     * @param userMap 参数必填： tradeRechargeUuid，accountType，rechargeBillCodeList， rechargeBillTypeList,rechargeStatusList,rechargeTimeBegin，rechargeTimeTo，userPhone，userUuid
     * @return
     * @throws BusinessException
     */
    @Override
    public Integer getCount(Map userMap) throws BusinessException {
        LOGGER.info("获取账户表列表总数,param:"+ JSONObject.toJSONString(userMap));
        Integer result = tradeRechargeMapper.getCount(userMap);
        return result;
    }


    @Override
    public TradeRecharge getTradeReacharge(String rechargeBillcCode) throws BusinessException {
        TradeRecharge result = tradeRechargeMapper.selectByBillCode(rechargeBillcCode);
        return result;
    }

}