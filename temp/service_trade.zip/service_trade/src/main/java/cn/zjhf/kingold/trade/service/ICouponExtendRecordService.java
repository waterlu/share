package cn.zjhf.kingold.trade.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.dto.CouponSendConditionDto;
import cn.zjhf.kingold.trade.entity.InVO.*;
import cn.zjhf.kingold.trade.entity.OutVO.CouponExtendRecordItemListVO;
import cn.zjhf.kingold.trade.entity.OutVO.CouponSpecifiedDistributionRecordItemDetailVO;
import cn.zjhf.kingold.trade.entity.OutVO.CouponSpecifiedDistributionRecordItemListVO;
import cn.zjhf.kingold.trade.entity.UserInfo;
import cn.zjhf.kingold.trade.utils.Tuple.TwoTuple;

import java.util.List;
import java.util.Map;

/**
 * Created by zhangyijie on 2017/7/5.
 */
public interface ICouponExtendRecordService {

    /**
     *  触发活动
     * @param conditionDto
     * @param marketCampaignVO
     * @return
     * Integer 1成功；-1失败
     * String message
     * @throws BusinessException
     */
    TwoTuple<Integer, String> establishCouponExtendRecord(CouponSendConditionDto conditionDto, MarketCampaignVO marketCampaignVO) throws BusinessException;

    /**
     * 作废发放给投资者的现金券
     * @param abolishCouponExtendRecordVO
     * @throws BusinessException
     */
    void abolishCouponExtendRecord(CommCouponUpdateVO abolishCouponExtendRecordVO) throws BusinessException;

    /**
     * 使用现金券
     * @param couponExtendCode
     * @param orderBillCode
     * @param userUuid
     * @throws BusinessException
     */
    int useCouponExtendRecord(String couponExtendCode, String orderBillCode, String userUuid) throws BusinessException;

    /**
     * 查询现金券发放记录，运营查询
     * @param lstCondition
     * @return
     * @throws BusinessException
     */
    CouponExtendRecordItemListVO lstCouponExtendRecord(LstCouponExtendRecordConditionVO lstCondition) throws BusinessException;

    /**
     * 查询现金券发放记录，投资者查询自己的现金券列表
     * @param
     * @return
     * @throws BusinessException
     */
    List<CouponExtendRecordVO> lstCouponExtendRecord(String userPhoneNumber, int couponType) throws BusinessException;

    /**
     * 投资者购买产品时，可用的现金券列表
     * @param
     * @return
     * @throws BusinessException
     */
    List<CouponExtendRecordVO> lstCouponExtendRecord(String userPhoneNumber, String productUuid, double amt) throws BusinessException;

    /**
     * 查询单条现金券发放记录
     * @param couponExtendCode
     * @return
     * @throws BusinessException
     */
    CouponExtendRecordVO lstCouponExtendRecord(String couponExtendCode) throws BusinessException;

    /**
     * 自动状态刷新
     */
    void autoRefreshStatus();


    /**
     * 根据查询条件查询现金券发放记录列表(关联cash_coupon和coupon_extend_record两张表查询)
     * @param params
     * @return
     * @throws BusinessException
     */
    List<Map> getExtendRecordList(Map params) throws BusinessException;


    /**
     * 根据查询条件查询现金券发放记录数量(关联cash_coupon和coupon_extend_record两张表查询)
     * @param params
     * @return
     * @throws BusinessException
     */
    Integer getExtendRecordCount(Map params) throws BusinessException;

    /**
     * 查询当前交易产品的可用现金券列表
     *
     * @param userUuid
     * @param productUuid
     * @param  amount
     * @return
     * @throws BusinessException
     */
    List<Map> getAvailableCouponList(String userUuid, String productUuid, Double amount, Integer couponType) throws BusinessException;

    /**
     * 添加指定发放礼券的记录
     * @param ccCodeList
     * @param userList
     * @param operator
     * @throws BusinessException
     */
    boolean insertSpecifiedDistribution(List<String> ccCodeList, List<String> userList, String operator) throws BusinessException;

    /**
     * 查询现金券指定发放记录
     * @param
     * @return
     * @throws BusinessException
     */
    CouponSpecifiedDistributionRecordItemListVO lstCouponSpecifiedDistributionRecord(LstCouponSpecifiedDistributionConditionVO lstCondition) throws BusinessException;

    /**
     * 查询现金券指定发放记录明细
     * @param
     * @return
     * @throws BusinessException
     */
    CouponSpecifiedDistributionRecordItemDetailVO lstCouponSpecifiedDistributionDetail(LstCouponSpecifiedDistributionDetailConditionVO lstCondition) throws BusinessException;

    /**
     * 现金券指定发放记录审核
     * @param
     * @return
     * @throws BusinessException
     */
    boolean couponSpecifiedDistributionAudit(CouponSpecifiedDistributionAuditVO auditInfo) throws BusinessException;

    /**
     * 通用批量发券
     * @param marketCampaign 场景
     * @param userPhones 用户手机号
     * @param operator 操作人
     * @return
     * @throws BusinessException
     */
    int commBatchEstablishCouponExtendRecordEx(MarketCampaignVO marketCampaign, List<String> userPhones, String operator) throws BusinessException;

    void recordShareCount(UserInfo userInfo, MarketCampaignVO marketCampaignVO, Integer shareCount)throws BusinessException;

    Integer getRecordShareCount(UserInfo userInfo, MarketCampaignVO marketCampaignVO)throws BusinessException;

    void updateRecordShareCount(UserInfo userInfo, MarketCampaignVO marketCampaignVO)throws BusinessException;

    /**
     * 通过活动领取领取礼券
     * @param vo
     * @param marketCampaignVO
     * @return
     * @throws BusinessException
     */
    void campaignExchangeCouponExtendRecord(MarketCampaignTriggerVO vo, MarketCampaignVO marketCampaignVO)
            throws BusinessException;

    /**
     * 获取要领取的一个礼券编码
     * @return
     */
    String getCouponExtendCode();
}
