package cn.zjhf.kingold.trade.entity.ReconVO;

import cn.zjhf.kingold.trade.service.impl.ProductClearBase;
import cn.zjhf.kingold.trade.utils.AmountUtils;
import cn.zjhf.kingold.trade.utils.DataUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangyijie on 2017/7/25.
 */
public class ReconTransAcctInfo extends ReconBase {
    public static List<String> getHeader() {
        List<String> header = new ArrayList<String>();
        header.add("转账单号");
        header.add("收款方ID");
        header.add("金疙瘩转账时间");
        header.add("宝付转账时间");
        header.add("金疙瘩转账金额(元)");
        header.add("宝付转账金额(元)");
        header.add("金疙瘩状态");
        header.add("宝付状态");
        header.add("错误原因");

        return header;
    }

    public List<String> getContent() {
        List<String> curLine = new ArrayList<String>();
        curLine.add(orderCode);
        curLine.add(accountNo + "");

        curLine.add(platformTime);
        curLine.add(baoFooTime);
        curLine.add(AmountUtils.toString(platformAmt));
        curLine.add(AmountUtils.toString(baoFooAmt));

        curLine.add(getStatus(platformStatus));
        curLine.add(getBaofooStatus(baoFooStatus));
        curLine.add(errMess);
        return curLine;
    }

    public String getOrderCode() {
        return orderCode;
    }

    public void setOrderCode(String orderCode) {
        this.orderCode = orderCode;
    }

    public Long getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(Long accountNo) {
        this.accountNo = accountNo;
    }

    public String getPlatformTime() {
        return platformTime;
    }

    public void setPlatformTime(String platformTime) {
        this.platformTime = platformTime;
    }

    public double getPlatformAmt() {
        return platformAmt;
    }

    public void setPlatformAmt(double platformAmt) {
        this.platformAmt = platformAmt;
    }

    public int getPlatformStatus() {
        return platformStatus;
    }

    public void setPlatformStatus(int platformStatus) {
        this.platformStatus = platformStatus;
    }

    public String getBaoFooTime() {
        return baoFooTime;
    }

    public void setBaoFooTime(String baoFooTime) {
        this.baoFooTime = baoFooTime;
    }

    public double getBaoFooAmt() {
        return baoFooAmt;
    }

    public void setBaoFooAmt(double baoFooAmt) {
        this.baoFooAmt = baoFooAmt;
    }

    public int getBaoFooStatus() {
        return baoFooStatus;
    }

    public void setBaoFooStatus(int baoFooStatus) {
        this.baoFooStatus = baoFooStatus;
    }

    public String getErrMess() {
        return errMess;
    }

    public void setErrMess(String errMess) {
        if(DataUtils.isEmpty(this.errMess)) {
            this.errMess = errMess;
        }else {
            this.errMess += "|" + errMess;
        }
    }
}
