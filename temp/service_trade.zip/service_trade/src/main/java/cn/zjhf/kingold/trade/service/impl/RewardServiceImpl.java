package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.service_consumer.service.UserServiceConsumer;
import cn.zjhf.kingold.trade.client.ProductClient;
import cn.zjhf.kingold.trade.constant.*;
import cn.zjhf.kingold.trade.dto.*;
import cn.zjhf.kingold.trade.entity.*;
import cn.zjhf.kingold.trade.persistence.dao.OperationReportMapper;
import cn.zjhf.kingold.trade.persistence.dao.RewardMapper;
import cn.zjhf.kingold.trade.persistence.dao.RewardOrderMapper;
import cn.zjhf.kingold.trade.persistence.dao.RewardPrivateFundMapper;
import cn.zjhf.kingold.trade.persistence.mq.message.RewardMessage;
import cn.zjhf.kingold.trade.persistence.mq.producer.RewardProducer;
import cn.zjhf.kingold.trade.service.IAchievementService;
import cn.zjhf.kingold.trade.service.IRewardService;
import cn.zjhf.kingold.trade.service.ITradeOrderService;
import cn.zjhf.kingold.trade.service.ITradePrivateFundOrderService;
import cn.zjhf.kingold.trade.utils.*;
import cn.zjhf.kingold.trade.vo.RewardConfigVO;
import com.alibaba.fastjson.JSON;
import com.google.common.base.Strings;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 奖励服务的实现类
 *
 * Created by lutiehua on 2017/5/26.
 */
@Service
public class RewardServiceImpl implements IRewardService, InitializingBean {

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Autowired
    ITradeOrderService orderService;

    @Autowired
    ITradePrivateFundOrderService privateFundOrderService;

    @Autowired
    UserServiceConsumer userServiceConsumer;

    @Autowired
    ProductClient productClient;

    @Autowired
    RewardMapper rewardMapper;

    @Autowired
    RewardPrivateFundMapper rewardPrivateFundMapper;

    @Autowired
    OperationReportMapper operationReportMapper;

    @Autowired
    private RewardOrderMapper rewardOrderMapper;

    @Autowired
    IAchievementService achievementService;

    @Autowired
    RewardProducer rewardProducer;

    private BigDecimal DAY_OF_YEAR = new BigDecimal(365);

    private BigDecimal MONTH_OF_YEAR = new BigDecimal(12);

    @Value("${award.factor.level.one}")
    private BigDecimal factorLevelOne;

    @Value("${award.factor.level.two}")
    private BigDecimal factorLevelTwo;

    @Value("${award.factor.service}")
    private BigDecimal factorService;

    @Value("${award.master.factor.level.two}")
    private BigDecimal masterFactorLevelTwo;

    @Value("${award.master.factor.level.three}")
    private BigDecimal masterFactorLevelThree;

    @Value("${award.master.factor.service}")
    private BigDecimal masterFactorService;

    /**
     * 奖励有限期的判断起始时间（"yyyy-MM-dd hh:mm:ss"）
     */
    @Value("${reward.expired.active.time}")
    private String rewardActiveTimeConfig;

    /**
     * 奖励有限期时间长度
     */
    @Value("${reward.expired.period}")
    private Long rewardPeriodConfig;

    /**
     * 奖励有限期时间单位
     */
    @Value("${reward.expired.period.unit}")
    private String rewardPeriodUnitConfig;

    /**
     * 奖励有限期的判断起始时间（毫秒）
     */
    private long expiredActiveTime = 0L;

    private long expiredPeriod = 0L;

    final String DAY = "D";

    final String HOUR = "H";

    final String MINUTE = "M";

    @Override
    public List<Reward> getRewardList(String userUUid , Integer rewardStatus, Integer rewardType, Integer offset, Integer limit) {
        Map<String, Object> param = new HashMap<>();
        param.put("userUuid", userUUid);
        param.put("offset", offset);
        param.put("limit", limit);
        param.put("rewardStatus", rewardStatus == null ? null : rewardStatus);
        param.put("rewardType", rewardType == null ? null : rewardType);
        return rewardMapper.getRewardList(param);
    }

    @Override
    public List<Map<String, BigDecimal>> listOrderBySum(String userUUid, Integer isInvest, Integer offset, Integer limit) {
        return rewardMapper.listOrderBySum(userUUid,isInvest, offset, limit);
    }

    @Override
    public Map<String, BigDecimal> getRewardSumListByUuids(List<String> invitedUuidList, String userUuid, String productType) {
        Map<String, Object> param = new HashMap<>();
        param.put("userUuid", userUuid);
        param.put("invitedUuidList", invitedUuidList);
        param.put("productType", productType);
        List<Reward> rewards = rewardMapper.getRewardListByUuids(param);
        Map<String, BigDecimal> result = new HashMap<>();

        for (Reward reward : rewards) {
            String invitedUserUuid = reward.getBeInvitedUserUuid();
            BigDecimal sum = result.get(invitedUserUuid);
            if (sum == null) {
                sum = reward.getRewardAmount();
                result.put(invitedUserUuid, sum);
            }  else {
                result.put(invitedUserUuid, sum.add(reward.getRewardAmount()));
            }
        }
        return result;
    }

    @Override
    public Integer getRewardCount(String userUUid , Integer rewardStatus, Integer rewardType) {
        Map<String, Object> param = new HashMap<>();
        param.put("userUuid", userUUid);
        param.put("rewardStatus", rewardStatus == null ? null : rewardStatus);
        param.put("rewardType", rewardType == null ? null : rewardType);
        return rewardMapper.getRewardCount(param);
    }



    @Override
    public Reward getRewardDetail(String rewardBillCode) {
        return rewardMapper.getRewardDetail(rewardBillCode);
    }

    @Override
    public Map<String, String> getRewardSum(String userUUid , Integer rewardType) {
        Map<String, Object> param = new HashMap<>();
        param.put("userUuid", userUUid);
        if (rewardType != null) {
            param.put("rewardType", rewardType.toString());
        }
        Map<String, String> result = new HashMap<>();

        BigDecimal inviterReward = new BigDecimal(0);
        BigDecimal inviterAllowance = new BigDecimal(0);
        BigDecimal masterReward = new BigDecimal(0);
        BigDecimal paid = new BigDecimal(0);
        BigDecimal paidWithTax = new BigDecimal(0);
        BigDecimal unPaid = new BigDecimal(0);
        List<Map> typeSumList = rewardMapper.getRewardGroupByType(userUUid);
        for(Map typeOne : typeSumList) {
            int type = MapParamUtils.getIntInMap(typeOne, ("rewardType"));
            if (rewardType != null && type != rewardType) {
                continue;
            }
            int status = MapParamUtils.getIntInMap(typeOne, ("rewardStatus"));
            BigDecimal payAmount = MapParamUtils.getBigDecimalInMap(typeOne, "payAmount");
            BigDecimal rewardAmount =MapParamUtils.getBigDecimalInMap(typeOne, "rewardAmount");

            //计算我的奖励总和（待结算（初始化+待结算）、已结算）
            if ( status == RewardStatus.PAID) {
                paid = paid.add(rewardAmount);
                paidWithTax = paidWithTax.add(payAmount);
            } else if (status == RewardStatus.INIT || status == RewardStatus.UNPAID) {
                unPaid = unPaid.add(rewardAmount);
            }

            //分类计算邀请奖励、邀请津贴、达人奖励（已生成+待结算+已结算）
            BigDecimal amount;
            if (status == RewardStatus.PAID) {
                amount = payAmount;
            } else {
                amount = rewardAmount;
            }
            if (type == RewardType.CATEGORY_REWARD) {
                inviterReward = inviterReward.add(amount);
            } else if (type == RewardType.REWARD_INVITER_LEVEL_ONE || type == RewardType.REWARD_INVITER_LEVEL_TWO) {
                inviterAllowance = inviterAllowance.add(amount);
            } else if (type == RewardType.REWARD_MASTER_INVITER_LEVEL_ONE || type == RewardType.REWARD_MASTER_INVITER_LEVEL_THREE||
                    type == RewardType.REWARD_MASTER_INVITER_LEVEL_TWO) {
                masterReward = masterReward.add(amount);
            }
        }
        result.put("paid", paid == null ? "0.00" : paid.setScale(BizConstant.CASH_FRACTION_COUNT,   BigDecimal.ROUND_HALF_UP).toString());
        result.put("unpaid", unPaid == null ? "0.00" : unPaid.setScale(BizConstant.CASH_FRACTION_COUNT,   BigDecimal.ROUND_HALF_UP).toString());
        result.put("paidWithTax", paidWithTax == null ? "0.00" : paidWithTax.setScale(BizConstant.CASH_FRACTION_COUNT,   BigDecimal.ROUND_HALF_UP).toString());
        result.put("inviterReward", inviterReward.setScale(BizConstant.CASH_FRACTION_COUNT,   BigDecimal.ROUND_HALF_UP).toString());
        result.put("inviterAllowance", inviterAllowance.setScale(BizConstant.CASH_FRACTION_COUNT,   BigDecimal.ROUND_HALF_UP).toString());
        result.put("masterReward", masterReward.setScale(BizConstant.CASH_FRACTION_COUNT,   BigDecimal.ROUND_HALF_UP).toString());
        return result;
    }

    @Override
    public BigDecimal getTotalAmount() {
        return rewardMapper.getTotalAmount();
    }

    /**
     * 获取配置信息
     *
     * @return
     */
    @Override
    public RewardConfigVO getConfig() {
        RewardConfigVO rewardConfigVO = new RewardConfigVO();
        rewardConfigVO.setActiveTime(rewardActiveTimeConfig);
        rewardConfigVO.setPeriod(rewardPeriodConfig);
        rewardConfigVO.setPeriodUnit(rewardPeriodUnitConfig);
        rewardConfigVO.setExpiredPeriod(expiredPeriod);
        rewardConfigVO.setExpiredActiveTime(expiredActiveTime);
        return rewardConfigVO;
    }

    /**
     * 产品成立时更新定期奖励状态
     *
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = BusinessException.class)
    public boolean updateProductRewardRecord(String productUuid) throws BusinessException {
        LOGGER.info("======== Update reward record for fixed product is started ========");

        // 参数检查
        if (StringUtils.isEmpty(productUuid)) {
            LOGGER.error("productUuid is null");
            return false;
        }

        LOGGER.info("productUuid={}", productUuid);

        // 查询产品的所有订单（订单状态必须是3产品已成立）
        Map<String, Object> queryProductOrder = new HashMap<>();
        queryProductOrder.put("deleteFlag", 0);
        queryProductOrder.put("productUuid", productUuid);
        List<Integer> statusList = new ArrayList<>();
        statusList.add(BizDefine.ORDER_STATUS_CONFIRM);
        queryProductOrder.put("orderStatusList", statusList);

        List<Map> orderList = orderService.getList(queryProductOrder);
        if (null == orderList || orderList.size() == 0) {
            LOGGER.error("没有查询到产品的定期交易订单：{}", productUuid);
            return false;
        }

        String jsonString = JSON.toJSONString(orderList);
        List<TradeOrder> tradeOrderList = JSON.parseArray(jsonString, TradeOrder.class);
        if (null == tradeOrderList || tradeOrderList.size() == 0) {
            LOGGER.error("没有查询到产品的定期交易订单：{}", productUuid);
            return false;
        }

        // 检查是否有没有产生奖励记录的订单
        Map<String, TradeOrder> missingOrder = new HashMap<>();

        // 查询产品的所有奖励记录
        List<Reward> rewardList = rewardMapper.selectByProductUuid(productUuid);
        if (rewardList.size() > 0) {
            for(TradeOrder tradeOrder : tradeOrderList) {
                String orderBillCode = tradeOrder.getOrderBillCode();
                if (StringUtils.isEmpty(orderBillCode)) {
                    continue;
                }
                // 是否已生成奖励记录
                boolean hit = false;
                for (Reward reward : rewardList) {
                    String rewordOrderBillCode = reward.getOrderBillCode();
                    if (StringUtils.isEmpty(rewordOrderBillCode)) {
                        continue;
                    }

                    if (rewordOrderBillCode.equalsIgnoreCase(orderBillCode)) {
                        hit = true;
                        break;
                    }
                }

                if (!hit) {
                    missingOrder.put(orderBillCode, tradeOrder);
                }
            }
        }

        // 安全第一：处理遗漏的订单（订单状态必须正确）
        // 先补充遗漏的奖励记录，然后再更新状态
        if(missingOrder.size() > 0) {
//            fixFTAwardRecord(productUuid, missingOrder);
            // 只提醒，不补漏
            StringBuffer buffer = new StringBuffer("以下订单没有生成奖励记录：");
            for(TradeOrder tradeOrder : missingOrder.values()) {
                buffer.append(tradeOrder.getOrderBillCode());
                buffer.append("\n");
            }

            LOGGER.warn(buffer.toString());
        }

        Map<String, Object> param = new HashMap<>();
        param.put("productUuid", productUuid);
        param.put("productInterestDate", new Date());

        // 更新产品成立时间
        rewardMapper.updateProductEstablishTime(param);

        // 更新奖励记录的状态
        rewardMapper.updateProductEstablishStatus(param);

        LOGGER.info("======== Update reward record for fixed product is finished ========");
        return true;
    }

    /**
     * 产品成立时更新私募产品奖励状态
     *
     * @param productUuid
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = BusinessException.class)
    public boolean updatePrivateProductRewardRecord(String productUuid) throws BusinessException {
        LOGGER.info("======== Update reward record for private product is started ========");

        // 参数检查
        if (StringUtils.isEmpty(productUuid)) {
            LOGGER.error("productUuid is null");
            return false;
        }

        LOGGER.info("productUuid={}", productUuid);

        // 产品成立日期
        Date establishDate = new Date();
        Map<String, Object> param = new HashMap<>();
        param.put("productUuid", productUuid);
        param.put("productInterestDate", establishDate);

        // 1.更新状态
        // 更新产品成立时间
        rewardMapper.updateProductEstablishTime(param);

        // 更新奖励记录的状态
        rewardMapper.updateProductEstablishStatus(param);

        // 2.生成奖励汇总记录
        Map<String, RewardPrivateFund> rewardPrivateMap = new HashMap<>();
        Map<String, Object> queryPrivateParam = new HashMap<>();
        queryPrivateParam.put("productUuid", productUuid);
        queryPrivateParam.put("productType", ProductType.PRODUCT_PF);
        List<Reward> rewardList = rewardMapper.queryPrivateRewardForSummary(queryPrivateParam);
        LOGGER.info("rewardList.size()={}", rewardList.size());

        // 根据用户ID进行汇总
        for(Reward reward : rewardList) {
            String userUuid = reward.getUserUuid();
            RewardPrivateFund rewardPrivateFund;
            if (rewardPrivateMap.containsKey(userUuid)) {
                rewardPrivateFund = rewardPrivateMap.get(userUuid);
                int count = rewardPrivateFund.getRewardCount();
                count++;
                rewardPrivateFund.setRewardCount(count);
                BigDecimal amount = rewardPrivateFund.getRewardAmount();
                amount = amount.add(reward.getRewardAmount()).setScale(BizConstant.CASH_FRACTION_COUNT, BigDecimal.ROUND_DOWN);
                rewardPrivateFund.setRewardAmount(amount);
            } else {
                rewardPrivateFund = new RewardPrivateFund();
                rewardPrivateFund.setRewardPrivateBillCode(ZJBuzzUtils.generateOrderBillCode(TradeType.TRADE_REWARD_PRIVATE_FUND));
                rewardPrivateFund.setRewardPrivateStatus(RewardPrivateStatus.INIT);
                rewardPrivateFund.setProductUuid(productUuid);
                rewardPrivateFund.setProductCode(reward.getProductCode());
                rewardPrivateFund.setProductName(reward.getProductName());
                rewardPrivateFund.setProductAbbrName(reward.getProductAbbrName());
                rewardPrivateFund.setUserUuid(reward.getUserUuid());
                rewardPrivateFund.setUserMobile(reward.getUserMobile());
                rewardPrivateFund.setUserRealName(reward.getUserRealName());
                rewardPrivateFund.setUserIdCardNo(reward.getUserIdCardNo());
                rewardPrivateFund.setRewardCount(1);
                rewardPrivateFund.setRewardAmount(reward.getRewardAmount());
                rewardPrivateFund.setCreateTime(new Date());
                rewardPrivateFund.setBelongTopOrgPath(reward.getBelongTopOrgPath());
                rewardPrivateFund.setBelongTopUserUuid(reward.getBelongTopUserUuid());
                rewardPrivateMap.put(userUuid, rewardPrivateFund);
            }
            rewardPrivateFund.addReward(reward);
        }

        // 检查记录是否已经存在（产品ID+用户ID唯一）
        List<RewardPrivateFund> rewardPrivateList = new ArrayList<>();
        for(RewardPrivateFund rewardPrivateFund : rewardPrivateMap.values()) {
            String productUUID = rewardPrivateFund.getProductUuid();
            String userUUID = rewardPrivateFund.getUserUuid();
            Map<String, Object> queryParam = new HashMap<>();
            queryParam.put("productUuid", productUUID);
            queryParam.put("userUuid", userUUID);
            int count = rewardPrivateFundMapper.queryByProductAndUser(queryParam);
            if (count > 0) {
                LOGGER.error("汇总记录已经存在，无法写入：productUuid={}, userUuid={}, count={}", productUUID, userUUID, count);
            } else {
                rewardPrivateList.add(rewardPrivateFund);
            }
        }

        // 写入合法数据
        LOGGER.info("写入私募奖励汇总记录");
        for(RewardPrivateFund rewardPrivateFund : rewardPrivateList) {
            // 写入私募奖励汇总记录
            LOGGER.info("productUuid={}, userUuid={}", rewardPrivateFund.getProductUuid(), rewardPrivateFund.getUserUuid());
            String rewardPrivateBillCode = rewardPrivateFund.getRewardPrivateBillCode();
            rewardPrivateFundMapper.insert(rewardPrivateFund);

            // 更新奖励明细中的汇总单号
            LOGGER.info("更新奖励明细中的汇总单号");
            List<Reward> rewardDetailList = rewardPrivateFund.getRewardList();
            for (Reward reward : rewardDetailList) {
                Map<String, Object> rewardParam = new HashMap<>();
                rewardParam.put("summaryBillCode", rewardPrivateBillCode);
                rewardParam.put("rewardBillCode", reward.getRewardBillCode());
                LOGGER.info("summaryBillCode={}, rewardBillCode={}", rewardPrivateBillCode, reward.getRewardBillCode());
                rewardMapper.updateSummaryBillCode(rewardParam);
            }
        }

        LOGGER.info("======== Update reward record for private product is finished ========");
        return true;
    }

    /**
     * 根据条件查询奖励记录（分页查询）
     *
     * @param searchCondition
     * @return
     * @throws BusinessException
     */
    @Override
    public List<Reward> searchReward(RewardSearchDto searchCondition) throws BusinessException {
        List<Reward> rewardList = rewardMapper.searchReward(searchCondition);

        List<List<Reward>> rewardListList = DataUtils.splitList(rewardList, 1000, false);
        for(List<Reward> list : rewardListList) {
            List<String> orderBillCodeList = new ArrayList<String>();
            for(Reward reward : list) {
                if(DataUtils.isNotEmpty(reward.getOrderBillCode())) {
                    orderBillCodeList.add(reward.getOrderBillCode());
                }
            }

            WhereCondition where = new WhereCondition();
            where.setInString("trade_order_bill_code", orderBillCodeList);
            where.noDelete();
            String sql = "SELECT trade_order_bill_code, trade_order_bill_code_extend FROM account_transaction " + where.toString();
            List<Map> retList = operationReportMapper.lstQueryData(new QueryUtils(sql));

            if(retList != null) {
                Map<String, String> codeMap = new HashMap<String, String>();
                for (Map map : retList) {
                    if (map.containsKey("trade_order_bill_code") && map.containsKey("trade_order_bill_code_extend")) {
                        String orderBillCode = map.get("trade_order_bill_code").toString();
                        String orderBillCodeExtend = map.get("trade_order_bill_code_extend").toString();

                        if (DataUtils.isNotEmpty(orderBillCode) & DataUtils.isNotEmpty(orderBillCodeExtend)) {
                            codeMap.put(orderBillCode, orderBillCodeExtend);
                        }
                    }
                }

                for (Reward reward : list) {
                    if (DataUtils.isNotEmpty(reward.getOrderBillCode()) && codeMap.containsKey(reward.getOrderBillCode())) {
                        reward.setOrderBillCodeExtend(codeMap.get(reward.getOrderBillCode()));
                    }
                }
            }
        }

        return rewardList;
    }

    /**
     * 根据条件查询奖励记录总数
     *
     * @param searchCondition
     * @return
     * @throws BusinessException
     */
    @Override
    public int searchRewardCount(RewardSearchDto searchCondition) throws BusinessException {
        return rewardMapper.searchRewardCount(searchCondition);
    }

    @Override
    public List<Reward> searchSummaryReward(String summaryBillCode, int pageNo, int pageSize) throws BusinessException {
        int offset = pageNo * pageSize;
        int limit = pageSize;
        Map<String, Object> param = new HashMap<>();
        param.put("summaryBillCode", summaryBillCode);
        param.put("offset", offset);
        param.put("limit", limit);
        return rewardMapper.queryPageBySummaryBillCode(param);
    }

    @Override
    public int searchSummaryRewardCount(String summaryBillCode) throws BusinessException {
        return rewardMapper.queryBySummaryBillCodeCount(summaryBillCode);
    }

    @Override
    public List<Reward> preApply(RewardSearchDto searchCondition) throws BusinessException {
        // 传过来的是[]，查询的时候是[)，所以加一天
        // 存储的时候还是[]
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(searchCondition.getToCreateTime());
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        Date endDate = calendar.getTime();
        searchCondition.setToCreateTime(endDate);

        // 必须是定期产品产生的奖励
        searchCondition.setProductType(ProductType.PRODUCT_FT);

        return rewardMapper.searchEnableReward(searchCondition);
    }

    @Override
    public List<Reward> preApplyService(RewardSearchDto searchCondition) throws BusinessException {
        // 传过来的是[]，查询的时候是[)，所以加一天
        // 存储的时候还是[]
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(searchCondition.getToCreateTime());
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        Date endDate = calendar.getTime();
        searchCondition.setToCreateTime(endDate);

        // 必须是私募产品产生的奖励
        searchCondition.setProductType(ProductType.PRODUCT_PF);

        return rewardMapper.searchServiceReward(searchCondition);
    }

    /**
     * 根据定期交易生成奖励记录
     *
     * @param tradeOrder
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = BusinessException.class)
    public boolean generateFTAwardRecord(TradeOrder tradeOrder) throws BusinessException {
        LOGGER.info("======== Generating reward record for fixed term product is started ========");
        String orderBillCode = tradeOrder.getOrderBillCode();
        LOGGER.info("orderBillCode={}", orderBillCode);

        // 重新查询订单
        Map<String, Object> orderMap = orderService.getTradeOrder(orderBillCode);
        if (null == orderMap) {
            LOGGER.error("交易订单号不存在：{}", orderBillCode);
            return false;
        }

        String jsonString = JSON.toJSONString(orderMap);
        tradeOrder = JSON.parseObject(jsonString, TradeOrder.class);

        // 订单必须是已支付的状态
        if (tradeOrder.getOrderStatus() != BizDefine.ORDER_STATUS_CONFIRM) {
            LOGGER.error("订单状态不是已支付：{} ", tradeOrder.getOrderStatus());
            return false;
        }

        // 订单金额不能为空
        if (null == tradeOrder.getOrderAmount()) {
            LOGGER.error("订单金额不能为空：{} ", orderBillCode);
            return false;
        }

        LOGGER.info("orderAmount={}", tradeOrder.getOrderAmount());

        // 检查时间限制（首投6个月内可以生成奖励，超过6个月不再生成奖励）
        long orderTime = tradeOrder.getTransactionTime().getTime();
        if (expiredActiveTime > 0 && orderTime >= expiredActiveTime) {
            LOGGER.info("激活奖励有限期判断");
            List<RewardOrder> rewardOrderList = rewardOrderMapper.query(tradeOrder.getUserUuid());
            if (rewardOrderList.size() > 0) {
                // 按时间排序，第一个是首投
                RewardOrder rewardOrder = rewardOrderList.get(0);
                long firstOrderTime = rewardOrder.getOrderTime().getTime();

                // 以毫秒为单位
                long interval = orderTime - firstOrderTime;

                if (interval > expiredPeriod) {
                    // 超过奖励有效期
                    LOGGER.warn("用户[{}]订单[{}]距离首投时间[{}]>预置时间[{}]，没有生成奖励", tradeOrder.getUserUuid(), orderBillCode,
                            interval, expiredPeriod);
                    return false;
                }

                rewardOrder = new RewardOrder();
                rewardOrder.setUserUuid(tradeOrder.getUserUuid());
                rewardOrder.setOrderBillCode(tradeOrder.getOrderBillCode());
                rewardOrder.setOrderTime(tradeOrder.getTransactionTime());
                // 记录发奖励的订单
                rewardOrderMapper.insert(rewardOrder);
            } else {
                RewardOrder rewardOrder = new RewardOrder();
                rewardOrder.setUserUuid(tradeOrder.getUserUuid());
                rewardOrder.setOrderBillCode(tradeOrder.getOrderBillCode());
                rewardOrder.setOrderTime(tradeOrder.getTransactionTime());
                // 记录首投
                rewardOrderMapper.insert(rewardOrder);
                LOGGER.info("用户[{}]奖励订单首投[{}]", tradeOrder.getUserUuid(), tradeOrder.getOrderBillCode());
            }
        } else {
            LOGGER.info("未激活奖励有限期判断");
        }

        // 检查是否已经生成过奖励
        List<Reward> rewards = rewardMapper.queryByOrderBillCodeEx(orderBillCode, RewardType.CATEGORY_REWARD);
        if (rewards.size() > 0) {
            LOGGER.error("查询到已经存在奖励记录，共{}条", rewards.size());
            return false;
        }

        // 确认产品
        String productUuid = tradeOrder.getProductUuid();
        if (StringUtils.isEmpty(productUuid)) {
            LOGGER.error("productUuid不能为空");
            return false;
        }

        LOGGER.info("productUuid={}", productUuid);

        // 查询产品信息
        String url = String.format(URL.URL_PRODUCT_GET_FIXED_TERM, productUuid);
        Map<String, Object> param = new HashMap<>();
        ResponseResult responseResult = productClient.getFixedIncome(productUuid,param);
        if (!responseResult.isSuccessful()) {
            LOGGER.error("查询产品信息失败：{}" + responseResult.getMsg());
            return false;
        }
        ProductFTDto productFTDto = JsonUtil.getData(responseResult, ProductFTDto.class);
        LOGGER.info("product={}", productFTDto.toString());

        // 查看奖励设置
        jsonString = productFTDto.getProductAward();
        List<ProductRewardDto> rewardDtoList = JSON.parseArray(jsonString, ProductRewardDto.class);
        if (null == rewardDtoList || rewardDtoList.size() == 0) {
            LOGGER.error("产品没有找到奖励设置");
            return false;
        }

        // 奖励按金额排序
        Collections.sort(rewardDtoList, new Comparator<ProductRewardDto>() {
            @Override
            public int compare(ProductRewardDto o1, ProductRewardDto o2) {
                return o1.getMinAmount() - o2.getMinAmount();
            }
        });

        // 检查奖励设置
        if (!checkRewardSetting(rewardDtoList)) {
            LOGGER.error("奖励设置错误");
            return false;
        }

        // 确认认购人
        String userUuid = tradeOrder.getUserUuid();
        if (StringUtils.isEmpty(userUuid)) {
            LOGGER.error("userUuid不能为空");
            return false;
        }

        LOGGER.info("userUuid={}", userUuid);

        // 查询所有上级
        Map<String, Object> userRelationParam = new HashMap<>();
        userRelationParam.put("traceID", UUID.randomUUID().toString());
        url = String.format(URL.URL_USER_GET_RELATION, userUuid);
        responseResult = userServiceConsumer.get(url, userRelationParam);
        if (!responseResult.isSuccessful()) {
            LOGGER.error("查询用户关系失败：{}" + responseResult.getMsg());
            return false;
        }
        UserRelationDto userRelationDto = userServiceConsumer.getData(responseResult, UserRelationDto.class);
        LOGGER.info("userRelation={}", userRelationDto);

        // 每一级的奖励
        List<Reward> rewardList = new ArrayList<>();

        // 生成奖励记录
        if (createReward4Fixed(rewardList, userRelationDto, productFTDto, rewardDtoList, tradeOrder)) {
            // 持久化奖励记录到数据库中
            saveReward(rewardList);
        }

        LOGGER.info("======== Generating reward record for fixed term product is finished ========");
        return true;
    }


    /**
     * 根据定期产品达人交易生成奖励记录
     *
     * @param tradeOrder
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = BusinessException.class)
    public boolean generateMasterFTAwardRecord(TradeOrder tradeOrder, String masterAward) throws BusinessException {
        Long tick = System.currentTimeMillis();
        LOGGER.info("======== Generating master reward record for fixed term product is started========" + tick);

        String orderBillCode = tradeOrder.getOrderBillCode();
        LOGGER.info("orderBillCode={}", orderBillCode);

        // 重新查询订单
        LOGGER.info(tick + ", 1重新查询订单");
        Map<String, Object> orderMap = orderService.getTradeOrder(orderBillCode);
        if (null == orderMap) {
            LOGGER.error("交易订单号不存在：{}", orderBillCode);
            return false;
        }

        String jsonString = JSON.toJSONString(orderMap);
        tradeOrder = JSON.parseObject(jsonString, TradeOrder.class);

        // 订单必须是已支付的状态
        LOGGER.info(tick + ", 2订单必须是已支付的状态");
        if (tradeOrder.getOrderStatus() != BizDefine.ORDER_STATUS_CONFIRM) {
            LOGGER.error("订单状态不是已支付：{} ", tradeOrder.getOrderStatus());
            return false;
        }

        // 订单金额不能为空
        LOGGER.info(tick + ", 3订单金额不能为空");
        if (null == tradeOrder.getOrderAmount()) {
            LOGGER.error("订单金额不能为空：{} ", orderBillCode);
            return false;
        }

        LOGGER.info("orderAmount={}", tradeOrder.getOrderAmount());

        // 检查是否已经生成过达人奖励
        LOGGER.info(tick + ", 4检查是否已经生成过达人奖励");
        List<Reward> rewards = rewardMapper.queryByOrderBillCodeEx(orderBillCode, RewardType.CATEGORY_MASTER_REWARD);
        if (rewards.size() > 0) {
            LOGGER.error("查询到已经存在达人奖励记录，共{}条", rewards.size());
            return false;
        }

        // 确认产品
        LOGGER.info(tick + ", 5确认产品");
        String productUuid = tradeOrder.getProductUuid();
        if (StringUtils.isEmpty(productUuid)) {
            LOGGER.error("productUuid不能为空");
            return false;
        }

        LOGGER.info("productUuid={}", productUuid);

        // 查看奖励设置
        LOGGER.info(tick + ", 6查看奖励设置");
        jsonString = masterAward;
        List<ProductRewardDto> rewardDtoList = JSON.parseArray(jsonString, ProductRewardDto.class);
        if (null == rewardDtoList || rewardDtoList.size() == 0) {
            LOGGER.error("产品没有找到达人奖励设置");
            return false;
        }

        // 奖励按金额排序
        Collections.sort(rewardDtoList, new Comparator<ProductRewardDto>() {
            @Override
            public int compare(ProductRewardDto o1, ProductRewardDto o2) {
                return o1.getMinAmount() - o2.getMinAmount();
            }
        });

        // 检查奖励设置
        LOGGER.info(tick + ", 7检查奖励设置");
        if (!checkRewardSetting(rewardDtoList)) {
            LOGGER.error("奖励设置错误");
            return false;
        }

        // 确认认购人
        LOGGER.info(tick + ", 8确认认购人");
        String userUuid = tradeOrder.getUserUuid();
        if (StringUtils.isEmpty(userUuid)) {
            LOGGER.error("userUuid不能为空");
            return false;
        }

        LOGGER.info("userUuid={}", userUuid);

        // 查询所有上级
        LOGGER.info(tick + ", 9查询所有上级");
        Map<String, Object> userRelationParam = new HashMap<>();
        userRelationParam.put("traceID", UUID.randomUUID().toString());
        String url = String.format(URL.URL_USER_GET_RELATION, userUuid);
        ResponseResult responseResult = userServiceConsumer.get(url, userRelationParam);
        if (!responseResult.isSuccessful()) {
            LOGGER.error("查询用户关系失败：{}" + responseResult.getMsg());
            return false;
        }
        UserRelationDto userRelationDto = userServiceConsumer.getData(responseResult, UserRelationDto.class);
        LOGGER.info("userRelation={}", userRelationDto);

        // 查询产品信息
        LOGGER.info(tick + ", 10查询产品信息");
        url = String.format(URL.URL_PRODUCT_GET_FIXED_TERM, productUuid);
        Map<String, Object> param = new HashMap<>();
        responseResult = productClient.getFixedIncome(productUuid,param);
        if (!responseResult.isSuccessful()) {
            LOGGER.error("查询产品信息失败：{}" + responseResult.getMsg());
            return false;
        }
        ProductFTDto productFTDto = JsonUtil.getData(responseResult, ProductFTDto.class);
        LOGGER.info("product={}", productFTDto.toString());

        // 生成奖励记录
        LOGGER.info(tick + ", 11生成奖励记录");
        List<Reward> rewardList = new ArrayList<>();
        createMasterReward4Fixed(rewardList, userRelationDto, productFTDto, rewardDtoList, tradeOrder, tick);
        LOGGER.info(tick + ", 12, " + rewardList.size());
        saveReward(rewardList);

//        if (createMasterReward4Fixed(rewardList, userRelationDto, productFTDto, rewardDtoList, tradeOrder, tick)) {
//            // 持久化奖励记录到数据库中
//            LOGGER.info(tick + ", 12, " + rewardList.size());
//            saveReward(rewardList);
//        }

        LOGGER.info("======== Generating master reward record for fixed term product finished ========" + tick);
        return true;
    }

    /**
     * 根据私募订单生成奖励记录
     *
     * @param tradeOrder 私募订单号
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = BusinessException.class)
    public boolean generatePFAwardRecord(TradePrivateFundOrder tradeOrder) throws BusinessException {
        LOGGER.info("======== Generating reward record for private fund product is started ========");
        String billCode = tradeOrder.getPfoCode();
        LOGGER.info("billCode={}", billCode);

        // 重新查询订单
        Map<String, Object> privateFundOrderParam = new HashMap<>();
        privateFundOrderParam.put("pfoCode", billCode);
        Map<String, Object> orderMap = privateFundOrderService.getWithFilter(privateFundOrderParam);
        if (null == orderMap) {
            LOGGER.error("交易订单号不存在：{}", billCode);
            return false;
        }

        String jsonString = JSON.toJSONString(orderMap);
        tradeOrder = JSON.parseObject(jsonString, TradePrivateFundOrder.class);

        // 私募订单必须是2已确认状态
        if (tradeOrder.getPfoStatus() != TradeConstants.PFO_STAUTS_DONE) {
            LOGGER.error("订单状态不是已确认：{} ", tradeOrder.getPfoStatus());
            return false;
        }

        // 订单金额不能为空
        if (null == tradeOrder.getPurchaseAmount()) {
            LOGGER.error("订单金额不能为空：{} ", billCode);
            return false;
        }

        LOGGER.info("orderAmount={}", tradeOrder.getPurchaseAmount());

        // 检查是否已经生成过奖励
        List<Reward> rewards = rewardMapper.queryByOrderBillCode(billCode);
        if (rewards.size() > 0) {
            LOGGER.error("查询到已经存在奖励记录，共{}条", rewards.size());
            return false;
        }

        // 确认产品
        String productUuid = tradeOrder.getProductUuid();
        if (StringUtils.isEmpty(productUuid)) {
            LOGGER.error("productUuid is empty");
            return false;
        }

        LOGGER.info("productUuid={}", productUuid);

        // 查询产品信息
        String url = String.format(URL.URL_PRODUCT_GET_PRIVATE_FUND, productUuid);
        Map<String, Object> param = new HashMap<>();
        ResponseResult responseResult = productClient.getPrivateFund(productUuid, param);
        if (!responseResult.isSuccessful()) {
            LOGGER.error("查询产品信息失败：{}" + responseResult.getMsg());
            return false;
        }

        ProductFTDto productFTDto = JsonUtil.getData(responseResult, ProductFTDto.class);
        LOGGER.info("product={}", productFTDto);

        // 查看奖励设置
        jsonString = productFTDto.getProductAward();
        List<ProductRewardDto> rewardDtoList = JSON.parseArray(jsonString, ProductRewardDto.class);
        if (null == rewardDtoList || rewardDtoList.size() == 0) {
            LOGGER.error("产品没有找到奖励设置");
            return false;
        }

        // 奖励按金额排序
        Collections.sort(rewardDtoList, new Comparator<ProductRewardDto>() {
            @Override
            public int compare(ProductRewardDto o1, ProductRewardDto o2) {
                return o1.getMinAmount() - o2.getMinAmount();
            }
        });

        // 检查奖励设置
        if (!checkRewardSetting(rewardDtoList)) {
            return false;
        }

        // 确认预约人
        String userUuid = tradeOrder.getInvestorUserUuid();
        if (StringUtils.isEmpty(userUuid)) {
            LOGGER.error("userUuid is empty");
            return false;
        }

        LOGGER.info("userUuid={}", userUuid);

        // 检查是否是给自己做的预约
        boolean isBookMyself = false;
        String customerIdCardNo = tradeOrder.getCustomerIdCardNo();
        url = URL.URL_USER_GET_INVESTOR;
        Map<String, Object> investorParam = new HashMap<>();
        investorParam.put("userUuids", userUuid);
        responseResult = userServiceConsumer.get(url, investorParam);
        if (!responseResult.isSuccessful()) {
            LOGGER.error("查询投资人信息失败：{}" + userUuid);
            return false;
        }

        List<InvestorDto> investorDtoList = userServiceConsumer.getDataArray(responseResult, InvestorDto.class);
        if (investorDtoList.size() > 0) {
            InvestorDto investorDto = investorDtoList.get(0);
            String investorIdCardNo = investorDto.getInvestorIdCardNo();
            // 根据身份证号码判断是否给自己预约，投资人身份证号码=预约客户身份证号码？
            if (StringUtils.isNotEmpty(investorIdCardNo) && investorIdCardNo.equalsIgnoreCase(customerIdCardNo)) {
                isBookMyself = true;
            }
        }

        LOGGER.info("isBookMyself={}", isBookMyself);

        // 查询所有上级
        Map<String, Object> userRelationParam = new HashMap<>();
        userRelationParam.put("traceID", UUID.randomUUID().toString());
        url = String.format(URL.URL_USER_GET_RELATION, userUuid);
        responseResult = userServiceConsumer.get(url, userRelationParam);
        if (!responseResult.isSuccessful()) {
            LOGGER.error("查询用户关系失败：{}" + userUuid);
            return false;
        }

        UserRelationDto userRelationDto = userServiceConsumer.getData(responseResult, UserRelationDto.class);
        LOGGER.info("userRelation={}", userRelationDto);

        // 每一级的奖励
        List<Reward> rewardList = new ArrayList<>();

        // 创建私募奖励记录
        if (createReward4Private(rewardList, userRelationDto, productFTDto, rewardDtoList, tradeOrder, isBookMyself)) {
            // 持久化奖励记录到数据库中
            saveReward(rewardList);
        }


        LOGGER.info("======== Generating reward record for private fund product is finished ========");
        return true;
    }


    /**
     * 根据定期交易补充奖励记录
     *
     * @param productUuid
     * @param tradeOrderMap
     * @return
     * @throws BusinessException
     */
    private boolean fixFTAwardRecord(String productUuid, Map<String, TradeOrder> tradeOrderMap) throws BusinessException {
        LOGGER.info("======== Fix reward record for fixed term product is started ========");
        // 确认产品
        if (StringUtils.isEmpty(productUuid)) {
            LOGGER.error("productUuid is empty");
            return false;
        }

        LOGGER.info("productUuid={}", productUuid);

        // 查询产品信息
        String url = String.format(URL.URL_PRODUCT_GET_FIXED_TERM, productUuid);
        Map<String, Object> param = new HashMap<>();
        ResponseResult responseResult = productClient.getFixedIncome(productUuid, param);
        ProductFTDto productFTDto = JsonUtil.getData(responseResult, ProductFTDto.class);
        LOGGER.info("product={}", productFTDto);

        // 查看奖励设置
        String jsonString = productFTDto.getProductAward();
        List<ProductRewardDto> rewardDtoList = JSON.parseArray(jsonString, ProductRewardDto.class);
        if (null == rewardDtoList || rewardDtoList.size() == 0) {
            LOGGER.error("cannot find reward setting");
            return false;
        }

        // 奖励按金额排序
        Collections.sort(rewardDtoList, new Comparator<ProductRewardDto>() {
            @Override
            public int compare(ProductRewardDto o1, ProductRewardDto o2) {
                return o1.getMinAmount() - o2.getMinAmount();
            }
        });

        // 检查奖励设置
        if (!checkRewardSetting(rewardDtoList)) {
            LOGGER.error("wrong reward setting");
            return false;
        }

        // 遍历所有订单
        for(TradeOrder tradeOrder : tradeOrderMap.values()) {
            fixFTAwardRecord(productFTDto, rewardDtoList, tradeOrder);
        }

        LOGGER.info("======== Fix reward record for fixed term product is finished ========");
        return true;
    }

    /**
     * 根据定期交易补充奖励记录
     *
     * @param tradeOrder
     * @return
     * @throws BusinessException
     */
    private boolean fixFTAwardRecord(ProductFTDto productFTDto, List<ProductRewardDto> rewardDtoList,
                                     TradeOrder tradeOrder) throws BusinessException {
        LOGGER.info("orderBillCode={}", tradeOrder.getOrderBillCode());

        // 订单金额不能为空
        if (null == tradeOrder.getOrderAmount()) {
            LOGGER.error("order amount is null {} ", tradeOrder.getOrderBillCode());
            return false;
        }

        // 确认认购人
        String userUuid = tradeOrder.getUserUuid();
        if (StringUtils.isEmpty(userUuid)) {
            LOGGER.error("userUuid is empty");
            return false;
        }

        LOGGER.info("userUuid={}", userUuid);

        // 查询所有上级
        Map<String, Object> userRelationParam = new HashMap<>();
        userRelationParam.put("traceID", UUID.randomUUID().toString());
        String url = String.format(URL.URL_USER_GET_RELATION, userUuid);
        ResponseResult responseResult = userServiceConsumer.get(url, userRelationParam);
        if (!responseResult.isSuccessful()) {
            LOGGER.error(responseResult.getMsg());
            return false;
        }

        UserRelationDto userRelationDto = userServiceConsumer.getData(responseResult, UserRelationDto.class);
        LOGGER.info("userRelation={}", userRelationDto);

        if (StringUtils.isEmpty(userRelationDto.getUserUuid())) {
            LOGGER.error("cannot find {} user relation", userUuid);
            return false;
        }

        List<Reward> rewardList = new ArrayList<>();

        // 生成奖励记录
        if (createReward4Fixed(rewardList, userRelationDto, productFTDto, rewardDtoList, tradeOrder)) {
            // 持久化奖励记录到数据库中
            return saveReward(rewardList);
        }

        return true;
    }

    /**
     * 创建定期理财奖励
     *
     * @param rewardList 待持久化的奖励列表
     * @param userRelationDto 用户关系信息
     * @param productFTDto 产品信息
     * @param rewardDtoList 奖励设置信息
     * @param tradeOrder 交易订单信息
     * @throws BusinessException
     */
    private boolean createReward4Fixed(List<Reward> rewardList, UserRelationDto userRelationDto, ProductFTDto productFTDto,
                                List<ProductRewardDto> rewardDtoList, TradeOrder tradeOrder) throws BusinessException {
        // 创建时间
        Date createTime = new Date();

        BigDecimal saleFactor = null;
        String userPhone = tradeOrder.getUserPhone();

        // 邀请奖励
        if (StringUtils.isNotEmpty(userRelationDto.getInviterLevelOneUuid())) {
            LOGGER.info("生成邀请奖励");

            Reward reward = new Reward();
            reward.setRewardCategory(RewardType.CATEGORY_REWARD);
            reward.setBelongTopOrgPath(tradeOrder.getServiceUserOrgPath());
            reward.setBelongTopUserUuid(tradeOrder.getServiceUserUuid());
            reward.setBeInvitedMobile(userPhone);
            reward.setBeInvitedUserUuid(tradeOrder.getUserUuid());
            reward.setBeInvitedInvestTime(tradeOrder.getPayedTime());
            // 设置用户UUID
            reward.setUserUuid(userRelationDto.getInviterLevelOneUuid());
            // 设置产品相关信息
            setProductInfo(reward, productFTDto);

            // 设置订单相关信息
            // 基于订单金额计算（营销款也计算在内）
            reward.setOrderBillCode(tradeOrder.getOrderBillCode());
            setRewardBaseInfo(reward, RewardType.REWARD_SALE, tradeOrder.getOrderAmount(), createTime);

            // 奖励比例
            BigDecimal factor = getRewardFactor(rewardDtoList, reward.getBaseAmount());
            if (null == factor) {
                LOGGER.error("没有找到匹配的奖励比例：{}", reward.getBaseAmount());
                return false;
            }
            factor = factor.setScale(6, BigDecimal.ROUND_HALF_UP);
            reward.setRewardFactor(factor);
            saleFactor = factor;

            LOGGER.info("奖励比例={}", saleFactor);

            // 奖励金额
            BigDecimal rewardAmount = calculateReward4Fixed(reward, saleFactor, new BigDecimal(1));
            reward.setRewardAmount(rewardAmount);
            setRewardAmount(reward);

            reward.setRewardBillCode(ZJBuzzUtils.generateOrderBillCode(TradeType.TRADE_REWARD_SALE));
            rewardList.add(reward);

            //发送MQ
            RewardMessage rewardMessage = new RewardMessage();
            rewardMessage.setReward(reward);
            rewardProducer.send(rewardMessage);

        }

        // 一度邀请津贴
        if (StringUtils.isNotEmpty(userRelationDto.getInviterLevelTwoUuid())) {
            LOGGER.info("生成一度邀请津贴");

            Reward reward = new Reward();
            reward.setRewardCategory(RewardType.CATEGORY_REWARD);
            reward.setBelongTopOrgPath(tradeOrder.getServiceUserOrgPath());
            reward.setBelongTopUserUuid(tradeOrder.getServiceUserUuid());
            reward.setBeInvitedMobile(userPhone);
            reward.setBeInvitedUserUuid(tradeOrder.getUserUuid());
            reward.setBeInvitedInvestTime(tradeOrder.getPayedTime());
            // 设置用户UUID
            reward.setUserUuid(userRelationDto.getInviterLevelTwoUuid());

            // 设置产品相关信息
            setProductInfo(reward, productFTDto);

            // 设置订单相关信息
            // 基于邀请奖励金额计算
            reward.setOrderBillCode(tradeOrder.getOrderBillCode());
            setRewardBaseInfo(reward, RewardType.REWARD_INVITER_LEVEL_ONE, tradeOrder.getOrderAmount(), createTime);
            reward.setBaseAmount(reward.getInvestAmount());

            // 奖励比例
            BigDecimal factor = factorLevelOne.multiply(saleFactor).setScale(6, BigDecimal.ROUND_HALF_UP);
            LOGGER.info("奖励比例={}", factor);
            reward.setRewardFactor(factor);

            // 奖励金额
            BigDecimal rewardAmount = calculateReward4Fixed(reward, saleFactor, factorLevelOne);
            reward.setRewardAmount(rewardAmount);
            setRewardAmount(reward);

            reward.setRewardBillCode(ZJBuzzUtils.generateOrderBillCode(TradeType.TRADE_REWARD_INVITER_ONE));
            rewardList.add(reward);

            //发送MQ
            RewardMessage rewardMessage = new RewardMessage();
            rewardMessage.setReward(reward);
            rewardProducer.send(rewardMessage);

        }

        // 二度邀请津贴
        if (StringUtils.isNotEmpty(userRelationDto.getInviterLevelThreeUuid())) {
            LOGGER.info("生成二度邀请津贴");

            Reward reward = new Reward();
            reward.setRewardCategory(RewardType.CATEGORY_REWARD);
            reward.setBelongTopOrgPath(tradeOrder.getServiceUserOrgPath());
            reward.setBelongTopUserUuid(tradeOrder.getServiceUserUuid());
            reward.setBeInvitedMobile(userPhone);
            reward.setBeInvitedUserUuid(tradeOrder.getUserUuid());
            reward.setBeInvitedInvestTime(tradeOrder.getPayedTime());
            // 设置用户UUID
            reward.setUserUuid(userRelationDto.getInviterLevelThreeUuid());

            // 设置产品相关信息
            setProductInfo(reward, productFTDto);

            // 设置订单相关信息
            // 基于邀请奖励金额计算
            reward.setOrderBillCode(tradeOrder.getOrderBillCode());
            setRewardBaseInfo(reward, RewardType.REWARD_INVITER_LEVEL_TWO, tradeOrder.getOrderAmount(), createTime);
            reward.setBaseAmount(reward.getInvestAmount());

            // 奖励比例
            BigDecimal factor = factorLevelTwo.multiply(saleFactor).setScale(6, BigDecimal.ROUND_HALF_UP);
            LOGGER.info("奖励比例={}", factor);
            reward.setRewardFactor(factor);

            // 奖励金额
            BigDecimal rewardAmount = calculateReward4Fixed(reward, saleFactor, factorLevelTwo);
            reward.setRewardAmount(rewardAmount);
            setRewardAmount(reward);

            reward.setRewardBillCode(ZJBuzzUtils.generateOrderBillCode(TradeType.TRADE_REWARD_INVITER_TWO));
            rewardList.add(reward);

            //发送MQ
            RewardMessage rewardMessage = new RewardMessage();
            rewardMessage.setReward(reward);
            rewardProducer.send(rewardMessage);

        }

        return true;
    }

    /**
     * 判断该投资者是否是理财达人
     * @param userUuid
     * @return
     */
    private boolean isMasterInvester(String userUuid) throws BusinessException {
        Map params = new HashMap();
        params.put("userUuid", userUuid);
        ResponseResult result = userServiceConsumer.get(String.format(URL.URL_GET_USER, userUuid), params);
        if (result.isSuccessful()) {
            Map<String, Object> userInfo = (Map)result.getData();
            int investorType = new BizParam(userInfo).getInt("investorType");

            return investorType == InvestorType.FINANCIAL_PLANNER;
        } else if (result.getCode() == 1109) {//用户被冻结
            LOGGER.error("sendCoupon first invest user freezing. userUuid={}", userUuid);
            return false;
        } else {
            LOGGER.error("getInviterUuid get user info error.resultCode={}, msg={}", result.getCode(), result.getMsg());
            throw new BusinessException(result.getCode(), result.getMsg(), true);
        }
    }

    /**
     * 创建定期理财达人奖励
     *
     * @param rewardList 待持久化的奖励列表
     * @param userRelationDto 用户关系信息
     * @param productFTDto 产品信息
     * @param rewardDtoList 奖励设置信息
     * @param tradeOrder 交易订单信息
     * @param curTick
     * @throws BusinessException
     */
    private boolean createMasterReward4Fixed(List<Reward> rewardList, UserRelationDto userRelationDto, ProductFTDto productFTDto,
                                             List<ProductRewardDto> rewardDtoList, TradeOrder tradeOrder, Long curTick) throws BusinessException {
        // 创建时间
        Date createTime = new Date();
        String userPhone = tradeOrder.getUserPhone();

        BigDecimal saleFactor = getRewardFactor(rewardDtoList, tradeOrder.getOrderAmount());
        if (null == saleFactor) {
            LOGGER.error("没有找到匹配的达人比例：{}", tradeOrder.getOrderAmount());
            return false;
        }
        saleFactor.setScale(6, BigDecimal.ROUND_HALF_UP);

        // 达人一度奖励
        LOGGER.info("达人一度奖励" + curTick);
        if (StringUtils.isNotEmpty(userRelationDto.getInviterLevelOneUuid()) && isMasterInvester(userRelationDto.getInviterLevelOneUuid())) {
            LOGGER.info("生成达人一度奖励" + curTick);

            Reward reward = new Reward();
            reward.setRewardCategory(RewardType.CATEGORY_MASTER_REWARD);
            reward.setBelongTopOrgPath(tradeOrder.getServiceUserOrgPath());
            reward.setBelongTopUserUuid(tradeOrder.getServiceUserUuid());
            reward.setBeInvitedMobile(userPhone);
            reward.setBeInvitedUserUuid(tradeOrder.getUserUuid());
            reward.setBeInvitedInvestTime(tradeOrder.getPayedTime());
            // 设置用户UUID
            reward.setUserUuid(userRelationDto.getInviterLevelOneUuid());
            // 设置产品相关信息
            setProductInfo(reward, productFTDto);

            // 设置订单相关信息
            // 基于订单金额计算（营销款也计算在内）
            reward.setOrderBillCode(tradeOrder.getOrderBillCode());
            setRewardBaseInfo(reward, RewardType.REWARD_MASTER_INVITER_LEVEL_ONE, tradeOrder.getOrderAmount(), createTime);

            // 奖励比例
            reward.setRewardFactor(saleFactor);

            LOGGER.info("奖励比例={}", saleFactor);

            // 奖励金额
            BigDecimal rewardAmount = calculateReward4Fixed(reward, saleFactor, new BigDecimal(1));
            reward.setRewardAmount(rewardAmount);
            setRewardAmount(reward);

            reward.setRewardBillCode(ZJBuzzUtils.generateOrderBillCode(TradeType.TRADE_REWARD_SALE));
            rewardList.add(reward);

            //发送MQ
            RewardMessage rewardMessage = new RewardMessage();
            rewardMessage.setReward(reward);
            rewardProducer.send(rewardMessage);
        }

        // 达人二度奖励
        LOGGER.info("达人二度奖励" + curTick);
        if (StringUtils.isNotEmpty(userRelationDto.getInviterLevelTwoUuid()) && isMasterInvester(userRelationDto.getInviterLevelTwoUuid())) {
            LOGGER.info("生成达人二度奖励" + curTick);

            Reward reward = new Reward();
            reward.setRewardCategory(RewardType.CATEGORY_MASTER_REWARD);
            reward.setBelongTopOrgPath(tradeOrder.getServiceUserOrgPath());
            reward.setBelongTopUserUuid(tradeOrder.getServiceUserUuid());
            reward.setBeInvitedMobile(userPhone);
            reward.setBeInvitedUserUuid(tradeOrder.getUserUuid());
            reward.setBeInvitedInvestTime(tradeOrder.getPayedTime());
            // 设置用户UUID
            LOGGER.info("生成达人二度奖励 设置用户UUID " + curTick);
            reward.setUserUuid(userRelationDto.getInviterLevelTwoUuid());

            // 设置产品相关信息
            LOGGER.info("生成达人二度奖励 设置产品相关信息 " + curTick);
            setProductInfo(reward, productFTDto);

            // 设置订单相关信息
            // 基于邀请奖励金额计算
            LOGGER.info("生成达人二度奖励 reward.setOrderBillCode " + curTick);
            reward.setOrderBillCode(tradeOrder.getOrderBillCode());
            LOGGER.info("生成达人二度奖励 setRewardBaseInfo " + curTick);
            setRewardBaseInfo(reward, RewardType.REWARD_MASTER_INVITER_LEVEL_TWO, tradeOrder.getOrderAmount(), createTime);
            LOGGER.info("生成达人二度奖励 reward.setBaseAmount " + curTick);
            reward.setBaseAmount(reward.getInvestAmount());

            // 奖励比例
            LOGGER.info("生成达人二度奖励 factorLevelOne.multiply " + curTick);
            BigDecimal factor = masterFactorLevelTwo.multiply(saleFactor).setScale(6, BigDecimal.ROUND_HALF_UP);
            LOGGER.info("奖励比例={}", factor);
            reward.setRewardFactor(factor);

            // 奖励金额
            LOGGER.info("生成达人二度奖励 calculateReward4Fixed " + curTick);
            BigDecimal rewardAmount = calculateReward4Fixed(reward, saleFactor, masterFactorLevelTwo);
            reward.setRewardAmount(rewardAmount);
            LOGGER.info("生成达人二度奖励 setRewardAmount " + curTick);
            setRewardAmount(reward);

            LOGGER.info("生成达人二度奖励 reward.setRewardBillCode " + curTick);
            reward.setRewardBillCode(ZJBuzzUtils.generateOrderBillCode(TradeType.TRADE_REWARD_INVITER_ONE));
            LOGGER.info("生成达人二度奖励 rewardList.add " + curTick);
            rewardList.add(reward);

            //发送MQ
            RewardMessage rewardMessage = new RewardMessage();
            rewardMessage.setReward(reward);
            rewardProducer.send(rewardMessage);
        }

        // 生成达人三度奖励
        LOGGER.info("达人三度奖励" + curTick);
        if (StringUtils.isNotEmpty(userRelationDto.getInviterLevelThreeUuid()) && isMasterInvester(userRelationDto.getInviterLevelThreeUuid())) {
            LOGGER.info("生成达人三度奖励");

            Reward reward = new Reward();
            reward.setRewardCategory(RewardType.CATEGORY_MASTER_REWARD);
            reward.setBelongTopOrgPath(tradeOrder.getServiceUserOrgPath());
            reward.setBelongTopUserUuid(tradeOrder.getServiceUserUuid());
            reward.setBeInvitedMobile(userPhone);
            reward.setBeInvitedUserUuid(tradeOrder.getUserUuid());
            reward.setBeInvitedInvestTime(tradeOrder.getPayedTime());
            // 设置用户UUID
            reward.setUserUuid(userRelationDto.getInviterLevelThreeUuid());

            // 设置产品相关信息
            setProductInfo(reward, productFTDto);

            // 设置订单相关信息
            // 基于邀请奖励金额计算
            reward.setOrderBillCode(tradeOrder.getOrderBillCode());
            setRewardBaseInfo(reward, RewardType.REWARD_MASTER_INVITER_LEVEL_THREE, tradeOrder.getOrderAmount(), createTime);
            reward.setBaseAmount(reward.getInvestAmount());

            // 奖励比例
            BigDecimal factor = masterFactorLevelThree.multiply(saleFactor).setScale(6, BigDecimal.ROUND_HALF_UP);
            LOGGER.info("达人奖励比例={}", factor);
            reward.setRewardFactor(factor);

            // 奖励金额
            BigDecimal rewardAmount = calculateReward4Fixed(reward, saleFactor, masterFactorLevelThree);
            reward.setRewardAmount(rewardAmount);
            setRewardAmount(reward);

            reward.setRewardBillCode(ZJBuzzUtils.generateOrderBillCode(TradeType.TRADE_REWARD_INVITER_TWO));
            rewardList.add(reward);

            //发送MQ
            RewardMessage rewardMessage = new RewardMessage();
            rewardMessage.setReward(reward);
            rewardProducer.send(rewardMessage);
        }

        return true;
    }

    /**
     * 创建私募基金奖励
     *
     * @param rewardList
     * @param userRelationDto
     * @param productFTDto
     * @param rewardDtoList
     * @param tradeOrder
     * @param isBookMyself
     * @return
     * @throws BusinessException
     */
    private boolean createReward4Private(List<Reward> rewardList, UserRelationDto userRelationDto, ProductFTDto productFTDto,
                                         List<ProductRewardDto> rewardDtoList, TradePrivateFundOrder tradeOrder,
                                         boolean isBookMyself) throws BusinessException {
        // 创建时间
        Date createTime = new Date();

        // 计算奖励比例
        BigDecimal factor = getRewardFactor(rewardDtoList, tradeOrder.getPurchaseAmount());
        if (null == factor) {
            LOGGER.error("没有找到匹配的奖励比例：{}", tradeOrder.getPurchaseAmount());
            return false;
        }
        factor = factor.setScale(6, BigDecimal.ROUND_HALF_UP);

        String inviterLevelOneUuid = null;
        String inviterLevelTwoUuid = null;
        String inviterLevelThreeUuid = null;

        // 判断奖励发放给谁
        if (isBookMyself) {
            LOGGER.info("理财师给自己做预约");
            // 理财师给自己做预约，邀请奖励发给理财师的直接上级
            inviterLevelOneUuid = userRelationDto.getInviterLevelOneUuid();
            inviterLevelTwoUuid = userRelationDto.getInviterLevelTwoUuid();
            inviterLevelThreeUuid = userRelationDto.getInviterLevelThreeUuid();
        } else {
            LOGGER.info("理财师给别人做预约");
            // 理财师给别人做预约，邀请奖励发给理财师
            inviterLevelOneUuid = tradeOrder.getInvestorUserUuid();
            inviterLevelTwoUuid = userRelationDto.getInviterLevelOneUuid();
            inviterLevelThreeUuid = userRelationDto.getInviterLevelTwoUuid();
        }

        // 邀请奖励
        if (StringUtils.isNotEmpty(inviterLevelOneUuid)) {
            LOGGER.info("生成邀请奖励");

            Reward reward = new Reward();
            reward.setRewardCategory(RewardType.CATEGORY_OTHER);
            reward.setBelongTopOrgPath(tradeOrder.getServiceUserOrgPath());
            reward.setBelongTopUserUuid(tradeOrder.getServiceUserUuid());
            reward.setBeInvitedMobile(tradeOrder.getInvestorUserMobile());
            reward.setBeInvitedUserUuid(tradeOrder.getInvestorUserUuid());
            reward.setBeInvitedInvestTime(tradeOrder.getCreateTime());
            // 设置用户UUID
            LOGGER.info("奖励人={}", inviterLevelOneUuid);
            reward.setUserUuid(inviterLevelOneUuid);

            // 设置产品相关信息
            setProductInfo(reward, productFTDto);

            // 设置订单相关信息
            // 基于订单金额计算（营销款也计算在内）
            reward.setOrderBillCode(tradeOrder.getPfoCode());
            setRewardBaseInfo(reward, RewardType.REWARD_SALE, tradeOrder.getPurchaseAmount(), createTime);

            // 奖励比例
            reward.setRewardFactor(factor);

            // 奖励金额
            BigDecimal rewardAmount = reward.getBaseAmount().multiply(factor).setScale(BizConstant.CASH_FRACTION_COUNT,
                    BigDecimal.ROUND_DOWN);
            reward.setRewardAmount(rewardAmount);
            setRewardAmount(reward);

            // 添加到列表
            setRewardCode(reward, TradeType.TRADE_REWARD_SALE);
            rewardList.add(reward);

            //发送MQ
            RewardMessage rewardMessage = new RewardMessage();
            rewardMessage.setReward(reward);
            rewardProducer.send(rewardMessage);
        }

        // 一度邀请津贴
        if (StringUtils.isNotEmpty(inviterLevelTwoUuid)) {
            LOGGER.info("生成一度邀请津贴");
            Reward reward = new Reward();

            reward.setRewardCategory(RewardType.CATEGORY_OTHER);
            reward.setBelongTopOrgPath(tradeOrder.getServiceUserOrgPath());
            reward.setBelongTopUserUuid(tradeOrder.getServiceUserUuid());
            reward.setBeInvitedMobile(tradeOrder.getInvestorUserMobile());
            reward.setBeInvitedUserUuid(tradeOrder.getInvestorUserUuid());
            reward.setBeInvitedInvestTime(tradeOrder.getCreateTime());
            // 设置用户UUID
            LOGGER.info("奖励人={}", inviterLevelTwoUuid);
            reward.setUserUuid(inviterLevelTwoUuid);

            // 设置产品相关信息
            setProductInfo(reward, productFTDto);

            // 设置订单相关信息
            // 基于邀请奖励金额计算
            reward.setOrderBillCode(tradeOrder.getPfoCode());
            setRewardBaseInfo(reward, RewardType.REWARD_INVITER_LEVEL_ONE, tradeOrder.getPurchaseAmount(), createTime);

            // 奖励基数
            reward.setBaseAmount(reward.getInvestAmount());

            // 奖励比例
            BigDecimal factor1 = factorLevelOne.multiply(factor).setScale(6, BigDecimal.ROUND_HALF_UP);
            reward.setRewardFactor(factor1);

            // 奖励金额
            BigDecimal rewardAmount = reward.getBaseAmount().multiply(factor).multiply(factorLevelOne).
                    setScale(BizConstant.CASH_FRACTION_COUNT, BigDecimal.ROUND_DOWN);
            reward.setRewardAmount(rewardAmount);
            setRewardAmount(reward);

            // 添加到列表
            setRewardCode(reward, TradeType.TRADE_REWARD_INVITER_ONE);
            rewardList.add(reward);

            //发送MQ
            RewardMessage rewardMessage = new RewardMessage();
            rewardMessage.setReward(reward);
            rewardProducer.send(rewardMessage);
        }

        // 二度邀请津贴
        if (StringUtils.isNotEmpty(inviterLevelThreeUuid)) {
            LOGGER.info("生成二度邀请津贴");

            Reward reward = new Reward();

            reward.setRewardCategory(RewardType.CATEGORY_OTHER);
            reward.setBelongTopOrgPath(tradeOrder.getServiceUserOrgPath());
            reward.setBelongTopUserUuid(tradeOrder.getServiceUserUuid());
            reward.setBeInvitedMobile(tradeOrder.getInvestorUserMobile());
            reward.setBeInvitedUserUuid(tradeOrder.getInvestorUserUuid());
            reward.setBeInvitedInvestTime(tradeOrder.getCreateTime());
            // 设置用户UUID
            LOGGER.info("奖励人={}", inviterLevelThreeUuid);
            reward.setUserUuid(inviterLevelThreeUuid);

            // 设置产品相关信息
            setProductInfo(reward, productFTDto);

            // 设置订单相关信息
            // 基于邀请奖励金额计算
            reward.setOrderBillCode(tradeOrder.getPfoCode());
            setRewardBaseInfo(reward, RewardType.REWARD_INVITER_LEVEL_TWO, tradeOrder.getPurchaseAmount(), createTime);

            // 奖励基数
            reward.setBaseAmount(reward.getInvestAmount());

            // 奖励比例
            BigDecimal factor2 = factorLevelTwo.multiply(factor).setScale(6, BigDecimal.ROUND_HALF_UP);
            reward.setRewardFactor(factor2);

            // 奖励金额
            BigDecimal rewardAmount = reward.getBaseAmount().multiply(factor).multiply(factorLevelTwo).
                    setScale(BizConstant.CASH_FRACTION_COUNT, BigDecimal.ROUND_DOWN);
            reward.setRewardAmount(rewardAmount);
            setRewardAmount(reward);

            // 添加到列表
            setRewardCode(reward, TradeType.TRADE_REWARD_INVITER_TWO);
            rewardList.add(reward);

            //发送MQ
            RewardMessage rewardMessage = new RewardMessage();
            rewardMessage.setReward(reward);
            rewardProducer.send(rewardMessage);
        }

        // 检查是否有服务津贴
        boolean isServiceAward = false;
        if(null != tradeOrder.getServiceUserType() && tradeOrder.getServiceUserType() == 1) {
            // 只有处理人是专职理财师才有可能产生服务津贴
            // 专职理财师UUID
            LOGGER.info("处理人类型是专职理财师");
            String serviceUserUuid = tradeOrder.getServiceUserUuid();
            if (StringUtils.isNotEmpty(serviceUserUuid)) {
                LOGGER.info("处理人用户Uuid={}", serviceUserUuid);
                if(isBookMyself) {
                    // 如果理财师给自己预约的，那么上级理财师是邀请奖励获得人，从理财师上级往上找三级
                    LOGGER.info("理财师给自己预约的，从理财师上级开始找三级");
                    String levelOneUuid = userRelationDto.getInviterLevelOneUuid();
                    if (StringUtils.isNotEmpty(levelOneUuid) && levelOneUuid.equalsIgnoreCase(serviceUserUuid)) {
                        LOGGER.info("上一级好友是处理人");
                        isServiceAward = true;
                    }

                    String levelTwoUuid = userRelationDto.getInviterLevelTwoUuid();
                    if (StringUtils.isNotEmpty(levelTwoUuid) && levelTwoUuid.equalsIgnoreCase(serviceUserUuid)) {
                        LOGGER.info("上二级好友是处理人");
                        isServiceAward = true;
                    }

                    String levelThreeUuid = userRelationDto.getInviterLevelThreeUuid();
                    if (StringUtils.isNotEmpty(levelThreeUuid) && levelThreeUuid.equalsIgnoreCase(serviceUserUuid)) {
                        LOGGER.info("上三级好友是处理人");
                        isServiceAward = true;
                    }
                } else {
                    // 如果理财师给别人预约的，那么理财师是邀请奖励获得人，从理财师往上找三级
                    LOGGER.info("理财师给别人预约的，从理财师开始找三级");
                    String userUuid = tradeOrder.getInvestorUserUuid();
                    if (StringUtils.isNotEmpty(userUuid) && userUuid.equalsIgnoreCase(serviceUserUuid)) {
                        LOGGER.info("自己是处理人");
                        isServiceAward = true;
                    }

                    String levelOneUuid = userRelationDto.getInviterLevelOneUuid();
                    if (StringUtils.isNotEmpty(levelOneUuid) && levelOneUuid.equalsIgnoreCase(serviceUserUuid)) {
                        LOGGER.info("上一级好友是处理人");
                        isServiceAward = true;
                    }

                    String levelTwoUuid = userRelationDto.getInviterLevelTwoUuid();
                    if (StringUtils.isNotEmpty(levelTwoUuid) && levelTwoUuid.equalsIgnoreCase(serviceUserUuid)) {
                        LOGGER.info("上二级好友是处理人");
                        isServiceAward = true;
                    }
                }
            } else {
                LOGGER.error("serviceUserUuid is null: {}", tradeOrder.getPfoCode());
            }

            // 记录服务津贴
            // 不要服务津贴
            isServiceAward = false;
            if (isServiceAward) {
                LOGGER.info("生成服务津贴");
                Reward reward = new Reward();

                reward.setBelongTopOrgPath(tradeOrder.getServiceUserOrgPath());
                reward.setBelongTopUserUuid(tradeOrder.getServiceUserUuid());
                reward.setBeInvitedMobile(tradeOrder.getInvestorUserMobile());
                reward.setBeInvitedUserUuid(tradeOrder.getInvestorUserUuid());
                reward.setBeInvitedInvestTime(tradeOrder.getCreateTime());

                // 设置用户UUID
                LOGGER.info("奖励人={}", serviceUserUuid);
                reward.setUserUuid(serviceUserUuid);

                // 设置产品相关信息
                setProductInfo(reward, productFTDto);

                // 设置订单相关信息
                // 基于订单金额计算（营销款也计算在内）
                reward.setOrderBillCode(tradeOrder.getPfoCode());
                setRewardBaseInfo(reward, RewardType.REWARD_SERVICE, tradeOrder.getPurchaseAmount(), createTime);

                // 奖励比例
                reward.setRewardFactor(factorService);
                // 奖励金额
                BigDecimal rewardAmount = reward.getBaseAmount().multiply(factorService).
                        setScale(BizConstant.CASH_FRACTION_COUNT, BigDecimal.ROUND_DOWN);
                reward.setRewardAmount(rewardAmount);
                setRewardAmount(reward);

                // 添加到列表
                setRewardCode(reward, TradeType.TRADE_REWARD_SERVICE);
                rewardList.add(reward);

                //发送MQ
                RewardMessage rewardMessage = new RewardMessage();
                rewardMessage.setReward(reward);
                rewardProducer.send(rewardMessage);

            }
        }

        return true;
    }

    /**
     * 计算定期奖励金额
     * 奖励比例为年化比例
     *
     * @param reward
     * @param factor
     * @param extra
     * @return
     */
    private BigDecimal calculateReward4Fixed(Reward reward, BigDecimal factor, BigDecimal extra) {
        BigDecimal baseAmount = reward.getBaseAmount();
        BigDecimal periodAmount = new BigDecimal(reward.getProductPeriod());
        BigDecimal rewardAmount = new BigDecimal(0);
        BigDecimal temp = baseAmount.multiply(periodAmount).multiply(factor).multiply(extra);
        if (reward.getProductPeriodType().equalsIgnoreCase(ProductPeriodType.DAY)) {
            rewardAmount = temp.divide(DAY_OF_YEAR, BizConstant.CASH_FRACTION_COUNT, BigDecimal.ROUND_DOWN);
        } else if (reward.getProductPeriodType().equalsIgnoreCase(ProductPeriodType.MONTH)) {
            rewardAmount = temp.divide(MONTH_OF_YEAR, BizConstant.CASH_FRACTION_COUNT, BigDecimal.ROUND_DOWN);
        } else if (reward.getProductPeriodType().equalsIgnoreCase(ProductPeriodType.YEAR)) {
            rewardAmount = temp.setScale(BizConstant.CASH_FRACTION_COUNT, BigDecimal.ROUND_DOWN);
        } else {
            LOGGER.error("未知的产品周期类型：{}", reward.getProductPeriodType());
        }

        LOGGER.info("baseAmount={}", baseAmount);
        LOGGER.info("temp={}", temp);
        LOGGER.info("rewardAmount={}", rewardAmount);
        return rewardAmount;
    }

    /**
     * 保存奖励记录
     *
     * @param rewardList 奖励记录列表
     */
    private boolean saveReward(List<Reward> rewardList) throws BusinessException {
        // 检查是否有需要持久化的奖励记录
        if (rewardList.size() == 0) {
            LOGGER.info("没有需要持久化的奖励记录");
            return false;
        }

        // 生成获取用户信息的字符串
        String userUuidList = getUserListString(rewardList);

        // 根据UUID查询用户信息
        String url = URL.URL_USER_GET_INVESTOR;
        Map<String, Object> investorParam = new HashMap<>();
        investorParam.put("userUuids", userUuidList);
        ResponseResult responseResult = userServiceConsumer.get(url, investorParam);
        if (!responseResult.isSuccessful()) {
            LOGGER.error("查询用户信息失败：{}", responseResult.getMsg());
            return false;
        }
        List<InvestorDto> investorDtoList = userServiceConsumer.getDataArray(responseResult, InvestorDto.class);

        Map<String, InvestorDto> investorMap = new HashMap<>();
        for(InvestorDto investorDto : investorDtoList) {
            investorMap.put(investorDto.getUserUuid(), investorDto);
        }

        // 写入奖励记录
        for (Reward reward : rewardList) {
            String userUUID = reward.getUserUuid();
            if (!investorMap.containsKey(userUUID)) {
                LOGGER.warn("没有用户信息：{}", userUUID);
                continue;
            }

            // 补充投资人信息
            InvestorDto investorDto = investorMap.get(userUUID);
            reward.setUserUuid(investorDto.getUserUuid());
            reward.setInvestorType(investorDto.getInvestorType());
            reward.setUserMobile(investorDto.getInvestorMobile());
            reward.setUserRealName(investorDto.getInvestorRealName());
            reward.setUserIdCardNo(investorDto.getInvestorIdCardNo());
            reward.setUserAddress(investorDto.getUserAddress());

            // 补充认证时间与是否有效
            if(AmountUtils.exac(reward.getRewardAmount()) > 0) {
                reward.setIsEnabledReward(1);
            }
//            if (investorDto.getInvestorType() == InvestorType.FULL_TIME) {
//                // 专职理财师一定是有效的
//                LOGGER.info("专职理财师");
//                reward.setIsEnabledReward(1);
//                reward.setUserAuthTime(investorDto.getRegisterTime());
//            } else if (investorDto.getInvestorType() == InvestorType.FINANCIAL_PLANNER) {
//                LOGGER.info("认证理财师");
//                reward.setIsEnabledReward(1);
//                // 查询明细，获取用户认证时间
//                Map<String, Object> userAuthParam = new HashMap<>();
//                url = String.format(URL.URL_USER_AUTH_GET, userUUID);
//                responseResult = userServiceConsumer.get(url, userAuthParam);
//                List<UserAuthDto> userAuthDtoList = userServiceConsumer.getDataArray(responseResult, UserAuthDto.class);
//                for (UserAuthDto userAuthDto : userAuthDtoList) {
//                    if (userAuthDto.getUserCertificationType() == UserCertificationType.FINANCIAL_PLANNER &&
//                            userAuthDto.getUserCertificationStatus() == 1) {
//                        reward.setUserAuthTime(userAuthDto.getCreateTime());
//                        break;
//                    }
//                }
//            } else {
//                LOGGER.info("普通投资人");
//                reward.setIsEnabledReward(0);
//            }

            rewardMapper.insert(reward);

            LOGGER.info("save reward: {}", reward.toString());
        }

        return true;
    }

    /**
     * 生成获取用户信息的字符串
     *
     * @param rewardList
     * @return
     */
    private String getUserListString(List<Reward> rewardList) {
        StringBuffer userBuffer = new StringBuffer();
        for (Reward reward : rewardList) {
            if (userBuffer.length() == 0) {
                userBuffer.append(reward.getUserUuid());
            } else {
                userBuffer.append(Separator.DATA);
                userBuffer.append(reward.getUserUuid());
            }
        }

        return userBuffer.toString();
    }

    /**
     * 设置奖励单编码
     *
     * @param reward
     * @param type
     */
    private void setRewardCode(Reward reward, String type) {
        reward.setRewardBillCode(ZJBuzzUtils.generateOrderBillCode(type));
    }

    /**
     * 设置奖励基本信息
     *
     * @param reward 奖励实体对象
     * @param type 奖励类型
     * @param amount 奖励金额
     * @param createTime 奖励生成时间
     */
    private void setRewardBaseInfo(Reward reward, int type, BigDecimal amount, Date createTime) {
        reward.setRewardType(type);
        reward.setRewardStatus(RewardStatus.INIT);
        reward.setCreateTime(createTime);
        reward.setInvestAmount(amount);
        reward.setBaseAmount(amount);
        reward.setUserAuthTime(null);
        reward.setIsEnabledReward(0);
    }

    /**
     * 设置奖励金额（前提已经设置好奖励基数和奖励比例）
     *
     * @param reward
     */
    private void setRewardAmount(Reward reward) {
        BigDecimal rewardAmount = reward.getRewardAmount();
        rewardAmount = rewardAmount.setScale(BizConstant.CASH_FRACTION_COUNT, BigDecimal.ROUND_DOWN);
        LOGGER.info("奖励金额={}", rewardAmount);
        reward.setRewardAmount(rewardAmount);
    }

    /**
     * 设置产品相关信息
     *
     * @param reward
     * @param productFTDto
     */
    private void setProductInfo(Reward reward, ProductFTDto productFTDto) {
        reward.setProductUuid(productFTDto.getProductUuid());
        reward.setProductCode(productFTDto.getProductCode());
        reward.setProductType(productFTDto.getProductType());
        reward.setProductName(productFTDto.getProductName());
        reward.setProductAbbrName(productFTDto.getProductAbbrName());
        reward.setProductPeriod(productFTDto.getProductPeriod());
        reward.setProductPeriodType(productFTDto.getProductPeriodType());
    }

    /**
     * 检查奖励佣金设置是否合法
     *
     * @param rewardDtoList
     * @return
     */
    private boolean checkRewardSetting(List<ProductRewardDto> rewardDtoList) {
        // 检查奖励设置是否合法
        if (rewardDtoList.size() == 1) {
            // 只有一条记录的情况
            ProductRewardDto productReward = rewardDtoList.get(0);

            // 奖励系数不能为空
            if (null == productReward.getPercent()) {
                LOGGER.error("wrong reward setting: {}", productReward.toString());
                return false;
            }

            // 最小和最大金额不能同时为空
            Integer minAmount = productReward.getMinAmount();
            Integer maxAmount = productReward.getMaxAmount();
            if (null == minAmount && null == maxAmount) {
                LOGGER.error("wrong reward setting: {}", productReward.toString());
                return false;
            }

            int min = 0;
            if (null != minAmount) {
                min = minAmount.intValue();
            }

            int max = Integer.MAX_VALUE;
            if (null != maxAmount) {
                max = maxAmount.intValue();
            }

            // 最大金额必须大于最小金额
            if (max <= min) {
                LOGGER.error("wrong reward setting: {}", productReward.toString());
                return false;
            }

            return true;
        } else {
            // 多余一条记录的情况
            int lastMax = 0;
            for(int i=0; i<rewardDtoList.size(); i++) {
                ProductRewardDto productReward = rewardDtoList.get(i);

                // 奖励系数不能为空
                if (null == productReward.getPercent()) {
                    LOGGER.error("wrong reward setting: {}", productReward.toString());
                    return false;
                }

                // [100,200) 前闭后开区间
                Integer minAmount = productReward.getMinAmount();
                Integer maxAmount = productReward.getMaxAmount();

                if (i == 0) {
                    // 最小金额可空，默认为0
                    int min = 0;
                    if (null != minAmount) {
                        min = minAmount.intValue();
                    }

                    // 最大金额不能为空
                    int max = Integer.MAX_VALUE;
                    if (null == maxAmount) {
                        LOGGER.error("wrong reward setting: {}", productReward.toString());
                        return false;
                    } else {
                        max = maxAmount.intValue();
                    }

                    // 保存上一条的最大值
                    lastMax = max;
                } else if (i == rewardDtoList.size() - 1) {
                    // 最小金额不能为空
                    int min = 0;
                    if (null == minAmount) {
                        LOGGER.error("wrong reward setting: {}", productReward.toString());
                        return false;
                    } else {
                        min = minAmount.intValue();
                    }

                    // 最小金额等于上一条的最大金额
                    if (min != lastMax) {
                        LOGGER.error("wrong reward setting: {}", productReward.toString());
                        return false;
                    }
                } else {
                    // 最小金额不能为空
                    int min = 0;
                    if (null == minAmount) {
                        LOGGER.error("wrong reward setting: {}", productReward.toString());
                        return false;
                    } else {
                        min = minAmount.intValue();
                    }

                    // 最大金额不能为空
                    int max = Integer.MAX_VALUE;
                    if (null == maxAmount) {
                        LOGGER.error("wrong reward setting: {}", productReward.toString());
                        return false;
                    } else {
                        max = maxAmount.intValue();
                    }

                    if (min != lastMax) {
                        LOGGER.error("wrong reward setting: {}", productReward.toString());
                        return false;
                    }

                    // 保存上一条的最大值
                    lastMax = max;
                }
            }

            return true;
        }
    }

    /**
     * 获取奖励系数
     *
     * @param investAmount
     * @return
     */
    private BigDecimal getRewardFactor(List<ProductRewardDto> rewardDtoList, BigDecimal investAmount) {
        for(ProductRewardDto rewardDto : rewardDtoList) {
            int min = 0;
            if (null != rewardDto.getMinAmount()) {
                min = rewardDto.getMinAmount().intValue();
            }

            int max = Integer.MAX_VALUE;
            if (null != rewardDto.getMaxAmount()) {
                max = rewardDto.getMaxAmount().intValue();
            }

            int amount = investAmount.intValue();
            if (amount >= min && amount < max) {
                return new BigDecimal(rewardDto.getPercent());
            }
        }

        return null;
    }


    @Override
    public void afterPropertiesSet() throws Exception {
        RewardConfigVO configVO = new RewardConfigVO();
        configVO.setActiveTime(rewardActiveTimeConfig);
        configVO.setPeriod(rewardPeriodConfig);
        configVO.setPeriodUnit(rewardPeriodUnitConfig);
        setConfig(configVO);
    }

    /**
     * 设置配置信息
     *
     * @param configVO
     * @return
     * @throws BusinessException
     */
    @Override
    public RewardConfigVO setConfig(RewardConfigVO configVO) throws BusinessException {
        // 合法性检查
        String activeTime = configVO.getActiveTime();
        if (Strings.isNullOrEmpty(activeTime)) {
            throw new BusinessException(400, "activeTime不能为空");
        }

        String unit = configVO.getPeriodUnit();
        if (Strings.isNullOrEmpty(unit)) {
            throw new BusinessException(400, "periodUnit不能为空");
        }

        if (!DAY.equalsIgnoreCase(unit) && !HOUR.equalsIgnoreCase(unit) && !MINUTE.equalsIgnoreCase(unit)) {
            throw new BusinessException(400, "periodUnit只能是D/H/M");
        }

        Long period = configVO.getPeriod();
        if (null == period) {
            throw new BusinessException(400, "period不能为空");
        }

        if (period <= 0) {
            throw new BusinessException(400, "period必须大于0");
        }

        // 日期格式检查
        Date expiredStartTimeDate = null;
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            expiredStartTimeDate = dateFormat.parse(activeTime);
        } catch (ParseException exception) {
            throw new BusinessException(500, exception.getMessage());
        }

        // 替换默认配置
        rewardActiveTimeConfig = configVO.getActiveTime();
        rewardPeriodConfig = configVO.getPeriod();
        rewardPeriodUnitConfig = configVO.getPeriodUnit();

        // 逻辑计算
        expiredActiveTime = expiredStartTimeDate.getTime();

        if (DAY.equalsIgnoreCase(rewardPeriodUnitConfig)) {
            // 天
            expiredPeriod = rewardPeriodConfig * 24 * 3600 * 1000;
        } else if (HOUR.equalsIgnoreCase(rewardPeriodUnitConfig)) {
            // 小时
            expiredPeriod = rewardPeriodConfig * 3600 * 1000;
        } else if (MINUTE.equalsIgnoreCase(rewardPeriodUnitConfig)) {
            // 分钟
            expiredPeriod = rewardPeriodConfig * 60 * 1000;
        }

        LOGGER.info("expiredActiveTime=[{}]", expiredActiveTime);
        LOGGER.info("expiredPeriod=[{}]", expiredPeriod);

        configVO.setExpiredActiveTime(expiredActiveTime);
        configVO.setExpiredPeriod(expiredPeriod);
        return configVO;
    }
}
