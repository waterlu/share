package cn.zjhf.kingold.trade.constant;

/**
 * 定期产品奖励结算状态
 *
 * Created by lutiehua on 2017/5/27.
 */
public interface RewardSummaryStatus {

    /**
     * 已作废
     *
     */
    int DELETE = 0;

    /**
     * 待审核
     *
     */
    int INIT = 1;

    /**
     * 待结算
     */
    int CHECKED = 2;

    /**
     * 已结算
     */
    int FINISH = 3;

    /**
     * 结算失败
     *
     */
    int FAILED = 4;

    /**
     * 结算驳回
     *
     */
    int REJECT = 5;

}
