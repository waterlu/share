package cn.zjhf.kingold.trade.persistence.mq.producer;

import cn.zjhf.kingold.rocketmq.annotation.RocketMQProducer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQProducer;
import cn.zjhf.kingold.rocketmq.base.SimpleMessage;

/**
 * Created by Xiaody on 17/7/27.
 */
@RocketMQProducer(topic = "product", tag = "expire")
public class ProductExpireProducer extends AbstractMQProducer<SimpleMessage> {
}
