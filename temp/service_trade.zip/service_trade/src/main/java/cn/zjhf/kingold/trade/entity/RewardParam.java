package cn.zjhf.kingold.trade.entity;

/**
 * @Author liuyao
 * @Description
 * @Date Created in 14:17 2017/5/31
 */

public class RewardParam {

    Integer rewardType;
    Integer rewardStatus;
    Integer rewardBillCode;
    String userUUid;
    String traceID;

    public Integer getRewardType() {
        return rewardType;
    }

    public void setRewardType(Integer rewardType) {
        this.rewardType = rewardType;
    }

    public Integer getRewardStatus() {
        return rewardStatus;
    }

    public void setRewardStatus(Integer rewardStatus) {
        this.rewardStatus = rewardStatus;
    }

    public String getUserUUid() {
        return userUUid;
    }

    public void setUserUUid(String userUUid) {
        this.userUUid = userUUid;
    }

    public Integer getRewardBillCode() {
        return rewardBillCode;
    }

    public void setRewardBillCode(Integer rewardBillCode) {
        this.rewardBillCode = rewardBillCode;
    }

    public String getTraceID() {
        return traceID;
    }

    public void setTraceID(String traceID) {
        this.traceID = traceID;
    }
}
