package cn.zjhf.kingold.trade.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class MarketCampaign implements Serializable {
    /**
     * 序号
     */
    private Integer mcId;

    /**
     * 活动名称
     */
    private String mcName;

    /**
     * 活动状态(1未开始，2进行中，3已结束)
     */
    private Byte mcStatus;

    /**
     * 是否送金币（0否 1是）
     */
    private Byte isCoin;

    /**
     * 开始时间
     */
    private Date startTime;

    /**
     * 结束时间
     */
    private Date endTime;

    /**
     * 说明
     */
    private String mcMark;

    /**
     * 场景编码(1注册,2实名,3首次绑卡,4首次充值,4首次投资,5邀请好友首次投资)
     */
    private Integer applyScene;

    /**
     * 礼券批次号(多个同时存在用$$分隔)
     */
    private String applyCashCoupon;

    /**
     * 删除标记 0未删除，1已删除
     */
    private Byte deleteFlag;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 更新用户id
     */
    private String updateUserId;

    /**
     * 触发频率，1单次触发，2多次触发
     */
    private Byte frequencyLimit;

    /**
     * 考察开始时间
     */
    private Date investigateStartTime;

    /**
     * 考察结束时间
     */
    private Date investigateEndTime;

    /**
     * 复投奖励次数
     */
    private Integer recastCount;

    /**
     * 金币场景名称
     */
    private String coinTaskName;

    /**
     * 任务送的金币数量
     */
    private Integer coinTaskAmount;

    /**
     * 任务送达人的金币数量
     */
    private Integer coinTaskDrAmount;

    /**
     * 多长时间后金币才可收取（小时）
     */
    private Integer coinTaskAfterHour;

    /**
     * 金币任务显示顺序（正序排序）
     */
    private Integer coinTaskShowOrder;

    /**
     * 每日触发最大次数
     */
    private Integer coinTaskLimit;

    /**
     * 金币场景描述
     */
    private String coinTaskMark;

    private static final long serialVersionUID = 1L;

    public Integer getMcId() {
        return mcId;
    }

    public void setMcId(Integer mcId) {
        this.mcId = mcId;
    }

    public String getMcName() {
        return mcName;
    }

    public void setMcName(String mcName) {
        this.mcName = mcName;
    }

    public Byte getMcStatus() {
        return mcStatus;
    }

    public void setMcStatus(Byte mcStatus) {
        this.mcStatus = mcStatus;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getMcMark() {
        return mcMark;
    }

    public void setMcMark(String mcMark) {
        this.mcMark = mcMark;
    }

    public Integer getApplyScene() {
        return applyScene;
    }

    public void setApplyScene(Integer applyScene) {
        this.applyScene = applyScene;
    }

    public String getApplyCashCoupon() {
        return applyCashCoupon;
    }

    public void setApplyCashCoupon(String applyCashCoupon) {
        this.applyCashCoupon = applyCashCoupon;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(String updateUserId) {
        this.updateUserId = updateUserId;
    }

    public Byte getFrequencyLimit() {
        return frequencyLimit;
    }

    public void setFrequencyLimit(Byte frequencyLimit) {
        this.frequencyLimit = frequencyLimit;
    }

    public Date getInvestigateStartTime() {
        return investigateStartTime;
    }

    public void setInvestigateStartTime(Date investigateStartTime) {
        this.investigateStartTime = investigateStartTime;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public Date getInvestigateEndTime() {
        return investigateEndTime;
    }

    public void setInvestigateEndTime(Date investigateEndTime) {
        this.investigateEndTime = investigateEndTime;
    }

    public Integer getRecastCount() {
        return recastCount;
    }

    public void setRecastCount(Integer recastCount) {
        this.recastCount = recastCount;
    }

    public Integer getCoinTaskAmount() {
        return coinTaskAmount;
    }

    public void setCoinTaskAmount(Integer coinTaskAmount) {
        this.coinTaskAmount = coinTaskAmount;
    }

    public Integer getCoinTaskDrAmount() {
        return coinTaskDrAmount;
    }

    public void setCoinTaskDrAmount(Integer coinTaskDrAmount) {
        this.coinTaskDrAmount = coinTaskDrAmount;
    }

    public Integer getCoinTaskAfterHour() {
        return coinTaskAfterHour;
    }

    public void setCoinTaskAfterHour(Integer coinTaskAfterHour) {
        this.coinTaskAfterHour = coinTaskAfterHour;
    }

    public Integer getCoinTaskShowOrder() {
        return coinTaskShowOrder;
    }

    public void setCoinTaskShowOrder(Integer coinTaskShowOrder) {
        this.coinTaskShowOrder = coinTaskShowOrder;
    }

    public Integer getCoinTaskLimit() {
        return coinTaskLimit;
    }

    public void setCoinTaskLimit(Integer coinTaskLimit) {
        this.coinTaskLimit = coinTaskLimit;
    }

    public Byte getIsCoin() {
        return isCoin;
    }

    public void setIsCoin(Byte isCoin) {
        this.isCoin = isCoin;
    }

    public String getCoinTaskName() {
        return coinTaskName;
    }

    public void setCoinTaskName(String coinTaskName) {
        this.coinTaskName = coinTaskName;
    }

    public String getCoinTaskMark() {
        return coinTaskMark;
    }

    public void setCoinTaskMark(String coinTaskMark) {
        this.coinTaskMark = coinTaskMark;
    }
}