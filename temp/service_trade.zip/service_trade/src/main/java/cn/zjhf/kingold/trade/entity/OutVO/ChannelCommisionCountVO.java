package cn.zjhf.kingold.trade.entity.OutVO;

import io.swagger.annotations.ApiModelProperty;

/**
 * Created by xiexiaojie on 2017/10/20.
 */
public class ChannelCommisionCountVO {
    @ApiModelProperty(required = true, value = "总条数")
    private Integer count;

    @ApiModelProperty(required = true, value = "总佣金")
    private double commisionAmount;

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public double getCommisionAmount() {
        return commisionAmount;
    }

    public void setCommisionAmount(double commisionAmount) {
        this.commisionAmount = commisionAmount;
    }

    @Override
    public String toString() {
        return "ChannelCommisionCountVO{" +
                "count=" + count +
                ", commisionAmount=" + commisionAmount +
                '}';
    }
}
