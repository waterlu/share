package cn.zjhf.kingold.trade.service;


import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.entity.TradeRecharge;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.Map;

/**
 * 远程获取投资人信息
 * <p>
 * Created by lutiehua on 2017/4/28.
 */
public interface IInvestorRemoteService {


    Map getInvestorInfo(String userUuid) throws BusinessException;

    boolean checkPayPassword(String userUuid, String payPassword) throws BusinessException;
}