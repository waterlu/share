package cn.zjhf.kingold.trade.persistence.dao;

import cn.zjhf.kingold.trade.entity.CouponSpecifiedDistributionRecord;
import cn.zjhf.kingold.trade.entity.CouponSpecifiedDistributionRecordItem;
import cn.zjhf.kingold.trade.entity.CouponSpecifiedDistributionRecordItemExample;
import java.util.List;

import cn.zjhf.kingold.trade.utils.QueryUtils;
import cn.zjhf.kingold.trade.utils.WhereCondition;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface CouponSpecifiedDistributionRecordItemMapper {
    long countByExample(CouponSpecifiedDistributionRecordItemExample example);

    int deleteByExample(CouponSpecifiedDistributionRecordItemExample example);

    int deleteByPrimaryKey(Long id);

    int insert(CouponSpecifiedDistributionRecordItem record);

    int insertSelective(CouponSpecifiedDistributionRecordItem record);

    @Insert("${condition}")
    int insertMultipleRecord(QueryUtils condition);

    @Select("SELECT Count(*) FROM coupon_specified_distribution_record_item ${condition}")
    int lstCountByCondition(WhereCondition condition);

    @Delete("DELETE FROM coupon_specified_distribution_record_item WHERE audit_id=#{auditId}")
    int deleteByAuditId(@Param("auditId") Long auditId);

    @Delete("DELETE FROM coupon_specified_distribution_record_item_back WHERE audit_id=#{auditId}")
    int deleteBackByAuditId(@Param("auditId") Long auditId);

    @Insert("INSERT INTO coupon_specified_distribution_record_item_back(" +
            "id, audit_id, user_uuid, phone_number, phone_name, create_time) " +
            "SELECT id, audit_id, user_uuid, phone_number, phone_name, create_time " +
            "FROM coupon_specified_distribution_record_item \n" +
            "WHERE audit_id=#{auditId}")
    int insertBackByAuditId(@Param("auditId") Long auditId);

    @Select("SELECT * FROM coupon_specified_distribution_record_item ${condition}")
    @ResultMap("BaseResultMap")
    List<CouponSpecifiedDistributionRecordItem> lstByCondition(WhereCondition condition);

    @Select("SELECT phone_number FROM coupon_specified_distribution_record_item WHERE audit_id = #{auditId}")
    List<String> lstUserPhoneByAuditId(@Param("auditId") Long auditId);

    List<CouponSpecifiedDistributionRecordItem> selectByExample(CouponSpecifiedDistributionRecordItemExample example);

    CouponSpecifiedDistributionRecordItem selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") CouponSpecifiedDistributionRecordItem record, @Param("example") CouponSpecifiedDistributionRecordItemExample example);

    int updateByExample(@Param("record") CouponSpecifiedDistributionRecordItem record, @Param("example") CouponSpecifiedDistributionRecordItemExample example);

    int updateByPrimaryKeySelective(CouponSpecifiedDistributionRecordItem record);

    int updateByPrimaryKey(CouponSpecifiedDistributionRecordItem record);
}