package cn.zjhf.kingold.trade.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.dto.AccountTransactionDto;
import cn.zjhf.kingold.trade.entity.InVO.LstChannelCommisionDetailConditionVO;
import cn.zjhf.kingold.trade.service.IAccountTransactionService;
import cn.zjhf.kingold.trade.utils.DataUtils;
import cn.zjhf.kingold.trade.utils.MapParamUtils;
import cn.zjhf.kingold.trade.utils.PropertyDescriptionUtils;
import cn.zjhf.kingold.trade.utils.RequestMapperConvert;
import cn.zjhf.kingold.trade.vo.AccountTransactionVO;
import com.alibaba.fastjson.JSON;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * Created by lu on 2017/3/13.
 */
@RestController
@RequestMapping(value = "/accounttransaction")
public class AccountTransactionController {
    protected static final Logger logger = LoggerFactory.getLogger(AccountTransactionController.class);

    @Autowired
    private IAccountTransactionService accountTransactionService;

    /**
     * 插入
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "", method = RequestMethod.POST)
    public ResponseResult recharge( @RequestBody Map userMap) throws BusinessException {
        logger.info("recharge start: " + DataUtils.toString(userMap));
        RequestMapperConvert.initParam(userMap);

        accountTransactionService.insert(userMap);

        logger.info("recharge end: " + DataUtils.toString(userMap.get("traceID")));
        return  new ResponseResult( MapParamUtils.getStringInMap( userMap,"traceID"), ResponseCode.REQUEST_SUCCESS,"成功",userMap.get("accountTransactionUuid"));
    }

    /**
     * 查找
     * @param uuid
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/{uuid}", method = RequestMethod.GET)
    public ResponseResult get(@PathVariable("uuid") String uuid,@RequestParam Map paramMap) throws BusinessException {
        logger.info("get start: " + DataUtils.toString(paramMap));
        RequestMapperConvert.initParam(paramMap);

        paramMap.put("uuid",uuid);
        Map ui = accountTransactionService.get(paramMap);

        logger.info("get end: " + DataUtils.toString(paramMap.get("traceID"), ui));
        return new ResponseResult( MapParamUtils.getStringInMap( paramMap,"traceID"),ResponseCode.REQUEST_SUCCESS,"成功", ui);
    }

    /**
     * 根据uuid 更新
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/{uuid}", method = RequestMethod.PUT)
    public ResponseResult update(@PathVariable("uuid") String uuid, @RequestBody Map userMap) throws BusinessException {
        logger.info("update start: " + DataUtils.toString(uuid, userMap));
        RequestMapperConvert.initParam(userMap);
        userMap.put("uuid",uuid);
        int num = accountTransactionService.update(userMap);

        logger.info("update end: " + DataUtils.toString(userMap.get("traceID"), num));
        return  new ResponseResult( MapParamUtils.getStringInMap( userMap,"traceID"),ResponseCode.REQUEST_SUCCESS,"成功",num);
    }

    /**
     * 交易流水列表
     *
     * @param paramMap 参数选填： accountTransactionUuid,accountUuid(多个),tradeType(多个),userUuid（多个）,accountType,transactionTimeFrom,transactionTimeTo,accountNo
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public ResponseResult getList(@RequestParam Map paramMap) throws BusinessException {
        logger.info("getList start: " + DataUtils.toString(paramMap));
        RequestMapperConvert.initParam(paramMap);
        RequestMapperConvert.initAccountTransactionParam(paramMap);

        List<Map> result = new ArrayList<>();
        List<Map> userList = accountTransactionService.getList(paramMap);
        for(Map map : userList) {
            result.add(PropertyDescriptionUtils.convertProperty(map, MapParamUtils.getStringInMap( paramMap,"properties"), MapParamUtils.getStringInMap( paramMap,"desc"),PropertyDescriptionUtils.ACCOUNT_TRANSACTION_DIC));
        }

        logger.info("getList end: " + DataUtils.toString(paramMap.get("traceID"), result));
        return new ResponseResult( MapParamUtils.getStringInMap( paramMap,"traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", result);
    }

    /**
     * 交易流水总数
     *
     * @param paramMap 参数选填： accountTransactionUuid,accountUuid(多个),tradeType(多个),userUuid（多个）,accountType,transactionTimeFrom,transactionTimeTo,accountNo
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/count", method = RequestMethod.GET)
    public ResponseResult getCount(@RequestParam Map paramMap) throws BusinessException {
        logger.info("getCount start: " + DataUtils.toString(paramMap));
        RequestMapperConvert.initParam(paramMap);
        RequestMapperConvert.initAccountTransactionParam(paramMap);

        Integer count  = accountTransactionService.getCount(paramMap);

        logger.info("getCount end: " + DataUtils.toString(paramMap.get("traceID"), count));
        return new ResponseResult( MapParamUtils.getStringInMap( paramMap,"traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", count);
    }

    /**
     * 交易流水列表（通过账户uuid和对手账户uuid账户筛选account_type）
     *
     * @param paramMap 参数选填： accountTransactionUuid,accountUuid(多个),tradeType(多个),userUuid（多个）,accountType,transactionTimeFrom,transactionTimeTo,accountNo
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/transaction/list", method = RequestMethod.GET)
    public ResponseResult getTransactionList(@RequestParam Map paramMap) throws BusinessException {
        logger.info("getTransactionList start: " + DataUtils.toString(paramMap));

        RequestMapperConvert.initParam(paramMap);
        RequestMapperConvert.initAccountTransactionParam(paramMap);

        List<Map> result = new ArrayList<>();
        List<Map> userList = accountTransactionService.getTransactionList(paramMap);
        for(Map map : userList) {
            result.add(PropertyDescriptionUtils.convertProperty(map, MapParamUtils.getStringInMap( paramMap,"properties"), MapParamUtils.getStringInMap( paramMap,"desc"),PropertyDescriptionUtils.ACCOUNT_TRANSACTION_DIC));
        }

        logger.info("getTransactionList end: " + DataUtils.toString(paramMap.get("traceID"), result));
        return new ResponseResult( MapParamUtils.getStringInMap( paramMap,"traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", result);
    }

    /**
     * 投资人资金流水列表（目前仅导出使用）
     * @param param
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/investor/transaction/list", method = RequestMethod.GET)
    public ResponseResult getInvestorTransactionList(@RequestParam Map<String, Object> param) throws BusinessException {
        logger.info("getInvestorTransactionList start {} ", param);
        String jsonString = JSON.toJSONString(param);
        AccountTransactionDto dto = JSON.parseObject(jsonString, AccountTransactionDto.class);
        List<AccountTransactionVO> list = accountTransactionService.getInvestorTransactionList(dto);
        logger.info("getInvestorTransactionList list.size {} ", list.size());
        return new ResponseResult( dto.getTraceID(), ResponseCode.REQUEST_SUCCESS, "正常调用", list);
    }

    /**
     * 交易流水总数（通过账户uuid和对手账户uuid账户筛选account_type）
     *
     * @param paramMap 参数选填： accountTransactionUuid,accountUuid(多个),tradeType(多个),userUuid（多个）,accountType,transactionTimeFrom,transactionTimeTo,accountNo
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/transaction/count", method = RequestMethod.GET)
    public ResponseResult getTransactionCount(@RequestParam Map paramMap) throws BusinessException {
        logger.info("getTransactionCount start: " + DataUtils.toString(paramMap));

        RequestMapperConvert.initParam(paramMap);
        RequestMapperConvert.initAccountTransactionParam(paramMap);
        Integer count  = accountTransactionService.getTransactionCount(paramMap);

        logger.info("getTransactionCount end: " + DataUtils.toString(paramMap.get("traceID"), count));
        return new ResponseResult( MapParamUtils.getStringInMap( paramMap,"traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", count);
    }
}
