package cn.zjhf.kingold.trade.utils;

import cn.zjhf.kingold.trade.constant.PayResponseCode;
import cn.zjhf.kingold.trade.entity.PayResponse;

import java.util.HashMap;
import java.util.Map;

/**
 * @Author liuyao
 * @Description
 * @Date Created in 10:47 2017/6/2
 */

public class BaofooResponseMappingUtil {

    private static Map<String, Integer> codeMapping = new HashMap<>();
    private static Map<String, String> msgMapping = new HashMap<>();

    public static int getPayResponseCode(String code) {
        Integer result = codeMapping.get(code);
        if (result == null) {
            return PayResponseCode.ERROR_UNKNOW_CODE;
        }
        return result;
    }

    public static String getPayResponseMsg(String code) {
        String result = msgMapping.get(code);
        if (result == null) {
            return PayResponseCode.ERROR_UNKNOW_MSG;
        }
        return result;
    }

    static {
        codeMapping.put("CSD002", PayResponseCode.ERROR_PARAMETER_CODE);
        codeMapping.put("CSD005", PayResponseCode.ERROR_USER_NOT_EXIST_CODE);
        codeMapping.put("CSD009", PayResponseCode.ERROR_USER_HAS_CANCLE_BIND_CODE);
        codeMapping.put("RQ004", PayResponseCode.ERROR_ORDER_REPEAT_CODE);
        codeMapping.put("RQ006", PayResponseCode.ERROR_PAY_AMOUNT_SUM_CODE);
        codeMapping.put("BD009", PayResponseCode.ERROR_USER_EXIST_CODE);
        codeMapping.put("CSD333", PayResponseCode.ERROR_DEAL_CODE);
        codeMapping.put("BD004", PayResponseCode.ERROR_SMS_VERIFY_CODE);
        codeMapping.put("BD001", PayResponseCode.ERROR_EXIST_ACCOUNT_BIND_CODE);
        codeMapping.put("CSD000", PayResponseCode.OK);

        msgMapping.put("CSD002", PayResponseCode.ERROR_PARAMETER_MSG);
        msgMapping.put("CSD005", PayResponseCode.ERROR_USER_NOT_EXIST_MSG);
        msgMapping.put("CSD009", PayResponseCode.ERROR_USER_HAS_CANCLE_BIND_MSG);
        msgMapping.put("RQ004", PayResponseCode.ERROR_ORDER_REPEAT_MSG);
        msgMapping.put("RQ006", PayResponseCode.ERROR_PAY_AMOUNT_SUM_MSG);
        msgMapping.put("BD009", PayResponseCode.ERROR_USER_EXIST_MSG);
        msgMapping.put("CSD333", PayResponseCode.ERROR_DEAL_MSG);
        msgMapping.put("BD004", PayResponseCode.ERROR_SMS_VERIFY_MSG);
        msgMapping.put("BD001", PayResponseCode.ERROR_EXIST_ACCOUNT_BIND_MSG);
        msgMapping.put("CSD000", PayResponseCode.OK_MSG);

    }
}
