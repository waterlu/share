package cn.zjhf.kingold.trade.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.service_consumer.service.UserServiceConsumer;
import cn.zjhf.kingold.trade.baofoo.*;
import cn.zjhf.kingold.trade.constant.PayMsg;
import cn.zjhf.kingold.trade.constant.PayResponseCode;
import cn.zjhf.kingold.trade.constant.URL;
import cn.zjhf.kingold.trade.entity.InVO.RechargeSdkVo;
import cn.zjhf.kingold.trade.entity.OutVO.BaofooPayParamVO;
import cn.zjhf.kingold.trade.persistence.mq.message.PayRechargeMessage;
import cn.zjhf.kingold.trade.persistence.mq.producer.PayRechargeTransactionProducer;
import cn.zjhf.kingold.trade.service.IPayService;
import cn.zjhf.kingold.trade.service.ITradeService;
import cn.zjhf.kingold.trade.utils.DataUtils;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.rocketmq.client.producer.LocalTransactionExecuter;
import com.alibaba.rocketmq.client.producer.LocalTransactionState;
import com.alibaba.rocketmq.common.message.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by lutiehua on 2017/4/27.
 */
@RestController
@RequestMapping(value = "/trade/baofoo")
public class BaoFooPayController {

    private final Logger LOGGER = LoggerFactory.getLogger(BaoFooPayController.class);

    @Autowired
    private SecurityUtil securityUtil;

    @Autowired
    private IPayService payService;

    @Autowired
    private UserServiceConsumer userServiceConsumer;

    @Autowired
    private ITradeService tradeService;

    @Autowired
    private PayRechargeTransactionProducer transactionMQProducer;

    @RequestMapping(value = "/orderId", method = RequestMethod.POST)
    public ResponseResult getBaofooOrderId(@RequestBody RechargeSdkVo rechargeSdkVo) throws BusinessException {
        LOGGER.info("BaoFooPayController getBaofooOrderId param. rechargeSdkVo={}", rechargeSdkVo);
        return payService.getBaofooOrderId(rechargeSdkVo.getUserId(), rechargeSdkVo.getOrderId(), rechargeSdkVo.getAmount(), rechargeSdkVo.getReturnUrl());
    }

    @RequestMapping(value = "/rechargeParam", method = RequestMethod.POST)
    public ResponseResult aesRechargePage(@RequestBody RechargeSdkVo rechargeSdkVo) throws BusinessException {
        LOGGER.info("BaoFooPayController aesRechargePage param. rechargeSdkVo={}", rechargeSdkVo);
        BaofooPayParamVO baofooPayParamVO = payService.getRechargeParam(rechargeSdkVo);
        LOGGER.info("BaoFooPayController aesRechargePage result. BaofooPayParamVO={}", baofooPayParamVO);
        return  new ResponseResult( rechargeSdkVo.getTraceID(), ResponseCode.REQUEST_SUCCESS,"成功", baofooPayParamVO);

    }

    @RequestMapping(value = "/validation")
    public ResponseResult sendVerifyCode(@RequestParam String callSystemID, @RequestParam String traceID,@RequestParam int type,
                                         @RequestParam(value="accountMobile", required = false) String accountMobile,
                                         @RequestParam(value="userID", required = false) Long userID) throws BusinessException {
        LOGGER.info("sendVerifyCode start: "
                + DataUtils.toLog("callSystemID", callSystemID)
                + DataUtils.toLog("traceID", traceID)
                + DataUtils.toLog("type", type)
                + DataUtils.toLog("accountMobile", accountMobile)
                + DataUtils.toLog("userID", userID));

        ResponseResult respResult = null;
        if (type == IPayService.SMS_BIND_BANK_CARD) {
            LOGGER.info("sendVerifyCode . userId={}, type={}", userID, type);
            respResult = payService.sendVerifyCode(userID);
        } else if (type == IPayService.SMS_BIND_PLATFORM) {
            LOGGER.info("sendVerifyCode . baofooAccountMobile={}, type={}", accountMobile, type);
            respResult = payService.sendAccountBindVerifyCode(accountMobile);
        } else {
            throw new BusinessException(PayResponseCode.ERROR_PARAMETER_CODE, PayResponseCode.ERROR_PARAMETER_MSG, false);
        }

        LOGGER.info("sendVerifyCode end: " + DataUtils.toString(traceID, respResult));
        return respResult;
    }


    /**
     * 授权回调
     *
     * @param result
     * @param sign
     * @return
     */
    @RequestMapping(value = "/notification/auth")
    public String auth(@RequestParam String result, @RequestParam String sign) {
        LOGGER.info("auth start: "
                + DataUtils.toLog("result", result)
                + DataUtils.toLog("sign", sign));

        String checkSum = securityUtil.encryptMD5(result);
        if (!checkSum.equalsIgnoreCase(sign)) {
            LOGGER.info("check sign failed!");
            return "failed!";
        }

        try {
            JSONObject jsonObject = XmlTool.xml2Json(result);
            AuthResponse authResponse = jsonObject.toJavaObject(AuthResponse.class);
            // 授权成功的用户ID
            long userID = authResponse.getUser_id();
            LOGGER.info("auth userID=" + userID);
            String traceID = UUID.randomUUID().toString();
            Map<String, Object> param = new HashMap();
            param.put("traceID", traceID);
            param.put("userId", userID);
            param.put("userVerifyStatus", 2);
            ResponseResult responseResult = userServiceConsumer.put(String.format(URL.URL_USER_AUTH_SUCCESS,userID), param);

            LOGGER.info("auth end: "
                    + DataUtils.toString(responseResult));
            if (responseResult.getCode() == ResponseCode.OK) {
                return ResponseCode.OK_TEXT;
            } else {
                return responseResult.getMsg();
            }

        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error(e.getMessage());
            return "failed!";
        }
    }



    /**
     * 充值回调
     *
     * @param result
     * @param sign
     * @return
     */
    @RequestMapping(value = "/notification/recharge")
    public ResponseResult recharge(@RequestParam String result, @RequestParam String sign) {
        LOGGER.info("notificationRecharge recharge result={}, sign={}", result, sign);
        ResponseResult responseResult = new ResponseResult();

        String checkSum = securityUtil.encryptMD5(result);
        if (!checkSum.equalsIgnoreCase(sign)) {
            LOGGER.info("check sign failed!");
            responseResult.setCode(ResponseCode.EXCEPTION);
            responseResult.setMsg("check sign failed!");
            return responseResult;
        }

        try {
            JSONObject jsonObject = XmlTool.xml2Json(result);
            RechargeResponse rechargeResponse = jsonObject.toJavaObject(RechargeResponse.class);
            if (rechargeResponse.getCode().equalsIgnoreCase(BaoFooCode.OK)) {
                String billCode = rechargeResponse.getOrder_id();
                double amount = rechargeResponse.getIncash_money();
                double fee = rechargeResponse.getFee();
                String date = rechargeResponse.getSucc_time();
                int feeTakenOn = rechargeResponse.getFee_taken_on();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
                Date time = dateFormat.parse(date);
                LOGGER.info("notificationRecharge info . code={}, billCode={}, amount={}, fee={}, feeTakenOn={}, date={}, time={}.",
                        rechargeResponse.getCode(), billCode, amount, fee, feeTakenOn, date, time);
                RechargeNotify rechargeNotify = new RechargeNotify();
                rechargeNotify.setAmount(amount);
                rechargeNotify.setBillCode(billCode);
                rechargeNotify.setFee(fee);
                rechargeNotify.setChannel(null);
                rechargeNotify.setFeeTakenOn(feeTakenOn);
                rechargeNotify.setTime(time);
                rechargeNotify.setResult(result);
                PayRechargeMessage message = new PayRechargeMessage(rechargeNotify);
                transactionMQProducer.send(message, new LocalTransactionExecuter() {
                    @Override
                    public LocalTransactionState executeLocalTransactionBranch(Message message, Object o) {
                        try {
                            // 更新支付状态
                            payService.notifyRecharge(billCode, result);
                            return LocalTransactionState.COMMIT_MESSAGE;
                        } catch (BusinessException e) {
                            LOGGER.error(e.getMessage());
                            return LocalTransactionState.ROLLBACK_MESSAGE;
                        }
                    }
                }, null);
            }
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            responseResult.setCode(ResponseCode.EXCEPTION);
            responseResult.setMsg(e.getMessage());
        }

        return responseResult;
    }


    /**
     * 获取商户信息
     *
     * @return
     */
    @RequestMapping(value = "/getPlatformInfo")
    public ResponseResult getPlatformInfo(@RequestParam String traceId) {
        return new ResponseResult(traceId, ResponseCode.REQUEST_SUCCESS, "成功", payService.getPlatformInfo());
    }

}
