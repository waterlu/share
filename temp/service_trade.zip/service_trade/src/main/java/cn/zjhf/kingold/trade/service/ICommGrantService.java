package cn.zjhf.kingold.trade.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

/**
 * Created by zhangyijie on 2018/2/1.
 */
public interface ICommGrantService {

    /**
     * 通用发放
     * @param file
     * @return
     * @throws BusinessException
     */
    Map<Integer, String> commGrant(MultipartFile file) throws BusinessException;

    /**
     * 通用发放
     * @param fileName
     * @return
     * @throws BusinessException
     */
    Map<Integer, String> commGrant(String fileName) throws BusinessException;
}
