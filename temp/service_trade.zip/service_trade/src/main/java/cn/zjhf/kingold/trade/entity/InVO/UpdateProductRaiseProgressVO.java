package cn.zjhf.kingold.trade.entity.InVO;

import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * Created by zhangyijie on 2017/5/31.
 */
@ApiModel(value = "UpdateProductRaiseProgressVO", description = "更新产品募集进度, 入参")
public class UpdateProductRaiseProgressVO extends InVOBase {
    @ApiModelProperty(required = true, value = "traceID")
    @NotEmpty
    private String traceID;

    @ApiModelProperty(required = true, value = "product_uuid")
    @NotEmpty
    private String product_uuid;

    @ApiModelProperty(required = true, value = "productType")
    @NotEmpty
    private String productType;

    @ApiModelProperty(required = true, value = "执行人，当前运营管理系统用户")
    @NotEmpty
    private String userPhone;

    @ApiModelProperty(required = true, value = "更新的募集进度金额")
    private double amount;

    /**
     * 操作人
     */
    private String createBy;

    public String getTraceID() {
        return traceID;
    }

    public void setTraceID(String traceID) {
        this.traceID = traceID;
    }

    public String getProduct_uuid() {
        return product_uuid;
    }

    public void setProduct_uuid(String product_uuid) {
        this.product_uuid = product_uuid;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(traceID) + ", ");
        sb.append("product_uuid:" + DataUtils.toString(product_uuid) + ", ");
        sb.append("productType:" + DataUtils.toString(productType) + ", ");
        sb.append("userPhone:" + DataUtils.toString(userPhone) + ", ");
        sb.append("amount:" + DataUtils.toString(amount));
        return sb.toString();
    }
}
