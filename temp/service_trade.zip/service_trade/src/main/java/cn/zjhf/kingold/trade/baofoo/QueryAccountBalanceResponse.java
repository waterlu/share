package cn.zjhf.kingold.trade.baofoo;

/**
 * @Author liuyao
 * @Description
 * @Date Created in 19:58 2017/6/1
 */

public class QueryAccountBalanceResponse extends BaoFooResponse {
    private Double balance;

    public Double getBalance() {
        return balance;
    }

    public void setBalance(Double balance) {
        this.balance = balance;
    }
}
