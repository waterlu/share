package cn.zjhf.kingold.trade.entity.InVO;

import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Size;
import java.util.Date;

/**
 * Created by zhangyijie on 2017/10/12.
 */
public class LstChannelCommisionSummaryConditionVO extends InVOBase {
    @ApiModelProperty(required = true, value = "请求周期，格式: YYYY.MM")
    @Size(min = 1, max = 10)
    private String requestCycle;

    @ApiModelProperty(required = false, value = "APP名称/渠道名称")
    @Size(min = 1, max = 30)
    private String channelAppName;

    @ApiModelProperty(required = false, value = "创建起始日期")
    private Date beginCreateDate;

    @ApiModelProperty(required = false, value = "创建截止日期")
    private Date endCreateDate;

    @ApiModelProperty(required = false, value = "结算起始日期")
    private Date beginSettleDate;

    @ApiModelProperty(required = false, value = "结算截止日期")
    private Date endSettleDate;

    @ApiModelProperty(required = true, value = "结算状态: -1审核失败；1待审核；2已结算")
    @NotEmpty
    private int settleStatus;

    @ApiModelProperty(required = true, value = "起始序号")
    private int beginSN;

    @ApiModelProperty(required = true, value = "结束序号")
    private int endSN;

    public String getChannelAppName() {
        return channelAppName;
    }

    public void setChannelAppName(String channelAppName) {
        this.channelAppName = channelAppName;
    }

    public int getSettleStatus() {
        return settleStatus;
    }

    public void setSettleStatus(int settleStatus) {
        this.settleStatus = settleStatus;
    }

    public int getBeginSN() {
        return beginSN;
    }

    public void setBeginSN(int beginSN) {
        this.beginSN = beginSN;
    }

    public int getEndSN() {
        return endSN;
    }

    public void setEndSN(int endSN) {
        this.endSN = endSN;
    }

    public String getRequestCycle() {
        return requestCycle;
    }

    public void setRequestCycle(String requestCycle) {
        this.requestCycle = requestCycle;
    }

    public Date getBeginCreateDate() {
        return beginCreateDate;
    }

    public void setBeginCreateDate(Date beginCreateDate) {
        this.beginCreateDate = beginCreateDate;
    }

    public Date getEndCreateDate() {
        return convertEndDate(endCreateDate);
    }

    public void setEndCreateDate(Date endCreateDate) {
        this.endCreateDate = endCreateDate;
    }

    public Date getBeginSettleDate() {
        return beginSettleDate;
    }

    public void setBeginSettleDate(Date beginSettleDate) {
        this.beginSettleDate = beginSettleDate;
    }

    public Date getEndSettleDate() {
        return convertEndDate(endSettleDate);
    }

    public void setEndSettleDate(Date endSettleDate) {
        this.endSettleDate = endSettleDate;
    }

    @Override
    public String toString() {
        return "LstChannelCommisionSummaryConditionVO{" +
                "requestCycle='" + requestCycle + '\'' +
                ", channelAppName='" + channelAppName + '\'' +
                ", beginCreateDate=" + beginCreateDate +
                ", endCreateDate=" + endCreateDate +
                ", beginSettleDate=" + beginSettleDate +
                ", endSettleDate=" + endSettleDate +
                ", settleStatus=" + settleStatus +
                ", beginSN=" + beginSN +
                ", endSN=" + endSN +
                '}';
    }
}
