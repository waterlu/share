package cn.zjhf.kingold.trade.constant;

/**
 * Created by lutiehua on 2017/6/2.
 */
public interface RewardError {

    String CLEAR_FINISH_TXT = "以下结算单执行结算操作成功：";

    String CLEAR_FAILED_TXT = "以下结算单执行结算操作失败：";

    String CHECK_FINISH_TXT = "以下结算单执行审核操作成功：";

    String CHECK_FAILED_TXT = "以下结算单执行审核操作失败：";

    String CLEAR_REJECT_TXT = "以下结算单被结算驳回：";



    int FOUND_INIT_REWARD = 6201;

    String FOUND_INIT_REWARD_TXT = "以下奖励单的状态为已生成，不能结算：";

    int COLLIDED_PERIOD = 6202;

    String COLLIDED_PERIOD_TXT = "存在用户结算周期重叠的情况：";

    int ACCOUNT_BALANCE = 6203;

    String ACCOUNT_BALANCE_TXT = "平台基本户余额不足，请先充值";

    int CLEAR_FAILED = 6204;

    String ACCOUNT_FAILED_TXT = "以下用户还没有开通结算账户：";

    int EMPTY_DATA = 6205;

    String EMPTY_DATA_TXT = "时间周期内没有有效的待结算奖励记录！";

    int COLLIDED_REWARD = 6206;

    String COLLIDED_REWARD_TXT = "存在奖励记录重复申请结算的情况：";

    int ZERO_ROW = 6207;

    String ZERO_ROW_TXT = "SQL语句影响记录条数为零";
}
