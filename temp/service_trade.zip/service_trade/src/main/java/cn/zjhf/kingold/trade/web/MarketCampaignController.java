package cn.zjhf.kingold.trade.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.dto.MarketCampaignDto;
import cn.zjhf.kingold.trade.entity.InVO.MarketCampaignVO;
import cn.zjhf.kingold.trade.entity.OutVO.MarketCampaignItemListVO;
import cn.zjhf.kingold.trade.service.IMarketCampaignService;
import cn.zjhf.kingold.trade.utils.DataUtils;
import com.alibaba.fastjson.JSON;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * 场景相关操作
 * @author guoxiaoming
 * @date 2018/1/9
 */
@RestController
@RequestMapping(value = "/market")
public class MarketCampaignController {

    protected static final Logger logger = LoggerFactory.getLogger(MarketCampaignController.class);

    @Autowired
    IMarketCampaignService marketCampaignService;

    /**
     * 金币活动场景列表查询
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/coin/getMarketCampaignList", method = RequestMethod.GET)
    public ResponseResult getMarketCampaignList(@RequestParam Map<String, Object> param) throws BusinessException {
        String jsonString = JSON.toJSONString(param);
        MarketCampaignDto marketCampaignDto = JSON.parseObject(jsonString, MarketCampaignDto.class);
        logger.info("getMarketCampaignList start:{} ", DataUtils.toString(marketCampaignDto));
        if (marketCampaignDto.getPageSize() == null){
            marketCampaignDto.setPageSize(20);
        }
        if (marketCampaignDto.getPageNo() == null){
            marketCampaignDto.setStartRow(0);
        }else{
            marketCampaignDto.setStartRow((marketCampaignDto.getPageNo() - 1) * marketCampaignDto.getPageSize());
        }
        if (marketCampaignDto.getMcStatus() == null){
            marketCampaignDto.setMcStatus(2);
        }
        if (marketCampaignDto.getIsCoin() == null){
            marketCampaignDto.setIsCoin(1);
        }
        MarketCampaignItemListVO itemList = marketCampaignService.getMarketCampaignList(marketCampaignDto);

        logger.info("getMarketCampaignList end:{}", DataUtils.toString(marketCampaignDto.getTraceID(), itemList));
        return createOKRespResult(marketCampaignDto.getTraceID(), itemList);
    }

    /**
     * 根据mc_id获取场景
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/getMarketCampaign", method = RequestMethod.GET)
    public ResponseResult getMarketCampaign(@RequestParam Map<String, Object> param) throws BusinessException {
        logger.info("getMarketCampaign start:");
        String jsonString = JSON.toJSONString(param);
        MarketCampaignDto marketCampaignDto = JSON.parseObject(jsonString, MarketCampaignDto.class);
        if (marketCampaignDto.getMcId() == null){
            return createErrorRespResult(marketCampaignDto.getTraceID(), "mcId");
        }
        MarketCampaignVO marketCampaignVO = marketCampaignService.lstMarketCampaign(marketCampaignDto.getMcId());
        logger.info("getMarketCampaign end:{}", DataUtils.toString(marketCampaignDto.getTraceID(), marketCampaignVO));
        return createOKRespResult(marketCampaignDto.getTraceID(), marketCampaignVO);
    }

    private ResponseResult createOKRespResult(String traceID, Object data) {
        ResponseResult respResult = new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS,ResponseCode.OK_TEXT, data);
        return respResult;
    }

    /**
     * 参数错误返回
     * @param traceID
     * @param data
     * @return
     */
    private ResponseResult createErrorRespResult(String traceID, Object data) {
        ResponseResult respResult = new ResponseResult(traceID, ResponseCode.PARAM_ERROR, ResponseCode.PARAM_ERROR_TEXT, data);
        return respResult;
    }
}
