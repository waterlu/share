package cn.zjhf.kingold.trade.exception;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.constant.TradeStatusMsg;

/**
 * 产品状态异常
 *
 * @author lutiehua
 * @date 2018/3/9
 */
public class ProductStatusException extends BusinessException {

    public ProductStatusException() {
        super(TradeStatusMsg.PRODUCT_STATUS_WRONG_CODE, TradeStatusMsg.PRODUCT_STATUS_WRONG_MSG, true);
    }
}
