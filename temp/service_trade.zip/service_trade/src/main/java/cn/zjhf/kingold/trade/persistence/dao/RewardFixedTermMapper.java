package cn.zjhf.kingold.trade.persistence.dao;

import cn.zjhf.kingold.trade.dto.RewardFixedSearchDto;
import cn.zjhf.kingold.trade.entity.RewardFixedTerm;
import cn.zjhf.kingold.trade.vo.RewardBatchInfoVO;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface RewardFixedTermMapper {
    int deleteByPrimaryKey(String rewardFixedBillCode);

    int insert(RewardFixedTerm record);

    RewardFixedTerm selectByPrimaryKey(String rewardFixedBillCode);

    int updateByPrimaryKey(RewardFixedTerm record);

    /**
     * 根据时间段查询定期奖励汇总表
     *
     * @param rewardFixedSearchDto
     * @return
     */
    List<RewardFixedTerm> getRewardFixedList(RewardFixedSearchDto rewardFixedSearchDto);

    /**
     *
     * @param rewardFixedSearchDto
     * @return
     */
    List<RewardFixedTerm> searchRewardFixed(RewardFixedSearchDto rewardFixedSearchDto);

    /**
     *
     * @param rewardFixedSearchDto
     * @return
     */
    int searchRewardFixedCount(RewardFixedSearchDto rewardFixedSearchDto);

    /**
     * 更新审核状态
     *
     * @param param
     * @return
     */
    int updateCheckStatus(Map<String, Object> param);

    /**
     * 更新结算状态
     *
     * @param param
     * @return
     */
    int updateClearStatus(Map<String, Object> param);

    /**
     * 读取批次信息
     *
     * @param batchCode
     * @return
     */
    List<RewardBatchInfoVO> getOneBatchInfo(String batchCode);

    /**
     * 根据批次查询
     *
     * @param batchCode
     * @return
     */
    List<RewardFixedTerm> selectByBatchCode(String batchCode);

    /**
     * 根据批次单号查询待审核的奖励结算单
     *
     * @param batchCode
     * @return
     */
    List<RewardFixedTerm> selectToCheckByBatchCode(String batchCode);

    /**
     * 根据批次单号查询待结算的奖励结算单
     *
     * @param batchCode
     * @return
     */
    List<RewardFixedTerm> selectToClearByBatchCode(String batchCode);
}