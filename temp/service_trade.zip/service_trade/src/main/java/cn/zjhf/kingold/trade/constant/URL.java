package cn.zjhf.kingold.trade.constant;

/**
 * Created by lutiehua on 2017/6/5.
 */
public interface URL {

    /**
     * 获取定期产品信息
     */
    String URL_PRODUCT_GET_FIXED_TERM = "/product/fixedIncome/%s";

    /**
     * 获取私募产品信息
     */
    String URL_PRODUCT_GET_PRIVATE_FUND = "/product/privateFund/%s";

    /**
     * 更新产品募集金额
     */
    String URL_PRODUCT_UPDATE_ACCUMULATION = "/product/updateAccumulation";

    /**
     * 获取投资人信息
     */
    String URL_USER_GET_INVESTOR = "/user/investor/list";

    /**
     * 获取投资人用户关系
     */
    String URL_USER_GET_RELATION = "/investorRelation/%s";

    /**
     * 获取投资人用户关系列表
     */
    String URL_USER_GET_RELATION_LIST = "/investorRelation/list";


    /**
     * 添加用户身份认证信息
     */
    String URL_USER_AUTH_ADD = "/user/certification";

    /**
     * 获取用户身份认证信息
     */
    String URL_USER_AUTH_GET = "/user/certification/%s";

    /**
     * 修改用户身份状态信息
     */
    String URL_USER_PUT = "/user/%s";


    /**
     * 获取用户信息
     */
    String URL_GET_USER = "/user/%s";


    /**
     * 校验交易密码
     */
    String URL_CHECK_PAY_PASSWORD = "/user/checkPayPassword";


    /**
     * 设置用户授权成功
     */
    String URL_USER_AUTH_SUCCESS = "/user/userAuthSuccess/%s";

    /**
     * 发送消息
     */
    String URL_SEND_MESSAGE = "/message/send";

    /**
     * 获取定期产品列表
     */
    String URL_PRODUCT_GET_FIXED_TERM_LIST = "/product/fixedIncome/list";

    /**
     * 设置消息
     */
    String URL_BASE_BATCH_COUPON_SET_UNREAD_MESSAGE = "/message/batchSetUnreadMessage";

    /**
     * 查询积分流水数量接口
     */
    String URL_GET_COIN_TRANSACTION_COUNT = "/coinTransaction/count";

}
