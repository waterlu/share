package cn.zjhf.kingold.trade.persistence.dao;

import cn.zjhf.kingold.trade.entity.TradeRecharge;
import cn.zjhf.kingold.trade.entity.TradeRechargeExample;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface TradeRechargeMapper {

    int insert(TradeRecharge record);

    TradeRecharge selectByPrimaryKey(String tradeRechargeUuid);

    TradeRecharge selectByBillCode(String billCode);

    int update(TradeRecharge record);

    int updateByPrimaryKey(TradeRecharge record);

    List<Map> getList(Map transParams);

    int getCount(Map transParams);
}