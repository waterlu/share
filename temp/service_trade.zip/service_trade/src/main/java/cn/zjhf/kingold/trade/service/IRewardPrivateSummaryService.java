package cn.zjhf.kingold.trade.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.dto.RewardPrivateSearchDto;
import cn.zjhf.kingold.trade.entity.RewardFixedTerm;
import cn.zjhf.kingold.trade.entity.RewardPrivateFund;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

/**
 * Created by lutiehua on 2017/6/2.
 */
public interface IRewardPrivateSummaryService {

    /**
     * 查询私募奖励发放记录
     *
     * @return
     * @throws BusinessException
     */
    List<RewardPrivateFund> searchRewardPrivate(RewardPrivateSearchDto rewardSearchDto) throws BusinessException;

    /**
     * 查询私募奖励发放记录的总条数
     *
     * @param rewardSearchDto
     * @return
     * @throws BusinessException
     */
    int searchRewardPrivateCount(RewardPrivateSearchDto rewardSearchDto) throws BusinessException;

    /**
     *
     * @param rewardPrivateBillCode
     * @return
     */
    RewardPrivateFund getAwardPrivate(String rewardPrivateBillCode) throws BusinessException;

    /**
     * 更新审核状态
     *
     * @param param
     * @return
     */
    ResponseResult updateCheckStatus(Map<String, Object> param) throws BusinessException;

    /**
     * 更新结算状态
     *
     * @param param
     * @return
     */
    ResponseResult updateClearStatus(Map<String, Object> param) throws BusinessException;
}
