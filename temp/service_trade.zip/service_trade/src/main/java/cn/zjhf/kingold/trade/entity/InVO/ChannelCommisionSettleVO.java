package cn.zjhf.kingold.trade.entity.InVO;

import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Size;
import java.util.List;

/**
 * Created by zhangyijie on 2017/10/16.
 */
public class ChannelCommisionSettleVO extends InVOBase {
    @ApiModelProperty(required = true, value = "请求结算ID列表")
    @NotEmpty
    private List<String> requestIdList;

    @ApiModelProperty(required = true, value = "审核人")
    private String auditor;

    @ApiModelProperty(required = true, value = "是否审核通过，仅在审核时使用，1审核通过  0审核未通过")
    private int isAudited;

    @ApiModelProperty(required = true, value = "审核不通过的原因，仅在审核失败(isAudited == 0)时使用")
    private String message;

    public List<String> getRequestIdList() {
        return requestIdList;
    }

    public void setRequestIdList(List<String> requestIdList) {
        this.requestIdList = requestIdList;
    }

    public int getIsAudited() {
        return isAudited;
    }

    public void setIsAudited(int isAudited) {
        this.isAudited = isAudited;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getAuditor() {
        return auditor;
    }

    public void setAuditor(String auditor) {
        this.auditor = auditor;
    }

    @Override
    public String toString() {
        return "ChannelCommisionSettleVO{" +
                "traceID=" + DataUtils.toString(getTraceID()) + ", " +
                ", requestIdList=" + requestIdList +
                ", auditor=" + auditor +
                ", isAudited=" + isAudited +
                ", message='" + message + '\'' +
                '}';
    }
}
