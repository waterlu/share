package cn.zjhf.kingold.trade.entity.OutVO;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.trade.entity.CouponExtendRecord;
import cn.zjhf.kingold.trade.entity.CouponSpecifiedDistributionRecord;
import cn.zjhf.kingold.trade.entity.InVO.CouponExtendRecordVO;
import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModelProperty;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangyijie on 2017/8/23.
 */
public class CouponSpecifiedDistributionRecordItemListVO extends ParamVO {
    @ApiModelProperty(required = true, value = "总记录数")
    private int totalCount;

    @ApiModelProperty(required = true, value = "返回列表")
    private List<CouponSpecifiedDistributionRecordVO> items;

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public List<CouponSpecifiedDistributionRecordVO> getItems() {
        return items;
    }

    public void setItems(List<CouponSpecifiedDistributionRecordVO> items) {
        this.items = items;
    }

    public void setItemsEx(List<CouponSpecifiedDistributionRecord> items) {
        if(null == items) {
            return;
        }

        this.items = new ArrayList<CouponSpecifiedDistributionRecordVO>();
        if(items != null && items.size() > 0) {
            for(CouponSpecifiedDistributionRecord item : items) {
                this.items.add(new CouponSpecifiedDistributionRecordVO(item));
            }
        }
    }

    public void addItem(CouponSpecifiedDistributionRecordVO item) {
        if(this.items == null) {
            this.items = new ArrayList<>();
        }

        this.items.add(item);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(getTraceID()) + ", ");
        sb.append("totalCount:" + DataUtils.toString(totalCount) + ", ");
        sb.append("items:" + DataUtils.toString(items));
        return sb.toString();
    }
}
