package cn.zjhf.kingold.trade.entity.InVO;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.trade.entity.CashCoupon;
import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 */
@ApiModel(value = "CashCouponVO", description = "现金券表")
public class CashCouponVO extends InVOBase {

    @ApiModelProperty(required = true, value = "现金券批次号")
    private String ccCode;

    @ApiModelProperty(required = true, value = "现金券名称")
    @NotEmpty
    @Size(min = 1, max = 32)
    private String ccName;

    @ApiModelProperty(required = false, value = "现金券状态(1待激活，2已激活，3已停用)")
    private int ccStatus;

    @ApiModelProperty(required = false, value = "现金券类型(1现金券，2加息券)")
    private int ccType;

    @ApiModelProperty(required = true, value = "现金券面值")
    private double faceValue;

    @ApiModelProperty(required = true, value = "加息券加息率")
    private double interestYieldRate;

    @ApiModelProperty(required = true, value = "加息券加息类型：0全产品期限加息；1指定加息天数")
    private int interestYieldType;

    @ApiModelProperty(required = true, value = "加息券加息天数，interest_yield_type=1时有效")
    private int interestYieldPeriod;

    @ApiModelProperty(required = true, value = "有效期类型(1指定有效时间区间，2指定有效时间长度) ")
    @NotEmpty
    private int validTermType;

    @ApiModelProperty(required = false, value = "有效期开始时间")
    private Date validStartTime;

    @ApiModelProperty(required = false, value = "有效期结束时间")
    private Date validEndTime;

    @ApiModelProperty(required = false, value = "有效时间单位(1年，2月，3日)")
    private int validTermUnit;

    @ApiModelProperty(required = false, value = "和有效时间单位配合使用，有效期长度为 * 年/月/日")
    private int validTermQuantity;

    @ApiModelProperty(required = false, value = "发行总数上限")
    private int extendMaxNum;

    @ApiModelProperty(required = false, value = "单日发行总数上限")
    private int extendDayMaxNum;

    @ApiModelProperty(required = false, value = "发布渠道（PC/APP/H5，多个同时存在用$$分隔）")
    private String extendChannel;

    @ApiModelProperty(required = false, value = "适用产品类型，FIXI固收产品，PRIF私募产品")
    @Size(min = 1, max = 32)
    private String applyProductType;

    @ApiModelProperty(required = false, value = "使用渠道（PC/APP/H5，多个同时存在用$$分隔）")
    private String applyChannel;

    @ApiModelProperty(required = false, value = "要求的单笔投资下限")
    private double applyTradeAmount;

    @ApiModelProperty(required = false, value = "是否限制产品期限(1否，2是)")
    private int isApplyProductTerm;

    @ApiModelProperty(required = false, value = "适用产品期限集合,单位(天), 格式x1-y1,x2-y2")
    private String applyProductTerms;

    @ApiModelProperty(required = false, value = "是否限制子产品(1否，2是)")
    private int isApplyProductuuids;

    @ApiModelProperty(required = false, value = "限制子产品集合(多个同时存在用$$分隔)")
    private String applyProductuuids;

    @ApiModelProperty(required = false, value = "前台规则概要1")
    private String ccRemark1;

    @ApiModelProperty(required = false, value = "前台规则概要2")
    private String ccRemark2;

    @ApiModelProperty(required = false, value = "前台规则概要3")
    private String ccRemark3;

    @ApiModelProperty(required = true, value = "删除标记 0未删除，1已删除")
    private int deleteFlag;

    @ApiModelProperty(required = false, value = "停用时间")
    private Date deleteTime;

    @ApiModelProperty(required = false, value = "创建时间")
    private Date createTime;

    @ApiModelProperty(required = false, value = "更新时间")
    private Date updateTime;

    @ApiModelProperty(required = false, value = "激活时间")
    private Date activateTime;

    @ApiModelProperty(required = false, value = "停用时间")
    private Date disableTime;

    @ApiModelProperty(required = true, value = "领取数量")
    private int receiptCount;

    @ApiModelProperty(required = true, value = "已使用数量")
    private int usedCount;

    @ApiModelProperty(required = false, value = "更新用户id")
    @NotEmpty
    @Size(min = 1, max = 32)
    private String updateUserId;

    public CashCouponVO() {
    }

    public CashCouponVO(CashCoupon cashCoupon) {
        this.ccCode = cashCoupon.getCcCode();
        this.ccName = cashCoupon.getCcName();
        this.ccStatus = cashCoupon.getCcStatus();
        this.ccType = cashCoupon.getCcType();
        this.faceValue = cashCoupon.getFaceValue().doubleValue();
        this.interestYieldRate = cashCoupon.getInterestYieldRate().doubleValue();
        this.interestYieldType = cashCoupon.getInterestYieldType();
        this.interestYieldPeriod = cashCoupon.getInterestYieldPeriod();
        this.validTermType = cashCoupon.getValidTermType();
        this.validStartTime = cashCoupon.getValidStartTime();
        this.validEndTime = cashCoupon.getValidEndTime();
        this.validTermUnit = cashCoupon.getValidTermUnit();
        this.validTermQuantity = cashCoupon.getValidTermQuantity();
        this.extendMaxNum = cashCoupon.getExtendMaxNum();
        this.extendDayMaxNum = cashCoupon.getExtendDayMaxNum();
        this.extendChannel = cashCoupon.getExtendChannel();
        this.applyProductType = cashCoupon.getApplyProductType();
        this.applyChannel = cashCoupon.getApplyChannel();
        this.applyTradeAmount = cashCoupon.getApplyTradeAmount().doubleValue();
        this.isApplyProductTerm = cashCoupon.getIsApplyProductTerm();
        this.applyProductTerms = cashCoupon.getApplyProductTerms();
        this.isApplyProductuuids = cashCoupon.getIsApplyProductuuids();
        this.applyProductuuids = cashCoupon.getApplyProductuuids();
        this.ccRemark1 = cashCoupon.getCcRemark1();
        this.ccRemark2 = cashCoupon.getCcRemark2();
        this.ccRemark3 = cashCoupon.getCcRemark3();
        this.deleteFlag = cashCoupon.getDeleteFlag();
        this.deleteTime = cashCoupon.getDeleteTime();
        this.createTime = cashCoupon.getCreateTime();
        this.updateTime = cashCoupon.getUpdateTime();
        this.updateUserId = cashCoupon.getUpdateUserId();
        this.activateTime = cashCoupon.getActivateTime();
        this.disableTime = cashCoupon.getDisableTime();
    }

    public String getCcCode() {
        return ccCode;
    }

    public void setCcCode(String ccCode) {
        this.ccCode = ccCode;
    }

    public String getCcName() {
        return ccName;
    }

    public void setCcName(String ccName) {
        this.ccName = ccName;
    }

    public int getCcStatus() {
        return ccStatus;
    }

    public void setCcStatus(int ccStatus) {
        this.ccStatus = ccStatus;
    }

    public int getCcType() {
        return ccType;
    }

    public void setCcType(int ccType) {
        this.ccType = ccType;
    }

    public double getFaceValue() {
        return faceValue;
    }

    public void setFaceValue(double faceValue) {
        this.faceValue = faceValue;
    }

    public int getValidTermType() {
        return validTermType;
    }

    public void setValidTermType(int validTermType) {
        this.validTermType = validTermType;
    }

    public Date getValidStartTime() {
        return validStartTime;
    }

    public void setValidStartTime(Date validStartTime) {
        this.validStartTime = validStartTime;
    }

    public Date getValidEndTime() {
        return validEndTime;
    }

    public void setValidEndTime(Date validEndTime) {
        this.validEndTime = validEndTime;
    }

    public int getValidTermUnit() {
        return validTermUnit;
    }

    public void setValidTermUnit(int validTermUnit) {
        this.validTermUnit = validTermUnit;
    }

    public int getValidTermQuantity() {
        return validTermQuantity;
    }

    public void setValidTermQuantity(int validTermQuantity) {
        this.validTermQuantity = validTermQuantity;
    }

    public int getExtendMaxNum() {
        return extendMaxNum;
    }

    public void setExtendMaxNum(int extendMaxNum) {
        this.extendMaxNum = extendMaxNum;
    }

    public int getExtendDayMaxNum() {
        return extendDayMaxNum;
    }

    public void setExtendDayMaxNum(int extendDayMaxNum) {
        this.extendDayMaxNum = extendDayMaxNum;
    }

    public String getExtendChannel() {
        return extendChannel;
    }

    public void setExtendChannel(String extendChannel) {
        this.extendChannel = extendChannel;
    }

    public String getApplyProductType() {
        return applyProductType;
    }

    public void setApplyProductType(String applyProductType) {
        this.applyProductType = applyProductType;
    }

    public String getApplyChannel() {
        return applyChannel;
    }

    public void setApplyChannel(String applyChannel) {
        this.applyChannel = applyChannel;
    }

    public double getApplyTradeAmount() {
        return applyTradeAmount;
    }

    public void setApplyTradeAmount(double applyTradeAmount) {
        this.applyTradeAmount = applyTradeAmount;
    }

    public int getIsApplyProductTerm() {
        return isApplyProductTerm;
    }

    public void setIsApplyProductTerm(int isApplyProductTerm) {
        this.isApplyProductTerm = isApplyProductTerm;
    }

    public String getApplyProductTerms() {
        return applyProductTerms;
    }

    public void setApplyProductTerms(String applyProductTerms) {
        this.applyProductTerms = applyProductTerms;
    }

    public int getIsApplyProductuuids() {
        return isApplyProductuuids;
    }

    public void setIsApplyProductuuids(int isApplyProductuuids) {
        this.isApplyProductuuids = isApplyProductuuids;
    }

    public String getApplyProductuuids() {
        return applyProductuuids;
    }

    public void setApplyProductuuids(String applyProductuuids) {
        this.applyProductuuids = applyProductuuids;
    }

    public String getCcRemark1() {
        return ccRemark1;
    }

    public void setCcRemark1(String ccRemark1) {
        this.ccRemark1 = ccRemark1;
    }

    public String getCcRemark2() {
        return ccRemark2;
    }

    public void setCcRemark2(String ccRemark2) {
        this.ccRemark2 = ccRemark2;
    }

    public String getCcRemark3() {
        return ccRemark3;
    }

    public void setCcRemark3(String ccRemark3) {
        this.ccRemark3 = ccRemark3;
    }

    public int getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(int deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getDeleteTime() {
        return deleteTime;
    }

    public void setDeleteTime(Date deleteTime) {
        this.deleteTime = deleteTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(String updateUserId) {
        this.updateUserId = updateUserId;
    }

    public CashCoupon get() {
        CashCoupon cashCoupon = new CashCoupon();
        cashCoupon.setCcCode(ccCode);
        cashCoupon.setCcName(ccName);
        cashCoupon.setCcStatus(new Integer(ccStatus).byteValue());
        cashCoupon.setCcType(new Integer(ccType).byteValue());
        cashCoupon.setFaceValue(new BigDecimal(faceValue));
        cashCoupon.setInterestYieldRate(new BigDecimal(interestYieldRate));
        cashCoupon.setInterestYieldType(interestYieldType);
        cashCoupon.setInterestYieldPeriod(interestYieldPeriod);
        cashCoupon.setValidTermType(new Integer(validTermType).byteValue());
        cashCoupon.setValidStartTime(validStartTime);
        cashCoupon.setValidEndTime(validEndTime);
        cashCoupon.setValidTermUnit(new Integer(validTermUnit).byteValue());
        cashCoupon.setValidTermQuantity(validTermQuantity);
        cashCoupon.setExtendMaxNum(extendMaxNum);
        cashCoupon.setExtendDayMaxNum(extendDayMaxNum);
        cashCoupon.setExtendChannel(extendChannel);
        cashCoupon.setApplyProductType(applyProductType);
        cashCoupon.setApplyChannel(applyChannel);
        cashCoupon.setApplyTradeAmount(new BigDecimal(applyTradeAmount));
        cashCoupon.setIsApplyProductTerm(new Integer(isApplyProductTerm).byteValue());
        cashCoupon.setApplyProductTerms(applyProductTerms);
        cashCoupon.setIsApplyProductuuids(new Integer(isApplyProductuuids).byteValue());
        cashCoupon.setApplyProductuuids(applyProductuuids);
        cashCoupon.setCcRemark1(ccRemark1);
        cashCoupon.setCcRemark2(ccRemark2);
        cashCoupon.setCcRemark3(ccRemark3);
        cashCoupon.setDeleteFlag(new Integer(deleteFlag).byteValue());
        cashCoupon.setDeleteTime(deleteTime);
        cashCoupon.setCreateTime(createTime);
        cashCoupon.setUpdateTime(updateTime);
        cashCoupon.setUpdateUserId(updateUserId);
        cashCoupon.setActivateTime(activateTime);
        cashCoupon.setDisableTime(disableTime);
        return cashCoupon;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(getTraceID()) + ", ");
        sb.append("ccCode:" + DataUtils.toString(ccCode) + ", ");
        sb.append("ccName:" + DataUtils.toString(ccName) + ", ");
        sb.append("ccStatus:" + DataUtils.toString(ccStatus) + ", ");
        sb.append("ccType:" + DataUtils.toString(ccType) + ", ");
        sb.append("faceValue:" + DataUtils.toString(faceValue) + ", ");
        sb.append("interestYieldRate:" + DataUtils.toString(interestYieldRate) + ", ");
        sb.append("interestYieldType:" + DataUtils.toString(interestYieldType) + ", ");
        sb.append("interestYieldPeriod:" + DataUtils.toString(interestYieldPeriod) + ", ");
        sb.append("faceValue:" + DataUtils.toString(faceValue) + ", ");
        sb.append("validTermType:" + DataUtils.toString(validTermType) + ", ");
        sb.append("validStartTime:" + DataUtils.toString(validStartTime) + ", ");
        sb.append("validEndTime:" + DataUtils.toString(validEndTime) + ", ");
        sb.append("validTermUnit:" + DataUtils.toString(validTermUnit) + ", ");
        sb.append("validTermQuantity:" + DataUtils.toString(validTermQuantity) + ", ");
        sb.append("extendMaxNum:" + DataUtils.toString(extendMaxNum) + ", ");
        sb.append("extendDayMaxNum:" + DataUtils.toString(extendDayMaxNum) + ", ");
        sb.append("extendChannel:" + DataUtils.toString(extendChannel) + ", ");
        sb.append("applyProductType:" + DataUtils.toString(applyProductType) + ", ");
        sb.append("applyChannel:" + DataUtils.toString(applyChannel) + ", ");
        sb.append("applyTradeAmount:" + DataUtils.toString(applyTradeAmount) + ", ");
        sb.append("isApplyProductTerm:" + DataUtils.toString(isApplyProductTerm) + ", ");
        sb.append("applyProductTerms:" + DataUtils.toString(applyProductTerms) + ", ");
        sb.append("isApplyProductuuids:" + DataUtils.toString(isApplyProductuuids) + ", ");
        sb.append("applyProductuuids:" + DataUtils.toString(applyProductuuids) + ", ");
        sb.append("ccRemark1:" + DataUtils.toString(ccRemark1) + ", ");
        sb.append("ccRemark2:" + DataUtils.toString(ccRemark2) + ", ");
        sb.append("ccRemark3:" + DataUtils.toString(ccRemark3) + ", ");
        sb.append("activateTime:" + DataUtils.toString(activateTime) + ", ");
        sb.append("receiptCount:" + DataUtils.toString(receiptCount) + ", ");
        sb.append("usedCount:" + DataUtils.toString(usedCount) + ", ");
        sb.append("disableTime:" + DataUtils.toString(disableTime) + ", ");
        sb.append("deleteFlag:" + DataUtils.toString(deleteFlag) + ", ");
        sb.append("deleteTime:" + DataUtils.toString(deleteTime) + ", ");
        sb.append("createTime:" + DataUtils.toString(createTime) + ", ");
        sb.append("updateTime:" + DataUtils.toString(updateTime) + ", ");
        sb.append("updateUserId:" + DataUtils.toString(updateUserId));
        return sb.toString();
    }

    public Date getActivateTime() {
        return activateTime;
    }

    public void setActivateTime(Date activateTime) {
        this.activateTime = activateTime;
    }

    public int getReceiptCount() {
        return receiptCount;
    }

    public void setReceiptCount(int receiptCount) {
        this.receiptCount = receiptCount;
    }

    public int getUsedCount() {
        return usedCount;
    }

    public void setUsedCount(int usedCount) {
        this.usedCount = usedCount;
    }

    public Date getDisableTime() {
        return disableTime;
    }

    public void setDisableTime(Date disableTime) {
        this.disableTime = disableTime;
    }

    public double getInterestYieldRate() {
        return interestYieldRate;
    }

    public void setInterestYieldRate(double interestYieldRate) {
        this.interestYieldRate = interestYieldRate;
    }

    public int getInterestYieldType() {
        return interestYieldType;
    }

    public void setInterestYieldType(int interestYieldType) {
        this.interestYieldType = interestYieldType;
    }

    public int getInterestYieldPeriod() {
        return interestYieldPeriod;
    }

    public void setInterestYieldPeriod(int interestYieldPeriod) {
        this.interestYieldPeriod = interestYieldPeriod;
    }
}
