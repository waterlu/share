package cn.zjhf.kingold.trade.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.common.utils.MapRemoveNullUtil;
import cn.zjhf.kingold.trade.service.ITradeOrderService;
import cn.zjhf.kingold.trade.service.ITradePrivateFundOrderService;
import cn.zjhf.kingold.trade.utils.DataUtils;
import cn.zjhf.kingold.trade.utils.MapParamUtils;
import cn.zjhf.kingold.trade.utils.PropertyDescriptionUtils;
import cn.zjhf.kingold.trade.utils.RequestMapperConvert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by lu on 2017/3/13.
 */
@RestController
@RequestMapping(value = "/tradeprivatefund")
public class TradePrivateFundController {
    protected static final Logger logger = LoggerFactory.getLogger(TradePrivateFundController.class);

    @Autowired
    private ITradePrivateFundOrderService tradePrivateFundOrderService;

    /**
     * 插入
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "", method = RequestMethod.POST)
    public ResponseResult insert( @RequestBody Map userMap) throws BusinessException {
        logger.info("recharge start: " + DataUtils.toString(userMap));

        RequestMapperConvert.initParam(userMap);

        tradePrivateFundOrderService.insert(userMap);

        logger.info("recharge end: " + DataUtils.toString(userMap.get("traceID")));
        return  new ResponseResult( MapParamUtils.getStringInMap( userMap,"traceID"), ResponseCode.REQUEST_SUCCESS,"成功",userMap.get("accountTransactionUuid"));
    }

    /**
     * 查找
     * @param pfoCode
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/{pfoCode}", method = RequestMethod.GET)
    public ResponseResult get(@PathVariable("pfoCode") String pfoCode,@RequestParam Map paramMap) throws BusinessException {
        logger.info("get start: " + DataUtils.toString(pfoCode, paramMap));
        RequestMapperConvert.initParam(paramMap);

        paramMap.put("pfoCode",pfoCode);
        Map ui = tradePrivateFundOrderService.getWithFilter(paramMap);

        logger.info("get end: " + DataUtils.toString(paramMap.get("traceID"), ui));
        return new ResponseResult( MapParamUtils.getStringInMap( paramMap,"traceID"), ResponseCode.REQUEST_SUCCESS,"成功",ui);
    }

    /**
     * 查找
     * @param paramMap 参数选填：
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/getByFilter", method = RequestMethod.GET)
    public ResponseResult getByFilter(@RequestParam Map paramMap) throws BusinessException {
        logger.info("getByFilter start: " + DataUtils.toString(paramMap));

        RequestMapperConvert.initParam(paramMap);
        RequestMapperConvert.initPrivateFundOrderParam(paramMap);
        Map ui = tradePrivateFundOrderService.getWithFilter(paramMap);

        logger.info("getByFilter end: " + DataUtils.toString(paramMap.get("traceID"), ui));
        return new ResponseResult( MapParamUtils.getStringInMap( paramMap,"traceID"),ResponseCode.REQUEST_SUCCESS,"成功",ui);
    }


    /**
     * 根据uuid 更新
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/{uuid}", method = RequestMethod.PUT)
    public ResponseResult update(@PathVariable("uuid") String uuid, @RequestBody Map userMap) throws BusinessException {
        logger.info("update start: " + DataUtils.toString(uuid, userMap));

        MapRemoveNullUtil.removeNullEntry(userMap);
        RequestMapperConvert.initParam(userMap);
        userMap.put("uuid",uuid);
        int num = tradePrivateFundOrderService.update(userMap);

        logger.info("update end: " + DataUtils.toString(userMap.get("traceID"), num));
        return  new ResponseResult( MapParamUtils.getStringInMap( userMap,"traceID"),ResponseCode.REQUEST_SUCCESS,"成功",num);
    }


    /**
     * 私募订单列表
     *
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public ResponseResult getList(@RequestParam Map paramMap) throws BusinessException {
        logger.info("getList start: " + DataUtils.toString(paramMap));

        MapRemoveNullUtil.removeNullEntry(paramMap);
        RequestMapperConvert.initParam(paramMap);
        RequestMapperConvert.initPrivateFundOrderParam(paramMap);
        List<Map> result = new ArrayList<>();
        List<Map> userList = tradePrivateFundOrderService.getList(paramMap);
        if(paramMap.get("properties") != null) {
            for (Map map : userList) {
                result.add(PropertyDescriptionUtils.convertProperty(map, (String) paramMap.get("properties"), (String) paramMap.get("desc"), PropertyDescriptionUtils.TRADE_PRIVATE_FUND_ORDER_DIC));
            }
        }

        logger.info("getList end: " + DataUtils.toString(paramMap.get("traceID"), result));
        return new ResponseResult( MapParamUtils.getStringInMap( paramMap,"traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", result);
    }

    /**
     * 私募订单总数
     *
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/count", method = RequestMethod.GET)
    public ResponseResult getCount(@RequestParam Map paramMap) throws BusinessException {
        logger.info("getCount start: " + DataUtils.toString(paramMap));

        MapRemoveNullUtil.removeNullEntry(paramMap);
        RequestMapperConvert.initParam(paramMap);
        RequestMapperConvert.initPrivateFundOrderParam(paramMap);
        Integer count  = tradePrivateFundOrderService.getCount(paramMap);

        logger.info("getCount end: " + DataUtils.toString(paramMap.get("traceID"), count));
        return new ResponseResult( MapParamUtils.getStringInMap( paramMap,"traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", count);
    }

    /**
     * 某个产品私募订单预约金额总数
     *
     * 必填入参（二选一） productUuid，productCode，type：orderSum 所有订单金额，orderVerifySum 所有确认订单金额
     *
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/getPurchaseSum", method = RequestMethod.GET)
    public ResponseResult getPurchaseSum(@RequestParam Map paramMap) throws BusinessException {
        logger.info("getPurchaseSum start: " + DataUtils.toString(paramMap));

        MapRemoveNullUtil.removeNullEntry(paramMap);
        RequestMapperConvert.initParam(paramMap);
        String type = MapParamUtils.getStringInMap(paramMap,"type");
        BigDecimal sumPurchase = null;
        if(type.equals("orderSum")) {
            sumPurchase = tradePrivateFundOrderService.getOrderPurchaseSum(paramMap);
        }else if(type.equals("orderVerifySum")){
            sumPurchase = tradePrivateFundOrderService.getOrderVerifyPurchaseSum(paramMap);
        }else{
            sumPurchase = tradePrivateFundOrderService.getOrderPurchaseSum(paramMap);
        }

        logger.info("getPurchaseSum end: " + DataUtils.toString(paramMap.get("traceID"), sumPurchase));
        return new ResponseResult( MapParamUtils.getStringInMap( paramMap,"traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", sumPurchase);
    }
}
