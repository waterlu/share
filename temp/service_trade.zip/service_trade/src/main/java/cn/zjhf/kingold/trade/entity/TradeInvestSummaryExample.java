package cn.zjhf.kingold.trade.entity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TradeInvestSummaryExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private Integer limit;

    private Integer offset;

    public TradeInvestSummaryExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andTradeInvestSummaryUuidIsNull() {
            addCriterion("trade_invest_summary_uuid is null");
            return (Criteria) this;
        }

        public Criteria andTradeInvestSummaryUuidIsNotNull() {
            addCriterion("trade_invest_summary_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andTradeInvestSummaryUuidEqualTo(Long value) {
            addCriterion("trade_invest_summary_uuid =", value, "tradeInvestSummaryUuid");
            return (Criteria) this;
        }

        public Criteria andTradeInvestSummaryUuidNotEqualTo(Long value) {
            addCriterion("trade_invest_summary_uuid <>", value, "tradeInvestSummaryUuid");
            return (Criteria) this;
        }

        public Criteria andTradeInvestSummaryUuidGreaterThan(Long value) {
            addCriterion("trade_invest_summary_uuid >", value, "tradeInvestSummaryUuid");
            return (Criteria) this;
        }

        public Criteria andTradeInvestSummaryUuidGreaterThanOrEqualTo(Long value) {
            addCriterion("trade_invest_summary_uuid >=", value, "tradeInvestSummaryUuid");
            return (Criteria) this;
        }

        public Criteria andTradeInvestSummaryUuidLessThan(Long value) {
            addCriterion("trade_invest_summary_uuid <", value, "tradeInvestSummaryUuid");
            return (Criteria) this;
        }

        public Criteria andTradeInvestSummaryUuidLessThanOrEqualTo(Long value) {
            addCriterion("trade_invest_summary_uuid <=", value, "tradeInvestSummaryUuid");
            return (Criteria) this;
        }

        public Criteria andTradeInvestSummaryUuidIn(List<Long> values) {
            addCriterion("trade_invest_summary_uuid in", values, "tradeInvestSummaryUuid");
            return (Criteria) this;
        }

        public Criteria andTradeInvestSummaryUuidNotIn(List<Long> values) {
            addCriterion("trade_invest_summary_uuid not in", values, "tradeInvestSummaryUuid");
            return (Criteria) this;
        }

        public Criteria andTradeInvestSummaryUuidBetween(Long value1, Long value2) {
            addCriterion("trade_invest_summary_uuid between", value1, value2, "tradeInvestSummaryUuid");
            return (Criteria) this;
        }

        public Criteria andTradeInvestSummaryUuidNotBetween(Long value1, Long value2) {
            addCriterion("trade_invest_summary_uuid not between", value1, value2, "tradeInvestSummaryUuid");
            return (Criteria) this;
        }

        public Criteria andBatchNoIsNull() {
            addCriterion("batch_no is null");
            return (Criteria) this;
        }

        public Criteria andBatchNoIsNotNull() {
            addCriterion("batch_no is not null");
            return (Criteria) this;
        }

        public Criteria andBatchNoEqualTo(String value) {
            addCriterion("batch_no =", value, "batchNo");
            return (Criteria) this;
        }

        public Criteria andBatchNoNotEqualTo(String value) {
            addCriterion("batch_no <>", value, "batchNo");
            return (Criteria) this;
        }

        public Criteria andBatchNoGreaterThan(String value) {
            addCriterion("batch_no >", value, "batchNo");
            return (Criteria) this;
        }

        public Criteria andBatchNoGreaterThanOrEqualTo(String value) {
            addCriterion("batch_no >=", value, "batchNo");
            return (Criteria) this;
        }

        public Criteria andBatchNoLessThan(String value) {
            addCriterion("batch_no <", value, "batchNo");
            return (Criteria) this;
        }

        public Criteria andBatchNoLessThanOrEqualTo(String value) {
            addCriterion("batch_no <=", value, "batchNo");
            return (Criteria) this;
        }

        public Criteria andBatchNoLike(String value) {
            addCriterion("batch_no like", value, "batchNo");
            return (Criteria) this;
        }

        public Criteria andBatchNoNotLike(String value) {
            addCriterion("batch_no not like", value, "batchNo");
            return (Criteria) this;
        }

        public Criteria andBatchNoIn(List<String> values) {
            addCriterion("batch_no in", values, "batchNo");
            return (Criteria) this;
        }

        public Criteria andBatchNoNotIn(List<String> values) {
            addCriterion("batch_no not in", values, "batchNo");
            return (Criteria) this;
        }

        public Criteria andBatchNoBetween(String value1, String value2) {
            addCriterion("batch_no between", value1, value2, "batchNo");
            return (Criteria) this;
        }

        public Criteria andBatchNoNotBetween(String value1, String value2) {
            addCriterion("batch_no not between", value1, value2, "batchNo");
            return (Criteria) this;
        }

        public Criteria andProductUuidIsNull() {
            addCriterion("product_uuid is null");
            return (Criteria) this;
        }

        public Criteria andProductUuidIsNotNull() {
            addCriterion("product_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andProductUuidEqualTo(String value) {
            addCriterion("product_uuid =", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotEqualTo(String value) {
            addCriterion("product_uuid <>", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidGreaterThan(String value) {
            addCriterion("product_uuid >", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidGreaterThanOrEqualTo(String value) {
            addCriterion("product_uuid >=", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidLessThan(String value) {
            addCriterion("product_uuid <", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidLessThanOrEqualTo(String value) {
            addCriterion("product_uuid <=", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidLike(String value) {
            addCriterion("product_uuid like", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotLike(String value) {
            addCriterion("product_uuid not like", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidIn(List<String> values) {
            addCriterion("product_uuid in", values, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotIn(List<String> values) {
            addCriterion("product_uuid not in", values, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidBetween(String value1, String value2) {
            addCriterion("product_uuid between", value1, value2, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotBetween(String value1, String value2) {
            addCriterion("product_uuid not between", value1, value2, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductCodeIsNull() {
            addCriterion("product_code is null");
            return (Criteria) this;
        }

        public Criteria andProductCodeIsNotNull() {
            addCriterion("product_code is not null");
            return (Criteria) this;
        }

        public Criteria andProductCodeEqualTo(String value) {
            addCriterion("product_code =", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotEqualTo(String value) {
            addCriterion("product_code <>", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeGreaterThan(String value) {
            addCriterion("product_code >", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeGreaterThanOrEqualTo(String value) {
            addCriterion("product_code >=", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLessThan(String value) {
            addCriterion("product_code <", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLessThanOrEqualTo(String value) {
            addCriterion("product_code <=", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLike(String value) {
            addCriterion("product_code like", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotLike(String value) {
            addCriterion("product_code not like", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeIn(List<String> values) {
            addCriterion("product_code in", values, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotIn(List<String> values) {
            addCriterion("product_code not in", values, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeBetween(String value1, String value2) {
            addCriterion("product_code between", value1, value2, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotBetween(String value1, String value2) {
            addCriterion("product_code not between", value1, value2, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductTypeIsNull() {
            addCriterion("product_type is null");
            return (Criteria) this;
        }

        public Criteria andProductTypeIsNotNull() {
            addCriterion("product_type is not null");
            return (Criteria) this;
        }

        public Criteria andProductTypeEqualTo(String value) {
            addCriterion("product_type =", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeNotEqualTo(String value) {
            addCriterion("product_type <>", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeGreaterThan(String value) {
            addCriterion("product_type >", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeGreaterThanOrEqualTo(String value) {
            addCriterion("product_type >=", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeLessThan(String value) {
            addCriterion("product_type <", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeLessThanOrEqualTo(String value) {
            addCriterion("product_type <=", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeLike(String value) {
            addCriterion("product_type like", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeNotLike(String value) {
            addCriterion("product_type not like", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeIn(List<String> values) {
            addCriterion("product_type in", values, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeNotIn(List<String> values) {
            addCriterion("product_type not in", values, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeBetween(String value1, String value2) {
            addCriterion("product_type between", value1, value2, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeNotBetween(String value1, String value2) {
            addCriterion("product_type not between", value1, value2, "productType");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameIsNull() {
            addCriterion("product_abbr_name is null");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameIsNotNull() {
            addCriterion("product_abbr_name is not null");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameEqualTo(String value) {
            addCriterion("product_abbr_name =", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameNotEqualTo(String value) {
            addCriterion("product_abbr_name <>", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameGreaterThan(String value) {
            addCriterion("product_abbr_name >", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameGreaterThanOrEqualTo(String value) {
            addCriterion("product_abbr_name >=", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameLessThan(String value) {
            addCriterion("product_abbr_name <", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameLessThanOrEqualTo(String value) {
            addCriterion("product_abbr_name <=", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameLike(String value) {
            addCriterion("product_abbr_name like", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameNotLike(String value) {
            addCriterion("product_abbr_name not like", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameIn(List<String> values) {
            addCriterion("product_abbr_name in", values, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameNotIn(List<String> values) {
            addCriterion("product_abbr_name not in", values, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameBetween(String value1, String value2) {
            addCriterion("product_abbr_name between", value1, value2, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameNotBetween(String value1, String value2) {
            addCriterion("product_abbr_name not between", value1, value2, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andRaiseCountIsNull() {
            addCriterion("raise_count is null");
            return (Criteria) this;
        }

        public Criteria andRaiseCountIsNotNull() {
            addCriterion("raise_count is not null");
            return (Criteria) this;
        }

        public Criteria andRaiseCountEqualTo(BigDecimal value) {
            addCriterion("raise_count =", value, "raiseCount");
            return (Criteria) this;
        }

        public Criteria andRaiseCountNotEqualTo(BigDecimal value) {
            addCriterion("raise_count <>", value, "raiseCount");
            return (Criteria) this;
        }

        public Criteria andRaiseCountGreaterThan(BigDecimal value) {
            addCriterion("raise_count >", value, "raiseCount");
            return (Criteria) this;
        }

        public Criteria andRaiseCountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("raise_count >=", value, "raiseCount");
            return (Criteria) this;
        }

        public Criteria andRaiseCountLessThan(BigDecimal value) {
            addCriterion("raise_count <", value, "raiseCount");
            return (Criteria) this;
        }

        public Criteria andRaiseCountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("raise_count <=", value, "raiseCount");
            return (Criteria) this;
        }

        public Criteria andRaiseCountIn(List<BigDecimal> values) {
            addCriterion("raise_count in", values, "raiseCount");
            return (Criteria) this;
        }

        public Criteria andRaiseCountNotIn(List<BigDecimal> values) {
            addCriterion("raise_count not in", values, "raiseCount");
            return (Criteria) this;
        }

        public Criteria andRaiseCountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("raise_count between", value1, value2, "raiseCount");
            return (Criteria) this;
        }

        public Criteria andRaiseCountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("raise_count not between", value1, value2, "raiseCount");
            return (Criteria) this;
        }

        public Criteria andRaiseAmountIsNull() {
            addCriterion("raise_amount is null");
            return (Criteria) this;
        }

        public Criteria andRaiseAmountIsNotNull() {
            addCriterion("raise_amount is not null");
            return (Criteria) this;
        }

        public Criteria andRaiseAmountEqualTo(BigDecimal value) {
            addCriterion("raise_amount =", value, "raiseAmount");
            return (Criteria) this;
        }

        public Criteria andRaiseAmountNotEqualTo(BigDecimal value) {
            addCriterion("raise_amount <>", value, "raiseAmount");
            return (Criteria) this;
        }

        public Criteria andRaiseAmountGreaterThan(BigDecimal value) {
            addCriterion("raise_amount >", value, "raiseAmount");
            return (Criteria) this;
        }

        public Criteria andRaiseAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("raise_amount >=", value, "raiseAmount");
            return (Criteria) this;
        }

        public Criteria andRaiseAmountLessThan(BigDecimal value) {
            addCriterion("raise_amount <", value, "raiseAmount");
            return (Criteria) this;
        }

        public Criteria andRaiseAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("raise_amount <=", value, "raiseAmount");
            return (Criteria) this;
        }

        public Criteria andRaiseAmountIn(List<BigDecimal> values) {
            addCriterion("raise_amount in", values, "raiseAmount");
            return (Criteria) this;
        }

        public Criteria andRaiseAmountNotIn(List<BigDecimal> values) {
            addCriterion("raise_amount not in", values, "raiseAmount");
            return (Criteria) this;
        }

        public Criteria andRaiseAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("raise_amount between", value1, value2, "raiseAmount");
            return (Criteria) this;
        }

        public Criteria andRaiseAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("raise_amount not between", value1, value2, "raiseAmount");
            return (Criteria) this;
        }

        public Criteria andRaiseInvestorAmountIsNull() {
            addCriterion("raise_investor_amount is null");
            return (Criteria) this;
        }

        public Criteria andRaiseInvestorAmountIsNotNull() {
            addCriterion("raise_investor_amount is not null");
            return (Criteria) this;
        }

        public Criteria andRaiseInvestorAmountEqualTo(BigDecimal value) {
            addCriterion("raise_investor_amount =", value, "raiseInvestorAmount");
            return (Criteria) this;
        }

        public Criteria andRaiseInvestorAmountNotEqualTo(BigDecimal value) {
            addCriterion("raise_investor_amount <>", value, "raiseInvestorAmount");
            return (Criteria) this;
        }

        public Criteria andRaiseInvestorAmountGreaterThan(BigDecimal value) {
            addCriterion("raise_investor_amount >", value, "raiseInvestorAmount");
            return (Criteria) this;
        }

        public Criteria andRaiseInvestorAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("raise_investor_amount >=", value, "raiseInvestorAmount");
            return (Criteria) this;
        }

        public Criteria andRaiseInvestorAmountLessThan(BigDecimal value) {
            addCriterion("raise_investor_amount <", value, "raiseInvestorAmount");
            return (Criteria) this;
        }

        public Criteria andRaiseInvestorAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("raise_investor_amount <=", value, "raiseInvestorAmount");
            return (Criteria) this;
        }

        public Criteria andRaiseInvestorAmountIn(List<BigDecimal> values) {
            addCriterion("raise_investor_amount in", values, "raiseInvestorAmount");
            return (Criteria) this;
        }

        public Criteria andRaiseInvestorAmountNotIn(List<BigDecimal> values) {
            addCriterion("raise_investor_amount not in", values, "raiseInvestorAmount");
            return (Criteria) this;
        }

        public Criteria andRaiseInvestorAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("raise_investor_amount between", value1, value2, "raiseInvestorAmount");
            return (Criteria) this;
        }

        public Criteria andRaiseInvestorAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("raise_investor_amount not between", value1, value2, "raiseInvestorAmount");
            return (Criteria) this;
        }

        public Criteria andRaisePlatformAmountIsNull() {
            addCriterion("raise_platform_amount is null");
            return (Criteria) this;
        }

        public Criteria andRaisePlatformAmountIsNotNull() {
            addCriterion("raise_platform_amount is not null");
            return (Criteria) this;
        }

        public Criteria andRaisePlatformAmountEqualTo(BigDecimal value) {
            addCriterion("raise_platform_amount =", value, "raisePlatformAmount");
            return (Criteria) this;
        }

        public Criteria andRaisePlatformAmountNotEqualTo(BigDecimal value) {
            addCriterion("raise_platform_amount <>", value, "raisePlatformAmount");
            return (Criteria) this;
        }

        public Criteria andRaisePlatformAmountGreaterThan(BigDecimal value) {
            addCriterion("raise_platform_amount >", value, "raisePlatformAmount");
            return (Criteria) this;
        }

        public Criteria andRaisePlatformAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("raise_platform_amount >=", value, "raisePlatformAmount");
            return (Criteria) this;
        }

        public Criteria andRaisePlatformAmountLessThan(BigDecimal value) {
            addCriterion("raise_platform_amount <", value, "raisePlatformAmount");
            return (Criteria) this;
        }

        public Criteria andRaisePlatformAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("raise_platform_amount <=", value, "raisePlatformAmount");
            return (Criteria) this;
        }

        public Criteria andRaisePlatformAmountIn(List<BigDecimal> values) {
            addCriterion("raise_platform_amount in", values, "raisePlatformAmount");
            return (Criteria) this;
        }

        public Criteria andRaisePlatformAmountNotIn(List<BigDecimal> values) {
            addCriterion("raise_platform_amount not in", values, "raisePlatformAmount");
            return (Criteria) this;
        }

        public Criteria andRaisePlatformAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("raise_platform_amount between", value1, value2, "raisePlatformAmount");
            return (Criteria) this;
        }

        public Criteria andRaisePlatformAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("raise_platform_amount not between", value1, value2, "raisePlatformAmount");
            return (Criteria) this;
        }

        public Criteria andPlatformServiceFeeIsNull() {
            addCriterion("platform_service_fee is null");
            return (Criteria) this;
        }

        public Criteria andPlatformServiceFeeIsNotNull() {
            addCriterion("platform_service_fee is not null");
            return (Criteria) this;
        }

        public Criteria andPlatformServiceFeeEqualTo(BigDecimal value) {
            addCriterion("platform_service_fee =", value, "platformServiceFee");
            return (Criteria) this;
        }

        public Criteria andPlatformServiceFeeNotEqualTo(BigDecimal value) {
            addCriterion("platform_service_fee <>", value, "platformServiceFee");
            return (Criteria) this;
        }

        public Criteria andPlatformServiceFeeGreaterThan(BigDecimal value) {
            addCriterion("platform_service_fee >", value, "platformServiceFee");
            return (Criteria) this;
        }

        public Criteria andPlatformServiceFeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("platform_service_fee >=", value, "platformServiceFee");
            return (Criteria) this;
        }

        public Criteria andPlatformServiceFeeLessThan(BigDecimal value) {
            addCriterion("platform_service_fee <", value, "platformServiceFee");
            return (Criteria) this;
        }

        public Criteria andPlatformServiceFeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("platform_service_fee <=", value, "platformServiceFee");
            return (Criteria) this;
        }

        public Criteria andPlatformServiceFeeIn(List<BigDecimal> values) {
            addCriterion("platform_service_fee in", values, "platformServiceFee");
            return (Criteria) this;
        }

        public Criteria andPlatformServiceFeeNotIn(List<BigDecimal> values) {
            addCriterion("platform_service_fee not in", values, "platformServiceFee");
            return (Criteria) this;
        }

        public Criteria andPlatformServiceFeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("platform_service_fee between", value1, value2, "platformServiceFee");
            return (Criteria) this;
        }

        public Criteria andPlatformServiceFeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("platform_service_fee not between", value1, value2, "platformServiceFee");
            return (Criteria) this;
        }

        public Criteria andExchangeManageFeeIsNull() {
            addCriterion("exchange_manage_fee is null");
            return (Criteria) this;
        }

        public Criteria andExchangeManageFeeIsNotNull() {
            addCriterion("exchange_manage_fee is not null");
            return (Criteria) this;
        }

        public Criteria andExchangeManageFeeEqualTo(BigDecimal value) {
            addCriterion("exchange_manage_fee =", value, "exchangeManageFee");
            return (Criteria) this;
        }

        public Criteria andExchangeManageFeeNotEqualTo(BigDecimal value) {
            addCriterion("exchange_manage_fee <>", value, "exchangeManageFee");
            return (Criteria) this;
        }

        public Criteria andExchangeManageFeeGreaterThan(BigDecimal value) {
            addCriterion("exchange_manage_fee >", value, "exchangeManageFee");
            return (Criteria) this;
        }

        public Criteria andExchangeManageFeeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("exchange_manage_fee >=", value, "exchangeManageFee");
            return (Criteria) this;
        }

        public Criteria andExchangeManageFeeLessThan(BigDecimal value) {
            addCriterion("exchange_manage_fee <", value, "exchangeManageFee");
            return (Criteria) this;
        }

        public Criteria andExchangeManageFeeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("exchange_manage_fee <=", value, "exchangeManageFee");
            return (Criteria) this;
        }

        public Criteria andExchangeManageFeeIn(List<BigDecimal> values) {
            addCriterion("exchange_manage_fee in", values, "exchangeManageFee");
            return (Criteria) this;
        }

        public Criteria andExchangeManageFeeNotIn(List<BigDecimal> values) {
            addCriterion("exchange_manage_fee not in", values, "exchangeManageFee");
            return (Criteria) this;
        }

        public Criteria andExchangeManageFeeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("exchange_manage_fee between", value1, value2, "exchangeManageFee");
            return (Criteria) this;
        }

        public Criteria andExchangeManageFeeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("exchange_manage_fee not between", value1, value2, "exchangeManageFee");
            return (Criteria) this;
        }

        public Criteria andOutUserUuidIsNull() {
            addCriterion("out_user_uuid is null");
            return (Criteria) this;
        }

        public Criteria andOutUserUuidIsNotNull() {
            addCriterion("out_user_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andOutUserUuidEqualTo(String value) {
            addCriterion("out_user_uuid =", value, "outUserUuid");
            return (Criteria) this;
        }

        public Criteria andOutUserUuidNotEqualTo(String value) {
            addCriterion("out_user_uuid <>", value, "outUserUuid");
            return (Criteria) this;
        }

        public Criteria andOutUserUuidGreaterThan(String value) {
            addCriterion("out_user_uuid >", value, "outUserUuid");
            return (Criteria) this;
        }

        public Criteria andOutUserUuidGreaterThanOrEqualTo(String value) {
            addCriterion("out_user_uuid >=", value, "outUserUuid");
            return (Criteria) this;
        }

        public Criteria andOutUserUuidLessThan(String value) {
            addCriterion("out_user_uuid <", value, "outUserUuid");
            return (Criteria) this;
        }

        public Criteria andOutUserUuidLessThanOrEqualTo(String value) {
            addCriterion("out_user_uuid <=", value, "outUserUuid");
            return (Criteria) this;
        }

        public Criteria andOutUserUuidLike(String value) {
            addCriterion("out_user_uuid like", value, "outUserUuid");
            return (Criteria) this;
        }

        public Criteria andOutUserUuidNotLike(String value) {
            addCriterion("out_user_uuid not like", value, "outUserUuid");
            return (Criteria) this;
        }

        public Criteria andOutUserUuidIn(List<String> values) {
            addCriterion("out_user_uuid in", values, "outUserUuid");
            return (Criteria) this;
        }

        public Criteria andOutUserUuidNotIn(List<String> values) {
            addCriterion("out_user_uuid not in", values, "outUserUuid");
            return (Criteria) this;
        }

        public Criteria andOutUserUuidBetween(String value1, String value2) {
            addCriterion("out_user_uuid between", value1, value2, "outUserUuid");
            return (Criteria) this;
        }

        public Criteria andOutUserUuidNotBetween(String value1, String value2) {
            addCriterion("out_user_uuid not between", value1, value2, "outUserUuid");
            return (Criteria) this;
        }

        public Criteria andOutAccountUuidIsNull() {
            addCriterion("out_account_uuid is null");
            return (Criteria) this;
        }

        public Criteria andOutAccountUuidIsNotNull() {
            addCriterion("out_account_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andOutAccountUuidEqualTo(String value) {
            addCriterion("out_account_uuid =", value, "outAccountUuid");
            return (Criteria) this;
        }

        public Criteria andOutAccountUuidNotEqualTo(String value) {
            addCriterion("out_account_uuid <>", value, "outAccountUuid");
            return (Criteria) this;
        }

        public Criteria andOutAccountUuidGreaterThan(String value) {
            addCriterion("out_account_uuid >", value, "outAccountUuid");
            return (Criteria) this;
        }

        public Criteria andOutAccountUuidGreaterThanOrEqualTo(String value) {
            addCriterion("out_account_uuid >=", value, "outAccountUuid");
            return (Criteria) this;
        }

        public Criteria andOutAccountUuidLessThan(String value) {
            addCriterion("out_account_uuid <", value, "outAccountUuid");
            return (Criteria) this;
        }

        public Criteria andOutAccountUuidLessThanOrEqualTo(String value) {
            addCriterion("out_account_uuid <=", value, "outAccountUuid");
            return (Criteria) this;
        }

        public Criteria andOutAccountUuidLike(String value) {
            addCriterion("out_account_uuid like", value, "outAccountUuid");
            return (Criteria) this;
        }

        public Criteria andOutAccountUuidNotLike(String value) {
            addCriterion("out_account_uuid not like", value, "outAccountUuid");
            return (Criteria) this;
        }

        public Criteria andOutAccountUuidIn(List<String> values) {
            addCriterion("out_account_uuid in", values, "outAccountUuid");
            return (Criteria) this;
        }

        public Criteria andOutAccountUuidNotIn(List<String> values) {
            addCriterion("out_account_uuid not in", values, "outAccountUuid");
            return (Criteria) this;
        }

        public Criteria andOutAccountUuidBetween(String value1, String value2) {
            addCriterion("out_account_uuid between", value1, value2, "outAccountUuid");
            return (Criteria) this;
        }

        public Criteria andOutAccountUuidNotBetween(String value1, String value2) {
            addCriterion("out_account_uuid not between", value1, value2, "outAccountUuid");
            return (Criteria) this;
        }

        public Criteria andOutAccountNoIsNull() {
            addCriterion("out_account_no is null");
            return (Criteria) this;
        }

        public Criteria andOutAccountNoIsNotNull() {
            addCriterion("out_account_no is not null");
            return (Criteria) this;
        }

        public Criteria andOutAccountNoEqualTo(String value) {
            addCriterion("out_account_no =", value, "outAccountNo");
            return (Criteria) this;
        }

        public Criteria andOutAccountNoNotEqualTo(String value) {
            addCriterion("out_account_no <>", value, "outAccountNo");
            return (Criteria) this;
        }

        public Criteria andOutAccountNoGreaterThan(String value) {
            addCriterion("out_account_no >", value, "outAccountNo");
            return (Criteria) this;
        }

        public Criteria andOutAccountNoGreaterThanOrEqualTo(String value) {
            addCriterion("out_account_no >=", value, "outAccountNo");
            return (Criteria) this;
        }

        public Criteria andOutAccountNoLessThan(String value) {
            addCriterion("out_account_no <", value, "outAccountNo");
            return (Criteria) this;
        }

        public Criteria andOutAccountNoLessThanOrEqualTo(String value) {
            addCriterion("out_account_no <=", value, "outAccountNo");
            return (Criteria) this;
        }

        public Criteria andOutAccountNoLike(String value) {
            addCriterion("out_account_no like", value, "outAccountNo");
            return (Criteria) this;
        }

        public Criteria andOutAccountNoNotLike(String value) {
            addCriterion("out_account_no not like", value, "outAccountNo");
            return (Criteria) this;
        }

        public Criteria andOutAccountNoIn(List<String> values) {
            addCriterion("out_account_no in", values, "outAccountNo");
            return (Criteria) this;
        }

        public Criteria andOutAccountNoNotIn(List<String> values) {
            addCriterion("out_account_no not in", values, "outAccountNo");
            return (Criteria) this;
        }

        public Criteria andOutAccountNoBetween(String value1, String value2) {
            addCriterion("out_account_no between", value1, value2, "outAccountNo");
            return (Criteria) this;
        }

        public Criteria andOutAccountNoNotBetween(String value1, String value2) {
            addCriterion("out_account_no not between", value1, value2, "outAccountNo");
            return (Criteria) this;
        }

        public Criteria andInUserUuidIsNull() {
            addCriterion("in_user_uuid is null");
            return (Criteria) this;
        }

        public Criteria andInUserUuidIsNotNull() {
            addCriterion("in_user_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andInUserUuidEqualTo(String value) {
            addCriterion("in_user_uuid =", value, "inUserUuid");
            return (Criteria) this;
        }

        public Criteria andInUserUuidNotEqualTo(String value) {
            addCriterion("in_user_uuid <>", value, "inUserUuid");
            return (Criteria) this;
        }

        public Criteria andInUserUuidGreaterThan(String value) {
            addCriterion("in_user_uuid >", value, "inUserUuid");
            return (Criteria) this;
        }

        public Criteria andInUserUuidGreaterThanOrEqualTo(String value) {
            addCriterion("in_user_uuid >=", value, "inUserUuid");
            return (Criteria) this;
        }

        public Criteria andInUserUuidLessThan(String value) {
            addCriterion("in_user_uuid <", value, "inUserUuid");
            return (Criteria) this;
        }

        public Criteria andInUserUuidLessThanOrEqualTo(String value) {
            addCriterion("in_user_uuid <=", value, "inUserUuid");
            return (Criteria) this;
        }

        public Criteria andInUserUuidLike(String value) {
            addCriterion("in_user_uuid like", value, "inUserUuid");
            return (Criteria) this;
        }

        public Criteria andInUserUuidNotLike(String value) {
            addCriterion("in_user_uuid not like", value, "inUserUuid");
            return (Criteria) this;
        }

        public Criteria andInUserUuidIn(List<String> values) {
            addCriterion("in_user_uuid in", values, "inUserUuid");
            return (Criteria) this;
        }

        public Criteria andInUserUuidNotIn(List<String> values) {
            addCriterion("in_user_uuid not in", values, "inUserUuid");
            return (Criteria) this;
        }

        public Criteria andInUserUuidBetween(String value1, String value2) {
            addCriterion("in_user_uuid between", value1, value2, "inUserUuid");
            return (Criteria) this;
        }

        public Criteria andInUserUuidNotBetween(String value1, String value2) {
            addCriterion("in_user_uuid not between", value1, value2, "inUserUuid");
            return (Criteria) this;
        }

        public Criteria andInAccountUuidIsNull() {
            addCriterion("in_account_uuid is null");
            return (Criteria) this;
        }

        public Criteria andInAccountUuidIsNotNull() {
            addCriterion("in_account_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andInAccountUuidEqualTo(String value) {
            addCriterion("in_account_uuid =", value, "inAccountUuid");
            return (Criteria) this;
        }

        public Criteria andInAccountUuidNotEqualTo(String value) {
            addCriterion("in_account_uuid <>", value, "inAccountUuid");
            return (Criteria) this;
        }

        public Criteria andInAccountUuidGreaterThan(String value) {
            addCriterion("in_account_uuid >", value, "inAccountUuid");
            return (Criteria) this;
        }

        public Criteria andInAccountUuidGreaterThanOrEqualTo(String value) {
            addCriterion("in_account_uuid >=", value, "inAccountUuid");
            return (Criteria) this;
        }

        public Criteria andInAccountUuidLessThan(String value) {
            addCriterion("in_account_uuid <", value, "inAccountUuid");
            return (Criteria) this;
        }

        public Criteria andInAccountUuidLessThanOrEqualTo(String value) {
            addCriterion("in_account_uuid <=", value, "inAccountUuid");
            return (Criteria) this;
        }

        public Criteria andInAccountUuidLike(String value) {
            addCriterion("in_account_uuid like", value, "inAccountUuid");
            return (Criteria) this;
        }

        public Criteria andInAccountUuidNotLike(String value) {
            addCriterion("in_account_uuid not like", value, "inAccountUuid");
            return (Criteria) this;
        }

        public Criteria andInAccountUuidIn(List<String> values) {
            addCriterion("in_account_uuid in", values, "inAccountUuid");
            return (Criteria) this;
        }

        public Criteria andInAccountUuidNotIn(List<String> values) {
            addCriterion("in_account_uuid not in", values, "inAccountUuid");
            return (Criteria) this;
        }

        public Criteria andInAccountUuidBetween(String value1, String value2) {
            addCriterion("in_account_uuid between", value1, value2, "inAccountUuid");
            return (Criteria) this;
        }

        public Criteria andInAccountUuidNotBetween(String value1, String value2) {
            addCriterion("in_account_uuid not between", value1, value2, "inAccountUuid");
            return (Criteria) this;
        }

        public Criteria andInAccountNoIsNull() {
            addCriterion("in_account_no is null");
            return (Criteria) this;
        }

        public Criteria andInAccountNoIsNotNull() {
            addCriterion("in_account_no is not null");
            return (Criteria) this;
        }

        public Criteria andInAccountNoEqualTo(String value) {
            addCriterion("in_account_no =", value, "inAccountNo");
            return (Criteria) this;
        }

        public Criteria andInAccountNoNotEqualTo(String value) {
            addCriterion("in_account_no <>", value, "inAccountNo");
            return (Criteria) this;
        }

        public Criteria andInAccountNoGreaterThan(String value) {
            addCriterion("in_account_no >", value, "inAccountNo");
            return (Criteria) this;
        }

        public Criteria andInAccountNoGreaterThanOrEqualTo(String value) {
            addCriterion("in_account_no >=", value, "inAccountNo");
            return (Criteria) this;
        }

        public Criteria andInAccountNoLessThan(String value) {
            addCriterion("in_account_no <", value, "inAccountNo");
            return (Criteria) this;
        }

        public Criteria andInAccountNoLessThanOrEqualTo(String value) {
            addCriterion("in_account_no <=", value, "inAccountNo");
            return (Criteria) this;
        }

        public Criteria andInAccountNoLike(String value) {
            addCriterion("in_account_no like", value, "inAccountNo");
            return (Criteria) this;
        }

        public Criteria andInAccountNoNotLike(String value) {
            addCriterion("in_account_no not like", value, "inAccountNo");
            return (Criteria) this;
        }

        public Criteria andInAccountNoIn(List<String> values) {
            addCriterion("in_account_no in", values, "inAccountNo");
            return (Criteria) this;
        }

        public Criteria andInAccountNoNotIn(List<String> values) {
            addCriterion("in_account_no not in", values, "inAccountNo");
            return (Criteria) this;
        }

        public Criteria andInAccountNoBetween(String value1, String value2) {
            addCriterion("in_account_no between", value1, value2, "inAccountNo");
            return (Criteria) this;
        }

        public Criteria andInAccountNoNotBetween(String value1, String value2) {
            addCriterion("in_account_no not between", value1, value2, "inAccountNo");
            return (Criteria) this;
        }

        public Criteria andTransactionStatusIsNull() {
            addCriterion("transaction_status is null");
            return (Criteria) this;
        }

        public Criteria andTransactionStatusIsNotNull() {
            addCriterion("transaction_status is not null");
            return (Criteria) this;
        }

        public Criteria andTransactionStatusEqualTo(Byte value) {
            addCriterion("transaction_status =", value, "transactionStatus");
            return (Criteria) this;
        }

        public Criteria andTransactionStatusNotEqualTo(Byte value) {
            addCriterion("transaction_status <>", value, "transactionStatus");
            return (Criteria) this;
        }

        public Criteria andTransactionStatusGreaterThan(Byte value) {
            addCriterion("transaction_status >", value, "transactionStatus");
            return (Criteria) this;
        }

        public Criteria andTransactionStatusGreaterThanOrEqualTo(Byte value) {
            addCriterion("transaction_status >=", value, "transactionStatus");
            return (Criteria) this;
        }

        public Criteria andTransactionStatusLessThan(Byte value) {
            addCriterion("transaction_status <", value, "transactionStatus");
            return (Criteria) this;
        }

        public Criteria andTransactionStatusLessThanOrEqualTo(Byte value) {
            addCriterion("transaction_status <=", value, "transactionStatus");
            return (Criteria) this;
        }

        public Criteria andTransactionStatusIn(List<Byte> values) {
            addCriterion("transaction_status in", values, "transactionStatus");
            return (Criteria) this;
        }

        public Criteria andTransactionStatusNotIn(List<Byte> values) {
            addCriterion("transaction_status not in", values, "transactionStatus");
            return (Criteria) this;
        }

        public Criteria andTransactionStatusBetween(Byte value1, Byte value2) {
            addCriterion("transaction_status between", value1, value2, "transactionStatus");
            return (Criteria) this;
        }

        public Criteria andTransactionStatusNotBetween(Byte value1, Byte value2) {
            addCriterion("transaction_status not between", value1, value2, "transactionStatus");
            return (Criteria) this;
        }

        public Criteria andAuditOperatorIsNull() {
            addCriterion("audit_operator is null");
            return (Criteria) this;
        }

        public Criteria andAuditOperatorIsNotNull() {
            addCriterion("audit_operator is not null");
            return (Criteria) this;
        }

        public Criteria andAuditOperatorEqualTo(String value) {
            addCriterion("audit_operator =", value, "auditOperator");
            return (Criteria) this;
        }

        public Criteria andAuditOperatorNotEqualTo(String value) {
            addCriterion("audit_operator <>", value, "auditOperator");
            return (Criteria) this;
        }

        public Criteria andAuditOperatorGreaterThan(String value) {
            addCriterion("audit_operator >", value, "auditOperator");
            return (Criteria) this;
        }

        public Criteria andAuditOperatorGreaterThanOrEqualTo(String value) {
            addCriterion("audit_operator >=", value, "auditOperator");
            return (Criteria) this;
        }

        public Criteria andAuditOperatorLessThan(String value) {
            addCriterion("audit_operator <", value, "auditOperator");
            return (Criteria) this;
        }

        public Criteria andAuditOperatorLessThanOrEqualTo(String value) {
            addCriterion("audit_operator <=", value, "auditOperator");
            return (Criteria) this;
        }

        public Criteria andAuditOperatorLike(String value) {
            addCriterion("audit_operator like", value, "auditOperator");
            return (Criteria) this;
        }

        public Criteria andAuditOperatorNotLike(String value) {
            addCriterion("audit_operator not like", value, "auditOperator");
            return (Criteria) this;
        }

        public Criteria andAuditOperatorIn(List<String> values) {
            addCriterion("audit_operator in", values, "auditOperator");
            return (Criteria) this;
        }

        public Criteria andAuditOperatorNotIn(List<String> values) {
            addCriterion("audit_operator not in", values, "auditOperator");
            return (Criteria) this;
        }

        public Criteria andAuditOperatorBetween(String value1, String value2) {
            addCriterion("audit_operator between", value1, value2, "auditOperator");
            return (Criteria) this;
        }

        public Criteria andAuditOperatorNotBetween(String value1, String value2) {
            addCriterion("audit_operator not between", value1, value2, "auditOperator");
            return (Criteria) this;
        }

        public Criteria andAuditTimeIsNull() {
            addCriterion("audit_time is null");
            return (Criteria) this;
        }

        public Criteria andAuditTimeIsNotNull() {
            addCriterion("audit_time is not null");
            return (Criteria) this;
        }

        public Criteria andAuditTimeEqualTo(Date value) {
            addCriterion("audit_time =", value, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditTimeNotEqualTo(Date value) {
            addCriterion("audit_time <>", value, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditTimeGreaterThan(Date value) {
            addCriterion("audit_time >", value, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("audit_time >=", value, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditTimeLessThan(Date value) {
            addCriterion("audit_time <", value, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditTimeLessThanOrEqualTo(Date value) {
            addCriterion("audit_time <=", value, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditTimeIn(List<Date> values) {
            addCriterion("audit_time in", values, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditTimeNotIn(List<Date> values) {
            addCriterion("audit_time not in", values, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditTimeBetween(Date value1, Date value2) {
            addCriterion("audit_time between", value1, value2, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditTimeNotBetween(Date value1, Date value2) {
            addCriterion("audit_time not between", value1, value2, "auditTime");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionIsNull() {
            addCriterion("audit_opinion is null");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionIsNotNull() {
            addCriterion("audit_opinion is not null");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionEqualTo(String value) {
            addCriterion("audit_opinion =", value, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionNotEqualTo(String value) {
            addCriterion("audit_opinion <>", value, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionGreaterThan(String value) {
            addCriterion("audit_opinion >", value, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionGreaterThanOrEqualTo(String value) {
            addCriterion("audit_opinion >=", value, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionLessThan(String value) {
            addCriterion("audit_opinion <", value, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionLessThanOrEqualTo(String value) {
            addCriterion("audit_opinion <=", value, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionLike(String value) {
            addCriterion("audit_opinion like", value, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionNotLike(String value) {
            addCriterion("audit_opinion not like", value, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionIn(List<String> values) {
            addCriterion("audit_opinion in", values, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionNotIn(List<String> values) {
            addCriterion("audit_opinion not in", values, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionBetween(String value1, String value2) {
            addCriterion("audit_opinion between", value1, value2, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andAuditOpinionNotBetween(String value1, String value2) {
            addCriterion("audit_opinion not between", value1, value2, "auditOpinion");
            return (Criteria) this;
        }

        public Criteria andPayedOperatorIsNull() {
            addCriterion("payed_operator is null");
            return (Criteria) this;
        }

        public Criteria andPayedOperatorIsNotNull() {
            addCriterion("payed_operator is not null");
            return (Criteria) this;
        }

        public Criteria andPayedOperatorEqualTo(String value) {
            addCriterion("payed_operator =", value, "payedOperator");
            return (Criteria) this;
        }

        public Criteria andPayedOperatorNotEqualTo(String value) {
            addCriterion("payed_operator <>", value, "payedOperator");
            return (Criteria) this;
        }

        public Criteria andPayedOperatorGreaterThan(String value) {
            addCriterion("payed_operator >", value, "payedOperator");
            return (Criteria) this;
        }

        public Criteria andPayedOperatorGreaterThanOrEqualTo(String value) {
            addCriterion("payed_operator >=", value, "payedOperator");
            return (Criteria) this;
        }

        public Criteria andPayedOperatorLessThan(String value) {
            addCriterion("payed_operator <", value, "payedOperator");
            return (Criteria) this;
        }

        public Criteria andPayedOperatorLessThanOrEqualTo(String value) {
            addCriterion("payed_operator <=", value, "payedOperator");
            return (Criteria) this;
        }

        public Criteria andPayedOperatorLike(String value) {
            addCriterion("payed_operator like", value, "payedOperator");
            return (Criteria) this;
        }

        public Criteria andPayedOperatorNotLike(String value) {
            addCriterion("payed_operator not like", value, "payedOperator");
            return (Criteria) this;
        }

        public Criteria andPayedOperatorIn(List<String> values) {
            addCriterion("payed_operator in", values, "payedOperator");
            return (Criteria) this;
        }

        public Criteria andPayedOperatorNotIn(List<String> values) {
            addCriterion("payed_operator not in", values, "payedOperator");
            return (Criteria) this;
        }

        public Criteria andPayedOperatorBetween(String value1, String value2) {
            addCriterion("payed_operator between", value1, value2, "payedOperator");
            return (Criteria) this;
        }

        public Criteria andPayedOperatorNotBetween(String value1, String value2) {
            addCriterion("payed_operator not between", value1, value2, "payedOperator");
            return (Criteria) this;
        }

        public Criteria andPayedTimeIsNull() {
            addCriterion("payed_time is null");
            return (Criteria) this;
        }

        public Criteria andPayedTimeIsNotNull() {
            addCriterion("payed_time is not null");
            return (Criteria) this;
        }

        public Criteria andPayedTimeEqualTo(Date value) {
            addCriterion("payed_time =", value, "payedTime");
            return (Criteria) this;
        }

        public Criteria andPayedTimeNotEqualTo(Date value) {
            addCriterion("payed_time <>", value, "payedTime");
            return (Criteria) this;
        }

        public Criteria andPayedTimeGreaterThan(Date value) {
            addCriterion("payed_time >", value, "payedTime");
            return (Criteria) this;
        }

        public Criteria andPayedTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("payed_time >=", value, "payedTime");
            return (Criteria) this;
        }

        public Criteria andPayedTimeLessThan(Date value) {
            addCriterion("payed_time <", value, "payedTime");
            return (Criteria) this;
        }

        public Criteria andPayedTimeLessThanOrEqualTo(Date value) {
            addCriterion("payed_time <=", value, "payedTime");
            return (Criteria) this;
        }

        public Criteria andPayedTimeIn(List<Date> values) {
            addCriterion("payed_time in", values, "payedTime");
            return (Criteria) this;
        }

        public Criteria andPayedTimeNotIn(List<Date> values) {
            addCriterion("payed_time not in", values, "payedTime");
            return (Criteria) this;
        }

        public Criteria andPayedTimeBetween(Date value1, Date value2) {
            addCriterion("payed_time between", value1, value2, "payedTime");
            return (Criteria) this;
        }

        public Criteria andPayedTimeNotBetween(Date value1, Date value2) {
            addCriterion("payed_time not between", value1, value2, "payedTime");
            return (Criteria) this;
        }

        public Criteria andSignatureIsNull() {
            addCriterion("signature is null");
            return (Criteria) this;
        }

        public Criteria andSignatureIsNotNull() {
            addCriterion("signature is not null");
            return (Criteria) this;
        }

        public Criteria andSignatureEqualTo(String value) {
            addCriterion("signature =", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureNotEqualTo(String value) {
            addCriterion("signature <>", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureGreaterThan(String value) {
            addCriterion("signature >", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureGreaterThanOrEqualTo(String value) {
            addCriterion("signature >=", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureLessThan(String value) {
            addCriterion("signature <", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureLessThanOrEqualTo(String value) {
            addCriterion("signature <=", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureLike(String value) {
            addCriterion("signature like", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureNotLike(String value) {
            addCriterion("signature not like", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureIn(List<String> values) {
            addCriterion("signature in", values, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureNotIn(List<String> values) {
            addCriterion("signature not in", values, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureBetween(String value1, String value2) {
            addCriterion("signature between", value1, value2, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureNotBetween(String value1, String value2) {
            addCriterion("signature not between", value1, value2, "signature");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNull() {
            addCriterion("delete_flag is null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNotNull() {
            addCriterion("delete_flag is not null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagEqualTo(Byte value) {
            addCriterion("delete_flag =", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotEqualTo(Byte value) {
            addCriterion("delete_flag <>", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThan(Byte value) {
            addCriterion("delete_flag >", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThanOrEqualTo(Byte value) {
            addCriterion("delete_flag >=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThan(Byte value) {
            addCriterion("delete_flag <", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThanOrEqualTo(Byte value) {
            addCriterion("delete_flag <=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIn(List<Byte> values) {
            addCriterion("delete_flag in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotIn(List<Byte> values) {
            addCriterion("delete_flag not in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagBetween(Byte value1, Byte value2) {
            addCriterion("delete_flag between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotBetween(Byte value1, Byte value2) {
            addCriterion("delete_flag not between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("update_time is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("update_time is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("update_time =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("update_time <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("update_time >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("update_time >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("update_time <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("update_time <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("update_time in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("update_time not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("update_time between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("update_time not between", value1, value2, "updateTime");
            return (Criteria) this;
        }
    }

    /**
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}