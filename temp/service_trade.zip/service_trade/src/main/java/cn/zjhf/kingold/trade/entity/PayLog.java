package cn.zjhf.kingold.trade.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class PayLog implements Serializable {
    /**
     * 支付单号
     */
    private String payOrderId;

    /**
     * 支付类型（// 1-投标 2-满标 3-流标 4-还款 5-充值 6-提现 7-转账 8-用户信息）
     */
    private Integer payType;

    /**
     * 订单号
     */
    private String orderBillCode;

    /**
     * 支付序号
     */
    private Integer paySeq;

    /**
     * 支付状态
     */
    private Integer payStatus;

    /**
     * 支付请求内容
     */
    private String payRequest;

    /**
     * 支付响应内容
     */
    private String payResponse;

    /**
     * 支付请求时间
     */
    private Date payRequestTime;

    /**
     * 支付响应时间
     */
    private Date payResponseTime;

    private static final long serialVersionUID = 1L;

    public String getPayOrderId() {
        return payOrderId;
    }

    public void setPayOrderId(String payOrderId) {
        this.payOrderId = payOrderId;
    }

    public Integer getPayType() {
        return payType;
    }

    public void setPayType(Integer payType) {
        this.payType = payType;
    }

    public String getOrderBillCode() {
        return orderBillCode;
    }

    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    public Integer getPaySeq() {
        return paySeq;
    }

    public void setPaySeq(Integer paySeq) {
        this.paySeq = paySeq;
    }

    public Integer getPayStatus() {
        return payStatus;
    }

    public void setPayStatus(Integer payStatus) {
        this.payStatus = payStatus;
    }

    public String getPayRequest() {
        return payRequest;
    }

    public void setPayRequest(String payRequest) {
        this.payRequest = payRequest;
    }

    public String getPayResponse() {
        return payResponse;
    }

    public void setPayResponse(String payResponse) {
        this.payResponse = payResponse;
    }

    public Date getPayRequestTime() {
        return payRequestTime;
    }

    public void setPayRequestTime(Date payRequestTime) {
        this.payRequestTime = payRequestTime;
    }

    public Date getPayResponseTime() {
        return payResponseTime;
    }

    public void setPayResponseTime(Date payResponseTime) {
        this.payResponseTime = payResponseTime;
    }
}