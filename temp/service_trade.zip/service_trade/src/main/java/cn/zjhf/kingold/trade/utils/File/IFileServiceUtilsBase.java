package cn.zjhf.kingold.trade.utils.File;

import java.io.InputStream;

/**
 * Created by zhangyijie on 2017/7/24.
 */
public interface IFileServiceUtilsBase {

    /**
     * 上传文件
     *
     * @param fileName 原始文件名称(包含路径)
     * @return 访问地址
     */
    String uploadFile(String fileName);

    /**
     * 上传文件
     *
     * @param inputStream 原始文件数据流
     * @param sourceFileName 原始文件名称
     * @param secret 是是否可以公开访问
     * @return 访问地址
     *
     */
    String uploadFile(InputStream inputStream, String sourceFileName, boolean secret);

    /**
     * 获取阿里private 文件访问路径
     *
     * @param file 阿里文件访问全路径或者文件名
     * @return 1小时内有效访问地址
     *
     */
    String getAccessFileUrl(String file);
}
