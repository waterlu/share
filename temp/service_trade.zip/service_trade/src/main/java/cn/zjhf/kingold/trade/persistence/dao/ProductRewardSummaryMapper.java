package cn.zjhf.kingold.trade.persistence.dao;

import cn.zjhf.kingold.trade.entity.ProductRewardSummary;
import cn.zjhf.kingold.trade.entity.ProductRewardSummaryExample;
import cn.zjhf.kingold.trade.utils.WhereCondition;
import cn.zjhf.kingold.trade.vo.ProductRewardSummaryReportVO;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
@Mapper
public interface ProductRewardSummaryMapper {
    long countByExample(ProductRewardSummaryExample example);

    int deleteByExample(ProductRewardSummaryExample example);

    int deleteByPrimaryKey(Long productRewardSummaryUuid);

    int insert(ProductRewardSummary record);

    int insertSelective(ProductRewardSummary record);

    List<ProductRewardSummary> lstByCondition(WhereCondition condition);

    List<ProductRewardSummary> selectByExample(ProductRewardSummaryExample example);

    ProductRewardSummary selectByPrimaryKey(Long productRewardSummaryUuid);

    @Delete("DELETE FROM product_reward_summary WHERE product_uuid = #{productUuid}")
    void deleteByProductUuid(@Param("productUuid") String productUuid);

    @Select("SELECT Count(*) FROM product_reward_summary ${condition}")
    int lstCountByCondition(WhereCondition condition);

    @Select("SELECT  reward.product_reward_summary_uuid, reward.product_uuid, reward.product_code, reward.product_abbr_name, reward.product_type, " +
            "reward.product_establishment_date, reward.reward_count, reward.reward_clear_count, reward.financial_advisor_count, " +
            "reward.pretax_reward_amount, reward.pretax_platform_servicefee, reward.platform_servicefee_tax, reward.aftertax_platform_servicefee, " +
            "reward.exchange_manage_fee, reward.platform_income, reward.loan_time, reward.income_tax_audit_operator, reward.income_tax_audit_time, " +
            "reward.income_tax_audit_opinion, reward.income_tax_clear_operator, reward.income_tax_clear_time, reward.income_tax_clear_status, " +
            "reward.exchange_managefee_audit_operator, reward.exchange_managefee_audit_time, reward.exchange_managefee_audit_opinion, " +
            "reward.exchange_managefee_clear_operator, reward.exchange_managefee_clear_time, reward.exchange_managefee_clear_status, " +
            "reward.signature, reward.delete_flag, reward.product_period, reward.product_scale, reward.management_fee, reward.product_accumulation, " +
            "reward.platform_commission, reward.create_time, reward.update_time,product.product_issuer_name" +
            " FROM kingold_trade.product_reward_summary reward,kingold_product.product product ${condition}")
    @ResultMap("productRewardSummary")
    List<ProductRewardSummary> listByCondition(WhereCondition condition);

    @Select("SELECT Count(*) FROM kingold_trade.product_reward_summary reward,kingold_product.product product ${condition}")
    int listCountByCondition(WhereCondition condition);

    @Update("UPDATE product_reward_summary SET loan_time = #{loanTime} WHERE product_uuid = #{productUuid}")
    void updateLoanTime(@Param("productUuid") String productUuid, @Param("loanTime") Date loanTime);

    int updateByExampleSelective(@Param("record") ProductRewardSummary record, @Param("example") ProductRewardSummaryExample example);

    int updateByExample(@Param("record") ProductRewardSummary record, @Param("example") ProductRewardSummaryExample example);

    int updateByPrimaryKeySelective(ProductRewardSummary record);

    int updateByPrimaryKey(ProductRewardSummary record);


    /**
     * 计算加息券收益和产品加息收益时，需要先截取两位小数，然后再加和
     *
     * @param condition
     * @return
     */
    @Select("SELECT  reward.product_abbr_name,reward.product_establishment_date,pro.product_issuer_name,reward.product_period,fixed.annual_interest_show,fixed.increase_interest_rate,reward.product_accumulation," +
            "TRUNCATE (SUM(trade.expected_profit_amount - trade.marketing_rate_amount),2) AS clearProfitAmount,reward.exchange_manage_fee,reward.pretax_platform_servicefee," +
            "SUM(TRUNCATE(trade.order_amount * trade.coupon_interest_yield_rate * (CASE trade.coupon_interest_period WHEN 0 THEN trade.product_period ELSE trade.coupon_interest_period END) / 365,2)) AS couponInterestYieldProfit, " +
            "SUM(TRUNCATE(trade.marketing_rate_amount,2)) - SUM(TRUNCATE(trade.order_amount * trade.coupon_interest_yield_rate * (CASE trade.coupon_interest_period WHEN 0 THEN trade.product_period ELSE trade.coupon_interest_period END) / 365,2)) AS increaseInterestProfit," +
            "reward.pretax_reward_amount,TRUNCATE (SUM(trade.marketing_amount),2) AS marketingAmout" +
            " FROM kingold_trade.product_reward_summary reward,kingold_trade.trade_order trade,kingold_product.product pro,kingold_product.product_fixed_income fixed ${condition}")
    @ResultMap("productRewardSummaryReportVO")
    List<ProductRewardSummaryReportVO> getExpenditureDetailsReport(WhereCondition condition);

    @Select("SELECT Count(DISTINCT(reward.product_reward_summary_uuid)) FROM kingold_trade.product_reward_summary reward,kingold_trade.trade_order trade,kingold_product.product pro,kingold_product.product_fixed_income fixed ${condition}")
    int getExpenditureDetailsReportCount(WhereCondition condition);
}