package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.service_consumer.service.CoinServiceConsumer;
import cn.zjhf.kingold.service_consumer.service.UserServiceConsumer;
import cn.zjhf.kingold.trade.constant.*;
import cn.zjhf.kingold.trade.dto.CoinSendConditionDto;
import cn.zjhf.kingold.trade.dto.CouponSendConditionDto;
import cn.zjhf.kingold.trade.dto.MarketCampaignDto;
import cn.zjhf.kingold.trade.entity.CashCoupon;
import cn.zjhf.kingold.trade.entity.InVO.LstMarketCampaignConditionVO;
import cn.zjhf.kingold.trade.entity.InVO.MarketCampaignTriggerVO;
import cn.zjhf.kingold.trade.entity.InVO.MarketCampaignVO;
import cn.zjhf.kingold.trade.entity.MarketCampaign;
import cn.zjhf.kingold.trade.entity.OutVO.MarketCampaignItemListVO;
import cn.zjhf.kingold.trade.entity.TradeOrder;
import cn.zjhf.kingold.trade.entity.UserInfo;
import cn.zjhf.kingold.trade.persistence.dao.CashCouponMapper;
import cn.zjhf.kingold.trade.persistence.dao.CouponExtendRecordMapper;
import cn.zjhf.kingold.trade.persistence.dao.MarketCampaignMapper;
import cn.zjhf.kingold.trade.persistence.dao.TradeOrderMapper;
import cn.zjhf.kingold.trade.persistence.mq.message.GoldCoinMessage;
import cn.zjhf.kingold.trade.persistence.mq.producer.EstablishGoldCoinProducer;
import cn.zjhf.kingold.trade.service.ICashCouponService;
import cn.zjhf.kingold.trade.service.ICoinCouponService;
import cn.zjhf.kingold.trade.service.ICouponExtendRecordService;
import cn.zjhf.kingold.trade.service.IMarketCampaignService;
import cn.zjhf.kingold.trade.utils.*;
import cn.zjhf.kingold.trade.utils.Tuple.TwoTuple;
import com.alibaba.rocketmq.client.producer.SendResult;
import com.google.common.collect.ImmutableList;
import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * Created by zhangyijie on 2017/7/5.
 */
@Service
public class MarketCampaignServiceImpl implements IMarketCampaignService {
    protected static final Logger logger = LoggerFactory.getLogger(MarketCampaignServiceImpl.class);

    /**
     * 分享:可发放礼券数量
     */
    @Value("${share.count}")
    private Integer SHARE_COUNT;

    //活动状态：1未开始
    public static final int STATUS_INIT = 1;

    //活动状态：2进行中
    public static final int STATUS_ACTIVE = 2;

    //活动状态：3已结束
    public static final int STATUS_STOP = 3;

    //指定发放
    public static final int SPECIFIED_DISTRIBUTION_CODE = 99;

    @Autowired
    protected MarketCampaignMapper marketCampaignMapper;

    @Autowired
    protected ICouponExtendRecordService couponExtendRecordService;

    @Autowired
    protected CouponExtendRecordMapper couponExtendRecordMapper;

    @Autowired
    private TradeOrderMapper tradeOrderMapper;

    @Autowired
    private ICashCouponService cashCouponService;

    @Autowired
    private ICoinCouponService coinCouponService;

    @Autowired
    protected CashCouponMapper cashCouponMapper;

    @Autowired
    private UserServiceConsumer userServiceConsumer;

    @Autowired
    private CoinServiceConsumer coinServiceConsumer;

    @Autowired
    EstablishGoldCoinProducer establishGoldCoinProducer ;

    @Autowired
    private RedisTemplate redisTemplate;

    private int getMcCode() {
        WhereCondition where = new WhereCondition();
        where.setPage(1,1,"mc_id");

        List<MarketCampaign> items = marketCampaignMapper.lstByCondition(where);
        if((items != null) && (items.size() > 0)) {
            return items.get(0).getMcId();
        }

        return -1;
    }

    /**
     * 创建活动
     * @param marketCampaignVO
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public String establishMarketCampaign(MarketCampaignVO marketCampaignVO) throws BusinessException {
        marketCampaignVO.setMcStatus(STATUS_INIT);

        if((marketCampaignVO.getStartTime() == null) || (marketCampaignVO.getEndTime() == null) || (marketCampaignVO.getEndTime().getTime() <= marketCampaignVO.getStartTime().getTime())) {
            throw new BusinessException(TradeStatusMsg.MARKETCAMPAIGN_PAPAM_ERR, TradeStatusMsg.MARKETCAMPAIGN_PAPAM_ERR_MSG, false);
        }

        if((marketCampaignVO.getApplyScene() <= 0) || DataUtils.isEmpty(marketCampaignVO.getApplyCashCoupon())) {
            throw new BusinessException(TradeStatusMsg.MARKETCAMPAIGN_PAPAM_ERR, TradeStatusMsg.MARKETCAMPAIGN_PAPAM_ERR_MSG, false);
        }

        marketCampaignVO.setCreateTime(new Date());
        marketCampaignVO.setUpdateTime(new Date());
        marketCampaignVO.setUpdateUserId("sys");

        marketCampaignMapper.insert(marketCampaignVO.get());
        return "" + getMcCode();
    }

    /**
     * 更新活动
     * @param marketCampaignVO
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Boolean updateMarketCampaign(MarketCampaignVO marketCampaignVO) throws BusinessException {
        //避免覆盖处理
        MarketCampaignVO oldMarketCampaignVO = lstMarketCampaign(marketCampaignVO.getMcId());
        marketCampaignVO.setDeleteFlag(oldMarketCampaignVO.getDeleteFlag());
        marketCampaignVO.setCreateTime(oldMarketCampaignVO.getCreateTime());
        marketCampaignVO.setFrequencyLimit(oldMarketCampaignVO.getFrequencyLimit());

        return marketCampaignMapper.updateByPrimaryKeySelective(marketCampaignVO.get()) > 0;
    }

    /**
     * 查询活动
     * @param lstCondition
     * @return
     * @throws BusinessException
     */
    @Override
    public MarketCampaignItemListVO lstMarketCampaign(LstMarketCampaignConditionVO lstCondition) throws BusinessException {
        MarketCampaignItemListVO marketCampaignItemListVO = new MarketCampaignItemListVO();
        WhereCondition where = new WhereCondition();
        where.setCondi(" mc_id<90 ");
        marketCampaignItemListVO.setCount(marketCampaignMapper.lstCountByCondition(where));
        where.setPage(lstCondition.getBeginSN(), lstCondition.getEndSN(), "mc_id");
        List<MarketCampaign> list=marketCampaignMapper.lstByCondition(where);
        editApplyCashCoupon(list);
        marketCampaignItemListVO.setListEx(list);
        return marketCampaignItemListVO;
    }

    /**
     * 修改场景批次号为：批次号-名称
     * @param list
     * @throws BusinessException
     */
    private void editApplyCashCoupon(List<MarketCampaign> list) throws BusinessException {
        String applyCashCoupon="";
        for(MarketCampaign vo : list){
            List<String> rechargeBillCodeList = Arrays.asList(vo.getApplyCashCoupon().split("\\$\\$"));
            if(rechargeBillCodeList.size() > 0){
                for(int j=0;j<rechargeBillCodeList.size();j++){
                    if(rechargeBillCodeList.get(j) != null && !rechargeBillCodeList.get(j).equals("")){
                        CashCoupon cashCouponVO = cashCouponMapper.selectByPrimaryKey(rechargeBillCodeList.get(j));
                        if(cashCouponVO != null){
                            if(j==0){
                                applyCashCoupon=rechargeBillCodeList.get(j)+"-"+cashCouponVO.getCcName();
                            }else{
                                applyCashCoupon+=","+rechargeBillCodeList.get(j)+"-"+cashCouponVO.getCcName();
                            }
                            vo.setApplyCashCoupon(applyCashCoupon);
                        }
                    }
                }
            }
        }
    }

    /**
     * 查询单条活动
     * @param mcCode
     * @return
     * @throws BusinessException
     */
    @Override
    public MarketCampaignVO lstMarketCampaign(int mcCode) throws BusinessException {
        MarketCampaign marketCampaign = marketCampaignMapper.selectByPrimaryKey(mcCode);

        if(marketCampaign != null) {
            return new MarketCampaignVO(marketCampaign);
        } else {
            throw new BusinessException(TradeStatusMsg.MARKETCAMPAIGN_NOEXIST, TradeStatusMsg.MARKETCAMPAIGN_NOEXIST_MSG, false);
        }
    }

    /**
     * 自动状态刷新
     */
    @Override
    public void autoRefreshStatus() {
        WhereCondition where = new WhereCondition();
        where.setInInt("mc_status", STATUS_INIT, STATUS_ACTIVE);
        where.noDelete();
        List<MarketCampaign> marketCampaigns = marketCampaignMapper.lstByCondition(where);

        long curTime = System.currentTimeMillis();
        for(MarketCampaign marketCampaign: marketCampaigns) {
            if((marketCampaign!=null) && (marketCampaign.getStartTime()!=null) && (marketCampaign.getEndTime()!=null) && (marketCampaign.getMcId()!=null)) {
                long startTime = marketCampaign.getStartTime().getTime();
                long endTime = marketCampaign.getEndTime().getTime();

                if ((curTime > startTime) && (curTime < endTime)) {
                    marketCampaignMapper.updateStatus(marketCampaign.getMcId(), STATUS_ACTIVE);
                }

                if (curTime > endTime) {
                    marketCampaignMapper.updateStatus(marketCampaign.getMcId(), STATUS_STOP);
                }
            }
        }
    }

    private void checkCheckResult(TwoTuple<Boolean, String> checkResult) throws BusinessException {
        if((checkResult != null) && (checkResult.first == false)) {
            throw new BusinessException(ResponseCode.PARAM_ERROR, checkResult.second);
        }

        if(checkResult == null) {
            throw new BusinessException(ResponseCode.PARAM_ERROR, "其他错误");
        }
    }

    /**
     * 检查是否触发券
     * @param dto
     * @param marketCampaignVO
     * @return
     * @throws BusinessException
     */
    private Boolean checkMarketCampaignTrigger(CouponSendConditionDto dto, MarketCampaignVO marketCampaignVO) throws BusinessException {
        TwoTuple<Boolean, String> checkResult = null;

        //校验用户是否已经满足并领取过该场景下的礼券
        logger.info("校验用户是否已经满足并领取过该场景下的礼券");
        checkResult = checkUser(dto, marketCampaignVO);
        checkCheckResult(checkResult);

        //校验场景是否满足发放条件
        logger.info("校验场景是否满足发放条件");
        checkResult = checkScene(marketCampaignVO);
        checkCheckResult(checkResult);

        //校验礼券是否有有效的礼券批次
        logger.info("校验礼券是否有有效的礼券批次");
        checkResult = checkCoupon(marketCampaignVO);
        checkCheckResult(checkResult);

        return true;
    }

    /**
     * 各种活动领取礼券校验
     * @param dto
     * @param marketCampaignVO
     * @return
     * @throws BusinessException
     */
    private Boolean checkCampaignExchangeCoupon(CouponSendConditionDto dto, MarketCampaignVO marketCampaignVO) throws BusinessException {
        TwoTuple<Boolean, String> checkResult = null;

        //校验场景是否满足发放条件
        checkResult = checkScene(marketCampaignVO);
        checkCheckResult(checkResult);

        //校验用户是否已经满足并领取过该场景下的礼券
        checkResult = checkCampaignUser(dto, marketCampaignVO);
        checkCheckResult(checkResult);

        //校验礼券是否有有效的礼券批次
        checkResult = checkCoupon( marketCampaignVO);
        checkCheckResult(checkResult);

        return true;
    }

    /**
     * 触发活动
     * @param mcCode 场景编号
     * @param orderList 订单列表
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public List<String> marketCampaignTrigger(Integer mcCode, List<TradeOrder> orderList, Map<String, String> uuidPhoneNumMap) throws BusinessException {
        List<String> succPhoneNumList = new ArrayList<>();
        if((orderList==null) || (orderList.size()==0)) {
            logger.error("订单列表为null或者无记录");
            return succPhoneNumList;
        }

        MarketCampaignVO marketCampaign = null;
        try {
            marketCampaign = getVaildMarketCampaign(mcCode);
        }catch(BusinessException e){
            String errMess = "场景不存在或已失效";
            logger.error(errMess, e);
            return succPhoneNumList;
        }

        if (marketCampaign != null) {
            if (marketCampaign.getApplyCashCoupon() != null) {
                List<String> cashCouponCodes = DataUtils.split(marketCampaign.getApplyCashCoupon());
                for (String cashCouponCode : cashCouponCodes) {
                    for (TradeOrder order : orderList) {
                        try {
                            //不是金疙瘩渠道的订单不发券
                            if (BizDefine.KINGOLD_MERCHANT.equals(order.getBelongMerchantNum())) {
                                String couponExtendRecordNo = coinCouponService.establishCoinExtendRecord(order
                                        .getUserUuid(), cashCouponCode, marketCampaign.getApplyScene().byteValue());


                                //确实发券成功，添加发放成功的手机号列表
                                if (DataUtils.isNotEmpty(couponExtendRecordNo)) {
                                    succPhoneNumList.add(uuidPhoneNumMap.get(order.getUserUuid()));
                                }
                            }
                        } catch (BusinessException e) {
                            logger.error("BusinessException:", e);
                        }
                    }
                }
            }
        } else {
            logger.error("场景{}为空", mcCode);
        }

        return succPhoneNumList;
    }

    /**
     * 触发活动
     * @param dto
     * @return
     * Integer 1成功；-1失败
     * String message
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public TwoTuple<Integer, String> marketCampaignTrigger(CouponSendConditionDto dto) throws BusinessException {
        logger.info("marketCampaignTrigger start; " + DataUtils.toString(dto.toString()));

        MarketCampaignVO marketCampaignVO = null;

        try {
            marketCampaignVO = lstMarketCampaign(dto.getMcCode());
        }catch(BusinessException e){
            String errMess = "获取活动失败";
            logger.error(errMess, e);
            return new TwoTuple<Integer, String>(-1, errMess);
        }

        TwoTuple<Integer, String> result = new TwoTuple<Integer, String>(1, "成功");
        //送金币
        if(Byte.valueOf("1").equals(marketCampaignVO.getIsCoin())){
            this.campaignCoin(dto.getMcCode(),dto.getUserUuid());
        }
        //送券
        if(StringUtils.isNotBlank(marketCampaignVO.getApplyCashCoupon())){
            checkMarketCampaignTrigger(dto, marketCampaignVO);
            logger.info("实际发放礼券");
            result = couponExtendRecordService.establishCouponExtendRecord(dto, marketCampaignVO);
            logger.info("marketCampaignTrigger end; " + DataUtils.toString(result.toString()));
        }


        return result;
    }

    /**
     * 礼券发放校验
     * @param conditionDto
     * @return
     * @throws BusinessException
     */
    @Override
    public Boolean checkCouponSend(CouponSendConditionDto conditionDto)throws BusinessException {
        logger.info("checkCouponSend start {}", conditionDto);
        //校验参数是否为空
        if(DataUtils.isEmpty(conditionDto.getUserUuid()) || conditionDto.getMcCode() <= 0){
            return false;
        }
        Integer mcCode=conditionDto.getMcCode();
        if(mcCode == MarketCampaignCodeEnum.FRIEND_FIRST_INVEST.getCode()  && DataUtils.isEmpty(conditionDto.getOrderBillCode())){
            return false;
        }
        if(mcCode == MarketCampaignCodeEnum.BEING_INVITED_REGISTER.getCode() && DataUtils.isEmpty(conditionDto.getInvitedUserUuid())){
            return false;
        }
        MarketCampaignVO marketCampaignVO = null;
        try {
            marketCampaignVO = lstMarketCampaign(mcCode);
        }catch(BusinessException e){
            String errMess = "获取活动失败";
            logger.error(errMess, e);
            return false;
        }

        try {
            checkMarketCampaignTrigger(conditionDto, marketCampaignVO);
        }catch(BusinessException e){
            logger.error("获取活动失败", e);
            return false;
        }

        return true;
    }

    /**
     * 获取场景信息
     * @param mcCode
     * @return
     */
    @Override
    public MarketCampaignVO getVaildMarketCampaign(Integer mcCode)throws BusinessException {
        MarketCampaignVO marketCampaignVO = lstMarketCampaign(mcCode);

        TwoTuple<Boolean, String> checkResult = checkScene(marketCampaignVO);
        if((checkResult!=null) && (checkResult.first==true)) {
            return marketCampaignVO;
        }

        return null;
    }

    //校验场景是否满足发放条件
    public TwoTuple<Boolean, String> checkScene(MarketCampaignVO marketCampaignVO){
        Integer mcCode=marketCampaignVO.getApplyScene();
        if((null == marketCampaignVO) || (marketCampaignVO.getMcStatus() == STATUS_STOP) || (marketCampaignVO.getMcStatus() == STATUS_INIT)) {
            String errMess = "活动" + mcCode + "不存在或已结束";
            logger.error(errMess);
            return new TwoTuple<Boolean, String>(false, errMess);
        }
        if((marketCampaignVO.getStartTime() == null) || (marketCampaignVO.getEndTime() == null)) {
            String errMess = "活动" + mcCode + "开始或结束时间未设置或设置错误";
            logger.error(errMess);
            return new TwoTuple<Boolean, String>(false, errMess);
        }
        long curTime = new Date().getTime();//当前时间
        long startTime = marketCampaignVO.getStartTime().getTime();//预计开始时间
        long endTime = marketCampaignVO.getEndTime().getTime();//预计结束时间
        if((curTime < startTime) || (curTime > endTime)) {
            String errMess = "活动" + mcCode + "尚未开始或已经结束";
            logger.error(errMess);
            return new TwoTuple<Boolean, String>(false, errMess);
        }
        if(mcCode == MarketCampaignCodeEnum.REPEATED_INVESTMENT.getCode() || mcCode == MarketCampaignCodeEnum.FIRST_INVEST.getCode() || mcCode == MarketCampaignCodeEnum.FRIEND_FIRST_INVEST.getCode()){
            if(marketCampaignVO.getInvestigateStartTime() != null && marketCampaignVO.getInvestigateEndTime() != null){
                long investigateStartTime = marketCampaignVO.getInvestigateStartTime().getTime();//考察开始时间
                long investigateEndTime = marketCampaignVO.getInvestigateEndTime().getTime();//考察结束时间

                if(investigateStartTime > investigateEndTime) {
                    String errMess = "活动" + mcCode + "考察时间设置错误";
                    logger.error(errMess);
                    return new TwoTuple<Boolean, String>(false, errMess);
                }
                if(investigateStartTime > curTime || investigateEndTime < curTime) {
                    String errMess = "活动" + mcCode + "请求不在考察期内";
                    logger.error(errMess);
                    return new TwoTuple<Boolean, String>(false, errMess);
                }
            }
            if(marketCampaignVO.getInvestigateStartTime() != null && marketCampaignVO.getInvestigateEndTime() == null){
                long investigateStartTime = marketCampaignVO.getInvestigateStartTime().getTime();//考察开始时间
                if(investigateStartTime > curTime) {
                    String errMess = "活动" + mcCode + "请求不在考察期内";
                    logger.error(errMess);
                    return new TwoTuple<Boolean, String>(false, errMess);
                }
            }
            if(marketCampaignVO.getInvestigateEndTime() != null && marketCampaignVO.getInvestigateStartTime() == null){
                long investigateEndTime = marketCampaignVO.getInvestigateEndTime().getTime();//考察结束时间
                if(investigateEndTime < curTime) {
                    String errMess = "活动" + mcCode + "请求不在考察期内";
                    logger.error(errMess);
                    return new TwoTuple<Boolean, String>(false, errMess);
                }
            }
        }
        return new TwoTuple<Boolean, String>(true,"OK");
    }

    //校验用户是否已经满足并领取过该场景下的礼券
    public TwoTuple<Boolean, String> checkUser(CouponSendConditionDto conditionDto, MarketCampaignVO marketCampaignVO){
        logger.info("checkUser: " + marketCampaignVO.getApplyScene());
        if(MarketCampaignCodeEnum.isInvited(marketCampaignVO.getApplyScene())) {
            return new TwoTuple<Boolean, String>(true, "OK");
        }

        String userUuid = conditionDto.getUserUuid();
        String orderBillCode = conditionDto.getOrderBillCode();
        if (DataUtils.byteToInt(marketCampaignVO.getFrequencyLimit()) == 1) {
            //判断用户是否已经参加过该活动
            WhereCondition where = new WhereCondition();
            where.setCondi("user_uuid", userUuid);
            where.setCondi("apply_scene", marketCampaignVO.getApplyScene());
            if (couponExtendRecordMapper.lstByCondition(where).size() > 0) {
                String errMess = "用户" + userUuid + "已经领取过场景" + marketCampaignVO.getApplyScene() + "的现金券";
                logger.error(errMess);
                return new TwoTuple<Boolean, String>(false, errMess);
            }
        } else {
            if(marketCampaignVO.getApplyScene()!= MarketCampaignCodeEnum.REPEATED_INVESTMENT.getCode() && marketCampaignVO.getApplyScene()!= MarketCampaignCodeEnum.SHARE.getCode()){
                WhereCondition where = new WhereCondition();
                where.setCondi("user_uuid", userUuid);
                where.setCondi("order_bill_code", orderBillCode);
                where.setCondi("apply_scene", marketCampaignVO.getApplyScene());
                where.setCondi("invited_user_uuid", conditionDto.getInvitedUserUuid(),true);
                if (couponExtendRecordMapper.lstCountRecord(where) > 0) {
                    String errMess = "用户" + userUuid + "已经使用过流水号" + orderBillCode;
                    logger.error(errMess);
                    return new TwoTuple<Boolean, String>(false, errMess);
                }
            }else if(marketCampaignVO.getApplyScene() == MarketCampaignCodeEnum.REPEATED_INVESTMENT.getCode()){
                //1.获取场景
                //2.获取场景对应时间段内的该用户的订单
                Map<String, Object> param =new HashedMap();
                param.put("userUuid",userUuid);
                if(marketCampaignVO.getInvestigateStartTime() != null && marketCampaignVO.getInvestigateEndTime() == null){
                    param.put("payedTimeFrom",marketCampaignVO.getInvestigateStartTime());//订单支付时间--对应场景考察开始时间
                    param.put("payedTimeTo",marketCampaignVO.getEndTime());//订单支付时间--对应场景考察开始时间
                }else if(marketCampaignVO.getInvestigateStartTime() == null && marketCampaignVO.getInvestigateEndTime() != null){
                    param.put("payedTimeFrom",marketCampaignVO.getStartTime());//订单支付时间--对应场景考察开始时间
                    param.put("payedTimeTo",marketCampaignVO.getInvestigateEndTime());//订单支付时间--对应场景考察开始时间
                }else if(marketCampaignVO.getInvestigateStartTime() != null && marketCampaignVO.getInvestigateEndTime() != null){
                    param.put("payedTimeFrom",marketCampaignVO.getInvestigateStartTime());//订单支付时间--对应场景考察开始时间
                    param.put("payedTimeTo",marketCampaignVO.getInvestigateEndTime());//订单支付时间--对应场景考察开始时间
                }
                List<Integer> orderStatus = ImmutableList.of(TradeStatus.ORDER_STATUS_INVEST, TradeStatus.ORDER_STATUS_REFUND, TradeStatus.ORDER_STATUS_LOAN, TradeStatus.ORDER_STATUS_RETURN);
                param.put("orderStatusList", orderStatus);
                param.put("deleteFlag", 0);
                Integer orderCount = tradeOrderMapper.getCount(param);
                if (orderCount > (marketCampaignVO.getRecastCount() + 1)) {
                    String errMess = "用户" + userUuid + "已经使用过流水号" + orderBillCode;
                    logger.error(errMess);
                    return new TwoTuple<Boolean, String>(false, errMess);
                }
                if(orderCount <= 1) {
                    String errMess = "用户" + userUuid + "不满足复投条件";
                    logger.error(errMess);
                    return new TwoTuple<Boolean, String>(false, errMess);
                }
            }else if(marketCampaignVO.getApplyScene() == MarketCampaignCodeEnum.SHARE.getCode()){
                UserInfo userInfo = new UserInfo(conditionDto.getUserUuid(),"","");
                Integer shareCount = 0;
                try {
                    shareCount = couponExtendRecordService.getRecordShareCount(userInfo,marketCampaignVO);
                }catch (BusinessException e){
                    logger.error("查询失败", e);
                }
                if (shareCount >= SHARE_COUNT) {
                    String errMess = "用户" + userUuid + "已经领取过场景" + marketCampaignVO.getApplyScene() + "的现金券";
                    logger.error(errMess);
                    return new TwoTuple<Boolean, String>(false, errMess);
                }
            }
        }
        return new TwoTuple<Boolean, String>(true, "OK");
    }

    /**
     * 校验礼券是否有效（5个礼券，有一个有效，视为有效）
     * @param marketCampaignVO
     * @return
     */
    public TwoTuple<Boolean, String> checkCoupon(MarketCampaignVO marketCampaignVO){
        Integer recordCouont = 0;
        List<String> cashCouponCodes = DataUtils.split(marketCampaignVO.getApplyCashCoupon());
        for (String cashCouponCode : cashCouponCodes) {
            cashCouponCode = cashCouponCode.trim();
            if (DataUtils.isNotEmpty(cashCouponCode)) {
                try {
                    CashCoupon cashCoupon = cashCouponService.lstValidCashCoupon(cashCouponCode);
                    if(cashCoupon != null){
                        recordCouont ++;
                    }else {
                        logger.error(cashCouponCode + "批次无效或为空");
                    }
                }catch (BusinessException e){
                    String errMess = "获取礼券失败";
                    logger.error(errMess, e);
                }
            }
        }
        if(recordCouont == 0){
            return new TwoTuple<Boolean, String>(false, "没有关联有限的礼券批次");
        }
        return new TwoTuple<Boolean, String>(true, "关联的礼券有效");
    }

    /**
     * 活动兑换礼券校验
     * @param marketCampaignTriggerVO
     * @return
     * @throws BusinessException
     */
    @Override
    public void campaignExchangeCoupon(MarketCampaignTriggerVO marketCampaignTriggerVO)throws BusinessException {
        CouponSendConditionDto conditionDto = new CouponSendConditionDto();
        Integer mcCode = marketCampaignTriggerVO.getMcCode();
        conditionDto.setMcCode(mcCode);
        conditionDto.setUserUuid(marketCampaignTriggerVO.getUserUuid());
        MarketCampaignVO marketCampaignVO = lstMarketCampaign(mcCode);
        //送券
        if(StringUtils.isNotBlank(marketCampaignVO.getApplyCashCoupon())){
            checkCampaignExchangeCoupon(conditionDto, marketCampaignVO);
            this.couponExtendRecordService.campaignExchangeCouponExtendRecord(marketCampaignTriggerVO, marketCampaignVO);
        }
//        //送金币
//        if(Byte.valueOf("1").equals(marketCampaignVO.getIsCoin())){
//            this.campaignCoin(marketCampaignTriggerVO);
//        }

    }

    /**
     * 金币发放 （送金币业务）
     * @param
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = {BusinessException.class, RuntimeException.class})
    public void campaignCoin(int mcCode, String userUuid) throws BusinessException {
        logger.info("campaignCoin start mcCode_userUuid: {}", mcCode +"_"+userUuid);
        //MarketCampaignVO marketCampaignVO = lstMarketCampaign(mcCode);
        MarketCampaignVO marketCampaignVO = getVaildMarketCampaign(mcCode);
        logger.info("Step1 getVaildMarketCampaign: " + DataUtils.toString(marketCampaignVO));

        if(marketCampaignVO == null) {
            throw new BusinessException(TradeStatusMsg.MARKETCAMPAIGN_NOEXIST, TradeStatusMsg.MARKETCAMPAIGN_NOEXIST_MSG, false);
        }

        //校验参数是否为空
        if(DataUtils.isEmpty(userUuid) || mcCode <= 0){
            throw new BusinessException(TradeStatusMsg.MARKETCAMPAIGN_PAPAM_ERR, TradeStatusMsg.MARKETCAMPAIGN_PAPAM_ERR_MSG, false);
        }
        //isCoin 必须是 1
        if(!Byte.valueOf("1").equals(marketCampaignVO.getIsCoin())) {
            throw new BusinessException(TradeStatusMsg.MARKETCAMPAIGN_ISCOIN_ERR, TradeStatusMsg.MARKETCAMPAIGN_ISCOIN_ERR_MSG, false);
        }

        //设置marketCampaignVO 中 当日发送数
        logger.info("Step2 setUserCoinMarketNum start");
        setUserCoinMarketNum(marketCampaignVO,DateUtil.formateDate(new Date()),userUuid);
        logger.info("Step2 setUserCoinMarketNum end");
        //检查当前用户当日是否还能发送
        if(marketCampaignVO.getCoinTaskCompleteNum() >= marketCampaignVO.getCoinTaskLimit()){
            logger.info("{} today had send num is :{}. the coinTaskLimit is :{}", userUuid, marketCampaignVO
                    .getCoinTaskCompleteNum(), marketCampaignVO.getCoinTaskLimit());
            return;
        }

        logger.info("Step3 getUserInfo");
        UserInfo userInfo = getUserInfo(userUuid);
        logger.info("Step4 getCoinTaskAmount");
        Integer coinTaskAmount = marketCampaignVO.getCoinTaskAmount();
        if("12".equals(userInfo.getInvestorType())){
//            检查用户是否是达人，如果是达人，发送达人金币数量
            coinTaskAmount = marketCampaignVO.getCoinTaskDrAmount() == null ? marketCampaignVO.getCoinTaskAmount(): marketCampaignVO.getCoinTaskDrAmount() ;
        }
//        当前用户当日发送数量加一
//        logger.info("Step5 当前用户当日发送数量加一");
//        incrUserCoinMarketNum(marketCampaignVO,DateUtil.formateDate(new Date()),userUuid);
        //调用发送金币MQ
        //mq的key 规则:applyScene_userUUid_YYYY-MM-DD_coinTaskCompleteNum
//        String key = marketCampaignVO.getApplyScene() + "_"+userUuid + "_"+DateUtil.formateDate(new Date())+ "_" + marketCampaignVO.getCoinTaskCompleteNum();
        GoldCoinMessage goldCoinMessage = new GoldCoinMessage();
        goldCoinMessage.setGcUuid(UUIDKeyUtils.getUuidKey());
        goldCoinMessage.setKey(UUIDKeyUtils.getUuidKey());
        goldCoinMessage.setGcCreateUserUuid(userUuid);
        goldCoinMessage.setGcApplyScene(marketCampaignVO.getApplyScene());
        goldCoinMessage.setGcTotalAmount(new BigDecimal(coinTaskAmount));
        //计算当前批次金币的激活时间
        int afterHour = marketCampaignVO.getCoinTaskAfterHour()== null ? 0 : marketCampaignVO.getCoinTaskAfterHour();
        Calendar ca=Calendar.getInstance();
        ca.setTime(new Date());
        ca.add(Calendar.HOUR_OF_DAY, afterHour);
        goldCoinMessage.setGcActiveTime(ca.getTime());
        logger.info("Step6 establishGoldCoinProducer.send start: {}", goldCoinMessage);
        SendResult sendResult = establishGoldCoinProducer.send(goldCoinMessage);
        logger.info("Step6 establishGoldCoinProducer.send end: {}", sendResult);
    }

    /**
     * 获取用户信息
     *
     * @param userUuid
     * @return
     * @throws BusinessException
     */
    protected UserInfo getUserInfo(String userUuid) throws BusinessException {
        Map params = new HashMap();
        params.put("properties", "userUuid$$userType$$investorMobile$$investorRealName$$investorIdCardNo$$investorType"
                + "$$investorOrganizationPath$$investorOrganizationUuid$$userStatus$$userVerifyStatus$$issuerName$$legalPersonName");
        logger.info("getUserInfo start:-----");
        ResponseResult result = userServiceConsumer.get(String.format(URL.URL_GET_USER, userUuid), params);
        logger.info("getUserInfo result: {}", DataUtils.toString(result));
        if (result.isSuccessful()) {
            if(result.getData() instanceof Map) {
                return new UserInfo((Map)result.getData());
            }else {
                return null;
            }
        } else if (result.getCode() == 1109) {//用户被冻结
            return null;
        } else {
            logger.error("get user info error:{},{}", result.getCode(), result.getMsg());
            return null;
        }
    }


    /**
     * 金币发放校验 （谢晓杰）
     * @param conditionDto
     * @return
     * @throws BusinessException
     */
    @Override
    public Boolean checkCoinSend(CoinSendConditionDto conditionDto) throws BusinessException {
        logger.info("checkCoinSend start {}", conditionDto);
        //校验参数是否为空
        if(DataUtils.isEmpty(conditionDto.getUserUuid()) || conditionDto.getMcCode() <= 0){
            return false;
        }
        if(!checkUserCoinReceive(conditionDto)){
            return false;
        }
        return true;
    }


    /**
     * 判断用户是否以满足金币发放条件
     * @param conditionDto
     * @return
     */
    private Boolean checkUserCoinReceive(CoinSendConditionDto conditionDto){
        ResponseResult responseResult;
        Integer count= 0;
        Map<String, Object> param = new HashMap<>(5);
        param.put("ctType", CoinTransTypeEnum.ADD.getCode());
        param.put("userUuid", conditionDto.getUserUuid());
        Date nowDate=new Date();
        String formatDate=DateUtil.formateDate(nowDate,DateUtil.DAY_FROMAT);
        //当天凌晨
        Date startDate=DateUtil.strToDate(DateUtil.stringAppendStratTime(formatDate),DateUtil.CURRENTTIME_FORMAT);
        //当天中午12点
        Date middleDate= DateUtil.strToDate(DateUtil.stringAppendMiddleTime(formatDate),DateUtil.CURRENTTIME_FORMAT);
        //第二天凌晨
        Date nextDate=StringOrDate.dateOffsetDay(startDate, 1);
        String startDateStr= DateUtil.stringAppendStratTime(formatDate);
        String middleDateStr=DateUtil.stringAppendMiddleTime(formatDate);
        String nextDateStr=DateUtil.formateDate(nextDate,DateUtil.CURRENTTIME_FORMAT);
        if(MarketCampaignCodeEnum.EVERYDAY_SIGN.getCode().equals(conditionDto.getMcCode())){
            param.put("ctApplyScene", MarketCampaignCodeEnum.EVERYDAY_SIGN.getCode());
            if(nowDate.after(middleDate)){
                param.put("startDate", middleDateStr);
                param.put("endDate", nextDateStr);
            }else{
                param.put("startDate",startDateStr);
                param.put("endDate", middleDateStr);
            }
        }else  if(MarketCampaignCodeEnum.BEING_INVITED_REGISTER.getCode().equals(conditionDto.getMcCode())){
            param.put("startDate",startDateStr);
            param.put("endDate", nextDateStr);
            param.put("ctApplyScene", MarketCampaignCodeEnum.BEING_INVITED_REGISTER.getCode());
        }else  if(MarketCampaignCodeEnum.SHARE.getCode().equals(conditionDto.getMcCode())){
            param.put("startDate",startDateStr);
            param.put("endDate", nextDateStr);
            param.put("ctApplyScene", MarketCampaignCodeEnum.SHARE.getCode());
        }
        try {
            responseResult=coinServiceConsumer.get(URL.URL_GET_COIN_TRANSACTION_COUNT,param);
            count=coinServiceConsumer.getData(responseResult,Integer.class);
        }catch (Exception e){
            logger.error("checkUserCoinReceive error{}",e);
        }
        if(MarketCampaignCodeEnum.EVERYDAY_SIGN.getCode().equals(conditionDto.getMcCode()) && count > 0){
            return false;
        }else  if(MarketCampaignCodeEnum.BEING_INVITED_REGISTER.getCode().equals(conditionDto.getMcCode()) && count > 200){
            return false;
        }else  if(MarketCampaignCodeEnum.SHARE.getCode().equals(conditionDto.getMcCode()) && count > 20){
            return false;
        }
        return true;
    }

    /**
     * 设置用户对应场景每日已完成次数
     * @param dateString 拼接场景对应hash key 格式是yyyy-mm-dd
     * @param userUuid map对应key
     */
    private void setUserCoinMarketNum(MarketCampaignVO marketCampaignVO, String dateString, String userUuid){
        //计算当天还剩的秒数
        LocalDateTime midnight = LocalDateTime.now().plusDays(1).withHour(0).withMinute(0).withSecond(0).withNano(0);
        long millSeconds = ChronoUnit.MILLIS.between(LocalDateTime.now(), midnight);
        Object coinTaskCompleteNum = 0;
        if (marketCampaignVO.getApplyScene() == MarketCampaignCodeEnum.EVERYDAY_SIGN.getCode()){
            coinTaskCompleteNum = redisTemplate.opsForHash().get(MarketRedisKey.COIN_TASK_LOGIN + dateString, userUuid);
            redisTemplate.expire(MarketRedisKey.COIN_TASK_LOGIN + dateString, millSeconds, TimeUnit.MILLISECONDS);
        }
        if (marketCampaignVO.getApplyScene() == MarketCampaignCodeEnum.BEING_INVITED_REGISTER.getCode()){
            coinTaskCompleteNum = redisTemplate.opsForHash().get(MarketRedisKey.COIN_TASK_FRIEND_REGISTER + dateString, userUuid);
            redisTemplate.expire(MarketRedisKey.COIN_TASK_FRIEND_REGISTER + dateString, millSeconds, TimeUnit.MILLISECONDS);
        }
        if (marketCampaignVO.getApplyScene() == MarketCampaignCodeEnum.FRIEND_INVEST.getCode()){
            coinTaskCompleteNum = redisTemplate.opsForHash().get(MarketRedisKey.COIN_TASK_FRIEND_INVEST + dateString, userUuid);
            redisTemplate.expire(MarketRedisKey.COIN_TASK_FRIEND_INVEST + dateString, millSeconds, TimeUnit.MILLISECONDS);
        }
        if (marketCampaignVO.getApplyScene() == MarketCampaignCodeEnum.SELF_INVEST.getCode()){
            coinTaskCompleteNum = redisTemplate.opsForHash().get(MarketRedisKey.COIN_TASK_INVEST + dateString, userUuid);
            redisTemplate.expire(MarketRedisKey.COIN_TASK_INVEST + dateString, millSeconds, TimeUnit.MILLISECONDS);
        }
        marketCampaignVO.setCoinTaskCompleteNum(coinTaskCompleteNum == null ? 0 : Integer.valueOf(coinTaskCompleteNum.toString()));
    }

    /**
     * 用户对应场景每日已完成次数自增一
     * @param dateString 拼接场景对应hash key 格式是yyyy-mm-dd
     * @param userUuid map对应key
     */
    private void incrUserCoinMarketNum(MarketCampaignVO marketCampaignVO, String dateString, String userUuid){
        Object coinTaskCompleteNum = 0;
        if (marketCampaignVO.getApplyScene() == MarketCampaignCodeEnum.EVERYDAY_SIGN.getCode()){
            coinTaskCompleteNum = redisTemplate.opsForHash().increment(MarketRedisKey.COIN_TASK_LOGIN + dateString, userUuid,1);
        }
        if (marketCampaignVO.getApplyScene() == MarketCampaignCodeEnum.BEING_INVITED_REGISTER.getCode()){
            coinTaskCompleteNum = redisTemplate.opsForHash().increment(MarketRedisKey.COIN_TASK_FRIEND_REGISTER + dateString, userUuid,1);
        }
        if (marketCampaignVO.getApplyScene() == MarketCampaignCodeEnum.FRIEND_INVEST.getCode()){
            coinTaskCompleteNum = redisTemplate.opsForHash().increment(MarketRedisKey.COIN_TASK_FRIEND_INVEST + dateString, userUuid,1);
        }
        if (marketCampaignVO.getApplyScene() == MarketCampaignCodeEnum.SELF_INVEST.getCode()){
            coinTaskCompleteNum = redisTemplate.opsForHash().increment(MarketRedisKey.COIN_TASK_INVEST + dateString, userUuid,1);
        }
        marketCampaignVO.setCoinTaskCompleteNum(coinTaskCompleteNum == null ? 0 : Integer.valueOf(coinTaskCompleteNum.toString()));
    }


    @Override
    public MarketCampaignItemListVO getMarketCampaignList(MarketCampaignDto marketCampaignDto) throws BusinessException{
        MarketCampaignItemListVO marketCampaignItemListVO = new MarketCampaignItemListVO();
        marketCampaignItemListVO.setCount(marketCampaignMapper.getMarketCampaignCount(marketCampaignDto));
        marketCampaignItemListVO.setListEx(marketCampaignMapper.getMarketCampaignList(marketCampaignDto));
        //获取用户各场景已触发次数,目前只适用于金币场景isCoin=1
        String userUuid = marketCampaignDto.getUserUuid();
        if (userUuid != null) {
            List<MarketCampaignVO> marketCampaignVOList = marketCampaignItemListVO.getList();
            String dateString = DateUtil.formateDate(new Date());
            for (MarketCampaignVO marketCampaignVO : marketCampaignVOList){
                this.setUserCoinMarketNum(marketCampaignVO, dateString, userUuid);
            }
        }
        return marketCampaignItemListVO;
    }

    /**
     * 校验用户是否已经满足并领取过该场景下的礼券
     * @param conditionDto
     * @param marketCampaignVO
     * @return
     */
    private TwoTuple<Boolean, String> checkCampaignUser(CouponSendConditionDto conditionDto, MarketCampaignVO marketCampaignVO){
        String userUuid = conditionDto.getUserUuid();
        WhereCondition where = new WhereCondition();
        where.setCondi("user_uuid", userUuid);
        where.setCondi("apply_scene", marketCampaignVO.getApplyScene());
        int frequencyLimit = DataUtils.byteToInt(marketCampaignVO.getFrequencyLimit());
        int couponExtendRecordCount = couponExtendRecordMapper.lstCountRecord(where);
        //只有使用一次场景
        if (frequencyLimit == 1 && couponExtendRecordCount > 0){
            String errMess = "用户" + userUuid + "已经领取过场景" + marketCampaignVO.getApplyScene() + "的礼券";
            logger.error(errMess);
            return new TwoTuple<Boolean, String>(false, errMess);
        }
        return new TwoTuple<Boolean, String>(true, "OK");
    }
}
