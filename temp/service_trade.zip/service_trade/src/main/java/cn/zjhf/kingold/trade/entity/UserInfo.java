package cn.zjhf.kingold.trade.entity;

import cn.zjhf.kingold.trade.utils.BizParam;
import cn.zjhf.kingold.trade.utils.DataUtils;

import java.util.Map;

/**
 * Created by zhangyijie on 2017/7/14.
 */
public class UserInfo {
    /**
     * 用户UUID
     */
    private String userUuid;

    /**
     * 用户类型: 1投资者 2产品发行方 9金疙瘩平台
     */
    private int userType;


    /**
     * 用户移动手机号码
     */
    private String investorMobile;

    /**
     * 用户真实姓名
     */
    private String investorRealName;

    /**
     * 用户身份证号码
     */
    private String investorIdCardNo;


    /**
     * 用户组织机构路径
     */
    private String investorOrganizationPath;

    /**
     * 投资人所属机构UUID
     */
    private String investorOrganizationUuid;


    /**
     * 用户状态: 0正常 1冻结
     */
    private int userStatus;

    /**
     * 用户认证状态: 0初始状态，1宝付注册成功，2宝付授权成功，3绑卡成功，9开户流程完成
     */
    private int userVerifyStatus;

    /**
     * 发行人的名字
     */
    private String issuerName;

    /**
     * 法人代表
     */
    private String legalPersonName;

    /**
     * 投资人类型（11普通投资人 12理财达人 19专职理财师）
     */
    private  String investorType;


    public UserInfo(String userUuid, String investorMobile, String investorRealName) {
        this.userUuid = userUuid;
        this.investorMobile = investorMobile;
        this.investorRealName = investorRealName;
    }

    public UserInfo(Map data) {
        BizParam bizParam = new BizParam(data);

        userUuid = bizParam.getString("userUuid");
        userType = bizParam.getInt("userType");

        investorMobile = bizParam.getString("investorMobile");
        investorRealName = bizParam.getString("investorRealName");
        investorIdCardNo = bizParam.getString("investorIdCardNo");

        investorOrganizationPath = bizParam.getString("investorOrganizationPath");
        investorOrganizationUuid = bizParam.getString("investorOrganizationUuid");

        userStatus = bizParam.getInt("userStatus");
        userVerifyStatus = bizParam.getInt("userVerifyStatus");

        issuerName = bizParam.getString("issuerName");
        legalPersonName = bizParam.getString("legalPersonName");

        investorType = bizParam.getString("investorType");
    }

    public String getUserUuid() {
        return userUuid;
    }

    public int getUserType() {
        return userType;
    }

    public String getInvestorMobile() {
        return investorMobile;
    }

    public String getInvestorRealName() {
        return investorRealName;
    }

    public String getInvestorIdCardNo() {
        return investorIdCardNo;
    }

    public String getInvestorOrganizationPath() {
        return investorOrganizationPath;
    }

    public String getInvestorOrganizationUuid() {
        return investorOrganizationUuid;
    }

    public int getUserStatus() {
        return userStatus;
    }

    public int getUserVerifyStatus() {
        return userVerifyStatus;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("userUuid:" + DataUtils.toString(userUuid) + ", ");
        sb.append("userType:" + DataUtils.toString(userType) + ", ");

        sb.append("investorMobile:" + DataUtils.toString(investorMobile) + ", ");
        sb.append("investorRealName:" + DataUtils.toString(investorRealName) + ", ");
        sb.append("investorIdCardNo:" + DataUtils.toString(investorIdCardNo) + ", ");

        sb.append("investorOrganizationPath:" + DataUtils.toString(investorOrganizationPath) + ", ");
        sb.append("investorOrganizationUuid:" + DataUtils.toString(investorOrganizationUuid) + ", ");

        sb.append("userStatus:" + DataUtils.toString(userStatus) + ", ");
        sb.append("userVerifyStatus:" + DataUtils.toString(userVerifyStatus) + ", ");

        sb.append("issuerName:" + DataUtils.toString(issuerName) + ", ");
        sb.append("legalPersonName:" + DataUtils.toString(legalPersonName));
        sb.append("investorType:" + DataUtils.toString(investorType));
        return sb.toString();
    }

    public String getIssuerName() {
        return issuerName;
    }

    public String getLegalPersonName() {
        return legalPersonName;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public void setUserType(int userType) {
        this.userType = userType;
    }

    public void setInvestorMobile(String investorMobile) {
        this.investorMobile = investorMobile;
    }

    public void setInvestorRealName(String investorRealName) {
        this.investorRealName = investorRealName;
    }

    public void setInvestorIdCardNo(String investorIdCardNo) {
        this.investorIdCardNo = investorIdCardNo;
    }

    public void setInvestorOrganizationPath(String investorOrganizationPath) {
        this.investorOrganizationPath = investorOrganizationPath;
    }

    public void setInvestorOrganizationUuid(String investorOrganizationUuid) {
        this.investorOrganizationUuid = investorOrganizationUuid;
    }

    public void setUserStatus(int userStatus) {
        this.userStatus = userStatus;
    }

    public void setUserVerifyStatus(int userVerifyStatus) {
        this.userVerifyStatus = userVerifyStatus;
    }

    public void setIssuerName(String issuerName) {
        this.issuerName = issuerName;
    }

    public void setLegalPersonName(String legalPersonName) {
        this.legalPersonName = legalPersonName;
    }

    public String getInvestorType() {
        return investorType;
    }

    public void setInvestorType(String investorType) {
        this.investorType = investorType;
    }
}
