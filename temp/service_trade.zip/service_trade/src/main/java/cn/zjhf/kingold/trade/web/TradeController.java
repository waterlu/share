package cn.zjhf.kingold.trade.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.common.utils.MapRemoveNullUtil;
import cn.zjhf.kingold.trade.constant.AccountType;
import cn.zjhf.kingold.trade.constant.PayMethod;
import cn.zjhf.kingold.trade.constant.TradeError;
import cn.zjhf.kingold.trade.entity.FeeTypeResult;
import cn.zjhf.kingold.trade.entity.TradeRecharge;
import cn.zjhf.kingold.trade.service.ITradeService;
import cn.zjhf.kingold.trade.utils.DataUtils;
import cn.zjhf.kingold.trade.utils.MapParamUtils;
import cn.zjhf.kingold.trade.utils.RequestMapperConvert;
import cn.zjhf.kingold.trade.utils.Tuple.ThreeTuple;
import cn.zjhf.kingold.trade.vo.RechargeOrderVO;
import com.alibaba.fastjson.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/trade")
public class TradeController {
    private final Logger LOGGER = LoggerFactory.getLogger(TradeController.class);

    @Autowired
    private ITradeService tradeService;

    /**
     * 创建充值单
     *
     * @param rechargeOrderVO
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/rechargeOrders", method = RequestMethod.POST)
    public ResponseResult createRechargeOrder(@Valid @RequestBody RechargeOrderVO rechargeOrderVO) throws BusinessException {
        LOGGER.info("createRechargeOrder start: " + DataUtils.toString(rechargeOrderVO));
        String userUUID = rechargeOrderVO.getUserUUID();
        String userPhone = rechargeOrderVO.getUserPhone();
        String accountUUID = rechargeOrderVO.getAccountUUID();
        String agencyAccountNo = rechargeOrderVO.getAgencyAccountNo();
        String tradeOrderBillCodeExtend = rechargeOrderVO.getTradeOrderBillCodeExtend();
        String accountType = rechargeOrderVO.getAccountType() != null ? rechargeOrderVO.getAccountType() : AccountType.ACCOUNT_TYPE_INVESTOR;
        Integer payMethod = rechargeOrderVO.getPayMethod() != null ? rechargeOrderVO.getPayMethod() : Integer.valueOf(PayMethod.SWIFT);
        String transactionChannel = rechargeOrderVO.getTransactionChannel();
        double amount = rechargeOrderVO.getAmount();
        String belongMerchantNum = rechargeOrderVO.getBelongMerchantNum();
        String orderBillCode = tradeService.createRechargeOrder(userUUID, userPhone, accountUUID, agencyAccountNo,
                amount,tradeOrderBillCodeExtend, transactionChannel, accountType, belongMerchantNum, payMethod);
        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(TradeError.OK);
        responseResult.setMsg(TradeError.OK_TEXT);
        Map<String, Object> data = new HashMap();
        data.put("orderBillCode", orderBillCode);
        data.put("additionalInfo", "");
//        data.put("returnUrl", returnUrl);
        responseResult.setData(data);

        LOGGER.info("createRechargeOrder end: " + responseResult.toString());
        return responseResult;
    }

    /**
     * 设置充值，并跟新订单状态（前端把收到的充值结果传给后端）
     *
     * @param param 参数必填： orderBillCode 充值单号
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/rechargeOrders", method = RequestMethod.PUT)
    public ResponseResult updateRechargeOrders(@RequestBody Map<String, Object> param) throws BusinessException {
        LOGGER.info("updateRechargeOrders start: " + DataUtils.toString(param));
        String traceID = (String) param.get("traceID");
        String orderBillCode = (String) param.get("orderBillCode");
        if (null == traceID || null == orderBillCode) {
            throw new BusinessException(TradeError.ERROR_PARAMETER, TradeError.ERROR_PARAMETER_TEXT, false);
        }

        int orderStatus = Integer.parseInt(param.get("orderStatus").toString());
        String request =  param.get("request") == null ? null : (String) param.get("request");

        int status = tradeService.updateRechargeOrder(orderBillCode, request, orderStatus);
        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(TradeError.OK);
        responseResult.setMsg(TradeError.OK_TEXT);
        Map<String, Object> data = new HashMap();
        data.put("status", status);
        responseResult.setData(data);

        LOGGER.info("updateRechargeOrders end: " + responseResult.toString());
        return responseResult;
    }

    /**
     * 设置充值，并跟新订单状态（前端把收到的充值结果传给后端）
     *
     * orderBillCode 充值单号
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/recharge/recover", method = RequestMethod.GET)
    public ResponseResult rechargeRecover(@RequestParam(value = "traceID") String traceID,
                                          @RequestParam(value = "orderBillCode") String orderBillCode) throws BusinessException {

        int status = tradeService.updateRechargeOrder(orderBillCode, null, 1);
        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(TradeError.OK);
        responseResult.setMsg(TradeError.OK_TEXT);
        Map<String, Object> data = new HashMap();
        data.put("status", status);
        responseResult.setData(data);
        LOGGER.info("rechargeRecover end. orderBillCode={}, response={}",orderBillCode,responseResult);

        return responseResult;
    }


    /**
     * 提现补单
     *
     * orderBillCode 充值单号
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/withdraw/recover", method = RequestMethod.GET)
    public ResponseResult withdrawRecover(@RequestParam(value = "traceID") String traceID,
                                          @RequestParam(value = "orderBillCode") String orderBillCode) throws BusinessException {

        ResponseResult responseResult = tradeService.recoverWithdraw(orderBillCode);
        LOGGER.info("withdrawRecover end. orderBillCode={}, response={}",orderBillCode,responseResult);
        return responseResult;
    }

    /**
     * 提现补单
     *
     * orderBillCode 充值单号
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/timer/withdraw/recover", method = RequestMethod.GET)
    public ResponseResult withdrawRecoverTimer() throws BusinessException {

        ResponseResult responseResult = tradeService.recoverWithdrawTimer();
        LOGGER.info("withdrawRecover end. orderBillCode={}, response={}",responseResult);
        return responseResult;
    }


    /**
     * 获取订单
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/order/{orderBillCode}", method = RequestMethod.GET)
    public ResponseResult getOrder(@PathVariable String orderBillCode ,@RequestParam Map params) throws BusinessException {
        LOGGER.info("getOrder start: " + DataUtils.toString(orderBillCode, params));
        Map tradeOrder = tradeService.getTradeOrder(orderBillCode);
        LOGGER.info("getOrder end: " + DataUtils.toString(params.get("traceID"), tradeOrder));
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", tradeOrder);
    }

    /**
     * 投资
     * @param params: productUuid, userUuid, orderAmount, couponExtendCode, belongMerchantNum, channelCommissionFlag
     * @return couponInterestYieldRate double 加息券加息率
     * @throws BusinessException
     */
    @RequestMapping(value = "/invest", method = RequestMethod.POST)
    public ResponseResult invest(@RequestBody Map params) throws BusinessException {
        LOGGER.info("invest start: " + DataUtils.toString(params));
        ResponseResult responseResult = tradeService.invest(params);
        LOGGER.info("invest end: " + DataUtils.toString(params.get("traceID"), responseResult.getData()));
        return responseResult;
    }

    /**
     * 检查投资者是否可以购买新手标产品
     * @param params
     * @return TRUE 可购买；FALSE 不可购买
     * @throws BusinessException
     */
    @RequestMapping(value = "/checkNoviceProduct/{userUuid}", method = RequestMethod.GET)
    public ResponseResult checkNoviceProduct(@PathVariable String userUuid, @RequestParam Map params) throws BusinessException {
        LOGGER.info("checkNoviceProduct start: " + DataUtils.toString(userUuid, params));
        Boolean ret = tradeService.checkNoviceProduct(userUuid);
        LOGGER.info("checkNoviceProduct end: " + DataUtils.toString(params.get("traceID"), ret));
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", ret);
    }

    /**
     * 设置固收订单所属专职理财师信息
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/fixdIncomeServiceUser", method = RequestMethod.PUT)
    public ResponseResult updateServiceUserInfo(@RequestBody Map params) throws BusinessException {
        LOGGER.info("updateServiceUserInfo start: " + DataUtils.toString(params));

        String orderBillCode = MapParamUtils.getStringInMap(params,"orderBillCode");
        String serviceUserUuid = MapParamUtils.getStringInMap(params,"serviceUserUuid");
        String serviceUserOrgPath = MapParamUtils.getStringInMap(params,"serviceUserOrgPath");

        tradeService.updateServiceUserInfo(orderBillCode,serviceUserUuid,serviceUserOrgPath);

        LOGGER.info("updateServiceUserInfo end: " + DataUtils.toString(params.get("traceID")));
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用");
    }


    /**
     * 提现（冻结余额）
     *
     * @param params 参数必填：userUuid,accountType,rechargeAmount,userPayPassword
     *
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/freezeWithdraw", method = RequestMethod.POST)
    public ResponseResult freezeWithdraw(@RequestBody Map params) throws BusinessException {
        LOGGER.info("freezeWithdraw start: " + DataUtils.toString(params));
//        ResponseResult rr = tradeService.freezeWithdraw(params);
        String billCode = "";
        LOGGER.info("创建提现订单;params:{}",JSONObject.toJSONString(params));
        TradeRecharge tradeRecharge = tradeService.createRechargeOrder(params);
        LOGGER.info("宝付 提现;params:{}",JSONObject.toJSONString(tradeRecharge));
        ResponseResult rr = tradeService.baofooWithDraw(tradeRecharge);

        if(rr.getCode() != ResponseCode.OK){
            LOGGER.error("宝付 提现 失败;params:{}",JSONObject.toJSONString(rr));
            return new ResponseResult((String) params.get("traceID"), rr.getCode(), rr.getMsg(), billCode);
        }

//        LOGGER.info("宝付提现成功后，设置账户系统冻结账户金额;params:{}",JSONObject.toJSONString(tradeRecharge));
//        try {
//            tradeService.successWithDraw(tradeRecharge);
//        }catch(BusinessException e){
//            LOGGER.error("宝付提现成功后，设置账户系统冻结账户金额失败，原因："+e.getMessage());
//            return new ResponseResult((String) params.get("traceID"), rr.getCode(), rr.getMsg(), billCode);
//        }

//        LOGGER.info("用户提现发送短信;params:{}",JSONObject.toJSONString(tradeRecharge));
//        try {
//            tradeService.freezeWithdrawSendSms(tradeRecharge);
//        }catch(BusinessException e){
//            LOGGER.error("宝付提现成功后，用户提现发送短信失败，原因："+e.getMessage());
//            return new ResponseResult((String) params.get("traceID"), rr.getCode(), rr.getMsg(), billCode);
//        }

        billCode = rr.getData().toString();
        LOGGER.info("freezeWithdraw end: " + DataUtils.toString(params.get("traceID"), billCode));
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", billCode);
    }



    /**
     * 提现(成功后的回调）
     *
     * @param params 参数必填 billCode
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/callbackWithdraw", method = RequestMethod.POST)
    public ResponseResult executeCertificate(@RequestBody Map params) throws BusinessException {
        LOGGER.info("executeCertificate start: " + DataUtils.toString(params));

        tradeService.executeBill(MapParamUtils.getStringInMap(params,"billCode"));

        LOGGER.info("executeCertificate end: " + DataUtils.toString(params.get("traceID")));
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用");
    }

    /**
     * 取消提现(失败后的回调）
     *
     * @param params 参数必填 billCode
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/cancelWithdraw", method = RequestMethod.POST)
    public ResponseResult cancelWithdraw(@RequestBody Map params) throws BusinessException {
        LOGGER.info("cancelWithdraw start: " + DataUtils.toString(params));

        tradeService.cancelExecuteBill(MapParamUtils.getStringInMap(params,"billCode"),MapParamUtils.getStringInMap(params,"remark"));

        LOGGER.info("cancelWithdraw end: " + DataUtils.toString(params.get("traceID")));
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用");
    }

    /**
     * 获取用户在某个产品下的总投资金额
     *
     * @param params 必须包含productUuid 和 userUuid
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/getTotalInvestAmount", method = RequestMethod.GET)
    public ResponseResult getTotalInvestAmount(@RequestParam Map params) throws BusinessException {
        LOGGER.info("getTotalInvestAmount start: " + DataUtils.toString(params));

        MapRemoveNullUtil.removeNullEntry(params);
        RequestMapperConvert.initTradeOrderParam(params);
        BigDecimal totalAmount = tradeService.getTotalInvestAmount(params);

        LOGGER.info("getTotalInvestAmount end: " + DataUtils.toString(params.get("traceID")));
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", totalAmount);
    }


    /**
     * 固收产品认购(判断能否购买)
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/productSubscription", method = RequestMethod.POST)
    public ResponseResult productSubscription(@RequestBody Map params) throws BusinessException {
        LOGGER.info("productSubscription start: " + DataUtils.toString(params));

        tradeService.productSubscription(params);

        LOGGER.info("productSubscription end: " + DataUtils.toString(params.get("traceID")));
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用");
    }


    /**
     * 认证提现手续费 收取方和收取金额
     *
     * @param params  参数必填：userUuid,accountType,amount
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/getFeeType", method = RequestMethod.GET)
    public ResponseResult getFeeType(@RequestParam Map params) throws BusinessException {
        LOGGER.info("getFeeType start: " + DataUtils.toString(params));

        FeeTypeResult ftr = tradeService.getFeeType(params);

        LOGGER.info("getFeeType end: " + DataUtils.toString(params.get("traceID"), ftr));
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", ftr);
    }

    /**
     * 填充电子合同
     * @param params 参数必填 billCode
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/contractFill", method = RequestMethod.POST)
    public ResponseResult contractFill(@RequestBody Map params) throws BusinessException {
        LOGGER.info("contractFill start: " + DataUtils.toString(params));

        List<ThreeTuple<String, String, String>> contractFileInfoList = tradeService.contractFill(MapParamUtils.getStringInMap(params,"productUuid"));
        tradeService.updateContractFileInfo(contractFileInfoList);

        LOGGER.info("contractFill end: " + DataUtils.toString(params.get("traceID")));
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用");
    }

    /**
     * 获取阿里private 文件访问路径
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/getAccessFileUrl", method = RequestMethod.GET)
    public ResponseResult getAccessFileUrl(@RequestParam String traceID, @RequestParam String fileName) throws BusinessException {
        LOGGER.info("getAccessFileUrl start: " + DataUtils.toString(traceID, fileName));
        DataUtils.checkParam(traceID);

        String accessFileUri = tradeService.getAccessFileUrl(fileName);

        LOGGER.info("getAccessFileUrl end: " + DataUtils.toString(traceID, accessFileUri));
        return new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS, "正常调用", accessFileUri);
    }
}
