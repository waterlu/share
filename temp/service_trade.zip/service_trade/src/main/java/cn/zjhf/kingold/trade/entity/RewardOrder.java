package cn.zjhf.kingold.trade.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @author lutiehua
 * @date 2018/3/21
 */
public class RewardOrder implements Serializable {

    /**
     * 自增ID
     */
    private Long rewardOrderId;

    /**
     * 用户UUID
     */
    private String userUuid;

    /**
     * 订单号
     */
    private String orderBillCode;

    /**
     * 订单时间
     */
    private Date orderTime;

    /**
     * 删除标记
     */
    private Integer deleteFlag;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    public Long getRewardOrderId() {
        return rewardOrderId;
    }

    public void setRewardOrderId(Long rewardOrderId) {
        this.rewardOrderId = rewardOrderId;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getOrderBillCode() {
        return orderBillCode;
    }

    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    public Date getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(Date orderTime) {
        this.orderTime = orderTime;
    }

    public Integer getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Integer deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}
