package cn.zjhf.kingold.trade.constant;

/**
 * 私募产品奖励记录状态
 *
 * Created by lutiehua on 2017/6/7.
 */
public interface RewardPrivateStatus {

    /**
     * 待审核
     *
     */
    int INIT = 1;

    /**
     * 审核不通过
     */
    int REJECT = 2;

    /**
     * 待发放
     */
    int CHECKED = 3;

    /**
     * 已发放
     */
    int FINISH = 4;
}
