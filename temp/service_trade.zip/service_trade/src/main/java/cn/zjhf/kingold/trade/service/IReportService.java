package cn.zjhf.kingold.trade.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.trade.entity.InVO.LstProductRewardItemsVO;
import cn.zjhf.kingold.trade.entity.InVO.LstProductRewardSummaryItemsVO;
import cn.zjhf.kingold.trade.entity.InVO.ProductRewardSummaryBatchAuditVO;
import cn.zjhf.kingold.trade.entity.InVO.ReportConditionVO;
import cn.zjhf.kingold.trade.entity.OutVO.CommItemListVO;
import cn.zjhf.kingold.trade.entity.OutVO.CommReportDataVO;
import cn.zjhf.kingold.trade.entity.OutVO.ProductRewardItemListVO;
import cn.zjhf.kingold.trade.entity.OutVO.ProductRewardSummaryListVO;
import cn.zjhf.kingold.trade.vo.ProductRewardSummaryReportVO;

import java.util.List;

/**
 * Created by zhangyijie on 2017/6/5.
 */
public interface IReportService {
    /**
     * Step1 产品奖励记录_查询
     * @param lstProductRewardSummaryItemsVO
     * @return
     * @throws BusinessException
     */
    public ProductRewardSummaryListVO lstProductRewardSummaryItems(LstProductRewardSummaryItemsVO lstProductRewardSummaryItemsVO) throws BusinessException;

    /**
     * 产品收支明细表
     * @param lstProductRewardSummaryItemsVO
     * @return
     * @throws BusinessException
     */
    public CommItemListVO<ProductRewardSummaryReportVO> getExpenditureDetailsReport(LstProductRewardSummaryItemsVO lstProductRewardSummaryItemsVO) throws BusinessException;

    /**
     * Step2 产品奖励记录_批量报税审核
     * @param productRewardSummaryBatchAuditVO
     * @return
     * @throws BusinessException
     */
    public int productRewardSummaryBatchIncomeTaxAudit(ProductRewardSummaryBatchAuditVO productRewardSummaryBatchAuditVO) throws BusinessException;

    /**
     * Step3 产品奖励记录_批量报税(结算)
     * @param productRewardSummaryBatchAuditVO
     * @return
     * @throws BusinessException
     */
    public int productRewardSummaryBatchIncomeTaxClear(ProductRewardSummaryBatchAuditVO productRewardSummaryBatchAuditVO) throws BusinessException;

    /**
     * Step4 产品奖励记录_奖励详情_产品奖励明细记录
     * @param lstProductRewardItemsVO
     * @return
     * @throws BusinessException
     */
    public ProductRewardItemListVO lstProductRewardItems(LstProductRewardItemsVO lstProductRewardItemsVO) throws BusinessException;

    /**
     * Step5 产品奖励记录_奖励详情_管理费审核
     * @param productRewardSummaryBatchAuditVO
     * @return
     * @throws BusinessException
     */
    public int productRewardSummaryExchangeManagefeeAudit(ProductRewardSummaryBatchAuditVO productRewardSummaryBatchAuditVO) throws BusinessException;

    /**
     * Step6 产品奖励记录_奖励详情_管理费结算
     * @param productRewardSummaryBatchAuditVO
     * @return
     * @throws BusinessException
     */
    public int productRewardSummaryExchangeManagefeeClear(ProductRewardSummaryBatchAuditVO productRewardSummaryBatchAuditVO) throws BusinessException;

    /**
     * 通用报表数据生成
     * @param reportCondition
     * @return
     * @throws BusinessException
     */
    public CommReportDataVO commReportEx(ReportConditionVO reportCondition) throws BusinessException;
}
