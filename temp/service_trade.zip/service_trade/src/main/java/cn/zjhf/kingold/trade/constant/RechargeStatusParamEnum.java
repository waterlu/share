package cn.zjhf.kingold.trade.constant;

/**
 * Created by liuyao on 2017/6/21.
 */
public enum RechargeStatusParamEnum {
    FAIL(-1, TradeStatus.FAILURE, PayStatus.FAILED,"失败"), CANCEL(0, TradeStatus.CANCEL, PayStatus.CANCEL, "取消"),
    SUCCESS(1, TradeStatus.SUCCESS, PayStatus.SUCCESSFUL, "成功"), DOING(10, TradeStatus.NEW, PayStatus.PENDING, "处理中");

    private Integer paramStatus;
    private byte dbStatus;
    private int payStatus;
    private String desc;

    /**
     * 兼容充值各种状态枚举
     * @param paramStatus 充值申请参数
     * @param dbStatus db充值单状态
     * @param payStatus 支付状态
     * @param desc
     */
    RechargeStatusParamEnum(Integer paramStatus, byte dbStatus, int payStatus, String desc) {
        this.dbStatus = dbStatus;
        this.paramStatus = paramStatus;
        this.payStatus = payStatus;
        this.desc = desc;
    }

    public static RechargeStatusParamEnum getStatusByParamStatus(Integer paramStatus) {
        for (RechargeStatusParamEnum paramEnum: RechargeStatusParamEnum.values()) {
            if(paramEnum.getParamStatus().equals(paramStatus)) {
                return paramEnum;
            }
        }
        return DOING;
    }

    public Integer getParamStatus() {
        return paramStatus;
    }

    public void setParamStatus(Integer paramStatus) {
        this.paramStatus = paramStatus;
    }

    public byte getDbStatus() {
        return dbStatus;
    }

    public void setDbStatus(byte dbStatus) {
        this.dbStatus = dbStatus;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getPayStatus() {
        return payStatus;
    }

    public void setPayStatus(int payStatus) {
        this.payStatus = payStatus;
    }
}
