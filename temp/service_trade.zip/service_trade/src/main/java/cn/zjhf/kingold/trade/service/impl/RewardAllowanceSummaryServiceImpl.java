package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.trade.constant.*;
import cn.zjhf.kingold.trade.dto.RewardApplyDto;
import cn.zjhf.kingold.trade.dto.RewardSearchDto;
import cn.zjhf.kingold.trade.dto.RewardSummaryCollideDto;
import cn.zjhf.kingold.trade.dto.RewardSummarySearchDto;
import cn.zjhf.kingold.trade.entity.Reward;
import cn.zjhf.kingold.trade.entity.RewardServiceAllowance;
import cn.zjhf.kingold.trade.persistence.dao.RewardMapper;
import cn.zjhf.kingold.trade.persistence.dao.RewardServiceAllowanceMapper;
import cn.zjhf.kingold.trade.service.IRewardAllowanceSummaryService;
import cn.zjhf.kingold.trade.utils.ZJBuzzUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;

/**
 * 服务津贴结算处理
 *
 * Created by lutiehua on 2017/6/14.
 */
@Service
public class RewardAllowanceSummaryServiceImpl implements IRewardAllowanceSummaryService {

    private final Logger LOGGER = LoggerFactory.getLogger(RewardAllowanceSummaryServiceImpl.class);

    @Autowired
    private RewardMapper rewardMapper;

    @Autowired
    private RewardServiceAllowanceMapper serviceAllowanceMapper;


    @Override
    public List<RewardServiceAllowance> search(RewardSearchDto rewardSearchDto) throws BusinessException {
        return serviceAllowanceMapper.search(rewardSearchDto);
    }

    @Override
    public int searchCount(RewardSearchDto rewardSearchDto) throws BusinessException {
        return serviceAllowanceMapper.searchCount(rewardSearchDto);
    }

    /**
     * 申请生成服务津贴的结算
     *
     * @param rewardApplyDto
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = BusinessException.class)
    public ResponseResult applyServiceReward(RewardApplyDto rewardApplyDto) throws BusinessException {
        LOGGER.info("======== Generating reward summary for allowance is started ========");
        LOGGER.info("开始日期:{}", rewardApplyDto.getStartDate());
        LOGGER.info("截止日期:{}", rewardApplyDto.getEndDate());
        ResponseResult responseResult = new ResponseResult();

        // 传过来的是[]，查询的时候是[)，所以加一天
        // 存储的时候还是[]
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(rewardApplyDto.getEndDate());
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        Date endDate = calendar.getTime();
        LOGGER.info("查询截止日期:{}", endDate);

        // 加载奖励数据
        LOGGER.info("加载时间段内的所有服务津贴记录数据");
        RewardSearchDto searchCondition = new RewardSearchDto();
        // 必须是私募产品产生的奖励
        searchCondition.setProductType(ProductType.PRODUCT_PF);
        // 开始时间
        searchCondition.setFromCreateTime(rewardApplyDto.getStartDate());
        // 结束时间
        searchCondition.setToCreateTime(endDate);
        List<Reward> rewardList = rewardMapper.searchServiceReward(searchCondition);
        LOGGER.info("rewardList.size()={}", rewardList.size());

        if (rewardList.size() == 0) {
            // 没有数据，不用汇总
            LOGGER.error("没有有效的服务津贴记录");
            responseResult.setCode(RewardError.EMPTY_DATA);
            responseResult.setMsg(RewardError.EMPTY_DATA_TXT);
            return responseResult;
        }

        // 加载数据定期奖励结算数据
        LOGGER.info("加载时间段内的所有服务津贴结算数据");
        RewardSummarySearchDto rewardSummarySearchDto = new RewardSummarySearchDto();
        rewardSummarySearchDto.setStartDate(rewardApplyDto.getStartDate());
        rewardSummarySearchDto.setEndDate(rewardApplyDto.getEndDate());
        List<RewardServiceAllowance> rewardAllowanceList = serviceAllowanceMapper.getRewardAllowanceList(rewardSummarySearchDto);
        LOGGER.info("rewardAllowanceList.size()={}", rewardAllowanceList.size());

        if (rewardAllowanceList.size() > 0) {
            // 检查是否有用户已经生成过此时间的定期奖励汇总
            LOGGER.info("检查是否有用户已经生成过此时间的定期奖励汇总");
            // 汇总这个时间段内所有包含有效奖励的用户
            Map<String, String> userMap = new HashMap<>();
            for (Reward reward : rewardList) {
                String userUuid = reward.getUserUuid();
                if (!userMap.containsKey(userUuid)) {
                    userMap.put(userUuid, userUuid);
                }
            }

            // 检查这些用户是否有结算时间段交叉的情况
            List<RewardSummaryCollideDto> collidedRewardList = new ArrayList<>();
            for (RewardServiceAllowance rewardServiceAllowance : rewardAllowanceList) {
                String userUuid = rewardServiceAllowance.getUserUuid();
                if (!userMap.containsKey(userUuid)) {
                    continue;
                }

                RewardSummaryCollideDto rewardFixedCollideDto = new RewardSummaryCollideDto(rewardServiceAllowance);
                collidedRewardList.add(rewardFixedCollideDto);
            }

            if (collidedRewardList.size() > 0) {
                responseResult.setCode(RewardError.COLLIDED_PERIOD);
                StringBuffer buffer = new StringBuffer(RewardError.COLLIDED_PERIOD_TXT);
                buffer.append("<br/>");
                for(RewardSummaryCollideDto collideDto : collidedRewardList) {
                    LOGGER.error("存在用户结算周期重叠的情况：{}", collideDto.getRewardBillCode());
                    buffer.append(collideDto.getUserMobile());
                    buffer.append("|");
                    buffer.append(collideDto.getRewardStartDate());
                    buffer.append("至");
                    buffer.append(collideDto.getRewardEndDate());
                }
                responseResult.setMsg(buffer.toString());
                return responseResult;
            }
        }

        // 生成批次号
        String batchCode = ZJBuzzUtils.generateOrderBillCode(TradeType.TRADE_REWARD_SERVICE_SUMMARY_BATCH);
        LOGGER.info("批次号={}", batchCode);

        // 汇总服务津贴结算记录
        LOGGER.info("汇总服务津贴结算记录");
        Map<String, RewardServiceAllowance> rewardMap = new HashMap<>();
        for (Reward reward : rewardList) {
            String userUuid = reward.getUserUuid();
            RewardServiceAllowance rewardAllowance = null;
            if (rewardMap.containsKey(userUuid)) {
                rewardAllowance = rewardMap.get(userUuid);
            }
            if (null == rewardAllowance) {
                rewardAllowance = createRewardAllowance(reward, rewardApplyDto, batchCode);
                rewardMap.put(userUuid, rewardAllowance);
            }

            if(StringUtils.isBlank(rewardAllowance.getBelongTopOrgPath()) && StringUtils.isNotBlank(reward.getBelongTopOrgPath())){
                rewardAllowance.setBelongTopUserUuid(reward.getBelongTopUserUuid());
                rewardAllowance.setBelongTopOrgPath(reward.getBelongTopOrgPath());
            }

            // 记录RewardBillCode
            rewardAllowance.addReward(reward);

            rewardAllowance.setRewardCount(rewardAllowance.getRewardCount() + 1);
            BigDecimal rewardAmount = rewardAllowance.getRewardAmount();
            rewardAmount = rewardAmount.add(reward.getRewardAmount());
            rewardAllowance.setRewardAmount(rewardAmount);
            LOGGER.info("userUuid={}, reward={}", userUuid, rewardAmount.doubleValue());
        }

        // 持久化到数据库
        LOGGER.info("持久化到数据库");
        for (RewardServiceAllowance rewardAllowance : rewardMap.values()) {
            // 写入服务津贴汇总记录
            LOGGER.info("写入服务津贴汇总记录");
            String summaryBillCode = rewardAllowance.getRewardAllowanceBillCode();
            serviceAllowanceMapper.insert(rewardAllowance);

            // 更新奖励明细状态
            LOGGER.info("更新奖励明细状态");
            for (Reward reward : rewardAllowance.getRewardList()) {
                String rewardBillCode = reward.getRewardBillCode();
                Map<String, Object> param = new HashMap<>();
                param.put("rewardBillCode", rewardBillCode);
                param.put("summaryBillCode", summaryBillCode);
                rewardMapper.updateSummaryBillCode(param);
            }
        }

        LOGGER.info("======== Generating reward summary for allowance is finish ========");
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        return responseResult;
    }

    @Override
    public RewardServiceAllowance getAllowanceAward(String rewardAllowanceBillCode) throws BusinessException {
        return serviceAllowanceMapper.selectByPrimaryKey(rewardAllowanceBillCode);
    }

    /**
     * 更新审核状态
     *
     * @param param
     * @return
     */
    @Override
    @Transactional(rollbackFor = BusinessException.class)
    public ResponseResult updateCheckStatus(Map<String, Object> param) throws BusinessException {
        List<String> finishList = new ArrayList<>();
        List<String> failedList = new ArrayList<>();

        String rewardAllowanceBillCode = param.get("rewardAllowanceBillCode").toString();
        int pass = Integer.parseInt(param.get("pass").toString());
        String [] billCodeList = rewardAllowanceBillCode.split(Separator.DATA_SEPARATOR);
        for (String billCode : billCodeList) {
            if (pass == 1) {
                LOGGER.info("审核服务津贴：{}", billCode);
            } else {
                LOGGER.info("作废服务津贴：{}", billCode);
            }

            RewardServiceAllowance rewardServiceAllowance = serviceAllowanceMapper.selectByPrimaryKey(billCode);
            int status = rewardServiceAllowance.getRewardAllowanceStatus();
            LOGGER.info("status={}", status);
            if (status != RewardSummaryStatus.INIT && status != RewardSummaryStatus.REJECT) {
                LOGGER.info("服务津贴状态错误：{}", status);
                failedList.add(billCode);
            } else {
                // 更新服务津贴状态
                LOGGER.info("更新服务津贴状态");
                param.put("rewardAllowanceBillCode", billCode);
                serviceAllowanceMapper.updateCheckStatus(param);

                if (pass == 1) {
                    // 更新奖励记录状态
                    LOGGER.info("更新奖励记录状态");
                    Map<String, Object> paramReward = new HashMap<>();
                    paramReward.put("summaryBillCode", billCode);
                    paramReward.put("checkTime", new Date());
                    rewardMapper.updateCheckTime(paramReward);
                }

                finishList.add(billCode);
            }
        }

        StringBuffer buffer = new StringBuffer();
        if (finishList.size() > 0) {
            buffer.append(RewardError.CHECK_FINISH_TXT);
            buffer.append("\n");
            for(String billCode : finishList) {
                buffer.append(billCode);
                buffer.append("\n");
            }

            buffer.append("\n");
            buffer.append("\n");
        }

        if (failedList.size() > 0) {
            buffer.append(RewardError.CHECK_FAILED_TXT);
            buffer.append("\n");
            for(String billCode : failedList) {
                buffer.append(billCode);
                buffer.append("\n");
            }
        }

        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(buffer.toString());
        return responseResult;
    }

    /**
     * 更新结算状态
     *
     * @param param
     * @return
     */
    @Override
    @Transactional(rollbackFor = BusinessException.class)
    public ResponseResult updateClearStatus(Map<String, Object> param) throws BusinessException {
        List<String> finishList = new ArrayList<>();
        List<String> failedList = new ArrayList<>();

        String rewardAllowanceBillCode = param.get("rewardAllowanceBillCode").toString();
        int pass = Integer.parseInt(param.get("pass").toString());
        String [] billCodeList = rewardAllowanceBillCode.split(Separator.DATA_SEPARATOR);
        for (String billCode : billCodeList) {
            if (pass == 1) {
                LOGGER.info("发放服务津贴：{}", billCode);
            } else {
                LOGGER.info("驳回服务津贴：{}", billCode);
            }

            RewardServiceAllowance rewardServiceAllowance = serviceAllowanceMapper.selectByPrimaryKey(billCode);
            int status = rewardServiceAllowance.getRewardAllowanceStatus();
            LOGGER.info("status={}", status);
            if (status != RewardSummaryStatus.CHECKED) {
                LOGGER.info("服务津贴状态错误：{}", status);
                failedList.add(billCode);
            } else {
                // 更新服务津贴状态
                LOGGER.info("更新服务津贴状态");
                param.put("rewardAllowanceBillCode", billCode);
                serviceAllowanceMapper.updateClearStatus(param);

                if (pass == 1) {
                    // 更新奖励记录状态
                    LOGGER.info("更新奖励记录状态");
                    List<Reward> rewardList = rewardMapper.queryBySummaryBillCode(billCode);
                    for (Reward reward : rewardList) {
                        Map<String, Object> paramReward = new HashMap<>();
                        paramReward.put("clearTime", new Date());
                        paramReward.put("payAmount", reward.getRewardAmount());
                        paramReward.put("rewardBillCode", reward.getRewardBillCode());
                        rewardMapper.updateClearTime(paramReward);
                    }

                }

                finishList.add(billCode);
            }
        }

        StringBuffer buffer = new StringBuffer();
        if (finishList.size() > 0) {
            buffer.append(RewardError.CLEAR_FINISH_TXT);
            buffer.append("\n");
            for(String billCode : finishList) {
                buffer.append(billCode);
                buffer.append("\n");
            }

            buffer.append("\n");
            buffer.append("\n");
        }

        if (failedList.size() > 0) {
            buffer.append(RewardError.CLEAR_FAILED_TXT);
            buffer.append("\n");
            for(String billCode : failedList) {
                buffer.append(billCode);
                buffer.append("\n");
            }
        }

        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(buffer.toString());
        return responseResult;
    }

    /**
     * 创建服务津贴汇总记录
     *
     * @param reward
     * @param rewardApplyDto
     * @return
     */
    private RewardServiceAllowance createRewardAllowance(Reward reward, RewardApplyDto rewardApplyDto, String batchCode) {
        RewardServiceAllowance rewardServiceAllowance = new RewardServiceAllowance();
        rewardServiceAllowance.setRewardAllowanceBillCode(ZJBuzzUtils.generateOrderBillCode(TradeType.TRADE_REWARD_SERVICE_SUMMARY));
        rewardServiceAllowance.setRewardAllowanceEndDate(rewardApplyDto.getEndDate());
        rewardServiceAllowance.setRewardAllowanceStartDate(rewardApplyDto.getStartDate());
        rewardServiceAllowance.setRewardAllowanceStatus(RewardSummaryStatus.INIT);
        rewardServiceAllowance.setUserUuid(reward.getUserUuid());
        rewardServiceAllowance.setUserMobile(reward.getUserMobile());
        rewardServiceAllowance.setUserIdCardNo(reward.getUserIdCardNo());
        rewardServiceAllowance.setUserRealName(reward.getUserRealName());
        rewardServiceAllowance.setBelongTopOrgPath(reward.getBelongTopOrgPath());
        rewardServiceAllowance.setBelongTopUserUuid(reward.getBelongTopUserUuid());
        rewardServiceAllowance.setRewardCount(0);
        rewardServiceAllowance.setRewardAmount(new BigDecimal(0));
        rewardServiceAllowance.setCreateTime(new Date());
        rewardServiceAllowance.setRewardAllowanceBatchCode(batchCode);
        return rewardServiceAllowance;
    }

}
