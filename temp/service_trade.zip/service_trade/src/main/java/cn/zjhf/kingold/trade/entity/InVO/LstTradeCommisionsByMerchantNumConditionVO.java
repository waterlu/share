package cn.zjhf.kingold.trade.entity.InVO;

import cn.zjhf.kingold.trade.utils.DataUtils;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Size;

/**
 * Created by zhangyijie on 2017/10/13.
 */
public class LstTradeCommisionsByMerchantNumConditionVO extends InVOBase {
    @ApiModelProperty(required = true, value = "productUuid")
    @NotEmpty
    @Size(min = 1, max = 40)
    private String productUuid;

    @ApiModelProperty(required = true, value = "渠道商户号")
    @NotEmpty
    @Size(min = 1, max = 20)
    private String merchantNum;

    @ApiModelProperty(required = true, value = "起始序号")
    private int beginSN;

    @ApiModelProperty(required = true, value = "结束序号")
    private int endSN;

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getMerchantNum() {
        return merchantNum;
    }

    public void setMerchantNum(String merchantNum) {
        this.merchantNum = merchantNum;
    }

    public int getBeginSN() {
        return beginSN;
    }

    public void setBeginSN(int beginSN) {
        this.beginSN = beginSN;
    }

    public int getEndSN() {
        return endSN;
    }

    public void setEndSN(int endSN) {
        this.endSN = endSN;
    }

    @Override
    public String toString() {
        return "LstTradeCommisionsByMerchantNumConditionVO{" +
                "traceID=" + DataUtils.toString(getTraceID()) + ", " +
                ", productUuid='" + productUuid + '\'' +
                ", merchantNum='" + merchantNum + '\'' +
                ", beginSN=" + beginSN +
                ", endSN=" + endSN +
                '}';
    }
}
