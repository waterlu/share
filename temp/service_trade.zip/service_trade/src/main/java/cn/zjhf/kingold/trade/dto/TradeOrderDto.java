package cn.zjhf.kingold.trade.dto;

import cn.zjhf.kingold.trade.dto.options.PageOptions;

/**
 * 订单查询
 */
public class TradeOrderDto extends PageOptions{

    /**
     * 订单号，产品订单编号
     */
    private String orderBillCode;
    /**
     * 产品简称
     */
    private String productAbbrName;
    /**
     * 用户名，手机号码
     */
    private String userPhone;
    /**
     * 订单状态 1创建，2已付款，3产品成立，4已到期，5已清算，9已撤销
     * 放款：待发放：1/2/     已发放：3/4/5
     * 还款：待发放：1/2/3/4     已发放：5
     */
    private Integer orderStatus;
    /**
     * 查询订单创建开始时间
     */
    private String transactionTimeFrom;
    /**
     * 查询订单创建结束时间
     */
    private String transactionTimeTo;
    /**
     * 下单渠道 1,app(IOS); 2,app(安卓); 其他
     */
    private String transactionChannel;
    /**
     * 订单支付开始时间
     */
    private String payedTimeFrom;
    /**
     * 订单支付结束时间
     */
    private String payedTimeTo;

    public String getOrderBillCode() {
        return orderBillCode;
    }

    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    public String getProductAbbrName() {
        return productAbbrName;
    }

    public void setProductAbbrName(String productAbbrName) {
        this.productAbbrName = productAbbrName;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    public Integer getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(Integer orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getTransactionTimeFrom() {
        return transactionTimeFrom;
    }

    public void setTransactionTimeFrom(String transactionTimeFrom) {
        this.transactionTimeFrom = transactionTimeFrom;
    }

    public String getTransactionTimeTo() {
        return transactionTimeTo;
    }

    public void setTransactionTimeTo(String transactionTimeTo) {
        this.transactionTimeTo = transactionTimeTo;
    }

    public String getTransactionChannel() {
        return transactionChannel;
    }

    public void setTransactionChannel(String transactionChannel) {
        this.transactionChannel = transactionChannel;
    }

    public String getPayedTimeFrom() {
        return payedTimeFrom;
    }

    public void setPayedTimeFrom(String payedTimeFrom) {
        this.payedTimeFrom = payedTimeFrom;
    }

    public String getPayedTimeTo() {
        return payedTimeTo;
    }

    public void setPayedTimeTo(String payedTimeTo) {
        this.payedTimeTo = payedTimeTo;
    }

    @Override
    public String toString() {
        return "TradeOrderDTO{" +
                "orderBillCode='" + orderBillCode + '\'' +
                ", productAbbrName='" + productAbbrName + '\'' +
                ", userPhone='" + userPhone + '\'' +
                ", orderStatus=" + orderStatus +
                ", transactionTimeFrom='" + transactionTimeFrom + '\'' +
                ", transactionTimeTo='" + transactionTimeTo + '\'' +
                ", transactionChannel='" + transactionChannel + '\'' +
                ", payedTimeFrom='" + payedTimeFrom + '\'' +
                ", payedTimeTo='" + payedTimeTo + '\'' +
                '}';
    }
}
