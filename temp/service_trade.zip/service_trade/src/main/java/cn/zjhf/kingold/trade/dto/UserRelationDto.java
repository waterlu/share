package cn.zjhf.kingold.trade.dto;

/**
 * 用户关系返回的数据
 *
 * Created by lutiehua on 2017/5/27.
 */
public class UserRelationDto {

    /**
     * 用户UUID
     */
    private String userUuid;

    /**
     * 上一级邀请人UUID
     */
    private String inviterLevelOneUuid;

    /**
     * 上两级邀请人UUID
     */
    private String inviterLevelTwoUuid;

    /**
     * 上三级邀请人UUID
     */
    private String inviterLevelThreeUuid;

    /**
     * 专职理财人UUID
     */
    private String topUuid;

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getInviterLevelOneUuid() {
        return inviterLevelOneUuid;
    }

    public void setInviterLevelOneUuid(String inviterLevelOneUuid) {
        this.inviterLevelOneUuid = inviterLevelOneUuid;
    }

    public String getInviterLevelTwoUuid() {
        return inviterLevelTwoUuid;
    }

    public void setInviterLevelTwoUuid(String inviterLevelTwoUuid) {
        this.inviterLevelTwoUuid = inviterLevelTwoUuid;
    }

    public String getInviterLevelThreeUuid() {
        return inviterLevelThreeUuid;
    }

    public void setInviterLevelThreeUuid(String inviterLevelThreeUuid) {
        this.inviterLevelThreeUuid = inviterLevelThreeUuid;
    }

    public String getTopUuid() {
        return topUuid;
    }

    public void setTopUuid(String topUuid) {
        this.topUuid = topUuid;
    }

    @Override
    public String toString() {
        return "UserRelationDto{" +
                "userUuid='" + userUuid + '\'' +
                ", inviterLevelOneUuid='" + inviterLevelOneUuid + '\'' +
                ", inviterLevelTwoUuid='" + inviterLevelTwoUuid + '\'' +
                ", inviterLevelThreeUuid='" + inviterLevelThreeUuid + '\'' +
                ", topUuid='" + topUuid + '\'' +
                '}';
    }
}
