package cn.zjhf.kingold.trade.entity.OutVO;

/**
 * Created by liuyao on 2017/7/13.
 */
public class BaofooPayParamVO {
    private String merchantId;
    private String terminalId;
    private String sign;
    private String requestParams;

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    public String getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getRequestParams() {
        return requestParams;
    }

    public void setRequestParams(String requestParams) {
        this.requestParams = requestParams;
    }

    @Override
    public String toString() {
        return "BaofooPayParamVO{" +
                "merchantId='" + merchantId + '\'' +
                ", terminalId='" + terminalId + '\'' +
                ", sign='" + sign + '\'' +
                ", requestParams='" + requestParams + '\'' +
                '}';
    }
}
