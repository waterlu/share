package cn.zjhf.kingold.trade.entity;

import cn.zjhf.kingold.trade.utils.DataUtils;
import cn.zjhf.kingold.trade.utils.DateUtil;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by zhangyijie on 2017/8/4.
 */
public class ProductCriticalDateVO {
    /**
     *募集起始日, 格式为 YYYY-MM-DD
     */
    private Date raiseStartDate;
    /**
     * 募集截止日, 格式为 YYYY-MM-DD
     */
    private Date raiseEndDate;
    /**
     * 产品成立日, 格式为 YYYY-MM-DD
     */
    private Date productEstablishmentDate;
    /**
     * 实际放款日, 格式为 YYYY-MM-DD
     */
    private Date paymentDate;
    /**
     * 产品起息日, 格式为 YYYY-MM-DD
     */
    private Date productInterestDate;
    /**
     * 实际还款日, 格式为 YYYY-MM-DD
     */
    private Date repaymentDate;
    /**
     * 产品发布日, 格式为 YYYY-MM-DD
     */
    private Date productPublishDate;

    public Date getRaiseStartDate() {
        return raiseStartDate;
    }

    public void setRaiseStartDate(Date raiseStartDate) {
        this.raiseStartDate = raiseStartDate;
    }

    public Date getRaiseEndDate() {
        return raiseEndDate;
    }

    public void setRaiseEndDate(Date raiseEndDate) {
        this.raiseEndDate = raiseEndDate;
    }

    public Date getProductEstablishmentDate() {
        return productEstablishmentDate;
    }

    public void setProductEstablishmentDate(Date productEstablishmentDate) {
        this.productEstablishmentDate = productEstablishmentDate;
    }

    public Date getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(Date paymentDate) {
        this.paymentDate = paymentDate;
    }

    public Date getProductInterestDate() {
        return productInterestDate;
    }

    public void setProductInterestDate(Date productInterestDate) {
        this.productInterestDate = productInterestDate;
    }

    public Date getRepaymentDate() {
        return repaymentDate;
    }

    public void setRepaymentDate(Date repaymentDate) {
        this.repaymentDate = repaymentDate;
    }

    public Date getProductPublishDate() {
        return productPublishDate;
    }

    public void setProductPublishDate(Date productPublishDate) {
        this.productPublishDate = productPublishDate;
    }

    public Map<String, Object> getMap() {
        Map<String, Object> param = new HashMap<>();

        if(null != raiseStartDate){
            param.put("raiseStartDate", DateUtil.formateDate(raiseStartDate));
        }

        if(null != raiseEndDate){
            param.put("raiseEndDate", DateUtil.formateDate(raiseEndDate));
        }

        if(null != productEstablishmentDate){
            param.put("productEstablishmentDate", DateUtil.formateDate(productEstablishmentDate));
        }

        if(null != paymentDate){
            param.put("paymentDate", DateUtil.formateDate(paymentDate));
        }

        if(null != productInterestDate){
            param.put("productInterestDate", DateUtil.formateDate(productInterestDate));
        }

        if(null != repaymentDate){
            param.put("repaymentDate", DateUtil.formateDate(repaymentDate));
        }

        if(null != productPublishDate){
            param.put("productPublishDate", DateUtil.formateDate(productPublishDate));
        }

        return param;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("raiseStartDate: " + DataUtils.toString(raiseStartDate) + ", ");
        sb.append("raiseEndDate: " + DataUtils.toString(raiseEndDate) + ", ");
        sb.append("productEstablishmentDate: " + DataUtils.toString(productEstablishmentDate));
        sb.append("paymentDate: " + DataUtils.toString(paymentDate));
        sb.append("productInterestDate: " + DataUtils.toString(productInterestDate));
        sb.append("repaymentDate: " + DataUtils.toString(repaymentDate));
        sb.append("productPublishDate: " + DataUtils.toString(productPublishDate));
        return sb.toString();
    }
}
