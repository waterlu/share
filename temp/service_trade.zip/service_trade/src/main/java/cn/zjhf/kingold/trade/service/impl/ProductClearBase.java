package cn.zjhf.kingold.trade.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.service_consumer.service.UserServiceConsumer;
import cn.zjhf.kingold.trade.client.ProductClient;
import cn.zjhf.kingold.trade.constant.*;
import cn.zjhf.kingold.trade.entity.*;
import cn.zjhf.kingold.trade.persistence.dao.*;
import cn.zjhf.kingold.trade.service.*;
import cn.zjhf.kingold.trade.utils.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.serializer.JdkSerializationRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * Created by zhangyijie on 2017/5/19.
 */
@Service
public class ProductClearBase {
    private static final Logger logger = LoggerFactory.getLogger(ProductClearBase.class);

    //默认收益计算基数
    public static final int RATEFORMULAPARAM = 365;

    @Autowired
    protected StringRedisTemplate stringRedisTemplate;

    @Autowired
    protected RedisConnectionFactory redisConnectionFactory;

    @Autowired
    protected TradeOrderMapper tradeOrderMapper;

    @Autowired
    protected TradeInvestSummaryMapper tradeInvestSummaryMapper;

    @Autowired
    protected ProductClient productClient;

    @Autowired
    protected AccountMapper accountMapper;

    @Autowired
    protected AccountBaofooCustodyMapper accountBaofooCustodyMapper;

    @Autowired
    protected OperationReportMapper operationReportMapper;

    @Autowired
    private UserServiceConsumer userServiceConsumer;

    @Autowired
    protected TradePaymentSummaryMapper tradePaymentSummaryMapper;

    @Autowired
    protected IAccountTransactionService accountTransactionService;

    @Autowired
    protected IPayService payService;

    protected static final String URL_PRODUCT_DETAIL_FIXED = "/product/fixedIncome/%s";
    protected static final String URL_PRODUCT_DETAIL_FIXED_LIST = "/product/fixedIncome/list";
    protected static final String URL_PRODUCT_PRIVATE = "/product/privateFund/%s";
    protected static final String URL_PRODUCT_UPDATE = "/product/%s";
    protected static final String URL_PRODUCT_LSTBYCONDITION = "/product/lstByCondition";
    protected static final String URL_PRODUCT_REPORT = "/report/getCommReport";
    protected static final String URL_PRODUCT_DESCCODE = "/product/descriptionCode/%s";

    /**
     * 标记时间
     * @param key, minuteCount
     * @return
     */
    public String signTime(String key) {
        if(DataUtils.isEmpty(key)) {
            logger.error("Key: " + DataUtils.toString(key));
            return DateUtil.formatTime(DateUtil.strToDate("1999-12-31"));
        }

        if(stringRedisTemplate == null) {
            logger.error("StringRedisTemplate 初始化错误或者连接失败");
            return DateUtil.formatTime(DateUtil.strToDate("1999-12-31"));
        }

        String lastTime = stringRedisTemplate.opsForValue().getAndSet(key, DateUtil.formatTime(new Date()));

        if(DataUtils.isNotEmpty(lastTime)) {
            return lastTime;
        }else {
            return DateUtil.formatTime(DateUtil.strToDate("1999-12-31"));
        }
    }

    /**
     * 锁定指定key，锁定时间为minuteCount分钟
     * @param key, minuteCount
     * @return
     */
    public boolean checkKeyLock(String key, int minuteCount) {
        if(DataUtils.isEmpty(key) || minuteCount<=0) {
            logger.info("Key: " + DataUtils.toString(key) + ", MinuteCount: " + minuteCount);
            return false;
        }

        if(stringRedisTemplate == null) {
            logger.info("StringRedisTemplate 初始化错误或者连接失败");
            return false;
        }

        Object obj = stringRedisTemplate.opsForValue().get(key);
        final String value = "1";

        if(obj!=null) {
            if(obj instanceof String) {
                if(((String)obj).equals(value)) {
                    logger.info("key:" + key + ",  ExpireTime:" + stringRedisTemplate.getExpire(key));
                    return true;
                }
            }
        }

        stringRedisTemplate.opsForValue().set(key, value);
        stringRedisTemplate.expire(key, minuteCount, TimeUnit.MINUTES);
        return false;
    }

    protected String generateBatchNoEx(String prefix) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyMMddHHmmss");
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            logger.error("Thread.sleep", e);
        }
        Date now = new Date();
        String timeString = dateFormat.format(now);
        int randomNumber = RandUtil.getRandomNumbers(1000);
        String postfix = String.format("%04d", randomNumber);
        String batchNo = prefix + timeString + postfix;
        return batchNo;
    }

    protected String generateBatchNo(String prefix) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        Date now = new Date();
        String timeString = dateFormat.format(now);
        int randomNumber = RandUtil.getRandomNumbers(10000);
        String postfix = String.format("%04d", randomNumber);
        String batchNo = prefix + timeString + postfix;
        return batchNo;
    }

    //按照账户类型获取账户信息
    private Account getAccount(String type, String userUuid, String accountUuid) throws BusinessException {
        Map param = new HashMap();
        logger.debug(type + " " + userUuid + " " + accountUuid);

        if(DataUtils.isNotEmpty(type)) {
            param.put("accountType", type);
        }

        if(DataUtils.isNotEmpty(userUuid)) {
            param.put("userUuid", userUuid);
        }

        if(DataUtils.isNotEmpty(accountUuid)) {
            param.put("accountUuid", accountUuid);
        }

        if(param.size() == 0) {
            throw new BusinessException(TradeStatusMsg.ACCOUNT_NOT_EXIST, TradeStatusMsg.ACCOUNT_NOT_EXIST_MSG, false);
        }

        Map accountMap = accountMapper.get(param);
        BizParam bizParam = new BizParam(accountMap);

        Account account = new Account();
        if(accountMap != null) {
            account.setAccountUuid(bizParam.get("accountUuid"));
            account.setUserUuid(bizParam.get("userUuid"));
            account.setAccountCashAmount(bizParam.getBigDecimal("accountCashAmount"));
            account.setAccountFreezeAmount(bizParam.getBigDecimal("accountFreezeAmount"));

            String straccountNo = accountBaofooCustodyMapper.getAccountNoByUUId(account.getAccountUuid());
            long accountNo = 0;
            if(DataUtils.isNotEmpty(straccountNo)) {
                accountNo = Long.parseLong(straccountNo);
            }else {
                throw new BusinessException(TradeStatusMsg.ACCOUNT_NOT_EXIST, TradeStatusMsg.ACCOUNT_NOT_EXIST_MSG, false);
            }

            logger.debug("AccountNo: " + accountNo);
            account.setAccountNo(accountNo);
        }else {
            logger.info("Data Param: " + DataUtils.toString(param));
            throw new BusinessException(TradeStatusMsg.ACCOUNT_NOT_EXIST, TradeStatusMsg.ACCOUNT_NOT_EXIST_MSG, false);
        }

        return account;
    }

    protected Account getAccountByType(String type) throws BusinessException {
        return getAccount(type, null,null);
    }

    protected Account getAccountByUserUuid(String type, String userUuid) throws BusinessException {
        return getAccount(type, userUuid,null);
    }

    protected Account getAccountByAccountUuid(String accountUuid) throws BusinessException {
        return getAccount(null, null,accountUuid);
    }

    protected Account getAccountByProductUuid(String productUuid) throws BusinessException {
        ProductFixedIncome productInfo = getFixedIncomeProductById(productUuid);
        String productIssuerUuid = productInfo.getProductIssuerUuid();
        return getAccountByUserUuid(BizDefine.ACCOUNT_TYPE_ZJ_FINANCIER_DEPOSIT, productIssuerUuid);
    }

    protected void checkAccount(Account... accounts) throws BusinessException {
        if(accounts != null) {
            for(Account account : accounts) {
                if(account == null) {
                    throw new BusinessException(AccountStatusMsg.ACCOUNT_NOT_EXIST_CODE, AccountStatusMsg.ACCOUNT_NOT_EXIST, false);
                }
            }
        }else {
            throw new BusinessException(AccountStatusMsg.ACCOUNT_NOT_EXIST_CODE, AccountStatusMsg.ACCOUNT_NOT_EXIST, false);
        }
    }

    protected void bizCheck(Object obj) throws BusinessException {
        if(obj == null) {
            throw new BusinessException(TradeStatusMsg.SYSTEM_BIZ_ERR, TradeStatusMsg.SYSTEM_BIZ_ERR_MSG, false);
        }
    }

    /**
     * 新手标检查
     * @param productInfo 产品信息Map
     * @param userUuid
     * @throws BusinessException
     */
    protected void checkNoviceLabel(Map productInfo, String userUuid) throws BusinessException {
        logger.info(DataUtils.toString(productInfo));
        boolean isNoviceLabel = false;
        if((productInfo != null) && (productInfo.size() > 0)) {
            isNoviceLabel = ProductFixedIncome.isNoviceLabel((String) productInfo.get("productLabel"));
        }

        if(isNoviceLabel && havaValidOrder(null, userUuid, null)) {
            throw new BusinessException(TradeStatusMsg.TRADE_NOVICE_LABEL_CHECK_FAIL, TradeStatusMsg.TRADE_NOVICE_LABEL_CHECK_FAIL_MSG, false);
        }
    }

    protected void statusCheck(int status, int... optstatus1) throws BusinessException {
        if(!DataUtils.isContain(status, optstatus1)) {
            throw new BusinessException(TradeStatusMsg.WORKFLOW_STATUS_ERR, TradeStatusMsg.WORKFLOW_STATUS_ERR_MSG, false);
        }
    }

    //获取固收产品
    protected ProductFixedIncome getFixedIncomeProductById(String productUUId) throws BusinessException {
        Map<String, Object> param = new HashMap<>();
        ResponseResult responseResult = productClient.getFixedIncome(productUUId, param);
        logger.info((responseResult != null) ? responseResult.toString() : "null");

        if((responseResult == null)||(responseResult.getCode() != TradeError.OK)||(responseResult.getData() == null)) {
            throw new BusinessException(TradeStatusMsg.PRODUCT_NOT_EXIST, TradeStatusMsg.PRODUCT_NOT_EXIST_MSG, false);
        }

        ProductFixedIncome productInfo = JsonUtil.getData(responseResult, ProductFixedIncome.class);
        if(productInfo == null) {
            throw new BusinessException(TradeStatusMsg.PRODUCT_NOT_EXIST, TradeStatusMsg.PRODUCT_NOT_EXIST_MSG, false);
        }

        return productInfo;
    }

    //获取固收产品列表
    protected List<ProductFixedIncome> getFixedIncomeProductList(int status) throws BusinessException {
        List<ProductFixedIncome> productList = new ArrayList<ProductFixedIncome>();

        Map<String, Object> param = new HashMap<>();
        param.put("productStatus", status);
        param.put("operateFlag", true);
        ResponseResult responseResult = productClient.getFixedIncomeList(param);
        logger.info((responseResult != null) ? responseResult.toString() : "null");

        if((responseResult == null)||(responseResult.getCode() != TradeError.OK)||(responseResult.getData() == null)) {
            return productList;
        }

        productList = JsonUtil.getDataArray(responseResult, ProductFixedIncome.class);
        if(null == productList) {
            productList = new ArrayList<ProductFixedIncome>();
        }

        return productList;
    }

    protected String getProductDescriptionCode(String productUUId) throws BusinessException {
        ResponseResult responseResult = productClient.getDescriptionCode(productUUId, new HashMap<String, Object>());
        logger.info((responseResult != null) ? responseResult.toString() : "null");

        if((responseResult == null)||(responseResult.getCode() != TradeError.OK)||(responseResult.getData() == null)) {
            return "";
        }

        if(responseResult.getData() instanceof String) {
            return (String)responseResult.getData();
        }

        return "";
    }

    protected boolean havaValidOrder(String productUuid, String userUuid, String userPhone) {
        WhereCondition condition = new WhereCondition();
        condition.setCondi("product_uuid", productUuid);
        condition.setCondi("user_uuid", userUuid);
        condition.setCondi("user_phone", userPhone);

        String ret = tradeOrderMapper.havaValidOrder(condition);
        logger.info("tradeOrderMapper.havaValidOrder: " + DataUtils.toString(ret));
        return DataUtils.isNotEmpty(ret);
    }

    protected double lstRaiseAmt(String productUuid) {
        String amtStr = tradeOrderMapper.lstRaiseAmt(productUuid);

        if(DataUtils.isNotEmpty(amtStr)) {
            return Double.parseDouble(amtStr.trim());
        }

        return 0.0;
    }

    //获取私募产品
    protected ProductPrivateFund getPrivateProductById(String productUUId) throws BusinessException {
        Map<String, Object> param = new HashMap<>();
        ResponseResult responseResult = productClient.getPrivateFund(productUUId, param);
        logger.info((responseResult != null) ? responseResult.toString() : "null");

        if((responseResult == null)||(responseResult.getCode() != TradeError.OK)||(responseResult.getData() == null)) {
            throw new BusinessException(TradeStatusMsg.PRODUCT_NOT_EXIST, TradeStatusMsg.PRODUCT_NOT_EXIST_MSG, false);
        }

        ProductPrivateFund productInfo = JsonUtil.getData(responseResult, ProductPrivateFund.class);
        if(productInfo == null) {
            throw new BusinessException(TradeStatusMsg.PRODUCT_NOT_EXIST, TradeStatusMsg.PRODUCT_NOT_EXIST_MSG, false);
        }

        return productInfo;
    }

    protected int getProductStatus(String product_uuid, String productType) throws BusinessException {
        if(productType.equals(ProductType.PRODUCT_FT)) {
            ProductFixedIncome productInfo = getFixedIncomeProductById(product_uuid);
            return productInfo.getProductStatus();
        }

        ProductPrivateFund productInfo = getPrivateProductById(product_uuid);
        return productInfo.getProductStatus();
    }

    protected int getProductOnStatus(String product_uuid, String productType) throws BusinessException {
        if(productType.equals(ProductType.PRODUCT_FT)) {
            ProductFixedIncome productInfo = getFixedIncomeProductById(product_uuid);
            return productInfo.getProductOnStatus();
        }

        ProductPrivateFund productInfo = getPrivateProductById(product_uuid);
        return productInfo.getProductOnStatus();
    }

    public void updatePrivateProductRaiseStatus(String productUUId, int status, String createBy) throws BusinessException {
        Map<String, Object> param = new HashMap<>();
        param.put("productStatus", status);
        param.put("productChangeType", BizDefine.PRODUCT_CHANGE_TYPE_STATUS);

        if(null != createBy) {
            param.put("createBy", createBy);
            if (status == BizDefine.PRODUCT_STATUS_ENDRAISE) {
                param.put("raiseEndDate", DateUtil.formateDate(new Date()));
            }else if (status == BizDefine.PRODUCT_STATUS_RAISE){
                param.put("raiseStartDate", DateUtil.formateDate(new Date()));
            }
        }

        try {
            ResponseResult responseResult = productClient.update(productUUId, param);
            logger.info((responseResult != null) ? responseResult.toString() : "null");

            if((responseResult == null)||(responseResult.getCode() != TradeError.OK)) {
                throw new BusinessException(TradeStatusMsg.PRODUCT_UPDATE_PRODUCT_STATUS_ERR, TradeStatusMsg.PRODUCT_UPDATE_PRODUCT_STATUS_ERR_MSG, false);
            }
        } catch (BusinessException e) {
            logger.error("更新产品状态异常", e);
            throw(e);
        }
    }

    //更新产品状态
    public void updateProductStatus(String productUUId, int status, String createBy, ProductCriticalDateVO productCriticalDate) throws BusinessException {
        Map<String, Object> param = new HashMap<>();
        param.put("productStatus", status);
        param.put("productChangeType", BizDefine.PRODUCT_CHANGE_TYPE_STATUS);

        if(null != productCriticalDate) {
            logger.info(productCriticalDate.toString());
            param.putAll(productCriticalDate.getMap());
        }

        if(null != createBy) {
            param.put("createBy", createBy);
        }

        logger.info("productClient.update: {}， {}", productUUId, DataUtils.toString(param));

        try {
            ResponseResult responseResult = productClient.update(productUUId, param);
            logger.info("responseResult: {}", (responseResult != null) ? responseResult.toString() : "null");

            if ((responseResult == null) || (responseResult.getCode() != TradeError.OK)) {
                throw new BusinessException(TradeStatusMsg.PRODUCT_UPDATE_PRODUCT_STATUS_ERR,
                        TradeStatusMsg.PRODUCT_UPDATE_PRODUCT_STATUS_ERR_MSG, false);
            }
        } catch (BusinessException e) {
            logger.error("更新产品状态异常", e);
            throw (e);
        }
    }

    //更新产品上下架
    protected void updateProductShelves(String productUUId, int shelvesFlag, String createBy) throws BusinessException {
        Map<String, Object> param = new HashMap<>();
        param.put("productOnStatus", shelvesFlag);
        param.put("productChangeType", BizDefine.PRODUCT_CHANGE_TYPE_SHELVES);
        if(null != createBy) {
            param.put("createBy", createBy);
        }

        try {
            ResponseResult responseResult = productClient.update(productUUId, param);
            logger.info("responseResult: " + ((responseResult != null) ? responseResult.toString() : "null"));

            if((responseResult == null)||(responseResult.getCode() != TradeError.OK)) {
                throw new BusinessException(TradeStatusMsg.PRODUCT_UPDATE_PRODUCT_SHELVES_ERR, TradeStatusMsg.PRODUCT_UPDATE_PRODUCT_SHELVES_ERR_MSG, false);
            }
        } catch (BusinessException e) {
            logger.error("更新产品上下架异常", e);
            throw(e);
        }
    }

    //更新产品募集进度
    protected void updateProductProgress(String productUUId, double manualAmount, String productType, String createBy) throws BusinessException {
        Map<String, Object> param = new HashMap<>();
        param.put("productType", productType);
        param.put("productManual", manualAmount);
        param.put("productChangeType", BizDefine.PRODUCT_CHANGE_TYPE_RAISEAMOUNT);
        if(null != createBy) {
            param.put("createBy", createBy);
        }

        try {
            ResponseResult responseResult = productClient.update(productUUId, param);
            logger.info((responseResult != null) ? responseResult.toString() : "null");

            if ((responseResult == null) || (responseResult.getCode() != TradeError.OK)) {
                throw new BusinessException(TradeStatusMsg.PRODUCT_UPDATE_PRODUCT_RAISEPROGRESS_ERR, TradeStatusMsg.PRODUCT_UPDATE_PRODUCT_RAISEPROGRESS_ERR_MSG, false);
            }
        } catch (BusinessException e) {
            logger.error("更新产品募集进度异常", e);
            throw (e);
        }
    }

    //根据条件查询指定交易记录
    protected TradeOrder lstTradeOrderByOrderBillCode(String orderBillCode) {
        WhereCondition condition = new WhereCondition();
        condition.setCondi("order_bill_code", orderBillCode);
        condition.noDelete();
        List<TradeOrder> items = lstTradeOrdersByCondition(condition);
        return (items.size() > 0) ? items.get(0) : null;
    }

    //根据条件查询指定交易记录
    protected List<TradeOrder> lstTradeOrdersByCondition(WhereCondition condition) {
        List<TradeOrder> items = new ArrayList<TradeOrder>();
        List<Map> maps = tradeOrderMapper.lstByCondition(condition);
        for(Map map : maps) {
            BizParam bizParam = new BizParam(map);
            TradeOrder tradeOrder = new TradeOrder();
            tradeOrder.setUserUuid(bizParam.get("user_uuid"));
            tradeOrder.setAccountUuid(bizParam.get("account_uuid"));

            tradeOrder.setOrderBillCode(bizParam.get("order_bill_code"));
            tradeOrder.setUserName(bizParam.get("user_name"));
            tradeOrder.setUserPhone(bizParam.get("user_phone"));
            tradeOrder.setTransactionChannel(bizParam.get("transaction_channel"));
            tradeOrder.setTransactionTime(bizParam.getDate("transaction_time"));
            tradeOrder.setProductUuid(bizParam.get("product_uuid"));
            tradeOrder.setOrderAmount(bizParam.getBigDecimal("order_amount"));

            tradeOrder.setExpectedProfitAmount(bizParam.getBigDecimal("expected_profit_amount"));
            tradeOrder.setPaidAmount(bizParam.getBigDecimal("paid_amount"));
            tradeOrder.setMarketingAmount(bizParam.getBigDecimal("marketing_amount"));
            tradeOrder.setProfitAmount(bizParam.getBigDecimal("profit_amount"));
            tradeOrder.setCashAmount(bizParam.getBigDecimal("cash_amount"));

            tradeOrder.setOrderStatus(bizParam.getByte("order_status"));
            tradeOrder.setMarketingRateAmount(bizParam.getBigDecimal("marketing_rate_amount"));
            tradeOrder.setBelongMerchantNum(bizParam.getString("belong_merchant_num"));

            items.add(tradeOrder);
        }

        return items;
    }

    //添加资金流水
    protected String insertAccountTransactionEx(String orderCode, Account outAccount, Account inAccount, double amount, String type, String tradeOrderUuid, String transactionChannel) throws BusinessException {
        AccountTransaction accountTransaction = new AccountTransaction();

        if(DataUtils.isNotEmpty(tradeOrderUuid)) {
            accountTransaction.setTradeOrderUuid(tradeOrderUuid);
        }

        accountTransaction.setTradeOrderBillCodeExtend(orderCode);
        accountTransaction.setTradeOrderBillCode(orderCode);
        accountTransaction.setAccountUuid(outAccount.getAccountUuid());
        accountTransaction.setAccountNo(Long.toString(outAccount.getAccountNo()));
        accountTransaction.setUserUuid(outAccount.getUserUuid());

        accountTransaction.setOppoAccountUuid(inAccount.getAccountUuid());
        accountTransaction.setOppoAccountNo(Long.toString(inAccount.getAccountNo()));
        accountTransaction.setOppoUserUuid(inAccount.getUserUuid());

        if(null != transactionChannel) {
            accountTransaction.setTransactionChannel(transactionChannel);
        }
        accountTransaction.setTransactionAmount(new BigDecimal(amount));
        accountTransaction.setTradeType(type);

        Map map = accountTransaction.getMap();
        BizParam retMap = new BizParam(accountTransactionService.insert(map));

        if(retMap.containsKey("transactionBillCode")) {
            return retMap.get("transactionBillCode");
        }else {
            return "";
        }
    }


    /**
     * 获取用户信息
     *
     * @param userUuid
     * @return
     * @throws BusinessException
     */
    protected UserInfo getUserInfo(String userUuid) throws BusinessException {
        Map params = new HashMap();
        params.put("properties", "userUuid$$userType$$investorMobile$$investorRealName$$investorIdCardNo$$investorType"
                + "$$investorOrganizationPath$$investorOrganizationUuid$$userStatus$$userVerifyStatus$$issuerName$$legalPersonName");
        ResponseResult result = userServiceConsumer.get(String.format(URL.URL_GET_USER, userUuid), params);
        if (result.isSuccessful()) {
            if(result.getData() instanceof Map) {
                return new UserInfo((Map)result.getData());
            }else {
                return null;
            }
        } else if (result.getCode() == 1109) {//用户被冻结
            return null;
        } else {
            logger.error("get user info error:{},{}", result.getCode(), result.getMsg());
            return null;
        }
    }

    protected int lstQueryDataCount(String sql) {
        int fromPos = sql.lastIndexOf("from");
        if(fromPos < 0) {
            fromPos = sql.lastIndexOf("FROM");
        }

        int limitPos = sql.lastIndexOf("limit");
        if(limitPos < 0) {
            limitPos = sql.lastIndexOf("LIMIT");
        }

        String tmpSql = sql;
        if(limitPos > 0) {
            tmpSql = tmpSql.substring(0, limitPos);
        }

        if(fromPos > 0) {
            tmpSql = "SELECT Count(*) " + tmpSql.substring(fromPos);
        }

        int groupByPos = sql.lastIndexOf("GROUP BY");
        if(groupByPos < 0) {
            groupByPos = sql.lastIndexOf("group by");
        }

        if(groupByPos > 0) {
            tmpSql = "SELECT Count(*) FROM (" + tmpSql + ") TMP WHERE 1";
        }

        logger.info(tmpSql);
        return operationReportMapper.lstQueryCount(new QueryUtils(tmpSql));
    }
}
