package cn.zjhf.kingold.trade.persistence.mq.message;

import cn.zjhf.kingold.rocketmq.base.MQMessage;
import cn.zjhf.kingold.trade.utils.DataUtils;

/**
 * Created by zhangyijie on 2018/3/12.
 */
public class ContractFillMessage implements MQMessage {
    private String productUuid;

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    @Override
    public String getKey() {
        return productUuid;
    }

    @Override
    public String toString() {
        return DataUtils.toString(productUuid);
    }
}
