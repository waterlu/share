------------------------------
-- 修改交易订单表
------------------------------
ALTER TABLE kingold_trade.trade_order ADD `coupon_interest_period` int(11) DEFAULT '0' COMMENT '加息券加息天数';