###############################
# 修改交易订单表
###############################
ALTER TABLE kingold_trade.trade_order ADD `pay_seq` int(11) DEFAULT '0' COMMENT '支付尝试次数';
ALTER TABLE kingold_trade.trade_order ADD `order_pay_status` tinyint(4) DEFAULT '0' COMMENT '交易子状态(0-未支付,1-支付处理中,2-已付款,3-支付失败)';
ALTER TABLE kingold_trade.trade_order ADD `product_id` bigint(20) DEFAULT '0' COMMENT '产品ID';
ALTER TABLE kingold_trade.trade_order ADD `payee_account_no` bigint(20) DEFAULT '0' COMMENT '收款方账号';
ALTER TABLE kingold_trade.trade_order ADD `product_rookie_flag` tinyint(4) DEFAULT '0' COMMENT '是否新手标产品';
ALTER TABLE kingold_trade.trade_order ADD KEY `idx_trade_order_unique_identifier` (`unique_identifier`);

###############################
# 增加奖励订单表
###############################
CREATE TABLE `reward_order` (
  `reward_order_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `user_uuid` char(32) NOT NULL COMMENT '用户UUID',
  `order_bill_code` char(24) NOT NULL COMMENT '订单号',
  `order_time` datetime DEFAULT NULL COMMENT '订单时间',
  `delete_flag` tinyint(4) NOT NULL DEFAULT '0' COMMENT '删除标记',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`reward_order_id`),
  KEY `idx_reward_order_user_uuid` (`user_uuid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='奖励订单表';