# version

# 1.0.0

从原service_product复制产品类相关接口，集成服务注册中心和服务配置中心