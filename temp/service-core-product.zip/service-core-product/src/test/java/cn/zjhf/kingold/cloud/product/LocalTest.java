package cn.zjhf.kingold.cloud.product;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.product.entity.Product;
import cn.zjhf.kingold.product.entity.ProductSortModel;
import cn.zjhf.kingold.product.service.IProductService;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.collections4.CollectionUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

@RunWith(SpringRunner.class)
public class LocalTest {
	private static Logger LOGGER = LoggerFactory.getLogger(LocalTest.class);

	@Test
	public void test() {
		List<ProductSortModel> list = new ArrayList<>();
		ProductSortModel productSortModel1 = new ProductSortModel();
		productSortModel1.setCreateTime(new Date());
		productSortModel1.setProductLabel("1$$2");
		productSortModel1.setProductPeriod(180);
		productSortModel1.setProductPeriodType("D");
		productSortModel1.setProductShowOrder(10);
		productSortModel1.setProductStatus(2);
		productSortModel1.setVipFlag(0);
		list.add(productSortModel1);
		ProductSortModel productSortModel2 = new ProductSortModel();
		productSortModel2.setCreateTime(new Date());
		productSortModel2.setProductLabel("1");
		productSortModel2.setProductPeriod(280);
		productSortModel2.setProductPeriodType("D");
		productSortModel2.setProductShowOrder(1);
		productSortModel2.setProductStatus(2);
		productSortModel2.setVipFlag(0);
		list.add(productSortModel2);
		ProductSortModel productSortModel3 = new ProductSortModel();
		productSortModel3.setCreateTime(new Date());
		productSortModel3.setProductLabel("2");
		productSortModel3.setProductPeriod(10);
		productSortModel3.setProductPeriodType("D");
		productSortModel3.setProductShowOrder(10);
		productSortModel3.setProductStatus(2);
		productSortModel3.setVipFlag(1);
		list.add(productSortModel3);
		ProductSortModel productSortModel4 = new ProductSortModel();
		productSortModel4.setCreateTime(new Date());
		productSortModel4.setProductLabel("2");
		productSortModel4.setProductPeriod(180);
		productSortModel4.setProductPeriodType("D");
		productSortModel4.setProductShowOrder(6);
		productSortModel4.setProductStatus(2);
		productSortModel4.setVipFlag(0);
		list.add(productSortModel4);
		ProductSortModel productSortModel5 = new ProductSortModel();
		productSortModel5.setCreateTime(new Date());
		productSortModel5.setProductLabel("2");
		productSortModel5.setProductPeriod(10);
		productSortModel5.setProductPeriodType("W");
		ProductSortModel productSortModel = new ProductSortModel();
		productSortModel.setCreateTime(new Date());
		productSortModel.setProductLabel("2");
		productSortModel.setProductPeriod(90);
		productSortModel.setProductPeriodType("D");
		productSortModel.setProductShowOrder(100);
		productSortModel.setProductStatus(2);
		productSortModel.setVipFlag(0);
		list.add(productSortModel);
		productSortModel5.setProductShowOrder(100);
		productSortModel5.setProductStatus(1);
		productSortModel5.setVipFlag(0);
		list.add(productSortModel5);
		ProductSortModel productSortModel6 = new ProductSortModel();
		productSortModel6.setCreateTime(new Date());
		productSortModel6.setProductLabel("2");
		productSortModel6.setProductPeriod(2);
		productSortModel6.setProductPeriodType("M");
		productSortModel6.setProductShowOrder(100);
		productSortModel6.setProductStatus(1);
		productSortModel6.setVipFlag(0);
		list.add(productSortModel6);
		ProductSortModel productSortModel7 = new ProductSortModel();
		productSortModel7.setCreateTime(new Date());
		productSortModel7.setProductLabel("2");
		productSortModel7.setProductPeriod(1);
		productSortModel7.setProductPeriodType("Y");
		productSortModel7.setProductShowOrder(100);
		productSortModel7.setProductStatus(2);
		productSortModel7.setVipFlag(0);
		list.add(productSortModel7);
		ProductSortModel productSortModel9 = new ProductSortModel();
		productSortModel9.setCreateTime(new Date());
		productSortModel9.setProductLabel("2");
		productSortModel9.setProductPeriod(366);
		productSortModel9.setProductPeriodType("D");
		productSortModel9.setProductShowOrder(100);
		productSortModel9.setProductStatus(0);
		productSortModel9.setVipFlag(0);
		list.add(productSortModel9);
		ProductSortModel productSortModel8 = new ProductSortModel();
		productSortModel8.setCreateTime(new Date());
		productSortModel8.setProductLabel("2");
		productSortModel8.setProductPeriod(180);
		productSortModel8.setProductPeriodType("D");
		productSortModel8.setProductShowOrder(100);
		productSortModel8.setProductStatus(2);
		productSortModel8.setVipFlag(1);
		list.add(productSortModel8);



		Collections.sort(list);
		System.out.println(JSONObject.toJSON(list));

	}

}
