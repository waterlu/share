package cn.zjhf.kingold.cloud.product;

import cn.zjhf.kingold.product.dto.ProductRemainDTO;
import cn.zjhf.kingold.product.util.BillUtil;
import com.alibaba.fastjson.JSON;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

import javax.ws.rs.core.MediaType;
import java.math.BigDecimal;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * 产品RESTFul接口测试
 * <p>@WebAppConfiguration：测试web应用</p>
 * <p>@Transactional：测试完成后回滚数据库操作</p>
 * <p>MockMvc：发送REST请求</p>
 * <p>@Before：每一个@Test前初始化MockMvc</>
 * <p>做REST接口测试的好处：直接测试外对接口的可用性，有参数校验和返回值处理</p>
 *
 * @author lutiehua
 * @date 2018/3/7
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@WebAppConfiguration
@Transactional
public class ProductResourceTests {

    private final Logger logger = LoggerFactory.getLogger(ProductResourceTests.class);

    private MockMvc mvc;

    @Autowired
    protected WebApplicationContext wac;

    @Before
    public void setUp() throws Exception {
        mvc = MockMvcBuilders.webAppContextSetup(wac).build();
    }

    /**
     * 测试更新产品募集金额
     */
    @Test
    public void testUpdateRemain() throws Exception {
        String callSystemID = "1002";
        String tradeID = "9dc9805a-2220-11e8-9955-00163e32c6dd";
        String product_uuid = "4ba8f115c95a43eaacda14242e35488e";

        // REST资源访问地址
        String uri = String.format("/product/%s/raise", product_uuid);

        // 参数
        ProductRemainDTO productRemainDTO = new ProductRemainDTO();
        productRemainDTO.setTraceID(tradeID);
        productRemainDTO.setCallSystemID(callSystemID);
        productRemainDTO.setUserUuid("659fcc603f5d424584ddf38ac5ddf283");
        String orderBillCode = BillUtil.generateBillCode("POX");
        productRemainDTO.setOrderBillCode(orderBillCode);
        productRemainDTO.setAmount(new BigDecimal(2));

        // HTTP PUT 请求
        RequestBuilder request = MockMvcRequestBuilders.put(uri)
                .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
                .content(JSON.toJSONString(productRemainDTO));

        // 发送请求
        ResultActions resultActions = mvc.perform(request);

        // 设置返回数据编码格式
        resultActions.andReturn().getResponse().setCharacterEncoding("UTF-8");

        // 输出返回值
        String response = resultActions.andReturn().getResponse().getContentAsString();
        logger.info(response);

        // 校验返回值（相当于Assert），失败报错
        // HTTP.code = 200
        // "code":200
        // "data":1
        resultActions.andExpect(status().isOk())
                .andExpect(jsonPath("code").value("200"))
                .andExpect(jsonPath("data").value("1"));
    }
}

































