package cn.zjhf.kingold.cloud.product;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.product.entity.InVO.ProductApiVO;
import cn.zjhf.kingold.product.entity.OutVO.ProductApiOutVO;
import cn.zjhf.kingold.product.entity.ProductChannelRelational;
import cn.zjhf.kingold.product.persistence.dao.ProductChannelRelationalMapper;
import cn.zjhf.kingold.product.service.IProductApiService;
import cn.zjhf.kingold.product.service.IProductService;
import cn.zjhf.kingold.product.service.impl.ProductServiceImpl;
import cn.zjhf.kingold.product.util.DataUtils;
import cn.zjhf.kingold.product.util.MapParamUtils;
import com.alibaba.fastjson.JSON;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ServiceProductApplicationTests {
	private static Logger LOGGER = LoggerFactory.getLogger(ServiceProductApplicationTests.class);

	@Autowired
	IProductApiService productApiService;

	@Autowired
	IProductService productService;

	@Autowired
	ProductChannelRelationalMapper productChannelRelationalMapper;

	@Test
	public void contextLoads() {
	}

	@Test
	public void testOnlineFixedIncome() throws BusinessException {
		ProductApiVO productApiVO = new ProductApiVO();
		productApiVO.setStartRow(0);
		productApiVO.setPageSize(10);
		productApiVO.setMerchantNum("00000");
		//ProductApiOutVO productApiOutVO = productApiService.fixOnlineList(productApiVO);

		//System.out.println(JSON.toJSON(productApiOutVO));
	}

	@Test
	public void testOffineFixedIncome() throws BusinessException {
		ProductApiVO productApiVO = new ProductApiVO();
		productApiVO.setStartRow(0);
		productApiVO.setPageSize(10);
		//ProductApiOutVO productApiOutVO = productApiService.fixOfflineList(productApiVO);

		//System.out.println(JSON.toJSON(productApiOutVO));
	}

	@Test
	public void testrelation() throws BusinessException {
		Map<String, Object> param = new HashMap();
		param.put("productType", "FIXI");
		List<Map> list = productService.getFixedIncomeList(param);

		for (Map one : list) {
			try {
				ProductChannelRelational productChannelRelational = new ProductChannelRelational();
				productChannelRelational.setChannelAppName("kingold");
				productChannelRelational.setChannelChargeRate(new BigDecimal(1.2));
				productChannelRelational.setInterExterChannel("2");
				productChannelRelational.setMerchantNum("00000");
				productChannelRelational.setProductAbbrName(MapParamUtils.getStringInMap(one, "productAbbrName"));
				productChannelRelational.setProductCode(MapParamUtils.getStringInMap(one, "productCode"));
				productChannelRelational.setProductEstablishmentDate(new Date());
				productChannelRelational.setProductType("FIXI");
				productChannelRelational.setWechatSendMark(1);
				productChannelRelational.setProductUuid(MapParamUtils.getStringInMap(one, "productUuid"));
				productChannelRelational.setChannelUuid("148c374bbd7342b1bafb7c52697c80df");
				productChannelRelational.setDeleteFlag(Integer.valueOf(0).byteValue());
				productChannelRelational.setCreateTime(new Date());
				productChannelRelational.setUpdateTime(new Date());
				productChannelRelationalMapper.insert(productChannelRelational);
			} catch (Exception e){

			}

		}

	}
}
