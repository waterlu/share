package cn.zjhf.kingold.cloud.product;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.product.constant.URL;
import cn.zjhf.kingold.product.dto.ProductRemainDTO;
import cn.zjhf.kingold.product.entity.ProductProgress;
import cn.zjhf.kingold.product.persistence.dao.ProductProgressMapper;
import cn.zjhf.kingold.product.service.IProductService;
import cn.zjhf.kingold.product.util.DateUtil;
import cn.zjhf.kingold.service_consumer.service.BaseServiceConsumer;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author lutiehua
 * @date 2018/3/7
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class ProductServiceTests {

    private static Logger LOGGER = LoggerFactory.getLogger(ProductServiceTests.class);

    @Autowired
    IProductService productService;

    @Autowired
    ProductProgressMapper productProgressMapper;

    @Autowired
    private BaseServiceConsumer baseServiceConsumer;

    @Test
    /**
     * 测试产品募集
     */
    public void testUpdateRemain() throws BusinessException {
        ProductRemainDTO productRemainDTO = new ProductRemainDTO();
        productRemainDTO.setTraceID("9dc9805a-2220-11e8-9955-00163e32c6dd");
        productRemainDTO.setCallSystemID("1002");
        productRemainDTO.setProductUuid("4ba8f115c95a43eaacda14242e35488e");
        productRemainDTO.setUserUuid("659fcc603f5d424584ddf38ac5ddf283");
        productRemainDTO.setAmount(new BigDecimal(2));
        int row = productService.updateRaise(productRemainDTO);
        Assert.assertEquals(row, 1);
    }

    @Test
    public void getProgress()throws BusinessException{
       ProductProgress pp= productProgressMapper.getProgress("4ba8f115c95a43eaacda14242e35488e");
    }

    @Test
    public void send()throws BusinessException{
        Map<String, Object> param = new HashMap(16);
        param.put("currentTime", DateUtil.formateDate(new Date(), DateUtil.CURRENTTIME_FORMAT));
        param.put("productPeriod", 28);
        param.put("productPeriodType", "天");
        param.put("productAbbrName", "定期理财");
        param.put("surplusAmount",100);
        param.put("notificationType","1024");
        param.put("phone","18812665667");
        ResponseResult responseResult = baseServiceConsumer.post(URL.MESSAGE_SEND,param);
    }
}
