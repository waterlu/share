###############################
# 产品募集流水表
###############################
CREATE TABLE kingold_product.`product_raise` (
  `product_raise_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `product_uuid` char(32) NOT NULL COMMENT '产品UUID',
  `user_uuid` char(32) NOT NULL COMMENT '用户UUID',
  `order_bill_code` varchar(32) DEFAULT NULL COMMENT '订单号',
  `order_amount` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '订单金额',
  `delete_flag` tinyint(4) NOT NULL DEFAULT '0',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_uuid` varchar(32) DEFAULT NULL COMMENT '更新标识',
  PRIMARY KEY (`product_raise_id`),
  KEY `idx_product_raise_order_bill_code` (`order_bill_code`),
  KEY `idx_product_raise_product_uuid` (`product_uuid`),
  KEY `idx_product_raise_user_uuid` (`user_uuid`),
  KEY `idx_product_raise_update_uuid` (`update_uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='产品募集日志';

###############################
# 补充产品募集日志
###############################
INSERT INTO kingold_product.product_raise (product_uuid, user_uuid, order_bill_code, order_amount)
    SELECT product_uuid, user_uuid, order_bill_code, order_amount
    FROM kingold_trade.trade_order
    WHERE order_status = 2 AND delete_flag = 0;

# 预上线环境和生产环境需要增加RocketMQ的配置信息
# rocket-mq.consumer-group-name=c_service-product
# rocket-mq.producer-retryTimes=3
# rocket-mq.producer-timeout=10000
