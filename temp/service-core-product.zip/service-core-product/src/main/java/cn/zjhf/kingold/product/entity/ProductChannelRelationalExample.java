package cn.zjhf.kingold.product.entity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ProductChannelRelationalExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private Integer limit;

    private Integer offset;

    public ProductChannelRelationalExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andChannelUuidIsNull() {
            addCriterion("channel_uuid is null");
            return (Criteria) this;
        }

        public Criteria andChannelUuidIsNotNull() {
            addCriterion("channel_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andChannelUuidEqualTo(String value) {
            addCriterion("channel_uuid =", value, "channelUuid");
            return (Criteria) this;
        }

        public Criteria andChannelUuidNotEqualTo(String value) {
            addCriterion("channel_uuid <>", value, "channelUuid");
            return (Criteria) this;
        }

        public Criteria andChannelUuidGreaterThan(String value) {
            addCriterion("channel_uuid >", value, "channelUuid");
            return (Criteria) this;
        }

        public Criteria andChannelUuidGreaterThanOrEqualTo(String value) {
            addCriterion("channel_uuid >=", value, "channelUuid");
            return (Criteria) this;
        }

        public Criteria andChannelUuidLessThan(String value) {
            addCriterion("channel_uuid <", value, "channelUuid");
            return (Criteria) this;
        }

        public Criteria andChannelUuidLessThanOrEqualTo(String value) {
            addCriterion("channel_uuid <=", value, "channelUuid");
            return (Criteria) this;
        }

        public Criteria andChannelUuidLike(String value) {
            addCriterion("channel_uuid like", value, "channelUuid");
            return (Criteria) this;
        }

        public Criteria andChannelUuidNotLike(String value) {
            addCriterion("channel_uuid not like", value, "channelUuid");
            return (Criteria) this;
        }

        public Criteria andChannelUuidIn(List<String> values) {
            addCriterion("channel_uuid in", values, "channelUuid");
            return (Criteria) this;
        }

        public Criteria andChannelUuidNotIn(List<String> values) {
            addCriterion("channel_uuid not in", values, "channelUuid");
            return (Criteria) this;
        }

        public Criteria andChannelUuidBetween(String value1, String value2) {
            addCriterion("channel_uuid between", value1, value2, "channelUuid");
            return (Criteria) this;
        }

        public Criteria andChannelUuidNotBetween(String value1, String value2) {
            addCriterion("channel_uuid not between", value1, value2, "channelUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidIsNull() {
            addCriterion("product_uuid is null");
            return (Criteria) this;
        }

        public Criteria andProductUuidIsNotNull() {
            addCriterion("product_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andProductUuidEqualTo(String value) {
            addCriterion("product_uuid =", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotEqualTo(String value) {
            addCriterion("product_uuid <>", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidGreaterThan(String value) {
            addCriterion("product_uuid >", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidGreaterThanOrEqualTo(String value) {
            addCriterion("product_uuid >=", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidLessThan(String value) {
            addCriterion("product_uuid <", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidLessThanOrEqualTo(String value) {
            addCriterion("product_uuid <=", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidLike(String value) {
            addCriterion("product_uuid like", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotLike(String value) {
            addCriterion("product_uuid not like", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidIn(List<String> values) {
            addCriterion("product_uuid in", values, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotIn(List<String> values) {
            addCriterion("product_uuid not in", values, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidBetween(String value1, String value2) {
            addCriterion("product_uuid between", value1, value2, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotBetween(String value1, String value2) {
            addCriterion("product_uuid not between", value1, value2, "productUuid");
            return (Criteria) this;
        }

        public Criteria andMerchantNumIsNull() {
            addCriterion("merchant_num is null");
            return (Criteria) this;
        }

        public Criteria andMerchantNumIsNotNull() {
            addCriterion("merchant_num is not null");
            return (Criteria) this;
        }

        public Criteria andMerchantNumEqualTo(String value) {
            addCriterion("merchant_num =", value, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumNotEqualTo(String value) {
            addCriterion("merchant_num <>", value, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumGreaterThan(String value) {
            addCriterion("merchant_num >", value, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumGreaterThanOrEqualTo(String value) {
            addCriterion("merchant_num >=", value, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumLessThan(String value) {
            addCriterion("merchant_num <", value, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumLessThanOrEqualTo(String value) {
            addCriterion("merchant_num <=", value, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumLike(String value) {
            addCriterion("merchant_num like", value, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumNotLike(String value) {
            addCriterion("merchant_num not like", value, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumIn(List<String> values) {
            addCriterion("merchant_num in", values, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumNotIn(List<String> values) {
            addCriterion("merchant_num not in", values, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumBetween(String value1, String value2) {
            addCriterion("merchant_num between", value1, value2, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andMerchantNumNotBetween(String value1, String value2) {
            addCriterion("merchant_num not between", value1, value2, "merchantNum");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameIsNull() {
            addCriterion("channel_app_name is null");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameIsNotNull() {
            addCriterion("channel_app_name is not null");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameEqualTo(String value) {
            addCriterion("channel_app_name =", value, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameNotEqualTo(String value) {
            addCriterion("channel_app_name <>", value, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameGreaterThan(String value) {
            addCriterion("channel_app_name >", value, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameGreaterThanOrEqualTo(String value) {
            addCriterion("channel_app_name >=", value, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameLessThan(String value) {
            addCriterion("channel_app_name <", value, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameLessThanOrEqualTo(String value) {
            addCriterion("channel_app_name <=", value, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameLike(String value) {
            addCriterion("channel_app_name like", value, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameNotLike(String value) {
            addCriterion("channel_app_name not like", value, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameIn(List<String> values) {
            addCriterion("channel_app_name in", values, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameNotIn(List<String> values) {
            addCriterion("channel_app_name not in", values, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameBetween(String value1, String value2) {
            addCriterion("channel_app_name between", value1, value2, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andChannelAppNameNotBetween(String value1, String value2) {
            addCriterion("channel_app_name not between", value1, value2, "channelAppName");
            return (Criteria) this;
        }

        public Criteria andInterExterChannelIsNull() {
            addCriterion("inter_exter_channel is null");
            return (Criteria) this;
        }

        public Criteria andInterExterChannelIsNotNull() {
            addCriterion("inter_exter_channel is not null");
            return (Criteria) this;
        }

        public Criteria andInterExterChannelEqualTo(String value) {
            addCriterion("inter_exter_channel =", value, "interExterChannel");
            return (Criteria) this;
        }

        public Criteria andInterExterChannelNotEqualTo(String value) {
            addCriterion("inter_exter_channel <>", value, "interExterChannel");
            return (Criteria) this;
        }

        public Criteria andInterExterChannelGreaterThan(String value) {
            addCriterion("inter_exter_channel >", value, "interExterChannel");
            return (Criteria) this;
        }

        public Criteria andInterExterChannelGreaterThanOrEqualTo(String value) {
            addCriterion("inter_exter_channel >=", value, "interExterChannel");
            return (Criteria) this;
        }

        public Criteria andInterExterChannelLessThan(String value) {
            addCriterion("inter_exter_channel <", value, "interExterChannel");
            return (Criteria) this;
        }

        public Criteria andInterExterChannelLessThanOrEqualTo(String value) {
            addCriterion("inter_exter_channel <=", value, "interExterChannel");
            return (Criteria) this;
        }

        public Criteria andInterExterChannelLike(String value) {
            addCriterion("inter_exter_channel like", value, "interExterChannel");
            return (Criteria) this;
        }

        public Criteria andInterExterChannelNotLike(String value) {
            addCriterion("inter_exter_channel not like", value, "interExterChannel");
            return (Criteria) this;
        }

        public Criteria andInterExterChannelIn(List<String> values) {
            addCriterion("inter_exter_channel in", values, "interExterChannel");
            return (Criteria) this;
        }

        public Criteria andInterExterChannelNotIn(List<String> values) {
            addCriterion("inter_exter_channel not in", values, "interExterChannel");
            return (Criteria) this;
        }

        public Criteria andInterExterChannelBetween(String value1, String value2) {
            addCriterion("inter_exter_channel between", value1, value2, "interExterChannel");
            return (Criteria) this;
        }

        public Criteria andInterExterChannelNotBetween(String value1, String value2) {
            addCriterion("inter_exter_channel not between", value1, value2, "interExterChannel");
            return (Criteria) this;
        }

        public Criteria andProductCodeIsNull() {
            addCriterion("product_code is null");
            return (Criteria) this;
        }

        public Criteria andProductCodeIsNotNull() {
            addCriterion("product_code is not null");
            return (Criteria) this;
        }

        public Criteria andProductCodeEqualTo(String value) {
            addCriterion("product_code =", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotEqualTo(String value) {
            addCriterion("product_code <>", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeGreaterThan(String value) {
            addCriterion("product_code >", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeGreaterThanOrEqualTo(String value) {
            addCriterion("product_code >=", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLessThan(String value) {
            addCriterion("product_code <", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLessThanOrEqualTo(String value) {
            addCriterion("product_code <=", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLike(String value) {
            addCriterion("product_code like", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotLike(String value) {
            addCriterion("product_code not like", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeIn(List<String> values) {
            addCriterion("product_code in", values, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotIn(List<String> values) {
            addCriterion("product_code not in", values, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeBetween(String value1, String value2) {
            addCriterion("product_code between", value1, value2, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotBetween(String value1, String value2) {
            addCriterion("product_code not between", value1, value2, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameIsNull() {
            addCriterion("product_abbr_name is null");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameIsNotNull() {
            addCriterion("product_abbr_name is not null");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameEqualTo(String value) {
            addCriterion("product_abbr_name =", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameNotEqualTo(String value) {
            addCriterion("product_abbr_name <>", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameGreaterThan(String value) {
            addCriterion("product_abbr_name >", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameGreaterThanOrEqualTo(String value) {
            addCriterion("product_abbr_name >=", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameLessThan(String value) {
            addCriterion("product_abbr_name <", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameLessThanOrEqualTo(String value) {
            addCriterion("product_abbr_name <=", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameLike(String value) {
            addCriterion("product_abbr_name like", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameNotLike(String value) {
            addCriterion("product_abbr_name not like", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameIn(List<String> values) {
            addCriterion("product_abbr_name in", values, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameNotIn(List<String> values) {
            addCriterion("product_abbr_name not in", values, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameBetween(String value1, String value2) {
            addCriterion("product_abbr_name between", value1, value2, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameNotBetween(String value1, String value2) {
            addCriterion("product_abbr_name not between", value1, value2, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductTypeIsNull() {
            addCriterion("product_type is null");
            return (Criteria) this;
        }

        public Criteria andProductTypeIsNotNull() {
            addCriterion("product_type is not null");
            return (Criteria) this;
        }

        public Criteria andProductTypeEqualTo(String value) {
            addCriterion("product_type =", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeNotEqualTo(String value) {
            addCriterion("product_type <>", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeGreaterThan(String value) {
            addCriterion("product_type >", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeGreaterThanOrEqualTo(String value) {
            addCriterion("product_type >=", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeLessThan(String value) {
            addCriterion("product_type <", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeLessThanOrEqualTo(String value) {
            addCriterion("product_type <=", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeLike(String value) {
            addCriterion("product_type like", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeNotLike(String value) {
            addCriterion("product_type not like", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeIn(List<String> values) {
            addCriterion("product_type in", values, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeNotIn(List<String> values) {
            addCriterion("product_type not in", values, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeBetween(String value1, String value2) {
            addCriterion("product_type between", value1, value2, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeNotBetween(String value1, String value2) {
            addCriterion("product_type not between", value1, value2, "productType");
            return (Criteria) this;
        }

        public Criteria andChannelChargeRateIsNull() {
            addCriterion("channel_charge_rate is null");
            return (Criteria) this;
        }

        public Criteria andChannelChargeRateIsNotNull() {
            addCriterion("channel_charge_rate is not null");
            return (Criteria) this;
        }

        public Criteria andChannelChargeRateEqualTo(BigDecimal value) {
            addCriterion("channel_charge_rate =", value, "channelChargeRate");
            return (Criteria) this;
        }

        public Criteria andChannelChargeRateNotEqualTo(BigDecimal value) {
            addCriterion("channel_charge_rate <>", value, "channelChargeRate");
            return (Criteria) this;
        }

        public Criteria andChannelChargeRateGreaterThan(BigDecimal value) {
            addCriterion("channel_charge_rate >", value, "channelChargeRate");
            return (Criteria) this;
        }

        public Criteria andChannelChargeRateGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("channel_charge_rate >=", value, "channelChargeRate");
            return (Criteria) this;
        }

        public Criteria andChannelChargeRateLessThan(BigDecimal value) {
            addCriterion("channel_charge_rate <", value, "channelChargeRate");
            return (Criteria) this;
        }

        public Criteria andChannelChargeRateLessThanOrEqualTo(BigDecimal value) {
            addCriterion("channel_charge_rate <=", value, "channelChargeRate");
            return (Criteria) this;
        }

        public Criteria andChannelChargeRateIn(List<BigDecimal> values) {
            addCriterion("channel_charge_rate in", values, "channelChargeRate");
            return (Criteria) this;
        }

        public Criteria andChannelChargeRateNotIn(List<BigDecimal> values) {
            addCriterion("channel_charge_rate not in", values, "channelChargeRate");
            return (Criteria) this;
        }

        public Criteria andChannelChargeRateBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("channel_charge_rate between", value1, value2, "channelChargeRate");
            return (Criteria) this;
        }

        public Criteria andChannelChargeRateNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("channel_charge_rate not between", value1, value2, "channelChargeRate");
            return (Criteria) this;
        }

        public Criteria andSignatureIsNull() {
            addCriterion("signature is null");
            return (Criteria) this;
        }

        public Criteria andSignatureIsNotNull() {
            addCriterion("signature is not null");
            return (Criteria) this;
        }

        public Criteria andSignatureEqualTo(String value) {
            addCriterion("signature =", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureNotEqualTo(String value) {
            addCriterion("signature <>", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureGreaterThan(String value) {
            addCriterion("signature >", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureGreaterThanOrEqualTo(String value) {
            addCriterion("signature >=", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureLessThan(String value) {
            addCriterion("signature <", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureLessThanOrEqualTo(String value) {
            addCriterion("signature <=", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureLike(String value) {
            addCriterion("signature like", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureNotLike(String value) {
            addCriterion("signature not like", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureIn(List<String> values) {
            addCriterion("signature in", values, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureNotIn(List<String> values) {
            addCriterion("signature not in", values, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureBetween(String value1, String value2) {
            addCriterion("signature between", value1, value2, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureNotBetween(String value1, String value2) {
            addCriterion("signature not between", value1, value2, "signature");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNull() {
            addCriterion("delete_flag is null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNotNull() {
            addCriterion("delete_flag is not null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagEqualTo(Byte value) {
            addCriterion("delete_flag =", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotEqualTo(Byte value) {
            addCriterion("delete_flag <>", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThan(Byte value) {
            addCriterion("delete_flag >", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThanOrEqualTo(Byte value) {
            addCriterion("delete_flag >=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThan(Byte value) {
            addCriterion("delete_flag <", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThanOrEqualTo(Byte value) {
            addCriterion("delete_flag <=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIn(List<Byte> values) {
            addCriterion("delete_flag in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotIn(List<Byte> values) {
            addCriterion("delete_flag not in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagBetween(Byte value1, Byte value2) {
            addCriterion("delete_flag between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotBetween(Byte value1, Byte value2) {
            addCriterion("delete_flag not between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("update_time is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("update_time is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("update_time =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("update_time <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("update_time >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("update_time >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("update_time <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("update_time <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("update_time in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("update_time not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("update_time between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("update_time not between", value1, value2, "updateTime");
            return (Criteria) this;
        }
    }

    /**
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}