package cn.zjhf.kingold.product.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class User implements Serializable {
    /**
     * 自增ID
     */
    private Long userId;

    /**
     * 用户UUID
     */
    private String userUuid;

    /**
     * 用户类型
     */
    private Short userType;

    /**
     * 用户状态
     */
    private Short userStatus;

    /**
     * 手机号码
     */
    private String userPhone;

    /**
     * 登录密码
     */
    private String userPassword;

    /**
     * 支付密码
     */
    private String payPassword;

    /**
     * 加密盐
     */
    private String encryptSalt;

    /**
     * 性别
     */
    private Short userGender;

    /**
     * 头像
     */
    private String userAvatar;

    /**
     * 内部用户标识
     */
    private Short isInner;

    /**
     * 专职用户标识
     */
    private Short isFullTime;

    /**
     * 邀请人ID
     */
    private Long inviterId;

    /**
     * 邀请人手机号码
     */
    private String inviterMobile;

    /**
     * 用户关系路径
     */
    private String userPath;

    /**
     * 真实姓名
     */
    private String userName;

    /**
     * 身份证号
     */
    private String userIdCardNumber;

    /**
     * 风险评测等级
     */
    private Short riskAssessmentLevel;

    /**
     * 注册时间
     */
    private Date registerTime;

    /**
     * 注册渠道编码
     */
    private String registerChannelCode;

    /**
     * 注册渠道名称
     */
    private String registerChannelName;

    /**
     * 注册版本编码
     */
    private String registerVersionCode;

    /**
     * 注册版本名称
     */
    private String registerVersionName;

    /**
     * 注册设备ID
     */
    private String registerDeviceId;

    /**
     * 注册设备类型
     */
    private String registerDeviceType;

    /**
     * 注册设备名称
     */
    private String registerDeviceName;

    /**
     * 注册设备操作系统
     */
    private String registerDeviceOs;

    /**
     * 注册IP
     */
    private String registerDeviceIp;

    /**
     * 最后登录时间
     */
    private Date userLoginTime;

    /**
     * 最后登录渠道编码
     */
    private String loginChannelCode;

    /**
     * 最后登录渠道名称
     */
    private String userLoginChannelName;

    /**
     * 最后登录版本编码
     */
    private String loginVersionCode;

    /**
     * 最后登录版本名称
     */
    private String userLoginVersionName;

    /**
     * 最后登录设备ID
     */
    private String userLoginDeviceCode;

    /**
     * 最后登录设备类型
     */
    private String userOginDeviceType;

    /**
     * 最后登录设备名称
     */
    private String userLoginDeviceName;

    /**
     * 最后登录设备操作系统
     */
    private String loginDeviceOs;

    /**
     * 最后登录IP
     */
    private String loginDeviceIp;

    private Short deleteFlag;

    private Date createTime;

    private String createBy;

    private Date updateTime;

    private String updateBy;

    private String signature;

    private static final long serialVersionUID = 1L;

    private int isQualiInv;

    private int userVerifyStatus;

    private String parentInviterUuid;

    private String parentInviterPhone;

    public int getUserVerifyStatus() {
        return userVerifyStatus;
    }

    public void setUserVerifyStatus(int userVerifyStatus) {
        this.userVerifyStatus = userVerifyStatus;
    }

    public String getParentInviterUuid() {
        return parentInviterUuid;
    }

    public void setParentInviterUuid(String parentInviterUuid) {
        this.parentInviterUuid = parentInviterUuid;
    }

    public String getParentInviterPhone() {
        return parentInviterPhone;
    }

    public void setParentInviterPhone(String parentInviterPhone) {
        this.parentInviterPhone = parentInviterPhone;
    }

    public int getIsQualiInv() {
        return isQualiInv;
    }

    public void setIsQualiInv(int isQualiInv) {
        this.isQualiInv = isQualiInv;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public Short getUserType() {
        return userType;
    }

    public void setUserType(Short userType) {
        this.userType = userType;
    }

    public Short getUserStatus() {
        return userStatus;
    }

    public void setUserStatus(Short userStatus) {
        this.userStatus = userStatus;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public String getPayPassword() {
        return payPassword;
    }

    public void setPayPassword(String payPassword) {
        this.payPassword = payPassword;
    }

    public String getEncryptSalt() {
        return encryptSalt;
    }

    public void setEncryptSalt(String encryptSalt) {
        this.encryptSalt = encryptSalt;
    }

    public Short getUserGender() {
        return userGender;
    }

    public void setUserGender(Short userGender) {
        this.userGender = userGender;
    }

    public String getUserAvatar() {
        return userAvatar;
    }

    public void setUserAvatar(String userAvatar) {
        this.userAvatar = userAvatar;
    }

    public Short getIsInner() {
        return isInner;
    }

    public void setIsInner(Short isInner) {
        this.isInner = isInner;
    }

    public Short getIsFullTime() {
        return isFullTime;
    }

    public void setIsFullTime(Short isFullTime) {
        this.isFullTime = isFullTime;
    }

    public Long getInviterId() {
        return inviterId;
    }

    public void setInviterId(Long inviterId) {
        this.inviterId = inviterId;
    }

    public String getInviterMobile() {
        return inviterMobile;
    }

    public void setInviterMobile(String inviterMobile) {
        this.inviterMobile = inviterMobile;
    }

    public String getUserPath() {
        return userPath;
    }

    public void setUserPath(String userPath) {
        this.userPath = userPath;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserIdCardNumber() {
        return userIdCardNumber;
    }

    public void setUserIdCardNumber(String userIdCardNumber) {
        this.userIdCardNumber = userIdCardNumber;
    }

    public Short getRiskAssessmentLevel() {
        return riskAssessmentLevel;
    }

    public void setRiskAssessmentLevel(Short riskAssessmentLevel) {
        this.riskAssessmentLevel = riskAssessmentLevel;
    }



    public Date getUserLoginTime() {
        return userLoginTime;
    }

    public void setUserLoginTime(Date userLoginTime) {
        this.userLoginTime = userLoginTime;
    }

    public String getUserLoginChannelName() {
        return userLoginChannelName;
    }

    public void setUserLoginChannelName(String userLoginChannelName) {
        this.userLoginChannelName = userLoginChannelName;
    }

    public String getUserLoginVersionName() {
        return userLoginVersionName;
    }

    public void setUserLoginVersionName(String userLoginVersionName) {
        this.userLoginVersionName = userLoginVersionName;
    }

    public String getUserLoginDeviceCode() {
        return userLoginDeviceCode;
    }

    public void setUserLoginDeviceCode(String userLoginDeviceCode) {
        this.userLoginDeviceCode = userLoginDeviceCode;
    }

    public String getUserOginDeviceType() {
        return userOginDeviceType;
    }

    public void setUserOginDeviceType(String userOginDeviceType) {
        this.userOginDeviceType = userOginDeviceType;
    }

    public String getUserLoginDeviceName() {
        return userLoginDeviceName;
    }

    public void setUserLoginDeviceName(String userLoginDeviceName) {
        this.userLoginDeviceName = userLoginDeviceName;
    }

    public Short getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Short deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public Date getRegisterTime() {
        return registerTime;
    }

    public void setRegisterTime(Date registerTime) {
        this.registerTime = registerTime;
    }

    public String getRegisterChannelCode() {
        return registerChannelCode;
    }

    public void setRegisterChannelCode(String registerChannelCode) {
        this.registerChannelCode = registerChannelCode;
    }

    public String getRegisterChannelName() {
        return registerChannelName;
    }

    public void setRegisterChannelName(String registerChannelName) {
        this.registerChannelName = registerChannelName;
    }

    public String getRegisterVersionCode() {
        return registerVersionCode;
    }

    public void setRegisterVersionCode(String registerVersionCode) {
        this.registerVersionCode = registerVersionCode;
    }

    public String getRegisterVersionName() {
        return registerVersionName;
    }

    public void setRegisterVersionName(String registerVersionName) {
        this.registerVersionName = registerVersionName;
    }

    public String getRegisterDeviceId() {
        return registerDeviceId;
    }

    public void setRegisterDeviceId(String registerDeviceId) {
        this.registerDeviceId = registerDeviceId;
    }

    public String getRegisterDeviceType() {
        return registerDeviceType;
    }

    public void setRegisterDeviceType(String registerDeviceType) {
        this.registerDeviceType = registerDeviceType;
    }

    public String getRegisterDeviceName() {
        return registerDeviceName;
    }

    public void setRegisterDeviceName(String registerDeviceName) {
        this.registerDeviceName = registerDeviceName;
    }

    public String getRegisterDeviceOs() {
        return registerDeviceOs;
    }

    public void setRegisterDeviceOs(String registerDeviceOs) {
        this.registerDeviceOs = registerDeviceOs;
    }

    public String getRegisterDeviceIp() {
        return registerDeviceIp;
    }

    public void setRegisterDeviceIp(String registerDeviceIp) {
        this.registerDeviceIp = registerDeviceIp;
    }

    public String getLoginChannelCode() {
        return loginChannelCode;
    }

    public void setLoginChannelCode(String loginChannelCode) {
        this.loginChannelCode = loginChannelCode;
    }

    public String getLoginVersionCode() {
        return loginVersionCode;
    }

    public void setLoginVersionCode(String loginVersionCode) {
        this.loginVersionCode = loginVersionCode;
    }

    public String getLoginDeviceOs() {
        return loginDeviceOs;
    }

    public void setLoginDeviceOs(String loginDeviceOs) {
        this.loginDeviceOs = loginDeviceOs;
    }

    public String getLoginDeviceIp() {
        return loginDeviceIp;
    }

    public void setLoginDeviceIp(String loginDeviceIp) {
        this.loginDeviceIp = loginDeviceIp;
    }
}