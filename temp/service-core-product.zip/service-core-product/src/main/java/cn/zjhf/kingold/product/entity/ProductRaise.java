package cn.zjhf.kingold.product.entity;

import org.springframework.data.annotation.Id;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author lutiehua
 * @date 2018/3/6
 */
public class ProductRaise {
    /**
     * 自增主键
     */
    @Id
    private Long productRaiseId;

    /**
     * 产品UUID
     */
    private String productUuid;

    /**
     * 用户UUID
     */
    private String userUuid;

    /**
     * 订单号
     */
    private String orderBillCode;

    /**
     * 订单金额
     */
    private BigDecimal orderAmount;

    public BigDecimal getMaxInvestAmount() {
        return maxInvestAmount;
    }

    public void setMaxInvestAmount(BigDecimal maxInvestAmount) {
        this.maxInvestAmount = maxInvestAmount;
    }

    /**
     * 最大投资金额
     */
    private BigDecimal maxInvestAmount;

    private Integer deleteFlag;

    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    public String getUpdateUuid() {
        return updateUuid;
    }

    public void setUpdateUuid(String updateUuid) {
        this.updateUuid = updateUuid;
    }

    /**
     * 更新标识
     */
    private String updateUuid;

    /**
     * 获取自增主键
     *
     * @return product_raise_id - 自增主键
     */
    public Long getProductRaiseId() {
        return productRaiseId;
    }

    /**
     * 设置自增主键
     *
     * @param productRaiseId 自增主键
     */
    public void setProductRaiseId(Long productRaiseId) {
        this.productRaiseId = productRaiseId;
    }

    /**
     * 获取产品UUID
     *
     * @return product_uuid - 产品UUID
     */
    public String getProductUuid() {
        return productUuid;
    }

    /**
     * 设置产品UUID
     *
     * @param productUuid 产品UUID
     */
    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    /**
     * 获取用户UUID
     *
     * @return user_uuid - 用户UUID
     */
    public String getUserUuid() {
        return userUuid;
    }

    /**
     * 设置用户UUID
     *
     * @param userUuid 用户UUID
     */
    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    /**
     * 获取订单号
     *
     * @return order_bill_code - 订单号
     */
    public String getOrderBillCode() {
        return orderBillCode;
    }

    /**
     * 设置订单号
     *
     * @param orderBillCode 订单号
     */
    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    /**
     * 获取订单金额
     *
     * @return order_amount - 订单金额
     */
    public BigDecimal getOrderAmount() {
        return orderAmount;
    }

    /**
     * 设置订单金额
     *
     * @param orderAmount 订单金额
     */
    public void setOrderAmount(BigDecimal orderAmount) {
        this.orderAmount = orderAmount;
    }

    /**
     * @return delete_flag
     */
    public Integer getDeleteFlag() {
        return deleteFlag;
    }

    /**
     * @param deleteFlag
     */
    public void setDeleteFlag(Integer deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    /**
     * @return create_time
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * @param createTime
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 获取更新时间
     *
     * @return update_time - 更新时间
     */
    public Date getUpdateTime() {
        return updateTime;
    }

    /**
     * 设置更新时间
     *
     * @param updateTime 更新时间
     */
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}