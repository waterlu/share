package cn.zjhf.kingold.product.persistence.mq.consumer;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.product.dto.ProductRemainDTO;
import cn.zjhf.kingold.product.exception.NoProductException;
import cn.zjhf.kingold.product.persistence.mq.message.OrderCancelMessage;
import cn.zjhf.kingold.product.service.IProductService;
import cn.zjhf.kingold.product.util.MapParamUtils;
import cn.zjhf.kingold.rocketmq.annotation.RocketMQConsumer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQConsumer;
import com.google.common.base.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Map;

/**
 * 订单取消消息消费者
 *
 * @author lutiehua
 * @date 2017/12/14.
 */
@RocketMQConsumer(topic = "order", tag = "cancel")
public class OrderCancelConsumer extends AbstractMQConsumer<OrderCancelMessage> {

    private final Logger logger = LoggerFactory.getLogger(OrderCancelConsumer.class);

    @Autowired
    private IProductService productService;

    @Override
    public ResponseResult process(OrderCancelMessage orderCancelMessage) throws BusinessException {
        logger.info("收到订单取消消息={}", orderCancelMessage);

        Map product = productService.getFixedIncome(orderCancelMessage.getProductUuid());
        if (null == product) {
            logger.error("没有查询到产品");
            throw new NoProductException();
        }

        String productUuid = MapParamUtils.getStringInMap(product, "productUuid");
        if (Strings.isNullOrEmpty(productUuid)) {
            logger.error("没有查询到产品");
            throw new NoProductException();
        }

        ProductRemainDTO productRemain = new ProductRemainDTO();
        productRemain.setProductUuid(orderCancelMessage.getProductUuid());
        productRemain.setUserUuid(orderCancelMessage.getUserUuid());
        productRemain.setOrderBillCode(orderCancelMessage.getOrderBillCode());
        productRemain.setAmount(orderCancelMessage.getOrderAmount());
        productService.restoreRemain(productRemain);

        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseCode.OK);
        responseResult.setMsg(ResponseCode.OK_TEXT);
        return responseResult;
    }
}
