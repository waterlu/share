package cn.zjhf.kingold.product.exception;

import cn.zjhf.kingold.common.exception.BusinessException;

/**
 * @author lutiehua
 * @date  2017/12/14
 */
public class ProductSellOutException extends BusinessException {

    public ProductSellOutException() {
        super(12002 , "产品已售罄");
    }
}
