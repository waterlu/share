package cn.zjhf.kingold.product.exception;

import cn.zjhf.kingold.common.exception.BusinessException;

/**
 * @author lutiehua
 * @date 2018/3/13
 */
public class NoProductException extends BusinessException {

    public NoProductException() {
        super(6030, "产品不存在");
    }
}
