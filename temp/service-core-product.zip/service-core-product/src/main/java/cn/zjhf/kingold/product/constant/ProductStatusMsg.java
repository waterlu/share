package cn.zjhf.kingold.product.constant;

/**
 * Created by Xiaody on 17/4/15.
 */
public class ProductStatusMsg {

    public static final int REQUEST_PARAM_ERROR_CODE = -1;
    public static final String REQUEST_PARAM_ERROR = "入参参数错误";

    public static final int PRODUCT_TYPR_WRONG_CODE = 5001;
    public static final String PRODUCT_TYPE_WRONG_MSG = "没有产品类型或者产品类型不符";

    public static final int NO_RECOMMEND_PRODUCT_CODE = 5002;
    public static final String NO_RECOMMEND_PRODUCT_MSG = "没有推荐的产品";

    public static final int PRODUCT_CHANGE_TYPE_WRONG_CODE = 5003;
    public static final String PRODUCT_CHANGE_TYPE_WRONG_MSG = "没有产品操作类型或者产品操作类型不符";

    public static final int CUSTOMER_IN_PROTECTION_CODE = 5004;
    public static final String CUSTOMER_IN_PROTECTION_MSG = "客户目前处于保护期内，不能重复预约，如有问题请联系客服";

    public static final int UNFINISHED_ORDER_CODE = 5005;
    public static final String UNFINISHED_ORDER_MSG = "此客户有未完成订单，不能重复预约，如有问题请联系客服";

    public static final int NO_TOPIC_CODE = 6801;
    public static final String NO_TOPIC_MSG = "没有获取到主题";


    public static final int REPORT_UNDEFINED_ERR = 8301;
    public static final String REPORT_UNDEFINED_ERR_MSG = "该报表未定义";

    public static final int REPORT_PARAM_ERR = 8302;
    public static final String REPORT_PARAM_ERR_MSG = "该报表输入参数与所要求不一致";

    public static final int ERROR_PARAMETER = -1;
    public static final String ERROR_PARAMETER_TEXT = "参数错误";
}
