package cn.zjhf.kingold.product.exception;

import cn.zjhf.kingold.common.exception.BusinessException;

/**
 * @author lutiehua
 * @date 2017/12/19
 */
public class ProductUpdateRemainException extends BusinessException {

    public ProductUpdateRemainException() {
        super(6215 , "扣减产品募集金额失败");
    }
}
