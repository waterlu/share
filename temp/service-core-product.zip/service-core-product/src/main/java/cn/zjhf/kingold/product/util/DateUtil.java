package cn.zjhf.kingold.product.util;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * Created by Xiaody on 17/5/15.
 */
public class DateUtil {

    private static final Logger logger = LoggerFactory.getLogger(DateUtil.class);

    public static String CURRENTTIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
    /**
     * 计算两个日期之间相差的天数
     *
     * @param d1 较小的时间
     * @param d2  较大的时间
     * @return 相差天数
     * @throws ParseException
     */
    public static int daysBetween(Date d1, Date d2) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        d1 = sdf.parse(sdf.format(d1));
        d2 = sdf.parse(sdf.format(d2));
        Calendar cal = Calendar.getInstance();
        cal.setTime(d1);
        long time1 = cal.getTimeInMillis();
        cal.setTime(d2);
        long time2 = cal.getTimeInMillis();
        long between_days = (time2 - time1) / (1000 * 3600 * 24);
        return Integer.parseInt(String.valueOf(between_days));
    }

    public static void main(String[] args) throws Exception {
        Date d1 = new Date();
        System.out.println(d1);
        Date d2 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").parse("2017-05-12 17:00:00");
        System.out.println(d2);
        System.out.println(daysBetween(d2,d1));
    }

    public static String formateDate(Date date) {
        DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(date);
    }

    public static String formateDate(Date date,String dateType) {
        DateFormat sdf = new SimpleDateFormat(dateType);
        return sdf.format(date);
    }

    public static Date strToDate(String str, String pattern) {
        if (StringUtils.isEmpty(str)) {
            return null;
        }

        DateFormat format = new SimpleDateFormat(pattern);
        Date date = null;
        try {
            // Fri Feb 24 00:00:00 CST 2012
            date = format.parse(str);
        } catch (ParseException e) {
            logger.error("日期格式转换错误", e);
        }

        return date;
    }

    /**
     * 将date向前增加 count 天
     *
     * @param date
     * @param count //把日期往后增加一天.整数往后推,负数往前移动
     * @return
     */
    public static Date addDay(Date date, int count) {
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(date);
        calendar.add(calendar.DATE, count);//把日期往后增加一天.整数往后推,负数往前移动
        return calendar.getTime();   //这个时间就是日期往后推一天的结果
    }
}
