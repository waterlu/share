package cn.zjhf.kingold.product.util;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.product.constant.ProductStatusMsg;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by zhangyijie on 2017/5/16.
 */
public class DataUtils {
    private static final Logger logger = LoggerFactory.getLogger(DataUtils.class);

    public static final String LINEBREAK = "\r\n";
    public static final String SPLITSTR = "\\$\\$";

    public static boolean isNotEmpty(String value) {
        if(value != null) {
            if(value.trim().length() > 0) {
                return true;
            }
        }

        return false;
    }

    public static List<String> split(String value) {
        if(isEmpty(value)) {
            return new ArrayList<String>();
        }

        String[] items = value.trim().split(SPLITSTR);
        return java.util.Arrays.asList(items);
    }

    public static List<String> split(String value, String regex) {
        String[] items = value.split(regex);
        List<String> ret = new ArrayList<String>();
        for(String item : items) {
            ret.add(item);
        }

        return ret;
    }

    public static boolean isContain(int value, int... optValues) {
        if(optValues != null) {
            for (int optValue : optValues) {
                if (value == optValue) {
                    return true;
                }
            }
        }

        return false;
    }

    public static boolean isContain(String value, String... optValues) {
        if(optValues != null) {
            for (String optValue : optValues) {
                if (value.equals(optValue)) {
                    return true;
                }
            }
        }

        return false;
    }

    public static boolean isEmpty(String value) {
        return !isNotEmpty(value);
    }

    public static <T> String listToStr(List<T> items) {
        StringBuilder str = new StringBuilder("");
        if (items == null)
            return str.toString();

        int len = items.size();
        if(len == 0) {
            logger.debug("空列表");
        }

        for (int i = 0; i < len; i++) {
            if (null != items.get(i)) {
                str.append(items.get(i).toString());

                if (i != (len - 1)) {
                    str.append(", ");
                }
            }else {
                logger.debug("null");
            }
        }

        return str.toString();
    }

    public static String toString(List<List<String>> value) {
        StringBuilder sb = new StringBuilder("\r\n");

        for(List<String> items : value) {
            for(String item : items) {
                if(DataUtils.isEmpty(item)) {
                    item = "null";
                }

                sb.append(item).append("\t");
            }

            sb.append("\r\n");
        }

        return sb.toString();
    }

    //double的输出不要输出成科学计数法
    public static String toString(double value) {
        if (Double.isNaN(value))
            return "0";

        return AmountUtils.toString(value);
    }

    //Date不要输出成恶心的格式
    public static String toString(Date value) {
        if (null == value)
            return "1900-01-01 00:00:00";

        SimpleDateFormat sdf = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss" );
        return sdf.format(value);
    }

    //BigDecimal的输出不要输出成科学计数法
    public static String toString(BigDecimal value) {
        if (null == value)
            return "0";

        return AmountUtils.toString(value);
    }

    public static String toString(Object obj) {
        if(obj instanceof Double) {
            return toString((double)obj);
        }else if(obj instanceof BigDecimal) {
            return toString((BigDecimal)obj);
        }else if(obj instanceof Date) {
            return toString((Date)obj);
        }else if(obj instanceof Map) {
            return toString((Map)obj);
        }else if(obj instanceof List) {
            return listToStr((List)obj);
        }

        return (obj != null) ? obj.toString() : "null";
    }

    public static String toString(Map map) {
        final String interStr = ", ";
        StringBuilder sb = new StringBuilder();

        List<Object> keys = new ArrayList<Object>(map.keySet());
        int count = keys.size();
        for(int i = 0; i < count; i++) {
            Object key = keys.get(i);
            sb.append(DataUtils.toString(key) + ":[" + DataUtils.toString(map.get(key)) + "]");

            if(i != (count-1)) {
                sb.append(interStr);
            }
        }

        return sb.toString();
    }

    public static String toLog(String name, Object velue) {
        return (new StringBuilder(toString(name)).append(":").append(toString(velue))).append(" ").toString();
    }

    public static String toString(Object obj1, Object obj2) {
        return (new StringBuilder(toString(obj1)).append(", ").append(toString(obj2))).toString();
    }

    public static void checkParam(String... params) throws BusinessException {
        if(params != null) {
            for (String param : params) {
                if ( isEmpty(param)) {
                    throw new BusinessException(ProductStatusMsg.ERROR_PARAMETER, ProductStatusMsg.ERROR_PARAMETER_TEXT, false);
                }
            }
        }else {
            throw new BusinessException(ProductStatusMsg.ERROR_PARAMETER, ProductStatusMsg.ERROR_PARAMETER_TEXT, false);
        }
    }
}
