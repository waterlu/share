package cn.zjhf.kingold.product.entity;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author liuyao
 * @date 2018/3/2
 */
public class ProductSortModel implements Comparable<ProductSortModel> {
    /**
     * UUID主键
     */
    private String productUuid;

    /**
     * 产品状态（1募集中；2已售罄；3已成立；4已到期；5已兑付）
     */
    private Integer productStatus;

    /**
     * 产品显示顺序
     */
    private Integer productShowOrder;

    /**
     * 产品期限
     */
    private Integer productPeriod;

    /**
     * 产品期限类型： Y(year,年)； M(month,月)； W(week,周)； D(day,自然日)
     */
    private String productPeriodType;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 运营标示
     */
    private Integer vipFlag;

    /**
     * 产品运营标签
     */
    private String productLabel;

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public Integer getProductStatus() {
        return productStatus;
    }

    public void setProductStatus(Integer productStatus) {
        this.productStatus = productStatus;
    }

    public Integer getProductShowOrder() {
        return productShowOrder;
    }

    public void setProductShowOrder(Integer productShowOrder) {
        this.productShowOrder = productShowOrder;
    }

    public Integer getProductPeriod() {
        return productPeriod;
    }

    public void setProductPeriod(Integer productPeriod) {
        this.productPeriod = productPeriod;
    }

    public String getProductPeriodType() {
        return productPeriodType;
    }

    public void setProductPeriodType(String productPeriodType) {
        this.productPeriodType = productPeriodType;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getVipFlag() {
        return vipFlag;
    }

    public void setVipFlag(Integer vipFlag) {
        this.vipFlag = vipFlag;
    }

    public String getProductLabel() {
        return productLabel;
    }

    public void setProductLabel(String productLabel) {
        this.productLabel = productLabel;
    }

    /**
     * 规则：
     * 仅展示预热中和募集中状态的产品。
     * 先按照产品类型进行排序，新手标＞达人专享产品＞其他产品
     * 在产品类型内，再按照置顶排序，如果没有置顶按照产品期限由小到大排序，再按照募集中＞预热中排序
     */
    @Override
    public int compareTo(ProductSortModel o) {
        //权重第一：运营标示排序【新手标】>【达人专享】>【其他产品】
        int thisObjectFlag = this.productLabel != null && this.productLabel.contains("1") ? 1 : 0;
        int oFlag = o.productLabel != null && o.productLabel.contains("1") ? 1 : 0;
        if (thisObjectFlag - oFlag != 0) {
            return oFlag - thisObjectFlag;
        }
        if (this.getVipFlag() - o.getVipFlag() != 0) {
            return o.getVipFlag() - this.getVipFlag();
        }

        //权重二：置顶顺序
        if (this.getProductShowOrder() - o.getProductShowOrder() != 0) {
            return o.getProductShowOrder() - this.getProductShowOrder();
        }

        //权重三：期限大小
        if (this.getProductPeriod() * dateCalculate.get(this.getProductPeriodType().toLowerCase()) -
                o.getProductPeriod() * dateCalculate.get(o.getProductPeriodType().toLowerCase()) != 0) {
            return this.getProductPeriod() * dateCalculate.get(this.getProductPeriodType().toLowerCase()) -
                    o.getProductPeriod() * dateCalculate.get(o.getProductPeriodType().toLowerCase());
        }

        //权重四：产品状态
        if (this.getProductStatus() - o.getProductStatus() != 0) {
            return  o.getProductStatus() - this.getProductStatus();
        }

        return this.getCreateTime().compareTo(o.getCreateTime());

    }

    private static Map<String, Integer> dateCalculate = new HashMap<String, Integer>() {{
        put("y", 365);
        put("m", 30);
        put("w", 7);
        put("d", 1);
    }};

}