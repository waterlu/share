package cn.zjhf.kingold.product.constant;

/**
 * Created by lutiehua on 2017/6/1.
 */
public interface Topic {
    /**
     * 预约单主题
     */
    String RESERVATION = "reservation";
}