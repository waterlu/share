package cn.zjhf.kingold.product.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author 
 */
public class ProductFixedIncome implements Serializable {
    /**
     * 自增主键
     */
    private Long fixedIncomeID;

    /**
     * 产品UUID
     */
    private String productUuid;

    /**
     * 投资人条件
     */
    private String investorQualification;

    /**
     * 销售对象用户类型（默认不限制）
     */
    private Byte saleUserType;

    /**
     * 是否可转债权
     */
    private Byte isTransferFlag;

    /**
     * 产品募集账户类型
     */
    private Byte payeeAccountType;

    /**
     * 产品募集账户UUID
     */
    private String payeeAccountUuid;

    /**
     * 收益计算基数
     */
    private Short rateFormulaParam;

    /**
     * 产品预计年化收益率
     */
    private BigDecimal annualInterestRate;

    /**
     * 产品预计年化收益率（配合加息只用于显示）
     */
    private BigDecimal annualInterestShow;

    /**
     * 产品加息利率
     */
    private BigDecimal increaseInterestRate;

    /**
     * 产品起投金额
     */
    private BigDecimal productMinInvestment;

    /**
     * 产品追投递增金额
     */
    private BigDecimal investmentInterval;

    /**
     * 产品最大投资金额
     */
    private BigDecimal productMaxInvestment;


    /**
     * 产品发布日, 格式为 YYYY-MM-DD
     */
    private Date productPublishDate;

    /**
     * 产品起息日/成立日, 格式为 YYYY-MM-DD
     */
    private Date productInterestDate;

    /**
     * 产品到期日, 格式为 YYYY-MM-DD
     */
    private Date productExpiringDate;

    /**
     * 预期收款日, 格式为 YYYY-MM-DD
     */
    private Date productPaymentDate;

    /**
     * 募集起始日, 格式为 YYYY-MM-DD
     */
    private Date raiseStartDate;

    /**
     * 募集截止日, 格式为 YYYY-MM-DD
     */
    private Date raiseEndDate;

    /**
     * 实际收款日, 格式为 YYYY-MM-DD
     */
    private Date paymentDate;

    /**
     * 实际还款日, 格式为 YYYY-MM-DD
     */
    private Date repaymentDate;

    /**
     * 产品付息方式：11一次还本息12等额本息13等额本金14预付利息
     */
    private String productInterestType;

    /**
     * 项目概况
     */
    private String productIntroduction;

    /**
     * 产品详情(资金投向/还款来源/风险保障/风险提示)
     */
    private String productInformation;

    /**
     * 平台服务费
     */
    private BigDecimal platformCommission;

    /**
     * 交易所管理费
     */
    private BigDecimal managementFee;

    /**
     * 项目编号
     */
    private String productProjectCode;

    /**
     * 产品运营标签
     */
    private String productLabel;


    private Byte deleteFlag;

    private Date createTime;

    private Date updateTime;

    /**
     * 产品成立日
     */
    private Date productEstablishmentDate;

    private static final long serialVersionUID = 1L;

    public Long getFixedIncomeID() {
        return fixedIncomeID;
    }

    public void setFixedIncomeID(Long fixedIncomeID) {
        this.fixedIncomeID = fixedIncomeID;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getInvestorQualification() {
        return investorQualification;
    }

    public void setInvestorQualification(String investorQualification) {
        this.investorQualification = investorQualification;
    }

    public Byte getSaleUserType() {
        return saleUserType;
    }

    public void setSaleUserType(Byte saleUserType) {
        this.saleUserType = saleUserType;
    }

    public Byte getIsTransferFlag() {
        return isTransferFlag;
    }

    public void setIsTransferFlag(Byte isTransferFlag) {
        this.isTransferFlag = isTransferFlag;
    }

    public Byte getPayeeAccountType() {
        return payeeAccountType;
    }

    public void setPayeeAccountType(Byte payeeAccountType) {
        this.payeeAccountType = payeeAccountType;
    }

    public String getPayeeAccountUuid() {
        return payeeAccountUuid;
    }

    public void setPayeeAccountUuid(String payeeAccountUuid) {
        this.payeeAccountUuid = payeeAccountUuid;
    }

    public Short getRateFormulaParam() {
        return rateFormulaParam;
    }

    public void setRateFormulaParam(Short rateFormulaParam) {
        this.rateFormulaParam = rateFormulaParam;
    }

    public BigDecimal getAnnualInterestRate() {
        return annualInterestRate;
    }

    public void setAnnualInterestRate(BigDecimal annualInterestRate) {
        this.annualInterestRate = annualInterestRate;
    }

    public BigDecimal getAnnualInterestShow() {
        return annualInterestShow;
    }

    public void setAnnualInterestShow(BigDecimal annualInterestShow) {
        this.annualInterestShow = annualInterestShow;
    }

    public BigDecimal getIncreaseInterestRate() {
        return increaseInterestRate;
    }

    public void setIncreaseInterestRate(BigDecimal increaseInterestRate) {
        this.increaseInterestRate = increaseInterestRate;
    }

    public BigDecimal getProductMinInvestment() {
        return productMinInvestment;
    }

    public void setProductMinInvestment(BigDecimal productMinInvestment) {
        this.productMinInvestment = productMinInvestment;
    }

    public BigDecimal getInvestmentInterval() {
        return investmentInterval;
    }

    public void setInvestmentInterval(BigDecimal investmentInterval) {
        this.investmentInterval = investmentInterval;
    }

    public BigDecimal getProductMaxInvestment() {
        return productMaxInvestment;
    }

    public void setProductMaxInvestment(BigDecimal productMaxInvestment) {
        this.productMaxInvestment = productMaxInvestment;
    }

    public Date getProductPublishDate() {
        return productPublishDate;
    }

    public void setProductPublishDate(Date productPublishDate) {
        this.productPublishDate = productPublishDate;
    }

    public Date getProductInterestDate() {
        return productInterestDate;
    }

    public void setProductInterestDate(Date productInterestDate) {
        this.productInterestDate = productInterestDate;
    }

    public Date getProductExpiringDate() {
        return productExpiringDate;
    }

    public void setProductExpiringDate(Date productExpiringDate) {
        this.productExpiringDate = productExpiringDate;
    }

    public Date getProductPaymentDate() {
        return productPaymentDate;
    }

    public void setProductPaymentDate(Date productPaymentDate) {
        this.productPaymentDate = productPaymentDate;
    }

    public Date getRaiseStartDate() {
        return raiseStartDate;
    }

    public void setRaiseStartDate(Date raiseStartDate) {
        this.raiseStartDate = raiseStartDate;
    }

    public Date getRaiseEndDate() {
        return raiseEndDate;
    }

    public void setRaiseEndDate(Date raiseEndDate) {
        this.raiseEndDate = raiseEndDate;
    }

    public Date getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(Date paymentDate) {
        this.paymentDate = paymentDate;
    }

    public Date getRepaymentDate() {
        return repaymentDate;
    }

    public void setRepaymentDate(Date repaymentDate) {
        this.repaymentDate = repaymentDate;
    }

    public String getProductInterestType() {
        return productInterestType;
    }

    public void setProductInterestType(String productInterestType) {
        this.productInterestType = productInterestType;
    }

    public String getProductIntroduction() {
        return productIntroduction;
    }

    public void setProductIntroduction(String productIntroduction) {
        this.productIntroduction = productIntroduction;
    }

    public String getProductInformation() {
        return productInformation;
    }

    public void setProductInformation(String productInformation) {
        this.productInformation = productInformation;
    }

    public BigDecimal getPlatformCommission() {
        return platformCommission;
    }

    public void setPlatformCommission(BigDecimal platformCommission) {
        this.platformCommission = platformCommission;
    }

    public BigDecimal getManagementFee() {
        return managementFee;
    }

    public void setManagementFee(BigDecimal managementFee) {
        this.managementFee = managementFee;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getProductProjectCode() {
        return productProjectCode;
    }

    public String getProductLabel() {
        return productLabel;
    }

    public void setProductLabel(String productLabel) {
        this.productLabel = productLabel;
    }

    public void setProductProjectCode(String productProjectCode) {
        this.productProjectCode = productProjectCode;

    }

    public Date getProductEstablishmentDate() {
        return productEstablishmentDate;
    }

    public void setProductEstablishmentDate(Date productEstablishmentDate) {
        this.productEstablishmentDate = productEstablishmentDate;
    }
}