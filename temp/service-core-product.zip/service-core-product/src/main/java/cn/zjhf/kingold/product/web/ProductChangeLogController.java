package cn.zjhf.kingold.product.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.common.utils.MapRemoveNullUtil;
import cn.zjhf.kingold.product.service.IProductChangeLogService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * Created by Xiaody on 17/4/20.
 */
@RestController
@RequestMapping("/productChangeLog")
public class ProductChangeLogController {
    private static Logger LOGGER = LoggerFactory.getLogger(ProductChangeLogController.class);

    @Autowired
    private IProductChangeLogService productChangeLogService;

    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public ResponseResult getList(@RequestParam Map params) throws BusinessException {
        MapRemoveNullUtil.removeNullEntry(params);
        List<Map> list = productChangeLogService.getList(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", list);
    }

    @RequestMapping(value = "/count", method = RequestMethod.GET)
    public ResponseResult count(@RequestParam Map params) throws BusinessException {
        MapRemoveNullUtil.removeNullEntry(params);
        Integer count = productChangeLogService.getCount(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", count);
    }
}
