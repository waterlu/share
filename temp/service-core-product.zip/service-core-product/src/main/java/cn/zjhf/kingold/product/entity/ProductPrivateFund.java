package cn.zjhf.kingold.product.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author 
 */
public class ProductPrivateFund implements Serializable {
    /**
     * 自增主键
     */
    private Long privateFundID;

    /**
     * 产品UUID
     */
    private String productUuid;

    /**
     * 产品管理人
     */
    private String productManager;

    /**
     * 产品管理类型
     */
    private String productManageType;

    /**
     * 产品结构类型
     */
    private String productStructureType;

    /**
     * 产品存续期限
     */
    private String productDuration;

    /**
     * 产品起投金额
     */
    private BigDecimal productMinInvestment;

    /**
     * 产品托管人
     */
    private String productCustodian;

    /**
     * 募集对象
     */
    private String productCustomer;

    /**
     * 产品付息方式（1一次性；2按月；3按季度；4按半年 5按年）
     */
    private Byte productInterestType;

    /**
     * 业绩比较基准（JSON）
     */
    private String productBenchmark;

    /**
     * 申购费
     */
    private BigDecimal productApplyFee;

    /**
     * 认购费
     */
    private BigDecimal productPurchaseFee;

    /**
     * 管理费
     */
    private BigDecimal productManagerFee;

    /**
     * 托管费
     */
    private BigDecimal productCustodianFee;

    /**
     * 外包服务费
     */
    private BigDecimal productServiceFee;

    /**
     * 封闭期
     */
    private String productCloseDate;

    /**
     * 开放日
     */
    private String productOpenDate;

    /**
     * 募集账户-账户名称
     */
    private String bankAccountName;

    /**
     * 募集账户-募集账号
     */
    private String bankAccountNo;

    /**
     * 募集账户-开户银行
     */
    private String bankBrachName;

    /**
     * 募集账户-大额行号
     */
    private String bankLargeNo;

    /**
     * 产品投资范围
     */
    private String productInvestField;

    /**
     * 产品风控措施
     */
    private String productRiskTreatment;

    /**
     * 产品介绍(产品亮点)
     */
    private String productInformation;

    /**
     * 超额业绩报酬
     */
    private String extraPerformanceRemuneration;

    /**
     * 托管账户-账户名称
     */
    private String custodianAccountName;

    /**
     * 托管账户-托管账号
     */
    private String custodianAccountNo;

    /**
     * 托管账户-开户银行
     */
    private String custodianBrachName;

    /**
     * 托管账户-大额行号
     */
    private String custodianLargeNo;

    /**
     * 退出方式
     */
    private String exitMode;

    private Byte deleteFlag;

    private Date createTime;

    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public Long getPrivateFundID() {
        return privateFundID;
    }

    public void setPrivateFundID(Long privateFundID) {
        this.privateFundID = privateFundID;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductManager() {
        return productManager;
    }

    public void setProductManager(String productManager) {
        this.productManager = productManager;
    }

    public String getProductManageType() {
        return productManageType;
    }

    public void setProductManageType(String productManageType) {
        this.productManageType = productManageType;
    }

    public String getProductStructureType() {
        return productStructureType;
    }

    public void setProductStructureType(String productStructureType) {
        this.productStructureType = productStructureType;
    }

    public String getProductDuration() {
        return productDuration;
    }

    public void setProductDuration(String productDuration) {
        this.productDuration = productDuration;
    }

    public BigDecimal getProductMinInvestment() {
        return productMinInvestment;
    }

    public void setProductMinInvestment(BigDecimal productMinInvestment) {
        this.productMinInvestment = productMinInvestment;
    }

    public String getProductCustodian() {
        return productCustodian;
    }

    public void setProductCustodian(String productCustodian) {
        this.productCustodian = productCustodian;
    }

    public String getProductCustomer() {
        return productCustomer;
    }

    public void setProductCustomer(String productCustomer) {
        this.productCustomer = productCustomer;
    }

    public Byte getProductInterestType() {
        return productInterestType;
    }

    public void setProductInterestType(Byte productInterestType) {
        this.productInterestType = productInterestType;
    }

    public String getProductBenchmark() {
        return productBenchmark;
    }

    public void setProductBenchmark(String productBenchmark) {
        this.productBenchmark = productBenchmark;
    }

    public BigDecimal getProductPurchaseFee() {
        return productPurchaseFee;
    }

    public void setProductPurchaseFee(BigDecimal productPurchaseFee) {
        this.productPurchaseFee = productPurchaseFee;
    }

    public BigDecimal getProductManagerFee() {
        return productManagerFee;
    }

    public void setProductManagerFee(BigDecimal productManagerFee) {
        this.productManagerFee = productManagerFee;
    }

    public BigDecimal getProductCustodianFee() {
        return productCustodianFee;
    }

    public void setProductCustodianFee(BigDecimal productCustodianFee) {
        this.productCustodianFee = productCustodianFee;
    }

    public BigDecimal getProductServiceFee() {
        return productServiceFee;
    }

    public void setProductServiceFee(BigDecimal productServiceFee) {
        this.productServiceFee = productServiceFee;
    }

    public String getProductCloseDate() {
        return productCloseDate;
    }

    public void setProductCloseDate(String productCloseDate) {
        this.productCloseDate = productCloseDate;
    }

    public String getProductOpenDate() {
        return productOpenDate;
    }

    public void setProductOpenDate(String productOpenDate) {
        this.productOpenDate = productOpenDate;
    }

    public String getBankAccountName() {
        return bankAccountName;
    }

    public void setBankAccountName(String bankAccountName) {
        this.bankAccountName = bankAccountName;
    }

    public String getBankAccountNo() {
        return bankAccountNo;
    }

    public void setBankAccountNo(String bankAccountNo) {
        this.bankAccountNo = bankAccountNo;
    }

    public String getBankBrachName() {
        return bankBrachName;
    }

    public void setBankBrachName(String bankBrachName) {
        this.bankBrachName = bankBrachName;
    }

    public String getBankLargeNo() {
        return bankLargeNo;
    }

    public void setBankLargeNo(String bankLargeNo) {
        this.bankLargeNo = bankLargeNo;
    }

    public String getProductInvestField() {
        return productInvestField;
    }

    public void setProductInvestField(String productInvestField) {
        this.productInvestField = productInvestField;
    }

    public String getProductRiskTreatment() {
        return productRiskTreatment;
    }

    public void setProductRiskTreatment(String productRiskTreatment) {
        this.productRiskTreatment = productRiskTreatment;
    }

    public String getProductInformation() {
        return productInformation;
    }

    public void setProductInformation(String productInformation) {
        this.productInformation = productInformation;
    }

    public String getExtraPerformanceRemuneration() {
        return extraPerformanceRemuneration;
    }

    public void setExtraPerformanceRemuneration(String extraPerformanceRemuneration) {
        this.extraPerformanceRemuneration = extraPerformanceRemuneration;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public BigDecimal getProductApplyFee() {
        return productApplyFee;
    }

    public void setProductApplyFee(BigDecimal productApplyFee) {
        this.productApplyFee = productApplyFee;
    }

    public String getCustodianAccountName() {
        return custodianAccountName;
    }

    public void setCustodianAccountName(String custodianAccountName) {
        this.custodianAccountName = custodianAccountName;
    }

    public String getCustodianAccountNo() {
        return custodianAccountNo;
    }

    public void setCustodianAccountNo(String custodianAccountNo) {
        this.custodianAccountNo = custodianAccountNo;
    }

    public String getCustodianBrachName() {
        return custodianBrachName;
    }

    public void setCustodianBrachName(String custodianBrachName) {
        this.custodianBrachName = custodianBrachName;
    }

    public String getCustodianLargeNo() {
        return custodianLargeNo;
    }

    public void setCustodianLargeNo(String custodianLargeNo) {
        this.custodianLargeNo = custodianLargeNo;
    }

    public String getExitMode() {
        return exitMode;
    }

    public void setExitMode(String exitMode) {
        this.exitMode = exitMode;
    }
}