package cn.zjhf.kingold.product.persistence.dao;

import cn.zjhf.kingold.product.entity.ProductProgress;
import cn.zjhf.kingold.product.entity.ProductRaiseDO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.Map;

/**
 *
 * @author lutiehua
 * @date 2018/3/6
 *
 */
@Repository
@Mapper
public interface ProductProgressMapper {
    Integer insert(Map map);

    void update(Map map);

    void updateAccumulation(@Param("productUuid") String productUuid, @Param("amount") Double amount);

    /**
     * 增加产品募集金额
     *
     * @param productRaiseDO
     * @return
     */
    int raise(ProductRaiseDO productRaiseDO);

    /**
     * 回滚产品募集金额
     *
     * @param productRaiseDO
     * @return
     */
    int restore(ProductRaiseDO productRaiseDO);

    /**
     * 读取产品募集金额
     *
     * @param productUuid
     * @return
     */
    ProductProgress get(String productUuid);

    ProductProgress getProgress(@Param("productUuid") String productUuid);
}