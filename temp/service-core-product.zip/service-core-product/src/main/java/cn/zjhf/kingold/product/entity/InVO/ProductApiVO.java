package cn.zjhf.kingold.product.entity.InVO;

import cn.zjhf.kingold.common.param.ParamVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.Size;

/**
 * @author liuyao
 * @date 2018/3/2
 */
@ApiModel(value = "ProductApiVO", description = "产品应用端条件")
public class ProductApiVO  extends ParamVO {
    @ApiModelProperty(required = false, value = "商户号码(渠道商户号) （如：89890112）")
    @Size(min = 1, max = 18)
    private String merchantNum;

    private Integer startRow;

    private Integer pageSize;

    public String getMerchantNum() {
        return merchantNum;
    }

    public void setMerchantNum(String merchantNum) {
        this.merchantNum = merchantNum;
    }

    public Integer getStartRow() {
        return startRow;
    }

    public void setStartRow(Integer startRow) {
        this.startRow = startRow;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }
}
