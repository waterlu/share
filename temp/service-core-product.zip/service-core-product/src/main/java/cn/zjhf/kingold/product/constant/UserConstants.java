package cn.zjhf.kingold.product.constant;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Xiaody on 17/4/20.
 */
public class UserConstants {

    /**
     * 私募服务人员类型－专职理财师
     */
    public static final int RESERVATION_EXPECT = 1;
    /**
     * 私募服务人员类型－客服
     */
    public static final int RESERVATION_CUSTOMER_SERVICE = 2;

    

}
