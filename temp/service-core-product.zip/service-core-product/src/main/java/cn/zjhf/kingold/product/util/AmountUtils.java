package cn.zjhf.kingold.product.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.text.DecimalFormat;

/**
 * Created by zhangyijie on 2017/5/19.
 */
public class AmountUtils {
    protected static final Logger logger = LoggerFactory.getLogger(AmountUtils.class);

    //精确金额的小数精度
    private static final int DECICOUNT_EXAC = 2;

    //标准金额的小数精度
    private static final int DECICOUNT_STAND = 2;

    // 精确金额，保留四位
    public static String exacStr(double value) {
        DecimalFormat format = new DecimalFormat("0.0000");
        return format.format(value);
    }

    public static Double stand(double value) {
        return deciFormat(value, DECICOUNT_STAND);
    }

    public static String toString(double value) {
        DecimalFormat format = new DecimalFormat();
        format.applyPattern("##,###.00");
        return format.format(value);
    }

    public static String toString(String value) {
        double amt = 0.0;
        try {
            if(DataUtils.isNotEmpty(value)) {
                amt = Double.parseDouble(value);
            }
        }catch(Exception e) {
            logger.error("数据转换错误", e);
            amt = 0.0;
        }

        String strAmt = toString(amt);
        if(strAmt.startsWith(".")) {
            strAmt = "0" + strAmt;
        }else if(!strAmt.contains(".")) {
            strAmt = strAmt + ".00";
        }

        return strAmt;
    }

    public static String toString(BigDecimal value) {
        DecimalFormat format = new DecimalFormat();
        format.applyPattern("##,###.00");
        return format.format(value);
    }

    public static Double normal(double value) {
        if (Double.isNaN(value))
            return 0.0;

        BigDecimal bg = new BigDecimal(new Double(value).toString());
        return bg.setScale(DECICOUNT_STAND, BigDecimal.ROUND_HALF_UP).doubleValue();
    }

    public static Double exac(double value) {
        return deciFormat(value, DECICOUNT_EXAC);
    }

    public static Double exac(BigDecimal value) {
        return deciFormat(value, DECICOUNT_EXAC);
    }

    // 格式化double
    private static double deciFormat(BigDecimal value, int deciCount) {
        if (value == null)
            return 0;

        return value.setScale(deciCount, BigDecimal.ROUND_DOWN).doubleValue();
    }

    public static BigDecimal toBigDecimal(double value) {
        return new BigDecimal(new Double(value).toString());
    }

    // 格式化double
    private static double deciFormat(double value, int deciCount) {
        if (Double.isNaN(value))
            return 0;

        BigDecimal bg = new BigDecimal(new Double(value).toString());
        return bg.setScale(deciCount, BigDecimal.ROUND_DOWN).doubleValue();
    }
}
