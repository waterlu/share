package cn.zjhf.kingold.product.vo;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author xiexiaojie
 *         2018/3/26.
 */
public class ProductEarlyWarningVO {

    /**
     * 自增主键
     */
    private Integer productEarlyId;

    /**
     * 产品类型（PRIF私募基金FIXI固定收益理财）
     */
    private String productType;

    /**
     * 产品期限
     */
    private Integer productPeriod;

    /**
     * 产品期限类型： Y(year,年)； M(month,月)； W(week,周)； D(day,自然日)
     */
    private String productPeriodType;

    /**
     * 额度警戒线(元)
     */
    private BigDecimal productCordon;

    /**
     * 模版类型（唯一编号，一个模板类型表示一个文案模板）
     */
    private String notificationTemplateType;

    /**
     * 预警收件人 格式：手机号码-姓名；
     */
    private String warningAddressee;

    /**
     * 提醒开关，0：关闭，1：打开
     */
    private Byte remindSwitch;

    /**
     * 操作人（创建、编辑人）；
     */
    private String operator;

    /**
     * 删除标识
     */
    private Byte deleteFlag;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    public Integer getProductEarlyId() {
        return productEarlyId;
    }

    public void setProductEarlyId(Integer productEarlyId) {
        this.productEarlyId = productEarlyId;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public Integer getProductPeriod() {
        return productPeriod;
    }

    public void setProductPeriod(Integer productPeriod) {
        this.productPeriod = productPeriod;
    }

    public String getProductPeriodType() {
        return productPeriodType;
    }

    public void setProductPeriodType(String productPeriodType) {
        this.productPeriodType = productPeriodType;
    }

    public BigDecimal getProductCordon() {
        return productCordon;
    }

    public void setProductCordon(BigDecimal productCordon) {
        this.productCordon = productCordon;
    }

    public String getNotificationTemplateType() {
        return notificationTemplateType;
    }

    public void setNotificationTemplateType(String notificationTemplateType) {
        this.notificationTemplateType = notificationTemplateType;
    }

    public String getWarningAddressee() {
        return warningAddressee;
    }

    public void setWarningAddressee(String warningAddressee) {
        this.warningAddressee = warningAddressee;
    }

    public Byte getRemindSwitch() {
        return remindSwitch;
    }

    public void setRemindSwitch(Byte remindSwitch) {
        this.remindSwitch = remindSwitch;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        return "ProductEarlyWarningVO{" +
                "productEarlyId=" + productEarlyId +
                ", productType='" + productType + '\'' +
                ", productPeriod=" + productPeriod +
                ", productPeriodType='" + productPeriodType + '\'' +
                ", productCordon=" + productCordon +
                ", notificationTemplateType='" + notificationTemplateType + '\'' +
                ", warningAddressee='" + warningAddressee + '\'' +
                ", remindSwitch=" + remindSwitch +
                ", operator='" + operator + '\'' +
                ", deleteFlag=" + deleteFlag +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                '}';
    }
}
