package cn.zjhf.kingold.product.entity;

/**
 * @author lutiehua
 * @date 2017/12/22
 */
public class ProductUserRaiseDO {

    /**
     * 产品UUID
     *
     */
    private String productUuid;

    /**
     * 用户UUID
     *
     */
    private String userUuid;

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }
}
