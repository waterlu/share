package cn.zjhf.kingold.product.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.product.constant.BizDefine;
import cn.zjhf.kingold.product.constant.ProductConstants;
import cn.zjhf.kingold.product.constant.ProductStatusMsg;
import cn.zjhf.kingold.product.entity.ProductChannelRelational;
import cn.zjhf.kingold.product.entity.enums.ProductTypeEnum;
import cn.zjhf.kingold.product.persistence.dao.ProductChangeLogMapper;
import cn.zjhf.kingold.product.persistence.dao.ProductChannelRelationalMapper;
import cn.zjhf.kingold.product.persistence.dao.ProductMapper;
import cn.zjhf.kingold.product.persistence.dao.ProductRecommendationMapper;
import cn.zjhf.kingold.product.service.IRecommendationService;
import cn.zjhf.kingold.product.util.BizParam;
import cn.zjhf.kingold.product.util.DataUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by Xiaody on 17/4/14.
 */
@Service
public class RecommendationServiceImpl implements IRecommendationService {

    private static Logger LOGGER = LoggerFactory.getLogger(RecommendationServiceImpl.class);

    @Autowired
    private ProductRecommendationMapper recommendationMapper;

    @Autowired
    private ProductMapper productMapper;

    @Autowired
    private ProductChangeLogMapper productChangeLogMapper;

    @Autowired
    private ProductChannelRelationalMapper productChannelRelationalMapper;

    @Autowired
    private ProductServiceImpl productServiceImpl;

    @Override
    public Long insert(Map map) throws BusinessException {
        Map product = get(map.get("productUuid").toString());
        //插入产品修改日志表
        map.put("productChangeContent", "产品推荐");
        map.put("productName", product.get("productName").toString());
        productChangeLogMapper.insert(map);
        recommendationMapper.insert(map);
        return (Long) map.get("productRecommendationID");
    }

    @Override
    public void update(Map map) throws BusinessException {
        recommendationMapper.update(map);
    }

    @Override
    public List<Map> getList(Map map) throws BusinessException {
        return recommendationMapper.getList(map);
    }

    @Override
    public Integer getCount(Map map) throws BusinessException {
        return recommendationMapper.getCount(map);
    }

    /**
     * 获取新手标产品
     * @return
     */
    private Map getNoviceLabelProduct(Map map) {
        Map productInfo = null;
        if(BizDefine.isFromFrontEndSystem(map)) {
            boolean isGetNoviceLabelProduct = true;
            //有userUuid，并且该用户有有效的投资记录，则不可再取新手标产品
            if(map.containsKey("userUuid") && DataUtils.isNotEmpty(productMapper.havaValidOrder((String)map.get("userUuid")))) {
                isGetNoviceLabelProduct = false;
            }

            if(isGetNoviceLabelProduct) {
                productInfo = productMapper.getNoviceLabelProduct();

                if((productInfo != null) && (productInfo.size() > 0)) {
                    //设置新手标标志
                    productInfo.put("isNoviceLabelProduct", true);
                }
            }
        }

        LOGGER.info("获取新手标产品:" + DataUtils.toString(productInfo));
        return productInfo;
    }

    private Map getNoviceLabelProduct(Map map, String productType) throws BusinessException {
        List<Map> recommendations = recommendationMapper.getRecommendProduct(map);
        if (recommendations.size() > 0) {
            String productUuid = (String) recommendations.get(0).get("productUuid");
            Map product;
            if (StringUtils.equals(ProductTypeEnum.PRIVATE_FUND.getCode(), productType)) {
                product =  productMapper.getPrivateFund(productUuid);
            } else {
                product = productMapper.getFixedIncome(productUuid);

                //判断该产品是否为新手标产品
                if(product.containsKey("productLabel")){
                    String productLabel = (String)product.get("productLabel");
                    if(productLabel.contains("1")) {
                        //用户不可购买新手标产品，则取下一个推荐产品
                        if(map.containsKey("userUuid") && DataUtils.isNotEmpty(productMapper.havaValidOrder((String)map.get("userUuid")))) {
                            if(recommendations.size() > 1) {
                                return productMapper.getFixedIncome((String) recommendations.get(1).get("productUuid"));
                            }else {
                                return null;
                            }
                        }else {
                            //设置新手标标志
                            product.put("isNoviceLabelProduct", true);
                            return product;
                        }
                    }
                }
            }

            if (product == null || (Integer)product.get("productStatus") == 0 ) {
                throw new BusinessException(ProductStatusMsg.NO_RECOMMEND_PRODUCT_CODE, ProductStatusMsg.NO_RECOMMEND_PRODUCT_MSG, true);
            }

            if (map.get("merchantNum") == null)
                return product;

            ProductChannelRelational productChannelRelational = productChannelRelationalMapper.getByProductUuidAndChannel(productUuid, map.get("merchantNum").toString());
            if (productChannelRelational != null && productChannelRelational.getMerchantNum().equals(map.get("merchantNum").toString())) {
                return product;
            } else {
                throw new BusinessException(ProductStatusMsg.NO_RECOMMEND_PRODUCT_CODE, ProductStatusMsg.NO_RECOMMEND_PRODUCT_MSG, true);
            }
        }

        return null;
    }

    /**
     * 获取推荐的产品
     * @param map
     * @return
     * @throws BusinessException
     */
    @Override
    public Map getRecommendation(Map map) throws BusinessException {
        String productType = (String) map.get("productType");
        Map productInfo = getNoviceLabelProduct(map, productType);
        if(productInfo != null) {
            return productInfo;
        }

        map.put("orderBy", " product_open_time desc");
        map.put("startRow", 0);
        map.put("pageSize", 1);
        List<Map> productList;
        if (StringUtils.equals(ProductTypeEnum.PRIVATE_FUND.getCode(), productType)) {
            productList = productMapper.getPrivateFundList(map);
        } else {
            boolean isValid = true;
            if(!map.containsKey("operateFlag")) {
                if(map.containsKey("productStatus")) {
                    int status = new BizParam(map).getInt("productStatus");

                    if(DataUtils.isContain(status, ProductConstants.PRODUCT_STATUS_UNCONFIRMED, ProductConstants.PRODUCT_STATUS_ABORT)) {
                        LOGGER.info("前端不可取出状态为未确认和已废弃的产品");
                        isValid = false;
                    }
                }
            }

            if(isValid) {
                productList = productServiceImpl.getFixedIncomeList(map);
            }else {
                productList = new ArrayList<Map>();
            }
        }

        if (productList != null && productList.size() > 0 && (Integer)productList.get(0).get("productStatus") != 0) {
            return productList.get(0);
        }

        throw new BusinessException(ProductStatusMsg.NO_RECOMMEND_PRODUCT_CODE, ProductStatusMsg.NO_RECOMMEND_PRODUCT_MSG, true);
    }

    /**
     * 获取推荐的产品，不区分产品类型
     *
     * @param map
     * @return
     * @throws BusinessException
     */
    @Override
    public Map getRecommendProduct(Map map) throws BusinessException {
        List<Map> recommendations = recommendationMapper.getRecommendProduct(map);
        if (recommendations.size() > 0) {
            return recommendations.get(0);
        }
        return null;
    }

    /**
     * 更新推荐产品
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @Override
    public Long updateByProductUuid(Map params) throws BusinessException {

        Long count = recommendationMapper.updateByProductUuid(params.get("productUuid").toString());
        if(count > 0){
            Map product = get(params.get("productUuid").toString());
            //插入产品修改日志表
            params.put("productChangeContent", "产品推荐");
            params.put("productName", product.get("productName").toString());
            productChangeLogMapper.insert(params);
        }
        return count;
    }

    /**
     * 获取已推荐产品
     *
     * @param map
     * @return
     * @throws BusinessException
     */
    @Override
    public List<Map> getRecommendProductList(Map map) throws BusinessException{
        return recommendationMapper.getRecommendProductList(map);
    }

    /**
     * 根据产品uuid获取产品主表信息
     *
     * @param productUuid
     * @return
     * @throws BusinessException
     */
    public Map get(String productUuid) throws BusinessException {
        return productMapper.get(productUuid);
    }


}
