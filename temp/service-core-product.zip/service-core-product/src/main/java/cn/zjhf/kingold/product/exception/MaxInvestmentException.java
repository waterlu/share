package cn.zjhf.kingold.product.exception;

import cn.zjhf.kingold.common.exception.BusinessException;

/**
 * @author lutiehua
 * @date 2018/3/7
 */
public class MaxInvestmentException extends BusinessException {

    public MaxInvestmentException() {
        super(6213, "认购金额超出本产品单人投资上限，请重新输入");
    }
}
