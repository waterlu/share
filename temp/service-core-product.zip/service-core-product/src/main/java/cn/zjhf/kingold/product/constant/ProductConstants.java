package cn.zjhf.kingold.product.constant;

import cn.zjhf.kingold.product.util.BizParam;
import cn.zjhf.kingold.product.util.DataUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Xiaody on 17/4/20.
 */
public class ProductConstants {
    public static final Map<Integer, String> PRODUCT_CHANGE_TYPE = new HashMap() {{
        put(1, "创建产品");
        put(2, "修改产品");
        put(3, "上下架产品");
        put(4, "更改状态");
        put(5, "更新募集金额");
        put(6, "产品推荐");
        put(7, "产品置顶");
    }};

    /**
     * 产品状态 0待确认
     */
    public static final int PRODUCT_STATUS_UNCONFIRMED = 0;

    /**
     * 产品状态 1预热中
     */
    public static final int PRODUCT_STATUS_PREHEAT  = 1;

    /**
     * 产品状态 2募集中
     */
    public static final int PRODUCT_STATUS_RAISE = 2;

    /**
     * 产品状态 3募集结束
     */
    public static final int PRODUCT_STATUS_ENDRAISE = 3;

    /**
     * 产品状态 4产品成立
     */
    public static final int PRODUCT_STATUS_ESTABLISH = 4;

    /**
     * 产品状态 5产品放款
     */
    public static final int PRODUCT_STATUS_LOAN = 5;

    /**
     * 产品状态 6计息中
     */
    public static final int PRODUCT_STATUS_INTEREST = 6;

    /**
     * 产品状态 15封闭期
     */
    public static final int PRODUCT_PRIVATE_STATUS_CLOSED_PERIOD = 15;

    /**
     * 产品状态 16存续期
     */
    public static final int PRODUCT_PRIVATE_STATUS_DURATION = 16;

    /**
     * 产品状态 17已结束
     */
    public static final int PRODUCT_PRIVATE_STATUS_PRODUCTEND = 17;

    /**
     * 产品状态 8已到期
     */
    public static final int PRODUCT_STATUS_PRODUCTEND = 8;

    /**
     * 产品状态 9已兑付
     */
    public static final int PRODUCT_STATUS_CLEAR = 9;

    /**
     * 产品状态 21已废弃/中止
     */
    public static final int PRODUCT_STATUS_ABORT = 21;

    public static String getProductStatusName(int status) {
        switch(status) {
            case PRODUCT_STATUS_UNCONFIRMED:
                return "待确认";
            case PRODUCT_STATUS_PREHEAT:
                return "预热中";
            case PRODUCT_STATUS_RAISE:
                return "募集中";
            case PRODUCT_STATUS_ENDRAISE:
                return "已售罄";
            case PRODUCT_STATUS_ESTABLISH:
                return "已成立";
            case PRODUCT_STATUS_LOAN:
                return "已放款";
            case PRODUCT_STATUS_INTEREST:
                return "计息中";
            case PRODUCT_PRIVATE_STATUS_CLOSED_PERIOD:
                return "封闭期";
            case PRODUCT_PRIVATE_STATUS_DURATION:
                return "存续期";
            case PRODUCT_PRIVATE_STATUS_PRODUCTEND:
                return "已结束";
            case PRODUCT_STATUS_PRODUCTEND:
                return "已到期";
            case PRODUCT_STATUS_CLEAR:
                return "已兑付";
            case PRODUCT_STATUS_ABORT:
                return "已作废";
            default:
                return "其他";
        }
    }

//    public static final Map<Integer, String> PRODUCT_STATUS = new HashMap() {{
//        put(1, "预热中");
//        put(2, "募集中");
//        put(3, "已售罄");
//        put(4, "已成立");
//        put(5, "产品放款");
//        put(6, "计息中");
//        put(15, "封闭期");
//        put(16, "存续期");
//        put(17, "已结束");
//        put(8, "已到期");
//        put(9, "已兑付");
//    }};

    public static final Map<Integer, String> PRODUCT_ON_STATUS = new HashMap() {{
        put(1, "未上架");
        put(2, "已上架");
        put(3, "已下架");

    }};

    public static final Map<String, Integer> PRODUCT_PERIOD_TYPE = new HashMap() {{
        put("Y", 360);
        put("M", 30);
        put("W", 7);
        put("D", 1);
    }};

    /**
     * 预约单状态－预约中
     */
    public static final int RESERVATION_STAUTS_RESERVING = 1;
    /**
     * 预约单状态－已流转
     */
    public static final int RESERVATION_STAUTS_FLOW = 2;
    /**
     * 预约单状态－已成功
     */
    public static final int RESERVATION_STAUTS_SUCCESS = 3;
    /**
     * 预约单状态－已取消
     */
    public static final int RESERVATION_STAUTS_CANCEL = 4;
    /**
     * 预约单状态－已取消
     */
    public static final int RESERVATION_STAUTS_OVERDUE = 5;

    /**
     * 未上架
     */
    public static final int PRODUCT_SHELVES_INIT = 1;

    /**
     * 产品上架
     */
    public static final int PRODUCT_SHELVES_ON = 2;

    /**
     * 产品下架
     */
    public static final int PRODUCT_SHELVES_OFF = 3;

    /**
     * 产品变更类型 4状态变更
     */
    public static final int PRODUCT_CHANGE_TYPE_STATUS = 4;

    /**
     * 产品变更类型 5更新募集金额
     */
    public static final int PRODUCT_CHANGE_TYPE_RAISEAMOUNT = 5;
}
