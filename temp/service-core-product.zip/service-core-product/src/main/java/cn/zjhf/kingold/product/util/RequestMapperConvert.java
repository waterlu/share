package cn.zjhf.kingold.product.util;

import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by wangxun on 2017/4/19.
 */
public class RequestMapperConvert {
    public static Map<String,String> convert(Map<String,String[]> params){
        Map<String,String> result = new HashMap<>();
        for(String key : params.keySet()){
            if(params.get(key)[0] != null ) {
                result.put(key, params.get(key)[0]);
            }
        }

        return result;
    }

    /**
     * 对params参数中增加一些标准数据
     * @param params
     */
    public static void initParam(Map params){
        //修改所有params中value为字符串
        for(Object key : params.keySet()){
            Object value = params.get(key);
            if(value != null ){
                params.put(key, value.toString());
            }
        }

        //设置分页默认值
        if(params.get("pageSize") == null){
            params.put("pageSize",20);
        }
        if(params.get("startRow") == null){
            params.put("startRow",0);
        }

    }

    /**
     * 对params参数中增加一些标准数据
     * @param params
     */
    public static void initReservationParam(Map params){

        String  reservationStatus = (String)params.get("reservationStatus");
        if(StringUtils.isNotBlank(reservationStatus)){
            List<String> reservationStatusList = Arrays.asList(reservationStatus.split("\\$\\$"));
            params.put("reservationStatusList",reservationStatusList);
        }
    }

    /**
     * 对params参数中增加一些标准数据
     * @param params
     */
    public static void initProductParam(Map params){
        String productStatusArray = (String)params.get("productStatusArray");
        if(StringUtils.isNotBlank(productStatusArray)){
            List<String> productStatusList = Arrays.asList(productStatusArray.split("\\$\\$"));
            params.put("productStatusList",productStatusList);
        }

        String noProductUuids = (String)params.get("noProductUuids");
        if(StringUtils.isNotBlank(noProductUuids)){
            List<String> productUuidList = Arrays.asList(noProductUuids.split("\\$\\$"));
            params.put("noProductUuidList",productUuidList);
        }

        String productUuids = (String)params.get("productUuids");
        if(StringUtils.isNotBlank(productUuids)){
            List<String> productUuidList = Arrays.asList(productUuids.split("\\$\\$"));
            params.put("productUuids",productUuidList);
        }

        String productTypes = (String)params.get("productTypes");
        if(StringUtils.isNotBlank(productTypes)){
            List<String> productTypeList = Arrays.asList(productTypes.split("\\$\\$"));
            params.put("productTypeList",productTypeList);
        }

        String productPeriods = (String)params.get("productPeriods");
        if(StringUtils.isNotBlank(productPeriods)){
            List<String> productPeriodList = Arrays.asList(productPeriods.split("\\$\\$"));
            params.put("productPeriodList",productPeriodList);
        }

    }


}


