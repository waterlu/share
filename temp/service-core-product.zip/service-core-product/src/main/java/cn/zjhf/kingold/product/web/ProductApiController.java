package cn.zjhf.kingold.product.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.product.entity.InVO.ProductApiVO;
import cn.zjhf.kingold.product.entity.OutVO.ProductApiOutVO;
import cn.zjhf.kingold.product.service.IProductApiService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Created by liuyao on 18/03/01.
 */
@RestController
@RequestMapping("/api/product")
public class ProductApiController {

    private static Logger LOGGER = LoggerFactory.getLogger(ProductApiController.class);

    @Autowired
    private IProductApiService productAPiService;

    /**
     * 根据查询条件获取固收产品列表
     *
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/fixOnlineList", method = RequestMethod.GET)
    public ResponseResult fixOnlineList(@RequestParam(value = "merchantNum", defaultValue = "00000") String merchantNum,
                                        @RequestParam(value = "traceID") String traceID,
                                        @RequestParam(value = "isNew", defaultValue = "1") Integer isNew,
                                        @RequestParam(value = "startRow", defaultValue = "0") Integer startRow,
                                        @RequestParam(value = "pageSize", defaultValue = "20") Integer pageSize) throws BusinessException {
        ProductApiOutVO productApiOutVO = productAPiService.fixOnlineList(merchantNum, isNew, startRow, pageSize);
        return new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS, "正常调用", productApiOutVO);
    }

    /**
     * 根据查询条件获取过期固收产品列表
     *
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/fixOfflineList", method = RequestMethod.GET)
    public ResponseResult fixOfflineList(@RequestParam(value = "merchantNum", defaultValue = "00000") String merchantNum,
                                         @RequestParam(value = "traceID") String traceID,
                                         @RequestParam(value = "startRow", defaultValue = "0") Integer startRow,
                                         @RequestParam(value = "pageSize", defaultValue = "20") Integer pageSize) throws BusinessException {
        ProductApiOutVO productApiOutVO = productAPiService.fixOfflineList(merchantNum, startRow, pageSize);
        return new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS, "正常调用", productApiOutVO);
    }

}
