package cn.zjhf.kingold.product.util;


import cn.zjhf.kingold.common.exception.BusinessException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.stream.XMLStreamException;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class PropertyDescriptionUtils {
    private static final Logger LOGGER = LoggerFactory.getLogger(PropertyDescriptionUtils.class);

    private static Map<String, Map<String, String>> PRODUCT_DIC = null;

    static {

        try {
            PRODUCT_DIC = initMap("productDic.xml");
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            e.printStackTrace();
        }

    }


    /**
     * 根据properties 过滤 sourceObject值 ，返回仅有 properties 属性的map对象。
     * 返回properties 存在字典映射关系时，返回字典的哪个属性。 如果为空，则不与字典匹配
     *
     * @param sourceObject
     * @return
     */
    public static Map convertProductProperty(Map sourceObject,String properties,String desc) throws BusinessException {
        if (StringUtils.isBlank(properties)) {
            return sourceObject;
        }
        List<String> propList = Arrays.asList(properties.split("\\$\\$"));
        if (sourceObject == null || sourceObject.keySet().size() == 0) {
            return sourceObject;
        }

        Map targetObject = new HashMap();
        propList.forEach(prop -> {
            if (null != sourceObject.get(prop)) targetObject.put(prop, sourceObject.get(prop));
        });

        if (StringUtils.isBlank(desc)) {
            return targetObject;
        }

        propList.forEach(prop -> {
            String propDescValue = getProductDic(prop, targetObject.get(prop).toString());
            if (StringUtils.isNotBlank(propDescValue)) targetObject.put(prop + "Desc", propDescValue);
        });

        return targetObject;
    }


    private static String getProductDic(String key, String value) {
        if (PRODUCT_DIC == null || StringUtils.isBlank(value))
            return null;
        Map<String, String> map = PRODUCT_DIC.get(key);
        if (map != null) {
            return map.get(value);
        }
        return null;
    }


    public static Map<String, Map<String, String>> initMap(String xmlPath) throws XMLStreamException, ParserConfigurationException, BusinessException, IOException, SAXException {
        Map<String, Map<String, String>> countMap = new HashMap<>();
        Map<String, String> twoMap;
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();

        Document document = builder.parse(PropertyDescriptionUtils.class.getClassLoader().getResourceAsStream(xmlPath));
        Element element = document.getDocumentElement();
        NodeList elementNodes = element.getElementsByTagName("element");
        for (int i = 0; i < elementNodes.getLength(); i++) {
            Element childElement = (Element) elementNodes.item(i);
            twoMap = new HashMap<>();
            NodeList childNodes = childElement.getChildNodes();
            for (int j = 0; j < childNodes.getLength(); j++) {
                if (childNodes.item(j).getNodeType() == Node.ELEMENT_NODE) {
                    Element element1 = (Element) childNodes.item(j);
                    twoMap.put(element1.getAttribute("value"), element1.getAttribute("name"));
                }
            }
            countMap.put(childElement.getAttribute("name"), twoMap);
        }
        return countMap;
    }

}