package cn.zjhf.kingold.product.persistence.dao;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
@Mapper
public interface ProductChangeLogMapper {
    Integer insert(Map map);

    List<Map> getList(Map map);

    Integer getCount(Map map);
}