package cn.zjhf.kingold.product.util;

import cn.zjhf.kingold.common.exception.BusinessException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

/**
 * Created by zhangyijie on 2017/5/10.
 */
public class BizParam {
    protected static final Logger logger = LoggerFactory.getLogger(BizParam.class);

    private Map _map;

    public BizParam(Map map) {
        //RequestMapperConvert.initParam(map);
        this._map = map;
    }

    public boolean containsKey(String key){
        return _map.containsKey(key);
    }

    public String get(String key) {
        if(_map.containsKey(key)) {
            Object obj = _map.get(key);
            if(obj != null) {
                return obj.toString();
            }else {
                return "";
            }
        }

        return "";
    }

    public String getString(String key) {
        return get(key);
    }

    public Byte getByte(String key) {
        try {
            return getInt(key).byteValue();
        }catch(Exception e) {
            logger.error("数据转换错误", e);
            return new Byte("0");
        }
    }

    public Integer getInt(String key) {
        try {
            String value = get(key);
            if(DataUtils.isNotEmpty(value)) {
                return Integer.parseInt(value);
            }else {
                return new Integer(0);
            }
        }catch(Exception e) {
            logger.error("数据转换错误", e);
            return new Integer(0);
        }
    }

    public Long getLong(String key) {
        try {
            String value = get(key);
            if(DataUtils.isNotEmpty(value)) {
                return Long.parseLong(value);
            }else {
                return new Long(0);
            }
        }catch(Exception e) {
            logger.error("数据转换错误", e);
            return new Long(0);
        }
    }

    public Double getDouble(String key) {
        try {
            String value = get(key);
            if(DataUtils.isNotEmpty(value)) {
                return Double.parseDouble(value);
            }else {
                return new Double(0);
            }
        }catch(Exception e) {
            logger.error("数据转换错误", e);
            return new Double(0);
        }
    }

    public BigDecimal getBigDecimal(String key) {
        try {
            String value = get(key);
            if(DataUtils.isNotEmpty(value)) {
                return  new BigDecimal(Double.parseDouble(value));
            }else {
                return new BigDecimal(0);
            }
        }catch(Exception e) {
            logger.error("数据转换错误", e);
            return new BigDecimal(0);
        }
    }

    public Date getDate(String key) {
        final String pattern = "yyyy-MM-dd hh:mm:ss";

        if(_map.containsKey(key)) {
            Object obj = _map.get(key);
            if((obj != null) && (obj instanceof Date)) {
                return (Date)obj;
            }else if(obj instanceof String) {
                try {
                    return new SimpleDateFormat(pattern).parse((String)obj);
                } catch (ParseException e) {
                    logger.error("数据转换错误", e);
                    return null;
                }
            }
        }

        return null;
    }

    public Object getObj(String key) {
        return _map.get(key);
    }

    public boolean isBlank(String key) {
        return StringUtils.isNotBlank(get(key));
    }

    public boolean check() throws BusinessException {
        Iterator entries = _map.entrySet().iterator();
        while (entries.hasNext()) {
            Map.Entry entry = (Map.Entry) entries.next();
            if(null == entry.getValue())
                return false;
        }

        return true;
    }

    public Map getMap() {
        return _map;
    }

    public String toString() {
        return (_map != null) ? _map.toString() : "null";
    }
}
