package cn.zjhf.kingold.product.entity;

import java.io.Serializable;

/**
 * @author 
 */
public class OperationReport extends OperationReportKey implements Serializable {
    /**
     * 报表规则
     */
    private String reportRule;

    /**
     * 批次描述
     */
    private String batchDesc;

    /**
     * 报表描述
     */
    private String reportDesc;

    private static final long serialVersionUID = 1L;

    public String getReportRule() {
        return reportRule;
    }

    public void setReportRule(String reportRule) {
        this.reportRule = reportRule;
    }

    public String getBatchDesc() {
        return batchDesc;
    }

    public void setBatchDesc(String batchDesc) {
        this.batchDesc = batchDesc;
    }

    public String getReportDesc() {
        return reportDesc;
    }

    public void setReportDesc(String reportDesc) {
        this.reportDesc = reportDesc;
    }
}