package cn.zjhf.kingold.product.util;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.product.constant.ProductStatusMsg;
import cn.zjhf.kingold.product.entity.InVO.ReportConditionVO;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangyijie on 2017/6/28.
 */
public class ReportUtils {
    private String reportRule = null;
    private List<String> fieldNames = new ArrayList<String>();
    private List<String> wildCards = new ArrayList<String>();

    final static String Amt = "Amt";
    final static String Time = "Time";

    public ReportUtils(String value) {
        reportRule = value;

        init();

        creatWildCards();
        creatFieldNames();
    }

    private void init() {
        String[] tmpStrs = reportRule.split("\\s+");

        for(int i=0; i<tmpStrs.length; i++) {
            String tmpStr = tmpStrs[i].trim();
            if(tmpStr.startsWith("$")) {
                String target = "";

                if(tmpStr.endsWith(",")) {
                    target = toSQLStr(tmpStr.substring(0, tmpStr.length() -1).replace("$", "")) + ",";
                }else {
                    target = toSQLStr(tmpStr.replace("$", ""));
                }

                reportRule = reportRule.replace(tmpStr, target);
            }
        }
    }

    private void creatWildCards() {
        String[] tmpStrs = reportRule.split("\\s+");

        for(int i=0; i<tmpStrs.length; i++) {
            if(tmpStrs[i].trim().startsWith("#")) {
                wildCards.add(tmpStrs[i].trim());
            }
        }
    }

    private void creatFieldNames() {
        String[] tmpStrs = reportRule.split("\\s+");

        int asPos = -1;
        for(int i=0; i<tmpStrs.length; i++) {
            if(tmpStrs[i].trim().equals("AS") || tmpStrs[i].trim().equals("as")) {
                asPos = i;
            }

            if((asPos != -1) && ((i-1) == asPos)) {
                fieldNames.add(tmpStrs[i].replace(",", "").replace("'", "").trim());
                asPos = -1;
            }
        }
    }


    public List<String> getFieldNames() {
        return fieldNames;
    }

    private String toSQLStr(String strValue) {
        if (DataUtils.isEmpty(strValue))
            strValue = "''";

        return "'" + strValue.trim() + "'";
    }

    public void processWildCard(ReportConditionVO condi) throws BusinessException {
        for(String wildCard : wildCards) {
            wildCard = wildCard.trim();
            String value = null;

//            if(wildCard.equals("#productCode")) {
//                value = (DataUtils.isNotEmpty(condi.getProductCode()) ? toSQLStr(condi.getProductCode()) : null);
                //产品名称和产品编号是或的关系
//                if((wildCards.contains("#productAbbrName")) && (value == null)) {
//                    value = toSQLStr("");
//                }else {
//                    value = "OR" + value
//                }
//            }else
            if(wildCard.equals("#productInterestBeginDate")) {
                if(condi.getProductInterestBeginDate() != null) {
                    value = DateUtil.formateDate(condi.getProductInterestBeginDate());
                    value = toSQLStr(value);
                }
            }else if (wildCard.equals("#productUuid")){
                 if(DataUtils.isNotEmpty(condi.getProductUuid())){
                     value = toSQLStr(condi.getProductUuid());
                 }
            }else if(wildCard.equals("#productAbbrName")) {
                value = (DataUtils.isNotEmpty(condi.getProductAbbrName()) ? condi.getProductAbbrName() : "");
                value = "%" + value + "%";
                value = toSQLStr(value);
            }else if(wildCard.equals("#productInterestBeginDate")) {
                if(condi.getProductInterestBeginDate() != null) {
                    value = DateUtil.formateDate(condi.getProductInterestBeginDate());
                    value = toSQLStr(value);
                }
            }else if(wildCard.equals("#productInterestEndDate")) {
                if(condi.getProductInterestEndDate() != null) {
                    value = DateUtil.formateDate(condi.getProductInterestEndDate());
                    value = toSQLStr(value);
                }
            }else if(wildCard.equals("#productExpiringBeginDate")) {
                if(condi.getProductExpiringBeginDate() != null) {
                    value = DateUtil.formateDate(condi.getProductExpiringBeginDate());
                    value = toSQLStr(value);
                }
            }else if(wildCard.equals("#productExpiringEndDate")) {
                if(condi.getProductExpiringEndDate() != null) {
                    value = DateUtil.formateDate(condi.getProductExpiringEndDate());
                    value = toSQLStr(value);
                }
            }else if(wildCard.equals("#beginSN,#endSN")){
                value = condi.getBeginSN()+","+condi.getEndSN();
            }
            if(value == null) {
                throw new BusinessException(ProductStatusMsg.REPORT_PARAM_ERR, ProductStatusMsg.REPORT_PARAM_ERR_MSG, false);
            }
            reportRule = reportRule.replace(wildCard, value);
        }
    }

    public List<String> getFilterFieldNames() {
        List<String> filterFieldNames = new ArrayList<String>();
        for(String fieldName : fieldNames) {
            fieldName = fieldName.replace(Amt,"").replace(Time,"");
            filterFieldNames.add(fieldName);
        }

        return filterFieldNames;
    }

    public static String getValue(String fieldName, String value) {
        if(fieldName.endsWith(Time)) {
            int pos = value.lastIndexOf(".");
            return value.substring(0,pos);
        }else if(fieldName.endsWith(Amt)) {
            return AmountUtils.toString(value);
        }

        return value;
    }

    public String getCondition() {
        return toString();
    }

    @Override
    public String toString() {
        return reportRule.toString();
    }
}
