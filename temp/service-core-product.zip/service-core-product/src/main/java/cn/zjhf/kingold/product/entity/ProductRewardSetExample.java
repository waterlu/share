package cn.zjhf.kingold.product.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ProductRewardSetExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private Integer limit;

    private Integer offset;

    public ProductRewardSetExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andProductAwardIdIsNull() {
            addCriterion("product_award_id is null");
            return (Criteria) this;
        }

        public Criteria andProductAwardIdIsNotNull() {
            addCriterion("product_award_id is not null");
            return (Criteria) this;
        }

        public Criteria andProductAwardIdEqualTo(Long value) {
            addCriterion("product_award_id =", value, "productAwardId");
            return (Criteria) this;
        }

        public Criteria andProductAwardIdNotEqualTo(Long value) {
            addCriterion("product_award_id <>", value, "productAwardId");
            return (Criteria) this;
        }

        public Criteria andProductAwardIdGreaterThan(Long value) {
            addCriterion("product_award_id >", value, "productAwardId");
            return (Criteria) this;
        }

        public Criteria andProductAwardIdGreaterThanOrEqualTo(Long value) {
            addCriterion("product_award_id >=", value, "productAwardId");
            return (Criteria) this;
        }

        public Criteria andProductAwardIdLessThan(Long value) {
            addCriterion("product_award_id <", value, "productAwardId");
            return (Criteria) this;
        }

        public Criteria andProductAwardIdLessThanOrEqualTo(Long value) {
            addCriterion("product_award_id <=", value, "productAwardId");
            return (Criteria) this;
        }

        public Criteria andProductAwardIdIn(List<Long> values) {
            addCriterion("product_award_id in", values, "productAwardId");
            return (Criteria) this;
        }

        public Criteria andProductAwardIdNotIn(List<Long> values) {
            addCriterion("product_award_id not in", values, "productAwardId");
            return (Criteria) this;
        }

        public Criteria andProductAwardIdBetween(Long value1, Long value2) {
            addCriterion("product_award_id between", value1, value2, "productAwardId");
            return (Criteria) this;
        }

        public Criteria andProductAwardIdNotBetween(Long value1, Long value2) {
            addCriterion("product_award_id not between", value1, value2, "productAwardId");
            return (Criteria) this;
        }

        public Criteria andProductUuidIsNull() {
            addCriterion("product_uuid is null");
            return (Criteria) this;
        }

        public Criteria andProductUuidIsNotNull() {
            addCriterion("product_uuid is not null");
            return (Criteria) this;
        }

        public Criteria andProductUuidEqualTo(String value) {
            addCriterion("product_uuid =", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotEqualTo(String value) {
            addCriterion("product_uuid <>", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidGreaterThan(String value) {
            addCriterion("product_uuid >", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidGreaterThanOrEqualTo(String value) {
            addCriterion("product_uuid >=", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidLessThan(String value) {
            addCriterion("product_uuid <", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidLessThanOrEqualTo(String value) {
            addCriterion("product_uuid <=", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidLike(String value) {
            addCriterion("product_uuid like", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotLike(String value) {
            addCriterion("product_uuid not like", value, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidIn(List<String> values) {
            addCriterion("product_uuid in", values, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotIn(List<String> values) {
            addCriterion("product_uuid not in", values, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidBetween(String value1, String value2) {
            addCriterion("product_uuid between", value1, value2, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductUuidNotBetween(String value1, String value2) {
            addCriterion("product_uuid not between", value1, value2, "productUuid");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameIsNull() {
            addCriterion("product_abbr_name is null");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameIsNotNull() {
            addCriterion("product_abbr_name is not null");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameEqualTo(String value) {
            addCriterion("product_abbr_name =", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameNotEqualTo(String value) {
            addCriterion("product_abbr_name <>", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameGreaterThan(String value) {
            addCriterion("product_abbr_name >", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameGreaterThanOrEqualTo(String value) {
            addCriterion("product_abbr_name >=", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameLessThan(String value) {
            addCriterion("product_abbr_name <", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameLessThanOrEqualTo(String value) {
            addCriterion("product_abbr_name <=", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameLike(String value) {
            addCriterion("product_abbr_name like", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameNotLike(String value) {
            addCriterion("product_abbr_name not like", value, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameIn(List<String> values) {
            addCriterion("product_abbr_name in", values, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameNotIn(List<String> values) {
            addCriterion("product_abbr_name not in", values, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameBetween(String value1, String value2) {
            addCriterion("product_abbr_name between", value1, value2, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductAbbrNameNotBetween(String value1, String value2) {
            addCriterion("product_abbr_name not between", value1, value2, "productAbbrName");
            return (Criteria) this;
        }

        public Criteria andProductTypeIsNull() {
            addCriterion("product_type is null");
            return (Criteria) this;
        }

        public Criteria andProductTypeIsNotNull() {
            addCriterion("product_type is not null");
            return (Criteria) this;
        }

        public Criteria andProductTypeEqualTo(String value) {
            addCriterion("product_type =", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeNotEqualTo(String value) {
            addCriterion("product_type <>", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeGreaterThan(String value) {
            addCriterion("product_type >", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeGreaterThanOrEqualTo(String value) {
            addCriterion("product_type >=", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeLessThan(String value) {
            addCriterion("product_type <", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeLessThanOrEqualTo(String value) {
            addCriterion("product_type <=", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeLike(String value) {
            addCriterion("product_type like", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeNotLike(String value) {
            addCriterion("product_type not like", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeIn(List<String> values) {
            addCriterion("product_type in", values, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeNotIn(List<String> values) {
            addCriterion("product_type not in", values, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeBetween(String value1, String value2) {
            addCriterion("product_type between", value1, value2, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeNotBetween(String value1, String value2) {
            addCriterion("product_type not between", value1, value2, "productType");
            return (Criteria) this;
        }

        public Criteria andProductInviteAwardIsNull() {
            addCriterion("product_invite_award is null");
            return (Criteria) this;
        }

        public Criteria andProductInviteAwardIsNotNull() {
            addCriterion("product_invite_award is not null");
            return (Criteria) this;
        }

        public Criteria andProductInviteAwardEqualTo(String value) {
            addCriterion("product_invite_award =", value, "productInviteAward");
            return (Criteria) this;
        }

        public Criteria andProductInviteAwardNotEqualTo(String value) {
            addCriterion("product_invite_award <>", value, "productInviteAward");
            return (Criteria) this;
        }

        public Criteria andProductInviteAwardGreaterThan(String value) {
            addCriterion("product_invite_award >", value, "productInviteAward");
            return (Criteria) this;
        }

        public Criteria andProductInviteAwardGreaterThanOrEqualTo(String value) {
            addCriterion("product_invite_award >=", value, "productInviteAward");
            return (Criteria) this;
        }

        public Criteria andProductInviteAwardLessThan(String value) {
            addCriterion("product_invite_award <", value, "productInviteAward");
            return (Criteria) this;
        }

        public Criteria andProductInviteAwardLessThanOrEqualTo(String value) {
            addCriterion("product_invite_award <=", value, "productInviteAward");
            return (Criteria) this;
        }

        public Criteria andProductInviteAwardLike(String value) {
            addCriterion("product_invite_award like", value, "productInviteAward");
            return (Criteria) this;
        }

        public Criteria andProductInviteAwardNotLike(String value) {
            addCriterion("product_invite_award not like", value, "productInviteAward");
            return (Criteria) this;
        }

        public Criteria andProductInviteAwardIn(List<String> values) {
            addCriterion("product_invite_award in", values, "productInviteAward");
            return (Criteria) this;
        }

        public Criteria andProductInviteAwardNotIn(List<String> values) {
            addCriterion("product_invite_award not in", values, "productInviteAward");
            return (Criteria) this;
        }

        public Criteria andProductInviteAwardBetween(String value1, String value2) {
            addCriterion("product_invite_award between", value1, value2, "productInviteAward");
            return (Criteria) this;
        }

        public Criteria andProductInviteAwardNotBetween(String value1, String value2) {
            addCriterion("product_invite_award not between", value1, value2, "productInviteAward");
            return (Criteria) this;
        }

        public Criteria andProductTalentAwardIsNull() {
            addCriterion("product_talent_award is null");
            return (Criteria) this;
        }

        public Criteria andProductTalentAwardIsNotNull() {
            addCriterion("product_talent_award is not null");
            return (Criteria) this;
        }

        public Criteria andProductTalentAwardEqualTo(String value) {
            addCriterion("product_talent_award =", value, "productTalentAward");
            return (Criteria) this;
        }

        public Criteria andProductTalentAwardNotEqualTo(String value) {
            addCriterion("product_talent_award <>", value, "productTalentAward");
            return (Criteria) this;
        }

        public Criteria andProductTalentAwardGreaterThan(String value) {
            addCriterion("product_talent_award >", value, "productTalentAward");
            return (Criteria) this;
        }

        public Criteria andProductTalentAwardGreaterThanOrEqualTo(String value) {
            addCriterion("product_talent_award >=", value, "productTalentAward");
            return (Criteria) this;
        }

        public Criteria andProductTalentAwardLessThan(String value) {
            addCriterion("product_talent_award <", value, "productTalentAward");
            return (Criteria) this;
        }

        public Criteria andProductTalentAwardLessThanOrEqualTo(String value) {
            addCriterion("product_talent_award <=", value, "productTalentAward");
            return (Criteria) this;
        }

        public Criteria andProductTalentAwardLike(String value) {
            addCriterion("product_talent_award like", value, "productTalentAward");
            return (Criteria) this;
        }

        public Criteria andProductTalentAwardNotLike(String value) {
            addCriterion("product_talent_award not like", value, "productTalentAward");
            return (Criteria) this;
        }

        public Criteria andProductTalentAwardIn(List<String> values) {
            addCriterion("product_talent_award in", values, "productTalentAward");
            return (Criteria) this;
        }

        public Criteria andProductTalentAwardNotIn(List<String> values) {
            addCriterion("product_talent_award not in", values, "productTalentAward");
            return (Criteria) this;
        }

        public Criteria andProductTalentAwardBetween(String value1, String value2) {
            addCriterion("product_talent_award between", value1, value2, "productTalentAward");
            return (Criteria) this;
        }

        public Criteria andProductTalentAwardNotBetween(String value1, String value2) {
            addCriterion("product_talent_award not between", value1, value2, "productTalentAward");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNull() {
            addCriterion("delete_flag is null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNotNull() {
            addCriterion("delete_flag is not null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagEqualTo(Byte value) {
            addCriterion("delete_flag =", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotEqualTo(Byte value) {
            addCriterion("delete_flag <>", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThan(Byte value) {
            addCriterion("delete_flag >", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThanOrEqualTo(Byte value) {
            addCriterion("delete_flag >=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThan(Byte value) {
            addCriterion("delete_flag <", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThanOrEqualTo(Byte value) {
            addCriterion("delete_flag <=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIn(List<Byte> values) {
            addCriterion("delete_flag in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotIn(List<Byte> values) {
            addCriterion("delete_flag not in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagBetween(Byte value1, Byte value2) {
            addCriterion("delete_flag between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotBetween(Byte value1, Byte value2) {
            addCriterion("delete_flag not between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("update_time is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("update_time is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("update_time =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("update_time <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("update_time >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("update_time >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("update_time <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("update_time <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("update_time in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("update_time not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("update_time between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("update_time not between", value1, value2, "updateTime");
            return (Criteria) this;
        }
    }

    /**
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}