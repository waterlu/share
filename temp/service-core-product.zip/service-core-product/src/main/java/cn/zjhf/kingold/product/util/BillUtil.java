package cn.zjhf.kingold.product.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

/**
 * @author lutiehua
 * @date 2018/3/8
 */
public class BillUtil {

    /**
     * 产生单据编号
     *
     * @param prefix
     * @return
     */
    public static String generateBillCode(String prefix) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        Date now = new Date();
        String timeString = dateFormat.format(now);
        int randomNumber = RandUtil.getRandomNumbers(10000);
        String postfix = String.format("%04d", randomNumber);
        String billCode = prefix + timeString + postfix;
        return billCode;
    }

    /**
     * 产生UUID
     *
     * @return
     */
    public static String generateUUID() {
        return UUID.randomUUID().toString().replaceAll("-", "");
    }

}
