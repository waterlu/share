package cn.zjhf.kingold.product.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.product.persistence.dao.ProductChangeLogMapper;
import cn.zjhf.kingold.product.service.IProductChangeLogService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Created by Xiaody on 17/4/20.
 */
@Service
public class ProductChangeLogServiceImpl implements IProductChangeLogService {

    private static Logger LOGGER = LoggerFactory.getLogger(ProductChangeLogServiceImpl.class);

    @Autowired
    private ProductChangeLogMapper productChangeLogMapper;

    @Override
    public Long insert(Map map) throws BusinessException {
        productChangeLogMapper.insert(map);
        return (Long) map.get("productChangeLogID");
    }

    @Override
    public List<Map> getList(Map map) throws BusinessException {
        return productChangeLogMapper.getList(map);
    }

    @Override
    public Integer getCount(Map map) throws BusinessException {
        return productChangeLogMapper.getCount(map);
    }
}
