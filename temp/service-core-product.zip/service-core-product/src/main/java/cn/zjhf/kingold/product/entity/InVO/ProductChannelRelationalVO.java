package cn.zjhf.kingold.product.entity.InVO;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.product.entity.ProductChannelRelational;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.Date;

@ApiModel(value = "ProductChannelRelationalVO", description = "渠道产品关联表")
public class ProductChannelRelationalVO extends ParamVO {

    @ApiModelProperty(required = true, value = "channel_uuid 渠道方UUID")
    @NotEmpty
    @Size(min = 1, max = 32)
    private String channelUuid;

    @ApiModelProperty(required = false, value = "商户号码(渠道商户号) （如：89890112）")
    @Size(min = 1, max = 18)
    private String merchantNum;

    @ApiModelProperty(required = false, value = "APP名称")
    @Size(min = 1, max = 30)
    private String channelAppName;

    @ApiModelProperty(required = false, value = "内外部渠道（1.内部渠道 2 外部渠道 默认外部渠道）")
    @Size(min = 1, max = 2)
    private String interExterChannel;

    @ApiModelProperty(required = true, value = "UUID主键")
    @NotEmpty
    @Size(min = 1, max = 32)
    private String productUuid;

    @ApiModelProperty(required = true, value = "产品编码")
    @NotEmpty
    @Size(min = 1, max = 16)
    private String productCode;

    @ApiModelProperty(required = true, value = "产品简称")
    @NotEmpty
    @Size(min = 1, max = 40)
    private String productAbbrName;

    @ApiModelProperty(required = true, value = "产品上架状态  1未上架，2已上架，3已下架")
    private int productOnStatus;

    @ApiModelProperty(required = true, value = "产品状态  1预热中，2募集中，3已售罄，4已成立，5封闭期，6存续期，7已结束，8已到期，9已兑付")
    private int productStatus;

    @ApiModelProperty(required = true, value = "产品类型（PRIF私募基金FIXI固定收益理财）")
    @NotEmpty
    @Size(min = 1, max = 16)
    private String productType;

    @ApiModelProperty(required = true, value = "渠道手续费")
    @NotEmpty
    private double channelChargeRate;

    @ApiModelProperty(required = false, value = "签名")
    @Size(min = 1, max = 128)
    private String signature;

    @ApiModelProperty(required = true, value = "删除标记 0未删除，1已删除")
    private int deleteFlag;

    @ApiModelProperty(required = true, value = "分配时间")
    private Date createTime;

    @ApiModelProperty(required = true, value = "")
    private Date updateTime;

    private Date productEstablishmentDate;

    @ApiModelProperty(required = true, value = "短信发送标识 1.允许、2、不允许")
    private Integer wechatSendMark;


    public ProductChannelRelationalVO() {
    }

    public ProductChannelRelationalVO(ProductChannelRelational productChannelRelational) {
        this.channelUuid = productChannelRelational.getChannelUuid();
        this.merchantNum = productChannelRelational.getMerchantNum();
        this.channelAppName = productChannelRelational.getChannelAppName();
        this.interExterChannel = productChannelRelational.getInterExterChannel();
        this.productUuid = productChannelRelational.getProductUuid();
        this.productCode = productChannelRelational.getProductCode();
        this.productAbbrName = productChannelRelational.getProductAbbrName();
        this.productType = productChannelRelational.getProductType();
        this.channelChargeRate = productChannelRelational.getChannelChargeRate().doubleValue();
        this.signature = productChannelRelational.getSignature();
        this.deleteFlag = productChannelRelational.getDeleteFlag();
        this.createTime = productChannelRelational.getCreateTime();
        this.updateTime = productChannelRelational.getUpdateTime();
        this.productEstablishmentDate = productChannelRelational.getProductEstablishmentDate();
        this.wechatSendMark = productChannelRelational.getWechatSendMark();
    }

    public String getChannelUuid() {
        return channelUuid;
    }

    public void setChannelUuid(String channelUuid) {
        this.channelUuid = channelUuid;
    }

    public String getMerchantNum() {
        return merchantNum;
    }

    public void setMerchantNum(String merchantNum) {
        this.merchantNum = merchantNum;
    }

    public String getChannelAppName() {
        return channelAppName;
    }

    public void setChannelAppName(String channelAppName) {
        this.channelAppName = channelAppName;
    }

    public String getInterExterChannel() {
        return interExterChannel;
    }

    public void setInterExterChannel(String interExterChannel) {
        this.interExterChannel = interExterChannel;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductAbbrName() {
        return productAbbrName;
    }

    public void setProductAbbrName(String productAbbrName) {
        this.productAbbrName = productAbbrName;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public double getChannelChargeRate() {
        return channelChargeRate;
    }

    public void setChannelChargeRate(double channelChargeRate) {
        this.channelChargeRate = channelChargeRate;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public int getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(int deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public ProductChannelRelational get() {
        ProductChannelRelational productChannelRelational = new ProductChannelRelational();
        productChannelRelational.setChannelUuid(channelUuid);
        productChannelRelational.setMerchantNum(merchantNum);
        productChannelRelational.setChannelAppName(channelAppName);
        productChannelRelational.setInterExterChannel(interExterChannel);
        productChannelRelational.setProductUuid(productUuid);
        productChannelRelational.setProductCode(productCode);
        productChannelRelational.setProductAbbrName(productAbbrName);
        productChannelRelational.setProductType(productType);
        productChannelRelational.setChannelChargeRate(new BigDecimal(channelChargeRate));
        productChannelRelational.setSignature(signature);
        productChannelRelational.setDeleteFlag(new Integer(deleteFlag).byteValue());
        productChannelRelational.setCreateTime(createTime);
        productChannelRelational.setUpdateTime(updateTime);
        productChannelRelational.setProductEstablishmentDate(productEstablishmentDate);
        productChannelRelational.setWechatSendMark(wechatSendMark);
        return productChannelRelational;
    }

    public int getProductOnStatus() {
        return productOnStatus;
    }

    public void setProductOnStatus(int productOnStatus) {
        this.productOnStatus = productOnStatus;
    }

    public int getProductStatus() {
        return productStatus;
    }

    public void setProductStatus(int productStatus) {
        this.productStatus = productStatus;
    }

    public Date getProductEstablishmentDate() {
        return productEstablishmentDate;
    }

    public void setProductEstablishmentDate(Date productEstablishmentDate) {
        this.productEstablishmentDate = productEstablishmentDate;
    }

    public Integer getWechatSendMark() {
        return wechatSendMark;
    }

    public void setWechatSendMark(Integer wechatSendMark) {
        this.wechatSendMark = wechatSendMark;
    }
}
