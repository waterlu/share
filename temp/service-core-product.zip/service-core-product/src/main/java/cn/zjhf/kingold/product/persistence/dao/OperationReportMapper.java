package cn.zjhf.kingold.product.persistence.dao;

import cn.zjhf.kingold.product.entity.OperationReport;
import cn.zjhf.kingold.product.entity.OperationReportExample;
import cn.zjhf.kingold.product.entity.OperationReportKey;
import java.util.List;
import java.util.Map;

import cn.zjhf.kingold.product.util.ReportUtils;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface OperationReportMapper {
    long countByExample(OperationReportExample example);

    int deleteByExample(OperationReportExample example);

    int deleteByPrimaryKey(OperationReportKey key);

    int insert(OperationReport record);

    int insertSelective(OperationReport record);

    List<OperationReport> selectByExample(OperationReportExample example);

    OperationReport selectByPrimaryKey(OperationReportKey key);
	
    @Select("${condition}")
    List<Map> lstReportData(ReportUtils condition);

    int updateByExampleSelective(@Param("record") OperationReport record, @Param("example") OperationReportExample example);

    int updateByExample(@Param("record") OperationReport record, @Param("example") OperationReportExample example);

    int updateByPrimaryKeySelective(OperationReport record);

    int updateByPrimaryKey(OperationReport record);
}