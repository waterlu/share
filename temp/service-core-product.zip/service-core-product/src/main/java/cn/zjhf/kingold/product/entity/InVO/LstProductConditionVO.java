package cn.zjhf.kingold.product.entity.InVO;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.product.util.DataUtils;
import cn.zjhf.kingold.product.util.TwoTuple;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangyijie on 2017/7/12.
 */
@ApiModel(value = "LstProductConditionVO", description = "产品查询条件")
public class LstProductConditionVO extends ParamVO {
    @ApiModelProperty(required = true, value = "产品期限集合,单位(天), 格式x1-y1,x2-y2")
    private String productTerms;

    @ApiModelProperty(required = true, value = "产品集合(多个同时存在用$$分隔)")
    private String productuuIds;

    @ApiModelProperty(required = true, value = "商户号")
    private String merchantNum;

    private Integer startRow;

    private Integer pageSize;

    public String getProductTerms() {
        return productTerms;
    }

    public void setProductTerms(String productTerms) {
        this.productTerms = productTerms;
    }

    public String getProductuuIds() {
        return productuuIds;
    }

    public void setProductuuIds(String productuuIds) {
        this.productuuIds = productuuIds;
    }

    public List<String> getProductuuIdItems() {
        return DataUtils.split(productuuIds);
    }

    public Integer getStartRow() {
        return startRow;
    }

    public void setStartRow(Integer startRow) {
        this.startRow = startRow;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public List<TwoTuple<Integer, Integer>> lstProductTerms() {
        List<TwoTuple<Integer, Integer>> listItems = new ArrayList<TwoTuple<Integer, Integer>>();
        if(StringUtils.isEmpty(productTerms)){
            return  listItems;
        }
        List<String> terms = DataUtils.split(productTerms, ",");

        for(String term : terms) {
            List<String> termPair = DataUtils.split(term, "-");
            if(termPair.size() > 1) {
                try {
                    Integer startTerm = Integer.parseInt(termPair.get(0).trim());
                    Integer endTerm = Integer.parseInt(termPair.get(1).trim());
                    listItems.add(new TwoTuple<Integer, Integer>(startTerm, endTerm));
                }catch(Exception e) {
                    continue;
                }
            }
        }

        return listItems;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(getTraceID()) + ", ");
        sb.append("productTerms:" + DataUtils.toString(productTerms) + ", ");
        sb.append("merchantNum:" + DataUtils.toString(merchantNum) + ", ");
        sb.append("productuuIds:" + DataUtils.toString(productuuIds));
        return sb.toString();
    }

    public String getMerchantNum() {
        return merchantNum;
    }

    public void setMerchantNum(String merchantNum) {
        this.merchantNum = merchantNum;
    }
}
