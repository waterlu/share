package cn.zjhf.kingold.product.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.product.constant.BizDefine;
import cn.zjhf.kingold.product.constant.ProductConstants;
import cn.zjhf.kingold.product.constant.ProductStatusMsg;
import cn.zjhf.kingold.product.constant.URL;
import cn.zjhf.kingold.product.dto.ProductRemainDTO;
import cn.zjhf.kingold.product.entity.*;
import cn.zjhf.kingold.product.entity.InVO.LstProductChannelRelationalConditionVO;
import cn.zjhf.kingold.product.entity.InVO.LstProductConditionVO;
import cn.zjhf.kingold.product.entity.InVO.ProductChannelRelationalVO;
import cn.zjhf.kingold.product.entity.OutVO.ProductChannelRelationalItemListVO;
import cn.zjhf.kingold.product.entity.enums.ProductTypeEnum;
import cn.zjhf.kingold.product.exception.*;
import cn.zjhf.kingold.product.lock.DistributedLock;
import cn.zjhf.kingold.product.persistence.dao.*;
import cn.zjhf.kingold.product.persistence.mq.message.ProductMessage;
import cn.zjhf.kingold.product.persistence.mq.producer.ProductOnSaleProducer;
import cn.zjhf.kingold.product.service.IProductService;
import cn.zjhf.kingold.product.service.IProductTransaction;
import cn.zjhf.kingold.product.util.*;
import cn.zjhf.kingold.service_consumer.service.TradeServiceConsumer;
import com.alibaba.fastjson.JSON;
import com.google.common.collect.Maps;
import com.netflix.discovery.converters.Auto;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.util.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * @author Xiaody
 * @date 17/4/12
 */
@Service
public class ProductServiceImpl implements IProductService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProductServiceImpl.class);

    @Autowired
    private ProductMapper productMapper;

    @Autowired
    private ProductPrivateFundMapper privateFundMapper;

    @Autowired
    private ProductFixedIncomeMapper fixedIncomeMapper;

    @Autowired
    private ProductProgressMapper progressMapper;

    @Autowired
    private ProductChangeLogMapper productChangeLogMapper;

    @Autowired
    private ProductChannelRelationalMapper productChannelRelationalMapper;

    @Autowired
    private ProductOnSaleProducer productOnSaleProducer;

    @Autowired
    private ProductRewardSetMapper productRewardSetMapper;

    @Autowired
    private TradeServiceConsumer tradeServiceConsumer;

    @Autowired
    private StringRedisTemplate redisTemplate;

    @Autowired
    private ProductRaiseMapper productRaiseMapper;

    @Autowired
    private ProductProgressMapper productProgressMapper;

    @Autowired
    private DistributedLock redisLock;

    @Autowired
    private IProductTransaction productTransaction;

    /**
     * 创建产品信息，根据产品类型分别对应创建私募产品和固收产品
     *
     * @param map
     * @return
     * @throws BusinessException
     */
    @Override
    @Transactional
    public String insert(Map map) throws BusinessException {
        String productUuid = UUID.randomUUID().toString().replace("-", "");
        map.put("productUuid", productUuid);
//        map.put("productCode", generateProductCode((String) map.get("productType")));
        //处理产品需要处理的字段
        //handle_product(map);
        //设置默认产品操作类型为1（创建产品）
        map.put("productChangeType", 1);
        //插入产品修改日志表
        insertProductChangeLog(map, null);
        if (StringUtils.equals(ProductTypeEnum.PRIVATE_FUND.getCode(), (String) map.get("productType"))) {
            map.put("productStatus", 1);
            productMapper.insert(map);
            privateFundMapper.insert(map);
            progressMapper.insert(map);
            productRewardSetMapper.insertSelective(map);
        } else if (StringUtils.equals(ProductTypeEnum.FIXED_INCOME.getCode(), (String) map.get("productType"))) {
            map.put("productStatus", ProductConstants.PRODUCT_STATUS_UNCONFIRMED);
            productMapper.insert(map);
            fixedIncomeMapper.insert(map);
            progressMapper.insert(map);
            productRewardSetMapper.insertSelective(map);
        } else {
            throw new BusinessException(ProductStatusMsg.PRODUCT_TYPR_WRONG_CODE, ProductStatusMsg.PRODUCT_TYPE_WRONG_MSG, true);
        }
        return (String) map.get("productUuid");
    }

    /**
     * 根据产品uuid获取产品主表信息
     *
     * @param productUuid
     * @return
     * @throws BusinessException
     */
    @Override
    public Map get(String productUuid) throws BusinessException {
        return productMapper.get(productUuid);
    }

    /**
     * 根据产品uuid获取产品主表信息和募集信息
     *
     * @param productUuid
     * @return
     * @throws BusinessException
     */
    @Override
    public Map getProductProgress(String productUuid) throws BusinessException {
        return productMapper.getProductProgress(productUuid);
    }

    /**
     * 更新产品信息
     *
     * @param map
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void update(Map map) throws BusinessException {
        Map product = getProductProgress(map.get("productUuid").toString());
        map.put("productType", product.get("productType"));
//        checkUpdate(map, product);
        //插入产品修改日志表
        insertProductChangeLog(map, product);

        if (map.containsKey("productIssuerUuid") && Strings.isNotEmpty(map.get("productIssuerUuid").toString())) {
            Map<String, Object> tradeParam = new HashMap();
            tradeParam.put("userUuid", map.get("productIssuerUuid").toString());
            tradeParam.put("properties", "accountUuid$$accountType");
            ResponseResult responseResult = tradeServiceConsumer.get(URL.URL_ACCOUNT_GET_BAOFOO, tradeParam);
            if (responseResult.isSuccessful()) {
                Map account = tradeServiceConsumer.getData(responseResult, Map.class);
                if (account != null) {
                    map.put("payeeAccountUuid", account.get("accountUuid"));
                    map.put("payeeAccountType", account.get("accountType"));
                }
            }else{
                throw new BusinessException(responseResult.getCode(),responseResult.getMsg(),true);
            }
        }

        //如果是上下架写入上下架时间
        fillProductOpenTime(map);
        if (map.get("productChangeType") != null && map.get("productChangeType").equals(2)) {
            if (StringUtils.equals(ProductTypeEnum.PRIVATE_FUND.getCode(), map.get("productType").toString())) {
                productMapper.update(map);
                privateFundMapper.update(map);
                progressMapper.update(map);
                productRewardSetMapper.update(map);
            } else if (StringUtils.equals(ProductTypeEnum.FIXED_INCOME.getCode(), map.get("productType").toString())) {
                productMapper.update(map);
                fixedIncomeMapper.update(map);
                progressMapper.update(map);
                productRewardSetMapper.update(map);
            } else {
                throw new BusinessException(ProductStatusMsg.PRODUCT_TYPR_WRONG_CODE, ProductStatusMsg.PRODUCT_TYPE_WRONG_MSG, true);
            }
        } else {
            //不是编辑更新，只更新状态
            if (StringUtils.equals(ProductTypeEnum.PRIVATE_FUND.getCode(), map.get("productType").toString())) {
                productMapper.updateStatus(map);
                privateFundMapper.updateStatus(map);
                progressMapper.update(map);
            } else if (StringUtils.equals(ProductTypeEnum.FIXED_INCOME.getCode(), map.get("productType").toString())) {
                LOGGER.info(DataUtils.toString(map));
                productMapper.updateStatus(map);
                fixedIncomeMapper.updateStatus(map);
                progressMapper.update(map);
            } else {
                throw new BusinessException(ProductStatusMsg.PRODUCT_TYPR_WRONG_CODE, ProductStatusMsg.PRODUCT_TYPE_WRONG_MSG, true);
            }
        }
    }

    /**
     * 根据条件获取产品列表
     *
     * @param map
     * @return
     * @throws BusinessException
     */
    @Override
    public List<Map> getList(Map map) throws BusinessException {
        return productMapper.getList(map);
    }

    /**
     * 根据条件获取产品数量
     *
     * @param map
     * @return
     * @throws BusinessException
     */
    @Override
    public Integer getCount(Map map) throws BusinessException {
        return productMapper.getCount(map);
    }

    /**
     * 通过产品uuid获取私募产品信息
     *
     * @param productUuid
     * @return
     * @throws BusinessException
     */
    @Override
    public Map getPrivateFund(String productUuid) throws BusinessException {
        return productMapper.getPrivateFund(productUuid);
    }

    /**
     * 通过产品uuid获取固收产品信息
     *
     * @param productUuid
     * @return
     * @throws BusinessException
     */
    @Override
    public Map getFixedIncome(String productUuid) throws BusinessException {
        Map product = productMapper.getFixedIncome(productUuid);
        dealProductReward(product);
        return product;
    }

    /**
     * 用户购买成功修改产品募集金额
     *
     * @param productUuid
     * @param amount
     * @throws BusinessException
     */
    @Override
    public void updateAccumulation(String productUuid, Double amount) throws BusinessException {
        progressMapper.updateAccumulation(productUuid, amount);
    }

    @Override
    public List<Map> getPrivateFundList(Map map) throws BusinessException {
        return productMapper.getPrivateFundList(map);
    }

    /**
     * 根据条件反查产品列表
     *
     * @param lstCondition
     * @return
     * @throws BusinessException
     */
    @Override
    public List<Map> lstByCondition(LstProductConditionVO lstCondition) throws BusinessException {
        List<Map> results;

        String sql = "SELECT pro.product_uuid AS productUuid, pro.product_abbr_name AS productAbbrName, pro.vip_flag AS vipFlag, "
                + "pro_fixed.annual_interest_rate AS annualInterestRate, pro.product_period  AS productPeriod, "
                + "pro_fixed.coupon_interest_rate AS couponInterestRate "
                + "FROM product pro, product_fixed_income pro_fixed "
                + "WHERE pro.product_uuid = pro_fixed.product_uuid "
                + " AND pro.product_status = 2 and pro.product_on_status = 2 ";

        if (DataUtils.isNotEmpty(lstCondition.getMerchantNum())) {
            sql += " AND pro.product_uuid IN (SELECT product_uuid FROM product_channel_relational WHERE merchant_num =" + SQLUtils.toSQLStr(lstCondition.getMerchantNum()) + ")";
        }

        String orderBy = " ORDER BY pro.product_period ASC ";
        String page = "";
        if (lstCondition.getPageSize() != null && lstCondition.getPageSize() != 0 && lstCondition.getStartRow() != null) {
            page = " limit " + lstCondition.getPageSize() + " offset " + lstCondition.getStartRow();
        }

        List<String> productIds = lstCondition.getProductuuIdItems();

        if (productIds.size() > 0) {
            String productCodi = " and  pro.product_uuid IN (" + SQLUtils.stringListToSql(productIds) + ")";

            String tmpSql = sql;
            tmpSql += productCodi;
            tmpSql += orderBy;
            tmpSql += page;
            LOGGER.info(tmpSql);

            results = productMapper.lstByCondition(new QueryUtils(tmpSql));
        } else {
            List<TwoTuple<Integer, Integer>> tuples = lstCondition.lstProductTerms();
            String productCodi = "";
            if (tuples.size() > 0) {
                productCodi = " and (";
                for (TwoTuple<Integer, Integer> tuple : tuples) {
                    productCodi += " pro.product_period BETWEEN " + tuple.first + " AND " + tuple.second + " or";
                }
                productCodi = productCodi.substring(0, productCodi.length() - 3) + " )";
            }
            String tmpSql = sql;
            tmpSql += productCodi;
            tmpSql += orderBy;
            tmpSql += page;
            LOGGER.info(tmpSql);
            results = productMapper.lstByCondition(new QueryUtils(tmpSql));
        }

        return results;
    }

    @Override
    public Integer countByCondition(LstProductConditionVO lstCondition) throws BusinessException {
        Integer count;
        String countSql = "select count(*) from product pro, product_fixed_income pro_fixed "
                + " WHERE pro.product_uuid = pro_fixed.product_uuid  "
                + " AND pro.product_status = 2 and pro.product_on_status = 2 ";

        if (DataUtils.isNotEmpty(lstCondition.getMerchantNum())) {
            countSql += " AND pro.product_uuid IN (SELECT product_uuid FROM product_channel_relational WHERE merchant_num =" + SQLUtils.toSQLStr(lstCondition.getMerchantNum()) + ")";
        }

        List<String> productIds = lstCondition.getProductuuIdItems();

        if (productIds.size() > 0) {
            String productCodi = " and pro.product_uuid IN (" + SQLUtils.stringListToSql(productIds) + ")";

            String tmpSql = countSql;
            tmpSql += productCodi;
            LOGGER.info(tmpSql);

            count = productMapper.countByCondition(new QueryUtils(tmpSql));
        } else {
            List<TwoTuple<Integer, Integer>> tuples = lstCondition.lstProductTerms();
            String productCodi = "";
            if (tuples.size() > 0) {
                productCodi = " and (";
                for (TwoTuple<Integer, Integer> tuple : tuples) {
                    productCodi += " pro.product_period BETWEEN " + tuple.first + " AND " + tuple.second + " or";

                }
                productCodi = productCodi.substring(0, productCodi.length() - 3) + ")";
            }
            String tmpSql = countSql;
            tmpSql += productCodi;
            LOGGER.info(tmpSql);
            count = productMapper.countByCondition(new QueryUtils(tmpSql));
        }
        return count;
    }

    @Override
    public Integer getPrivateFundCount(Map map) throws BusinessException {
        return productMapper.getPrivateFundCount(map);
    }

    /**
     * 检查是否展示新手标
     *
     * @param map
     * @return true 展示，FALSE 不展示
     */
    private boolean checkIsGetNoviceLabelProduct(Map map) {
        boolean isGetNoviceLabelProduct = true;
        //有userUuid，并且该用户有有效的投资记录，则不可再取新手标产品
        if (map.containsKey("userUuid") && DataUtils.isNotEmpty(productMapper.havaValidOrder((String) map.get("userUuid")))) {
            isGetNoviceLabelProduct = false;
        } else {
            map.put("isGetNoviceLabelProduct", isGetNoviceLabelProduct);
        }

        return isGetNoviceLabelProduct;
    }

    @Override
    public List<Map> getFixedIncomeList(Map map) throws BusinessException {
        if (!map.containsKey("operateFlag") && map.containsKey("productStatus")) {
            int status = new BizParam(map).getInt("productStatus");
            if (DataUtils.isContain(status, ProductConstants.PRODUCT_STATUS_UNCONFIRMED, ProductConstants.PRODUCT_STATUS_ABORT)) {
                LOGGER.info("前端不可取出状态为未确认和已废弃的产品");
                return new ArrayList<Map>();
            }
        }

        LOGGER.info(DataUtils.toString(map));
        List<Map> productList = productMapper.getFixedIncomeList(map);
        dealNoviceProduct(map, productList);
        dealProductReward(productList);
        return productList;
    }

    @Override
    public List<Map> getVipFixedIncome() throws BusinessException {
        return productMapper.getVipFixedIncomeList();
    }

    private void dealNoviceProduct(Map param, List<Map> productList) {
        boolean isFromFrontEndSystem = BizDefine.isFromFrontEndSystem(param);
        boolean isGetNoviceLabelProduct = checkIsGetNoviceLabelProduct(param);

        //来自前端并且不展示新手标的产品，则添加过滤标志
        if (isFromFrontEndSystem && (!isGetNoviceLabelProduct)) {
            param.put("passNoviceProduct", true);
        }

        //修正产品列表
        if (isFromFrontEndSystem) {
            TreeMap<String, List<Map>> noviceLabelProductMap = new TreeMap<String, List<Map>>();

            //Step1 先挑选出新手标的产品
            Iterator<Map> it = productList.iterator();
            while (it.hasNext()) {
                Map productInfo = it.next();
                if (productInfo.containsKey("productLabel")) {
                    String productLabel = (String) productInfo.get("productLabel");
                    if (productLabel.contains("1")) {
                        //设置新手标标记
                        productInfo.put("isNoviceLabelProduct", true);

                        //确保没有上架的话排到已上架新手标的前面
                        String openTime = "0000";
                        if (productInfo.containsKey("productOpenTime") && DataUtils.isNotEmpty((String) productInfo.get("productOpenTime"))) {
                            openTime = productInfo.get("productOpenTime").toString();
                        }

                        if (!noviceLabelProductMap.containsKey(openTime)) {
                            noviceLabelProductMap.put(openTime, new ArrayList<Map>());
                        }
                        noviceLabelProductMap.get(openTime).add(productInfo);

                        it.remove();
                    }
                }
            }

            if (isGetNoviceLabelProduct) {
                List<Map> noviceLabelProductList = new ArrayList<Map>();
                NavigableMap<String, List<Map>> noviceLabelProductMap1 = noviceLabelProductMap.descendingMap();
                for (Map.Entry<String, List<Map>> entry : noviceLabelProductMap1.entrySet()) {
                    noviceLabelProductList.addAll(entry.getValue());
                }
                productList.addAll(0, noviceLabelProductList);
            }
        }
    }

    private void dealProductReward(Map product) throws BusinessException {
        List<Map> productList = new ArrayList<>();
        productList.add(product);
        dealProductReward(productList);
    }

    @Override
    public void dealProductReward(List<Map> productList) throws BusinessException {
        if (CollectionUtils.isEmpty(productList)) {
            return;
        }
        List<String> productUuidList = new ArrayList<>();
        for (Map product : productList) {
            productUuidList.add(MapParamUtils.getStringInMap(product, "productUuid"));
        }
        Map<String, Object> params = new HashMap<>();
        params.put("productUuidList", productUuidList);
        List<Map> rewardList = productRewardSetMapper.getList(params);
        Map<String, Map> rewardMap = Maps.uniqueIndex(rewardList,
                reward -> MapParamUtils.getStringInMap(reward, "productUuid"));
        for (Map product : productList) {
            String productUuid = MapParamUtils.getStringInMap(product, "productUuid");
            Map reward = rewardMap.get(productUuid);
            if (reward == null || !reward.containsKey("productTalentAward") ) {
                continue;
            }
            List<Map> splitList = (List<Map>)reward.get("productTalentAward");
            double max = 0;
            for (Map split : splitList) {
                double awardRate = MapParamUtils.getDoubleInMap(split, "percent");
                max = awardRate > max ? awardRate : max;
            }
            product.put("talentAwardMaxRate", max);

        }
    }

    @Override
    public Integer getFixedIncomeCount(Map map) throws BusinessException {
        boolean isFromFrontEndSystem = BizDefine.isFromFrontEndSystem(map);
        boolean isGetNoviceLabelProduct = checkIsGetNoviceLabelProduct(map);

        //来自前端并且不展示新手标的产品，则添加过滤标志
        if (isFromFrontEndSystem && (!isGetNoviceLabelProduct)) {
            map.put("passNoviceProduct", true);
        }

        LOGGER.info(DataUtils.toString(map));
        return productMapper.getFixedIncomeCount(map);
    }

    @Override
    public void topUpdate(Map map) throws BusinessException {
        Map product = get(map.get("productUuid").toString());
        map.put("productType", product.get("productType"));
        //插入产品修改日志表
        insertProductChangeLog(map, product);
        productMapper.topUpdate(map);
    }

    @Override
    public List<Map> getProductRewardList(Map map) throws BusinessException {
       if(map.get("isRefresh") != null && (Boolean) map.get("isRefresh")){
           return productMapper.getRewardList(map);
       }
        return productRewardSetMapper.getRewardList(map);
    }

    @Override
    public Integer getProductRewardCount(Map map) throws BusinessException {
        return productRewardSetMapper.getRewardCount(map);
    }

    /**
     * 插入产品修改日志表
     *
     * @param map
     * @throws BusinessException
     */
    private void insertProductChangeLog(Map map, Map product) throws BusinessException {
        Integer productChangeType = MapParamUtils.getIntInMap(map, "productChangeType");
        if (productChangeType == null || productChangeType == 0) {
            return;
        }

        if (productChangeType == 1) {
            map.put("productChangeContent", "创建产品");
        } else {
            if (product != null) {
                //状态更改productName为null，无法写入日志。
                if (map.get("productName") == null) {
                    map.put("productName", product.get("productName"));
                }
                switch (productChangeType) {
                    case 2:
                        map.put("productChangeContent", "修改产品");
                        break;
                    case 3:
                        Integer productOnStatus = MapParamUtils.getIntInMap(map, "productOnStatus");
                        map.put("productChangeContent", "[上下架产品]" + ProductConstants.PRODUCT_ON_STATUS.get(product.get("productOnStatus"))
                                + "->" + ProductConstants.PRODUCT_ON_STATUS.get(productOnStatus));
                        break;
                    case 4:
                        Integer productStatus = MapParamUtils.getIntInMap(map, "productStatus");
                        map.put("productChangeContent", "[更改状态]" + ProductConstants.getProductStatusName((int) product.get("productStatus"))
                                + "->" + ProductConstants.getProductStatusName(productStatus));
                        if (productStatus == ProductConstants.PRODUCT_STATUS_INTEREST || productStatus == ProductConstants.PRODUCT_STATUS_PRODUCTEND) {
                            map.put("createBy", "system");
                        }
                        break;
                    case 5:
                        DecimalFormat df = new DecimalFormat("#0.00");
                        map.put("productChangeContent", "[更新募集金额]" + df.format(new BigDecimal(product.get("productManual").toString())) + "->"
                                + df.format(new BigDecimal(map.get("productManual").toString())));
                        break;
                    case 6:
                        map.put("productChangeContent", "产品推荐");
                        break;
                    case 7:
                        map.put("productChangeContent", "产品置顶");
                        break;
                    case 8:
                        map.put("productChangeContent", "产品删除");
                        break;
                    default:
                        throw new BusinessException(ProductStatusMsg.PRODUCT_CHANGE_TYPE_WRONG_CODE,
                                ProductStatusMsg.PRODUCT_CHANGE_TYPE_WRONG_MSG, true);
                }
            }
        }
        productChangeLogMapper.insert(map);
    }


    private void checkUpdate(Map map, Map product) throws BusinessException {
        Integer productChangeType = MapParamUtils.getIntInMap(map, "productChangeType");
        if (productChangeType == null) {
            throw new BusinessException(ProductStatusMsg.PRODUCT_CHANGE_TYPE_WRONG_CODE,
                    ProductStatusMsg.PRODUCT_CHANGE_TYPE_WRONG_MSG, true);
        }
        switch (productChangeType) {
        }
    }


    /**
     * 如果是上下架写入上下架时间
     *
     * @param map
     * @throws BusinessException
     */
    private void fillProductOpenTime(Map map) throws BusinessException {
        if (MapParamUtils.getIntInMap(map, "productChangeType") == 3) {
            if (MapParamUtils.getIntInMap(map, "productOnStatus") == 2) {
                map.put("productOpenTime", new Date());
            }
            if (MapParamUtils.getIntInMap(map, "productOnStatus") == 3) {
                map.put("productCloseTime", new Date());
            }
        }
    }


    /**
     * 添加关联关系
     *
     * @param relationalInfo
     * @throws BusinessException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void addProductChannelRelational(ProductChannelRelationalVO relationalInfo) throws BusinessException {

        ProductChannelRelationalKey primaryKey = new ProductChannelRelationalKey();
        primaryKey.setChannelUuid(relationalInfo.getChannelUuid());
        primaryKey.setChannelUuid(relationalInfo.getProductUuid());
        productChannelRelationalMapper.deleteByPrimaryKey(primaryKey);

        relationalInfo.setUpdateTime(new Date());
        relationalInfo.setDeleteFlag(0);
        relationalInfo.setCreateTime(new Date());
        int ret = productChannelRelationalMapper.insert(relationalInfo.get());
        if ("00000".equals(relationalInfo.getMerchantNum())) {
            ProductMessage productMessage = new ProductMessage();
            productMessage.setProductType(relationalInfo.getProductType());
            productMessage.setProductUuid(relationalInfo.getProductUuid());
            productMessage.setWechatSendMark(relationalInfo.getWechatSendMark());
            productOnSaleProducer.send(productMessage);
        }
        LOGGER.info("addProductChannelRelational result：" + ret);
    }

    /**
     * 查询关联关系列表
     *
     * @param lstCondition
     * @return
     * @throws BusinessException
     */
    @Override
    public ProductChannelRelationalItemListVO lstProductChannelRelationals(LstProductChannelRelationalConditionVO lstCondition) throws BusinessException {
        WhereCondition where = new WhereCondition();
        where.setLike("rela.channel_app_name", lstCondition.getChannelAppName());
        where.setCondi("rela.product_type", lstCondition.getProductType());
        if(lstCondition.getProductStatus()!=null){
            where.setCondi("pro.product_status", lstCondition.getProductStatus());
        }
        where.setCondi("rela.channel_uuid", lstCondition.getChannelUuid(), true);
        if(lstCondition.getProductOnStatus()!=null){
            where.setCondi("pro.product_on_status", lstCondition.getProductOnStatus(), true);
        }
        where.setBetween("rela.create_time", lstCondition.getBeginDate(), lstCondition.getEndDate());

        String sql = "select rela.channel_uuid, rela.merchant_num, rela.channel_app_name, rela.inter_exter_channel, " +
                "rela.product_uuid, rela.product_code, rela.product_abbr_name, rela.product_type, pro.product_status, pro.product_on_status, " +
                "rela.channel_charge_rate, rela.create_time, rela.wechat_send_mark  " +
                "from product_channel_relational rela, product pro " +
                "where rela.product_uuid = pro.product_uuid ";

        ProductChannelRelationalItemListVO relationalItemList = new ProductChannelRelationalItemListVO();
        String tmpSql = sql + where.toAnd();
        LOGGER.info(tmpSql);
        relationalItemList.setTotalCount(productChannelRelationalMapper.lstCommData(new QueryUtils(tmpSql)).size());

        List<ProductChannelRelationalVO> items = new ArrayList<ProductChannelRelationalVO>();
        where.setPage(lstCondition.getBeginSN(), lstCondition.getEndSN(), "rela.create_time");
        tmpSql = sql + where.toAnd();
        LOGGER.info(tmpSql);
        List<Map> lstDatas = productChannelRelationalMapper.lstCommData(new QueryUtils(tmpSql));
        for (Map map : lstDatas) {
            ProductChannelRelationalVO productChannelRelational = new ProductChannelRelationalVO();
            BizParam bizParam = new BizParam(map);

            productChannelRelational.setChannelUuid(bizParam.getString("channel_uuid"));
            productChannelRelational.setMerchantNum(bizParam.getString("merchant_num"));
            productChannelRelational.setChannelAppName(bizParam.getString("channel_app_name"));
            productChannelRelational.setInterExterChannel(bizParam.getString("inter_exter_channel"));

            productChannelRelational.setProductUuid(bizParam.getString("product_uuid"));
            productChannelRelational.setProductCode(bizParam.getString("product_code"));
            productChannelRelational.setProductAbbrName(bizParam.getString("product_abbr_name"));
            productChannelRelational.setProductType(bizParam.getString("product_type"));
            productChannelRelational.setProductStatus(bizParam.getInt("product_status"));
            productChannelRelational.setProductOnStatus(bizParam.getInt("product_on_status"));

            productChannelRelational.setChannelChargeRate(bizParam.getDouble("channel_charge_rate"));
            productChannelRelational.setCreateTime(bizParam.getDate("create_time"));
            productChannelRelational.setWechatSendMark(bizParam.getInt("wechat_send_mark"));

            items.add(productChannelRelational);
        }
        relationalItemList.setItems(items);

        return relationalItemList;
    }

    /**
     * 根据渠道的Uuid取得其相关联的产品
     *
     * @param channelUuid
     * @return
     * @throws BusinessException
     */
    @Override
    public List<String> lstRelationProducts(String channelUuid) throws BusinessException {
        List<String> productUuids = new ArrayList<String>();

        if (DataUtils.isNotEmpty(channelUuid)) {
            WhereCondition where = new WhereCondition();
            where.setCondi("channel_uuid", channelUuid);
            where.noDelete();

            String sql = "SELECT product_uuid FROM product_channel_relational " + where.toString();
            List<Map> lstDatas = productChannelRelationalMapper.lstCommData(new QueryUtils(sql));
            for (Map map : lstDatas) {
                BizParam bizParam = new BizParam(map);
                String productUuid = bizParam.getString("product_uuid");
                if (DataUtils.isNotEmpty(productUuid)) {
                    productUuids.add(productUuid);
                }
            }
        }
        return productUuids;
    }

    /**
     * 获取限制子产品集合
     *
     * @param map
     * @return
     * @throws BusinessException
     */
    @Override
    public List<Map> getFixedProducts(Map map) throws BusinessException {
        List<TwoTuple<Integer, Integer>> productPeriods = new ArrayList<>();
        String productTerms = (String) map.get("productPeriods");
        if (productTerms != null && !productTerms.equals("")) {
            List<String> terms = DataUtils.split(productTerms, ",");
            for (String term : terms) {
                List<String> termPair = DataUtils.split(term, "-");
                if (termPair.size() > 1) {
                    try {
                        Integer startTerm = Integer.parseInt(termPair.get(0).trim());
                        Integer endTerm = Integer.parseInt(termPair.get(1).trim());
                        productPeriods.add(new TwoTuple<Integer, Integer>(startTerm, endTerm));
                    } catch (Exception e) {
                        continue;
                    }
                }
            }
            map.put("productPeriods", productPeriods);
        }
        return productMapper.getFixedProducts(map);
    }

    /**
     * 获取定期产品和渠道信息
     */
    @Override
    public Map getFixedIncomeChannel(Map map) throws BusinessException {
        return productMapper.getFixedIncomeChannel(map);
    }

    /**
     * 获取渠道下不存在产品列表
     */
    @Override
    public List<Map> channelNonExistProductList(Map map) throws BusinessException {
        return productMapper.channelNonExistProductList(map);
    }

    /**
     * 根据条件获取产品数量
     *
     * @param map
     * @return
     * @throws BusinessException
     */
    @Override
    public Integer channelNonExistProductCount(Map map) throws BusinessException {
        return productMapper.channelNonExistProductCount(map);
    }
    /**
     * 通过产品uuid获取奖励明细
     * @param productUuid
     * @return
     * @throws BusinessException
     */
    @Override
    public ProductRewardSet getRewardByProductUuid(String productUuid)  throws BusinessException {
        return productRewardSetMapper.selectByProductUuid(productUuid);
    }

    @Override
    public List<Map> getProductTalentRewardList(Map map) throws BusinessException {
        return productRewardSetMapper.getProductTalentRewardList(map);
    }

    @Override
    public Integer getProductTalentRewardCount(Map map) throws BusinessException {
        return productRewardSetMapper.getProductTalentRewardCount(map);
    }

    @Override
    public void transferRewardData(Map map) throws BusinessException {
         productRewardSetMapper.insertSelective(map);
    }

    /**
     * 更新产品剩余募集额度
     * <p>先写入product_raise表，再更新product_progress表，两步都成功才提交</p>
     * <p>product_raise表记录明细，可用于回滚</p>
     *
     * @param productRemain
     * @return
     */
    @Override
    public int updateRaise(ProductRemainDTO productRemain) throws BusinessException {

        // 读取产品信息
        Map<String, Object> productMap = getFixedIncome(productRemain.getProductUuid());
        Product product = JSON.parseObject(JSON.toJSONString(productMap), Product.class);
        ProductFixedIncome fixedIncomeProduct = JSON.parseObject(JSON.toJSONString(productMap), ProductFixedIncome.class);

        // 判断产品状态
        if (product.getProductOnStatus().intValue() != ProductConstants.PRODUCT_SHELVES_ON) {
            // 产品已下架
            throw new ProductStatusException();
        }
        if (product.getProductStatus().intValue() != ProductConstants.PRODUCT_STATUS_RAISE) {
            // 产品已募集完成
            throw new ProductSaleStatusException();
        }

        // 分布式锁
        String productUuid = productRemain.getProductUuid();
        String userUuid = productRemain.getUserUuid();
        String key = String.format("lock:product-raise:%s:%s", productUuid, userUuid);
//        String key = String.format("lock:product-raise:%s", productUuid);

        // 锁定5秒钟
        long seconds = 5;
        int times = 50;
        int count = 0;
        int interval = 100;
        boolean locked = false;
        locked = redisLock.lock(key, seconds);
        while(!locked && count < times) {
            try {
                Thread.sleep(interval);
            } catch (InterruptedException e) {
                throw new LockException(key);
            }
            count++;
            locked = redisLock.lock(key, seconds);
        }

        if (!locked) {
            // 并发时没有抢到锁，失败
            LOGGER.error("没有抢到锁[{}]", key);
            throw new LockException(key);
        }

        try {
            // 订单金额
            BigDecimal amount = productRemain.getAmount();

            // 检查累计购买
            BigDecimal maxAmount = fixedIncomeProduct.getProductMaxInvestment();
            if (null != maxAmount && maxAmount.compareTo(BigDecimal.ZERO) > 0) {
                // 不设置上限时不检查
                ProductUserRaiseDO productUserRaiseDO = new ProductUserRaiseDO();
                productUserRaiseDO.setProductUuid(productUuid);
                productUserRaiseDO.setUserUuid(userUuid);
                BigDecimal totalRaiseAmount = productRaiseMapper.getUserTotalRaiseAmount(productUserRaiseDO);
                if (totalRaiseAmount.add(amount).compareTo(maxAmount) > 0) {
                    // 超过了最大投资金额
                    LOGGER.error("已投资{}元，加上本次投资{}元，超过投资上限标准{}元", totalRaiseAmount, amount, maxAmount);
                    throw new MaxInvestmentException();
                }
            }

            // 更新募集金额
            return productTransaction.updateRaise(productRemain);

        } finally {
            // 释放锁
            redisLock.unlock(key);
        }
    }

    /**
     * 补偿产品剩余募集额度
     *
     * @param productRemain
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int restoreRemain(ProductRemainDTO productRemain) throws BusinessException {
        // 逻辑删除产品募集日志
        ProductRaise productRaise = new ProductRaise();
        String updateUuid = BillUtil.generateUUID();
        productRaise.setOrderBillCode(productRemain.getOrderBillCode());
        productRaise.setUserUuid(productRemain.getUserUuid());
        productRaise.setProductUuid(productRemain.getProductUuid());
        productRaise.setUpdateUuid(updateUuid);
        int row = productRaiseMapper.restore(productRaise);
        if (row <= 0) {
            LOGGER.info("没有需要回滚的产品募集日志");
            return 0;
        }

        // 使用产品募集日志重新计算一遍剩余额度最安全，但是效率太低
        // 查询影响了多少数据
        BigDecimal updatedAmount = productRaiseMapper.getUpdatedInfo(updateUuid);
        LOGGER.info("逻辑删除产品募集金额总和[{}]元", updatedAmount);

        if (updatedAmount.compareTo(BigDecimal.ZERO) == 0) {
            LOGGER.info("没有需要回滚的交易流水");
            return 0;
        }

        ProductRaiseDO productRaiseDO = new ProductRaiseDO();
        productRaiseDO.setProductUuid(productRemain.getProductUuid());
        productRaiseDO.setAmount(updatedAmount);
        row = productProgressMapper.restore(productRaiseDO);
        if (row > 0) {
            LOGGER.info("补偿产品[{}]募集金额[{}]元", productRemain.getProductUuid(), productRemain.getAmount());
        }

        return row;
    }

}