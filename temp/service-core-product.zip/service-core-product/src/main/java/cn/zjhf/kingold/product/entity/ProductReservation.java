package cn.zjhf.kingold.product.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author
 */
public class ProductReservation implements Serializable {
    /**
     * 自增主键
     */
    private Long productReservationID;

    /**
     * 私募产品预约单UUID
     */
    private String productReservationUuid;

    /**
     * 私募预约单编号
     */
    private String reservationBillCode;

    /**
     * 预约产品UUID
     */
    private String reservationProductUuid;

    /**
     * 预约产品编码
     */
    private String reservationProductCode;

    /**
     * 预约产品名称
     */
    private String reservationProductName;

    /**
     * 预约人用户UUID
     */
    private String reservationUserUuid;

    /**
     * 预约用户手机号码
     */
    private String reservationUserMobile;

    /**
     * 处理人用户UUID（专职理财师或者客服）
     */
    private String serviceUserUuid;

    /**
     * 处理人所属组织机构UUID
     */
    private String serviceUserOrgUuid;


    /**
     * 处理人组织Path
     */
    private String serviceUserOrgPath;


    /**
     * 处理人用户类型（专职理财师或者客服）
     */
    private Byte serviceUserType;

    /**
     * 客户姓名
     */
    private String customerName;

    /**
     * 客户真实姓名
     */
    private String customerRealName;

    /**
     * 客户身份证号码
     */
    private String customerIdCardNo;

    /**
     * 客户手机号码
     */
    private String customerMobile;

    /**
     * 客户真实手机号码
     */
    private String customerRealMobile;

    /**
     * 客户所在地区编码
     */
    private String customerRegionCode;

    /**
     * 客户详细住址
     */
    private String customerAddress;

    /**
     * 客户真实地址
     */
    private String customerRealAddress;

    /**
     * 预约金额
     */
    private String reservationAmount;

    /**
     * 预约状态（1-预约中 2-已流转 3-已完成 4-已作废 5-已过期）
     */
    private Byte reservationStatus;

    /**
     * 预约时间
     */
    private Date reservationTime;

    /**
     * 服务处理响应时间
     */
    private Date reservationServiceTime;

    /**
     * 完成时间
     */
    private Date reservationFinishTime;

    /**
     * 预约取消时间
     */
    private Date reservationCancelTime;

    /**
     * 预约过期时间
     */
    private Date reservationOverdueTime;

    /**
     * 附件（合同扫描件）
     */
    private String reservationContract;

    /**
     * 附件（身份证正面扫描件）
     */
    private String reservationIdCardFront;

    /**
     * 附件（身份证背面扫描件）
     */
    private String reservationIdCardBack;

    /**
     * 附件（打款记录扫描件）
     */
    private String reservationVoucher;

    /**
     * 附件（银行卡扫描件）
     */
    private String reservationBankCard;

    /**
     * 实际购买金额
     */
    private BigDecimal purchaseAmount;

    /**
     * 实际购买时间
     */
    private Date purchaseTime;

    /**
     * 删除标识
     */
    private Byte deleteFlag;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public Long getProductReservationID() {
        return productReservationID;
    }

    public void setProductReservationID(Long productReservationID) {
        this.productReservationID = productReservationID;
    }

    public String getProductReservationUuid() {
        return productReservationUuid;
    }

    public void setProductReservationUuid(String productReservationUuid) {
        this.productReservationUuid = productReservationUuid;
    }

    public String getReservationBillCode() {
        return reservationBillCode;
    }

    public void setReservationBillCode(String reservationBillCode) {
        this.reservationBillCode = reservationBillCode;
    }

    public String getReservationProductUuid() {
        return reservationProductUuid;
    }

    public void setReservationProductUuid(String reservationProductUuid) {
        this.reservationProductUuid = reservationProductUuid;
    }

    public String getReservationProductCode() {
        return reservationProductCode;
    }

    public void setReservationProductCode(String reservationProductCode) {
        this.reservationProductCode = reservationProductCode;
    }

    public String getReservationProductName() {
        return reservationProductName;
    }

    public void setReservationProductName(String reservationProductName) {
        this.reservationProductName = reservationProductName;
    }

    public String getReservationUserUuid() {
        return reservationUserUuid;
    }

    public void setReservationUserUuid(String reservationUserUuid) {
        this.reservationUserUuid = reservationUserUuid;
    }

    public String getReservationUserMobile() {
        return reservationUserMobile;
    }

    public void setReservationUserMobile(String reservationUserMobile) {
        this.reservationUserMobile = reservationUserMobile;
    }

    public String getServiceUserUuid() {
        return serviceUserUuid;
    }

    public void setServiceUserUuid(String serviceUserUuid) {
        this.serviceUserUuid = serviceUserUuid;
    }

    public Byte getServiceUserType() {
        return serviceUserType;
    }

    public void setServiceUserType(Byte serviceUserType) {
        this.serviceUserType = serviceUserType;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerRealName() {
        return customerRealName;
    }

    public void setCustomerRealName(String customerRealName) {
        this.customerRealName = customerRealName;
    }

    public String getCustomerIdCardNo() {
        return customerIdCardNo;
    }

    public void setCustomerIdCardNo(String customerIdCardNo) {
        this.customerIdCardNo = customerIdCardNo;
    }

    public String getCustomerMobile() {
        return customerMobile;
    }

    public void setCustomerMobile(String customerMobile) {
        this.customerMobile = customerMobile;
    }

    public String getCustomerRealMobile() {
        return customerRealMobile;
    }

    public void setCustomerRealMobile(String customerRealMobile) {
        this.customerRealMobile = customerRealMobile;
    }

    public String getCustomerRegionCode() {
        return customerRegionCode;
    }

    public void setCustomerRegionCode(String customerRegionCode) {
        this.customerRegionCode = customerRegionCode;
    }

    public String getCustomerAddress() {
        return customerAddress;
    }

    public void setCustomerAddress(String customerAddress) {
        this.customerAddress = customerAddress;
    }

    public String getCustomerRealAddress() {
        return customerRealAddress;
    }

    public void setCustomerRealAddress(String customerRealAddress) {
        this.customerRealAddress = customerRealAddress;
    }

    public String getReservationAmount() {
        return reservationAmount;
    }

    public void setReservationAmount(String reservationAmount) {
        this.reservationAmount = reservationAmount;
    }

    public Byte getReservationStatus() {
        return reservationStatus;
    }

    public void setReservationStatus(Byte reservationStatus) {
        this.reservationStatus = reservationStatus;
    }

    public Date getReservationTime() {
        return reservationTime;
    }

    public void setReservationTime(Date reservationTime) {
        this.reservationTime = reservationTime;
    }

    public Date getReservationServiceTime() {
        return reservationServiceTime;
    }

    public void setReservationServiceTime(Date reservationServiceTime) {
        this.reservationServiceTime = reservationServiceTime;
    }

    public Date getReservationFinishTime() {
        return reservationFinishTime;
    }

    public void setReservationFinishTime(Date reservationFinishTime) {
        this.reservationFinishTime = reservationFinishTime;
    }

    public Date getReservationCancelTime() {
        return reservationCancelTime;
    }

    public void setReservationCancelTime(Date reservationCancelTime) {
        this.reservationCancelTime = reservationCancelTime;
    }

    public Date getReservationOverdueTime() {
        return reservationOverdueTime;
    }

    public void setReservationOverdueTime(Date reservationOverdueTime) {
        this.reservationOverdueTime = reservationOverdueTime;
    }

    public String getReservationContract() {
        return reservationContract;
    }

    public void setReservationContract(String reservationContract) {
        this.reservationContract = reservationContract;
    }

    public String getReservationIdCardFront() {
        return reservationIdCardFront;
    }

    public void setReservationIdCardFront(String reservationIdCardFront) {
        this.reservationIdCardFront = reservationIdCardFront;
    }

    public String getReservationIdCardBack() {
        return reservationIdCardBack;
    }

    public void setReservationIdCardBack(String reservationIdCardBack) {
        this.reservationIdCardBack = reservationIdCardBack;
    }

    public String getReservationVoucher() {
        return reservationVoucher;
    }

    public void setReservationVoucher(String reservationVoucher) {
        this.reservationVoucher = reservationVoucher;
    }

    public String getReservationBankCard() {
        return reservationBankCard;
    }

    public void setReservationBankCard(String reservationBankCard) {
        this.reservationBankCard = reservationBankCard;
    }

    public BigDecimal getPurchaseAmount() {
        return purchaseAmount;
    }

    public void setPurchaseAmount(BigDecimal purchaseAmount) {
        this.purchaseAmount = purchaseAmount;
    }

    public Date getPurchaseTime() {
        return purchaseTime;
    }

    public void setPurchaseTime(Date purchaseTime) {
        this.purchaseTime = purchaseTime;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getServiceUserOrgUuid() {
        return serviceUserOrgUuid;
    }

    public void setServiceUserOrgUuid(String serviceUserOrgUuid) {
        this.serviceUserOrgUuid = serviceUserOrgUuid;
    }

    public String getServiceUserOrgPath() {
        return serviceUserOrgPath;
    }

    public void setServiceUserOrgPath(String serviceUserOrgPath) {
        this.serviceUserOrgPath = serviceUserOrgPath;
    }
}