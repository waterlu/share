package cn.zjhf.kingold.product.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class ProductRewardSet implements Serializable {
    /**
     * 自增主键
     */
    private Long productAwardId;

    /**
     * 产品uuid
     */
    private String productUuid;

    /**
     * 产品简称
     */
    private String productAbbrName;

    /**
     * 产品类型（PRIF私募基金FIXI固定收益理财）
     */
    private String productType;

    /**
     * 产品邀请奖励设置（JSON）
     */
    private String productInviteAward;

    /**
     * 产品达人奖励设置（JSON）
     */
    private String productTalentAward;

    /**
     * 删除标识
     */
    private Byte deleteFlag;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public Long getProductAwardId() {
        return productAwardId;
    }

    public void setProductAwardId(Long productAwardId) {
        this.productAwardId = productAwardId;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductAbbrName() {
        return productAbbrName;
    }

    public void setProductAbbrName(String productAbbrName) {
        this.productAbbrName = productAbbrName;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getProductInviteAward() {
        return productInviteAward;
    }

    public void setProductInviteAward(String productInviteAward) {
        this.productInviteAward = productInviteAward;
    }

    public String getProductTalentAward() {
        return productTalentAward;
    }

    public void setProductTalentAward(String productTalentAward) {
        this.productTalentAward = productTalentAward;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}