package cn.zjhf.kingold.product.persistence.mq.consumer;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.product.constant.BizDefine;
import cn.zjhf.kingold.product.constant.ProductConstants;
import cn.zjhf.kingold.product.persistence.mq.message.OrderPaidMessage;
import cn.zjhf.kingold.product.service.IProductService;
import cn.zjhf.kingold.product.util.DateUtil;
import cn.zjhf.kingold.product.util.MapParamUtils;
import cn.zjhf.kingold.rocketmq.annotation.RocketMQConsumer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQConsumer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 定期订单付款成功消费，修改募集金额
 * <p>
 * @author Xiaody
 * @date 2017/7/14
 */
@RocketMQConsumer(topic = "order", tag = "paid")
public class OrderPaidConsumer extends AbstractMQConsumer<OrderPaidMessage> {

    @Autowired
    private IProductService productService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ResponseResult process(OrderPaidMessage orderPaidMessage) throws BusinessException {
        // 判断是否募集完成
        logger.info("消费订单认购成功判断产品募集状态：");
        ResponseResult result = new ResponseResult();
        try {
            // service_trade同步更新产品募集进度，这里不再更新，只判断是否已经募集完成
            Map product = productService.getFixedIncome(orderPaidMessage.getProductUuid());
            BigDecimal scale = MapParamUtils.getBigDecimalInMap(product, "productScale");
            BigDecimal accumulation = MapParamUtils.getBigDecimalInMap(product, "productAccumulation");
            BigDecimal manual = MapParamUtils.getBigDecimalInMap(product, "productManual");

            // 剩余额度
            BigDecimal remain = scale.subtract(accumulation).subtract(manual);

            // 最小投资金额
            BigDecimal minInvestment = MapParamUtils.getBigDecimalInMap(product, "productMinInvestment");

            // 剩余额度已经小于最小投资金额
            if (remain.compareTo(minInvestment) < 0) {
                logger.info("remain=[{}], minInvestment=[{}]", remain, minInvestment);

                if (remain.compareTo(BigDecimal.ZERO) > 0) {
                    Map<String, Object> param = new HashMap<>();
                    param.put("productType", "FIXI");
                    param.put("productManual", remain);
                    param.put("productChangeType", ProductConstants.PRODUCT_CHANGE_TYPE_RAISEAMOUNT);
                    param.put("createBy", "system");
                    productService.update(param);
                    logger.info("调整募集金额[{}]", remain);
                }

                Map updateMap = new HashMap();
                updateMap.put("productUuid", orderPaidMessage.getProductUuid());
                updateMap.put("productChangeType", ProductConstants.PRODUCT_CHANGE_TYPE_STATUS);
                updateMap.put("productStatus", 3);
                updateMap.put("createBy", "system");
                updateMap.put("raiseEndDate", DateUtil.formateDate(new Date()));
                productService.update(updateMap);
                logger.info("更新产品募集状态成功");
            }
            result.setCode(ResponseCode.OK);
            result.setMsg(ResponseCode.OK_TEXT);
            return result;
        } catch (Exception e) {
            logger.error("消费订单认购成功判断产品募集状态失败:{}",e.getMessage());
            result.setCode(ResponseCode.EXCEPTION);
            result.setMsg(e.getMessage());
            return result;
        }
    }
}
