package cn.zjhf.kingold.product.exception;

import cn.zjhf.kingold.common.exception.BusinessException;

/**
 * @author lutiehua
 * @date 2017/12/19
 */
public class ProductRaiseLogException extends BusinessException {

    public ProductRaiseLogException() {
        super(6214 , "记录产品募集日志失败");
    }
}
