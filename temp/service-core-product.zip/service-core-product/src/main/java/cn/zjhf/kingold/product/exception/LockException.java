package cn.zjhf.kingold.product.exception;

import cn.zjhf.kingold.common.exception.BusinessException;

/**
 * @author lutiehua
 * @date 2018/3/14
 */
public class LockException extends BusinessException {

    public LockException(String info) {
        super(421, String.format("竞争资源[%s]失败", info));
    }

}
