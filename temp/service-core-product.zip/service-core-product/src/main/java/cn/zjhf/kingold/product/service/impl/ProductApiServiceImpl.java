package cn.zjhf.kingold.product.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.product.constant.BizDefine;
import cn.zjhf.kingold.product.constant.ProductConstants;
import cn.zjhf.kingold.product.constant.ProductStatusMsg;
import cn.zjhf.kingold.product.entity.InVO.LstProductChannelRelationalConditionVO;
import cn.zjhf.kingold.product.entity.InVO.LstProductConditionVO;
import cn.zjhf.kingold.product.entity.InVO.ProductApiVO;
import cn.zjhf.kingold.product.entity.InVO.ProductChannelRelationalVO;
import cn.zjhf.kingold.product.entity.OutVO.ProductApiOutVO;
import cn.zjhf.kingold.product.entity.OutVO.ProductChannelRelationalItemListVO;
import cn.zjhf.kingold.product.entity.ProductChannelRelationalKey;
import cn.zjhf.kingold.product.entity.ProductRewardSet;
import cn.zjhf.kingold.product.entity.ProductSortModel;
import cn.zjhf.kingold.product.entity.enums.ProductTypeEnum;
import cn.zjhf.kingold.product.persistence.dao.*;
import cn.zjhf.kingold.product.persistence.mq.message.ProductMessage;
import cn.zjhf.kingold.product.persistence.mq.producer.ProductOnSaleProducer;
import cn.zjhf.kingold.product.service.IProductApiService;
import cn.zjhf.kingold.product.service.IProductService;
import cn.zjhf.kingold.product.util.*;
import com.alibaba.fastjson.JSON;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Maps;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.*;

/**
 * Created by Xiaody on 17/4/12.
 */
@Service
public class ProductApiServiceImpl implements IProductApiService {

    private static Logger LOGGER = LoggerFactory.getLogger(ProductApiServiceImpl.class);

    @Autowired
    private ProductMapper productMapper;

    @Autowired
    private IProductService productService;

    /**
     * 产品列表
     *
     * 应用端在线（productStatus = 1,2）的产品展示
     * 基于这个接口的特性（1）排序复杂无法用mysql排序
     *                  （2）在线产品数量很少
     * 整体策略如下：
     * （1）选出待排序的产品和排序依赖关键字段
     * （2）根据排序算法进行排序
     * （3）根据分页规则分页
     * （4）根据结果的uuid列表获取产品全部信息
     */
    @Override
    public ProductApiOutVO fixOnlineList(String merchantNum, Integer isNew, Integer startRow, Integer pageSize) throws BusinessException {
        ProductApiOutVO productApiOutVO = new ProductApiOutVO();
        Map<String, Object> sqlParam = new HashMap<>();
        sqlParam.put("merchantNum", merchantNum);
        //获取待排数据
        List<ProductSortModel> onlineFixedList = productMapper.getApiOnlineFixedProduct(sqlParam);
        //过滤新手标数据
        Iterator<ProductSortModel> it = onlineFixedList.iterator();
        while (it.hasNext()) {
            ProductSortModel temp = it.next();
            if (temp.getProductLabel() != null && temp.getProductLabel().contains("1")
                    && isNew == 0) {
                it.remove();
            }
        }
        Integer totalCount = onlineFixedList.size();
        //排序
        Collections.sort(onlineFixedList);
        //分页
        Integer endRow = (startRow + pageSize) > totalCount ?
                totalCount : (startRow +pageSize);
        List<ProductSortModel> pageSortList = onlineFixedList.subList(startRow,endRow);
        LOGGER.info("fixOnlineList page list. pageSortList={}", JSON.toJSON(pageSortList));
        //补充产品信息属性
        List<String> productUuidList = new ArrayList<>();
        for (ProductSortModel productSortModel: pageSortList) {
            productUuidList.add(productSortModel.getProductUuid());
        }
        if (CollectionUtils.isEmpty(pageSortList)) {
            productApiOutVO.setCount(0);
            return productApiOutVO;
        }
        sqlParam = new HashMap<>();
        sqlParam.put("productUuids", productUuidList);
        List<Map> products = productMapper.getProductByProductUuids(sqlParam);
        Map<String, Map> productMap = Maps.uniqueIndex(products, product -> MapParamUtils.getStringInMap(product, "productUuid"));
        List<Map> result = new ArrayList<>();
        for (ProductSortModel productSortModel: pageSortList) {
            Map product = productMap.get(productSortModel.getProductUuid());
            if (product != null) {
                result.add(product);
            }
        }
        productService.dealProductReward(result);
        productApiOutVO.setCount(totalCount);
        productApiOutVO.setProductList(result);

        return productApiOutVO;
    }

    @Override
    public ProductApiOutVO fixOfflineList(String merchantNum, Integer startRow, Integer pageSize) throws BusinessException {
        ProductApiOutVO productApiOutVO = new ProductApiOutVO();
        Map<String, Object> sqlParam = new HashMap<>();
        sqlParam.put("merchantNum", merchantNum);
        sqlParam.put("startRow", startRow);
        sqlParam.put("pageSize", pageSize);
        List<Map> result = productMapper.getApiOfflineFixedProduct(sqlParam);
        Integer count = productMapper.getApiOfflineFixedProductCount(sqlParam);
        productApiOutVO.setCount(count);
        productApiOutVO.setProductList(result);
        return productApiOutVO;
    }


}
