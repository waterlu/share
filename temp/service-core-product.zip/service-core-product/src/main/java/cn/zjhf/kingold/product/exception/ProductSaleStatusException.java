package cn.zjhf.kingold.product.exception;

import cn.zjhf.kingold.common.exception.BusinessException;

/**
 * @author lutiehua
 * @date 2018/3/7
 */
public class ProductSaleStatusException extends BusinessException {

    public ProductSaleStatusException() {
        super(6212, "产品目前不能够购买(产品已募集完成)");
    }

}
