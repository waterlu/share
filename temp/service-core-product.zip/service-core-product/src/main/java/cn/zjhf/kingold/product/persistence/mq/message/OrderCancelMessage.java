package cn.zjhf.kingold.product.persistence.mq.message;

import cn.zjhf.kingold.rocketmq.base.AbstractMQMessage;

import java.math.BigDecimal;

/**
 * 订单取消消息
 *
 * @author lutiehua
 * @date 2017/12/8
 */
public class OrderCancelMessage extends AbstractMQMessage {

    /**
     * 订单编号
     */
    private String orderBillCode;

    /**
     * 产品UUID
     */
    private String productUuid;

    /**
     * 用户UUID
     */
    private String userUuid;

    /**
     * 账户UUID
     */
    private String accountUuid;

    /**
     * 订单金额
     */
    private BigDecimal orderAmount;

    /**
     * 支付金额
     */
    private BigDecimal paidAmount;

    /**
     * 使用的现金券
     */
    private String couponExtendCode;

    /**
     * 尝试次数
     */
    private Integer paySeq;

    public String getOrderBillCode() {
        return orderBillCode;
    }

    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getAccountUuid() {
        return accountUuid;
    }

    public void setAccountUuid(String accountUuid) {
        this.accountUuid = accountUuid;
    }

    public BigDecimal getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(BigDecimal orderAmount) {
        this.orderAmount = orderAmount;
    }

    public BigDecimal getPaidAmount() {
        return paidAmount;
    }

    public void setPaidAmount(BigDecimal paidAmount) {
        this.paidAmount = paidAmount;
    }

    public Integer getPaySeq() {
        return paySeq;
    }

    public void setPaySeq(Integer paySeq) {
        this.paySeq = paySeq;
    }

    public String getCouponExtendCode() {
        return couponExtendCode;
    }

    public void setCouponExtendCode(String couponExtendCode) {
        this.couponExtendCode = couponExtendCode;
    }

    @Override
    public String getKey() {
        return orderBillCode + "-" + paySeq;
    }
}