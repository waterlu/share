package cn.zjhf.kingold.product.persistence.mq.message;

import cn.zjhf.kingold.product.entity.ProductReservation;
import cn.zjhf.kingold.rocketmq.base.MQMessage;

/**
 * Created by Xiaody on 17/7/14.
 * <p>
 * 私募产品预约发送的mq消息
 */
public class ProductReservationMessage extends ProductReservation implements MQMessage {
    private Integer platform;

    public Integer getPlatform() {
        return platform;
    }

    public void setPlatform(Integer platform) {
        this.platform = platform;
    }

    @Override
    public String getKey() {
        return getProductReservationUuid();
    }
}
