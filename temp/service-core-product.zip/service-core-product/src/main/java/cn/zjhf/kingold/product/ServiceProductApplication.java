package cn.zjhf.kingold.product;

import cn.zjhf.kingold.rocketmq.annotation.EnableRocketMQConfiguration;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * 应用程序入口类
 *
 * @author lutiehua
 * @date 2018/03/06
 *
 */
@EnableDiscoveryClient
@SpringBootApplication
@MapperScan("cn.zjhf.kingold.product.persistence.dao")
@EnableRocketMQConfiguration
public class ServiceProductApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceProductApplication.class, args);
	}
}