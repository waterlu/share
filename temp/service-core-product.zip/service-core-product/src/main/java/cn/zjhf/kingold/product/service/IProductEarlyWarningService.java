package cn.zjhf.kingold.product.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.product.dto.ProductEarlyWarningDTO;
import cn.zjhf.kingold.product.vo.CommItemListVO;
import cn.zjhf.kingold.product.vo.ProductEarlyWarningVO;

/**
 * @author xiexiaojie
 *         2018/3/26.
 */
public interface IProductEarlyWarningService {

    /**
     * 产品额度预警-列表
     * @param dto
     * @return
     * @throws BusinessException
     */
    CommItemListVO<ProductEarlyWarningVO> getList(ProductEarlyWarningDTO dto) throws BusinessException;
}
