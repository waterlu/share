package cn.zjhf.kingold.product.util;

import java.util.List;

/**
 * Created by zhangyijie on 2017/7/12.
 */
public class SQLUtils {

    public static String toSQLStr(String strValue) {
        if (DataUtils.isEmpty(strValue))
            strValue = "' '";

        return "'" + strValue.trim() + "'";
    }

    public static String stringListToSql(List<String> items) {
        StringBuilder str = new StringBuilder("");
        if (items == null)
            return str.toString();

        int len = items.size();

        for (int i = 0; i < len; i++) {
            if(DataUtils.isNotEmpty(items.get(i))) {
                str.append(toSQLStr(items.get(i)));

                if (i != (len - 1)) {
                    str.append(",");
                }
            }
        }

        return str.toString();
    }
}
