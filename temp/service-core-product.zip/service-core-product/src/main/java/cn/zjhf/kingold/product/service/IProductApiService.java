package cn.zjhf.kingold.product.service;


import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.product.entity.InVO.LstProductChannelRelationalConditionVO;
import cn.zjhf.kingold.product.entity.InVO.LstProductConditionVO;
import cn.zjhf.kingold.product.entity.InVO.ProductApiVO;
import cn.zjhf.kingold.product.entity.InVO.ProductChannelRelationalVO;
import cn.zjhf.kingold.product.entity.OutVO.ProductApiOutVO;
import cn.zjhf.kingold.product.entity.OutVO.ProductChannelRelationalItemListVO;
import cn.zjhf.kingold.product.entity.ProductRewardSet;

import java.util.List;
import java.util.Map;

/**
 * Created by Xiaody on 17/4/12.
 */
public interface IProductApiService {

    /**
     * 应用端固定收益产品列表，只展示在线产品（预热、募集中）
     * @param merchantNum
     * @param startRow
     * @param pageSize
     * @return
     * @throws BusinessException
     */
    ProductApiOutVO fixOnlineList(String merchantNum, Integer isNew, Integer startRow, Integer pageSize) throws BusinessException;

    /**
     * 应用端固定收益产品列表，只展示不在线产品（大于募集期的产品）
     * @return
     * @throws BusinessException
     */
    ProductApiOutVO fixOfflineList(String merchantNum, Integer startRow, Integer pageSize) throws BusinessException;


}
