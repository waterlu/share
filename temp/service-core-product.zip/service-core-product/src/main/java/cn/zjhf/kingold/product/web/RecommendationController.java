package cn.zjhf.kingold.product.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.product.service.IRecommendationService;
import cn.zjhf.kingold.product.util.DataUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Created by Xiaody on 17/4/14.
 */
@RestController
@RequestMapping("/productRecommendation")
public class RecommendationController {
    private static Logger LOGGER = LoggerFactory.getLogger(RecommendationController.class);

    @Autowired
    private IRecommendationService recommendationService;

    @RequestMapping(value = "", method = RequestMethod.POST)
    public ResponseResult insert(@RequestBody Map params) throws BusinessException {
        Long productRecommendationID = recommendationService.insert(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", productRecommendationID);
    }

    @RequestMapping(value = "/{productRecommendationID}", method = RequestMethod.PUT)
    public ResponseResult update(@PathVariable Long productRecommendationID, @RequestBody Map params) throws BusinessException {
        params.put("productRecommendationID", productRecommendationID);
        recommendationService.update(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用");
    }

    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public ResponseResult getList(@RequestParam Map params) throws BusinessException {
        List<Map> list = recommendationService.getList(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", list);
    }

    @RequestMapping(value = "/count", method = RequestMethod.GET)
    public ResponseResult count(@RequestParam Map params) throws BusinessException {
        Integer count = recommendationService.getCount(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", count);
    }

    @RequestMapping(value = "/recommend", method = RequestMethod.GET)
    public ResponseResult getRecommendation(@RequestParam Map params) throws BusinessException {
        LOGGER.info("getRecommendation start: " + DataUtils.toString(params));
        Map product = recommendationService.getRecommendation(params);
        LOGGER.info("getRecommendation end: " + DataUtils.toString(product));
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", product);
    }

    /**
     * 不区分产品，获取推荐
     * */
    @RequestMapping(value = "/getRecommendProduct", method = RequestMethod.GET)
    public ResponseResult getRecommendProduct(@RequestParam Map params) throws BusinessException {
        Map product = recommendationService.getRecommendProduct(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", product);
    }

    /**
     * 对新推荐产品有更新，没有新建
     * */
    @RequestMapping(value = "/updateOrSave", method = RequestMethod.POST)
    public ResponseResult updateOrSave(@RequestBody Map params) throws BusinessException {
        Long result = recommendationService.updateByProductUuid(params);
        if(result == 0){
            Long productRecommendationID = recommendationService.insert(params);
            return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", productRecommendationID);
        }
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", params.get("productUuid").toString());
    }

    /**
     * 获取已推荐产品列表
     * */
    @RequestMapping(value = "getRecommendProductList", method = RequestMethod.GET)
    public ResponseResult getRecommendProductList(@RequestParam Map params) throws BusinessException {
        List<Map> result = recommendationService.getRecommendProductList(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", result);
    }
}
