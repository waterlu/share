package cn.zjhf.kingold.product.exception;

import cn.zjhf.kingold.common.exception.BusinessException;

/**
 * @author lutiehua
 * @date 2018/3/7
 */
public class MinInvestmentException extends BusinessException {

    public MinInvestmentException() {
        super(6004, "认购金额不能小于起投金额，请重新输入");
    }
}
