package cn.zjhf.kingold.product.entity;

import java.io.Serializable;

/**
 * @author 
 */
public class ProductChannelRelationalKey implements Serializable {
    /**
     * channel_uuid 渠道方UUID
     */
    private String channelUuid;

    /**
     * UUID主键
     */
    private String productUuid;

    private static final long serialVersionUID = 1L;

    public String getChannelUuid() {
        return channelUuid;
    }

    public void setChannelUuid(String channelUuid) {
        this.channelUuid = channelUuid;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }
}