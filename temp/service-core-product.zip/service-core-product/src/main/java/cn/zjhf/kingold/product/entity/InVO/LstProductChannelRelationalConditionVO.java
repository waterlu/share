package cn.zjhf.kingold.product.entity.InVO;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.product.util.DataUtils;
import io.swagger.annotations.ApiModelProperty;

import java.util.Date;

/**
 * Created by zhangyijie on 2017/7/19.
 */
public class LstProductChannelRelationalConditionVO extends ParamVO {

    @ApiModelProperty(required = false, value = "渠道uuid")
    private String channelUuid;

    @ApiModelProperty(required = false, value = "APP名称")
    private String channelAppName;

    @ApiModelProperty(required = true, value = "产品类型：PRIF私募基金；FIXI固定收益理财；null全部")
    private String productType;

    @ApiModelProperty(required = true, value = "产品状态  0全部，1预热中，2募集中，3已售罄，4已成立，5封闭期，6存续期，7已结束，8已到期，9已兑付")
    private Integer productStatus;

    @ApiModelProperty(required = true, value = "产品上架状态  0全部，1未上架，2已上架，3已下架")
    private Integer productOnStatus;

    @ApiModelProperty(required = true, value = "分配时间_起始")
    private Date beginDate;

    @ApiModelProperty(required = true, value = "分配时间_结束")
    private Date endDate;

    @ApiModelProperty(required = true, value = "起始序号")
    private int beginSN;

    @ApiModelProperty(required = true, value = "结束序号")
    private int endSN;

    public String getChannelUuid() {
        return channelUuid;
    }

    public void setChannelUuid(String channelUuid) {
        this.channelUuid = channelUuid;
    }

    public String getChannelAppName() {
        return channelAppName;
    }

    public void setChannelAppName(String channelAppName) {
        this.channelAppName = channelAppName;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public Integer getProductStatus() {
        return productStatus;
    }

    public void setProductStatus(Integer productStatus) {
        this.productStatus = productStatus;
    }

    public Integer getProductOnStatus() {
        return productOnStatus;
    }

    public void setProductOnStatus(Integer productOnStatus) {
        this.productOnStatus = productOnStatus;
    }

    public Date getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(Date beginDate) {
        this.beginDate = beginDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(getTraceID()) + ", ");

        sb.append("channelAppName:" + DataUtils.toString(channelAppName) + ", ");
        sb.append("productType:" + DataUtils.toString(productType) + ", ");
        sb.append("productStatus:" + DataUtils.toString(productStatus) + ", ");
        sb.append("productOnStatus:" + DataUtils.toString(productOnStatus) + ", ");

        sb.append("beginDate:" + DataUtils.toString(beginDate) + ", ");
        sb.append("endDate:" + DataUtils.toString(endDate) + ", ");
        sb.append("beginSN:" + DataUtils.toString(beginSN) + ", ");
        sb.append("endSN:" + DataUtils.toString(endSN));
        return sb.toString();
    }

    public int getBeginSN() {
        return beginSN;
    }

    public void setBeginSN(int beginSN) {
        this.beginSN = beginSN;
    }

    public int getEndSN() {
        return endSN;
    }

    public void setEndSN(int endSN) {
        this.endSN = endSN;
    }
}
