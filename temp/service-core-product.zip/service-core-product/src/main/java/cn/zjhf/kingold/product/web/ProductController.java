package cn.zjhf.kingold.product.web;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.common.utils.MapRemoveNullUtil;
import cn.zjhf.kingold.product.dto.ProductRemainDTO;
import cn.zjhf.kingold.product.entity.InVO.LstProductChannelRelationalConditionVO;
import cn.zjhf.kingold.product.entity.InVO.LstProductConditionVO;
import cn.zjhf.kingold.product.entity.InVO.ProductChannelRelationalVO;
import cn.zjhf.kingold.product.entity.OutVO.ProductChannelRelationalItemListVO;
import cn.zjhf.kingold.product.entity.ProductRewardSet;
import cn.zjhf.kingold.product.exception.ProductSellOutException;
import cn.zjhf.kingold.product.service.IProductService;
import cn.zjhf.kingold.product.util.DataUtils;
import cn.zjhf.kingold.product.util.MapParamUtils;
import cn.zjhf.kingold.product.util.PropertyDescriptionUtils;
import cn.zjhf.kingold.product.util.RequestMapperConvert;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.hibernate.validator.constraints.NotEmpty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static cn.zjhf.kingold.product.util.PropertyDescriptionUtils.convertProductProperty;

/**
 * @author Xiaody
 * @date 17/4/12
 */
@RestController
@RequestMapping("/product")
public class ProductController {

    private static Logger LOGGER = LoggerFactory.getLogger(ProductController.class);

    @Autowired
    private IProductService productService;

    /**
     * 创建产品
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "", method = RequestMethod.POST)
    public ResponseResult insert(@RequestBody Map params) throws BusinessException {
        MapRemoveNullUtil.removeNullEntry(params);
        String productUuid = productService.insert(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", productUuid);
    }

    /**
     * 获取产品信息
     *
     * @param productUuid
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/{productUuid}", method = RequestMethod.GET)
    public ResponseResult get(@PathVariable String productUuid, @RequestParam Map params) throws BusinessException {
        Map product = productService.get(productUuid);
        product = PropertyDescriptionUtils.convertProductProperty(product, (String) params.get("properties"), (String) params.get("desc"));
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", product);
    }

    /**
     * 修改产品信息
     *
     * @param productUuid
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/{productUuid}", method = RequestMethod.PUT)
    public ResponseResult update(@PathVariable String productUuid, @RequestBody Map params) throws BusinessException {
        MapRemoveNullUtil.removeNullEntry(params);
        params.put("productUuid", productUuid);
        productService.update(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用");
    }

    /**
     * 修改产品信息到置顶
     *
     * @param productUuid
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/top/{productUuid}", method = RequestMethod.PUT)
    public ResponseResult top(@PathVariable String productUuid, @RequestBody Map params) throws BusinessException {
        MapRemoveNullUtil.removeNullEntry(params);
        params.put("productUuid", productUuid);
        productService.topUpdate(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用");
    }

    /**
     * 通用报表处理
     *
     * @param param
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/lstByCondition", method = RequestMethod.GET)
    public ResponseResult lstByCondition(@RequestParam Map<String, Object> param) throws BusinessException {
        LOGGER.info("lstByCondition start: " + DataUtils.toString(param));
        String jsonString = JSON.toJSONString(param);
        LstProductConditionVO lstCondition = JSON.parseObject(jsonString, LstProductConditionVO.class);

        List<Map> reportData = productService.lstByCondition(lstCondition);

        Integer count = productService.countByCondition(lstCondition);
        Map result = new HashMap();
        result.put("list", reportData);
        result.put("count", count);

        LOGGER.info("getCommReport end: " + DataUtils.toString(lstCondition.getTraceID(), result));
        return new ResponseResult(lstCondition.getTraceID(), ResponseCode.REQUEST_SUCCESS, "成功", result);
    }

    /**
     * 根据查询条件获取产品列表
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public ResponseResult getList(@RequestParam Map params) throws BusinessException {
        MapRemoveNullUtil.removeNullEntry(params);
        RequestMapperConvert.initProductParam(params);
        List<Map> list = productService.getList(params);
        List<Map> returnList = new ArrayList<>();
        for (Map map : list) {
            returnList.add(convertProductProperty(map, (String) params.get("properties"), (String) params.get("desc")));
        }
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", returnList);
    }

    /**
     * 根据查询条件获取产品数量
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/count", method = RequestMethod.GET)
    public ResponseResult count(@RequestParam Map params) throws BusinessException {
        MapRemoveNullUtil.removeNullEntry(params);
        RequestMapperConvert.initProductParam(params);
        Integer count = productService.getCount(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", count);
    }

    /**
     * 根据查询条件获取产品列表,过滤掉给定渠道下已有产品
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/channelNonExistProductList", method = RequestMethod.GET)
    public ResponseResult channelNonExistProductList(@RequestParam Map params) throws BusinessException {
        MapRemoveNullUtil.removeNullEntry(params);
        RequestMapperConvert.initProductParam(params);
        List<Map> list = productService.channelNonExistProductList(params);
        List<Map> returnList = new ArrayList<>();
        for (Map map : list) {
            returnList.add(convertProductProperty(map, (String) params.get("properties"), (String) params.get("desc")));
        }
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", returnList);
    }

    /**
     * 根据查询条件获取产品列表,过滤掉给定渠道下已有产品数量
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/channelNonExistProductCount", method = RequestMethod.GET)
    public ResponseResult channelNonExistProductCount(@RequestParam Map params) throws BusinessException {
        MapRemoveNullUtil.removeNullEntry(params);
        RequestMapperConvert.initProductParam(params);
        Integer count = productService.channelNonExistProductCount(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", count);
    }

    /**
     * 获取私募产品详情
     *
     * @param productUuid
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/privateFund/{productUuid}", method = RequestMethod.GET)
    public ResponseResult getPrivateFund(@PathVariable String productUuid, @RequestParam Map params) throws BusinessException {
        Map product = productService.getPrivateFund(productUuid);
        product = PropertyDescriptionUtils.convertProductProperty(product, (String) params.get("properties"), (String) params.get("desc"));
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", product);
    }

    /**
     * 获取固收产品详情
     *
     * @param productUuid
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/fixedIncome/{productUuid}", method = RequestMethod.GET)
    public ResponseResult getFixedIncome(@PathVariable String productUuid, @RequestParam Map params) throws BusinessException {
        Map product = productService.getFixedIncome(productUuid);
        product = PropertyDescriptionUtils.convertProductProperty(product, (String) params.get("properties"), (String) params.get("desc"));
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", product);
    }

    /**
     * 获取固收产品和渠道详情
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/channel/fixedIncome", method = RequestMethod.GET)
    public ResponseResult getFixedIncomeChannel(@RequestParam Map params) throws BusinessException {
        LOGGER.info("getFixedIncomeChannel start: " + DataUtils.toString(params));
        Map product = productService.getFixedIncomeChannel(params);
        product = PropertyDescriptionUtils.convertProductProperty(product, (String) params.get("properties"), (String) params.get("desc"));
        LOGGER.info("getFixedIncomeChannel end: " + DataUtils.toString(product));
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", product);
    }

    /**
     * 修改募集金额
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/updateAccumulation", method = RequestMethod.PUT)
    public ResponseResult updateAccumulation(@RequestBody Map params) throws BusinessException {
        productService.updateAccumulation(MapParamUtils.getStringInMap(params, "productUuid"), MapParamUtils.getDoubleInMap(params, "amount"));
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用");
    }

    /**
     * 根据查询条件获取私募产品列表
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/privateFund/list", method = RequestMethod.GET)
    public ResponseResult getPrivateFundList(@RequestParam Map params) throws BusinessException {
        MapRemoveNullUtil.removeNullEntry(params);
        RequestMapperConvert.initProductParam(params);
        List<Map> list = productService.getPrivateFundList(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", list);
    }

    /**
     * 根据查询条件获取私募产品数量
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/privateFund/count", method = RequestMethod.GET)
    public ResponseResult privateFundCount(@RequestParam Map params) throws BusinessException {
        MapRemoveNullUtil.removeNullEntry(params);
        RequestMapperConvert.initProductParam(params);
        Integer count = productService.getPrivateFundCount(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", count);
    }

    /**
     * 获取理财达人专属产品
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/fixedIncome/viplist", method = RequestMethod.GET)
    public ResponseResult getVipFixedIncome(@RequestParam Map params) throws BusinessException {
        LOGGER.info("getVipFixedIncome start: ");

        List<Map> list = productService.getVipFixedIncome();

        LOGGER.info("getVipFixedIncome end: " + DataUtils.toString((String) params.get("traceID"), list));
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", list);
    }

    /**
     * 根据查询条件获取固收产品列表
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/fixedIncome/list", method = RequestMethod.GET)
    public ResponseResult getFixedIncomeList(@RequestParam Map params) throws BusinessException {
        LOGGER.info("getFixedIncomeList start: " + DataUtils.toString(params));

        MapRemoveNullUtil.removeNullEntry(params);
        RequestMapperConvert.initProductParam(params);
        List<Map> list = productService.getFixedIncomeList(params);

        LOGGER.info("getFixedIncomeList end: " + DataUtils.toString((String) params.get("traceID"), list));
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", list);
    }

    /**
     * 根据查询条件获取固定产品数量
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/fixedIncome/count", method = RequestMethod.GET)
    public ResponseResult fixedIncomeCount(@RequestParam Map params) throws BusinessException {
        MapRemoveNullUtil.removeNullEntry(params);
        RequestMapperConvert.initProductParam(params);
        Integer count = productService.getFixedIncomeCount(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", count);
    }


    /**
     * 获取产品奖励细则列表
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/reward/list", method = RequestMethod.GET)
    public ResponseResult rewardList(@RequestParam Map params) throws BusinessException {
        MapRemoveNullUtil.removeNullEntry(params);
        List<Map> list = productService.getProductRewardList(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", list);
    }


    /**
     * 获取产品奖励细则数量
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/reward/count", method = RequestMethod.GET)
    public ResponseResult rewardCount(@RequestParam Map params) throws BusinessException {
        MapRemoveNullUtil.removeNullEntry(params);
        Integer count = productService.getProductRewardCount(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", count);
    }

    /**
     * 获取产品达人奖励细则列表
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/talent/reward/list", method = RequestMethod.GET)
    public ResponseResult talentRewardList(@RequestParam Map params) throws BusinessException {
        MapRemoveNullUtil.removeNullEntry(params);
        List<Map> list = productService.getProductTalentRewardList(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", list);
    }


    /**
     * 获取产品达人奖励细则数量
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/talent/reward/count", method = RequestMethod.GET)
    public ResponseResult talentRewardCount(@RequestParam Map params) throws BusinessException {
        MapRemoveNullUtil.removeNullEntry(params);
        Integer count = productService.getProductTalentRewardCount(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", count);
    }

    /**
     * 添加 产品-渠道 关联关系
     *
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/addProductChannelRelational", method = RequestMethod.POST)
    public ResponseResult addProductChannelRelational(@RequestBody ProductChannelRelationalVO productChannelRelationalVO) throws BusinessException {
        LOGGER.info("addProductChannelRelational start: " + DataUtils.toString(productChannelRelationalVO));

        DataUtils.checkParam(productChannelRelationalVO.getChannelUuid(), productChannelRelationalVO.getProductUuid());
        productService.addProductChannelRelational(productChannelRelationalVO);

        LOGGER.info("addProductChannelRelational end: " + DataUtils.toString(productChannelRelationalVO.getTraceID()));
        return new ResponseResult(productChannelRelationalVO.getTraceID(), ResponseCode.REQUEST_SUCCESS, "正常调用");
    }

    /**
     * 查询 产品-渠道 关联关系列表
     *
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/lstProductChannelRelationals", method = RequestMethod.GET)
    public ResponseResult lstProductChannelRelationals(@RequestParam Map<String, Object> param) throws BusinessException {
        String jsonString = JSON.toJSONString(param);
        LstProductChannelRelationalConditionVO lstCondition = JSON.parseObject(jsonString, LstProductChannelRelationalConditionVO.class);
        LOGGER.info("lstProductChannelRelationals start: " + DataUtils.toString(lstCondition));

        ProductChannelRelationalItemListVO relationalItemList = productService.lstProductChannelRelationals(lstCondition);

        LOGGER.info("lstProductChannelRelationals end: " + DataUtils.toString(relationalItemList));
        return new ResponseResult(lstCondition.getTraceID(), ResponseCode.REQUEST_SUCCESS, "正常调用", relationalItemList);
    }

    /**
     * 获取产品说明书编码
     *
     * @param productUuid
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/descriptionCode/{productUuid}", method = RequestMethod.GET)
    public ResponseResult getDescriptionCode(@PathVariable String productUuid, @RequestParam Map params) throws BusinessException {
        LOGGER.info("getDescriptionCode start: " + DataUtils.toString(productUuid) + " " + DataUtils.toString(params));

        Map product = productService.get(productUuid);
        String productDescriptionCode = "";
        if (product.get("productAttachment") != null) {
            List<Map> attachmentArray = (List<Map>) product.get("productAttachment");
            for (int i = 0; i < attachmentArray.size(); i++) {
                if (attachmentArray.get(i).get("attachmentType") != null) {
                    if (attachmentArray.get(i).get("attachmentType").equals("产品说明书")) {
                        productDescriptionCode = attachmentArray.get(i).get("attachmentCode").toString();
                        break;
                    }
                }
            }
        }

        LOGGER.info("getDescriptionCode end: " + DataUtils.toString((String) params.get("traceID")) + " " + DataUtils.toString(productDescriptionCode));
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", productDescriptionCode);
    }

    /**
     * 获取限制子产品集合
     *
     * @param params
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/getFixedProducts", method = RequestMethod.GET)
    public ResponseResult getFixedProducts(@RequestParam Map params) throws BusinessException {
        MapRemoveNullUtil.removeNullEntry(params);
        List<Map> list = productService.getFixedProducts(params);
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", list);
    }

    /**
     * 通过产品uuid获取奖励明细
     *
     * @param productUuid
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/getRewardByProductUuid", method = RequestMethod.GET)
    public ResponseResult getRewardByProductUuid(String traceID, @RequestParam("productUuid") @NotEmpty String productUuid) throws BusinessException {
        ProductRewardSet rewardSet = productService.getRewardByProductUuid(productUuid);
        return new ResponseResult(traceID, ResponseCode.REQUEST_SUCCESS, "正常调用", rewardSet);
    }

    /**
     * 定期产品奖励数据转移如新的奖励设置库表
     *
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/transferRewardData", method = RequestMethod.GET)
    public ResponseResult transferRewardData(@RequestParam Map params) throws BusinessException {
        Map<String, Object> param = new HashMap<>();
        param.put("isRefresh", true);
        List<Map> list = productService.getProductRewardList(param);
        for (Map map : list) {
            try {
                map.put("productInviteAward", JSONObject.toJSONString(map.get("productAward")));
                productService.transferRewardData(map);
            } catch (Exception e) {
                LOGGER.error("transferRewardData productUuid exception {}{}", map.get("productUuid"), e);
            }
        }
        return new ResponseResult((String) params.get("traceID"), ResponseCode.REQUEST_SUCCESS, "正常调用", list.size());
    }

    /**
     * 更新产品剩余募集金额
     *
     * @param uuid
     * @param productRemainDTO
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/{uuid}/raise", method = RequestMethod.PUT)
    public ResponseResult updateProductRaise(@PathVariable String uuid,
                                             @RequestBody @Validated ProductRemainDTO productRemainDTO) throws BusinessException {
        productRemainDTO.setProductUuid(uuid);
        LOGGER.info("产品{}扣减募集金额{}", productRemainDTO.getProductUuid(), productRemainDTO.getAmount());
        int row = productService.updateRaise(productRemainDTO);
        if (row == 1) {
            LOGGER.info("产品扣减募集金额成功");
            ResponseResult responseResult = new ResponseResult(productRemainDTO.getTraceID(), ResponseCode.REQUEST_SUCCESS, "正常调用");
            responseResult.setData(row);
            return responseResult;
        } else {
            LOGGER.error("产品扣减募集金额失败");
            throw new ProductSellOutException();
        }
    }
}
