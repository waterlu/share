package cn.zjhf.kingold.product.entity.OutVO;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.product.entity.InVO.ProductChannelRelationalVO;
import cn.zjhf.kingold.product.util.DataUtils;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * Created by zhangyijie on 2017/7/19.
 */
public class ProductChannelRelationalItemListVO extends ParamVO {
    @ApiModelProperty(required = true, value = "总记录数")
    private int totalCount;

    @ApiModelProperty(required = true, value = "返回列表")
    private List<ProductChannelRelationalVO> items;

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public List<ProductChannelRelationalVO> getItems() {
        return items;
    }

    public void setItems(List<ProductChannelRelationalVO> items) {
        this.items = items;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(getTraceID()) + ", ");
        sb.append("totalCount:" + DataUtils.toString(totalCount) + ", ");
        sb.append("items:" + DataUtils.toString(items));
        return sb.toString();
    }
}
