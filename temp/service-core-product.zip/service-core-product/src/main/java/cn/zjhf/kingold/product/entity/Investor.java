package cn.zjhf.kingold.product.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class Investor extends User implements Serializable {

    /**
     * 自增ID
     */
    private Long investorId;

    /**
     * 用户主表UUID
     */
    private String userUuid;

    /**
     * 投资人所属机构UUID
     */
    private String investorOrganizationUuid;

    /**
     * 投资人所属机构path
     */
    private String investorOrganizationPath;

    /**
     * 投资人手机号码
     */
    private String investorMobile;

    /**
     * 性别
     */
    private Byte investorGender;

    /**
     * 头像
     */
    private String investorAvatar;

    /**
     * 上一级邀请人用户UUID
     */
    private String inviterUuid;

    /**
     * 用户真实姓名
     */
    private String investorRealName;

    /**
     * 用户身份证号码
     */
    private String investorIdCardNo;

    /**
     * 用户所在地区编码
     */
    private String investorRegionCode;

    /**
     * 用户详细住址
     */
    private String investorAddress;

    /**
     * 是否合格投资者
     */
    private Byte isEligibleInvestor;

    /**
     * 风险评测等级
     */
    private Byte investorRiskLevel;

    /**
     * 数据签名
     */
    private String signature;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 银行卡号
     */
    private String bankUserCardNo;

    private static final long serialVersionUID = 1L;

    public Long getInvestorId() {
        return investorId;
    }

    public void setInvestorId(Long investorId) {
        this.investorId = investorId;
    }

    /**
     * 投资人类型（11普通投资人 12理财顾问 19专职理财师)
     */
    private Integer investorType;


    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getInvestorOrganizationUuid() {
        return investorOrganizationUuid;
    }

    public void setInvestorOrganizationUuid(String investorOrganizationUuid) {
        this.investorOrganizationUuid = investorOrganizationUuid;
    }

    public String getInvestorMobile() {
        return investorMobile;
    }

    public void setInvestorMobile(String investorMobile) {
        this.investorMobile = investorMobile;
    }


    public Byte getInvestorGender() {
        return investorGender;
    }

    public void setInvestorGender(Byte investorGender) {
        this.investorGender = investorGender;
    }

    public String getInvestorAvatar() {
        return investorAvatar;
    }

    public void setInvestorAvatar(String investorAvatar) {
        this.investorAvatar = investorAvatar;
    }

    public String getInviterUuid() {
        return inviterUuid;
    }

    public void setInviterUuid(String inviterUuid) {
        this.inviterUuid = inviterUuid;
    }

    public String getInvestorRealName() {
        return investorRealName;
    }

    public void setInvestorRealName(String investorRealName) {
        this.investorRealName = investorRealName;
    }

    public String getInvestorIdCardNo() {
        return investorIdCardNo;
    }

    public void setInvestorIdCardNo(String investorIdCardNo) {
        this.investorIdCardNo = investorIdCardNo;
    }

    public String getInvestorRegionCode() {
        return investorRegionCode;
    }

    public void setInvestorRegionCode(String investorRegionCode) {
        this.investorRegionCode = investorRegionCode;
    }

    public String getInvestorAddress() {
        return investorAddress;
    }

    public void setInvestorAddress(String investorAddress) {
        this.investorAddress = investorAddress;
    }

    public Byte getIsEligibleInvestor() {
        return isEligibleInvestor;
    }

    public void setIsEligibleInvestor(Byte isEligibleInvestor) {
        this.isEligibleInvestor = isEligibleInvestor;
    }

    public Byte getInvestorRiskLevel() {
        return investorRiskLevel;
    }

    public void setInvestorRiskLevel(Byte investorRiskLevel) {
        this.investorRiskLevel = investorRiskLevel;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }


    public Integer getInvestorType() {
        return investorType;
    }

    public void setInvestorType(Integer investorType) {
        this.investorType = investorType;
    }

    public String getBankUserCardNo() {
        return bankUserCardNo;
    }

    public void setBankUserCardNo(String bankUserCardNo) {
        this.bankUserCardNo = bankUserCardNo;
    }

    public String getInvestorOrganizationPath() {
        return investorOrganizationPath;
    }

    public void setInvestorOrganizationPath(String investorOrganizationPath) {
        this.investorOrganizationPath = investorOrganizationPath;
    }
}

