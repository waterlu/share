package cn.zjhf.kingold.product.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.product.dto.ProductRemainDTO;
import cn.zjhf.kingold.product.entity.ProductRaise;
import cn.zjhf.kingold.product.entity.ProductRaiseDO;
import cn.zjhf.kingold.product.exception.ProductRaiseLogException;
import cn.zjhf.kingold.product.exception.ProductUpdateRemainException;
import cn.zjhf.kingold.product.persistence.dao.ProductProgressMapper;
import cn.zjhf.kingold.product.persistence.dao.ProductRaiseMapper;
import cn.zjhf.kingold.product.service.IProductTransaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author lutiehua
 * @date 2018/3/27
 */
@Service
public class ProductTransactionImpl implements IProductTransaction {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProductTransactionImpl.class);

    @Autowired
    private ProductRaiseMapper productRaiseMapper;

    @Autowired
    private ProductProgressMapper productProgressMapper;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int updateRaise(ProductRemainDTO productRemain) throws BusinessException {

        // 写募集流水（用于回滚）
        ProductRaise productRaise = new ProductRaise();
        productRaise.setProductUuid(productRemain.getProductUuid());
        productRaise.setUserUuid(productRemain.getUserUuid());
        productRaise.setOrderBillCode(productRemain.getOrderBillCode());
        productRaise.setOrderAmount(productRemain.getAmount());
        int row = productRaiseMapper.raise(productRaise);
        if (row <= 0) {
            LOGGER.error("记录产品[{}]募集日志失败", productRemain.getProductUuid());
            throw new ProductRaiseLogException();
        }

        // 更新募集金额（判断超募情况）
        ProductRaiseDO productRaiseDO = new ProductRaiseDO();
        productRaiseDO.setProductUuid(productRemain.getProductUuid());
        productRaiseDO.setAmount(productRemain.getAmount());
        row = productProgressMapper.raise(productRaiseDO);
        if (row <= 0) {
            LOGGER.error("更新产品[{}]募集金额失败", productRemain.getProductUuid());
            throw new ProductUpdateRemainException();
        }

        return row;
    }
}
