package cn.zjhf.kingold.product.persistence.dao;

import cn.zjhf.kingold.product.dto.ProductEarlyWarningDTO;
import cn.zjhf.kingold.product.vo.ProductEarlyWarningVO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductEarlyWarningMapper {

    List<ProductEarlyWarningVO> list(ProductEarlyWarningDTO dto);

    int count(ProductEarlyWarningDTO dto);

}