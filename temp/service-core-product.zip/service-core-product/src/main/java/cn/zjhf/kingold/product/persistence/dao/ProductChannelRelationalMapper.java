package cn.zjhf.kingold.product.persistence.dao;

import cn.zjhf.kingold.product.entity.ProductChannelRelational;
import cn.zjhf.kingold.product.entity.ProductChannelRelationalExample;
import cn.zjhf.kingold.product.entity.ProductChannelRelationalKey;
import cn.zjhf.kingold.product.util.QueryUtils;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
@Mapper
public interface ProductChannelRelationalMapper {
    long countByExample(ProductChannelRelationalExample example);

    int deleteByExample(ProductChannelRelationalExample example);

    int deleteByPrimaryKey(ProductChannelRelationalKey key);

    int insert(ProductChannelRelational record);

    int insertSelective(ProductChannelRelational record);

    ProductChannelRelational getByProductUuidAndChannel( @Param("productUuid")String productUuid, @Param("merchantNum")String merchantNum);

    ProductChannelRelational selectByPrimaryKey(ProductChannelRelationalKey key);

    @Select("${condition}")
    List<Map> lstCommData(QueryUtils condition);

    int updateByExampleSelective(@Param("record") ProductChannelRelational record, @Param("example") ProductChannelRelationalExample example);

    int updateByExample(@Param("record") ProductChannelRelational record, @Param("example") ProductChannelRelationalExample example);

    int updateByPrimaryKeySelective(ProductChannelRelational record);

    int updateByPrimaryKey(ProductChannelRelational record);
}