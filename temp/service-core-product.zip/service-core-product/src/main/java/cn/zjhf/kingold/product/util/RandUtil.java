package cn.zjhf.kingold.product.util;

import java.util.Random;

/**
 * Created by lutiehua on 2017/4/28.
 */
public class RandUtil {

    private static Random rand = new Random();

    public static int getRandomNumbers(int max) {
        return rand.nextInt(max);
    }
}