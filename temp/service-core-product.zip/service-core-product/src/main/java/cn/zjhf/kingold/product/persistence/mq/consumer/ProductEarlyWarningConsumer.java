package cn.zjhf.kingold.product.persistence.mq.consumer;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.product.constant.URL;
import cn.zjhf.kingold.product.dto.ProductEarlyWarningDTO;
import cn.zjhf.kingold.product.entity.ProductProgress;
import cn.zjhf.kingold.product.persistence.dao.ProductEarlyWarningMapper;
import cn.zjhf.kingold.product.persistence.dao.ProductProgressMapper;
import cn.zjhf.kingold.product.persistence.mq.message.OrderPaidMessage;
import cn.zjhf.kingold.product.util.DataUtils;
import cn.zjhf.kingold.product.util.DateUtil;
import cn.zjhf.kingold.product.vo.ProductEarlyWarningVO;
import cn.zjhf.kingold.rocketmq.annotation.RocketMQConsumer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQConsumer;
import cn.zjhf.kingold.service_consumer.service.BaseServiceConsumer;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author xiexiaojie
 *         2018/3/27.
 */
@RocketMQConsumer(topic = "order", tag = "paid" , consumerGroup = "c_service_product_warning")
public class ProductEarlyWarningConsumer extends AbstractMQConsumer<OrderPaidMessage> {

    /**
     * base服务
     */
    @Autowired
    private BaseServiceConsumer baseServiceConsumer;

    @Autowired
    ProductEarlyWarningMapper productEarlyWarningMapper;

    @Autowired
    ProductProgressMapper productProgressMapper;

    private static final Byte switchOpen = 1;

    @Override
    public ResponseResult process(OrderPaidMessage orderPaidMessage) throws BusinessException {
        ResponseResult result = new ResponseResult();
        //修改产品已募集金额,并判断是否募集满
        logger.info("产品额度预警start：orderId={} productUuid={} productPeriod={} productPeriodType={}",
                orderPaidMessage.getOrderBillCode(),orderPaidMessage.getProductUuid(),orderPaidMessage.getProductPeriod(),orderPaidMessage.getProductPeriodType());
        ProductProgress progress=productProgressMapper.getProgress(orderPaidMessage.getProductUuid());
        //剩余额度
        BigDecimal surplusAmount = progress.getProductScale().subtract(progress.getProductAccumulation()).subtract(progress.getProductManual());
        logger.info("产品额度预警---》剩余额度：{}",surplusAmount);
        //获取启用状态下的产品预警数据
        List<ProductEarlyWarningVO> list =productEarlyWarningMapper.list(new ProductEarlyWarningDTO(switchOpen));
        logger.info("产品额度预警---》启用状态下的产品预警条数：{}",list.size());
        //发送短信条数
        Integer count = 0;
        if(list != null && list.size() > 0){
            for(ProductEarlyWarningVO vo:list){
                //判断时间、以及时间单位是否相等
                logger.info("产品额度预警---》判断时间、以及时间单位是否相等：{} {}",orderPaidMessage.getProductPeriod(),orderPaidMessage.getProductPeriodType());
                if(vo.getProductPeriod().equals(orderPaidMessage.getProductPeriod()) && vo.getProductPeriodType().equals(orderPaidMessage.getProductPeriodType())){
                    //判断剩余额度与预警额度大小    剩余额度 《= 预警额度  发送短信
                    logger.info("产品额度预警---》判断剩余额度与预警额度大小:{}",vo.getProductCordon());
                    if(surplusAmount.compareTo(vo.getProductCordon()) <= 0){
                        count+=sendWarningMessage(orderPaidMessage,surplusAmount,vo.getNotificationTemplateType(),vo.getWarningAddressee());
                    }
                }
            }
        }
        logger.info("产品额度预警end---》短信通知条数：{}",count);
        result.setCode(ResponseCode.OK);
        result.setMsg(ResponseCode.OK_TEXT);
        return result;
    }

    /**
     * 调用base服务发送短信
     * @param orderPaidMessage
     * @param surplusAmount
     */
    private Integer  sendWarningMessage(OrderPaidMessage orderPaidMessage,BigDecimal surplusAmount,String templateType,String addressee)throws BusinessException {
        logger.info("产品额度预警---》调用base服务发送短信：surplusAmount={}templateType={},addressee={}",templateType,addressee);
        List<String> phoneList = DataUtils.split(addressee, ";");
        for(int i = 0;i<phoneList.size();i++){
            String a=phoneList.get(i);
            String b= DataUtils.split(a,"-").get(0);
            phoneList.set(i,b);
            phoneList.remove(a);
        }
        logger.info("产品额度预警---》phoneList：{}",phoneList);
        Integer sendCount = 0;
        if(phoneList != null && phoneList.size() > 0){
            Map<String, Object> param = new HashMap(16);
            param.put("currentTime", DateUtil.formateDate(new Date(), DateUtil.CURRENTTIME_FORMAT));
            param.put("productPeriod", orderPaidMessage.getProductPeriod());
            param.put("productPeriodType", "天");
            param.put("productAbbrName", orderPaidMessage.getProductAbbrName());
            param.put("surplusAmount",surplusAmount);
            param.put("notificationType",templateType);
            for(String phone:phoneList){
                param.put("phone",phone);
                ResponseResult responseResult = baseServiceConsumer.post(URL.MESSAGE_SEND,param);
                if(responseResult.getCode() == ResponseCode.OK){
                    sendCount++;
                }
            }
            return sendCount;
        }
        return 0;
    }
}
