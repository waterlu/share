package cn.zjhf.kingold.product.constant;

import cn.zjhf.kingold.product.util.BizParam;
import cn.zjhf.kingold.product.util.DataUtils;

import java.util.Map;

/**
 * Created by zhangyijie on 2017/8/25.
 */
public class BizDefine {
    public static boolean isFromFrontEndSystem(Map map) {
        BizParam bizParam = new BizParam(map);
        String callSystemID = bizParam.get("callSystemID");

        if(DataUtils.isNotEmpty(callSystemID)) {
            if (callSystemID.equals("1001") || callSystemID.equals("1002") || callSystemID.equals("1003")
                    || callSystemID.equals("3001") || callSystemID.equals("3002")) {
                return true;
            }
        }

        return false;
    }
}
