package cn.zjhf.kingold.product.entity.OutVO;

import cn.zjhf.kingold.common.param.ParamVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.Size;
import java.util.List;
import java.util.Map;

/**
 * @author liuyao
 * @date 2018/3/2
 */
@ApiModel(value = "ProductApiOutVO", description = "产品应用端返回结构")
public class ProductApiOutVO extends ParamVO {
    private Integer count;
    private List<Map> productList;

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public List<Map> getProductList() {
        return productList;
    }

    public void setProductList(List<Map> productList) {
        this.productList = productList;
    }
}
