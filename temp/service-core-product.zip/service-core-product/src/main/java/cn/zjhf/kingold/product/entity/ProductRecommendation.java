package cn.zjhf.kingold.product.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class ProductRecommendation implements Serializable {
    /**
     * 自增主键
     */
    private Long productRecommendationID;

    /**
     * 产品UUID
     */
    private String productUuid;

    /**
     * 推荐产品的类型
     */
    private String productType;

    /**
     * 显示顺序
     */
    private Integer recommendationShowOrder;

    private Integer deleteFlag;

    private Date createTime;

    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public Long getProductRecommendationID() {
        return productRecommendationID;
    }

    public void setProductRecommendationID(Long productRecommendationID) {
        this.productRecommendationID = productRecommendationID;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public Integer getRecommendationShowOrder() {
        return recommendationShowOrder;
    }

    public void setRecommendationShowOrder(Integer recommendationShowOrder) {
        this.recommendationShowOrder = recommendationShowOrder;
    }

    public Integer getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Integer deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}