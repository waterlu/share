package cn.zjhf.kingold.product.entity.InVO;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.product.util.DataUtils;
import com.alibaba.fastjson.annotation.JSONField;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import java.util.Date;

/**
 * Created by zhangyijie on 2017/6/29.
 */
@ApiModel(value = "ReportConditionVO", description = "报表查询条件")
public class ReportConditionVO extends ParamVO {
    @ApiModelProperty(required = true, value = "traceID")
    @NotEmpty
    private String traceID;

    @ApiModelProperty(required = true, value = "报告编号")
    @NotEmpty
    private String reportNo;

    @ApiModelProperty(required = true, value = "productUuid")
    private String productUuid;

    @ApiModelProperty(required = true, value = "产品简称")
    private String productAbbrName;

    @ApiModelProperty(required = true, value = "产品起息日_开始日期")
    private Date productInterestBeginDate;

    @ApiModelProperty(required = true, value = "产品起息日_结束日期")
    private Date productInterestEndDate;

    @ApiModelProperty(required = true, value = "产品到期日_开始日期")
    private Date productExpiringBeginDate;

    @ApiModelProperty(required = true, value = "产品到期日_结束日期")
    private Date productExpiringEndDate;

    @ApiModelProperty(required = true, value = "产品编号")
    private String productCode;

    @ApiModelProperty(required = true, value = "产品状态")
    private Integer productStatus;

    @ApiModelProperty(required = true, value = "起始序号")
    private int beginSN;

    @ApiModelProperty(required = true, value = "结束序号")
    private int endSN;

    @Override
    public String getTraceID() {
        return traceID;
    }

    @Override
    public void setTraceID(String traceID) {
        this.traceID = traceID;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductAbbrName() {
        return productAbbrName;
    }

    public void setProductAbbrName(String productAbbrName) {
        this.productAbbrName = productAbbrName;
    }

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    public Date getProductInterestBeginDate() {
        return productInterestBeginDate;
    }

    public void setProductInterestBeginDate(Date productInterestBeginDate) {
        this.productInterestBeginDate = productInterestBeginDate;
    }

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    public Date getProductInterestEndDate() {
        return productInterestEndDate;
    }

    public void setProductInterestEndDate(Date productInterestEndDate) {
        this.productInterestEndDate = productInterestEndDate;
    }

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    public Date getProductExpiringBeginDate() {
        return productExpiringBeginDate;
    }

    public void setProductExpiringBeginDate(Date productExpiringBeginDate) {
        this.productExpiringBeginDate = productExpiringBeginDate;
    }

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    public Date getProductExpiringEndDate() {
        return productExpiringEndDate;
    }

    public void setProductExpiringEndDate(Date productExpiringEndDate) {
        this.productExpiringEndDate = productExpiringEndDate;
    }

    public String getReportNo() {
        return reportNo;
    }

    public void setReportNo(String reportNo) {
        this.reportNo = reportNo;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public Integer getProductStatus() {
        return productStatus;
    }

    public void setProductStatus(Integer productStatus) {
        this.productStatus = productStatus;
    }

    public int getBeginSN() {
        return beginSN;
    }

    public void setBeginSN(int beginSN) {
        this.beginSN = beginSN;
    }

    public int getEndSN() {
        return endSN;
    }

    public void setEndSN(int endSN) {
        this.endSN = endSN;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(traceID) + ", ");
        sb.append("reportNo:" + DataUtils.toString(reportNo) + ", ");
        sb.append("productUuid:" + DataUtils.toString(productUuid) + ", ");
        sb.append("productAbbrName:" + DataUtils.toString(productAbbrName) + ", ");
        sb.append("productInterestBeginDate:" + DataUtils.toString(productInterestBeginDate) + ", ");
        sb.append("productInterestEndDate:" + DataUtils.toString(productInterestEndDate) + ", ");
        sb.append("productExpiringBeginDate:" + DataUtils.toString(productExpiringBeginDate) + ", ");
        sb.append("productExpiringEndDate:" + DataUtils.toString(productExpiringEndDate) + ", ");
        sb.append("productCode:" + DataUtils.toString(productCode) + ", ");
        sb.append("productStatus:" + DataUtils.toString(productStatus) + ", ");
        sb.append("beginSN:" + DataUtils.toString(beginSN) + ", ");
        sb.append("endSN:" + DataUtils.toString(endSN));
        return sb.toString();
    }
}
