package cn.zjhf.kingold.product.persistence.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.Map;

/**
 * Created by Xiaody on 17/4/13.
 */
@Repository
@Mapper
public interface ProductPrivateFundMapper {
    Integer insert(Map map);

    Map get(@Param("productUuid") String productUuid);

    void update(Map map);

    void updateStatus(Map map);
}
