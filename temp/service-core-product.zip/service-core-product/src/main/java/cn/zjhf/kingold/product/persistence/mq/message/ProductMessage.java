package cn.zjhf.kingold.product.persistence.mq.message;

import cn.zjhf.kingold.rocketmq.base.MQMessage;

import java.math.BigDecimal;

/**
 * Created by Xiaody on 17/7/27.
 */
public class ProductMessage implements MQMessage{

    private String productUuid;

    private String productType;

    private String productName;

    private Integer productPeriod;

    private BigDecimal annualInterestRate;

    private String productInterestType;

    /**
     * 微信信息发送标识 1.允许、2、不允许
     */
    private Integer wechatSendMark;

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Integer getProductPeriod() {
        return productPeriod;
    }

    public void setProductPeriod(Integer productPeriod) {
        this.productPeriod = productPeriod;
    }

    public BigDecimal getAnnualInterestRate() {
        return annualInterestRate;
    }

    public void setAnnualInterestRate(BigDecimal annualInterestRate) {
        this.annualInterestRate = annualInterestRate;
    }

    public String getProductInterestType() {
        return productInterestType;
    }

    public void setProductInterestType(String productInterestType) {
        this.productInterestType = productInterestType;
    }

    public Integer getWechatSendMark() {
        return wechatSendMark;
    }

    public void setWechatSendMark(Integer wechatSendMark) {
        this.wechatSendMark = wechatSendMark;
    }

    @Override
    public String getKey() {
        return getProductUuid();
    }
}
