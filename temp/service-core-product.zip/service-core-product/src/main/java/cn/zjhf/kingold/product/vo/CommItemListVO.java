package cn.zjhf.kingold.product.vo;

import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.product.util.DataUtils;
import io.swagger.annotations.ApiModelProperty;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangyijie on 2017/8/23.
 * 通用列表泛型类
 */
public class CommItemListVO<T> extends ParamVO {
    @ApiModelProperty(required = true, value = "总记录数")
    private int count;

    @ApiModelProperty(required = true, value = "返回列表")
    private List<T> list;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public List<T> getList() {
        return list;
    }

    public void setList(List<T> list) {
        this.list = list;
    }

    public void addItem(T item) {
        if(list==null) {
            list = new ArrayList<T>();
        }

        list.add(item);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("traceID:" + DataUtils.toString(getTraceID()) + ", ");
        sb.append("count:" + DataUtils.toString(count) + ", ");
        sb.append("list:" + DataUtils.toString(list));
        return sb.toString();
    }

    public CommItemListVO(int count, List<T> list) {
        this.count = count;
        this.list = list;
    }

    public CommItemListVO() {
    }
}
