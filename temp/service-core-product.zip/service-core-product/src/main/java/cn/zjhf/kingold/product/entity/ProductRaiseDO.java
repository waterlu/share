package cn.zjhf.kingold.product.entity;

import java.math.BigDecimal;

/**
 * @author lutiehua
 * @date 2018/3/6
 */
public class ProductRaiseDO {

    /**
     * 产品UUID
     *
     */
    private String productUuid;

    /**
     * 订单金额
     */
    private BigDecimal amount;


    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
}