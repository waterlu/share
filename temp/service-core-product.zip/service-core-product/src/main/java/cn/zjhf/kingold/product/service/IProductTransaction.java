package cn.zjhf.kingold.product.service;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.product.dto.ProductRemainDTO;

/**
 * @author lutiehua
 * @date 2018/3/27
 */
public interface IProductTransaction {

    int updateRaise(ProductRemainDTO productRemain) throws BusinessException;

}
