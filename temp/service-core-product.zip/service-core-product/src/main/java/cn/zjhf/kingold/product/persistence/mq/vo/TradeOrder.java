package cn.zjhf.kingold.product.persistence.mq.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author 
 */
public class TradeOrder implements Serializable {
    /**
     * 产品订单编号
     */
    private String orderBillCode;

    /**
     * 用户UUID
     */
    private String userUuid;

    /**
     * 用户类型
     */
    private Short userType;

    /**
     * 投资人所属机构UUID
     */
    private String investorOrganizationUuid;

    /**
     * 真实姓名
     */
    private String userName;

    /**
     * 手机号码
     */
    private String userPhone;

    /**
     * 账户UUID
     */
    private String accountUuid;

    /**
     * 托管机构用户账号
     */
    private String accountNo;

    /**
     * 交易渠道：1,app(IOS); 2,app(安卓); 其他
     */
    private String transactionChannel;

    /**
     * 交易时间
     */
    private Date transactionTime;

    /**
     * 产品UUID
     */
    private String productUuid;

    /**
     * 产品编码
     */
    private String productCode;

    /**
     * 产品简称
     */
    private String productAbbrName;

    /**
     * 产品预计年化收益率(冗余)
     */
    private BigDecimal productAnnualInterestRate;

    /**
     * 产品起息日/成立日, 格式为 YYYYMMDD
     */
    private Integer productInterestDate;

    /**
     * 产品到期日, 格式为 YYYYMMDD
     */
    private Integer productExpiringDate;

    /**
     * 预期收款日, 格式为 YYYYMMDD
     */
    private Integer productPaymentDate;

    /**
     * 订单金额，订单金额 = 实缴金额 + 营销费用；订单金额 = 产品份额 * 产品单价
     */
    private BigDecimal orderAmount;

    /**
     * 预期收益
     */
    private BigDecimal expectedProfitAmount;

    /**
     * 实缴金额
     */
    private BigDecimal paidAmount;

    /**
     * 营销费用
     */
    private BigDecimal marketingAmount;

    /**
     * 产品单价，默认是1元一份
     */
    private BigDecimal productPrice;

    /**
     * 产品份额
     */
    private BigDecimal orderShare;

    /**
     * 投资收益，每日日终更新
     */
    private BigDecimal profitAmount;

    /**
     * 兑付金额
     */
    private BigDecimal cashAmount;

    /**
     * 订单状态 1创建，2已付款，3产品成立，4已清算，5撤销
     */
    private Byte orderStatus;

    /**
     * 付款时间
     */
    private Date payedTime;

    /**
     * 营销费用付款时间
     */
    private Date marketingPaidTime;

    /**
     * 清算时间
     */
    private Date clearTime;

    /**
     * 撤销原因 1 自助撤销；2 流标；3 未付款撤销
     */
    private Byte cancelReason;

    /**
     * 撤销时间
     */
    private Date cancelTime;

    /**
     * 适用策略列表，多个策略之间用英文","间隔
     */
    private String strategyIds;

    /**
     * 签名
     */
    private String signature;

    /**
     * 删除标记 0未删除，1已删除
     */
    private Byte deleteFlag;

    private Date createTime;

    private Date updateTime;

    /**
     * 营销加息金额
     */
    private BigDecimal marketingRateAmount;

    /**
     * 产品期限类型： Y(year,年)； M(month,月)； W(week,周)； D(day,自然日)
     */
    private String productPeriodType;

    /**
     * 产品期限
     */
    private Integer productPeriod;


    /**
     * 所属顶级理财师UUID
     *
     */
    private String serviceUserUuid;
    /**
     * 所属顶级理财师组织机构path
     */
    private String serviceUserOrgPath;

    public String getServiceUserUuid() {
        return serviceUserUuid;
    }

    public void setServiceUserUuid(String serviceUserUuid) {
        this.serviceUserUuid = serviceUserUuid;
    }

    public String getServiceUserOrgPath() {
        return serviceUserOrgPath;
    }

    public void setServiceUserOrgPath(String serviceUserOrgPath) {
        this.serviceUserOrgPath = serviceUserOrgPath;
    }

    private static final long serialVersionUID = 1L;

    public String getOrderBillCode() {
        return orderBillCode;
    }

    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public Short getUserType() {
        return userType;
    }

    public void setUserType(Short userType) {
        this.userType = userType;
    }

    public String getInvestorOrganizationUuid() {
        return investorOrganizationUuid;
    }

    public void setInvestorOrganizationUuid(String investorOrganizationUuid) {
        this.investorOrganizationUuid = investorOrganizationUuid;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    public String getAccountUuid() {
        return accountUuid;
    }

    public void setAccountUuid(String accountUuid) {
        this.accountUuid = accountUuid;
    }

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    public String getTransactionChannel() {
        return transactionChannel;
    }

    public void setTransactionChannel(String transactionChannel) {
        this.transactionChannel = transactionChannel;
    }

    public Date getTransactionTime() {
        return transactionTime;
    }

    public void setTransactionTime(Date transactionTime) {
        this.transactionTime = transactionTime;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductAbbrName() {
        return productAbbrName;
    }

    public void setProductAbbrName(String productAbbrName) {
        this.productAbbrName = productAbbrName;
    }

    public BigDecimal getProductAnnualInterestRate() {
        return productAnnualInterestRate;
    }

    public void setProductAnnualInterestRate(BigDecimal productAnnualInterestRate) {
        this.productAnnualInterestRate = productAnnualInterestRate;
    }

    public Integer getProductInterestDate() {
        return productInterestDate;
    }

    public void setProductInterestDate(Integer productInterestDate) {
        this.productInterestDate = productInterestDate;
    }

    public Integer getProductExpiringDate() {
        return productExpiringDate;
    }

    public void setProductExpiringDate(Integer productExpiringDate) {
        this.productExpiringDate = productExpiringDate;
    }

    public Integer getProductPaymentDate() {
        return productPaymentDate;
    }

    public void setProductPaymentDate(Integer productPaymentDate) {
        this.productPaymentDate = productPaymentDate;
    }

    public BigDecimal getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(BigDecimal orderAmount) {
        this.orderAmount = orderAmount;
    }

    public BigDecimal getExpectedProfitAmount() {
        return expectedProfitAmount;
    }

    public void setExpectedProfitAmount(BigDecimal expectedProfitAmount) {
        this.expectedProfitAmount = expectedProfitAmount;
    }

    public BigDecimal getPaidAmount() {
        return paidAmount;
    }

    public void setPaidAmount(BigDecimal paidAmount) {
        this.paidAmount = paidAmount;
    }

    public BigDecimal getMarketingAmount() {
        return marketingAmount;
    }

    public void setMarketingAmount(BigDecimal marketingAmount) {
        this.marketingAmount = marketingAmount;
    }

    public BigDecimal getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(BigDecimal productPrice) {
        this.productPrice = productPrice;
    }

    public BigDecimal getOrderShare() {
        return orderShare;
    }

    public void setOrderShare(BigDecimal orderShare) {
        this.orderShare = orderShare;
    }

    public BigDecimal getProfitAmount() {
        return profitAmount;
    }

    public void setProfitAmount(BigDecimal profitAmount) {
        this.profitAmount = profitAmount;
    }

    public BigDecimal getCashAmount() {
        return cashAmount;
    }

    public void setCashAmount(BigDecimal cashAmount) {
        this.cashAmount = cashAmount;
    }

    public Byte getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(Byte orderStatus) {
        this.orderStatus = orderStatus;
    }

    public Date getPayedTime() {
        return payedTime;
    }

    public void setPayedTime(Date payedTime) {
        this.payedTime = payedTime;
    }

    public Date getMarketingPaidTime() {
        return marketingPaidTime;
    }

    public void setMarketingPaidTime(Date marketingPaidTime) {
        this.marketingPaidTime = marketingPaidTime;
    }

    public Date getClearTime() {
        return clearTime;
    }

    public void setClearTime(Date clearTime) {
        this.clearTime = clearTime;
    }

    public Byte getCancelReason() {
        return cancelReason;
    }

    public void setCancelReason(Byte cancelReason) {
        this.cancelReason = cancelReason;
    }

    public Date getCancelTime() {
        return cancelTime;
    }

    public void setCancelTime(Date cancelTime) {
        this.cancelTime = cancelTime;
    }

    public String getStrategyIds() {
        return strategyIds;
    }

    public void setStrategyIds(String strategyIds) {
        this.strategyIds = strategyIds;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public BigDecimal getMarketingRateAmount() {
        return marketingRateAmount;
    }

    public void setMarketingRateAmount(BigDecimal marketingRateAmount) {
        this.marketingRateAmount = marketingRateAmount;
    }

    public String getProductPeriodType() {
        return productPeriodType;
    }

    public void setProductPeriodType(String productPeriodType) {
        this.productPeriodType = productPeriodType;
    }

    public Integer getProductPeriod() {
        return productPeriod;
    }

    public void setProductPeriod(Integer productPeriod) {
        this.productPeriod = productPeriod;
    }

}