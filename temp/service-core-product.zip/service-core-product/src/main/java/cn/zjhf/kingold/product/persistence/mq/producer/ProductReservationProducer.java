package cn.zjhf.kingold.product.persistence.mq.producer;

import cn.zjhf.kingold.product.persistence.mq.message.ProductReservationMessage;
import cn.zjhf.kingold.rocketmq.annotation.RocketMQProducer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQProducer;

/**
 * Created by Xiaody on 17/7/14.
 */
@RocketMQProducer(topic = "product", tag = "reservation")
public class ProductReservationProducer extends AbstractMQProducer<ProductReservationMessage> {
}
