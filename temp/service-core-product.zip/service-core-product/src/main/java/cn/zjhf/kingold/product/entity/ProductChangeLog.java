package cn.zjhf.kingold.product.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class ProductChangeLog implements Serializable {
    /**
     * 自增主键
     */
    private Long productChangeLogID;

    /**
     * 产品UUID
     */
    private String productUuid;

    /**
     * 产品名称
     */
    private String productName;

    /**
     * 修改产品的类型
     */
    private String productType;

    /**
     * 操作类型
     */
    private Integer productChangeType;

    /**
     * 操作内容
     */
    private String productChangeContent;

    private Date createTime;

    private String createBy;

    private static final long serialVersionUID = 1L;

    public Long getProductChangeLogID() {
        return productChangeLogID;
    }

    public void setProductChangeLogID(Long productChangeLogID) {
        this.productChangeLogID = productChangeLogID;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public Integer getProductChangeType() {
        return productChangeType;
    }

    public void setProductChangeType(Integer productChangeType) {
        this.productChangeType = productChangeType;
    }

    public String getProductChangeContent() {
        return productChangeContent;
    }

    public void setProductChangeContent(String productChangeContent) {
        this.productChangeContent = productChangeContent;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }
}