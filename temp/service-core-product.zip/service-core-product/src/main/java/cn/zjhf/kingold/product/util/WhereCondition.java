package cn.zjhf.kingold.product.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * Created by zhangyijie on 2017/5/18.
 */
public class WhereCondition {
    protected static final Logger logger = LoggerFactory.getLogger(WhereCondition.class);

    private static final String WHERE = " WHERE ";
    private static final String DESC = " DESC ";
    private static final String ASC = " ASC ";

    private StringBuilder where = new StringBuilder();

    public WhereCondition() {
        where.append(WHERE);
    }

    private void and() {
        if (!where.toString().equals(WHERE))
            where.append(" AND ");
    }

    private void or() {
        if (!where.toString().equals(WHERE))
            where.append(" OR ");
    }

    private void all() {
        if (where.toString().equals(WHERE))
            where.append(" 1 ");
    }

    public static String toSQLStr(String strValue) {
        if (DataUtils.isEmpty(strValue))
            strValue = "' '";

        return "'" + strValue.trim() + "'";
    }

    public void setCondi(String condi) {
        if ((condi != null) && (condi.trim().length() > 0)) {
            and();
            where.append(condi);
        }
    }

    public void setCondiEx(String condi) {
        if ((condi != null) && (condi.trim().length() > 0)) {
            where.append(" " + condi);
        }
    }

    public void setCondi(String FieldName, String value, boolean ifCheck) {
        if(ifCheck && DataUtils.isEmpty(value)) {
            return;
        }

        setCondi(FieldName,value);
    }

    public void setCondi(String FieldName, String value) {
        if ((value != null) && (value.length() > 0)) {
            and();
            where.append(FieldName).append(" = ").append(toSQLStr(value));
        }
    }

    public void setCondi(String FieldName, int value, boolean ifCheck) {
        if(ifCheck && (value <= 0)) {
            return;
        }

        setCondi(FieldName,value);
    }

    public String toAnd() {
        String strWhere = toString();
        return strWhere.replace(WHERE, " AND ");
    }

    public void setCondi(String FieldName, int value) {
        and();
        where.append(FieldName).append(" = ").append(value);
    }

    public void setCondi(String FieldName, long value, boolean ifCheck) {
        if(ifCheck && (value <= 0)) {
            return;
        }

        setCondi(FieldName,value);
    }

    public void setCondi(String FieldName, long value) {
        and();
        where.append(FieldName).append(" = ").append(value);
    }

    public void setCondi(String FieldName, double value, boolean ifCheck) {
        if(ifCheck && (value <= 0)) {
            return;
        }

        setCondi(FieldName,value);
    }

    public void setCondi(String FieldName, double value) {
        and();
        where.append(FieldName).append(" = ").append(value);
    }

    public void setCondi(String FieldName, Date value, boolean ifCheck) {
        if(ifCheck && (value == null)) {
            return;
        }

        setCondi(FieldName,value);
    }

    public void setCondi(String FieldName, Date value) {
        if(null == value) {
            return;
        }

        and();
        where.append(FieldName).append(" = ").append(DataUtils.toString(value));
    }

    public void setCondi(String FieldName, BigDecimal value) {
        and();
        where.append(FieldName).append(" = ").append(value.toString());
    }

    public void setBetween(String FieldName, int bValue, int eValue) {
        setBetween(FieldName, String.valueOf(bValue), String.valueOf(eValue));
    }

    public void setBetween(String FieldName, Date bValue, Date eValue) {
        if((bValue != null) && (eValue != null)) {
            setBetween(FieldName, DataUtils.toString(bValue), DataUtils.toString(eValue));
        }
    }

    public void setBetween(String FieldName, double bValue, double eValue) {
        setBetween(FieldName, String.valueOf(bValue), String.valueOf(eValue));
    }

    public void setBetween(String FieldName, String bValue, String eValue) {
        and();
        where.append(FieldName).append(" BETWEEN ").append(toSQLStr(bValue)).append(" AND ")
                .append(toSQLStr(eValue));
    }

    public void setLike(String FieldName, String value) {
        if (DataUtils.isNotEmpty(FieldName) && DataUtils.isNotEmpty(value)) {
            and();

            where.append(FieldName).append(" LIKE ");
            where.append(toSQLStr("%" + value.trim() + "%"));
        }
    }

    public void setInInt(String FeildName, Integer... values) {
        if (values != null) {
            setInInt(FeildName, Arrays.asList(values));
        }
    }

    public void setNotInInt(String FeildName, Integer... values) {
        if (values != null) {
            setNotInInt(FeildName, Arrays.asList(values));
        }
    }

    public static String intsToSql(Integer... values) {
        return intListToSql(Arrays.asList(values));
    }

    public static String intListToSql(List<Integer> items) {
        StringBuilder str = new StringBuilder("");
        if (items == null)
            return str.toString();

        int len = items.size();

        for (int i = 0; i < len; i++) {
            str.append(items.get(i));

            if (i != (len - 1)) {
                str.append(",");
            }
        }

        return str.toString();
    }

    public static String stringListToSql(List<String> items) {
        StringBuilder str = new StringBuilder("");
        if (items == null)
            return str.toString();

        int len = items.size();

        for (int i = 0; i < len; i++) {
            if(DataUtils.isNotEmpty(items.get(i))) {
                str.append(toSQLStr(items.get(i)));

                if (i != (len - 1)) {
                    str.append(",");
                }
            }
        }

        return str.toString();
    }

    public void setInInt(String FeildName, List<Integer> values) {
        if ((values == null) || (values.size() <= 0))
            return;
        and();
        where.append(FeildName).append(" IN ( ");
        where.append(intListToSql(values));
        where.append(" ) ");
    }

    public void setNotInInt(String FeildName, List<Integer> values) {
        if ((values == null) || (values.size() <= 0))
            return;
        and();
        where.append(FeildName).append(" NOT IN ( ");
        where.append(intListToSql(values));
        where.append(" ) ");
    }

    public void setInString(String FeildName, List<String> values) {
        if ((values == null) || (values.size() <= 0))
            return;
        and();
        where.append(FeildName).append(" IN ( ");
        where.append(stringListToSql(values));
        where.append(" ) ");
    }

    // 排序条件_降序
    public void setOrderByDesc(String... args) {
        all();

        int len = args.length;
        if (len > 0) {
            where.append(" ORDER BY ");

            int i = 0;
            for (String arg : args) {
                i++;
                if (i != len) {
                    where.append(arg).append(", ");
                } else {
                    where.append(arg).append(" ");
                }
            }

            where.append(DESC);
        }
    }


    // 排序条件_降序
    public void setOrderByAsc(String... args) {
        all();

        int len = args.length;
        if (len > 0) {
            where.append(" ORDER BY ");

            int i = 0;
            for (String arg : args) {
                i++;
                if (i != len) {
                    where.append(arg).append(", ");
                } else {
                    where.append(arg).append(" ");
                }
            }

            where.append(ASC);
        }
    }

    // 分页条件
    public String setPage(int beginSn, int endSn, String... args) {
        if ((endSn < beginSn)
                || ((endSn == beginSn) && endSn == 0)) {
            return "";
        }

        all();

        int len = args.length;
        if (len > 0) {
            where.append(" ORDER BY ");

            int i = 0;
            for (String arg : args) {
                i++;
                if (i != len) {
                    where.append(arg).append(", ");
                } else {
                    where.append(arg).append(" ");
                }
            }

            where.append(DESC);
        }

        if (beginSn <= 0)
            beginSn = 1;

        where.append(" LIMIT ").append(beginSn - 1).append(", ")
                .append(endSn - beginSn + 1);
        return where.toString();
    }

    public void noDelete() {
        setCondi("delete_flag", 0);
    }

    public String getCondition() {
        return toString();
    }

    public WhereCondition clear() {
        where = new StringBuilder();
        where.append(WHERE);
        return this;
    }

    @Override
    public String toString() {
        all();
        return where.append(" ").toString();
    }
}