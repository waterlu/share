package cn.zjhf.kingold.product.persistence.dao;

import cn.zjhf.kingold.product.entity.ProductRaise;
import cn.zjhf.kingold.product.entity.ProductUserRaiseDO;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

/**
 * @author lutiehua
 * @date 2018/3/6
 */
@Repository
public interface ProductRaiseMapper {

    /**
     * 记录产品募集流水
     *
     * @param productRaise
     * @return
     */
    int raise(ProductRaise productRaise);

    /**
     * 回滚产品募集流水
     *
     * @param productRaise
     * @return
     */
    int restore(ProductRaise productRaise);

    /**
     * 查询用户累计投资金额
     *
     * @param productUserRaiseDO
     * @return
     */
    BigDecimal getUserTotalRaiseAmount(ProductUserRaiseDO productUserRaiseDO);

    /**
     * 汇总回滚的募集金额
     *
     * @param updateUuid
     * @return
     */
    BigDecimal getUpdatedInfo(String updateUuid);

}
