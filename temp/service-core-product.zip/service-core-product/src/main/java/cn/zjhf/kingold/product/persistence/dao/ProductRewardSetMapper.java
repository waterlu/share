package cn.zjhf.kingold.product.persistence.dao;

import cn.zjhf.kingold.product.entity.ProductRewardSet;
import cn.zjhf.kingold.product.entity.ProductRewardSetExample;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
@Mapper
public interface ProductRewardSetMapper {
    long countByExample(ProductRewardSetExample example);

    int deleteByExample(ProductRewardSetExample example);

    int deleteByPrimaryKey(Long productAwardId);

    int insert(ProductRewardSet record);

    int insertSelective(Map map);

    List<ProductRewardSet> selectByExample(ProductRewardSetExample example);

    ProductRewardSet selectByPrimaryKey(Long productAwardId);

    int updateByExampleSelective(@Param("record") ProductRewardSet record, @Param("example") ProductRewardSetExample example);

    int updateByExample(@Param("record") ProductRewardSet record, @Param("example") ProductRewardSetExample example);

    int updateByPrimaryKeySelective(ProductRewardSet record);

    int updateByPrimaryKey(ProductRewardSet record);

    List<Map> getList(Map map);

    /**
     * 获取产品奖励细则列表
     * @param map
     * @return
     */
    List<Map> getRewardList(Map map);

    /**
     * 获取产品奖励细则数量
     * @param map
     * @return
     */
    Integer getRewardCount(Map map);

    /**
     * 获取产品奖励细则列表
     * @param map
     * @return
     */
    List<Map> getProductTalentRewardList(Map map);

    /**
     * 获取产品奖励细则数量
     * @param map
     * @return
     */
    Integer getProductTalentRewardCount(Map map);


    /**
     * 通过产品uuid获取奖励明细
     * @param productUuid
     * @return
     */
    ProductRewardSet selectByProductUuid(String productUuid);

    /**
     * 修改奖励
     * @param map
     */
    void update(Map map);

    int batchInsert(List<ProductRewardSet> list);
}