package cn.zjhf.kingold.product.service;

import cn.zjhf.kingold.common.exception.BusinessException;

import java.util.List;
import java.util.Map;

/**
 * Created by Xiaody on 17/4/14.
 */
public interface IRecommendationService {
    Long insert(Map map) throws BusinessException;

    void update(Map map) throws BusinessException;

    List<Map> getList(Map map) throws BusinessException;

    Integer getCount(Map map) throws BusinessException;

    Map getRecommendation(Map map) throws BusinessException;

    Map getRecommendProduct(Map map) throws BusinessException;

    Long updateByProductUuid(Map map) throws BusinessException;

    List<Map> getRecommendProductList(Map map) throws BusinessException;
}
