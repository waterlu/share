package cn.zjhf.kingold.product.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author 
 */
public class ProductProgress implements Serializable {
    /**
     * 自增主键
     */
    private Long productProgressID;

    /**
     * 产品UUID
     */
    private String productUuid;

    /**
     * 产品总金额
     */
    private BigDecimal productScale;

    /**
     * 产品已募集金额
     */
    private BigDecimal productAccumulation;

    /**
     * 产品募集调整金额（人工调整）
     */
    private BigDecimal productManual;

    /**
     * 删除标识
     */
    private Byte deleteFlag;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public Long getProductProgressID() {
        return productProgressID;
    }

    public void setProductProgressID(Long productProgressID) {
        this.productProgressID = productProgressID;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    public BigDecimal getProductScale() {
        return productScale;
    }

    public void setProductScale(BigDecimal productScale) {
        this.productScale = productScale;
    }

    public BigDecimal getProductAccumulation() {
        return productAccumulation;
    }

    public void setProductAccumulation(BigDecimal productAccumulation) {
        this.productAccumulation = productAccumulation;
    }

    public BigDecimal getProductManual() {
        return productManual;
    }

    public void setProductManual(BigDecimal productManual) {
        this.productManual = productManual;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}