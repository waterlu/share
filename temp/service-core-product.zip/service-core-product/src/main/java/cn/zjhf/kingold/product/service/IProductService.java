package cn.zjhf.kingold.product.service;


import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.product.dto.ProductRemainDTO;
import cn.zjhf.kingold.product.entity.InVO.LstProductChannelRelationalConditionVO;
import cn.zjhf.kingold.product.entity.InVO.LstProductConditionVO;
import cn.zjhf.kingold.product.entity.InVO.ProductChannelRelationalVO;
import cn.zjhf.kingold.product.entity.OutVO.ProductChannelRelationalItemListVO;
import cn.zjhf.kingold.product.entity.ProductRewardSet;

import java.util.List;
import java.util.Map;

/**
 * Created by Xiaody on 17/4/12.
 */
public interface IProductService {

    String insert(Map map) throws BusinessException;

    Map get(String productUuid) throws BusinessException;

    void update(Map map) throws BusinessException;

    List<Map> getList(Map map) throws BusinessException;

    Integer getCount(Map map) throws BusinessException;

    Map getPrivateFund(String productUuid) throws BusinessException;

    Map getFixedIncome(String productUuid) throws BusinessException;

    void updateAccumulation(String productUuid,Double amount) throws BusinessException;

    List<Map> getPrivateFundList(Map map) throws BusinessException;

    Integer getPrivateFundCount(Map map) throws BusinessException;

    List<Map> getFixedIncomeList(Map map) throws BusinessException;

    List<Map> getVipFixedIncome() throws BusinessException;

    Integer getFixedIncomeCount(Map map) throws BusinessException;

    void topUpdate(Map map) throws BusinessException;

    List<Map> getProductRewardList(Map map) throws BusinessException;

    List<Map> lstByCondition(LstProductConditionVO lstCondition) throws BusinessException;

    Integer countByCondition(LstProductConditionVO lstCondition) throws BusinessException;

    Integer getProductRewardCount(Map map) throws BusinessException;

    /**
     * @param productUuid
     * @return Map
     * @throws BusinessException
     * 获取产品和调整募集金额
     */
    Map getProductProgress(String productUuid) throws BusinessException;

    /**
     * 添加 产品-渠道 关联关系
     * @param relationalInfo
     * @throws BusinessException
     */
    void addProductChannelRelational(ProductChannelRelationalVO relationalInfo) throws BusinessException;

    /**
     * 查询 产品-渠道 关联关系列表
     * @param lstCondition
     * @return
     * @throws BusinessException
     */
    ProductChannelRelationalItemListVO lstProductChannelRelationals(LstProductChannelRelationalConditionVO lstCondition) throws BusinessException;

    /**
     * 根据渠道的Uuid取得其相关联的产品
     * @param channelUuid
     * @return
     * @throws BusinessException
     */
    List<String> lstRelationProducts(String channelUuid) throws BusinessException;
    /**
     * 获取限制子产品集合
     * @param map
     * @return
     * @throws BusinessException
     */
    List<Map> getFixedProducts(Map map) throws BusinessException;

    /**
     * 获取定期产品和渠道信息
     */
    Map getFixedIncomeChannel(Map map) throws BusinessException;

    /**
     * 获取渠道下不存在产品列表
     */
    List<Map> channelNonExistProductList(Map map) throws BusinessException;

    /**
     * 获取渠道下不存在产品数量
     */
    Integer channelNonExistProductCount(Map map) throws BusinessException;

    ProductRewardSet getRewardByProductUuid(String productUuid) throws BusinessException;

    /**
     * 获取产品达人奖励细则列表
     * @param map
     * @return
     * @throws BusinessException
     */
    List<Map> getProductTalentRewardList(Map map) throws BusinessException;

    /**
     * 获取产品达人奖励细则数量
     * @param map
     * @return
     * @throws BusinessException
     */
    Integer getProductTalentRewardCount(Map map) throws BusinessException;

    void transferRewardData(Map map) throws BusinessException;

    /**
     * 更新产品剩余募集额度
     *
     * @param productRemain
     * @return
     * @throws BusinessException
     */
    int updateRaise(ProductRemainDTO productRemain) throws BusinessException;

    /**
     * 补偿产品剩余募集额度
     *
     * @param productRemain
     * @return
     */
    int restoreRemain(ProductRemainDTO productRemain) throws BusinessException;

    void dealProductReward(List<Map> productList) throws BusinessException;

}