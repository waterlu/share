package cn.zjhf.kingold.product.persistence.dao;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
@Mapper
public interface ProductRecommendationMapper {
    Integer insert(Map map);

    void update(Map map);

    List<Map> getList(Map map);

    Integer getCount(Map map);

    List<Map> getRecommendProduct(Map map);

    @Update("update product_recommendation set update_time=now() where product_uuid = #{productUuid}")
    Long updateByProductUuid(@Param("productUuid") String productUuid);

    List<Map> getRecommendProductList(Map map);
}