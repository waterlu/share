package cn.zjhf.kingold.product.persistence.dao;

import cn.zjhf.kingold.product.entity.ProductSortModel;
import cn.zjhf.kingold.product.util.QueryUtils;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
@Mapper
public interface ProductMapper {
    Integer insert(Map map);

    Map get(@Param("productUuid") String productUuid);

    void update(Map map);

    void updateStatus(Map map);

    Map getPrivateFund(@Param("productUuid") String productUuid);

    Map getFixedIncome(@Param("productUuid") String productUuid);

    Map getNoviceLabelProduct();

    List<Map> getList(Map map);

    @Select("${condition}")
    List<Map> lstByCondition(QueryUtils condition);

    @Select("${condition}")
    Integer countByCondition(QueryUtils condition);

    @Select("SELECT order_bill_code FROM kingold_trade.trade_order WHERE user_uuid = #{userUuid} AND order_status NOT IN (1,9) AND delete_flag = 0 LIMIT 0,1")
    String havaValidOrder(@Param("userUuid") String userUuid);

    Integer getCount(Map map);

    List<Map> getPrivateFundList(Map map);

    Integer getPrivateFundCount(Map map);

    @Select("SELECT * FROM product t, product_fixed_income t1, product_progress t2 " +
            " WHERE t.product_uuid = t1.product_uuid AND t.product_uuid = t2.product_uuid " +
            " AND t.product_on_status = 2 AND t.delete_flag = 0 " +
            " AND t.vip_flag = 1 AND t.product_on_status IN (2,1,3,4,5,6,8,9) " +
            " ORDER BY FIELD(t.product_on_status, 2,1,3,4,5,6,8,9), t.product_open_time DESC " +
            " LIMIT 0,1")
    @ResultMap("fixedIncomeMap")
    List<Map> getVipFixedIncomeList();

    List<Map> getFixedIncomeList(Map map);

    Integer getFixedIncomeCount(Map map);

    void topUpdate(Map map);

    List<Map> getRewardList(Map map);

    Integer getRewardCount(Map map);

    /**
     * @param productUuid
     * @return Map
     * 获取产品和调整募集金额
     */
    Map getProductProgress(String productUuid);
    /**
     * 获取限制子产品集合
     * @param map
     * @return
     */
    List<Map> getFixedProducts(Map map);

    /**
     * 定期产品和渠道信息
     */
    Map getFixedIncomeChannel(Map map);

    /**
     * 获取渠道下不存在产品列表
     */
    List<Map> channelNonExistProductList(Map map);

    /**
     * 获取渠道下不存在产品数量
     */
    Integer channelNonExistProductCount(Map map);

    List<ProductSortModel> getApiOnlineFixedProduct(Map map);

    List<Map> getApiOfflineFixedProduct(Map map);

    Integer getApiOfflineFixedProductCount(Map map);

    List<Map> getProductByProductUuids(Map map);

}