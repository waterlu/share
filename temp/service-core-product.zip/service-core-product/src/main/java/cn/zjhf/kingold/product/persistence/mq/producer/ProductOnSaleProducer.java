package cn.zjhf.kingold.product.persistence.mq.producer;

import cn.zjhf.kingold.product.persistence.mq.message.ProductMessage;
import cn.zjhf.kingold.rocketmq.annotation.RocketMQProducer;
import cn.zjhf.kingold.rocketmq.base.AbstractMQProducer;

/**
 * Created by liuyao on 2017/8/27.
 */
@RocketMQProducer(topic = "product",tag = "onsale")
public class ProductOnSaleProducer extends AbstractMQProducer<ProductMessage>{
}
