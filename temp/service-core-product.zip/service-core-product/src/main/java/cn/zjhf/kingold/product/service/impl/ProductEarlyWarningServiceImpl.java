package cn.zjhf.kingold.product.service.impl;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.product.dto.ProductEarlyWarningDTO;
import cn.zjhf.kingold.product.persistence.dao.ProductEarlyWarningMapper;
import cn.zjhf.kingold.product.service.IProductEarlyWarningService;
import cn.zjhf.kingold.product.vo.CommItemListVO;
import cn.zjhf.kingold.product.vo.ProductEarlyWarningVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author xiexiaojie
 *         2018/3/26.
 */
@Service
public class ProductEarlyWarningServiceImpl implements IProductEarlyWarningService {

    @Autowired
    ProductEarlyWarningMapper productEarlyWarningMapper;

    /**
     * 产品额度预警-列表
     * @param dto
     * @return
     * @throws BusinessException
     */
    @Override
    public CommItemListVO<ProductEarlyWarningVO> getList(ProductEarlyWarningDTO dto) throws BusinessException {
        return new CommItemListVO<ProductEarlyWarningVO>(productEarlyWarningMapper.count(dto), productEarlyWarningMapper.list(dto));
    }

}
