package cn.zjhf.kingold.product.dto;

import cn.zjhf.kingold.common.param.ParamVO;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
 * @author lutiehua
 * @date 2017/12/18
 */
public class ProductRemainDTO extends ParamVO {

    /**
     * 产品UUID
     *
     */
    @ApiModelProperty(value = "产品UUID", required = true)
    private String productUuid;

    /**
     * 用户UUID
     *
     */
    @ApiModelProperty(value = "用户UUID", required = true)
    @NotBlank
    private String userUuid;

    /**
     * 订单号
     *
     */
    @ApiModelProperty(value = "订单号", required = true)
    @NotBlank
    private String orderBillCode;

    /**
     * 募集金额
     */
    @NotNull
    @ApiModelProperty(value = "募集金额", required = true)
    private BigDecimal amount;


    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(String userUuid) {
        this.userUuid = userUuid;
    }

    public String getOrderBillCode() {
        return orderBillCode;
    }

    public void setOrderBillCode(String orderBillCode) {
        this.orderBillCode = orderBillCode;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getProductUuid() {
        return productUuid;
    }

    public void setProductUuid(String productUuid) {
        this.productUuid = productUuid;
    }

    @Override
    public String toString() {
        return "ProductRemainDTO{" +
                "userUuid='" + userUuid + '\'' +
                ", orderBillCode='" + orderBillCode + '\'' +
                ", amount=" + amount +
                ", productUuid='" + productUuid + '\'' +
                '}';
    }
}
