package cn.zjhf.kingold.product.constant;

/**
 * Created by Xiaody on 17/6/14.
 */
public interface URL {

    /**
     * 获取用户信息
     */
    String GET_USER = "/user/%s";

    /**
     * 获取baofoo账户
     */
    String URL_ACCOUNT_GET_BAOFOO = "/accountbaofoo";

    /**
     * 通过模版发送消息
     */
    String MESSAGE_SEND="/message/send";
}
