package cn.zjhf.kingold.product.web;

import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.product.dto.ProductEarlyWarningDTO;
import cn.zjhf.kingold.product.service.IProductEarlyWarningService;
import cn.zjhf.kingold.product.vo.CommItemListVO;
import cn.zjhf.kingold.product.vo.ProductEarlyWarningVO;
import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author xiexiaojie
 *         2018/3/26.
 *         产品额度预警设置
 */
@RestController
@RequestMapping("/product/early/warning")
public class ProductEarlyWarningController extends ControllerBase{

    private final Logger LOGGER = LoggerFactory.getLogger(ProductEarlyWarningController.class);

    @Autowired
    IProductEarlyWarningService productEarlyWarningService;

    /**
     * 产品额度预警-列表
     * @param dto
     * @return
     * @throws BusinessException
     */
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public ResponseResult getList(ProductEarlyWarningDTO dto) throws BusinessException {
        LOGGER.info("getActivityDiagramList-start-params {}",dto);
        CommItemListVO<ProductEarlyWarningVO> list= productEarlyWarningService.getList(dto);
        LOGGER.info("getActivityDiagramList-end-data {}",list.getCount());
        return creatOKRespResult(dto.getTraceID(),list);
    }

}
