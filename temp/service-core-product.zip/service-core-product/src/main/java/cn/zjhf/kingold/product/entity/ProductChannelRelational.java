package cn.zjhf.kingold.product.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author 
 */
public class ProductChannelRelational extends ProductChannelRelationalKey implements Serializable {
    /**
     * 商户号码(渠道商户号) （如：89890112）
     */
    private String merchantNum;

    /**
     * APP名称
     */
    private String channelAppName;

    /**
     * 内外部渠道（1.内部渠道 2 外部渠道 默认外部渠道）
     */
    private String interExterChannel;

    /**
     * 产品编码
     */
    private String productCode;

    /**
     * 产品简称
     */
    private String productAbbrName;

    /**
     * 产品类型（PRIF私募基金FIXI固定收益理财）
     */
    private String productType;

    /**
     * 渠道手续费
     */
    private BigDecimal channelChargeRate;

    /**
     * 签名
     */
    private String signature;

    /**
     * 删除标记 0未删除，1已删除
     */
    private Byte deleteFlag;

    /**
     * 分配时间
     */
    private Date createTime;

    private Date updateTime;

    private Date productEstablishmentDate;

    /**
     * 短信发送标识 1.允许、2、不允许
     */
    private Integer wechatSendMark;


    private static final long serialVersionUID = 1L;

    public String getMerchantNum() {
        return merchantNum;
    }

    public void setMerchantNum(String merchantNum) {
        this.merchantNum = merchantNum;
    }

    public String getChannelAppName() {
        return channelAppName;
    }

    public void setChannelAppName(String channelAppName) {
        this.channelAppName = channelAppName;
    }

    public String getInterExterChannel() {
        return interExterChannel;
    }

    public void setInterExterChannel(String interExterChannel) {
        this.interExterChannel = interExterChannel;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductAbbrName() {
        return productAbbrName;
    }

    public void setProductAbbrName(String productAbbrName) {
        this.productAbbrName = productAbbrName;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public BigDecimal getChannelChargeRate() {
        return channelChargeRate;
    }

    public void setChannelChargeRate(BigDecimal channelChargeRate) {
        this.channelChargeRate = channelChargeRate;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public Byte getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Byte deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getProductEstablishmentDate() {
        return productEstablishmentDate;
    }

    public void setProductEstablishmentDate(Date productEstablishmentDate) {
        this.productEstablishmentDate = productEstablishmentDate;
    }

    public Integer getWechatSendMark() {
        return wechatSendMark;
    }

    public void setWechatSendMark(Integer wechatSendMark) {
        this.wechatSendMark = wechatSendMark;
    }
}