package cn.zjhf.kingold.product.util;

/**
 * Created by zhangyijie on 2017/7/12.
 */
public class QueryUtils {

    String queryStr = "";

    public QueryUtils(String queryStr) {
        this.queryStr = queryStr;
    }

    public String getCondition() {
        return toString();
    }

    @Override
    public String toString() {
        return queryStr;
    }
}
