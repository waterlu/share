package cn.zjhf.kingold.product.entity.enums;

/**
 * Created by Xiaody on 17/4/12.
 */
public enum ProductTypeEnum {
    PRIVATE_FUND("PRIF"),
    FIXED_INCOME("FIXI");

    private String code;

    ProductTypeEnum(String code) {
        this.code = code;
    }

    public String getCode() {
        return this.code;
    }
}
