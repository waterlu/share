package cn.zjhf.kingold.product.persistence.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.Map;

@Repository
@Mapper
public interface ProductFixedIncomeMapper {
    Integer insert(Map map);

    Map get(@Param("productUuid") String productUuid);

    void update(Map map);

    void updateStatus(Map map);
}