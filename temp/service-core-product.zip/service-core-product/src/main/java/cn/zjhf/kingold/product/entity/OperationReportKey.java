package cn.zjhf.kingold.product.entity;

import java.io.Serializable;

/**
 * @author 
 */
public class OperationReportKey implements Serializable {
    /**
     * 报表编号
     */
    private String reportNo;

    /**
     * 批次号
     */
    private Byte batchNo;

    private static final long serialVersionUID = 1L;

    public OperationReportKey() {

    }

    public OperationReportKey(String reportNo, int batchNo) {
        this.reportNo = reportNo;
        this.batchNo = new Integer(batchNo).byteValue();
    }

    public String getReportNo() {
        return reportNo;
    }

    public void setReportNo(String reportNo) {
        this.reportNo = reportNo;
    }

    public Byte getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(Byte batchNo) {
        this.batchNo = batchNo;
    }
}