package cn.zjhf.kingold.product.exception;

import cn.zjhf.kingold.common.exception.BusinessException;

/**
 * @author lutiehua
 * @date 2018/3/7
 */
public class ProductStatusException extends BusinessException {

    public ProductStatusException() {
        super(6211, "产品目前不能够购买(产品已下架)");
    }

}
