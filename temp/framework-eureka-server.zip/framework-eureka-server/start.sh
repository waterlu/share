#!/bin/bash
nohup java -server -Xms128m -Xmx128m -jar target/framework-eureka-server-1.0.0.jar > /dev/null 2>&1 &