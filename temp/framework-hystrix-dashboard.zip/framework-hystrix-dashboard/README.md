# version

## 1.0.0

基于Hystrix Dashboard实现断路器监控