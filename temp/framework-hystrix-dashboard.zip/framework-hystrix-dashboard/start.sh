#!/bin/bash
nohup java -server -Xms256m -Xmx256m -jar target/framework-hystrix-dashboard-1.0.0.jar > /dev/null 2>&1 &