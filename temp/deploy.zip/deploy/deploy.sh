#!/usr/bin/env bash

Usage() {
    echo "Usage: $0 project_name (branch_name)"
}

execute() {
   fab set_host deploy
}

if [[ "$#" -gt "2" ]]; then
    Usage
else
    export project_name="$1"
    export branch_name="$2"
    execute
fi