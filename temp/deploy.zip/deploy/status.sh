#!/usr/bin/env bash

Usage() {
    echo "Usage: $0 project_name"
}

execute() {
   fab set_host status
}

if [[ "$#" -ne "1" ]]; then
    Usage
else
    export project_name="$1"
    execute
fi