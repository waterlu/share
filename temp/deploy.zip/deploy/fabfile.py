# -*- coding: utf-8 -*-
import sys
import yaml
from fabric.api import *
from fabric.colors import *
from fabric import operations
import os

GIT_URL = 'gitlab.zj-hf.cn'
PROJECTS_YML = 'projects.yml'
SUPERVISOR_PATH = 'supervisor'


def get_project_info():
    project_name = os.getenv("project_name")
    print green("project name:" + project_name)

    # 读取projects.yml
    with open(PROJECTS_YML) as f:
        projects = yaml.load(f.read())

    projects_new = filter(lambda item: project_name == item.get('name'), projects)
    if len(projects_new) > 0:
        project_info = projects_new[0]
    else:
        print red("project name:" + str(project_name) + " not right")
        sys.exit(1)
    branch = os.getenv("branch_name")
    print green("branch name:" + str(branch))

    # 替换变量信息
    git_info = project_info.get('git')
    git_info['repo'] = git_info.get('repo').replace('{{git_url}}', GIT_URL)
    if branch:
        git_info['branch'] = git_info.get('branch').replace('{{branch}}', branch)
    return project_info


def set_host():
    project_info = get_project_info()
    env.hosts = project_info.get('dest').get('host')
    env.user = project_info.get('dest').get('user')
    env.password = project_info.get('dest').get('password')


def deploy():
    project_info = get_project_info()
    project_name = project_info.get('name')
    file_path = project_info.get('file_path')
    git_repo = project_info.get('git').get('repo')
    branch = project_info.get('git').get('branch')
    tag = project_info.get('tag')
    tar_file_name = project_info.get('tar_file')
    # 拉取代码
    if os.path.exists(file_path + '/' + project_name):
        if branch == '{{branch}}':
            cmd = "cd %s/%s;git fetch;git stash;git pull" % (file_path, project_name)
        else:
            cmd = "cd %s/%s;git fetch;git stash;git checkout %s;git pull" % (file_path, project_name, branch)
        local(cmd)
    else:
        if branch == '{{branch}}':
            cmd = "cd %s;git clone %s" % (file_path, git_repo)
        else:
            cmd = "cd %s;git clone -b %s %s" % (file_path, branch, git_repo)
        local(cmd)

    # 编译打包 根据tag判断是java还是python项目
    if tag == 'java':
        package = "cd %s/%s;mvn clean package -Dmaven.test.skip=true" % (file_path, project_name)
        local(package)
    elif tag == 'python':
        local("cd %s/%s;rm -rf %s" % (file_path, project_name, tar_file_name))
        local("cd %s/%s;tar -czf %s %s" % (file_path, project_name, tar_file_name, '*'))

    # 上传代码
    remote_dir = project_info.get('dest').get('dir')
    run("mkdir -p %s" % remote_dir)
    with settings(warn_only=True):
        local_path = file_path + "/" + project_name + "/" + tar_file_name if tag == 'python' \
            else file_path + "/" + project_name + "/target/" + tar_file_name
        result = put(local_path, remote_dir + "/" + tar_file_name)
        if result.failed:
            abort("Aborting code upload task!")

    # 上传supervisor配置文件
    with settings(warn_only=True):
        result = put("%s/%s.conf" % (SUPERVISOR_PATH, project_name), "/etc/supervisor/conf.d/")
        if result.failed:
            abort("Aborting supervisor upload task!")

    # 重启部署
    with cd(remote_dir):
        if tag == 'java':
            run("supervisorctl update;supervisorctl restart %s" % project_name)
        elif tag == 'python':
            run("rm -rf %s;mkdir -p %s" % (project_name, project_name))
            run("tar -xzf %s -C %s" % (tar_file_name, project_name))
            run("supervisorctl update;supervisorctl restart %s" % project_name)


def cat_log():
    project_info = get_project_info()
    log_file_path = project_info.get('log_file_path')
    run("tail -f %s" % log_file_path)


def status():
    run("supervisorctl status")


def restart():
    project_info = get_project_info()
    project_name = project_info.get('name')
    run("supervisorctl restart %s" % project_name)


def stop():
    project_info = get_project_info()
    project_name = project_info.get('name')
    run("supervisorctl stop %s" % project_name)


def login():
    print "即将登陆服务器: %s" % (env.host_string)
    operations.open_shell()
