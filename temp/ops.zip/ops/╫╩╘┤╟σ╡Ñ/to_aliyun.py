import csv
import datetime
import shutil, os
import pandas as pd

# def utc2cst(str):
#     time1 = datetime.datetime.strptime(str, '%Y-%m-%dT%H:%MZ')
#     time2 = time1 + datetime.timedelta(hours=8)
#     return time2.strftime('%Y-%m-%d')
#
# def change_file(file):
#     with open(file, 'r', encoding='utf-8') as f, open('.ceshi.csv', 'w', encoding='utf-8') as f1:
#         reader = csv.DictReader(f)
#         fildnames = reader.fieldnames
#         writer = csv.DictWriter(f1, fildnames)
#         writer.writeheader()
#         for row in reader:
#             row['到期时间(UTC)'] = utc2cst(row['到期时间(UTC)'])
#             writer.writerow(row)
    # os.remove(file)
    # shutil.copy('.ceshi.csv', file)
    # os.remove('.ceshi.csv')

all_file = os.listdir('.')
writer = pd.ExcelWriter('阿里云服务.xlsx')
for file in all_file:
    if file.split('.')[1] == 'csv':
        # change_file(file)
        csv = pd.read_csv(file)
        csv.to_excel(writer, file.split('.')[0])
writer.save()
