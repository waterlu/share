package cn.zjhf.kingold.service_consumer.config;

import cn.zjhf.kingold.service_consumer.service.ProductServiceConsumer;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@EnableConfigurationProperties(ServiceProperties.class)
public class ServicePropertiesConfiguration {
}
