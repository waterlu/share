package cn.zjhf.kingold.service_consumer.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * 读取配置文件用
 * <p>
 * Created by lutiehua on 2017/5/5.
 */
@ConfigurationProperties(prefix = "kingold.service")
public class ServiceProperties {

    /**
     * 用户服务地址默认域名
     */
    private String user = "http://user-service-kingold.zj-hf.cn:8050";

    /**
     * 产品服务地址默认域名
     */
    private String product = "http://product-service-kingold.zj-hf.cn:8820";

    /**
     * 交易服务地址默认域名
     */
    private String trade = "http://trade-service-kingold.zj-hf.cn:8051";

    /**
     * 基础服务地址默认域名
     */
    private String base = "http://base-service-kingold.zj-hf.cn:8810";

    /**
     * 机构服务地址默认域名
     */
    private String org = "http://organization-service-kingold.zj-hf.cn:8061";

    /**
     * 营销服务地址默认域名
     */
    private String market = "http://market-service-kingold.zj-hf.cn:8056";

    /**
     * ifa服务地址默认域名
     */
    private String ifa = "http://ifa-service-kingold.zj-hf.cn:8110";

    /**
     * pfo服务地址默认域名
     */
    private String pfo = "http://pfo-service-kingold.zj-hf.cn:8058";

    /**
     * fopAuth服务地址默认域名
     */
    private String fopAuth = "http://fopauth-service-kingold.zj-hf.cn:8990";


    /**
     * 理财师用户信息服务地址默认域名
     */
    private String advisor = "http://advisor-service-kingold.zj-hf.cn:8059";

    /**
     * 短信服务地址默认域名
     */
    private String sms = "http://sms-service-kingold.zj-hf.cn:8812";

    /**
     * campaign服务地址默认域名
     */
    private String campaign = "http://campaign-service-kingold.zj-hf.cn:8062";

    /**
     * marketInfo服务地址默认域名
     */
    private String marketInfo = "http://marketinfo-service-kingold.zj-hf.cn:8063";

    /**
     * coin服务地址默认域名
     */
    private String coin = "http://coin-service-kingold.zj-hf.cn:8067";

    /**
     * 短信服务地址默认域名
     */
    private String fund = "http://fund-service-kingold.zj-hf.cn:8021";

    /**
     * cloud网关地址默认域名
     */
    private String gateway = "http://gateway-service-kingold.zj-hf.cn:10080";

    private String callSystemId = "2000";

    /**
     * OKHTTP的超时设置
     */
    private int connectTimeOut = 30;

    private int readTimeout = 30;

    private int writeTimeOut = 30;

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getTrade() {
        return trade;
    }

    public void setTrade(String trade) {
        this.trade = trade;
    }

    public String getBase() {
        return base;
    }

    public void setBase(String base) {
        this.base = base;
    }

    public String getCallSystemId() {
        return callSystemId;
    }

    public void setCallSystemId(String callSystemId) {
        this.callSystemId = callSystemId;
    }

    public int getConnectTimeOut() {
        return connectTimeOut;
    }

    public void setConnectTimeOut(int connectTimeOut) {
        this.connectTimeOut = connectTimeOut;
    }

    public int getReadTimeout() {
        return readTimeout;
    }

    public void setReadTimeout(int readTimeout) {
        this.readTimeout = readTimeout;
    }

    public int getWriteTimeOut() {
        return writeTimeOut;
    }

    public void setWriteTimeOut(int writeTimeOut) {
        this.writeTimeOut = writeTimeOut;
    }

    public String getOrg() {
        return org;
    }

    public void setOrg(String org) {
        this.org = org;
    }

    public String getFund() {
        return fund;
    }

    public void setFund(String fund) {
        this.fund = fund;
    }

    public String getMarket() {
        return market;
    }

    public void setMarket(String market) {
        this.market = market;
    }

    public String getIfa() {
        return ifa;
    }

    public void setIfa(String ifa) {
        this.ifa = ifa;
    }

    public String getAdvisor() {
        return advisor;
    }

    public void setAdvisor(String advisor) {
        this.advisor = advisor;
    }

    public String getPfo() {
        return pfo;
    }

    public void setPfo(String pfo) {
        this.pfo = pfo;
    }

    public String getFopAuth() {
        return fopAuth;
    }

    public void setFopAuth(String fopAuth) {
        this.fopAuth = fopAuth;
    }

    public String getSms() {
        return sms;
    }

    public void setSms(String sms) {
        this.sms = sms;
    }

    public String getCampaign() {
        return campaign;
    }

    public void setCampaign(String campaign) {
        this.campaign = campaign;
    }

    public String getMarketInfo() {
        return marketInfo;
    }

    public void setMarketInfo(String marketInfo) {
        this.marketInfo = marketInfo;
    }

    public String getCoin() {
        return coin;
    }

    public void setCoin(String coin) {
        this.coin = coin;
    }

    public String getGateway() {
        return gateway;
    }

    public void setGateway(String gateway) {
        this.gateway = gateway;
    }
}
