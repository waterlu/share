package cn.zjhf.kingold.service_consumer.service;

import cn.zjhf.kingold.service_consumer.config.ServiceProperties;

/**
 * Created by siqingwei on 2017/8/28.
 */
public class SmsServiceConsumer extends AbstractServiceConsumer{

    public SmsServiceConsumer(ServiceProperties properties) {
        super(properties);
    }

    public String getDomain() {
        return properties.getSms();
    }
}
