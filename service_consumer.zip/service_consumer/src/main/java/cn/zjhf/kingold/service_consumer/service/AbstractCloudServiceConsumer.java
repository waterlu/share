package cn.zjhf.kingold.service_consumer.service;

import cn.zjhf.kingold.cloud.common.dto.ParamDTO;
import cn.zjhf.kingold.cloud.common.dto.QueryParam;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.common.utils.CacheUtil;
import cn.zjhf.kingold.service_consumer.config.ServiceProperties;
import com.alibaba.fastjson.JSONObject;
import com.google.common.base.Strings;

import java.util.UUID;

/**
 * @author xiaody
 * @description
 * @date create in 18/1/19
 */
public abstract class AbstractCloudServiceConsumer extends AbstractServiceConsumer {


    public AbstractCloudServiceConsumer(ServiceProperties properties) {
        super(properties);
    }

    /**
     * HTTP GET QueryParam参数
     *
     * @param url
     * @param queryParam
     * @return
     * @throws BusinessException
     */
    public ResponseResult get(String url, QueryParam queryParam) throws BusinessException {
        String requestUrl = getRequestUrl(url);
        queryParam = beforeHttpRequest(queryParam);
        String jsonParam = JSONObject.toJSONString(queryParam);
        return this.doHttpPostRequest(requestUrl, jsonParam);
    }

    /**
     * HTTP POST ParamDTO参数
     *
     * @param url
     * @param dto
     * @return
     * @throws BusinessException
     */
    public ResponseResult post(String url, ParamDTO dto) throws BusinessException {
        String requestUrl = getRequestUrl(url);
        dto = beforeHttpRequest(dto);
        String jsonParam = JSONObject.toJSONString(dto);
        return this.doHttpPostRequest(requestUrl, jsonParam);
    }


    /**
     * HTTP PUT ParamDTO参数
     *
     * @param url
     * @param dto
     * @return
     * @throws BusinessException
     */
    public ResponseResult put(String url, ParamDTO dto) throws BusinessException {
        String requestUrl = getRequestUrl(url);
        dto = beforeHttpRequest(dto);
        String jsonParam = JSONObject.toJSONString(dto);
        return this.doHttpPutRequest(requestUrl, jsonParam);
    }


    /**
     * 如果参数里面没有traceID和callSystemID，自动补上
     *
     * @param queryParam
     * @return
     * @throws BusinessException
     */
    private QueryParam beforeHttpRequest(QueryParam queryParam) throws BusinessException {
        if (null == queryParam) {
            queryParam = new QueryParam();
        }

        // 优先级：传参 > ThreadLocal > 新生成
        if (Strings.isNullOrEmpty(queryParam.getTraceID())) {
            String traceID = CacheUtil.getTraceID();
            if (Strings.isNullOrEmpty(traceID)) {
                traceID = UUID.randomUUID().toString();
            }
            queryParam.setTraceID(traceID);
        }

        // 优先级：传参 > .properties
        if (Strings.isNullOrEmpty(queryParam.getCallSystemID())) {
            queryParam.setCallSystemID(getCallSystemId());
        }

        return queryParam;
    }


    /**
     * 如果参数里面没有traceID和callSystemID，自动补上
     *
     * @param dto
     * @return
     * @throws BusinessException
     */
    private ParamDTO beforeHttpRequest(ParamDTO dto) throws BusinessException {
        if (null == dto) {
            dto = new ParamDTO();
        }

        // 优先级：传参 > ThreadLocal > 新生成
        if (Strings.isNullOrEmpty(dto.getTraceID())) {
            String traceID = CacheUtil.getTraceID();
            if (Strings.isNullOrEmpty(traceID)) {
                traceID = UUID.randomUUID().toString();
            }
            dto.setTraceID(traceID);
        }

        // 优先级：传参 > .properties
        if (Strings.isNullOrEmpty(dto.getCallSystemID())) {
            dto.setCallSystemID(getCallSystemId());
        }

        return dto;
    }
}
