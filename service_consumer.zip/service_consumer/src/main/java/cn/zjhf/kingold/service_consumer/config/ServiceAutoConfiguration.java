package cn.zjhf.kingold.service_consumer.config;

import cn.zjhf.kingold.service_consumer.service.*;
import okhttp3.OkHttpClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;

import java.util.concurrent.TimeUnit;

/**
 * 负责根据条件构造Bean
 * <p>
 * Created by lutiehua on 2017/5/5.
 */
@Configuration
@EnableConfigurationProperties(ServiceProperties.class)
@ConditionalOnClass(value = {BaseServiceConsumer.class, ProductServiceConsumer.class, TradeServiceConsumer.class,
        UserServiceConsumer.class})
@Order(value = 2)
public class ServiceAutoConfiguration {

    /**
     * 从.properties文件读取配置
     */
    @Autowired
    private ServiceProperties properties;

    @Bean
    @ConditionalOnMissingBean(UserServiceConsumer.class)
    public UserServiceConsumer userServiceConsumer() {
        UserServiceConsumer userServiceConsumer = new UserServiceConsumer(properties);
        return userServiceConsumer;
    }

    @Bean
    @ConditionalOnMissingBean(ProductServiceConsumer.class)
    public ProductServiceConsumer productServiceConsumer() {
        ProductServiceConsumer productServiceConsumer = new ProductServiceConsumer(properties);
        return productServiceConsumer;
    }

    @Bean
    @ConditionalOnMissingBean(TradeServiceConsumer.class)
    public TradeServiceConsumer tradeServiceConsumer() {
        TradeServiceConsumer tradeServiceConsumer = new TradeServiceConsumer(properties);
        return tradeServiceConsumer;
    }

    @Bean
    @ConditionalOnMissingBean(BaseServiceConsumer.class)
    public BaseServiceConsumer baseServiceConsumer() {
        BaseServiceConsumer baseServiceConsumer = new BaseServiceConsumer(properties);
        return baseServiceConsumer;
    }

    @Bean
    @ConditionalOnMissingBean(OrgServiceConsumer.class)
    public OrgServiceConsumer orgServiceConsumer() {
        OrgServiceConsumer orgServiceConsumer = new OrgServiceConsumer(properties);
        return orgServiceConsumer;
    }

    @Bean
    @ConditionalOnMissingBean(GeneralServiceConsumer.class)
    public GeneralServiceConsumer generalServiceConsumer() {
        GeneralServiceConsumer generalServiceConsumer = new GeneralServiceConsumer(properties);
        return generalServiceConsumer;
    }

    @Bean
    @ConditionalOnMissingBean(MarketServiceConsumer.class)
    public MarketServiceConsumer marketServiceConsumer() {
        MarketServiceConsumer marketServiceConsumer = new MarketServiceConsumer(properties);
        return marketServiceConsumer;
    }

    @Bean
    @ConditionalOnMissingBean(IfaServiceConsumer.class)
    public IfaServiceConsumer ifaServiceConsumer() {
        IfaServiceConsumer ifaServiceConsumer = new IfaServiceConsumer(properties);
        return ifaServiceConsumer;
    }

    @Bean
    @ConditionalOnMissingBean(PfoServiceConsumer.class)
    public PfoServiceConsumer pfoServiceConsumer() {
        PfoServiceConsumer pfoServiceConsumer = new PfoServiceConsumer(properties);
        return pfoServiceConsumer;
    }

    @Bean
    @ConditionalOnMissingBean(AdvisorServiceConsumer.class)
    public AdvisorServiceConsumer advisorServiceConsumer() {
        AdvisorServiceConsumer advisorServiceConsumer = new AdvisorServiceConsumer(properties);
        return advisorServiceConsumer;
    }

    @Bean
    @ConditionalOnMissingBean(SmsServiceConsumer.class)
    public SmsServiceConsumer smsServiceConsumer() {
        SmsServiceConsumer smsServiceConsumer = new SmsServiceConsumer(properties);
        return smsServiceConsumer;
    }

    @Bean
    @ConditionalOnMissingBean(FopAuthServiceConsumer.class)
    public FopAuthServiceConsumer fopAuthServiceConsumer() {
        FopAuthServiceConsumer fopAuthServiceConsumer = new FopAuthServiceConsumer(properties);
        return fopAuthServiceConsumer;
    }

    @Bean
    @ConditionalOnMissingBean(CampaignServiceConsumer.class)
    public CampaignServiceConsumer campaignServiceConsumer() {
        CampaignServiceConsumer campaignServiceConsumer = new CampaignServiceConsumer(properties);
        return campaignServiceConsumer;
    }

    @Bean
    @ConditionalOnMissingBean(FundServiceConsumer.class)
    public FundServiceConsumer fundServiceConsumer() {
        FundServiceConsumer fundServiceConsumer = new FundServiceConsumer(properties);
        return fundServiceConsumer;
    }

    @Bean
    @ConditionalOnMissingBean(MarketInfoServiceConsumer.class)
    public MarketInfoServiceConsumer marketInfoServiceConsumer() {
        MarketInfoServiceConsumer marketInfoServiceConsumer = new MarketInfoServiceConsumer(properties);
        return marketInfoServiceConsumer;
    }

    @Bean
    @ConditionalOnMissingBean(CoinServiceConsumer.class)
    public CoinServiceConsumer coinServiceConsumer() {
        CoinServiceConsumer coinServiceConsumer = new CoinServiceConsumer(properties);
        return coinServiceConsumer;
    }

    @Bean
    @ConditionalOnMissingBean(GatewayServiceConsumer.class)
    public GatewayServiceConsumer gatewayServiceConsumer() {
        GatewayServiceConsumer gatewayServiceConsumer = new GatewayServiceConsumer(properties);
        return gatewayServiceConsumer;
    }

    @Bean
    @ConditionalOnMissingBean(name = "okHttpClient")
    public OkHttpClient okHttpClient() {
        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .connectTimeout(properties.getConnectTimeOut(), TimeUnit.SECONDS)
                .readTimeout(properties.getReadTimeout(), TimeUnit.SECONDS)
                .writeTimeout(properties.getWriteTimeOut(), TimeUnit.SECONDS)
                .build();
        return okHttpClient;
    }
}
