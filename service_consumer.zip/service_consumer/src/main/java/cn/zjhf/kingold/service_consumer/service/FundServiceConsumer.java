package cn.zjhf.kingold.service_consumer.service;

import cn.zjhf.kingold.service_consumer.config.ServiceProperties;

/**
 * Created by liuyao on 2017/11/1.
 */
public class FundServiceConsumer extends AbstractServiceConsumer{

    public FundServiceConsumer(ServiceProperties properties) {
        super(properties);
    }

    public String getDomain() {
        return properties.getFund();
    }
}