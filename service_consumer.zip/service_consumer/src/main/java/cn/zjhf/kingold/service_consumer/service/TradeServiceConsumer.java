package cn.zjhf.kingold.service_consumer.service;

import cn.zjhf.kingold.service_consumer.config.ServiceProperties;

/**
 * Created by lutiehua on 2017/5/5.
 */
public class TradeServiceConsumer extends AbstractServiceConsumer {

    public TradeServiceConsumer(ServiceProperties properties) {
        super(properties);
    }

    public String getDomain() {
        return properties.getTrade();
    }
}
