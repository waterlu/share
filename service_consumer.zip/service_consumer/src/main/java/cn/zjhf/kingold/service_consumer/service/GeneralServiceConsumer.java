package cn.zjhf.kingold.service_consumer.service;

import cn.zjhf.kingold.service_consumer.config.ServiceProperties;

/**
 * Created by lutiehua on 2017/5/6.
 */
public class GeneralServiceConsumer extends AbstractServiceConsumer {

    public GeneralServiceConsumer(ServiceProperties properties) {
        super(properties);
    }

    public String getDomain() {
        return "";
    }
}