package cn.zjhf.kingold.service_consumer.service;

import cn.zjhf.kingold.service_consumer.config.ServiceProperties;

/**
 * Created by lutiehua on 2017/5/5.
 */
public class CoinServiceConsumer extends AbstractServiceConsumer{

    public CoinServiceConsumer(ServiceProperties properties) {
        super(properties);
    }

    public String getDomain() {
        return properties.getCoin();
    }
}