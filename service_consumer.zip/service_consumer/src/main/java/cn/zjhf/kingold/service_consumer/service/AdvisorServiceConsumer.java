package cn.zjhf.kingold.service_consumer.service;

import cn.zjhf.kingold.service_consumer.config.ServiceProperties;

/**
 * Created by wangxun on 2017/5/5.
 */
public class AdvisorServiceConsumer extends AbstractServiceConsumer{

    public AdvisorServiceConsumer(ServiceProperties properties) {
        super(properties);
    }

    public String getDomain() {
        return properties.getAdvisor();
    }
}