package cn.zjhf.kingold.service_consumer.service;

import cn.zjhf.kingold.service_consumer.config.ServiceProperties;

/**
 * Created by lutiehua on 2017/5/5.
 */
public class CampaignServiceConsumer extends AbstractServiceConsumer{

    public CampaignServiceConsumer(ServiceProperties properties) {
        super(properties);
    }

    public String getDomain() {
        return properties.getCampaign();
    }
}