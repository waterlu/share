package cn.zjhf.kingold.service_consumer.service;

import cn.zjhf.kingold.common.constant.ResponseCode;
import cn.zjhf.kingold.common.exception.BusinessException;
import cn.zjhf.kingold.common.param.ParamVO;
import cn.zjhf.kingold.common.result.ResponseResult;
import cn.zjhf.kingold.common.utils.CacheUtil;
import cn.zjhf.kingold.service_consumer.config.ServiceProperties;
import com.alibaba.fastjson.JSONObject;
import okhttp3.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 服务层消费者抽象基类
 *
 * Created by lutiehua on 2017/5/5.
 *
 */
public abstract class AbstractServiceConsumer {

    protected final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    /**
     * 服务属性配置
     */
    protected ServiceProperties properties;

    /**
     * HTTP客户端
     */
    @Autowired
    private OkHttpClient okHttpClient;

    /**
     * HTTP + JSON
     */
    private final MediaType JSON = MediaType.parse("application/json; charset=utf-8");

    /**
     * HTTP + 上传文件
     */
    private final MediaType OCTET_STREAM = MediaType.parse("application/octet-stream");

    public AbstractServiceConsumer(ServiceProperties properties) {
        this.properties = properties;
    }

    /**
     * 返回当前服务的域名地址
     *
     * @return
     */
    public abstract String getDomain();

    public String getCallSystemId() {
        return properties.getCallSystemId();
    }

    /**
     * 将Data转换为对象
     *
     * @param responseResult
     * @param clazz
     * @param <T>
     * @return
     */
    public <T> T getData(ResponseResult responseResult, Class<T> clazz) {
        String jsonString = JSONObject.toJSONString(responseResult.getData());
        return JSONObject.parseObject(jsonString, clazz);
    }

    /**
     * 将Data转换为对象数组
     *
     * @param responseResult
     * @param clazz
     * @param <T>
     * @return
     */
    public <T> List<T> getDataArray(ResponseResult responseResult, Class<T> clazz) {
        String jsonString = JSONObject.toJSONString(responseResult.getData());
        return JSONObject.parseArray(jsonString, clazz);
    }

    /**
     * HTTP GET Map参数
     *
     * @param url
     * @param param
     * @return
     * @throws BusinessException
     */
    public ResponseResult get(String url, Map<String, Object> param) throws BusinessException {
        String requestUrl = getRequestUrl(url);
        param = beforeHttpRequest(param);
        for(Map.Entry<String, Object> entry : param.entrySet()) {
            if (null == entry.getValue()) {
                continue;
            }
            String key = entry.getKey();
            if (!StringUtils.isEmpty(entry.getValue())) {
                // 有值的情况下才添加到请求参数中
                String value = entry.getValue().toString();
                try {
                    value = URLEncoder.encode(value, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                    throw new BusinessException(ResponseCode.PARAM_ERROR, e.getMessage());
                }

                if (!requestUrl.contains("?")) {
                    requestUrl += "?" + key + "=" + value;
                } else {
                    requestUrl += "&" + key + "=" + value;
                }
            }
        }
        LOGGER.info("http get [{}]", requestUrl);
        Request request = new Request.Builder().url(requestUrl).get().build();
        return doHttpRequest(request);
    }

    /**
     * HTTP GET VO参数
     * 遍历对象的属性，通过getX()方法获取参数值，目前对于boolean没有做特殊处理，不建议使用。
     *
     * @param url
     * @param param
     * @return
     * @throws BusinessException
     */
    @Deprecated public ResponseResult get(String url, ParamVO param) throws BusinessException {
        String requestUrl = getRequestUrl(url);
        param = beforeHttpRequest(param);
        List<String> fieldList = new ArrayList<String>();
        getProperty(param.getClass(), fieldList);
        for(int i=0; i<fieldList.size(); i++){
            String key = fieldList.get(i);
            Object value = getFieldValueByName(key, param);
            if (!StringUtils.isEmpty(value)) {
                // 有值的情况下才添加到请求参数中
                if (!requestUrl.contains("?")) {
                    //针对Date类型做特殊处理，zhangyijie  20170630
                    if(value instanceof Date) {
                        SimpleDateFormat sdf = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss" );
                        String dateStr = sdf.format((Date)value);
                        requestUrl += "?" + key + "=" + dateStr;
                    }else {
                        requestUrl += "?" + key + "=" + value;
                    }
                } else {
                    //针对Date类型做特殊处理，zhangyijie  20170630
                    if(value instanceof Date) {
                        SimpleDateFormat sdf = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss" );
                        String dateStr = sdf.format((Date)value);
                        requestUrl += "&" + key + "=" + dateStr;
                    }else {
                        requestUrl += "&" + key + "=" + value;
                    }
                }
            }
        }
        LOGGER.info("http get [{}]", requestUrl);
        Request request = new Request.Builder().url(requestUrl).get().build();
        return doHttpRequest(request);
    }

    /**
     * 获取类的全部属性
     *
     * @param clazz
     * @param fieldList
     */
    private void getProperty(Class clazz, List<String> fieldList) {
        Field[] fields = clazz.getDeclaredFields();
        Field.setAccessible(fields, true);
        for (int i = 0; i < fields.length; i++) {
            Field field = fields[i];
            if (!field.getName().startsWith("this$")) {
                fieldList.add(field.getName());
            }
        }

        if(clazz.getGenericSuperclass() != null) {
            getProperty(clazz.getSuperclass(), fieldList);
        }
    }

    /**
     * 根据属性名得到属性值
     *
     * @param fieldName
     * @param object
     * @return
     */
    private Object getFieldValueByName(String fieldName, Object object) {
        try {
            String firstLetter = fieldName.substring(0, 1).toUpperCase();
            String getter = "get" + firstLetter + fieldName.substring(1);
            Method method = object.getClass().getMethod(getter, new Class[] {});
            Object value = method.invoke(object, new Object[] {});
            return value;
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error(e.getMessage());
        }

        return null;
    }

    /**
     * HTTP POST Map参数
     *
     * @param url
     * @param param
     * @return
     * @throws BusinessException
     */
    public ResponseResult post(String url, Map<String, Object> param) throws BusinessException {
        String requestUrl = getRequestUrl(url);
        param = beforeHttpRequest(param);
        String jsonParam = JSONObject.toJSONString(param);
        return doHttpPostRequest(requestUrl, jsonParam);
    }

    /**
     * HTTP POST VO参数
     *
     * @param url
     * @param vo
     * @return
     * @throws BusinessException
     */
    public ResponseResult post(String url, ParamVO vo) throws BusinessException {
        String requestUrl = getRequestUrl(url);
        vo = beforeHttpRequest(vo);
        String jsonParam = JSONObject.toJSONString(vo);
        return doHttpPostRequest(requestUrl, jsonParam);
    }

    /**
     * HTTP PUT Map参数
     *
     * @param url
     * @param param
     * @return
     * @throws BusinessException
     */
    public ResponseResult put(String url, Map<String, Object> param) throws BusinessException {
        String requestUrl = getRequestUrl(url);
        param = beforeHttpRequest(param);
        String jsonParam = JSONObject.toJSONString(param);
        return doHttpPutRequest(requestUrl, jsonParam);
    }

    /**
     * HTTP PUT VO参数
     *
     * @param url
     * @param vo
     * @return
     * @throws BusinessException
     */
    public ResponseResult put(String url, ParamVO vo) throws BusinessException {
        String requestUrl = getRequestUrl(url);
        vo = beforeHttpRequest(vo);
        String jsonParam = JSONObject.toJSONString(vo);
        return doHttpPutRequest(requestUrl, jsonParam);
    }

    /**
     * HTTP DELETE Map参数
     *
     * @param url
     * @param param
     * @return
     * @throws BusinessException
     */
    public ResponseResult delete(String url, Map<String, Object> param) throws BusinessException {
        String requestUrl = getRequestUrl(url);
        param = beforeHttpRequest(param);
        String jsonParam = JSONObject.toJSONString(param);
        return doHttpDeleteRequest(requestUrl, jsonParam);
    }

    /**
     *  HTTP DELETE VO参数
     *
     * @param url
     * @param vo
     * @return
     * @throws BusinessException
     */
    public ResponseResult delete(String url, ParamVO vo) throws BusinessException {
        String requestUrl = getRequestUrl(url);
        vo = beforeHttpRequest(vo);
        String jsonParam = JSONObject.toJSONString(vo);
        return doHttpDeleteRequest(requestUrl, jsonParam);
    }


    /**
     * HTTP UPLOAD Map参数
     *
     * @param url
     * @param param
     * @param file
     * @return
     * @throws BusinessException
     */
    public ResponseResult upload(String url, Map<String, Object> param, MultipartFile file) throws Exception {
        String requestUrl = getRequestUrl(url);
        param = beforeHttpRequest(param);
        return doHttpUploadRequest(requestUrl, param, file);
    }

    /**
     * 获取URL地址
     *
     * @param url
     * @return
     */
    protected String getRequestUrl(String url) throws BusinessException {
        if (StringUtils.isEmpty(url)) {
            throw new BusinessException(ResponseCode.PARAM_ERROR, ResponseCode.PARAM_ERROR_TEXT);
        }

        if (url.startsWith("http://") || url.startsWith("https://")) {
            return url;
        }

        String requestUrl = getDomain() + url;
        return requestUrl;
    }

    /**
     * 如果参数里面没有traceID和callSystemID，自动补上
     * traceID来自缓存
     * callSystemID来自配置文件
     *
     * @param param
     * @return
     */
    protected Map<String, Object> beforeHttpRequest(Map<String, Object> param) {
        if (null == param) {
            param = new HashMap<String, Object>();
        }

        // 优先级：传参 > ThreadLocal > 新生成
        if (!param.containsKey("traceID")) {
            String traceID = CacheUtil.getTraceID();
            if (StringUtils.isEmpty(traceID)) {
                traceID = UUID.randomUUID().toString();
            }
            param.put("traceID", traceID);
        }

        if (!param.containsKey("callSystemID")) {
            String callSystemId = getCallSystemId();
            param.put("callSystemID", callSystemId);
        }

        return param;
    }

    /**
     * 如果参数里面没有traceID和callSystemID，自动补上
     *
     * @param vo
     * @return
     * @throws BusinessException
     */
    protected ParamVO beforeHttpRequest(ParamVO vo) throws BusinessException {
        if (null == vo) {
            vo = new ParamVO();
        }

        // 优先级：传参 > ThreadLocal > 新生成
        if (StringUtils.isEmpty(vo.getTraceID())) {
            String traceID = CacheUtil.getTraceID();
            if (StringUtils.isEmpty(traceID)) {
                traceID = UUID.randomUUID().toString();
            }
            vo.setTraceID(traceID);
        }

        // 优先级：传参 > .properties
        if (StringUtils.isEmpty(vo.getCallSystemID())) {
            vo.setCallSystemID(getCallSystemId());
        }

        return vo;
    }

    /**
     * HTTP POST 请求
     *
     * @param url
     * @param jsonParam
     * @return
     * @throws BusinessException
     */
    protected ResponseResult doHttpPostRequest(String url, String jsonParam) throws BusinessException {
        RequestBody requestBody = RequestBody.create(JSON, jsonParam);
        LOGGER.info("http post url=[{}] body=[{}]", url, requestBody.toString());
        Request request = new Request.Builder().url(url).post(requestBody).build();
        return doHttpRequest(request);
    }

    /**
     * HTTP PUT 请求
     *
     * @param url
     * @param jsonParam
     * @return
     * @throws BusinessException
     */
    protected ResponseResult doHttpPutRequest(String url, String jsonParam) throws BusinessException {
        RequestBody requestBody = RequestBody.create(JSON, jsonParam);
        LOGGER.info("http put url=[{}] body=[{}]", url, requestBody.toString());
        Request request = new Request.Builder().url(url).put(requestBody).build();
        return doHttpRequest(request);
    }

    /**
     * HTTP DELETE 请求
     *
     * @param url
     * @param jsonParam
     * @return
     * @throws BusinessException
     */
    protected ResponseResult doHttpDeleteRequest(String url, String jsonParam) throws BusinessException {
        RequestBody requestBody = RequestBody.create(JSON, jsonParam);
        LOGGER.info("http delete url=[{}] body=[{}]", url, requestBody.toString());
        Request request = new Request.Builder().url(url).delete(requestBody).build();
        return doHttpRequest(request);
    }


    /**
     * HTTP 上传文件请求
     *
     * @param url
     * @param param
     * @param file
     * @return
     * @throws Exception
     */
    protected ResponseResult doHttpUploadRequest(String url,Map<String,Object> param, MultipartFile file) throws Exception {
        RequestBody fileBody = MultipartBody.create(OCTET_STREAM, file.getBytes());

        MultipartBody.Builder builder = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file",file.getOriginalFilename(),fileBody);
        for(Map.Entry<String,Object> entry:param.entrySet()){
            builder.addFormDataPart(entry.getKey(),entry.getValue().toString());
        }
        RequestBody requestBody = builder.build();
        LOGGER.info("http upload url=[{}]  body=[{}]", url, requestBody.toString());
        Request request = new Request.Builder().url(url).post(requestBody).build();
        return doHttpRequest(request);
    }

    /**
     * 真正的HTTP请求
     *
     * @param request
     * @return
     * @throws BusinessException
     */
    protected ResponseResult doHttpRequest(Request request) throws BusinessException {
        try {
            Response response = okHttpClient.newCall(request).execute();
            LOGGER.info("http response.code()={}", response.code());
            if (response.isSuccessful()) {
                String result = response.body().string();
                response.body().close();
                ResponseResult responseResult = JSONObject.parseObject(result, ResponseResult.class);
                LOGGER.info("http responseResult.getCode()={}", responseResult.getCode());
                return responseResult;
            } else {
                //throw new BusinessException(response.code(), response.message());
                ResponseResult responseResult = new ResponseResult();
                responseResult.setCode(response.code());
                responseResult.setMsg(response.message());
                responseResult.setData(null);
                return responseResult;
            }
            // 现在都是同步调用，也可以支持异步调用
//            okHttpClient.newCall(request).enqueue(new Callback() {
//                public void onFailure(Request request, IOException e) {
//
//                }
//
//                public void onResponse(Response response) throws IOException {
//
//                }
//            });
        } catch (IOException e) {
            LOGGER.error("doHttpRequest异常:{}", e.getMessage());
            throw new BusinessException(ResponseCode.REQUEST_ERROR_PROGRAM_EXCEPTION, e.getMessage());
        }
    }
}