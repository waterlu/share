package cn.zjhf.kingold.service_consumer.service;

import cn.zjhf.kingold.service_consumer.config.ServiceProperties;

/**
 * 组织机构消费者
 *
 * Created by lutiehua on 2017/5/5.
 */
public class OrgServiceConsumer extends AbstractServiceConsumer {

    public OrgServiceConsumer(ServiceProperties properties) {
        super(properties);
    }

    public String getDomain() {
        return properties.getOrg();
    }
}
