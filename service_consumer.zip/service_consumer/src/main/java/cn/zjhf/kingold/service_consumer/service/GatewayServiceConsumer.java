package cn.zjhf.kingold.service_consumer.service;

import cn.zjhf.kingold.service_consumer.config.ServiceProperties;

/**
 * @author xiaody
 * @description
 * @date create in 18/1/19
 */
public class GatewayServiceConsumer extends AbstractCloudServiceConsumer{

    public GatewayServiceConsumer(ServiceProperties properties) {
        super(properties);
    }

    @Override
    public String getDomain() {
        return properties.getGateway();
    }
}