package cn.zjhf.kingold.service_consumer.service;

import cn.zjhf.kingold.service_consumer.config.ServiceProperties;

/**
 * Created by lutiehua on 2017/5/5.
 */
public class MarketInfoServiceConsumer extends AbstractServiceConsumer{

    public MarketInfoServiceConsumer(ServiceProperties properties) {
        super(properties);
    }

    public String getDomain() {
        return properties.getMarketInfo();
    }
}