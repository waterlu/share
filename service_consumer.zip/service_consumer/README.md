# service consumer

service consumer 封装了服务之间调用的方法，使大家能够更专注于业务代码。

## 如何使用?

use it as a maven dependency:

```xml
<properties>
    <kingold-service-consumer.version>1.0-SNAPSHOT</kingold-service-consumer.version>
</properties>

<dependencies>
    <dependency>
        <groupId>cn.zjhf.kingold</groupId>
        <artifactId>service-consumer</artifactId>
        <version>${kingold-service-consumer.version}</version>
    </dependency>
</dependencies>    
```

## 样例

- 注入Service对象（以用户服务为例）
```java
    @Autowired
    private UserServiceConsumer userServiceConsumer;
```

- 调用Service对象的方法（目前提供get/post/put/delete四个方法）
```java
    ResponseResult responseResult = userServiceConsumer.get(url, param);
```

> url: 请求地址

> param: 请求参数，同时支持Map和VO对象（get方法目前只支持Map入参），VO对象请继承ParamVO 

- 解析返回值

> 对象：自动将data转换为对象

```java
    if (responseResult.isSuccessful()) {
        User user = userServiceConsumer.getData(responseResult, User.class);
        long id = user.getUserId();
        String name = user.getUserName();
        String phone = user.getUserPhone();
    } else {
        int errorCode = responseResult.getCode();
        String errorMessage = responseResult.getMsg();
    }
```

> 对象数组：自动将data转换为对象数组

```java
    if (responseResult.isSuccessful()) {
        List<User> userList = userServiceConsumer.getDataArray(responseResult, User.class);
        for(User user : userList) {
            long id = user.getUserId();
            String name = user.getUserName();
            String phone = user.getUserPhone();
        }
    } else {
        int errorCode = responseResult.getCode();
        String errorMessage = responseResult.getMsg();
    }
```


## 版本

### V1.0

* 请设置自己的callSystemID（kingold.service.callSystemID）
* 合并为service-consumer一个JAR
